# Améliorations multijoueur

Cette version renforce fortement l’aspect multijoueur du jeu.

## Escouades et raids

- progression d’escouade avec `niveau`, `xp`, `coffre` et `victoires`
- bonus de synergie calculé selon les relations entre membres
- capacité d’escouade qui augmente avec le niveau
- raids plus dynamiques avec :
  - combos personnels
  - coups critiques
  - bonus d’escouade
  - boss plus solides et jackpots mieux scalés
- récompenses de raid enrichies avec argent, XP, SocialCoins et progression d’escouade
- classement mondial enrichi avec top escouades et top guildes

## Social multijoueur

- les collaborations actives donnent désormais de vrais bonus de croissance
- les communautés donnent un bonus collectif selon leur taille
- ajout de `communaute` et `rejoindre_communaute`
- invitations de communauté utilisables en pratique
- posts, stories et lives peuvent devenir viraux
- les actions sociales donnent aussi des SocialCoins
- les dons sur live apportent maintenant des bonus au créateur
- correction de la logique de note sociale pour éviter les doublons incohérents
- maintenance sociale ajoutée pour nettoyer lives, tendances, collabs et sondages expirés

## Guildes

- panneau de guilde enrichi avec guerre active et membres les plus actifs
- dons de guilde plus utiles :
  - XP joueur
  - XP de guilde
  - meilleure boucle de progression collective
- guerre de guildes plus amusante :
  - attaques avec vrai calcul de puissance
  - cooldown d’attaque
  - gain de points variable
  - butin pris dans la trésorerie adverse
- correction de la reddition de guerre
- maintenance de guilde branchée dans le scheduler
- les quêtes de guilde peuvent maintenant se terminer correctement et distribuer leurs récompenses
- les compétitions de guilde ne redémarrent plus abusivement chaque jour

## Bot principal

- nouvelles commandes enregistrées :
  - `/communaute`
  - `/rejoindre_communaute`
  - `/parrainage`
- maintenance quotidienne enrichie pour les systèmes sociaux et de guilde

## Cohérence de jeu

- ajout d’un calcul central de cohérence entre faim, énergie, stress, santé et bonheur
- l’état global impacte désormais :
  - les revenus passifs
  - le bonus quotidien
  - le rendement au travail
  - l’efficacité du sommeil
- les états critiques combinés provoquent de vraies pénalités supplémentaires
- les actions de base se répondent mieux :
  - travailler fatigué ou affamé devient moins rentable
  - dormir en mauvais état récupère moins bien
  - les repas influencent aussi le stress et parfois le bonheur
- la simulation passive tient mieux compte des mauvaises habitudes et peut forcer un repos médical en cas de cumul extrême

## Parrainage

- système de parrainage branché au lien du bot : `https://t.me/MYLIFEYOURLIFESIM_bot`
- support du deep-link Telegram via `/start ref_<id>`
- nouvelle commande `/parrainage` avec :
  - lien personnel à partager
  - nombre de filleuls
  - filleuls activés / en attente
  - total des récompenses gagnées
- récompense immédiate quand un filleul rejoint via le lien
- récompense d’activation quand le filleul atteint un vrai palier de progression
- notifications et entrées de journal pour le parrain et le filleul
- mise à jour du nom complet des joueurs en base pour une meilleure cohérence d’affichage

## Vérifications

- compilation Python des fichiers modifiés validée
- import global de `bot.py` validé après installation des dépendances du projet
