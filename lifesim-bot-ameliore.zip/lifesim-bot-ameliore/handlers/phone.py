# handlers/phone.py — Téléphone interactif (version complète avec messagerie)
import aiosqlite
import time
import random
import re
import calendar
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import (
    DB_PATH, get_user, update_balance, update_field, now, add_notification,
    get_inventory, get_bank_account, get_all_bank_accounts, get_user_company
)
from utils.decorators import require_registered
from utils.helpers import fmt, escape_html, fmt_time, parse_amount
from utils.aesthetics import card, alert
from config import TIME_MULTIPLIER, SEASONS, SEASON_EFFECTS

# ============================================================
# INFOS DE JEU (heure, date, saison, météo) - TOUT EN UTC
# ============================================================

def get_game_datetime():
    real_ts = int(time.time())
    game_seconds = real_ts * TIME_MULTIPLIER
    ref_ts = 1704067200  # 2024-01-01 00:00:00 UTC
    game_ts = ref_ts + game_seconds
    gm = time.gmtime(game_ts)
    year, month, day = gm.tm_year, gm.tm_mon, gm.tm_mday
    hour, minute = gm.tm_hour, gm.tm_min

    if month in (3, 4, 5):
        season = "Printemps"
    elif month in (6, 7, 8):
        season = "Été"
    elif month in (9, 10, 11):
        season = "Automne"
    else:
        season = "Hiver"

    weather_options = {
        "Printemps": ["☀️ Ensoleillé", "🌦️ Averses", "🌈 Arc-en-ciel", "☁️ Nuageux"],
        "Été": ["☀️ Torride", "⛅ Nuageux", "🌩️ Orage", "🌤️ Doux"],
        "Automne": ["🍂 Brumeux", "🌧️ Pluvieux", "☁️ Couvert", "🌫️ Brouillard"],
        "Hiver": ["❄️ Neigeux", "🌨️ Tempête", "☀️ Froid sec", "🌬️ Vent glacial"]
    }
    weather = random.choice(weather_options.get(season, ["🌤️ Variable"]))

    return {
        "hour": hour, "minute": minute, "day": day, "month": month, "year": year,
        "season": season, "weather": weather, "game_ts": game_ts, "real_ts": real_ts
    }

# ============================================================
# CALENDRIER (UTC)
# ============================================================

async def get_calendar_events(month_ts: int, limit: int = 20):
    """Récupère les événements pour un mois donné (timestamp UTC du 1er du mois)."""
    gm = time.gmtime(month_ts)
    year, month = gm.tm_year, gm.tm_mon
    first_day_ts = calendar.timegm((year, month, 1, 0, 0, 0))
    if month == 12:
        next_year, next_month = year + 1, 1
    else:
        next_year, next_month = year, month + 1
    last_day_ts = calendar.timegm((next_year, next_month, 1, 0, 0, 0)) - 1

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT date, title, description FROM game_calendar WHERE date >= ? AND date <= ? ORDER BY date",
            (first_day_ts, last_day_ts)
        ) as cur:
            return [dict(row) for row in await cur.fetchall()]

async def add_personal_event(user_id: int, title: str, date_ts: int, description: str = ""):
    """Ajoute un événement personnel dans le calendrier (timestamp UTC)."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO game_calendar (date, title, description, created_at, user_id) VALUES (?, ?, ?, ?, ?)",
            (date_ts, title, description, now(), user_id)
        )
        await db.commit()

# ============================================================
# MESSAGERIE
# ============================================================

async def send_phone_message(from_id: int, to_id: int, message: str) -> bool:
    """Envoie un message via le téléphone."""
    if len(message) > 500:
        return False
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO phone_messages (from_id, to_id, message, created_at, read) VALUES (?, ?, ?, ?, 0)",
            (from_id, to_id, message, now())
        )
        await db.commit()
    from_user = await get_user(from_id)
    await add_notification(
        to_id,
        f"📱 Nouveau message de {from_user['full_name']} : {message[:100]}{'...' if len(message) > 100 else ''}"
    )
    return True

# ============================================================
# ASSISTANT (conseils personnalisés)
# ============================================================

async def get_assistant_advice(user_id: int):
    u = await get_user(user_id)
    messages = []

    if u.get("health", 100) < 50:
        messages.append("❤️ Ta santé est faible. Va consulter un médecin avec /medecin ou prends des médicaments.")
    if u.get("energy", 100) < 30:
        messages.append("⚡ Tu es épuisé. Dors avec /dormir ou repose-toi.")
    if u.get("hunger", 100) < 40:
        messages.append("🍽️ Tu as faim ! Mange avec /manger.")
    if u.get("stress", 0) > 70:
        messages.append("😰 Ton stress est élevé. Fais une pause, va au gym ou voyage.")
    if u.get("balance", 0) < 5000:
        messages.append("💰 Tes finances sont serrées. /travailler ou /quotidien pour gagner de l'argent.")
    if u.get("karma", 0) < -20:
        messages.append("🌟 Ton karma est négatif. Fais des bonnes actions (dons, charité).")
    if not u.get("job") or u.get("job") == "Livreur":
        messages.append("💼 Un meilleur métier t'attend ! Étudie avec /etudes et passe des examens.")
    if u.get("level", 1) < 5:
        messages.append("📈 Gagne de l'XP avec les missions (/missions) et en travaillant.")

    if not messages:
        messages.append("✅ Tout va bien ! Continue comme ça, tu es sur la bonne voie.")
    return random.choice(messages[:3])

# ============================================================
# COMMANDE PRINCIPALE
# ============================================================

@require_registered
async def cmd_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche l'écran d'accueil du téléphone."""
    user = update.effective_user
    u = await get_user(user.id)
    dt = get_game_datetime()

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, title, message, created_at FROM notifications WHERE user_id = ? AND sent = 1 ORDER BY created_at DESC LIMIT 3",
            (user.id,)
        ) as cur:
            notifs = [dict(row) for row in await cur.fetchall()]

    lines = [
        f"🕒 <b>{dt['hour']:02d}:{dt['minute']:02d}</b>",
        f"📅 {dt['day']:02d}/{dt['month']:02d}/{dt['year']}",
        f"🍃 Saison : <b>{dt['season']}</b>  🌤️ {dt['weather']}",
        f"💵 Solde : <b>{fmt(u['balance'])}</b>  ⭐ Niv.{u['level']}",
        "",
    ]
    if notifs:
        lines.append("🔔 <b>Dernières notifs</b>")
        for n in notifs[:2]:
            lines.append(f"  • {escape_html(n['title'])} — {fmt_time(now() - n['created_at'])}")
    else:
        lines.append("📭 Aucune notification récente.")

    keyboard = [
        [InlineKeyboardButton("📅 Calendrier", callback_data="phone_calendar"),
         InlineKeyboardButton("📨 Messages", callback_data="phone_messages")],
        [InlineKeyboardButton("💡 Assistant", callback_data="phone_assistant"),
         InlineKeyboardButton("🏦 Banque", callback_data="phone_bank")],
        [InlineKeyboardButton("📦 Inventaire", callback_data="phone_inventory"),
         InlineKeyboardButton("🏪 Marché", callback_data="phone_market")],
        [InlineKeyboardButton("👤 Profil", callback_data="phone_profile"),
         InlineKeyboardButton("⚙️ Paramètres", callback_data="phone_settings")],
        [InlineKeyboardButton("❌ Fermer", callback_data="phone_close")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        card("📱 TÉLÉPHONE", lines, icon="📱", style="thick"),
        parse_mode="HTML",
        reply_markup=reply_markup
    )

# ============================================================
# COMMANDE POUR ENVOYER UN MESSAGE
# ============================================================

@require_registered
async def cmd_phone_msg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Envoie un message à un autre joueur."""
    user = update.effective_user
    if len(context.args) < 2:
        await update.message.reply_text(
            "Usage : `/phone_msg @utilisateur [message]`\n"
            "Exemple : `/phone_msg @mauridieu Salut, on se voit au casino ?`",
            parse_mode="Markdown"
        )
        return

    target_username = context.args[0].lstrip("@")
    target = None
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT user_id, full_name FROM users WHERE username = ? AND registered = 1",
            (target_username,)
        ) as cur:
            row = await cur.fetchone()
        if not row:
            if target_username.isdigit():
                async with db.execute(
                    "SELECT user_id, full_name FROM users WHERE user_id = ? AND registered = 1",
                    (int(target_username),)
                ) as cur2:
                    row = await cur2.fetchone()
        if not row:
            await update.message.reply_text("❌ Joueur introuvable ou non enregistré.")
            return
        target_id, target_name = row

    if target_id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas t'envoyer un message à toi-même.")
        return

    message = " ".join(context.args[1:])
    if len(message) > 500:
        await update.message.reply_text("❌ Message trop long (max 500 caractères).")
        return

    success = await send_phone_message(user.id, target_id, message)
    if not success:
        await update.message.reply_text("❌ Erreur lors de l'envoi.")
        return

    await update.message.reply_text(
        f"✅ Message envoyé à **{target_name}** via le téléphone.\n"
        f"📝 *{message[:100]}{'...' if len(message) > 100 else ''}*",
        parse_mode="Markdown"
    )

# ============================================================
# CALLBACKS PRINCIPAUX
# ============================================================

async def phone_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user = query.from_user
    u = await get_user(user.id)

    if data == "phone_close":
        await query.message.delete()
        return

    if data == "phone_home":
        dt = get_game_datetime()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT id, title, message, created_at FROM notifications WHERE user_id = ? AND sent = 1 ORDER BY created_at DESC LIMIT 3",
                (user.id,)
            ) as cur:
                notifs = [dict(row) for row in await cur.fetchall()]
        lines = [
            f"🕒 <b>{dt['hour']:02d}:{dt['minute']:02d}</b>",
            f"📅 {dt['day']:02d}/{dt['month']:02d}/{dt['year']}",
            f"🍃 Saison : <b>{dt['season']}</b>  🌤️ {dt['weather']}",
            f"💵 Solde : <b>{fmt(u['balance'])}</b>  ⭐ Niv.{u['level']}",
            "",
        ]
        if notifs:
            lines.append("🔔 <b>Dernières notifs</b>")
            for n in notifs[:2]:
                lines.append(f"  • {escape_html(n['title'])} — {fmt_time(now() - n['created_at'])}")
        else:
            lines.append("📭 Aucune notification récente.")
        keyboard = [
            [InlineKeyboardButton("📅 Calendrier", callback_data="phone_calendar"),
             InlineKeyboardButton("📨 Messages", callback_data="phone_messages")],
            [InlineKeyboardButton("💡 Assistant", callback_data="phone_assistant"),
             InlineKeyboardButton("🏦 Banque", callback_data="phone_bank")],
            [InlineKeyboardButton("📦 Inventaire", callback_data="phone_inventory"),
             InlineKeyboardButton("🏪 Marché", callback_data="phone_market")],
            [InlineKeyboardButton("👤 Profil", callback_data="phone_profile"),
             InlineKeyboardButton("⚙️ Paramètres", callback_data="phone_settings")],
            [InlineKeyboardButton("❌ Fermer", callback_data="phone_close")]
        ]
        await query.edit_message_text(
            card("📱 TÉLÉPHONE", lines, icon="📱", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    # --------------------------------------------
    # CALENDRIER (UTC)
    # --------------------------------------------
    if data == "phone_calendar":
        dt = get_game_datetime()
        first_day_ts = calendar.timegm((dt['year'], dt['month'], 1, 0, 0, 0))
        events = await get_calendar_events(first_day_ts)
        month_name = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
                      "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"][dt['month']-1]

        body = [f"📅 <b>{month_name} {dt['year']}</b>"]
        if events:
            for ev in events[:15]:
                ev_date = time.gmtime(ev['date'])
                body.append(f"  {ev_date.tm_mday:02d} — {escape_html(ev['title'])}")
            if len(events) > 15:
                body.append(f"  _... et {len(events)-15} autres_")
        else:
            body.append("  Aucun événement ce mois-ci.")
        body.append("")
        body.append("➕ Pour ajouter un événement : /phone_event \"titre\" [jour] [mois] [année] (ex: /phone_event \"Anniversaire\" 15 8 2026)")

        keyboard = [[InlineKeyboardButton("🔙 Retour", callback_data="phone_home")]]
        await query.edit_message_text(
            card("📅 CALENDRIER", body, icon="📅", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    # --------------------------------------------
    # MESSAGES (conversations) - CORRECTION SQL
    # --------------------------------------------
    if data == "phone_messages":
        page = 1
        if ":" in data:
            try:
                page = int(data.split(":")[1])
            except:
                pass
        per_page = 10

        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            # On utilise une CTE pour récupérer les interlocuteurs uniques
            async with db.execute("""
                WITH interlocutors AS (
                    SELECT DISTINCT
                        CASE WHEN from_id = ? THEN to_id ELSE from_id END AS other_id
                    FROM phone_messages
                    WHERE from_id = ? OR to_id = ?
                )
                SELECT
                    i.other_id,
                    (SELECT full_name FROM users WHERE user_id = i.other_id) AS other_name,
                    (SELECT message FROM phone_messages
                     WHERE (from_id = ? AND to_id = i.other_id) OR (from_id = i.other_id AND to_id = ?)
                     ORDER BY created_at DESC LIMIT 1) AS last_message,
                    (SELECT created_at FROM phone_messages
                     WHERE (from_id = ? AND to_id = i.other_id) OR (from_id = i.other_id AND to_id = ?)
                     ORDER BY created_at DESC LIMIT 1) AS last_date,
                    (SELECT COUNT(*) FROM phone_messages
                     WHERE from_id = i.other_id AND to_id = ? AND read = 0) AS unread
                FROM interlocutors i
                ORDER BY last_date DESC
                LIMIT ? OFFSET ?
            """, (user.id, user.id, user.id,
                  user.id, user.id, user.id, user.id,
                  user.id,
                  per_page, (page-1)*per_page)) as cur:
                convs = [dict(row) for row in await cur.fetchall()]

            # Compter le nombre total de conversations
            async with db.execute("""
                SELECT COUNT(DISTINCT CASE WHEN from_id = ? THEN to_id ELSE from_id END) AS total
                FROM phone_messages
                WHERE from_id = ? OR to_id = ?
            """, (user.id, user.id, user.id)) as cur2:
                total_row = await cur2.fetchone()
                total = total_row[0] if total_row else 0

        if not convs:
            body = ["📭 Aucune conversation."]
            keyboard = [[InlineKeyboardButton("🔙 Retour", callback_data="phone_home")]]
            await query.edit_message_text(
                card("📨 MESSAGES", body, icon="📨", style="thick"),
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            return

        body = [f"📨 <b>Conversations</b> (page {page}/{max(1, (total+per_page-1)//per_page)})"]
        for conv in convs:
            unread_badge = f" 🔴({conv['unread']})" if conv['unread'] > 0 else ""
            last_date = fmt_time(now() - conv['last_date'])
            body.append(f"  • <b>{conv['other_name']}</b>{unread_badge} — {last_date}")
            body.append(f"    {conv['last_message'][:80]}{'...' if len(conv['last_message']) > 80 else ''}")

        keyboard = []
        nav = []
        if page > 1:
            nav.append(InlineKeyboardButton("◀️", callback_data=f"phone_messages:{page-1}"))
        if page * per_page < total:
            nav.append(InlineKeyboardButton("▶️", callback_data=f"phone_messages:{page+1}"))
        if nav:
            keyboard.append(nav)
        keyboard.append([InlineKeyboardButton("📤 Nouveau message", callback_data="phone_new_msg")])
        keyboard.append([InlineKeyboardButton("🔙 Retour", callback_data="phone_home")])

        await query.edit_message_text(
            card("📨 MESSAGES", body, icon="📨", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    # --------------------------------------------
    # NOUVEAU MESSAGE
    # --------------------------------------------
    if data == "phone_new_msg":
        await query.edit_message_text(
            "📤 **Nouveau message**\n\n"
            "Envoie un message avec :\n"
            "`/phone_msg @utilisateur [ton message]`\n\n"
            "Exemple : `/phone_msg @mauridieu Salut !`",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Retour", callback_data="phone_messages")]])
        )
        return

    # --------------------------------------------
    # ASSISTANT
    # --------------------------------------------
    if data == "phone_assistant":
        advice = await get_assistant_advice(user.id)
        body = [
            "🧠 <b>Assistant LifeSim</b>",
            "",
            advice,
            "",
            f"💵 Solde : {fmt(u['balance'])}",
            f"❤️ Santé : {u['health']}%  ⚡ Énergie : {u['energy']}%",
            f"🍽️ Faim : {u['hunger']}%  😊 Bonheur : {u['happiness']}%",
            f"😰 Stress : {u['stress']}%  🌟 Karma : {u['karma']}",
        ]
        keyboard = [[InlineKeyboardButton("🔄 Nouveau conseil", callback_data="phone_assistant"),
                     InlineKeyboardButton("🔙 Retour", callback_data="phone_home")]]
        await query.edit_message_text(
            card("🧠 ASSISTANT", body, icon="🧠", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    # --------------------------------------------
    # BANQUE
    # --------------------------------------------
    if data == "phone_bank":
        accounts = await get_all_bank_accounts(user.id)
        if not accounts:
            body = ["Aucun compte bancaire.", "Ouvre un compte avec /ouvrir"]
        else:
            body = [f"🏦 <b>Comptes bancaires</b>"]
            for acc in accounts:
                body.append(f"  • {acc['bank_name']} : {fmt(acc['balance'])}")
                if acc['loan'] > 0:
                    body.append(f"    Prêt : {fmt(acc['loan'])}")
        body.append("")
        body.append("💸 Tes Comptes : /mescomptes")
        keyboard = [[InlineKeyboardButton("🔙 Retour", callback_data="phone_home")]]
        await query.edit_message_text(
            card("🏦 BANQUE", body, icon="🏦", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    # --------------------------------------------
    # INVENTAIRE
    # --------------------------------------------
    if data == "phone_inventory":
        inv = await get_inventory(user.id)
        if not inv:
            body = ["📭 Inventaire vide."]
        else:
            body = [f"📦 <b>Inventaire</b> ({len(inv)} items)"]
            for item in inv[:10]:
                body.append(f"  • {item['item_name']} x{item['quantity']} (ID {item['item_id']})")
            if len(inv) > 10:
                body.append(f"  _... et {len(inv)-10} autres_")
        body.append("")
        body.append("Utilise /useitem [id] [qty] pour utiliser un item.")
        keyboard = [[InlineKeyboardButton("🔙 Retour", callback_data="phone_home")]]
        await query.edit_message_text(
            card("📦 INVENTAIRE", body, icon="📦", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    # --------------------------------------------
    # MARCHÉ (annonces)
    # --------------------------------------------
    if data == "phone_market":
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("""
                SELECT ml.listing_id, ml.price, ml.quantity, i.name, i.emoji, u.full_name as seller
                FROM market_listings ml
                JOIN items i ON i.item_id = ml.item_id
                JOIN users u ON u.user_id = ml.seller_id
                WHERE ml.status = 'active' AND ml.expires_at > ?
                ORDER BY ml.price ASC
                LIMIT 10
            """, (now(),)) as cur:
                listings = await cur.fetchall()
        if not listings:
            body = ["🏪 Aucune annonce active."]
        else:
            body = ["🏪 <b>Dernières annonces</b>"]
            for l in listings:
                body.append(f"  {l['emoji']} <b>{escape_html(l['name'])}</b> — {fmt(l['price'])}/u (x{l['quantity']})")
                body.append(f"    Vendeur : {escape_html(l['seller'])} | ID: {l['listing_id']}")
        body.append("")
        body.append("Acheter : /buyitem [listing_id] [qty]")
        keyboard = [[InlineKeyboardButton("🔙 Retour", callback_data="phone_home")]]
        await query.edit_message_text(
            card("🏪 MARCHÉ", body, icon="🏪", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    # --------------------------------------------
    # PROFIL
    # --------------------------------------------
    if data == "phone_profile":
        u_full = await get_user(user.id)
        body = [
            f"👤 <b>{escape_html(user.full_name)}</b>",
            f"🆔 ID: <code>{user.id}</code>",
            f"⭐ Niveau {u_full['level']} — XP: {u_full['xp']}",
            f"💰 Solde: {fmt(u_full['balance'])}",
            f"🌟 Karma: {u_full['karma']}  👑 Prestige: {u_full['prestige']}",
            f"💼 Métier: {u_full['job']}",
            f"🎓 Diplôme: {u_full['diplome'] or 'Aucun'}",
            f"❤️ Santé: {u_full['health']}%  ⚡ Énergie: {u_full['energy']}%",
            f"🍽️ Faim: {u_full['hunger']}%  😊 Bonheur: {u_full['happiness']}%",
            f"😰 Stress: {u_full['stress']}%",
        ]
        keyboard = [[InlineKeyboardButton("🔙 Retour", callback_data="phone_home")]]
        await query.edit_message_text(
            card("👤 PROFIL", body, icon="👤", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    # --------------------------------------------
    # PARAMÈTRES
    # --------------------------------------------
    if data == "phone_settings":
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT phone_theme, phone_ringtone FROM users WHERE user_id = ?", (user.id,)) as cur:
                pref = await cur.fetchone()
        theme = pref["phone_theme"] if pref else "dark"
        ringtone = pref["phone_ringtone"] if pref else "classic"

        keyboard = [
            [InlineKeyboardButton(f"🎨 Thème : {'Sombre' if theme == 'dark' else 'Clair'}", callback_data="phone_theme_toggle")],
            [InlineKeyboardButton(f"🔔 Sonnerie : {'Classique' if ringtone == 'classic' else 'Moderne'}", callback_data="phone_ringtone_toggle")],
            [InlineKeyboardButton("🔙 Retour", callback_data="phone_home")]
        ]
        await query.edit_message_text(
            card("⚙️ PARAMÈTRES", [
                f"Thème actuel : <b>{theme}</b>",
                f"Sonnerie : <b>{ringtone}</b>",
                "",
                "Clique sur un bouton pour changer."
            ], icon="⚙️", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    # --------------------------------------------
    # TOGGLE THÈME / SONNERIE
    # --------------------------------------------
    if data == "phone_theme_toggle":
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT phone_theme FROM users WHERE user_id = ?", (user.id,)) as cur:
                row = await cur.fetchone()
            current = row[0] if row else "dark"
            new_theme = "light" if current == "dark" else "dark"
            await db.execute("UPDATE users SET phone_theme = ? WHERE user_id = ?", (new_theme, user.id))
            await db.commit()
        await query.answer(f"Thème changé en {new_theme}", show_alert=True)
        await phone_callback(update, context)
        return

    if data == "phone_ringtone_toggle":
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT phone_ringtone FROM users WHERE user_id = ?", (user.id,)) as cur:
                row = await cur.fetchone()
            current = row[0] if row else "classic"
            new_ringtone = "modern" if current == "classic" else "classic"
            await db.execute("UPDATE users SET phone_ringtone = ? WHERE user_id = ?", (new_ringtone, user.id))
            await db.commit()
        await query.answer(f"Sonnerie changée en {new_ringtone}", show_alert=True)
        await phone_callback(update, context)
        return

# ============================================================
# COMMANDE POUR AJOUTER UN ÉVÉNEMENT PERSONNEL (UTC)
# ============================================================

@require_registered
async def cmd_phone_event(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ajoute un événement personnel au calendrier (date UTC)."""
    user = update.effective_user
    if len(context.args) < 2:
        await update.message.reply_text(
            "Usage : /phone_event \"titre\" [date_timestamp] ou /phone_event \"titre\" [jour] [mois] [année]"
        )
        return

    text = " ".join(context.args)
    match = re.match(r'^"(.+?)"\s+(.+)$', text)
    if not match:
        await update.message.reply_text("❌ Titre invalide. Utilise des guillemets : /phone_event \"Mon événement\" 15 8 2026")
        return
    title = match.group(1)
    rest = match.group(2)

    date_ts = None
    parts = rest.split()
    if len(parts) == 1 and parts[0].isdigit():
        date_ts = int(parts[0])
    elif len(parts) == 3 and all(p.isdigit() for p in parts):
        day, month, year = int(parts[0]), int(parts[1]), int(parts[2])
        try:
            date_ts = calendar.timegm((year, month, day, 0, 0, 0))
        except:
            await update.message.reply_text("❌ Date invalide.")
            return
    else:
        await update.message.reply_text("❌ Format de date invalide. Utilise timestamp ou jour mois année.")
        return

    if date_ts < now():
        await update.message.reply_text("❌ La date doit être dans le futur.")
        return

    await add_personal_event(user.id, title, date_ts, f"Événement personnel de {user.full_name}")
    date_str = time.strftime('%d/%m/%Y', time.gmtime(date_ts))
    await add_notification(user.id, f"📅 Événement ajouté : {title} le {date_str}")
    await update.message.reply_text(f"✅ Événement **{title}** ajouté au calendrier pour le {date_str}.")

# ============================================================
# FONCTION POUR AJOUTER DES ÉVÉNEMENTS ALÉATOIRES (scheduler)
# ============================================================

async def add_random_calendar_events():
    """Ajoute un événement aléatoire pour le jour suivant (si aucun événement n'existe)."""
    tomorrow_ts = now() + 86400
    day_start = tomorrow_ts - (tomorrow_ts % 86400)
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT id FROM game_calendar WHERE date = ?", (day_start,)) as cur:
            if await cur.fetchone():
                return
        events = [
            ("📈 Jour de paie", "Tous les joueurs reçoivent leur salaire."),
            ("🎉 Fête nationale", "Événement festif : bonheur +10%."),
            ("🌪️ Tempête", "Les jardins perdent 20% de leurs récoltes."),
            ("🏛️ Élection", "Vote pour élire un nouveau leader."),
            ("🎪 Carnaval", "Réduction de 20% sur les articles de luxe."),
            ("🔬 Découverte", "R&D des entreprises +5%."),
            ("💥 Crash boursier", "Marché financier en baisse de 15%."),
            ("🚀 Lancement spatial", "Les voyages dans l'espace sont à -30%."),
            ("🎭 Festival du cinéma", "Bonus de prestige pour les artistes."),
            ("☕ Journée du café", "Restauration d'énergie gratuite."),
        ]
        chosen = random.choice(events)
        await db.execute(
            "INSERT INTO game_calendar (date, title, description, created_at) VALUES (?, ?, ?, ?)",
            (day_start, chosen[0], chosen[1], now())
        )
        await db.commit()