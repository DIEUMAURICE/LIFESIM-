# handlers/vehicle.py — Version améliorée (pagination, notifications, robustesse)
import random
import aiosqlite
from telegram import Update
from telegram.ext import ContextTypes
from database import DB_PATH, get_user, update_balance, get_vehicles, increment_field, now, add_notification
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, fmt_time, escape_html
from utils.pagination import paginate_lines
from config import VEHICLES

MAX_VEHICLES = 10

# ==================== COMMANDES ====================
@require_registered
@require_free
async def cmd_vehicules_liste(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche le catalogue des véhicules disponibles."""
    text = "🚗 <b>Showroom de véhicules</b>\n\n"
    for vtype, data in VEHICLES.items():
        text += (
            f"{data['emoji']} <b>{vtype}</b>\n"
            f"  💰 Prix : {fmt(data['price'])}\n"
            f"  🔧 Entretien : {fmt(data['maint'])}/mois\n"
            f"  ✨ Prestige : +{data['status']} pts\n\n"
        )
    text += "<i>/acheterv [véhicule] pour acheter</i>"
    await update.message.reply_text(text, parse_mode="HTML")

@require_registered
@require_free
@cooldown("buy_vehicle", 10, "⏳ Attends un instant avant d'acheter un autre véhicule.")
async def cmd_acheter_vehicule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not context.args:
        await update.message.reply_text("Usage : /acheterv [nom du véhicule]")
        return

    vtype = " ".join(context.args).title()
    matched = None
    for v in VEHICLES:
        if v.lower() == vtype.lower():
            matched = v
            break
    if not matched:
        await update.message.reply_text("❌ Véhicule inconnu. /vehicules pour voir la liste.")
        return

    data = VEHICLES[matched]
    if u["balance"] < data["price"]:
        await update.message.reply_text(
            f"❌ Fonds insuffisants !\n"
            f"💰 Prix : {fmt(data['price'])}\n"
            f"💵 Ton solde : {fmt(u['balance'])}",
            parse_mode="HTML"
        )
        return

    vehs = await get_vehicles(user.id)
    if len(vehs) >= MAX_VEHICLES:
        await update.message.reply_text(f"❌ Tu as déjà {MAX_VEHICLES} véhicules, vends-en un avant d'en acheter un autre.")
        return

    await update_balance(user.id, -data["price"])
    await increment_field(user.id, "prestige", data["status"])

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO vehicles (user_id, veh_type, condition, insured, purchased_at, last_maintenance) VALUES (?,?,100,0,?,?)",
            (user.id, matched, now(), now())
        )
        await db.commit()

    await update.message.reply_text(
        f"✅ <b>{matched} acheté !</b>\n\n"
        f"{data['emoji']} Bienvenue dans ta nouvelle monture !\n"
        f"💰 Prix : {fmt(data['price'])}\n"
        f"🔧 Entretien mensuel : {fmt(data['maint'])}\n"
        f"✨ +{data['status']} prestige\n\n"
        f"👉 /assurerv [numéro] pour l'assurer\n"
        f"👉 /mesvehicules pour voir ta collection",
        parse_mode="HTML"
    )
    await add_notification(user.id, f"🚗 Tu as acheté un {matched} !")

@require_registered
@require_free
async def cmd_mes_vehicules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche la liste des véhicules du joueur avec pagination."""
    user = update.effective_user
    vehs = await get_vehicles(user.id)

    if not vehs:
        await update.message.reply_text(
            "🚗 Tu ne possèdes aucun véhicule.\n"
            "/vehicules pour voir le catalogue."
        )
        return

    lines = []
    for i, v in enumerate(vehs, 1):
        data = VEHICLES.get(v["veh_type"], {})
        cond_bar = "🟢" if v["condition"] >= 70 else "🟡" if v["condition"] >= 40 else "🔴"
        ins_text = "✅ Assuré" if v["insured"] else "❌ Non assuré"
        last_maint = v.get("last_maintenance", 0)
        maint_ago = fmt_time(now() - last_maint) if last_maint else "jamais"
        lines.append(
            f"#{i} {data.get('emoji', '🚗')} <b>{escape_html(v['veh_type'])}</b>\n"
            f"  {cond_bar} État : {v['condition']}%\n"
            f"  🏥 {ins_text}\n"
            f"  🔧 Dernier entretien : il y a {maint_ago}"
        )

    header = f"🚗 <b>Tes véhicules</b> (total: {len(vehs)})\n\n"
    footer = ("\n<i>/reparer [numéro] — réparer\n"
              "/assurerv [numéro] — assurer\n"
              "/vendrevehicule [numéro] — vendre\n"
              "/vehicule_info [numéro] — détails</i>")

    page = 1
    if context.args and context.args[0].isdigit():
        page = int(context.args[0])
    text, markup = await paginate_lines(lines, page, per_page=10, header=header, footer=footer)
    if markup:
        await update.message.reply_text(text, parse_mode="HTML", reply_markup=markup)
    else:
        await update.message.reply_text(text, parse_mode="HTML")

@require_registered
@require_free
@cooldown("repair_vehicle", 10, "⏳ Attends un instant avant de réparer à nouveau.")
async def cmd_reparer_vehicule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    vehs = await get_vehicles(user.id)

    if not context.args:
        await update.message.reply_text("Usage : /reparer [numéro de véhicule]")
        return

    try:
        idx = int(context.args[0]) - 1
        veh = vehs[idx]
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Numéro invalide. Utilise /mesvehicules pour voir la liste.")
        return

    if veh["condition"] >= 100:
        await update.message.reply_text("✅ Ton véhicule est déjà en parfait état !")
        return

    veh_data = VEHICLES.get(veh["veh_type"], {})
    repair_cost = int((100 - veh["condition"]) * veh_data.get("price", 10000) / 500)
    if repair_cost < 100:
        repair_cost = 100  # coût minimum

    if u["balance"] < repair_cost:
        await update.message.reply_text(f"❌ Réparation coûte {fmt(repair_cost)}\n💵 Ton solde : {fmt(u['balance'])}", parse_mode="HTML")
        return

    await update_balance(user.id, -repair_cost)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE vehicles SET condition=100, last_maintenance=? WHERE veh_id=?", (now(), veh["veh_id"]))
        await db.commit()

    await update.message.reply_text(
        f"🔧 <b>Réparation terminée !</b>\n\n"
        f"{veh_data.get('emoji', '🚗')} {escape_html(veh['veh_type'])}\n"
        f"État : {veh['condition']}% → 100%\n"
        f"💰 Coût : {fmt(repair_cost)}",
        parse_mode="HTML"
    )
    await add_notification(user.id, f"🔧 Tu as réparé ton {veh['veh_type']} pour {fmt(repair_cost)}.")

@require_registered
@require_free
@cooldown("insure_vehicle", 10, "⏳ Attends un instant avant d'assurer un autre véhicule.")
async def cmd_assurer_vehicule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    vehs = await get_vehicles(user.id)

    if not context.args:
        await update.message.reply_text("Usage : /assurerv [numéro de véhicule]")
        return

    try:
        idx = int(context.args[0]) - 1
        veh = vehs[idx]
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Numéro invalide. Utilise /mesvehicules pour voir la liste.")
        return

    if veh["insured"]:
        await update.message.reply_text("✅ Ce véhicule est déjà assuré !")
        return

    veh_data = VEHICLES.get(veh["veh_type"], {})
    insurance_cost = int(veh_data.get("price", 10000) * 0.05)  # 5% du prix par mois
    if insurance_cost < 100:
        insurance_cost = 100

    if u["balance"] < insurance_cost:
        await update.message.reply_text(f"❌ Assurance coûte {fmt(insurance_cost)}/mois", parse_mode="HTML")
        return

    await update_balance(user.id, -insurance_cost)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE vehicles SET insured=1 WHERE veh_id=?", (veh["veh_id"],))
        await db.commit()

    await update.message.reply_text(
        f"✅ <b>Véhicule assuré !</b>\n\n"
        f"{veh_data.get('emoji','🚗')} {escape_html(veh['veh_type'])}\n"
        f"💰 Prime mensuelle : {fmt(insurance_cost)}\n"
        f"_En cas d'accident, tu es couvert !_",
        parse_mode="HTML"
    )
    await add_notification(user.id, f"🏥 Tu as assuré ton {veh['veh_type']} pour {fmt(insurance_cost)}/mois.")

@require_registered
@require_free
@cooldown("sell_vehicle", 10, "⏳ Attends un instant avant de vendre un autre véhicule.")
async def cmd_vendre_vehicule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Vendre un véhicule (prix de reprise = 60% de la valeur neuve, déduction selon état)."""
    user = update.effective_user
    vehs = await get_vehicles(user.id)

    if not context.args:
        await update.message.reply_text("Usage : /vendrevehicule [numéro] (/mesvehicules pour voir la liste)")
        return

    try:
        idx = int(context.args[0]) - 1
        veh = vehs[idx]
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Numéro invalide.")
        return

    veh_data = VEHICLES.get(veh["veh_type"], {})
    condition = veh["condition"]
    base_price = veh_data.get("price", 0)
    # Prix de reprise : 60% de la valeur neuve, dégradé selon état
    sell_price = int(base_price * 0.6 * (condition / 100))
    if sell_price <= 0:
        await update.message.reply_text("❌ Ce véhicule ne vaut plus rien, tu peux le détruire (non implémenté).")
        return

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM vehicles WHERE veh_id=?", (veh["veh_id"],))
        await db.commit()

    await update_balance(user.id, sell_price)
    # Retirer le prestige (optionnel)
    await increment_field(user.id, "prestige", -veh_data.get("status", 0))

    await update.message.reply_text(
        f"💰 <b>Vente de véhicule</b>\n\n"
        f"{veh_data.get('emoji', '🚗')} {escape_html(veh['veh_type'])}\n"
        f"État : {condition}%\n"
        f"💰 Prix de reprise : {fmt(sell_price)}\n\n"
        f"_Tu regrettes peut-être..._",
        parse_mode="HTML"
    )
    await add_notification(user.id, f"💰 Tu as vendu ton {veh['veh_type']} pour {fmt(sell_price)}.")

# ==================== NOUVELLE COMMANDE : INFOS DÉTAILLÉES ====================
@require_registered
async def cmd_vehicule_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les détails complets d'un véhicule (par numéro)."""
    user = update.effective_user
    vehs = await get_vehicles(user.id)
    if not context.args:
        await update.message.reply_text("Usage : /vehicule_info [numéro] (voir /mesvehicules pour les numéros)")
        return
    try:
        idx = int(context.args[0]) - 1
        veh = vehs[idx]
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Numéro invalide.")
        return

    data = VEHICLES.get(veh["veh_type"], {})
    cond_bar = "█" * (veh["condition"] // 10) + "░" * (10 - veh["condition"] // 10)
    last_maint = veh.get("last_maintenance", 0)
    maint_ago = fmt_time(now() - last_maint) if last_maint else "jamais"
    purchased_ago = fmt_time(now() - veh.get("purchased_at", now()))

    text = (
        f"🚗 <b>Informations sur le véhicule</b>\n\n"
        f"{data.get('emoji', '🚗')} <b>{escape_html(veh['veh_type'])}</b>\n"
        f"💰 Valeur neuve : {fmt(data.get('price', 0))}\n"
        f"🔧 Entretien mensuel : {fmt(data.get('maint', 0))}\n"
        f"✨ Prestige : +{data.get('status', 0)}\n"
        f"🏚️ État : <code>{cond_bar}</code> {veh['condition']}%\n"
        f"🏥 Assurance : {'✅ Oui' if veh['insured'] else '❌ Non'}\n"
        f"🔧 Dernier entretien : il y a {maint_ago}\n"
        f"📅 Acheté il y a : {purchased_ago}\n"
    )
    await update.message.reply_text(text, parse_mode="HTML")

# ==================== MAINTENANCE QUOTIDIENNE ====================
async def process_vehicles_maintenance():
    """Appelé quotidiennement :
    - Détérioration légère (2% par jour, déjà dans degrade_vehicles)
    - Dégradation accélérée si plus de 30 jours sans entretien
    - Prélèvement des frais d'entretien et d'assurance
    - Accidents aléatoires (uniquement véhicules non assurés)
    """
    from config import VEHICLES
    async with aiosqlite.connect(DB_PATH) as db:
        # 1. Détérioration accélérée pour absence d'entretien (>30 jours)
        cutoff = now() - 30 * 86400
        async with db.execute("SELECT * FROM vehicles WHERE last_maintenance < ? AND condition > 0", (cutoff,)) as cur:
            neglected = await cur.fetchall()
        for v in neglected:
            deg = random.randint(5, 15)
            new_cond = max(0, v["condition"] - deg)
            await db.execute("UPDATE vehicles SET condition = ? WHERE veh_id = ?", (new_cond, v["veh_id"]))
            # Notifier le propriétaire
            await add_notification(v["user_id"], f"🚗 Ton {v['veh_type']} se dégrade faute d'entretien ! (-{deg}%)")

        # 2. Prélèvement des frais d'entretien mensuels et assurances
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM vehicles WHERE condition > 0") as cur:
            vehicles = await cur.fetchall()

        for v in vehicles:
            user_id = v["user_id"]
            veh_data = VEHICLES.get(v["veh_type"], {})
            maint_cost = veh_data.get("maint", 0)
            insur_cost = 0
            if v["insured"]:
                insur_cost = int(veh_data.get("price", 10000) * 0.05)
            total_cost = maint_cost + insur_cost
            if total_cost > 0:
                u = await get_user(user_id)
                if u["balance"] >= total_cost:
                    await update_balance(user_id, -total_cost)
                else:
                    # Pas assez d'argent : le véhicule se dégrade plus vite
                    penalty = 20
                    new_cond = max(0, v["condition"] - penalty)
                    await db.execute("UPDATE vehicles SET condition = ? WHERE veh_id = ?", (new_cond, v["veh_id"]))
                    await add_notification(user_id, f"⚠️ Entretien impayé ! Ton {v['veh_type']} perd {penalty}% d'état.")
                    if v["insured"]:
                        await db.execute("UPDATE vehicles SET insured = 0 WHERE veh_id = ?", (v["veh_id"],))
                        await add_notification(user_id, f"❌ Ton assurance a été résiliée pour impayé.")

        # 3. Accidents aléatoires (5% de chance par jour pour chaque véhicule non assuré)
        async with db.execute("SELECT veh_id, user_id, veh_type, condition, insured FROM vehicles WHERE condition > 0") as cur:
            all_veh = await cur.fetchall()
        for v in all_veh:
            if v["insured"]:
                continue
            if random.random() < 0.05:  # 5% par jour
                damage = random.randint(20, 50)
                new_cond = max(0, v["condition"] - damage)
                await db.execute("UPDATE vehicles SET condition = ? WHERE veh_id = ?", (new_cond, v["veh_id"]))
                await add_notification(v["user_id"], f"🚨 Accident ! Ton {v['veh_type']} a subi {damage}% de dégâts. (non assuré)")

        await db.commit()