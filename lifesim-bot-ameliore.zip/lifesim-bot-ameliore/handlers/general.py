"""
handlers/general.py — LIFESIM ULTRA V2
═══════════════════════════════════════════════════════════════════════
Commandes générales : /start, /menu, /aide, /guide, /nouveautes, /about
Refonte esthétique complète avec menu interactif boutons et liens sociaux.
Ajout Phase 0 : /shop (menu boutique unifié)
Ajout Phase 1 : commandes du marché joueur dans /aide et /menu
Mise à jour sociale avancée (liberté totale + multijoueur)
Mise à jour politique avancée (élections, partis, lois, référendums, destitution)
Version interactive du casino, fusions avec accord, produits à effets, négociation de contrats.
Téléphone intégré (hub central) avec messagerie privée.
"""
from datetime import datetime
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputFile
from telegram.ext import ContextTypes

from database import (
    DB_PATH, get_user, update_field, increment_field, update_balance,
    get_active_event, add_life_journal
)
from utils.decorators import require_registered
from utils.helpers import (
    fmt, now, get_level, lifestyle_score, life_state_label,
    wealth_class, karma_label, random_quote, xp_progress, escape_html
)
from utils.aesthetics import (
    card, stat_card, alert, age_stage,
)
from utils.simulation import apply_passive_simulation, current_season, SEASON_EFFECTS
from config import START_PHOTO_PATH
from handlers.missions import update_mission_progress

BOT_PUBLIC_LINK = "https://t.me/MYLIFEYOURLIFESIM_bot"
REFERRAL_JOIN_REFERRER = 15_000
REFERRAL_JOIN_REFERRED = 7_500
REFERRAL_JOIN_COINS = 15
REFERRAL_ACTIVATION_REFERRER = 40_000
REFERRAL_ACTIVATION_REFERRED = 20_000
REFERRAL_ACTIVATION_COINS = 30


async def _notify_user(bot, user_id: int, text: str):
    try:
        await bot.send_message(user_id, text, parse_mode="HTML")
    except Exception:
        pass


async def process_referral_progress(user_id: int, bot=None):
    """Active la seconde récompense quand le filleul progresse vraiment."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT r.referrer_id, u.level, u.total_earned, u.full_name, u.referral_activated
            FROM referrals r
            JOIN users u ON u.user_id = r.referred_id
            WHERE r.referred_id=? AND r.activated_at=0
        """, (user_id,)) as cur:
            row = await cur.fetchone()
        if not row:
            return False
        if row["referral_activated"]:
            return False
        if row["level"] < 3 or row["total_earned"] < 25_000:
            return False

        current = now()
        await db.execute("UPDATE referrals SET activated_at=? WHERE referred_id=?", (current, user_id))
        await db.execute(
            "UPDATE users SET referral_activated=1, social_coins=COALESCE(social_coins,0)+?, referral_rewards=referral_rewards+? WHERE user_id=?",
            (REFERRAL_ACTIVATION_COINS, REFERRAL_ACTIVATION_REFERRED, user_id)
        )
        await db.execute(
            "UPDATE users SET social_coins=COALESCE(social_coins,0)+?, referral_rewards=referral_rewards+? WHERE user_id=?",
            (REFERRAL_ACTIVATION_COINS, REFERRAL_ACTIVATION_REFERRER, row["referrer_id"])
        )
        await db.commit()

    await update_balance(user_id, REFERRAL_ACTIVATION_REFERRED)
    await update_balance(row["referrer_id"], REFERRAL_ACTIVATION_REFERRER)
    await add_life_journal(
        user_id, "parrainage",
        f"🎁 Récompense d'activation de parrainage reçue : {fmt(REFERRAL_ACTIVATION_REFERRED)} + {REFERRAL_ACTIVATION_COINS} SocialCoins.",
        severity="success"
    )
    await add_life_journal(
        row["referrer_id"], "parrainage",
        f"👥 Ton filleul {escape_html(row['full_name'])} s'est bien lancé : {fmt(REFERRAL_ACTIVATION_REFERRER)} + {REFERRAL_ACTIVATION_COINS} SocialCoins.",
        severity="success"
    )
    if bot:
        await _notify_user(
            bot,
            row["referrer_id"],
            f"🎉 <b>Ton filleul progresse vraiment !</b>\n"
            f"{escape_html(row['full_name'])} a validé son activation.\n"
            f"💰 Récompense : <b>{fmt(REFERRAL_ACTIVATION_REFERRER)}</b>\n"
            f"💎 Bonus : <b>{REFERRAL_ACTIVATION_COINS}</b> SocialCoins"
        )
        await _notify_user(
            bot,
            user_id,
            f"🎁 <b>Parrainage activé</b>\n"
            f"Tu as débloqué la récompense de progression.\n"
            f"💰 Gain : <b>{fmt(REFERRAL_ACTIVATION_REFERRED)}</b>\n"
            f"💎 Bonus : <b>{REFERRAL_ACTIVATION_COINS}</b> SocialCoins"
        )
    return True


async def _handle_referral_start(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> str:
    if not context.args:
        return ""
    token = context.args[0].strip()
    if not token.startswith("ref_"):
        return ""
    code = token[4:]
    if not code.isdigit():
        return ""

    referrer_id = int(code)
    if referrer_id == user_id:
        return ""

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT referred_by FROM users WHERE user_id=?", (user_id,)) as cur:
            current_user = await cur.fetchone()
        if not current_user or (current_user["referred_by"] or 0):
            return ""

        async with db.execute(
            "SELECT user_id, full_name, registered FROM users WHERE user_id=?",
            (referrer_id,)
        ) as cur:
            referrer = await cur.fetchone()
        if not referrer or not referrer["registered"]:
            return ""

        await db.execute("UPDATE users SET referred_by=? WHERE user_id=?", (referrer_id, user_id))
        await db.execute(
            "INSERT OR IGNORE INTO referrals(referrer_id, referred_id, created_at, starter_rewarded, activated_at) VALUES(?,?,?,?,0)",
            (referrer_id, user_id, now(), 1)
        )
        await db.execute(
            "UPDATE users SET referral_count=referral_count+1, social_coins=COALESCE(social_coins,0)+?, referral_rewards=referral_rewards+? WHERE user_id=?",
            (REFERRAL_JOIN_COINS, REFERRAL_JOIN_REFERRER, referrer_id)
        )
        await db.execute(
            "UPDATE users SET social_coins=COALESCE(social_coins,0)+?, referral_rewards=referral_rewards+? WHERE user_id=?",
            (REFERRAL_JOIN_COINS, REFERRAL_JOIN_REFERRED, user_id)
        )
        await db.commit()
        referrer_name = referrer["full_name"] or f"Joueur {referrer_id}"

    await update_balance(referrer_id, REFERRAL_JOIN_REFERRER)
    await update_balance(user_id, REFERRAL_JOIN_REFERRED)
    await add_life_journal(
        user_id, "parrainage",
        f"🤝 Tu as rejoint le jeu via {escape_html(referrer_name)} : {fmt(REFERRAL_JOIN_REFERRED)} + {REFERRAL_JOIN_COINS} SocialCoins.",
        severity="success"
    )
    await add_life_journal(
        referrer_id, "parrainage",
        f"👥 Un nouveau filleul a rejoint le jeu : {fmt(REFERRAL_JOIN_REFERRER)} + {REFERRAL_JOIN_COINS} SocialCoins.",
        severity="success"
    )
    await _notify_user(
        context.bot,
        referrer_id,
        f"🎉 <b>Nouveau filleul !</b>\n"
        f"Un joueur vient de rejoindre grâce à ton lien.\n"
        f"💰 Récompense immédiate : <b>{fmt(REFERRAL_JOIN_REFERRER)}</b>\n"
        f"💎 Bonus : <b>{REFERRAL_JOIN_COINS}</b> SocialCoins"
    )
    return (
        f"🤝 <b>Parrainage activé</b>\n"
        f"Parrain : <b>{escape_html(referrer_name)}</b>\n"
        f"🎁 Bonus de départ : <b>{fmt(REFERRAL_JOIN_REFERRED)}</b>\n"
        f"💎 Bonus : <b>{REFERRAL_JOIN_COINS}</b> SocialCoins\n"
        f"🚀 Une autre récompense se débloquera quand tu auras vraiment lancé ta partie."
    )


# ═══════════════════════════════════════════════════════════════════
#                              /start
# ═══════════════════════════════════════════════════════════════════
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id, user.username or "", user.full_name or "")

    if u.get("registered"):
        # Joueur de retour
        sim = await apply_passive_simulation(user.id)
        await process_referral_progress(user.id, context.bot)
        u = await get_user(user.id, user.username or "", user.full_name or "")
        score = lifestyle_score(u)
        lvl, xp_in, xp_for = xp_progress(u.get("xp", 0))
        age = u.get("age", 20)
        age_label, age_icon = age_stage(age)
        season = current_season()
        s_fx = SEASON_EFFECTS[season]
        await update_mission_progress(user.id, "login", 1)

        if sim.get("alert"):
            await update.message.reply_text(sim["alert"], parse_mode="HTML")

        body = [
            f"{age_icon} <b>{age} ans</b> · {age_label}",
            f"{s_fx['icon']} Saison : <b>{season.capitalize()}</b>",
            "",
            f"🧬 État global : <b>{life_state_label(score)}</b>  ({score}/100)",
            "",
            stat_card("Santé",   u.get("health", 100),   emoji="❤️"),
            stat_card("Énergie", u.get("energy", 100),   emoji="⚡"),
            stat_card("Faim",    u.get("hunger", 100),   emoji="🍽️"),
            stat_card("Bonheur", u.get("happiness", 100), emoji="😊"),
            stat_card("Stress",  u.get("stress", 0),     emoji="😰", inverted=True),
            "",
            f"💰 Solde : <b>{fmt(u['balance'])}</b>   ·   {wealth_class(u['balance'])}",
            f"⭐ Niveau <b>{lvl}</b>  ·  XP : {xp_in}/{xp_for}",
            f"🌟 Karma : <b>{karma_label(u.get('karma', 0))}</b>",
            f"💼 {escape_html(u.get('job') or 'Sans emploi')}  ·  🎓 {escape_html(u.get('diplome') or 'Aucun diplôme')}",
        ]

        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🎮 Menu principal", callback_data="menu_main"),
             InlineKeyboardButton("🧬 Vie", callback_data="menu_life")],
            [InlineKeyboardButton("💼 Économie", callback_data="menu_economy"),
             InlineKeyboardButton("🎓 Carrière", callback_data="menu_career")],
            [InlineKeyboardButton("👥 Multijoueur", callback_data="menu_mp"),
             InlineKeyboardButton("🏛️ Société", callback_data="menu_society")],
            [InlineKeyboardButton("🏢 Entreprises", callback_data="menu_companies"),
             InlineKeyboardButton("🎲 Loisirs", callback_data="menu_fun")],
            [InlineKeyboardButton("📜 Profil", callback_data="menu_profile"),
             InlineKeyboardButton("❓ Aide", callback_data="menu_help")],
            [InlineKeyboardButton("👥 Groupe de jeu", url="https://t.me/MYLIFEYOURLIFESIM"),
             InlineKeyboardButton("📢 Mises à jour", url="https://t.me/GameFrench")],
            [InlineKeyboardButton("🛠️ Support", url="https://t.me/GameFrenchSupport"),
             InlineKeyboardButton("👨‍💻 Développeur", callback_data="dev_info"),
             InlineKeyboardButton("👑 Créateur", callback_data="creator_info")],
            [InlineKeyboardButton("🤖 Bot officiel", url="https://t.me/MYLIFEYOURLIFESIM_bot")],
        ])

        texte = card(
            f"Bon retour, {escape_html(user.full_name)}",
            body,
            footer=random_quote(),
            icon="🌟",
            style="thick",
        )

        try:
            with open(START_PHOTO_PATH, 'rb') as photo_file:
                # Envoyer la photo avec une légende courte
                await update.message.reply_photo(
                    photo=InputFile(photo_file),
                    caption=f"Bon retour, {escape_html(user.full_name)} 👋",
                    parse_mode="HTML",
                    reply_markup=kb
                )
                # Envoyer le message complet séparément
                await update.message.reply_text(texte, parse_mode="HTML")
        except FileNotFoundError:
            await update.message.reply_text(texte, parse_mode="HTML", reply_markup=kb)

        await update_field(user.id, "last_seen", now())
        return

    # ─── PREMIÈRE FOIS ──────────────────────────────────────────
    defaults = {
        "registered": 1,
        "created_at": now(),
        "last_seen": now(),
        "last_life_tick": now(),
        "balance": 10_000,
        "health": 100, "energy": 100, "happiness": 100, "hunger": 100,
        "stress": 0, "karma": 0, "age": 18,
        "job": "Livreur", "diplome": "",
        "level": 1, "xp": 0,
    }
    for field, value in defaults.items():
        await update_field(user.id, field, value)

    referral_text = await _handle_referral_start(update, context, user.id)

    await add_life_journal(
        user.id, "naissance",
        f"🎂 Naissance d'un nouveau destin : {escape_html(user.full_name)}, 18 ans, 10 000$ en poche, Livreur.",
        severity="success",
    )

    intro_body = [
        f"🎂 Tu nais à <b>18 ans</b> dans une grande métropole.",
        "💼 Premier job : <b>Livreur</b>.",
        "💰 Capital de départ : <b>10 000$</b>.",
        "",
        "<b>🌍 Ce qui t'attend dans cette version</b>",
        "  ▸ Marché joueur d'items : acheter, vendre et utiliser des objets",
        "  ▸ Entreprises plus complètes avec audit, produits à effets, fusions avec accord, contrats négociables",
        "  ▸ Casino interactif (boutons SPIN, LANCER, grille cliquable) – ouvert la nuit (17h→5h)",
        "  ▸ Escouades coopératives et raids contre boss",
        "  ▸ Réseaux sociaux, communautés, tendances et SocialCoins",
        "  ▸ Parrainage avec lien personnel et récompenses progressives",
        "  ▸ 📱 Téléphone intégré avec calendrier, assistant, banque, inventaire, marché, messagerie et plus !",
        "",
        "<b>🚀 Pour commencer</b>",
        "  • <code>/menu</code> ─ voir les grands systèmes du jeu",
        "  • <code>/nouveautes</code> ─ lire les changements récents",
        "  • <code>/guide</code> ─ comprendre les règles importantes",
        "  • <code>/travailler</code> ─ gagner ton premier salaire",
        "  • <code>/vie</code> ─ voir ton état complet",
        "  • <code>/parrainage</code> ─ inviter tes amis et gagner des bonus",
        "  • <code>/phone</code> ─ ton hub central dans le jeu",
    ]
    if referral_text:
        intro_body.extend(["", referral_text])

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🚀 Lancer mon aventure", callback_data="menu_main")],
        [InlineKeyboardButton("🆕 Voir les nouveautés", callback_data="menu_help")],
        [InlineKeyboardButton("👥 Groupe de jeu", url="https://t.me/MYLIFEYOURLIFESIM"),
         InlineKeyboardButton("📢 Mises à jour", url="https://t.me/GameFrench")],
        [InlineKeyboardButton("🛠️ Support", url="https://t.me/GameFrenchSupport"),
         InlineKeyboardButton("👨‍💻 Développeur", callback_data="dev_info"),
         InlineKeyboardButton("👑 Créateur", callback_data="creator_info")],
    ])

    texte = card(
        f"Bienvenue dans LifeSim Ultra, {escape_html(user.full_name)}",
        intro_body,
        footer="Chaque choix forge ton destin. Tape /menu pour entrer dans le jeu.",
        icon="🌟",
        style="thick",
    )

    try:
        with open(START_PHOTO_PATH, 'rb') as photo_file:
            # Envoyer la photo avec une légende courte
            await update.message.reply_photo(
                photo=InputFile(photo_file),
                caption=f"Bienvenue, {escape_html(user.full_name)} 🚀",
                parse_mode="HTML",
                reply_markup=kb
            )
            # Envoyer le message complet séparément
            await update.message.reply_text(texte, parse_mode="HTML")
    except FileNotFoundError:
        await update.message.reply_text(texte, parse_mode="HTML", reply_markup=kb)

    await update_field(user.id, "last_seen", now())
    return

    # ─── PREMIÈRE FOIS ──────────────────────────────────────────
    defaults = {
        "registered": 1,
        "created_at": now(),
        "last_seen": now(),
        "last_life_tick": now(),
        "balance": 10_000,
        "health": 100, "energy": 100, "happiness": 100, "hunger": 100,
        "stress": 0, "karma": 0, "age": 18,
        "job": "Livreur", "diplome": "",
        "level": 1, "xp": 0,
    }
    for field, value in defaults.items():
        await update_field(user.id, field, value)

    referral_text = await _handle_referral_start(update, context, user.id)

    await add_life_journal(
        user.id, "naissance",
        f"🎂 Naissance d'un nouveau destin : {escape_html(user.full_name)}, 18 ans, 10 000$ en poche, Livreur.",
        severity="success",
    )

    intro_body = [
        f"🎂 Tu nais à <b>18 ans</b> dans une grande métropole.",
        "💼 Premier job : <b>Livreur</b>.",
        "💰 Capital de départ : <b>10 000$</b>.",
        "",
        "<b>🌍 Ce qui t'attend dans cette version</b>",
        "  ▸ Marché joueur d'items : acheter, vendre et utiliser des objets",
        "  ▸ Entreprises plus complètes avec audit, produits à effets, fusions avec accord, contrats négociables",
        "  ▸ Casino interactif (boutons SPIN, LANCER, grille cliquable) – ouvert la nuit (17h→5h)",
        "  ▸ Escouades coopératives et raids contre boss",
        "  ▸ Réseaux sociaux, communautés, tendances et SocialCoins",
        "  ▸ Parrainage avec lien personnel et récompenses progressives",
        "  ▸ 📱 Téléphone intégré avec calendrier, assistant, banque, inventaire, marché, messagerie et plus !",
        "",
        "<b>🚀 Pour commencer</b>",
        "  • <code>/menu</code> ─ voir les grands systèmes du jeu",
        "  • <code>/nouveautes</code> ─ lire les changements récents",
        "  • <code>/guide</code> ─ comprendre les règles importantes",
        "  • <code>/travailler</code> ─ gagner ton premier salaire",
        "  • <code>/vie</code> ─ voir ton état complet",
        "  • <code>/parrainage</code> ─ inviter tes amis et gagner des bonus",
        "  • <code>/phone</code> ─ ton hub central dans le jeu",
    ]
    if referral_text:
        intro_body.extend(["", referral_text])

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🚀 Lancer mon aventure", callback_data="menu_main")],
        [InlineKeyboardButton("🆕 Voir les nouveautés", callback_data="menu_help")],
        [InlineKeyboardButton("👥 Groupe de jeu", url="https://t.me/MYLIFEYOURLIFESIM"),
         InlineKeyboardButton("📢 Mises à jour", url="https://t.me/GameFrench")],
        [InlineKeyboardButton("🛠️ Support", url="https://t.me/GameFrenchSupport"),
         InlineKeyboardButton("👨‍💻 Développeur", callback_data="dev_info"),
         InlineKeyboardButton("👑 Créateur", callback_data="creator_info")],
    ])

    texte = card(
        f"Bienvenue dans LifeSim Ultra, {escape_html(user.full_name)}",
        intro_body,
        footer="Chaque choix forge ton destin. Tape /menu pour entrer dans le jeu.",
        icon="🌟",
        style="thick",
    )

    try:
        with open(START_PHOTO_PATH, 'rb') as photo_file:
            await update.message.reply_photo(
                photo=InputFile(photo_file),
                caption=texte,
                parse_mode="HTML",
                reply_markup=kb
            )
    except FileNotFoundError:
        await update.message.reply_text(texte, parse_mode="HTML", reply_markup=kb)

    await update_field(user.id, "last_seen", now())
    return


@require_registered
async def cmd_parrainage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    deep_link = f"{BOT_PUBLIC_LINK}?start=ref_{user.id}"
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN activated_at > 0 THEN 1 ELSE 0 END) AS activated
            FROM referrals
            WHERE referrer_id=?
        """, (user.id,)) as cur:
            stats = await cur.fetchone()
        async with db.execute("""
            SELECT u.full_name, u.level, r.created_at, r.activated_at
            FROM referrals r
            JOIN users u ON u.user_id = r.referred_id
            WHERE r.referrer_id=?
            ORDER BY r.created_at DESC
            LIMIT 8
        """, (user.id,)) as cur:
            rows = await cur.fetchall()

    u = await get_user(user.id)
    total = stats["total"] or 0
    activated = stats["activated"] or 0
    pending = total - activated

    body = [
        "Invite tes amis avec ce lien personnel :",
        f"<code>{escape_html(deep_link)}</code>",
        "",
        f"👥 Filleuls inscrits : <b>{total}</b>",
        f"✅ Activés : <b>{activated}</b>",
        f"⏳ En attente : <b>{pending}</b>",
        f"💰 Récompenses gagnées : <b>{fmt(u.get('referral_rewards', 0))}</b>",
        "",
        "<b>Récompenses</b>",
        f"• Arrivée d'un filleul : <b>{fmt(REFERRAL_JOIN_REFERRER)}</b> + {REFERRAL_JOIN_COINS} SocialCoins",
        f"• Activation d'un filleul : <b>{fmt(REFERRAL_ACTIVATION_REFERRER)}</b> + {REFERRAL_ACTIVATION_COINS} SocialCoins",
        "",
        "Un filleul est activé quand il atteint le niveau 3 et a gagné au moins 25 000$ au total.",
    ]
    if rows:
        body.extend(["", "<b>Derniers filleuls</b>"])
        for row in rows:
            status = "✅ activé" if row["activated_at"] else "⏳ en cours"
            body.append(f"• <b>{escape_html(row['full_name'])}</b> · niv.{row['level']} · {status}")

    await update.message.reply_text(
        card("🤝 PARRAINAGE", body, icon="🤝", style="thick",
             footer="Partage le lien /start pour faire grandir la communauté."),
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════
#                              /menu
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    event = await get_active_event()
    ev_line = f"⚡ Événement actif : <b>{escape_html(event['name'])}</b>" if event else "🌍 Monde stable"

    body = [
        ev_line,
        "",
        f"💰 Solde : <b>{fmt(u.get('balance', 0))}</b>",
        f"⭐ Niveau : <b>{u.get('level', 1)}</b>   ·   ❤️ Santé : <b>{u.get('health', 100)}%</b>",
        "",
        "<b>🎮 Raccourcis utiles</b>",
        "  /vie ─ état complet de ton personnage",
        "  /phone ─ téléphone (hub central)",
        "  /travailler ─ gagner de l'argent",
        "  /etudes ─ progresser et débloquer de meilleurs jobs",
        "  /market ─ marché joueur d'items",
        "  /crafting ─ fabriquer des objets",
        "  /monentreprise ─ gérer ta boîte",
        "  /escouade ─ coop et raids",
        "  /competition ─ défi hebdomadaire",
        "  /ranked ─ saison compétitive",
        "  /tutorial ─ parcours guidé",
        "  /graphstats ─ évolution richesse / XP",
        "",
        "<b>🆕 Changements récents</b>",
        "  • 📱 Téléphone intégré avec calendrier, assistant, banque, inventaire, marché, messagerie et plus !",
        "  • Casino interactif (boutons SPIN, LANCER, grille cliquable) – ouvert la nuit",
        "  • Entreprises : produits à effets, fusions avec accord, contrats négociables",
        "  • Escouades, raids et coopération renforcée",
        "  • Réseaux sociaux, tendances et SocialCoins",
        "  • Parrainage avec récompenses progressives",
        "",
        "<b>📚 Pour t'orienter</b>",
        "  /aide ─ liste complète des commandes",
        "  /guide ─ explications détaillées",
        "  /nouveautes ─ résumé des ajouts et changements",
        "  Utilise aussi les boutons ci-dessous pour naviguer par thème.",
    ]
    
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🧬 Vie", callback_data="menu_life"),
         InlineKeyboardButton("💼 Économie", callback_data="menu_economy")],
        [InlineKeyboardButton("🎲 Loisirs", callback_data="menu_fun"),
         InlineKeyboardButton("🎓 Carrière", callback_data="menu_career")],
        [InlineKeyboardButton("👥 Multijoueur", callback_data="menu_mp"),
         InlineKeyboardButton("🏛️ Société", callback_data="menu_society")],
        [InlineKeyboardButton("🏢 Entreprises", callback_data="menu_companies"),
         InlineKeyboardButton("📜 Profil", callback_data="menu_profile")],
        [InlineKeyboardButton("❓ Aide", callback_data="menu_help")],
    ])
    
    await update.message.reply_text(
        card("MENU PRINCIPAL", body, icon="🎮", style="double",
             footer="Menu raccourci pour éviter les messages trop longs. /aide contient la liste complète."),
        parse_mode="HTML",
        reply_markup=kb,
    )


# ═══════════════════════════════════════════════════════════════════
#                              /aide
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_aide(update: Update, context: ContextTypes.DEFAULT_TYPE):
    body = [
        "<b>📱 TÉLÉPHONE (hub central)</b>",
        "  /phone — écran d'accueil avec heure, date, météo",
        "  • 📅 Calendrier : événements du mois et personnel (/phone_event)",
        "  • 📨 Messages : notifications reçues",
        "  • 📨 /phone_msg @utilisateur [message] — envoyer un message privé",
        "  • 💡 Assistant : conseils personnalisés selon ton état",
        "  • 🏦 Banque : consulter comptes et prêts",
        "  • 📦 Inventaire : voir et utiliser tes items",
        "  • 🏪 Marché : annonces récentes",
        "  • 👤 Profil : toutes tes stats",
        "  • ⚙️ Paramètres : thème (clair/sombre) et sonnerie",
        "  • /phone_event \"titre\" [date] — ajouter un événement perso",
        "",
        "<b>🧬 SURVIE & SANTÉ</b>",
        "  /vie · /manger · /dormir · /sante · /gym · /medecin · /hopital",
        "  /medicaments · /assurance · /journal · /routine · /choix",
        "",
        "<b>💰 ÉCONOMIE & FINANCES</b>",
        "  /quotidien · /travailler · /metier · /promotion · /compte",
        "  /payer · /don · /impots · /banques · /ouvrir · /depot",
        "  /retrait · /pret · /rembourser · /mescomptes · /richesse",
        "  /loterie · /acheterticket · /mestickets · /tirage",
        "",
        "<b>📈 INVESTISSEMENTS & PATRIMOINE</b>",
        "  /marche · /acheteraction · /vendreaction · /portefeuille",
        "  /historique · /proprietes · /acheter · /hypotheque · /mesbiens",
        "  /vendre · /entretenir · /vehicules · /acheterv · /mesvehicules",
        "  /reparer · /assurerv · /vendrevehicule · /luxe · /acheterLuxe",
        "",
        "<b>🏪 MARCHÉ JOUEUR & ITEMS</b>",
        "  /market — voir les annonces des joueurs",
        "  /sellitem [item_id] [prix] [quantité] — mettre un item en vente",
        "  /buyitem [listing_id] [quantité] — acheter un item",
        "  /cancelitem [listing_id] — annuler une vente",
        "  /useitem [item_id] [quantité] — utiliser un item consommable (effets heal/energy/xp/money)",
        "  /myitems — voir tes propres annonces",
        "  /crafting — voir les recettes",
        "  /craft [recette] [quantité] — fabriquer un objet",
        "",
        "<b>🔒 LOCATION</b>",
        "  /proposer_location · /meslocations · /quitter_logement",
        "",
        "<b>🏢 ENTREPRISES</b>",
        "  Gestion : /boites · /creerboite · /monentreprise · /dissoudreboite",
        "  /depotboite · /retirerboite · /renommer_entreprise · /changer_secteur",
        "  Recrutement : /postuler · /candidatures · /accepter · /refuser",
        "  /negocier · /repondre_offre",
        "  Employés : /employes · /nommer · /setsalaire · /licencier · /former · /prime",
        "  Finances : /parts · /acheterparts · /vendreparts · /dividendes",
        "  R&D / frais : /rd · /setoverhead · /auditboite",
        "  Produits (à effets : heal/energy/xp/money/buff) : /produits · /creer_produit [nom] [effet] [valeur] [quantité]",
        "  /supprimer_produit · /retirer_produit · /renommer_produit · /desc_produit · /emoji_produit",
        "  /donner_produit (en répondant) · /setprix",
        "  Relations B2B : /annonce · /emplois · /inviter · /repondre_invitation",
        "  /proposer_contrat · /repondre_contrat · /negocier_contrat",
        "  Fusions (avec accord) : /proposer_fusion · /repondre_fusion",
        "  /transfert_entreprise · /fusion (ancienne, sans accord)",
        "",
        "<b>👥 SOCIAL & MULTIJOUEUR</b>",
        "  /mariage · /acceptermariage · /divorce · /famille · /creerfamille",
        "  /adopter · /ami · /mesamis · /inviterfamille · /rejoindrefamille",
        "  /quitterfamille · /transfertclan · /dissoudrefamille",
        "  /guild · /guild_create · /guild_invite · /guild_join",
        "  /guild_leave · /guild_members · /guild_desc · /guild_promote",
        "  /guild_transfer · /guild_dissolve · /guild_donate",
        "  /guild_quest · /guild_rank",
        "  /gang · /creergand · /rejoindregang · /quittergang",
        "  /ganginfo · /gangactions · /gangcaisse · /transfertchef",
        "  /ganghold · /gangupgrade · /gangclassement · /dissoudregang",
        "  /creerescouade · /escouade · /inviterescouade · /quitterescouade",
        "  /chatescouade · /raid",
        "  /echange · /cadeau · /salutations · /relations · /classements",
        "  /payer · /don",
        "",
        "<b>🌐 RÉSEAUX SOCIAUX (liberté totale !)</b>",
        "  📱  /plateformes — liste des réseaux",
        "  📤  /poster [plateforme] [message libre] — publier (réponse factuelle)",
        "  📸  /story [plateforme] [message] — story éphémère",
        "  🎥  /live [plateforme] [durée_h] — live interactif",
        "  💰  /vendre_followers @utilisateur [quantité] [prix] — vente (avec accord)",
        "  🤝  /collab @utilisateur [--type live|giveaway|cross] [--duree h] — demande de collab",
        "  ⭐  /noter @utilisateur +1|-1 — réputation sociale",
        "  🏆  /classement_social — top influenceurs",
        "  👥  /creer_communaute [nom] — créer un groupe social",
        "  📨  /inviter_communaute [id] @user — inviter dans une communauté",
        "  🏷️  /lancer_tendance #hashtag [mise] — créer une tendance mondiale",
        "  🏷️  /utiliser_tendance #hashtag — booster son prochain post",
        "  💎  /socialcoins — voir son solde de SocialCoins",
        "  🎁  /donner_socialcoins @user [montant] — donner des SocialCoins",
        "  📊  /analytiques [plateforme] [--periode N] — stats d'évolution",
        "  🔄  /partager (en répondant à un message) — partager le post d'un autre",
        "  ⁉️ /sondage \"Question\" \"Option1\" \"Option2\" ... — créer un sondage",
        "  📊  /resultats_sondage [id] — voir les résultats (créateur uniquement)",
        "",
        "<b>🏛️ POLITIQUE (sans simulation)</b>",
        "  📜 /constitution — consulter la constitution",
        "  ✍️ /modifierconstitution [texte] — proposer une modification (référendum)",
        "  🏛️ /postes — voir les élus en fonction",
        "  🗳️ /lancerelection [poste] [durée_h] — lancer une élection",
        "  📢 /candidater [poste] [programme] — se présenter à l'élection en cours",
        "  ✅ /voter @candidat — voter",
        "  👥 /candidats [poste] — voir les candidats et ces programmes en temps réel",
        "  📊 /elections — liste des élections en cours",
        "  📊 /depouiller — clôturer l’élection et compter les voix",
        "  👔 /monposte — voir son mandat",
        "  🚪 /demissionnerposte confirmer — démissionner",
        "  ⚖️ /destituer @elu — lancer une motion de destitution",
        "  ✍️ /signer @elu — signer une motion",
        "  🗳️ /vote_destitution pour/contre — voter lors d'une destitution",
        "  🏛️ /creerparti [nom] [idéologie] — créer un parti politique",
        "  📋 /partis — lister les partis",
        "  🤝 /rejoindreparti [nom] — rejoindre un parti",
        "  🚪 /quitterparti — quitter son parti",
        "  👑 /transfertchefparti @user — transférer le leadership",
        "  📜 /proposerloi [titre] | [description] [effet] — proposer une loi",
        "  🗳️ /voterloi [titre] pour/contre — voter une loi",
        "  📢 /referendum [question] — lancer un référendum",
        "  🗳️ /votereferendum pour/contre — voter un référendum",
        "  👥 /nommer @user [poste] — nommer un ministre (pour l’élu)",
        "  📋 /ministres — liste du gouvernement",
        "",
        "<b>🎲 LOISIRS & JEUX (interactifs)</b>",
        "  🎰 /slots — appuie sur SPIN",
        "  🃏 /blackjack — boutons Tirer/Rester/Doubler",
        "  🎡 /roulette — choisis ton pari puis LANCER",
        "  💥 /crash — bouton ENCAISSER avant le crash",
        "  ♠️ /poker — vidéo poker (comparatif automatique)",
        "  💣 /mines — grille 5x5 cliquable",
        "  🐎 /pmu — choisis ton cheval puis LANCER LA COURSE",
        "  🌱 /jardin · /planter · /arroser · /recolter · /vendrecolte",
        "  🕒 Le casino est ouvert de 17h à 5h (heure du jeu).",
        "",
        "<b>🥊 PVP & ARÈNE</b>",
        "  /defier · /defis · /classementarene · /parier",
        "",
        "<b>⚔️ CRIME & BLACK MARKET</b>",
        "  /crimes · /commettre · /caution · /tribunal · /avocat",
        "  /noir · /acheternoir · /hacktargets · /hacker · /defenses",
        "",
        "<b>🎯 PROGRESSION & MISSIONS</b>",
        "  /missions · /missions_completed · /achievements · /prestige",
        "  /classementprestige · /prestigelog · /legacy · /reincarnate",
        "  /evenements · /eventinfo · /competition · /competition_join",
        "  /competition_history · /ranked · /ranked_join · /ranked_leaderboard",
        "  /ranked_history · /tutorial · /graphstats",
        "",
        "<b>📜 PROFIL & COMMUNAUTÉ</b>",
        "  /profil · /stats · /badges · /bio · /lieu · /inventaire",
        "  /titres · /historiquetitres · /karma · /niveau",
        "  /leaderboard · /topxp · /richesse",
        "",
        "<b>📩 NOTIFICATIONS & SIGNALEMENTS</b>",
        "  /notifications · /notifications_history · /notifications_clear",
        "  /report · /report_user · /myreports",
        "",
        "<b>✈️ VOYAGES</b>",
        "  /destinations · /voyager · /monstimbre",
        "",
        "<b>🛒 BOUTIQUE UNIFIÉE</b>",
        "  /shop — accès rapide aux articles de luxe et marché noir",
    ]

    footer = "Plus de 200 commandes disponibles. Tape /guide pour le tutoriel détaillé."

    # Découpage par groupes de 22 lignes (pour rester sous 4096 caractères)
    chunk_size = 22
    for i in range(0, len(body), chunk_size):
        chunk = body[i:i+chunk_size]
        # Afficher le footer seulement sur le dernier message
        current_footer = footer if i + chunk_size >= len(body) else None
        text = card("📖 GUIDE DES COMMANDES", chunk, icon="📖", style="thick", footer=current_footer)
        await update.message.reply_text(text, parse_mode="HTML") 

# ═══════════════════════════════════════════════════════════════════
#                              /guide
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_guide(update: Update, context: ContextTypes.DEFAULT_TYPE):
    body = [
        "<b>📖 LES BASES</b>",
        "Dans LifeSim, ton personnage vit en temps réel.",
        "Pendant ton absence, le monde évolue : faim ↘, énergie ↗,",
        "événements aléatoires, vieillissement, saisons…",
        "",
        "<b>🎯 LES 5 PILIERS</b>",
        "  ❤️ <b>Santé</b> ─ à 0%, tu meurs et perds ton legacy",
        "  ⚡ <b>Énergie</b> ─ nécessaire pour bosser, étudier, agir",
        "  🍽️ <b>Faim</b> ─ /manger pour la restaurer",
        "  😊 <b>Bonheur</b> ─ booste les chances de succès",
        "  😰 <b>Stress</b> ─ inverse : plus c'est haut, plus c'est mauvais",
        "",
        "<b>💡 STRATÉGIE TYPE</b>",
        "  1. /quotidien chaque jour pour les revenus passifs",
        "  2. /travailler toutes les 4h pour ton salaire",
        "  3. /etudier pour grimper en diplôme = meilleurs jobs",
        "  4. /acheter une propriété ─ revenus locatifs",
        "  5. /marche ─ investis tes économies à long terme",
        "  6. /missions chaque jour pour XP & bonus",
        "",
        "<b>📱 TÉLÉPHONE (hub central)</b>",
        "  • /phone ouvre un menu complet avec accès à toutes les infos essentielles.",
        "  • Calendrier : visualise les événements mondiaux et ajoute les tiens.",
        "  • Assistant : reçois des conseils personnalisés pour améliorer ta santé, ton argent, etc.",
        "  • Messagerie : consulte toutes tes notifications et envoie des messages à d'autres joueurs avec /phone_msg.",
        "  • Banque, inventaire, marché, profil : tout est accessible depuis le téléphone.",
        "  • Personnalise ton téléphone (thème, sonnerie) dans Paramètres.",
        "",
        "<b>🏪 MARCHÉ JOUEUR & ITEMS</b>",
        "  • Gagne des items dans les casinos, arènes, crimes, missions.",
        "  • Vends-les à d’autres joueurs avec /sellitem et consulte les annonces avec /market.",
        "  • Achète ce qui t’intéresse avec /buyitem.",
        "  • Utilise les items consommables avec /useitem (santé, énergie, XP, argent).",
        "",
        "<b>🏠 SYSTÈME DE LOCATION SÉCURISÉ</b>",
        "  • /proposer_location [numéro] @locataire [loyer]",
        "    Le propriétaire envoie une proposition de bail.",
        "    Le locataire reçoit une notification avec Accepter/Refuser.",
        "  • /meslocations — voir les biens que tu loues",
        "  • /quitter_logement [id_contrat] — résilier un bail",
        "  • Les loyers sont prélevés automatiquement chaque mois.",
        "  • Si le locataire n'a pas assez d'argent, il est expulsé.",
        "",
        "<b>🤝 MULTIJOUEUR</b>",
        "  • /mariage, /famille, /gang, /guild",
        "  • /defier un autre joueur en duel",
        "  • /payer, /don, /cadeau, /echange, /salutations",
        "  • /creerescouade, /escouade, /inviterescouade, /chatescouade",
        "  • /raid lancer [mise] puis /raid attaquer pour jouer en coop",
        "",
        "<b>🏢 ENTREPRISES RENFORCÉES</b>",
        "  • /auditboite te donne une lecture claire des points forts, risques et priorités de ta société.",
        "  • Les produits ont des EFFETS RÉELS (soin, énergie, XP, argent, buff).",
        "  • Le coût d'un produit dépend de son effet et de sa puissance (formule dynamique).",
        "  • Les produits ne se vendent plus automatiquement : utilise /market pour les vendre.",
        "  • Les fusions se font avec accord : /proposer_fusion pour demander, /repondre_fusion pour accepter/refuser.",
        "  • Les contrats B2B peuvent être négociés (/negocier_contrat) avant acceptation.",
        "  • Les produits, la trésorerie, l'équipe et la R&D comptent davantage dans la progression.",
        "",
        "<b>🎰 CASINO INTERACTIF (comme 1xBet)</b>",
        "  • Tu ne lances plus une commande et tu attends un résultat.",
        "  • Tu joues VRAIMENT avec des boutons :",
        "    - /slots → bouton SPIN",
        "    - /roulette → choix du pari puis bouton LANCER",
        "    - /mines → grille 5x5, tu cliques sur les cases",
        "    - /pmu → choix du cheval puis LANCER LA COURSE",
        "    - /blackjack → boutons Tirer/Rester/Doubler",
        "    - /crash → bouton ENCAISSER avant le crash",
        "  • Le casino est ouvert uniquement la nuit (17h → 5h heure du jeu).",
        "",
        "<b>🌐 RÉSEAUX SOCIAUX (liberté totale !)</b>",
        "  • Tu écris TOUT le contenu : le bot ne raconte rien à ta place.",
        "  • Les réponses sont factuelles : gains d'abonnés, revenus, XP.",
        "  • <b>/poster</b> ─ publie ce que tu veux (texte libre).",
        "  • <b>/story</b> ─ contenu éphémère (boost temporaire).",
        "  • <b>/live</b> ─ streaming, les autres peuvent te faire des dons.",
        "  • <b>/collab</b> ─ demande de collaboration (nécessite acceptation).",
        "  • <b>/vendre_followers</b> ─ vends tes abonnés à d’autres joueurs (avec accord).",
        "  • <b>/noter</b> ─ donne une réputation (+1 ou -1) à un joueur.",
        "  • <b>/classement_social</b> ─ top des influenceurs.",
        "  • <b>/creer_communaute</b> ─ crée un groupe social (coût 1000 SocialCoins).",
        "  • <b>/lancer_tendance</b> ─ crée un hashtag tendance (mise obligatoire).",
        "  • <b>/utiliser_tendance</b> ─ booste ton prochain post avec cette tendance.",
        "  • <b>/socialcoins</b> ─ monnaie sociale indépendante (gagnée en postant, donnée entre joueurs).",
        "  • <b>/analytiques</b> ─ statistiques d’évolution (brutes, sans avis).",
        "  • <b>/partager</b> ─ partage le post d’un autre joueur (gain mutuel).",
        "  • **Sondages** : `/sondage \"Question\" \"Option1\" \"Option2\"` — crée un sondage. Les autres votent avec `/vote [id] [option]`.",
        "  • **Résultats** : `/resultats_sondage [id]` — consulte les résultats (réservé au créateur).",
        "",
        "<b>🤝 PARRAINAGE</b>",
        "  • /parrainage te donne un lien personnel à partager.",
        "  • Tu gagnes une récompense immédiate quand un filleul rejoint via ton lien.",
        "  • Une seconde récompense arrive quand ce filleul atteint un vrai palier de progression.",
        "",
        "<b>🏛️ POLITIQUE (sans simulation, tout est joueur)</b>",
        "  • /constitution — cadre fondamental (modifiable par référendum)",
        "  • /lancerelection — créer une élection pour un poste (coût, karma requis)",
        "  • /candidater — se porter candidat (avec programme libre)",
        "  • /voter @candidat — voter directement (un seul vote par élection)",
        "  • /candidats [poste] — voir les candidats et leurs programmes actuels",
        "  • /elections — liste des élections en cours",
        "  • /depouiller — ferme l’élection, vérifie le quorum, déclare le vainqueur",
        "  • /destituer /signer /vote_destitution — motion de censure : signatures puis vote",
        "  • /creerparti /partis /rejoindreparti /quitterparti — vie partisane",
        "  • /proposerloi /voterloi — système législatif (vote de tous les joueurs)",
        "  • /referendum — initiative citoyenne directe",
        "  • /nommer /ministres — gouvernement (si l’élu le souhaite)",
        "  • Les coûts, quorums, majorités, délais sont paramétrables par les admins à tout moment",
        "",
        "<b>🏢 ENTREPRISES</b>",
        "  • /creerboite ─ deviens PDG (coût 100M)",
        "  • /postuler ─ rejoindre une entreprise",
        "  • /setsalaire /nommer ─ fixer les salaires",
        "  • /rd ─ investir en R&D",
        "  • /produits ─ créer et vendre des produits",
        "  • /fusion ─ racheter une autre entreprise",
        "  • /inviter ─ envoyer une invitation directe",
        "",
        "<b>⚖️ KARMA</b>",
        "  Le karma influence TOUT : succès, salaires, événements.",
        "  Les bonnes actions le montent, les crimes le détruisent.",
        "",
        "<b>🌟 ASTUCES</b>",
        "  ◽ Reviens au moins 1x/jour pour ne pas accumuler de pénalité",
        "  ◽ Dormir restaure énergie, manger restaure faim",
        "  ◽ Le stress > 70% détruit ta santé en silence",
        "  ◽ Les diplômes débloquent les jobs à fort salaire",
        "  ◽ L'argent en banque génère des intérêts",
        "  ◽ Utilise /notifications pour suivre tes interactions",
        "  ◽ Le multi est clé : échanges, défis, alliances",
        "  ◽ Sur les réseaux sociaux : plus tu postes, plus tu gagnes de followers",
        "  ◽ Les collaborations et les tendances peuvent booster tes gains",
    ]

    footer = "Tape /nouveautes pour voir les dernières features."

    # Découpage par groupes de 22 lignes (identique à /aide)
    chunk_size = 22
    for i in range(0, len(body), chunk_size):
        chunk = body[i:i+chunk_size]
        current_footer = footer if i + chunk_size >= len(body) else None
        text = card("📖 GUIDE COMPLET LIFESIM ULTRA", chunk, icon="🎓", style="thick", footer=current_footer)
        await update.message.reply_text(text, parse_mode="HTML")

# ═══════════════════════════════════════════════════════════════════
#                          /nouveautes
# ═══════════════════════════════════════════════════════════════════
async def cmd_nouveautes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    body = [
        "<b>🆕 CE QUI A CHANGÉ DANS LE JEU</b>",
        "",
        "<b>📱 Téléphone (nouveau hub !)</b>",
        "  • /phone te donne un téléphone dans le jeu avec plusieurs applications.",
        "  • Consulte l'heure, la date, la météo, tes notifications en un coup d'œil.",
        "  • Assistant intelligent : te conseille sur tes faiblesses.",
        "  • Accès rapide à la banque, l'inventaire, le marché, le profil.",
        "  • Ajoute des événements personnels au calendrier avec /phone_event.",
        "  • Envoie et reçois des messages privés avec /phone_msg.",
        "  • Personnalise le thème (clair/sombre) et la sonnerie.",
        "",
        "<b>🎰 Casino interactif</b>",
        "  • Plus de simulation automatique : tu joues VRAIMENT avec des boutons !",
        "  • Slots : appuie sur SPIN pour lancer les rouleaux.",
        "  • Roulette : choisis ton pari (rouge/noir, pair/impair, numéro...) puis LANCE.",
        "  • Mines : clique sur les cases pour révéler, encaisse avant de tomber sur une mine.",
        "  • PMU : choisis ton cheval puis lance la course.",
        "  • Blackjack et Crash restent interactifs (Tirer/Rester/Doubler, ENCAISSER).",
        "  • Le casino n'est ouvert que la nuit (17h → 5h heure du jeu).",
        "",
        "<b>🏢 Entreprises</b>",
        "  • Les produits ont maintenant de VRAIS EFFETS : soin, énergie, XP, argent ou buff.",
        "  • Le coût de création dépend de l'effet et de sa puissance (plus c'est fort, plus c'est cher).",
        "  • Les produits ne se vendent plus automatiquement : vous devez les mettre en vente sur /market.",
        "  • Les fusions se font avec accord : /proposer_fusion puis /repondre_fusion (plus de fusion forcée).",
        "  • Les contrats B2B peuvent être négociés avec /negocier_contrat avant acceptation.",
        "  • /auditboite donne une lecture claire des points forts, risques et priorités de ta société.",
        "",
        "<b>🤝 Coopération</b>",
        "  • Les escouades arrivent avec <code>/creerescouade</code>, <code>/escouade</code> et <code>/inviterescouade</code>.",
        "  • Les raids permettent de jouer ensemble contre un boss avec jackpot, XP et récompenses partagées.",
        "  • Le chat d'escouade et les relations entre membres rendent la progression collective plus utile.",
        "",
        "<b>🌐 Social</b>",
        "  • Les réseaux sociaux sont plus riches : communautés, tendances, partages, collaborations et SocialCoins.",
        "  • Les posts, stories et lives peuvent mieux récompenser l'activité et l'interaction entre joueurs.",
        "  • Le système reste libre : tu écris ton contenu, le bot te renvoie surtout des résultats chiffrés.",
        "",
        "<b>🤝 Parrainage</b>",
        "  • <code>/parrainage</code> donne un lien personnel pour inviter d'autres joueurs.",
        "  • Tu gagnes une première récompense à l'arrivée du filleul puis une autre quand il progresse vraiment.",
        "  • Le suivi des filleuls et les notifications sont intégrés.",
        "",
        "<b>🏪 Économie joueur</b>",
        "  • Le marché d'items renforce les échanges entre joueurs avec <code>/market</code>, <code>/sellitem</code> et <code>/buyitem</code>.",
        "  • <code>/shop</code> sert de porte d'entrée rapide vers le luxe et le marché noir.",
        "  • Les objets gagnés dans plusieurs activités ont donc plus d'utilité qu'avant.",
        "",
        "<b>🔒 Autres changements utiles</b>",
        "  • La location est sécurisée par proposition puis acceptation du locataire.",
        "  • Le suivi multijoueur, les maintenances et plusieurs interactions sont mieux reliés entre eux.",
        "  • Si tu reviens après une pause, commence par <code>/menu</code>, <code>/guide</code> et <code>/nouveautes</code>.",
        "",
        "<b>📌 Commandes à essayer</b>",
        "  • <code>/phone</code> · <code>/phone_event</code> · <code>/phone_msg</code>",
        "  • <code>/auditboite</code> · <code>/creerescouade</code> · <code>/raid</code>",
        "  • <code>/parrainage</code> · <code>/market</code> · <code>/shop</code>",
        "  • <code>/proposer_fusion</code> · <code>/repondre_fusion</code> · <code>/negocier_contrat</code>",
        "  • <code>/creer_produit</code> · <code>/useitem</code>",
        "  • <code>/communaute</code> · <code>/classement_social</code> · <code>/guide</code>",
    ]
    await update.message.reply_text(
        card("QUOI DE NEUF ?", body,
             icon="🆕", style="thick",
             footer="Tape /aide pour la liste des commandes et /guide pour les explications détaillées."),
        parse_mode="HTML",
    )


# ═══════════════════════════════════════════════════════════════════
#                              /about
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_about(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "**🎮 YOUR LIFE MY LIFE (LifeSim)**\n\n"
        "Plonge dans une simulation de vie réaliste :\n"
        "• Gère ta santé, ton travail, tes relations\n"
        "• Construis un empire économique\n"
        "• Interagis avec d'autres joueurs\n"
        "• Deviens un influenceur sur les réseaux sociaux\n\n"
        "**Liens utiles :**\n"
        "👥 [Groupe de jeu](https://t.me/MYLIFEYOURLIFESIM)\n"
        "📢 [Mises à jour Game French](https://t.me/GameFrench)\n"
        "🛠️ [Support](https://t.me/GameFrenchSupport)\n"
        "👨‍💻 Développeur : [NETFLASH DIEU MAURICE](http://t.me/mauridieu)\n"
        "👑 Créateur : [Game French](http://t.me/Sam_Rang_Nation)\n"
        "🤖 [Bot officiel](https://t.me/MYLIFEYOURLIFESIM_bot)"
    )
    await update.message.reply_text(text, parse_mode="Markdown", disable_web_page_preview=True)


# ═══════════════════════════════════════════════════════════════════
#                          /shop (Phase 0)
# ═══════════════════════════════════════════════════════════════════
async def cmd_shop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menu unifié de la boutique : Luxe ou Marché noir."""
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("👑 Articles de luxe", callback_data="shop_luxe")],
        [InlineKeyboardButton("🕶️ Marché noir", callback_data="shop_noir")],
        [InlineKeyboardButton("❌ Fermer", callback_data="shop_close")]
    ])
    await update.message.reply_text(
        "🛒 **Boutique**\n\nChoisis ta catégorie :",
        reply_markup=keyboard,
        parse_mode="Markdown"
    )


# ═══════════════════════════════════════════════════════════════════
#                  Callback du menu boutons
# ═══════════════════════════════════════════════════════════════════
async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    raw_key = q.data.replace("menu_", "", 1)
    if raw_key == "hold":
        return
    page = 1
    if raw_key != "main":
        parts = raw_key.rsplit("_", 1)
        if len(parts) == 2 and parts[1].isdigit():
            raw_key, page = parts[0], int(parts[1])
    key = raw_key

    # --- GARDE TON DICTIONNAIRE menUS ICI (il est inchangé) ---
    menus = {
        "main": (
            "MENU PRINCIPAL",
            "🎮",
            [
                "📱 /phone — Téléphone (hub central)",
                "🧬 /vie — diagnostic complet",
                "💼 /travailler — gagner de l'argent",
                "🎓 /etudes — se former",
                "💰 /quotidien — revenus journaliers",
                "🎯 /missions — objectifs du jour",
                "📜 /profil — ton profil",
            ],
        ),
        "life": (
            "VIE & SURVIE",
            "🧬",
            [
                "❤️ /sante — état de santé",
                "🍽️ /manger — restaurer la faim",
                "🛌 /dormir — restaurer l'énergie",
                "🏋️ /gym — fitness",
                "💊 /medicaments — soigner",
                "🏥 /hopital — urgences",
                "📔 /journal — historique de vie",
                "⚡ /routine — actions quotidiennes",
                "🏃 /choix — actions rapides",
            ],
        ),
        "economy": (
            "ÉCONOMIE",
            "💰",
            [
                "💼 /travailler — gagner un salaire",
                "🏦 /banques — comptes bancaires",
                "💳 /pret — emprunter",
                "📈 /marche — investir en bourse",
                "💎 /portefeuille — tes actifs",
                "🎟️ /loterie — loterie",
                "📊 /impots — fiscalité",
                "💸 /payer — envoyer de l'argent",
                "🎁 /don — donation",
                "📊 /compte — voir ton compte",
                "🏆 /richesse — classement des riches",
                "🎰 /casino — jeux d'argent (interactifs)",
            ],
        ),
        "career": (
            "CARRIÈRE & FORMATION",
            "🎓",
            [
                "🎓 /etudes — formation",
                "📝 /examen — passer un examen",
                "📚 /reviser — réviser",
                "🏆 /promotion — grimper",
                "💼 /metier — changer de métier",
                "🧠 /competences — voir compétences",
                "🧠 /formation — apprendre compétence",
                "🏢 /boites — liste des entreprises",
                "👑 /monentreprise — gérer mon entreprise",
                "📝 /postuler — candidater",
                "📋 /candidatures — voir candidats",
                "💰 /setsalaire — fixer salaire",
                "🔬 /rd — investir en R&D",
                "📦 /produits — gérer produits",
                "🆕 /creer_produit — créer produit (effet heal/energy/xp/money/buff)",
                "🤝 /fusion — fusionner entreprises (ancienne version)",
                "📢 /annonce — publier offre emploi",
                "📢 /emplois — voir offres d'emploi",
                "💌 /inviter — inviter un joueur",
                "📄 /proposer_contrat — contrat B2B",
                "🤝 /repondre_contrat — répondre contrat",
                "📝 /negocier_contrat — négocier contrat",
                "🤝 /proposer_fusion — demander fusion (avec accord)",
                "🤝 /repondre_fusion — répondre fusion",
                "🎓 /former — former employé",
                "🎁 /prime — donner une prime",
                "⚖️ /licencier — licencier",
                "📊 /parts — actionnariat",
                "💎 /dividendes — verser dividendes",
                "📈 /acheterparts — acheter parts",
                "📉 /vendreparts — vendre parts",
                "🏦 /depotboite — déposer trésorerie",
                "💸 /versersalaires — verser salaires",
                "📋 /logsboite — logs entreprise",
                "🏆 /classement — classement entreprises",
                "💀 /dissoudreboite — dissoudre entreprise",
                "👋 /demissionner — démissionner",
            ],
        ),
        "companies": (
            "ENTREPRISES",
            "🏢",
            [
                "🏢 /boites — liste des entreprises",
                "🏭 /creerboite — créer une entreprise",
                "👑 /monentreprise — gérer ma boîte",
                "💀 /dissoudreboite — fermer l'entreprise",
                "",
                "💰 FINANCES",
                "  /depotboite — déposer dans la trésorerie",
                "  /retirerboite — retirer de la trésorerie (vers son compte)",
                "  /parts — répartition des parts",
                "  /acheterparts — acheter des parts",
                "  /vendreparts — vendre des parts",
                "  /dividendes — verser des dividendes",
                "  /rd — investir en R&D",
                "  /setoverhead — frais généraux par employé",
                "",
                "📦 PRODUITS (à effets)",
                "  /produits — voir le stock",
                "  /creer_produit — créer produit (effet heal/energy/xp/money/buff)",
                "  /supprimer_produit — supprimer un produit",
                "  /retirer_produit — perdre du stock",
                "  /renommer_produit — changer le nom",
                "  /desc_produit — changer la description",
                "  /emoji_produit — changer l'emoji",
                "  /donner_produit — offrir à un autre joueur",
                "  /setprix — fixer le prix de vente conseillé",
                "  /sellitem — vendre sur le marché (plus de vente automatique)",
                "",
                "👥 GESTION",
                "  /candidatures — voir les candidats",
                "  /accepter · /refuser · /negocier",
                "  /repondre_offre — répondre à une offre",
                "  /nommer — promouvoir un employé",
                "  /setsalaire — ajuster le salaire",
                "  /licencier — licencier (indemnités)",
                "  /former — financer une formation",
                "  /prime — donner une prime",
                "  /annonce — publier une offre d'emploi",
                "  /emplois — voir les offres",
                "  /inviter — inviter directement un joueur",
                "  /repondre_invitation — accepter/refuser",
                "",
                "🤝 B2B (avec consentement)",
                "  /proposer_contrat — contrat commercial (type, durée, montant)",
                "  /repondre_contrat — accepter/refuser un contrat",
                "  /negocier_contrat — négocier un contrat en attente",
                "  /proposer_fusion — demander une fusion (avec accord)",
                "  /repondre_fusion — accepter/refuser une fusion",
                "  /transfert_entreprise — passer le leadership",
                "  /renommer_entreprise — changer le nom",
                "  /changer_secteur — changer de secteur",
                "",
                "📋 /logsboite — historique des actions",
                "🏆 /classement — classement des entreprises",
                "👋 /demissionner — quitter son poste",
            ],
        ),
        "fun": (
            "LOISIRS & JEUX (interactifs)",
            "🎲",
            [
                "🎰 /slots — machines à sous (bouton SPIN)",
                "🃏 /blackjack — 21 (Tirer/Rester/Doubler)",
                "🎡 /roulette — roulette (pari puis LANCER)",
                "💥 /crash — crash game (ENCAISSER)",
                "♠️ /poker — poker (vidéo, comparatif)",
                "💣 /mines — démineur (grille 5x5 cliquable)",
                "🐎 /pmu — courses hippiques (choix cheval puis LANCER)",
                "🌱 /jardin — jardinage",
                "🌱 /planter — planter",
                "💧 /arroser — arroser",
                "🌾 /recolter — récolter",
                "💰 /vendrecolte — vendre récolte",
                "",
                "🕒 Le casino est ouvert de 17h à 5h (heure du jeu).",
            ],
        ),
        "society": (
            "VIE POLITIQUE & SOCIÉTÉ",
            "🏛️",
            [
                "📜 /constitution — consulter la constitution",
                "✍️ /modifierconstitution — proposer une modification",
                "",
                "<b>🗳️ ÉLECTIONS</b>",
                "  /lancerelection — lancer un scrutin",
                "  /candidater — se présenter",
                "  /voter @candidat — voter",
                "  /candidats [poste] — voir les candidats et ces programmes",
                "  /elections — liste des élections en cours",
                "  /depouiller — compter les voix",
                "  /postes — voir les élus",
                "  /monposte — son mandat",
                "  /demissionnerposte — démissionner",
                "",
                "<b>⚖️ DESTITUTION</b>",
                "  /destituer @elu — lancer une motion",
                "  /signer @elu — signer",
                "  /vote_destitution — voter pour/contre",
                "",
                "<b>🏛️ PARTIS</b>",
                "  /creerparti — créer un parti",
                "  /partis — liste",
                "  /rejoindreparti /quitterparti",
                "  /transfertchefparti",
                "",
                "<b>📜 LOIS & RÉFÉRENDUMS</b>",
                "  /proposerloi — proposer une loi",
                "  /voterloi — voter",
                "  /referendum — question directe",
                "  /votereferendum — voter",
                "",
                "<b>👥 GOUVERNEMENT</b>",
                "  /nommer — nommer un ministre",
                "  /ministres — liste",
                "",
                "<b>⚔️ CRIME & JUSTICE</b>",
                "  /crimes /commettre /caution /tribunal /avocat",
                "",
                "<b>👥 GUILDES & GANGS</b>",
                "  /guild ... /gang ...",
                "",
                "<b>💍 FAMILLE & AMIS</b>",
                "  /mariage /famille /ami /adopter",
            ],
        ),
        "mp": (
            "MULTIJOUEUR",
            "👥",
            [
                "🤝 /echange — échange sécurisé",
                "🎁 /cadeau — offrir un cadeau",
                "💸 /payer — payer un joueur",
                "💍 /mariage — se marier",
                "🥊 /defier — défier un joueur",
                "🤲 /don — donation",
                "📊 /classements — classements mondiaux",
                "💬 /salutations — saluer un joueur",
                "❤️ /relations — voir relations",
                "🤝 /ami — ajouter ami",
                "👥 /mesamis — voir amis",
                "🏆 /leaderboard — classement général",
                "⭐ /topxp — top XP",
                "💰 /richesse — top richesse",
                "📱 /phone_msg @user message — envoyer un message privé",
                "",
                "<b>🌐 RÉSEAUX SOCIAUX</b>",
                "  📤 /poster /story /live",
                "  🤝 /collab /vendre_followers",
                "  ⭐ /noter /classement_social",
                "  👥 /creer_communaute",
                "  🏷️ /lancer_tendance /utiliser_tendance",
                "  💎 /socialcoins, /donner_socialcoins, /sondage"
            ],
        ),
        "profile": (
            "MON PROFIL",
            "📜",
            [
                "📱 /phone — Téléphone (hub central)",
                "📜 /profil — vue complète",
                "📊 /stats — toutes les stats",
                "🏅 /badges — succès",
                "📦 /inventaire — objets",
                "👑 /titres — historique titres",
                "📜 /historiquetitres — hiérarchie titres",
                "✍️ /bio — modifier bio",
                "📍 /lieu — changer ville",
                "📩 /notifications — gérer notifs",
                "📜 /notifications_history — historique notifs",
                "🗑️ /notifications_clear — effacer notifs",
                "🌟 /karma — voir karma",
                "⭐ /niveau — progression niveau",
                "🔮 /legacy — héritage",
                "😇 /reincarnate — réincarnation",
                "✈️ /monstimbre — collection voyages",
            ],
        ),
        "help": (
            "AIDE",
            "❓",
            [
                "📖 /aide — toutes les commandes",
                "🎓 /guide — tutoriel détaillé",
                "🆕 /nouveautes — quoi de neuf",
                "🚨 /report — signaler un bug",
                "📩 /notifications — gérer notifs",
                "💬 /menu — retour au menu",
            ],
        ),
    }

    title, icon, lines = menus.get(key, menus["main"])

    # Construction du texte et du markup
    if key == "main":
        text = card(
            title,
            lines,
            icon=icon,
            style="double",
            footer="Choisis une catégorie ci-dessous pour ouvrir un menu paginé.",
        )
        markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🧬 Vie", callback_data="menu_life"),
             InlineKeyboardButton("💼 Économie", callback_data="menu_economy")],
            [InlineKeyboardButton("🎲 Loisirs", callback_data="menu_fun"),
             InlineKeyboardButton("🎓 Carrière", callback_data="menu_career")],
            [InlineKeyboardButton("👥 Multijoueur", callback_data="menu_mp"),
             InlineKeyboardButton("🏛️ Société", callback_data="menu_society")],
            [InlineKeyboardButton("🏢 Entreprises", callback_data="menu_companies"),
             InlineKeyboardButton("📜 Profil", callback_data="menu_profile")],
            [InlineKeyboardButton("❓ Aide", callback_data="menu_help")],
        ])
    else:
        per_page = 12
        total_pages = max(1, (len(lines) + per_page - 1) // per_page)
        page = max(1, min(page, total_pages))
        start = (page - 1) * per_page
        end = start + per_page
        page_lines = lines[start:end]
        footer = f"Page {page}/{total_pages} · ← Retour menu"
        text = card(title, page_lines, icon=icon, style="double", footer=footer)

        keyboard = []
        if total_pages > 1:
            nav = []
            if page > 1:
                nav.append(InlineKeyboardButton("◀️", callback_data=f"menu_{key}_{page-1}"))
            nav.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="menu_hold"))
            if page < total_pages:
                nav.append(InlineKeyboardButton("▶️", callback_data=f"menu_{key}_{page+1}"))
            keyboard.append(nav)
        keyboard.append([InlineKeyboardButton("← Retour menu", callback_data="menu_main")])
        markup = InlineKeyboardMarkup(keyboard)

    # --- VÉRIFICATION ET ENVOI CORRECT ---
    try:
        # Si le message a du texte → on l'édite
        if q.message.text:
            await q.edit_message_text(
                text,
                parse_mode="HTML",
                reply_markup=markup,
            )
        else:
            # Sinon (photo), on envoie un nouveau message
            await context.bot.send_message(
                chat_id=q.message.chat_id,
                text=text,
                parse_mode="HTML",
                reply_markup=markup
            )
            await q.message.delete()  # on supprime l'ancien
    except Exception:
        # En cas d'erreur (message supprimé, etc.), on envoie un nouveau message
        await context.bot.send_message(
            chat_id=q.message.chat_id,
            text=text,
            parse_mode="HTML",
            reply_markup=markup
        )
        try:
            await q.message.delete()
        except:
            pass


# ═══════════════════════════════════════════════════════════════════
#                Callbacks pour informations
# ═══════════════════════════════════════════════════════════════════
async def dev_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    text = (
        "👨‍💻 **Développeur**\n\n"
        "Le cerveau derrière LifeSim :\n"
        "**[NETFLASH DIEU MAURICE](http://t.me/mauridieu)**\n\n"
        "_Passionné par la simulation de vie et les RPG textuels._"
    )
    await q.message.reply_text(text, parse_mode="Markdown", disable_web_page_preview=True)
    try:
        await q.message.delete()
    except Exception:
        pass

async def creator_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    text = (
        "👑 **Créateur**\n\n"
        "L’univers de LifeSim a été imaginé par un membre de :\n"
        "**[Game French](http://t.me/Sam_Rang_Nation)**\n\n"
        "_Merci de faire vivre ce monde._"
    )
    await q.message.reply_text(text, parse_mode="Markdown", disable_web_page_preview=True)
    try:
        await q.message.delete()
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════
#                Callback pour la boutique /shop
# ═══════════════════════════════════════════════════════════════════
async def shop_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "shop_luxe":
        await q.edit_message_text(
            "👑 <b>Boutique luxe</b>\n"
            "Utilise <code>/luxe</code> pour voir les articles premium.\n"
            "Utilise <code>/acheterLuxe [id]</code> pour acheter un article.",
            parse_mode="HTML"
        )
    elif q.data == "shop_noir":
        await q.edit_message_text(
            "🕶️ <b>Marché noir</b>\n"
            "Utilise <code>/noir</code> pour voir les offres illégales.\n"
            "Utilise <code>/acheternoir [id]</code> pour acheter un article.",
            parse_mode="HTML"
        )
    elif q.data == "shop_close":
        await q.message.delete()
    else:
        await q.edit_message_text("❌ Option invalide.")


# ═══════════════════════════════════════════════════════════════════
#                      Commande inconnue
# ═══════════════════════════════════════════════════════════════════
async def cmd_unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return
    cmd = update.message.text.split()[0]
    await update.message.reply_text(
        alert("warning",
              f"La commande <code>{escape_html(cmd)}</code> n'existe pas.\n"
              f"Tape /aide pour la liste complète."),
        parse_mode="HTML",
    )
