# handlers/market.py — Phase 1 : Marché joueur (commandes renommées)
import random
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import (
    DB_PATH, get_user, update_balance, add_life_journal,
    update_field, increment_field, log_company_action
)
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, now, parse_amount, fmt_time
from utils.aesthetics import card, alert, section

# ─────────────────────────────────────────────────────────────────────────────
# Helper : obtenir la quantité d'un item dans l'inventaire
# ─────────────────────────────────────────────────────────────────────────────
async def get_item_quantity(user_id: int, item_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?",
            (user_id, item_id)
        ) as cur:
            row = await cur.fetchone()
    return row[0] if row else 0

# ─────────────────────────────────────────────────────────────────────────────
# Helper : supprimer un item de l'inventaire (quantité)
# ─────────────────────────────────────────────────────────────────────────────
async def remove_item(user_id: int, item_id: int, quantity: int = 1) -> bool:
    qty = await get_item_quantity(user_id, item_id)
    if qty < quantity:
        return False
    async with aiosqlite.connect(DB_PATH) as db:
        if qty == quantity:
            await db.execute(
                "DELETE FROM inventory WHERE user_id = ? AND item_id = ?",
                (user_id, item_id)
            )
        else:
            await db.execute(
                "UPDATE inventory SET quantity = quantity - ? WHERE user_id = ? AND item_id = ?",
                (quantity, user_id, item_id)
            )
        await db.commit()
    return True

# ─────────────────────────────────────────────────────────────────────────────
# Helper : ajouter un item à l'inventaire
# ─────────────────────────────────────────────────────────────────────────────
async def add_item(user_id: int, item_id: int, quantity: int, source: str = None):
    """Ajoute un item à l'inventaire d'un joueur (cumule les quantités)."""
    async with aiosqlite.connect(DB_PATH, timeout=60.0) as db:
        cursor = await db.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?",
            (user_id, item_id)
        )
        row = await cursor.fetchone()
        if row:
            await db.execute(
                "UPDATE inventory SET quantity = quantity + ? WHERE user_id = ? AND item_id = ?",
                (quantity, user_id, item_id)
            )
        else:
            await db.execute(
                "INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at) VALUES (?,?,?,?,?,?)",
                (user_id, item_id, "", "", quantity, now())
            )
        await db.commit()

# ─────────────────────────────────────────────────────────────────────────────
# /market : afficher les annonces
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_market(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    page = 1
    if context.args and context.args[0].isdigit():
        page = int(context.args[0])
    
    per_page = 10
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ml.listing_id, ml.seller_id, ml.item_id, ml.quantity, ml.price,
                   i.name, i.emoji, i.rarity, u.full_name as seller_name
            FROM market_listings ml
            JOIN items i ON i.item_id = ml.item_id
            JOIN users u ON u.user_id = ml.seller_id
            WHERE ml.status = 'active' AND ml.expires_at > ?
            ORDER BY ml.price ASC, ml.created_at ASC
            LIMIT ? OFFSET ?
        """, (now(), per_page, (page - 1) * per_page)) as cur:
            listings = await cur.fetchall()
        
        async with db.execute("SELECT COUNT(*) FROM market_listings WHERE status = 'active' AND expires_at > ?", (now(),)) as cur2:
            total = (await cur2.fetchone())[0]
    
    if not listings:
        await update.message.reply_text(
            card("🏪 Marché joueur", ["Aucune annonce active pour le moment."],
                 icon="🏪", style="thick")
        )
        return
    
    text = f"🏪 **Marché joueur** (page {page}/{max(1, (total + per_page - 1) // per_page)})\n\n"
    for l in listings:
        text += (
            f"{l['emoji']} **{l['name']}** ({l['rarity']})\n"
            f"  Vendeur : {l['seller_name']}\n"
            f"  Quantité : {l['quantity']} | Prix unitaire : {fmt(l['price'])}\n"
            f"  ID annonce : `{l['listing_id']}`\n\n"
        )
    
    keyboard = []
    if page > 1:
        keyboard.append(InlineKeyboardButton("◀️ Page précédente", callback_data=f"market_page_{page-1}"))
    if (page * per_page) < total:
        keyboard.append(InlineKeyboardButton("Page suivante ▶️", callback_data=f"market_page_{page+1}"))
    
    if keyboard:
        reply_markup = InlineKeyboardMarkup([keyboard])
    else:
        reply_markup = None
    
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=reply_markup)

async def market_page_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    page = int(query.data.split("_")[-1])
    context.args = [str(page)]
    await cmd_market(update, context)
    try:
        await query.message.delete()
    except:
        pass

# ─────────────────────────────────────────────────────────────────────────────
# /sellitem : mettre un item en vente (corrigé : retrait immédiat)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@cooldown("sell_cooldown", 10, "⏳ Attends quelques secondes avant de mettre un autre item en vente.")
async def cmd_sellitem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    
    if len(context.args) < 2:
        await update.message.reply_text(
            "Usage : `/sellitem [item_id] [prix] [quantité]`\n\n"
            "Pour connaître l'ID d'un item, utilise `/inventaire`.\n"
            "Exemple : `/sellitem 3 5000 2` (vend 2 exemplaires de l'item #3 à 5000 coins l'unité)\n"
            "La vente expire automatiquement après 7 jours."
        )
        return
    
    try:
        item_id = int(context.args[0])
        price = int(context.args[1])
        quantity = int(context.args[2]) if len(context.args) > 2 else 1
        if price <= 0 or quantity <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides. Utilisez des nombres positifs.")
        return
    
    # 1. Vérifier le stock disponible
    current_qty = await get_item_quantity(user.id, item_id)
    if current_qty < quantity:
        await update.message.reply_text(f"❌ Tu ne possèdes que {current_qty} exemplaire(s) de cet item.")
        return

    # 2. Vérifier les quantités déjà en vente (hors inventaire)
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT SUM(quantity) FROM market_listings WHERE seller_id = ? AND item_id = ? AND status = 'active'",
            (user.id, item_id)
        ) as cur:
            row = await cur.fetchone()
        already_on_sale = row[0] if row[0] else 0

        if already_on_sale + quantity > current_qty:
            await update.message.reply_text(
                f"❌ Tu as déjà {already_on_sale} exemplaire(s) de cet item en vente.\n"
                f"Tu ne peux pas en mettre plus que ton stock total ({current_qty}).\n"
                f"Essaie de vendre {current_qty - already_on_sale} au maximum."
            )
            return

    # 3. Retirer les items de l'inventaire (réservation)
    if not await remove_item(user.id, item_id, quantity):
        await update.message.reply_text("❌ Erreur lors du retrait des items.")
        return

    # 4. Récupérer les infos de l'item
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT name, emoji FROM items WHERE item_id = ?", (item_id,)) as cur:
            item = await cur.fetchone()
    if not item:
        # Annulation : remettre les items
        await add_item(user.id, item_id, quantity, "rollback")
        await update.message.reply_text("❌ Item introuvable dans la base.")
        return
    
    expires_at = now() + 7 * 86400  # 7 jours
    
    # 5. Créer l'annonce
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT INTO market_listings (seller_id, item_id, quantity, price, created_at, expires_at, status)
            VALUES (?, ?, ?, ?, ?, ?, 'active')
        """, (user.id, item_id, quantity, price, now(), expires_at))
        await db.commit()
    
    await add_life_journal(
        user.id, "market",
        f"Mise en vente de {quantity}x {item['emoji']} {item['name']} pour {fmt(price)}/u.",
        severity="info"
    )
    
    await update.message.reply_text(
        f"📦 **Item mis en vente !**\n\n"
        f"{item['emoji']} **{item['name']}**\n"
        f"Quantité : {quantity}\n"
        f"Prix unitaire : {fmt(price)}\n"
        f"Expiration : {fmt_time(expires_at - now())}\n\n"
        f"_Utilise `/cancelitem [listing_id]` pour annuler la vente._"
    )

# ─────────────────────────────────────────────────────────────────────────────
# /cancelitem : annuler une vente (inchangé, déjà correct)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_cancelitem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    
    if not context.args:
        await update.message.reply_text("Usage : `/cancelitem [listing_id]`\n\nL'ID de l'annonce se trouve dans `/market` ou `/myitems`.")
        return
    
    try:
        listing_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID invalide.")
        return
    
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT listing_id, seller_id, item_id, quantity, price FROM market_listings WHERE listing_id = ? AND status = 'active'",
            (listing_id,)
        ) as cur:
            listing = await cur.fetchone()
        
        if not listing:
            await update.message.reply_text("❌ Annonce introuvable ou déjà vendue/expirée.")
            return
        if listing["seller_id"] != user.id:
            await update.message.reply_text("❌ Tu ne peux annuler que tes propres annonces.")
            return
        
        await db.execute(
            "UPDATE inventory SET quantity = quantity + ? WHERE user_id = ? AND item_id = ?",
            (listing["quantity"], user.id, listing["item_id"])
        )
        await db.execute("UPDATE market_listings SET status = 'cancelled' WHERE listing_id = ?", (listing_id,))
        await db.commit()
    
    await update.message.reply_text(f"✅ Annulation réussie. Tu as récupéré {listing['quantity']} exemplaire(s) de l'item.")
    await add_life_journal(user.id, "market", f"Annulation de la vente #{listing_id}", severity="info")

# ─────────────────────────────────────────────────────────────────────────────
# /buyitem : acheter un item (inchangé)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@cooldown("buy_cooldown", 5, "⏳ Attends quelques secondes avant de faire un autre achat.")
async def cmd_buyitem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not context.args:
        await update.message.reply_text("Usage : `/buyitem [listing_id] [quantité]`\n\nL'ID de l'annonce se trouve dans `/market`.")
        return

    try:
        listing_id = int(context.args[0])
        quantity = int(context.args[1]) if len(context.args) > 1 else 1
        if quantity <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return

    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ml.*, i.name, i.emoji, i.rarity, i.effect_type, i.effect_value,
                   u.full_name as seller_name
            FROM market_listings ml
            JOIN items i ON i.item_id = ml.item_id
            JOIN users u ON u.user_id = ml.seller_id
            WHERE ml.listing_id = ? AND ml.status = 'active' AND ml.expires_at > ?
        """, (listing_id, now())) as cur:
            listing = await cur.fetchone()

        if not listing:
            await update.message.reply_text("❌ Annonce introuvable, expirée ou déjà vendue.")
            return

        if listing["seller_id"] == user.id:
            await update.message.reply_text("❌ Tu ne peux pas acheter tes propres articles.")
            return

        if quantity > listing["quantity"]:
            await update.message.reply_text(f"❌ Le vendeur ne propose que {listing['quantity']} exemplaire(s).")
            return

        total_cost = quantity * listing["price"]
        if u["balance"] < total_cost:
            await update.message.reply_text(f"❌ Fonds insuffisants. Coût total : {fmt(total_cost)}")
            return

        # 1. Transférer l'argent
        await update_balance(user.id, -total_cost)
        await update_balance(listing["seller_id"], total_cost)

        # 2. Ajouter l'item à l'acheteur
        await add_item(user.id, listing["item_id"], quantity, "market")

        # 3. Retirer l'item de l'inventaire du vendeur (normalement déjà retiré lors de la mise en vente, mais sécurité)
        seller_qty = await get_item_quantity(listing["seller_id"], listing["item_id"])
        if seller_qty < quantity:
            # Cas improbable, mais on annule
            await update_balance(user.id, total_cost)
            await update_balance(listing["seller_id"], -total_cost)
            await update.message.reply_text("❌ Erreur : le vendeur n'a plus assez d'items. Transaction annulée.")
            return
        await remove_item(listing["seller_id"], listing["item_id"], quantity)

        # 4. Mettre à jour ou supprimer l'annonce
        new_quantity = listing["quantity"] - quantity
        if new_quantity <= 0:
            await db.execute("UPDATE market_listings SET status = 'sold' WHERE listing_id = ?", (listing_id,))
        else:
            await db.execute("UPDATE market_listings SET quantity = ? WHERE listing_id = ?", (new_quantity, listing_id))

        # 5. Récupérer les infos du produit pour le suivi des ventes (avant commit)
        product_info = None
        async with db.execute("""
            SELECT cp.id, cp.sales, cp.revenue, cp.price, cp.company_id
            FROM company_products cp
            JOIN items i ON i.name = cp.name
            WHERE i.item_id = ?
        """, (listing["item_id"],)) as cur2:
            product_row = await cur2.fetchone()
            if product_row:
                product_info = dict(product_row)

        await db.commit()

    # ─── Après le commit : mise à jour des stats et logs ───
    if product_info:
        new_sales = product_info["sales"] + quantity
        new_revenue = product_info["revenue"] + (quantity * product_info["price"])
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "UPDATE company_products SET sales = ?, revenue = ? WHERE id = ?",
                (new_sales, new_revenue, product_info["id"])
            )
            # Logguer l'action
            await log_company_action(
                product_info["company_id"],
                "vente_produit",
                listing["seller_id"],
                f"{quantity}x {listing['name']} pour {fmt(total_cost)} (ID annonce {listing_id})"
            )
            await db.commit()

    await add_life_journal(
        user.id, "market",
        f"Achat de {quantity}x {listing['emoji']} {listing['name']} pour {fmt(total_cost)} à {listing['seller_name']}",
        severity="success"
    )

    await update.message.reply_text(
        f"✅ **Achat réussi !**\n\n"
        f"{listing['emoji']} **{listing['name']}** ({listing['rarity']})\n"
        f"Quantité : {quantity}\n"
        f"Prix total : {fmt(total_cost)}\n"
        f"💰 Nouveau solde : {fmt(u['balance'] - total_cost)}\n\n"
        f"_Utilise `/useitem [item_id]` pour utiliser un objet consommable._"
    )

# ─────────────────────────────────────────────────────────────────────────────
# /useitem : utiliser un item (consommable) – inchangé
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@cooldown("use_cooldown", 2, "⏳ Attends 2 secondes avant d'utiliser un autre item.")
async def cmd_useitem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    
    if not context.args:
        await update.message.reply_text(
            "Usage : `/useitem [item_id] [quantité]`\n\n"
            "Les items consommables ont des effets :\n"
            "• `heal` : restaure des points de santé\n"
            "• `energy` : restaure de l'énergie\n"
            "• `xp` : donne de l'XP\n"
            "• `money` : donne de l'argent\n"
            "• `buff` : boost temporaire (bonheur +, stress -)\n\n"
            "Exemple : `/useitem 5` (utilise 1 exemplaire de l'item #5)"
        )
        return
    
    try:
        item_id = int(context.args[0])
        quantity = int(context.args[1]) if len(context.args) > 1 else 1
        if quantity <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return
    
    current_qty = await get_item_quantity(user.id, item_id)
    if current_qty < quantity:
        await update.message.reply_text(f"❌ Tu ne possèdes que {current_qty} exemplaire(s) de cet item.")
        return
    
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT name, emoji, rarity, type, effect_type, effect_value FROM items WHERE item_id = ?",
            (item_id,)
        ) as cur:
            item = await cur.fetchone()
        if not item:
            await update.message.reply_text("❌ Item introuvable.")
            return
    
    if item["type"] != "consumable":
        await update.message.reply_text(f"❌ L'item {item['emoji']} **{item['name']}** n'est pas consommable.")
        return
    
    effect_type = item["effect_type"]
    effect_value = item["effect_value"] * quantity
    
    effect_msg = ""
    if effect_type == "heal":
        new_health = min(100, u["health"] + effect_value)
        await update_field(user.id, "health", new_health)
        effect_msg = f"❤️ Santé : {u['health']} → {new_health}"
    elif effect_type == "energy":
        new_energy = min(100, u["energy"] + effect_value)
        await update_field(user.id, "energy", new_energy)
        effect_msg = f"⚡ Énergie : {u['energy']} → {new_energy}"
    elif effect_type == "xp":
        await increment_field(user.id, "xp", effect_value)
        effect_msg = f"✨ +{effect_value} XP"
    elif effect_type == "money":
        await update_balance(user.id, effect_value)
        effect_msg = f"💰 +{fmt(effect_value)} coins"
    elif effect_type == "buff":
        new_happiness = min(100, u["happiness"] + effect_value)
        new_stress = max(0, u["stress"] - effect_value // 2)
        await update_field(user.id, "happiness", new_happiness)
        await update_field(user.id, "stress", new_stress)
        effect_msg = f"✨ Buff appliqué : Bonheur +{effect_value}, Stress -{effect_value//2}"
    else:
        await update.message.reply_text(f"❌ Effet '{effect_type}' non implémenté pour le moment.")
        return
    
    await remove_item(user.id, item_id, quantity)
    
    await add_life_journal(
        user.id, "item",
        f"Utilisation de {quantity}x {item['emoji']} {item['name']} : {effect_msg}",
        severity="success"
    )
    
    await update.message.reply_text(
        f"✨ **Utilisation de {item['emoji']} {item['name']}** (x{quantity})\n\n"
        f"{effect_msg}\n\n"
        f"Il te reste {current_qty - quantity} exemplaire(s) de cet item."
    )

# ─────────────────────────────────────────────────────────────────────────────
# /myitems : voir ses propres annonces
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_myitems(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ml.listing_id, ml.item_id, ml.quantity, ml.price, ml.created_at, ml.expires_at,
                   i.name, i.emoji, i.rarity
            FROM market_listings ml
            JOIN items i ON i.item_id = ml.item_id
            WHERE ml.seller_id = ? AND ml.status = 'active'
            ORDER BY ml.created_at DESC
        """, (user.id,)) as cur:
            listings = await cur.fetchall()
    
    if not listings:
        await update.message.reply_text("📭 Tu n'as aucune annonce active.")
        return
    
    text = "📦 **Tes annonces**\n\n"
    for l in listings:
        expires_in = l["expires_at"] - now()
        text += (
            f"ID: `{l['listing_id']}` — {l['emoji']} **{l['name']}** ({l['rarity']})\n"
            f"  Quantité : {l['quantity']} | Prix unitaire : {fmt(l['price'])}\n"
            f"  Expire dans : {fmt_time(expires_in)}\n\n"
        )
    text += "Pour annuler : `/cancelitem [listing_id]`"
    await update.message.reply_text(text, parse_mode="Markdown")

# ─────────────────────────────────────────────────────────────────────────────
# Maintenance : nettoyer les annonces expirées (appelée par scheduler)
# ─────────────────────────────────────────────────────────────────────────────
async def clean_expired_listings():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT listing_id, seller_id, item_id, quantity
            FROM market_listings
            WHERE status = 'active' AND expires_at < ?
        """, (now(),)) as cur:
            expired = await cur.fetchall()
        
        for listing in expired:
            # Remettre les items en stock
            await db.execute(
                "UPDATE inventory SET quantity = quantity + ? WHERE user_id = ? AND item_id = ?",
                (listing["quantity"], listing["seller_id"], listing["item_id"])
            )
            await db.execute(
                "UPDATE market_listings SET status = 'expired' WHERE listing_id = ?",
                (listing["listing_id"],)
            )
        await db.commit()