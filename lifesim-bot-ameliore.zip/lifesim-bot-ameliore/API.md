# LifeSim Pro API Documentation

## Structure des modules

### `handlers/`
- `admin.py` - Commandes administrateur (ban, warn, addmoney, etc.)
- `economy.py` - Travail, métiers, loterie, taxes
- `education.py` - Diplômes, formations, compétences
- `crime.py` - Crimes, prison, gangs
- `casino.py` - Jeux d'argent (slots, blackjack, roulette...)

### `database.py`
Principales fonctions :
- `get_user(user_id)` - Récupère ou crée un utilisateur
- `update_balance(user_id, amount)` - Modifie le solde
- `increment_field(user_id, field, amount)` - Incrémente un champ

### `utils/`
- `decorators.py` - @require_registered, @require_free, @cooldown
- `helpers.py` - fmt(), fmt_time(), parse_amount(), get_level()