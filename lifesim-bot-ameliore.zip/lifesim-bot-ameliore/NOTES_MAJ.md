# LifeSim Bot amélioré

Principales évolutions intégrées dans cette version :

- correction de deux erreurs de syntaxe qui empêchaient le bot de démarrer
- résolution d’un conflit de commandes entre les modules `companies` et `political`
- suppression de plusieurs enregistrements de handlers en double dans `bot.py`
- refonte ciblée du module entreprises pour éviter l’essoufflement de la progression
- ajout d’un audit intelligent des entreprises avec la commande `/auditboite`
- ajout de vues interactives avec boutons dans les fiches d’entreprise :
  - vue d’ensemble
  - audit
  - produits
  - équipe
  - gestion et finance pour les responsables
- amélioration visuelle des messages entreprise avec cartes HTML plus lisibles
- ajout d’une vraie boucle économique produits :
  - catalogue suivi dans `company_products`
  - prix conseillés
  - ventes automatiques en maintenance
  - revenus et historique de ventes
- ajout d’une montée de niveau automatique des entreprises selon la trésorerie, la réputation, la R&D, les produits, l’équipe et les contrats
- amélioration du système de R&D avec montée de plusieurs niveaux selon l’investissement réel
- ajout d’un vrai système coopératif avec :
  - `/creerescouade`
  - `/escouade`
  - `/inviterescouade`
  - `/quitterescouade`
  - `/chatescouade`
  - `/raid lancer [mise]`
  - `/raid attaquer`
- ajout d’une maintenance multijoueur pour expirer les invitations et raids obsolètes
- ajout d’outils admin :
  - `/adminpanel`
  - `/raidstatus`
  - `/forceraid id finish|cancel`
  - `/squadinfo id`

Validation effectuée :

- compilation Python complète du projet
- test d’initialisation de la base de données
- test de construction de l’application Telegram
