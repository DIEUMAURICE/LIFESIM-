"""Vérifie le centre d'aide : taille des pages, callbacks, liens entre pages."""
import sys, types, asyncio
sys.path.insert(0, '.')
tg = types.ModuleType('telegram')
class Btn:
    def __init__(s, text, callback_data=None, **k): s.text, s.callback_data = text, callback_data
class Mk:
    def __init__(s, kb): s.inline_keyboard = kb
tg.InlineKeyboardButton, tg.InlineKeyboardMarkup = Btn, Mk
sys.modules['telegram'] = tg
from handlers import help_center as H
errors, valid = [], {f"help:{k}" for k, *_ in H.PAGES} | {"help:home", "help:news", "help:tuto"}
def walk(mk, where):
    for row in mk.inline_keyboard:
        for b in row:
            if len(b.callback_data.encode()) > 64: errors.append(f"{where}: callback trop long {b.callback_data}")
            if b.callback_data.startswith('help:') and b.callback_data not in valid: errors.append(f"{where}: lien cassé {b.callback_data}")
walk(H.home_markup(), 'home')
print(f"accueil : {len(H.home_text())} caractères")
class Q:
    data = ''
    async def answer(s): pass
    async def edit_message_text(s, text, **k): s.out = (text, k['reply_markup'])
async def main():
    for k, label, title, content in H.PAGES:
        q = Q(); q.data = f"help:{k}"
        await H.help_callback(types.SimpleNamespace(callback_query=q), None)
        text, mk = q.out; walk(mk, k)
        if len(text) > 1500: errors.append(f"{k}: page longue ({len(text)} car.)")
        lines = text.count('\n')
        print(f"  {k:<9} {len(text):>5} car. {lines:>3} lignes")
asyncio.run(main())
print("\n".join("❌ " + e for e in errors) or "✅ aide valide")
sys.exit(1 if errors else 0)
