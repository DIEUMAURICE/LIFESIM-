"""Détecte les noms utilisés mais jamais définis ni importés (NameError à l'exécution).

Ignore les fichiers qui utilisent « from x import * » (les noms viennent alors de x).
Sortie : code 0 si tout est résolu, 1 sinon.
"""
import ast, builtins, glob, sys, os

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BUILTINS = set(dir(builtins)) | {"__file__", "__name__", "__doc__"}


def check(path):
    tree = ast.parse(open(path, encoding="utf-8").read(), path)
    if any(isinstance(n, ast.ImportFrom) and any(a.name == "*" for a in n.names) for n in ast.walk(tree)):
        return []
    defined = set(BUILTINS)
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            defined.add(node.name)
        elif isinstance(node, ast.Import):
            defined.update((a.asname or a.name).split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            defined.update(a.asname or a.name for a in node.names)
        elif isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
            defined.add(node.id)
        elif isinstance(node, ast.arg):
            defined.add(node.arg)
        elif isinstance(node, ast.ExceptHandler) and node.name:
            defined.add(node.name)
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            defined.update(node.names)
    errors = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load) and node.id not in defined:
            errors.append(f"{os.path.relpath(path, ROOT)}:{node.lineno} nom non défini : {node.id}")
    return errors


if __name__ == "__main__":
    problems = []
    for path in glob.glob(os.path.join(ROOT, "**", "*.py"), recursive=True):
        rel = os.path.relpath(path, ROOT)
        if rel.startswith(("test", "tools", "scripts")):
            continue
        problems += check(path)
    for p in problems:
        print(p)
    print("✅ aucun nom non défini" if not problems else f"❌ {len(problems)} nom(s) non défini(s)")
    sys.exit(1 if problems else 0)
