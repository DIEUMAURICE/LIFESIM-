"""Valide offline tous les formulaires : fonctions, SQL, callback_data, cohérence."""
import re, sys, types, sqlite3, asyncio, importlib, glob
sys.path.insert(0, '.')
# stubs minimaux (telegram/aiosqlite absents du sandbox)
tg = types.ModuleType('telegram')
class Btn:
    def __init__(s, text, callback_data=None, **k): s.text, s.callback_data = text, callback_data
class Mk:
    def __init__(s, kb): s.inline_keyboard = kb
tg.InlineKeyboardButton, tg.InlineKeyboardMarkup = Btn, Mk
ext = types.ModuleType('telegram.ext')
class Stop(Exception): pass
ext.ApplicationHandlerStop = Stop
sys.modules['telegram'], sys.modules['telegram.ext'] = tg, ext
dbm = types.ModuleType('database'); dbm.db_connection = lambda *a, **k: None
sys.modules['database'] = dbm
from utils import forms
for f in sorted(glob.glob('handlers/forms_*.py')):
    importlib.import_module('handlers.' + f.split('/')[-1][:-3])

errors = []
# 1) la fonction cible existe, 2) args cohérents
for k, f in forms.FORMS.items():
    mod, fn = f.cmd.split(':')
    src = open(mod.replace('.', '/') + '.py', encoding='utf-8').read()
    reexported = re.search(r'^from [\w.]+ import \(?[^)]*?\b' + fn + r'\b', src, re.M | re.S)   # ré-export (module éclaté)
    if not re.search(r'^async def ' + fn + r'\(', src, re.M) and not reexported:
        errors.append(f"{k}: {fn} introuvable dans {mod}")
    if sum(1 for p in f.params if p.kind == 'user' and p.reply) > 1:
        errors.append(f"{k}: plusieurs joueurs en réponse")
    for p in f.params:
        if p.kind == 'choice' and not p.choices:
            errors.append(f"{k}.{p.key}: choice sans options")
        if isinstance(p.choices, str) and p.choices not in forms.PROVIDERS:
            errors.append(f"{k}.{p.key}: provider '{p.choices}' inconnu")
        if isinstance(p.choices, tuple):
            for lbl, v in p.choices:
                pass
# 3) SQL des providers contre le vrai schéma
db_src = open('database.py', encoding='utf-8').read()
con = sqlite3.connect(':memory:')
for c in re.findall(r'(CREATE TABLE IF NOT EXISTS \w+\s*\(.*?\n\s*\))\s*"""', db_src, re.S):
    try: con.execute(c)
    except Exception: pass
for t, col, typ in re.findall(r'ALTER TABLE (\w+) ADD COLUMN (\w+) ([A-Z]+(?: DEFAULT [^"\')]+)?)', db_src):
    try: con.execute(f"ALTER TABLE {t} ADD COLUMN {col} {typ}")
    except Exception: pass
nsql = 0
unchecked = []   # requêtes SQL qu'on n'a pas pu valider (f-strings dynamiques, variables…) → avertissement
_STR = r'(?:f?"[^"]*"|f?\'[^\']*\')'
_SEG = re.compile(r'(f?)(?:"([^"]*)"|\'([^\']*)\')')
for f in sorted(glob.glob('handlers/forms_*.py')):
    src = open(f, encoding='utf-8').read()
    seen = set()   # positions des execute( déjà traités
    for m in re.finditer(r'execute\(\s*((?:' + _STR + r'\s*)+)', src):
        seen.add(m.start())
        segs = _SEG.findall(m.group(1))
        sql = ''.join(a or b for _f, a, b in segs)
        if any(fp and '{' in (a or b) for fp, a, b in segs):    # f-string avec interpolation : SQL non figé
            unchecked.append(f"{f}: SQL dynamique (f-string) :: {sql[:70]}")
            continue
        nsql += 1
        try: con.execute("EXPLAIN " + sql, (0,) * sql.count('?'))
        except Exception as e: errors.append(f"SQL: {e} :: {sql[:90]}")
    # tous les autres appels execute( (variable, .format(), concaténation…) : signalés, jamais ignorés en silence
    for m in re.finditer(r'\bexecute\(', src):
        if m.start() not in seen:
            line = src.count('\n', 0, m.start()) + 1
            unchecked.append(f"{f}:{line}: execute() non analysable")
# 4) callback_data ≤ 64 octets (boutons statiques + choix statiques)
for k, f in forms.FORMS.items():
    if len(f"fm:{k}".encode()) > 64: errors.append(f"callback trop long: fm:{k}")
    for p in f.params:
        if isinstance(p.choices, tuple) and len(p.choices) > 60:
            errors.append(f"{k}.{p.key}: trop de choix")
print(f"{len(forms.FORMS)} formulaires, {nsql} requêtes SQL vérifiées")
for w in unchecked:
    print("⚠️ SQL non vérifié — " + w)
print("\n".join("❌ " + e for e in errors) or "✅ aucune erreur")
sys.exit(1 if errors else 0)
