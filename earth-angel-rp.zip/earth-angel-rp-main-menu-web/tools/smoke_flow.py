import sys, types, asyncio, sqlite3, contextlib
sys.path.insert(0, '.')

# ── stubs hors-ligne (telegram / database absents de ce sandbox) ──
tg = types.ModuleType('telegram')
class Btn:
    def __init__(s, text, callback_data=None): s.text, s.callback_data = text, callback_data
class Mk:
    def __init__(s, kb): s.inline_keyboard = kb
tg.InlineKeyboardButton, tg.InlineKeyboardMarkup = Btn, Mk
ext = types.ModuleType('telegram.ext')
class Stop(Exception): pass
ext.ApplicationHandlerStop = Stop
sys.modules['telegram'], sys.modules['telegram.ext'] = tg, ext

con = sqlite3.connect(':memory:')
con.execute("CREATE TABLE users(user_id INTEGER PRIMARY KEY, username TEXT, full_name TEXT)")
con.executemany("INSERT INTO users VALUES(?,?,?)", [(111,'Alice','Alice A'),(222,'bob_77','Bob'),(333,None,'Sans Pseudo')])
class Cur:
    def __init__(s, rows): s.rows = rows
    async def fetchone(s): return s.rows[0] if s.rows else None
    async def __aenter__(s): return s
    async def __aexit__(s,*a): pass
class DB:
    def execute(s, q, p=()): return Cur(con.execute(q, p).fetchall())
@contextlib.asynccontextmanager
async def db_connection(): yield DB()
dbm = types.ModuleType('database'); dbm.db_connection = db_connection
sys.modules['database'] = dbm

from utils import input_flow as f

class Msg:
    def __init__(s, text=None): s.text, s.sent = text, []
    async def reply_text(s, t, **k): s.sent.append((t, k))
class Ctx:
    def __init__(s): s.user_data = {}
class Upd:
    def __init__(s, text): s.effective_message = Msg(text); s.effective_user = types.SimpleNamespace(id=111)

got = []
@f.flow('t_user')
async def _u(update, context, value, data): got.append(('user', value, data))
@f.flow('t_amt')
async def _a(update, context, value, data): got.append(('amt', value, data))

async def run(kind, name, text, **kw):
    ctx = Ctx()
    q = types.SimpleNamespace(edit_message_text=None)
    async def edit(t, **k): ctx.last_prompt = (t, k)
    q.edit_message_text = edit
    await f.ask(q, ctx, name, 'Question ?', kind=kind, data={'x': 1}, back='eco_retour', **kw)
    upd = Upd(text)
    try:
        await f.flow_message_handler(upd, ctx)
        return 'no-stop', upd, ctx
    except Stop:
        return 'stop', upd, ctx

async def main():
    # résolution
    assert await f.resolve_user('@alice') == (111, 'Alice A')
    assert await f.resolve_user('bob_77') == (222, 'Bob')
    assert await f.resolve_user('333') == (333, 'Sans Pseudo')
    assert await f.resolve_user('@inconnu') is None
    assert await f.resolve_user('') is None
    # montant valide, raccourcis, bornes
    s,u,c = await run('amount','t_amt','2k', min_value=1); assert got[-1][:2]==('amt',2000) and s=='stop' and f.FLOW_KEY not in c.user_data
    s,u,c = await run('amount','t_amt','50%', min_value=1, balance=1000); assert got[-1][1]==500
    s,u,c = await run('amount','t_amt','tout', min_value=1, balance=1234); assert got[-1][1]==1234
    n=len(got); s,u,c = await run('amount','t_amt','abc', min_value=1)
    assert len(got)==n and 'invalide' in u.effective_message.sent[0][0] and f.FLOW_KEY in c.user_data  # saisie conservée
    n=len(got); s,u,c = await run('amount','t_amt','0', min_value=1); assert len(got)==n and 'Minimum' in u.effective_message.sent[0][0]
    n=len(got); s,u,c = await run('amount','t_amt','999', max_value=100); assert len(got)==n and 'Maximum' in u.effective_message.sent[0][0]
    # joueur
    s,u,c = await run('user','t_user','@bob_77'); assert got[-1]==('user',(222,'Bob'),{'x':1})
    n=len(got); s,u,c = await run('user','t_user','@fantome'); assert len(got)==n and 'introuvable' in u.effective_message.sent[0][0]
    # expiration
    ctx = Ctx(); await f.ask(types.SimpleNamespace(edit_message_text=lambda *a,**k: asyncio.sleep(0)), ctx, 't_amt', 'Q', kind='int')
    ctx.user_data[f.FLOW_KEY].expires = 0
    upd = Upd('5')
    try: await f.flow_message_handler(upd, ctx); raise SystemExit('devait lever Stop')
    except Stop: pass
    assert 'expirée' in upd.effective_message.sent[0][0] and f.FLOW_KEY not in ctx.user_data
    # aucun flux en attente → le message passe (pas de Stop)
    upd = Upd('salut'); await f.flow_message_handler(upd, Ctx())
    # flux inconnu
    try: await f.ask(types.SimpleNamespace(edit_message_text=None), Ctx(), 'nope', 'Q'); raise SystemExit('KeyError attendu')
    except KeyError: pass
    # bouton annuler + retour
    ctx = Ctx(); ctx.user_data[f.FLOW_KEY] = f.PendingFlow('t_amt','int',{},'eco_retour',None,None,None,9e9)
    out = {}
    async def ans(*a,**k): pass
    async def edit(t, **k): out['t'], out['k'] = t, k
    cq = types.SimpleNamespace(answer=ans, edit_message_text=edit)
    await f.flow_cancel_callback(types.SimpleNamespace(callback_query=cq), ctx)
    assert f.FLOW_KEY not in ctx.user_data and out['k']['reply_markup'].inline_keyboard[0][0].callback_data=='eco_retour'
    print("✅ input_flow : 14 vérifications OK")
asyncio.run(main())
