const { chromium } = require("/opt/npm-tools/node_modules/playwright");
const fs = require("fs"), path = require("path");
const STATIC = "" + require('path').resolve(__dirname, '..', 'webapp', 'static') + "";
const MAP = { "/shared/": STATIC + "/shared/", "/app/": STATIC + "/web/" };
const mime = { ".js": "text/javascript", ".css": "text/css", ".html": "text/html", ".png": "image/png", ".jpg": "image/jpeg" };
const J = (o, status = 200) => ({ status, contentType: "application/json", body: JSON.stringify(o) });

const API = {
  "/api/profile": { character_complete: true, avatar: "🧑", net_worth: 12345, character: { first_name: "Ada", last_name: "Lovelace" },
    user: { user_id: 7, level: 3, job: "Boulanger", karma: 10, health: 80, energy: 60, happiness: 70, hunger: 50, balance: 1000, prestige: 5 } },
  "/api/work/status": { work_ready: true, daily_ready: true, work_seconds_left: 0 },
  "/api/work/job": { job: { emoji: "🥖", name: "Boulanger", min: 10, max: 20, xp: 5 } },
  "/api/work/catalog": { jobs: [{ emoji: "🥖", name: "Boulanger", min: 10, max: 20, locked: false }] },
  "/api/bank": { wallet_balance: 1000, banks: [{ name: "BNP", daily_interest_pct: 1, min: 100 }], accounts: [{ bank_name: "BNP", balance: 500 }] },
  "/api/companies/mine": { company: null },
  "/api/companies": { sectors: ["Tech"], companies: [{ name: "<img src=x onerror=window.__xss=1>", sector: "Tech", treasury: 5 }] },
  "/api/realestate/catalog": { items: [{ emoji: "🏠", type: "Studio", price: 1000, rent: 10 }], owned_count: 0, max_properties: 3 },
  "/api/realestate/mine": { properties: [] },
  "/api/casino/status": { open: true, balance: 1000, min_bet: 10, max_bet: 1000 },
  "/api/justice/status": { in_prison: false },
  "/api/crime/status": { cooldown_seconds_left: 0, in_gang_or_exempt: true, crimes: [{ name: "Vol", success_pct: 50, reward_min: 1, reward_max: 2, karma: -1, needs_firearm: false }] },
  "/api/reseau/home": { followers: 1, following: 2, posts: 3, likes: 4 },
  "/api/reseau/feed": { enabled: true, posts: [{ id: 1, author: "Bob", author_id: 9, platform: "X", created_at: 0, text: "salut #test <b>x</b>", likes: 2, comments: 0, mine: false, liked: false, following: false }] },
  "/api/reseau/compose": { ready: true, platforms: ["X", "Insta"], max: 200, xp: 5, hours: 2 },
  "/api/sante/status": { health: 40, energy: 70, balance: 1000, hospitalized_seconds: 0, location_label: "Maison", in_transit: false, at_hospital: false,
    insurance: { type: "basique", claims: 0, limit: 3, left: 3, expires: "12/2026" }, bed: false, call: null,
    hospitals: [{ id: "grand", name: "Grand hôpital", kind: "grand", location: "hopital", beds_free: 8, beds_cap: 10, on_duty: 2, head: "<b>Dr X</b>", here: false, distance_km: 2.5 }] },
  "/api/sante/pharmacy": { items: [{ name: "Aspirine", emoji: "💊", health: 10, price: 90, base: 100, discounted: true, stock: 5 }] },
  "/api/sante/insurance": { plans: [{ key: "basique", emoji: "🔵", cost: 5000, coverage_pct: 30, claims_limit: 3 }] },
  "/api/places/options": { dest: "hopital", dest_label: "Grand hôpital", from_label: "Maison", options: [{ mode: "walk", label: "🚶 À pied", km: 2.5, duration_seconds: 600, energy: 5, fuel: 0, money: 0, ok: true, why: "" }, { mode: "taxi", label: "🚕 Taxi", km: 2.5, duration_seconds: 120, energy: 0, fuel: 0, money: 90, ok: false, why: "trop cher" }] },
  "/api/rankings/rich": { top: [{ user_id: 7, full_name: "Ada", balance: 99 }] },
  "/api/notifications/history": { notifications: [] },
  "/api/notifications/pending": { notifications: [] },
  "/api/phone/home": { notifications: [], unread: 0, contacts: [] },
};

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 800 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
  const posted = [];

  await page.route("http://test/**", async (route) => {
    const req = route.request(); const u = new URL(req.url()); const p = u.pathname;
    if (p.startsWith("/api/")) {
      if (req.method() === "POST") posted.push(p + " " + (req.postData() || ""));
      if (p === "/api/admin/whoami") return route.fulfill(J({ staff: false }));
      if (req.method() === "POST") return route.fulfill(J({ ok: true, success: true, gain: 5, xp: 1, energy_cost: 1 }));
      if (API[p]) return route.fulfill(J(API[p]));
      return route.fulfill(J({ detail: "unmocked " + p }, 404));
    }
    for (const [prefix, dir] of Object.entries(MAP)) {
      if (p.startsWith(prefix)) {
        let f = path.join(dir, p.slice(prefix.length)); if (f.endsWith("/")) f += "index.html";
        if (fs.existsSync(f)) return route.fulfill({ status: 200, contentType: mime[path.extname(f)] || "text/plain", body: fs.readFileSync(f) });
      }
    }
    if (u.hostname === "test") return route.fulfill({ status: 404, body: "nf" });
  });
  await page.route(/fonts\.(googleapis|gstatic)\.com/, (r) => r.fulfill({ status: 200, body: "" }));

  await page.addInitScript(() => { localStorage.setItem("ea_token", "x"); });
  await page.goto("http://test/app/");
  await page.waitForSelector(".ea-tabs", { timeout: 8000 });

  const check = async (label, sel) => {
    const ok = await page.locator(sel).first().waitFor({ state: "visible", timeout: 3000 }).then(() => true).catch(() => false);
    console.log((ok ? "OK   " : "FAIL ") + label);
    if (!ok) errors.push("missing: " + label);
  };
  await check("Accueil (hero)", ".ea-hero");
  await check("Accueil shortcuts", ".ea-quick");

  await page.click('.ea-tab[data-tab="economie"]');
  await page.click('[data-sub="travail"]');
  await check("Économie › Travail", "#work-btn");
  await page.click('[data-sub="banque"]');
  await check("Économie › Banque", ".bq-deposit");
  await page.click(".bq-deposit");
  await check("Feuille 'montant' ouverte", ".ea-sheet input");
  await page.fill(".ea-sheet input", "50");
  await page.click(".ea-sheet [data-yes]");
  await page.waitForTimeout(300);
  console.log(posted.some((x) => x.startsWith("/api/bank/deposit") && x.includes('"amount":50')) ? "OK   dépôt envoyé (amount 50)" : "FAIL dépôt non envoyé");
  await page.click('[data-sub="entreprises"]');
  await check("Économie › Entreprises", "#co-create");
  console.log((await page.evaluate(() => window.__xss)) ? "FAIL XSS exécuté" : "OK   nom d'entreprise échappé (pas de XSS)");
  await page.click('[data-sub="immobilier"]');
  await check("Économie › Immobilier", "[data-buy]");

  await page.click('.ea-tab[data-tab="jeux"]');
  await page.click('[data-sub="casino"]');
  await check("Ville › Loisirs", "#slots-spin");
  await page.click('[data-sub="crime"]');
  await check("Ville › Rue & justice", "[data-crime]");

  await page.click('[data-sub="sante"]');
  await check("Ville › Santé (soins)", "#hp-amb");
  await page.click("#hp-amb");
  await page.waitForTimeout(300);
  console.log(posted.some((x) => x.startsWith("/api/sante/ambulance")) ? "OK   ambulance envoyée" : "FAIL ambulance non envoyée");
  await page.click('[data-view="hopitaux"]');
  await check("Santé › Hôpitaux", "[data-goto]");
  console.log((await page.evaluate(() => !!document.querySelector(".ea-card b b"))) ? "FAIL HTML non échappé (directeur)" : "OK   nom du directeur échappé");
  await page.click("[data-goto]");
  await check("Feuille de trajet", ".ea-sheet [data-mode]");
  await page.click('.ea-sheet [data-mode="walk"]');
  await page.waitForTimeout(300);
  console.log(posted.some((x) => x.startsWith("/api/places/travel") && x.includes('"dest":"hopital"')) ? "OK   trajet envoyé" : "FAIL trajet non envoyé");
  await page.click('[data-view="pharmacie"]');
  await check("Santé › Pharmacie", "[data-med]");
  await page.click('[data-view="assurance"]');
  await check("Santé › Assurance", "[data-plan]");

  await page.click('.ea-tab[data-tab="social"]');
  await page.click('[data-sub="fol"]');
  await check("Social › fil", ".ea-post");
  await page.click('[data-sub="more"]');
  await check("Social › Publier", "#pub-send");

  await page.click('.ea-tab[data-tab="plus"]');
  await check("Plus › classement", ".ea-rank-row");
  await check("Plus › déconnexion", "#btn-logout");

  // persistance de la navigation
  await page.reload(); await page.waitForSelector(".ea-tabs");
  console.log((await page.locator('.ea-tab.active[data-tab="plus"]').count()) ? "OK   onglet restauré après rechargement" : "FAIL onglet non restauré");

  await page.click('.ea-tab[data-tab="moi"]');
  await page.waitForSelector(".ea-hero");
  await page.screenshot({ path: "/tmp/home.png" });
  await page.click('.ea-tab[data-tab="economie"]');
  await page.click('[data-sub="travail"]');
  await page.waitForSelector("#work-btn");
  await page.screenshot({ path: "/tmp/eco.png" });

  console.log(errors.length ? "\nERREURS:\n" + errors.join("\n") : "\nAucune erreur JS.");
  await browser.close();
})();
