import sys, types, asyncio, sqlite3, contextlib
sys.path.insert(0, '.')
tg = types.ModuleType('telegram')
class Btn:
    def __init__(s, text, callback_data=None, **k): s.text, s.callback_data = text, callback_data
class Mk:
    def __init__(s, kb): s.inline_keyboard = kb
tg.InlineKeyboardButton, tg.InlineKeyboardMarkup = Btn, Mk
ext = types.ModuleType('telegram.ext')
class Stop(Exception): pass
ext.ApplicationHandlerStop = Stop
sys.modules['telegram'], sys.modules['telegram.ext'] = tg, ext
con = sqlite3.connect(':memory:')
con.execute("CREATE TABLE users(user_id INTEGER PRIMARY KEY, username TEXT, full_name TEXT, registered INT DEFAULT 1)")
con.executemany("INSERT INTO users(user_id,username,full_name) VALUES(?,?,?)", [(111,'alice','Alice A'),(222,'bob_77','Bob'),(333,None,'Sans Pseudo')])
class Cur:
    def __init__(s, r): s.r = r
    async def fetchone(s): return s.r[0] if s.r else None
    async def fetchall(s): return s.r
    async def __aenter__(s): return s
    async def __aexit__(s,*a): pass
class DB:
    def execute(s, q, p=()): return Cur(con.execute(q, p).fetchall())
@contextlib.asynccontextmanager
async def db_connection(*a, **k): yield DB()
dbm = types.ModuleType('database'); dbm.db_connection = db_connection
sys.modules['database'] = dbm
calls = []
fake = types.ModuleType('handlers.companies')
async def cmd_prime(update, context): calls.append(('prime', context.args, update.message.reply_to_message.from_user.id))
async def cmd_creerboite(update, context): calls.append(('creer', context.args, None))
async def cmd_inviter(update, context): calls.append(('inviter', context.args, update.message.reply_to_message.from_user.username))
async def cmd_licencier(update, context): calls.append(('licencier', context.args, update.message.reply_to_message.from_user.id))
async def cmd_dissoudreboite(update, context): calls.append(('dissoudre', context.args, None))
for f in (cmd_prime, cmd_creerboite, cmd_inviter, cmd_licencier, cmd_dissoudreboite): setattr(fake, f.__name__, f)
pkg = types.ModuleType('handlers'); pkg.__path__ = ['handlers']; sys.modules['handlers'] = pkg
sys.modules['handlers.companies'] = fake
from utils import forms, input_flow as f
import handlers.forms_companies  # enregistre les formulaires (utilise config réelle)

class Msg:
    message_id = 5
    def __init__(s, text=None): s.text, s.sent = text, []
    async def reply_text(s, t, **k): s.sent.append(t)
class Ctx:
    def __init__(s): s.user_data = {}; s.bot = None; s.application = None
class Q:
    def __init__(s, data): s.data = data; s.from_user = types.SimpleNamespace(id=111, username='alice', full_name='Alice A', first_name='Alice', last_name=None); s.message = Msg(); s.edits = []; s.markup = None
    async def edit_message_text(s, t, **k): s.edits.append(t); s.markup = k.get('reply_markup')
    async def answer(s, *a, **k): pass
class U:
    def __init__(s, text, q): s.effective_message = Msg(text); s.effective_user = q.from_user; s.callback_query = None

async def say(ctx, q, text):
    u = U(text, q)
    try: await f.flow_message_handler(u, ctx)
    except Stop: pass
    return u

async def main():
    # A) texte + choix : /creerboite
    ctx = Ctx(); q = Q('fm:c_creer'); await forms.start_form(q, ctx, 'c_creer')
    assert 'Nom de ton entreprise' in q.edits[-1]
    u = await say(ctx, q, 'Ma Super Boite')
    assert 'secteur' in u.effective_message.sent[-1].lower()                       # étape secteur = boutons
    kb = u.effective_message.__dict__  # message de réponse : le bouton fp:n existe
    st = ctx.user_data['_form']; assert st['opts'][0] == 'Technologie'
    await forms.pick(Q('fp:0'), ctx, '0')
    assert calls[-1] == ('creer', ['Ma Super Boite', 'Technologie'], None), calls[-1]
    assert '_form' not in ctx.user_data
    # B) joueur « en réponse » + montant : /prime
    ctx = Ctx(); q = Q('fm:c_prime'); await forms.start_form(q, ctx, 'c_prime')
    u = await say(ctx, q, '@bob_77'); u = await say(ctx, q, '2500')
    assert calls[-1] == ('prime', ['2500'], 222), calls[-1]
    # C) joueur par ID sans pseudo + 3 champs : /inviter (reply + salaire + poste)
    ctx = Ctx(); q = Q('x'); await forms.start_form(q, ctx, 'c_inviter')
    await say(ctx, q, '333'); await say(ctx, q, '1500'); await say(ctx, q, 'Chef de projet')
    assert calls[-1] == ('inviter', ['1500', 'Chef de projet'], None), calls[-1]
    # D) validation : saisie invalide ne casse pas, joueur inconnu redemandé
    ctx = Ctx(); q = Q('x'); await forms.start_form(q, ctx, 'c_prime')
    n = len(calls); u = await say(ctx, q, '@fantome'); assert 'introuvable' in u.effective_message.sent[-1] and len(calls) == n
    await say(ctx, q, '@alice'); u = await say(ctx, q, 'abc'); assert 'invalide' in u.effective_message.sent[-1].lower() and len(calls) == n
    await say(ctx, q, '10'); assert calls[-1] == ('prime', ['10'], 111)
    # E) confirmation obligatoire (licencier) : rien n'est exécuté avant ✅
    ctx = Ctx(); q = Q('x'); await forms.start_form(q, ctx, 'c_licencier'); await say(ctx, q, '@bob_77')
    n = len(calls); assert len(calls) == n and ctx.user_data['_form']['i'] == 1
    q2 = Q('fp:ok'); await forms.pick(q2, ctx, 'ok'); assert calls[-1] == ('licencier', [], 222)
    # F) args fixes (dissoudre → ['confirmer']) après confirmation
    ctx = Ctx(); q = Q('x'); await forms.start_form(q, ctx, 'c_dissoudre'); assert not calls[-1][0] == 'dissoudre'
    await forms.pick(Q('x'), ctx, 'ok'); assert calls[-1] == ('dissoudre', ['confirmer'], None)
    # G) annuler efface le formulaire ; état périmé → message propre
    ctx = Ctx(); q = Q('x'); await forms.start_form(q, ctx, 'c_creer')
    cq = Q('flow_cancel'); await f.flow_cancel_callback(types.SimpleNamespace(callback_query=cq), ctx)
    assert '_form' not in ctx.user_data
    q3 = Q('fp:0'); await forms.pick(q3, ctx, '0'); assert 'expir' in q3.edits[-1].lower()
    # H) mot unique (annonce) : refuse les espaces et redemande
    ctx = Ctx(); q = Q('x'); await forms.start_form(q, ctx, 'c_annonce'); u = await say(ctx, q, 'deux mots')
    assert 'un seul mot' in u.effective_message.sent[0].lower() and ctx.user_data['_form']['i'] == 0
    print("✅ moteur de formulaires : 8 scénarios OK")
asyncio.run(main())
