"""Vérifie le hub : couverture de toutes les commandes, taille des pages, callback_data."""
import re, sys, types, asyncio, glob, importlib
sys.path.insert(0, '.')
tg = types.ModuleType('telegram')
class Btn:
    def __init__(s, text, callback_data=None, **k): s.text, s.callback_data = text, callback_data
class Mk:
    def __init__(s, kb): s.inline_keyboard = kb
tg.InlineKeyboardButton, tg.InlineKeyboardMarkup = Btn, Mk
ext = types.ModuleType('telegram.ext')
class Stop(Exception): pass
ext.ApplicationHandlerStop = Stop
sys.modules['telegram'], sys.modules['telegram.ext'] = tg, ext
dbm = types.ModuleType('database'); dbm.db_connection = lambda *a, **k: None
sys.modules['database'] = dbm
# rôle du joueur simulé : le rendu du hub consulte utils.decorators (console staff masquée aux joueurs)
dec = types.ModuleType('utils.decorators')
async def _role(uid): return 'PLAYER'
dec.get_user_role_async = _role
sys.modules['utils.decorators'] = dec
from handlers import hub, hub_data
for f in glob.glob('handlers/forms_*.py'):
    importlib.import_module('handlers.' + f.split('/')[-1][:-3])

errors = []
from utils import auto_forms
from utils.forms import FORMS, build_args
defs = {}
for f in glob.glob('handlers/*.py'):
    t = open(f, encoding='utf-8').read()
    for m in re.finditer(r'^async def cmd_(\w+)\(', t, re.M):
        defs.setdefault(m.group(1), f)
# 1) chaque fonction du hub existe ; 2) tout formulaire généré pointe vers une vraie fonction
for r in hub_data.ITEMS:
    area, fn = r[0], r[1]
    if fn not in defs: errors.append(f"hub : fonction inconnue cmd_{fn}")
    if area not in {a[0] for a in hub_data.AREAS}: errors.append(f"zone inconnue : {area}")
for fn in auto_forms.SPEC:
    if not auto_forms.module_of(fn): errors.append(f"formulaire sans fonction : {fn}")
for key, form in FORMS.items():
    mod, name = form.cmd.split(":")
    if name not in open(mod.replace('.', '/') + '.py', encoding='utf-8').read():
        errors.append(f"formulaire {key} : {form.cmd} introuvable")
# 3) aucune action n'exige encore une commande : chaque entrée du hub est un bouton (formulaire ou lancement)
needs_args = {r[1] for r in hub_data.ITEMS if not r[3]}
RE_FORMS = set(hub._RE_FORMS)
for fn in needs_args:
    if fn not in auto_forms.SPEC and fn not in auto_forms.RUN_ONLY and fn not in RE_FORMS and fn not in FORMS \
            and f"a_{fn}" not in FORMS \
            and not any(f'"a_{fn}"' in open(h, encoding='utf-8').read() for h in glob.glob('handlers/*.py')) and fn not in hub._GARDEN_SCREENS and fn not in hub._ECO_SCREENS and fn not in {
            'mesbiens', 'hypotheque'}:
        errors.append(f"action à arguments sans formulaire : {fn}")
# 4) menu unique : chaque ancien menu thématique redirige vers une zone existante
legacy = ['life','economy','career','invest','companies','market','vehicles','fun','social','mp','society',
          'political','progression','profile','missions']
zones = {a[0] for a in hub_data.AREAS}
for k in legacy:
    if hub.ZONE_OF_MENU.get(k) not in zones: errors.append(f"ancien menu menu_{k} sans zone dans le menu unique")
# rendu de toutes les pages
class Q:
    def __init__(s): s.out = None
    async def edit_message_text(s, text, **k): s.out = (text, k['reply_markup'])
async def render():
    n = 0
    def check(tag, q):
        nonlocal n
        text, mk = q.out; n += 1
        if len(text) > 4000: errors.append(f"{tag}: texte trop long ({len(text)})")
        btns = [b for row in mk.inline_keyboard for b in row]
        if len(btns) > 40: errors.append(f"{tag}: {len(btns)} boutons")
        if not any(b.callback_data in ("hub:home",) or b.callback_data.startswith("hub:") for b in btns):
            errors.append(f"{tag}: aucun bouton de retour")
        if "boutons" in text.lower(): errors.append(f"{tag}: le mot « boutons » apparaît dans le texte")
        for b in btns:
            if len(b.callback_data.encode()) > 64: errors.append(f"callback trop long : {b.callback_data}")
    for key, label, menu in hub_data.AREAS:
        q = Q(); await hub.show_zone(q, key); check(f"{key} (zone)", q)
        for si, title, entries in await hub._visible(key, 0):
            for p in range(max(1, -(-len(entries) // hub.PAGE))):
                q = Q(); await hub.show_rubrique(q, key, si, p); check(f"{key}/{title} p{p}", q)
    q = Q(); await hub.show_home(q)
    for row in q.out[1].inline_keyboard:
        for b in row:
            if len(b.callback_data.encode()) > 64: errors.append(f"callback trop long : {b.callback_data}")
    return n
pages = asyncio.run(render())
print(f"{len(hub_data.ITEMS)} actions, {len(hub_data.AREAS)} zones, {pages} pages rendues (zones + rubriques)")
print("\n".join("❌ " + e for e in errors) or "✅ hub complet : toute action est atteignable depuis le menu")
sys.exit(1 if errors else 0)
