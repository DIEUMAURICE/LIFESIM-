"""webapp/server.py — Serveur unique : API JSON (mini app + web) + fichiers statiques des 2 front-ends.

Lancement (déjà couvert par webapp/earthangel-webapp.service, voir DEPLOIEMENT_WEBAPP.md) :

    uvicorn webapp.server:app --host 0.0.0.0 --port 8000

Un seul processus Python en plus du bot (`bot.py`). Il ouvre SA PROPRE connexion à la même
base SQLite (life_sim.db, mode WAL — lecture/écriture concurrente sûre entre les 2 process).

Routes :
  /api/...        → API JSON utilisée par les deux front-ends (voir webapp/routers/)
  /tg/            → mini app Telegram (statique)
  /app/           → application web (statique, connexion Google)
  /shared/        → JS/CSS communs aux deux front-ends
"""
from __future__ import annotations

import logging
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse, JSONResponse

import database
from config import WEBAPP_CORS_ORIGINS
from migrations import run_migrations as run_extra_migrations
from webapp.routers import (
    auth_router, character_router, profile_router, bank_router, work_router, rankings_router,
    admin_router, casino_router, crime_router, companies_router, realestate_router, reseau_router,
    places_router, sante_router, missions_router, life_router, market_router, boutique_router,
    chain_router, notifications_router, phone_router, vehicles_router, travel_router, family_router, gang_router, garden_router, referral_router,
    arena_router, hub_router, education_router, political_router, reports_router,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("webapp")

STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(title="Earth Angel RP — API Mini App & Web")

app.add_middleware(
    CORSMiddleware,
    allow_origins=WEBAPP_CORS_ORIGINS,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def no_stale_static(request, call_next):
    # Les fichiers du front changent souvent. `no-cache` seul autorise encore certains
    # WebViews (notamment Telegram) à servir une copie locale sans revalider. `no-store`
    # empêche la conservation de l'HTML et des scripts : les joueurs récupèrent toujours
    # la version active sans devoir vider manuellement leur cache.
    resp = await call_next(request)
    if request.url.path.startswith(("/shared/", "/tg", "/app")):
        resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0, s-maxage=0"
        resp.headers["Pragma"] = "no-cache"
        resp.headers["Expires"] = "0"
    return resp


@app.on_event("startup")
async def on_startup():
    # Idempotent (CREATE TABLE IF NOT EXISTS) : sûr même si bot.py a déjà initialisé la base,
    # et nécessaire si ce process démarre avant le bot (ex: redéploiement de l'API seule).
    await database.init_db()
    # Le bot exécute aussi ces deux étapes. L'API doit les exécuter seule lorsqu'elle
    # démarre avant le polling Telegram (ou lorsqu'elle est déployée séparément),
    # sinon des tables ajoutées par migrations.py, notamment `characters`, manquent
    # et le premier GET /api/profile termine en 500.
    await database.run_migrations()
    await run_extra_migrations()
    logger.info("webapp: base de données prête (%s)", database.DB_PATH)


for r in (auth_router, character_router, profile_router, bank_router, work_router, rankings_router,
          admin_router, casino_router, companies_router, realestate_router, reseau_router,
          places_router, sante_router, missions_router, life_router, market_router, boutique_router,
          chain_router, notifications_router, phone_router, vehicles_router, travel_router, family_router, gang_router, garden_router, referral_router,
          arena_router, hub_router, education_router, political_router, reports_router):
    app.include_router(r.router)
app.include_router(crime_router.router)
app.include_router(crime_router.justice_router)


@app.get("/api/health")
async def health():
    return {"status": "ok"}


@app.get("/api/build-info", include_in_schema=False)
async def build_info():
    """Permet de vérifier depuis Hostrix que la bonne archive est bien active."""
    return {
        "build": "parity-v12-hostrix-fix-2026-11-09",
        "frontend_version": "9",
        "modules": ["family", "gangs", "garden"],
    }


@app.get("/")
async def root():
    return RedirectResponse("/app/")


@app.get("/manus-routes.json", include_in_schema=False)
async def manus_routes():
    """Déclare les pages publiques servies par les deux parcours clients.

    La route est servie directement par FastAPI afin d'éviter le fallback HTML
    des montages statiques et de rester valide chez l'hébergeur.
    """
    return JSONResponse({
        "routes": [
            {"path": "/", "title": "Earth Angel RP"},
            {"path": "/app/", "title": "Earth Angel RP — Application Web"},
            {"path": "/tg/", "title": "Earth Angel RP — Mini App Telegram"},
        ]
    })


app.mount("/shared", StaticFiles(directory=STATIC_DIR / "shared"), name="shared")
app.mount("/tg", StaticFiles(directory=STATIC_DIR / "telegram", html=True), name="telegram-miniapp")
app.mount("/app", StaticFiles(directory=STATIC_DIR / "web", html=True), name="web-app")


if __name__ == "__main__":
    # Permet de lancer directement "python3 webapp/server.py" (ou "python3 -m webapp.server")
    # sans avoir à connaître à l'avance le port : WEBAPP_LISTEN/WEBAPP_PORT (config.py) lisent
    # déjà la variable PORT fournie par l'hébergeur (Hostrix, Render, etc.) si elle existe.
    import uvicorn
    from config import WEBAPP_LISTEN, WEBAPP_PORT
    uvicorn.run(app, host=WEBAPP_LISTEN, port=WEBAPP_PORT)
