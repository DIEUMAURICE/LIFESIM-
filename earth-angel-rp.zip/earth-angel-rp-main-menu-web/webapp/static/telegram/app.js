// webapp/static/telegram/app.js — bootstrap spécifique à la mini app Telegram.
// Authentifie via Telegram.WebApp.initData (voir https://core.telegram.org/bots/webapps)
// puis délègue tout le reste (écrans, données de jeu) au module partagé EA (shared/core.js + shared/screens/*.js).

(async () => {
  EA.PLATFORM = "telegram";   // lu par certains écrans partagés (ex. boutique.js) pour les Étoiles
  const root = document.getElementById("app");
  const tg = window.Telegram && window.Telegram.WebApp;

  if (!tg) {
    root.innerHTML = `<div class="ea-card ea-center"><p>⚠️ Ouvre cette page depuis le bot Telegram
      (bouton Mini App), pas directement dans un navigateur.</p></div>`;
    return;
  }

  tg.ready();
  tg.expand();
  try { tg.setHeaderColor && tg.setHeaderColor("#0b0e15"); } catch (e) {}
  try { tg.setBackgroundColor && tg.setBackgroundColor("#0b0e15"); } catch (e) {}

  EA.setLoggedOutRenderer(async () => {
    try {
      const data = await EA.api("/auth/telegram", {
        method: "POST",
        body: JSON.stringify({ init_data: tg.initData }),
      });
      EA.setToken(data.token);
      EA.boot(root);
    } catch (e) {
      root.innerHTML = `<div class="ea-card ea-center">
        <p>❌ Connexion impossible : ${e.message || "erreur inconnue"}</p>
      </div>`;
    }
  });

  try {
    await EA.loadScreens();
  } catch (e) {
    root.innerHTML = `<div class="ea-card ea-center"><p>❌ Chargement impossible : ${e.message}</p></div>`;
    return;
  }
  EA.boot(root);
})();
