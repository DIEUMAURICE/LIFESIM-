// webapp/static/shared/core.js
// Noyau commun à la mini app Telegram et à l'application web.
//
// Rôle : session, appels API, navigation (onglets + sous-onglets), enveloppe de l'écran
// (en-tête + barre du bas), helpers d'UI (toast, feuilles, confirmations).
// Les écrans de jeu vivent chacun dans leur fichier : shared/screens/<nom>.js.
//
// ── Ajouter un module de jeu ────────────────────────────────────────────────
//  1. Créer shared/screens/<nom>.js qui appelle EA.sub({...}) (voir plus bas).
//  2. Ajouter "<nom>" dans la liste SCREENS ci-dessous. C'est tout : les deux
//     front-ends (Telegram + web) le chargent automatiquement.

const EA = (() => {
  const VERSION = "30";
  const TOKEN_KEY = "ea_token";
  const NAV_KEY = "ea_nav_v2";
  const SOUND_KEY = "ea_ui_sound";

  // Ordre de chargement des écrans (shared/screens/<nom>.js).
  const SCREENS = [
    "menu", "character", "places", "home", "work", "missions", "market", "boutique", "chain", "bank", "companies", "realestate", "vehicles", "travel",
    "life", "sante", "casino", "crime", "arena", "social", "family", "gangs", "garden", "referral", "education", "political", "reports", "admin", "more",
  ];

  const S = {
    root: null,
    staffInfo: null,        // null = pas encore vérifié, false = joueur normal, objet = staff
    renderId: 0,
    tab: "menu",
    sub: {},                // sous-onglet actif par onglet
  };
  const tabs = {};
  const subs = {};          // subs[tabId] = [ {id, label, icon, order, render, bind} ]
  const plusBlocks = [];
  let soundOn = localStorage.getItem(SOUND_KEY) === "on";
  let audioContext = null;

  // ───────────────────────── session ─────────────────────────
  function getToken() { return localStorage.getItem(TOKEN_KEY) || ""; }
  function setToken(t) { localStorage.setItem(TOKEN_KEY, t); }
  function clearToken() { localStorage.removeItem(TOKEN_KEY); }
  function logout() { clearToken(); sessionStorage.removeItem(NAV_KEY); location.reload(); }

  async function api(path, opts = {}) {
    const headers = Object.assign({ "Content-Type": "application/json" }, opts.headers || {});
    const token = getToken();
    if (token) headers["Authorization"] = "Bearer " + token;
    const res = await fetch("/api" + path, Object.assign({}, opts, { headers }));
    if (res.status === 401) {
      clearToken();
      renderLoggedOut();
      throw new Error("unauthenticated");
    }
    let data = null;
    try { data = await res.json(); } catch (e) { /* pas de corps */ }
    if (!res.ok) {
      const err = new Error((data && data.detail) || ("Erreur " + res.status));
      err.status = res.status;
      err.detail = data && data.detail;
      throw err;
    }
    return data;
  }
  // POST JSON (sans corps si body est undefined).
  function post(path, body) {
    return api(path, { method: "POST", body: body === undefined ? undefined : JSON.stringify(body) });
  }

  let loggedOutRenderer = () => {
    S.root.innerHTML = `<div class="ea-card ea-center"><p class="ea-muted">Session expirée.</p>
      <button class="ea-btn" onclick="location.reload()">Recharger</button></div>`;
  };
  function renderLoggedOut() { loggedOutRenderer(); }
  function setLoggedOutRenderer(fn) { loggedOutRenderer = fn; }

  // ───────────────────────── helpers ─────────────────────────
  function toast(msg, kind = "") {
    const el = document.createElement("div");
    el.className = "ea-toast" + (kind ? " " + kind : "");
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2600);
  }
  function fmt(n) { return (n ?? 0).toLocaleString("fr-FR"); }
  function fmtMin(sec) { return Math.ceil(sec / 60) + " min"; }
  function esc(t) {
    return String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  function ago(ts) {
    const d = Math.max(0, Math.floor(Date.now() / 1000) - ts);
    if (d < 60) return "à l'instant";
    if (d < 3600) return Math.floor(d / 60) + " min";
    if (d < 86400) return Math.floor(d / 3600) + " h";
    return Math.floor(d / 86400) + " j";
  }

  function playUiSound(kind = "tap") {
    if (!soundOn) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      audioContext = audioContext || new AudioCtx();
      if (audioContext.state === "suspended") audioContext.resume();
      const now = audioContext.currentTime;
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      const base = kind === "open" ? 590 : kind === "toggle" ? 740 : 460;
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(base, now);
      oscillator.frequency.exponentialRampToValueAtTime(base * 1.22, now + .065);
      gain.gain.setValueAtTime(.0001, now);
      gain.gain.exponentialRampToValueAtTime(.022, now + .012);
      gain.gain.exponentialRampToValueAtTime(.0001, now + .11);
      oscillator.connect(gain); gain.connect(audioContext.destination);
      oscillator.start(now); oscillator.stop(now + .115);
    } catch (e) { /* Web Audio indisponible : l'interface reste utilisable. */ }
  }

  function toggleSound() {
    soundOn = !soundOn;
    localStorage.setItem(SOUND_KEY, soundOn ? "on" : "off");
    const button = document.getElementById("hdr-sound");
    if (button) {
      button.classList.toggle("on", soundOn);
      button.title = soundOn ? "Sons activés" : "Sons désactivés";
      button.setAttribute("aria-label", soundOn ? "Désactiver les sons" : "Activer les sons");
      button.innerHTML = ico(soundOn ? "volume" : "volume-off");
    }
    if (soundOn) playUiSound("toggle");
    toast(soundOn ? "Sons activés" : "Sons désactivés");
  }

  const ICONS = {
    home: "M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10",
    city: "M4 21V7l7-3v17M11 21V10l9 3v8M2 21h20M7 10v.01M7 14v.01M7 18v.01M15 15v.01M15 18v.01",
    wallet: "M3 7h15a3 3 0 013 3v8a2 2 0 01-2 2H5a2 2 0 01-2-2V7zM3 7l12-3v3M17 14h.01",
    users: "M9 11a3 3 0 100-6 3 3 0 000 6zM3 20c0-3.3 2.7-6 6-6s6 2.7 6 6M17 11a2.5 2.5 0 100-5M21 20c0-2.6-1.6-4.6-4-5.4",
    grid: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z",
    bell: "M6 16v-5a6 6 0 1112 0v5l2 2H4l2-2zM10 21h4",
    heart: "M12 20s-7-4.5-7-10a4 4 0 017-2.5A4 4 0 0119 10c0 5.5-7 10-7 10z",
    bolt: "M13 3L5 14h6l-1 7 8-11h-6l1-7z",
    smile: "M12 21a9 9 0 100-18 9 9 0 000 18zM8.5 14a4.5 4.5 0 007 0M9 9.5v.01M15 9.5v.01",
    food: "M6 3v8a2 2 0 002 2v8M10 3v8M8 3v6M17 3c-2 1.5-3 4-3 7h3v11",
    briefcase: "M4 8h16v11H4zM9 8V6a2 2 0 012-2h2a2 2 0 012 2v2M4 13h16",
    gift: "M4 11h16v9H4zM3 8h18v3H3zM12 8v12",
    bank: "M3 10l9-6 9 6M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18",
    dice: "M5 3h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2zM8 8v.01M16 8v.01M12 12v.01M8 16v.01M16 16v.01",
    shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z",
    trophy: "M8 4h8v5a4 4 0 01-8 0V4zM8 6H4v2a3 3 0 003 3M16 6h4v2a3 3 0 01-3 3M12 13v4M8 20h8",
    phone: "M8 3h8a1 1 0 011 1v16a1 1 0 01-1 1H8a1 1 0 01-1-1V4a1 1 0 011-1zM11 18h2",
    flag: "M5 21V4M5 4h11l-2 4 2 4H5",
    coin: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v10M9.5 9.5c0-1 1-1.5 2.5-1.5s2.5.5 2.5 1.5-1 1.4-2.5 1.8-2.5.8-2.5 1.8 1 1.5 2.5 1.5 2.5-.5 2.5-1.5",
    spark: "M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z",
    "trending-up": "M3 17l6-6 4 4 8-9M16 6h5v5",
    volume: "M3 10v4h4l5 4V6l-5 4H3zM16 9a4 4 0 010 6M18 6a8 8 0 010 12",
    "volume-off": "M3 10v4h4l5 4V6l-5 4H3zM3 3l18 18",
  };
  function ico(name, cls = "") {
    return `<svg class="ea-ico ${cls}" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICONS[name] || ICONS.spark}"/></svg>`;
  }
  // Zone du monde qui existe sur le bot mais pas encore dans l'application.
  function botRow(icon, title, desc) {
    return `<div class="ea-list-row locked">
      <div class="ic">${ico(icon)}</div>
      <div><div class="t">${title}</div><div class="d">${desc}</div></div>
      <span class="end ea-tag">Sur le bot</span>
    </div>`;
  }

  // ── actions de bouton : anti double-clic + erreurs affichées en toast ──
  function act(el, fn) {
    el.onclick = async (ev) => {
      if (el.dataset.busy) return;
      el.dataset.busy = "1";
      el.classList.add("busy");
      try { await fn(ev); }
      catch (e) { if (e.message !== "unauthenticated") toast(e.message, "error"); }
      finally { delete el.dataset.busy; el.classList.remove("busy"); }
    };
  }
  // Branche fn(el) sur tous les éléments qui correspondent au sélecteur.
  function onAll(selector, fn, scope = document) {
    scope.querySelectorAll(selector).forEach((el) => act(el, () => fn(el)));
  }

  // ── feuille modale en bas d'écran, confirmations et saisies ──
  function sheet(html) {
    const ov = document.createElement("div");
    ov.className = "ea-sheet-ov";
    ov.innerHTML = `<div class="ea-sheet">${html}</div>`;
    const close = () => ov.remove();
    ov.addEventListener("click", (e) => { if (e.target === ov) close(); });
    document.body.appendChild(ov);
    return { el: ov.firstElementChild, close };
  }
  function confirmSheet(message, { ok = "Confirmer", danger = false } = {}) {
    return new Promise((resolve) => {
      const s = sheet(`<p class="ea-sheet-msg">${esc(message)}</p>
        <div class="ea-grid">
          <button class="ea-btn secondary" data-no>Annuler</button>
          <button class="ea-btn ${danger ? "danger" : ""}" data-yes>${esc(ok)}</button>
        </div>`);
      const done = (v) => { s.close(); resolve(v); };
      s.el.querySelector("[data-no]").onclick = () => done(false);
      s.el.querySelector("[data-yes]").onclick = () => done(true);
    });
  }
  function promptInt(title, { placeholder = "Montant", ok = "Valider" } = {}) {
    return new Promise((resolve) => {
      const s = sheet(`<p class="ea-sheet-msg">${esc(title)}</p>
        <input class="ea-input" type="number" inputmode="numeric" min="1" placeholder="${esc(placeholder)}" />
        <div class="ea-grid" style="margin-top:10px">
          <button class="ea-btn secondary" data-no>Annuler</button>
          <button class="ea-btn" data-yes>${esc(ok)}</button>
        </div>`);
      const input = s.el.querySelector("input");
      const done = (v) => { s.close(); resolve(v); };
      s.el.querySelector("[data-no]").onclick = () => done(null);
      s.el.querySelector("[data-yes]").onclick = () => {
        const n = parseInt(input.value, 10);
        done(n > 0 ? n : null);
      };
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") s.el.querySelector("[data-yes]").click(); });
      setTimeout(() => input.focus(), 50);
    });
  }

  // ───────────────────────── registre d'écrans ─────────────────────────
  // Onglet de la barre du bas. Soit il a des sous-onglets (EA.sub), soit il a son propre render.
  //   EA.tab({ id, icon, label, order, title?, subtitle?, render?(ctx), bind?(ctx) })
  function tab(def) { tabs[def.id] = Object.assign({ order: 50 }, def); }

  // Sous-onglet d'un onglet. render(ctx) renvoie du HTML (ou une promesse) ; bind(ctx) branche les boutons.
  //   ctx = { profile, user }
  function sub(def) {
    (subs[def.tab] = subs[def.tab] || []).push(Object.assign({ order: 50 }, def));
  }

  // Bloc de l'onglet « Plus » (classement, admin, compte...).
  function plusBlock(def) { plusBlocks.push(Object.assign({ order: 50 }, def)); }

  const screens = {};   // screens.wizard : assistant de création du personnage

  // ───────────────────────── navigation ─────────────────────────
  function saveNav() {
    try { sessionStorage.setItem(NAV_KEY, JSON.stringify({ tab: S.tab, sub: S.sub })); } catch (e) { /* ignore */ }
  }
  function loadNav() {
    try {
      const n = JSON.parse(sessionStorage.getItem(NAV_KEY) || "null");
      if (n && tabs[n.tab]) { S.tab = n.tab; S.sub = n.sub || {}; }
    } catch (e) { /* ignore */ }
  }
  // Aller à un onglet (et sous-onglet) puis réafficher.
  function go(tabId, subId) {
    if (!tabs[tabId]) return;
    S.tab = tabId;
    if (subId) S.sub[tabId] = subId;
    else delete S.sub[tabId];
    saveNav();
    return refresh();
  }

  function sortedTabs() { return Object.values(tabs).sort((a, b) => a.order - b.order); }
  function sortedSubs(tabId) { return (subs[tabId] || []).slice().sort((a, b) => a.order - b.order); }

  function headerHtml() {
    return `
      <aside class="ea-desktop-side">
        <div class="ea-side-caption">Ton monde</div>
        <nav class="ea-side-nav" aria-label="Navigation principale">
          ${sortedTabs().map((t) => `<button class="ea-side-tab ${S.tab === t.id ? "active" : ""}" data-tab="${t.id}">${ico(t.icon)}<span>${t.label}</span></button>`).join("")}
        </nav>
        <div class="ea-side-foot">Même monde · mêmes règles<br><span>Web + Telegram</span></div>
      </aside>
      <div class="ea-appheader">
        <div class="ea-brand">
          <span class="ea-brand-mark"><img src="/shared/icon.png" alt="" /></span>
          <div class="name">Earth Angel<small>RP</small></div>
        </div>
        <button class="ea-icon-btn ea-sound-btn ${soundOn ? "on" : ""}" id="hdr-sound" aria-label="${soundOn ? "Désactiver les sons" : "Activer les sons"}" title="${soundOn ? "Sons activés" : "Sons désactivés"}">${ico(soundOn ? "volume" : "volume-off")}</button>
        <div class="ea-icon-btn" id="hdr-bell">${ico("bell")}</div>
      </div>`;
  }
  function tabsHtml() {
    return `<div class="ea-tabs">` + sortedTabs().map((t) =>
      `<div class="ea-tab ${S.tab === t.id ? "active" : ""}" data-tab="${t.id}">
        ${ico(t.icon)}<span>${t.label}</span>
      </div>`).join("") + `</div>`;
  }
  function errorCard(e) {
    return `<div class="ea-card ea-center">
      <p class="ea-sub">${esc(e.message || "Erreur inconnue")}</p>
      <button class="ea-btn secondary" data-retry style="margin-top:8px">Réessayer</button>
    </div>`;
  }

  const HUB_COPY = {
    economie: { travail: ["Travail & carrière", "Travaille, forme-toi et prépare tes prochaines étapes."], banque: ["Banque & argent", "Solde, épargne, transferts et opérations financières."], missions: ["Missions & progression", "Objectifs, récompenses, XP et succès en cours."], boutique: ["Boutique", "Objets, achats et services disponibles."] },
    jeux: { vie: ["Vie & santé", "Besoins, routine, logement et état du personnage."], voyages: ["Déplacements", "Choisis une destination et un moyen de transport."], casino: ["Loisirs & casino", "Activités de détente, jeux et récompenses."], crime: ["Crime & justice", "Choix à risque, restrictions et conséquences."], arena: ["Arène", "Défis PvP, mises et combats résolus par les mêmes règles."] },
    social: { fol: ["Mon fil", "Publications, abonnements et actualités de la communauté."], exp: ["Explorer", "Découvre les joueurs, contenus et tendances du monde."], more: ["Publier", "Partage un message avec les autres habitants."], creator: ["Stories & lives", "Crée, regarde et rejoins les contenus en direct."], polls: ["Sondages", "Pose une question à la communauté et partage ton avis."], collabs: ["Collaborations", "Propose, accepte ou suis une collaboration de créateurs."] },
  };

  function hubCard(tabId, item) {
    const copy = (HUB_COPY[tabId] || {})[item.id] || [item.label, "Ouvre ce module pour consulter ses informations et ses actions."];
    return `<button class="ea-hub-card" data-sub="${item.id}"><span class="hub-icon">${ico(item.icon)}</span><span><b>${esc(copy[0])}</b><small>${esc(copy[1])}</small></span><i>›</i></button>`;
  }

  function hubView(t, list) {
    return { html: `<div class="ea-page-title">${esc(t.title || t.label)}</div><div class="ea-page-sub">${esc(t.subtitle || "Choisis un module pour continuer.")}</div><div class="ea-hub-intro">Chaque rubrique s’ouvre dans son propre écran. Les coûts, cooldowns et résultats restent gérés par le serveur.</div><div class="ea-hub-grid">${list.map((s) => hubCard(t.id, s)).join("")}</div>`, bind: () => document.querySelectorAll("[data-sub]").forEach((b) => b.onclick = () => go(t.id, b.dataset.sub)) };
  }

  // Construit le contenu de l'onglet courant : { html, bind }.
  async function renderTab(t, ctx) {
    if (t.render) {
      return { html: await t.render(ctx), bind: () => t.bind && t.bind(ctx) };
    }
    const list = sortedSubs(t.id);
    if (!list.length) return { html: `<div class="ea-card ea-center"><p class="ea-muted">Bientôt disponible.</p></div>`, bind: null };
    if (t.hub && !S.sub[t.id]) return hubView(t, list);
    const cur = list.find((s) => s.id === S.sub[t.id]) || list[0];
    const head = `<div class="ea-detail-head"><button class="ea-back" data-hub="${t.id}" aria-label="Retour à ${esc(t.label)}">‹</button><div><div class="ea-page-title">${t.title || t.label}</div>
      ${t.subtitle ? `<div class="ea-page-sub">${t.subtitle}</div>` : ""}
      </div></div><div class="ea-seg">` + list.map((s) =>
        `<button class="${s.id === cur.id ? "on" : ""}" data-sub="${s.id}">${ico(s.icon, "sm")}${s.label}</button>`).join("") + `</div>`;
    let body;
    try { body = await cur.render(ctx); }
    catch (e) {
      if (e.message === "unauthenticated") throw e;
      console.error(e);
      body = errorCard(e);
    }
    return {
      html: head + body,
      bind: () => {
        document.querySelectorAll("[data-hub]").forEach((b) => b.onclick = () => go(b.dataset.hub));
        document.querySelectorAll("[data-sub]").forEach((b) => b.onclick = () => go(t.id, b.dataset.sub));
        if (cur.bind) cur.bind(ctx);
      },
    };
  }

  function refresh() { return renderHub(); }

  async function renderHub() {
    const my = ++S.renderId;
    let profile;
    try {
      profile = await api("/profile");
    } catch (e) {
      if (e.detail === "character_incomplete") return screens.wizard();
      if (e.message !== "unauthenticated") toast(e.message, "error");
      return;
    }
    if (my !== S.renderId) return;       // un rendu plus récent a pris la main
    if (!profile.character_complete) return screens.wizard();

    // Vérification discrète du statut staff (403 silencieux pour un joueur normal).
    if (S.staffInfo === null) {
      try { S.staffInfo = await api("/admin/whoami"); }
      catch (e) { S.staffInfo = false; }
    }
    if (my !== S.renderId) return;

    const ctx = { profile, user: profile.user };
    const t = tabs[S.tab] || tabs.moi;
    let page;
    try { page = await renderTab(t, ctx); }
    catch (e) {
      if (e.message === "unauthenticated") return;
      console.error(e);
      page = { html: errorCard(e), bind: null };
    }
    if (my !== S.renderId) return;

    S.root.innerHTML = headerHtml() + page.html + tabsHtml();
    const activeMobileTab = document.querySelector(".ea-tabs .ea-tab.active");
    if (activeMobileTab && window.innerWidth < 600) activeMobileTab.scrollIntoView({ block: "nearest", inline: "nearest" });
    const bell = document.getElementById("hdr-bell");
    if (bell) act(bell, async () => {
      // Consulter les notifications en attente les marque comme délivrées pour éviter
      // un doublon entre la Mini App et le bot Telegram (contrat de l'API).
      const pending = await api("/notifications/pending");
      const history = await api("/notifications/history");
      const items = history.notifications || [];
      const rows = items.length ? items.map((n) => `
        <article class="ea-notification">
          <div class="ea-title">${esc(n.emoji || "📌")} ${esc(n.title || "Notification")}</div>
          <p class="ea-sub">${esc(n.message || "")}</p>
          <small class="ea-muted">${n.created_at ? ago(n.created_at) : ""}</small>
        </article>`).join("") : `<p class="ea-muted">Aucune notification pour le moment.</p>`;
      const fresh = (pending.notifications || []).length;
      const modal = sheet(`<div class="ea-title">Notifications${fresh ? ` · ${fresh} nouvelle${fresh > 1 ? "s" : ""}` : ""}</div>
        <div class="ea-notification-list">${rows}</div>
        <button class="ea-btn secondary" data-close style="margin-top:12px;width:100%">Fermer</button>`);
      modal.el.querySelector("[data-close]").onclick = modal.close;
    });
    const soundButton = document.getElementById("hdr-sound");
    if (soundButton) soundButton.onclick = () => toggleSound();
    document.querySelectorAll(".ea-tab, .ea-side-tab").forEach((el) => el.onclick = () => { playUiSound("tap"); go(el.dataset.tab); });
    document.querySelectorAll("[data-go]").forEach((el) => el.onclick = () => {
      const [tabId, subId] = el.dataset.go.split(":");
      go(tabId, subId);
    });
    document.querySelectorAll("[data-retry]").forEach((el) => el.onclick = () => refresh());
    try { if (page.bind) page.bind(); } catch (e) { console.error(e); }
  }

  // ───────────────────────── onglets principaux (les sous-onglets viennent des écrans) ─────────────────────────
  tab({ id: "economie", icon: "wallet", label: "Économie", order: 20, hub: true, title: "Économie", subtitle: "Gagne ta vie, fais fructifier ton argent." });
  tab({ id: "jeux", icon: "city", label: "Ville", order: 30, hub: true, title: "Ville", subtitle: "Les lieux où tout se joue — au grand jour ou dans l'ombre." });
  tab({ id: "social", icon: "users", label: "Social", order: 40, hub: true, title: "Social", subtitle: "Ta place parmi les autres : lus, likés, suivis pour de vrai." });
  tab({ id: "profil", icon: "users", label: "Profil", order: 80, title: "Profil & infos", subtitle: "Ton personnage, tes réussites et les informations de ton compte." });

  // ───────────────────────── onglet « Plus » (blocs extensibles) ─────────────────────────
  tab({
    id: "plus", icon: "grid", label: "Plus", order: 90,
    async render(ctx) {
      const blocks = plusBlocks.slice().sort((a, b) => a.order - b.order);
      const html = await Promise.all(blocks.map(async (b) => {
        try { return (await b.render(ctx)) || ""; }
        catch (e) { console.error(e); return ""; }
      }));
      return html.join("");
    },
    bind(ctx) { plusBlocks.forEach((b) => b.bind && b.bind(ctx)); },
  });

  // ───────────────────────── chargement des écrans + démarrage ─────────────────────────
  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = src;
      s.onload = resolve;
      s.onerror = () => reject(new Error("Chargement impossible : " + src));
      document.head.appendChild(s);
    });
  }
  // Charge tous les écrans dans l'ordre (le noyau doit être prêt avant, voir app.js).
  async function loadScreens() {
    for (const name of SCREENS) await loadScript(`/shared/screens/${name}.js?v=${VERSION}`);
  }

  async function boot(rootEl) {
    S.root = rootEl;
    if (!getToken()) return renderLoggedOut();
    loadNav();
    try { await renderHub(); }
    catch (e) { console.error(e); }
  }

    return {
    // session / réseau
    api, post, getToken, setToken, clearToken, logout, setLoggedOutRenderer,
    // UI
    toast, fmt, fmtMin, esc, ago, ico, botRow, act, onAll, sheet, confirm: confirmSheet, promptInt,
    // registre + navigation
    tab, sub, plusBlock, screens, go, refresh,
    // état
    root: () => S.root,
    staff: () => S.staffInfo || null,
    // démarrage
    loadScreens, boot, renderHub, renderCharacterWizard: () => screens.wizard(),
  };
})();
