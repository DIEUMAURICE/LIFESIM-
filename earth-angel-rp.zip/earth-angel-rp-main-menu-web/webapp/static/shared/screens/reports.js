// screens/reports.js — Profil › Signalements : bugs, idées, exploits, joueurs signalés, suivi, traitement staff.
// Mêmes règles que le bot (gameplay/reports.py) : cooldown, longueur minimale et anti-spam sont côté serveur.
(() => {
  const STAFF_STATUS = [["in_progress", "🔨 En cours"], ["resolved", "✅ Résolu"], ["rejected", "❌ Rejeter"]];

  function myRow(r) {
    return `<div style="padding:10px 0;border-bottom:1px solid var(--line)">
      <div><b>${r.type_emoji} ${EA.esc(r.type_name)}</b> ${r.status_emoji}${r.target_id ? ` · joueur ${r.target_id}` : ""}</div>
      <div class="ea-sub">${EA.esc(r.message.slice(0, 160))}${r.message.length > 160 ? "…" : ""}</div>
      ${r.admin_response ? `<div class="ea-sub">💬 ${EA.esc(r.admin_response)}</div>` : ""}</div>`;
  }

  function staffRow(r) {
    return `<div style="padding:10px 0;border-bottom:1px solid var(--line)">
      <div><b>#${r.id}</b> ${r.type_emoji} ${EA.esc(r.type_name)} — ${EA.esc(r.reporter_name || "")}${r.target_id ? ` · cible ${r.target_id}` : ""}</div>
      <div class="ea-sub">${EA.esc(r.message.slice(0, 300))}</div>
      <div class="ea-grid" style="margin-top:6px">${STAFF_STATUS.map(([s, l]) => `<button class="ea-btn secondary" data-handle="${r.id}:${s}">${l}</button>`).join("")}</div></div>`;
  }

  async function render() {
    const o = await EA.api("/reports");
    const types = o.types.map((t) => `<button class="ea-btn secondary" data-new="${t.code}">${t.emoji} ${EA.esc(t.name)}</button>`).join("");
    let staff = "";
    if (o.is_staff) {
      const s = await EA.api("/reports/staff?status=pending");
      staff = `<div class="ea-section-title">À traiter (staff) — ${s.stats.pending} en attente</div>`
        + (s.reports.length ? s.reports.map(staffRow).join("") : `<p class="ea-sub">Aucun signalement en attente.</p>`);
    }
    return `<div class="ea-card"><div class="ea-title">🚨 Signalements & support</div>
      <p class="ea-sub">${o.mine.length} envoyé(s) · ${o.open_count} en cours de traitement</p>
      <div class="ea-grid" style="margin-top:8px">${types}</div>
      <button class="ea-btn" id="rep-player" style="margin-top:8px">🎯 Signaler un joueur</button></div>
      <div class="ea-section-title">Mes signalements</div>
      ${o.mine.length ? o.mine.map(myRow).join("") : `<p class="ea-sub">Aucun signalement envoyé.</p>`}${staff}`;
  }

  function composer(title, withTarget, send) {
    const s = EA.sheet(`<p class="ea-sheet-msg">${title}</p>`
      + (withTarget ? `<input class="ea-input" id="rep-target" type="number" inputmode="numeric" placeholder="ID du joueur signalé" style="margin-bottom:8px" />` : "")
      + `<textarea class="ea-input" id="rep-msg" rows="4" maxlength="1000" placeholder="Décris le problème (5 caractères minimum)"></textarea>
        <div class="ea-grid" style="margin-top:10px"><button class="ea-btn secondary" data-no>Annuler</button><button class="ea-btn" data-yes>Envoyer</button></div>`);
    s.el.querySelector("[data-no]").onclick = s.close;
    s.el.querySelector("[data-yes]").onclick = async () => {
      const message = s.el.querySelector("#rep-msg").value;
      const target = withTarget ? parseInt(s.el.querySelector("#rep-target").value, 10) || 0 : null;
      s.close();
      if (withTarget && !target) return EA.toast("ID du joueur requis", "error");
      await send(message, target);
      EA.toast("Signalement envoyé.", "success"); EA.refresh();
    };
  }

  function bind() {
    EA.onAll("[data-new]", (b) => composer("Ton message", false,
      (message) => EA.post("/reports", { type: b.dataset.new, message })));
    const player = document.getElementById("rep-player");
    if (player) EA.act(player, () => composer("Signaler un joueur", true,
      (message, target_id) => EA.post("/reports", { type: "exploit", message, target_id })));
    EA.onAll("[data-handle]", async (b) => {
      const [id, status] = b.dataset.handle.split(":");
      await EA.post(`/reports/staff/${id}`, { status });
      EA.toast("Signalement mis à jour.", "success"); EA.refresh();
    });
  }

  EA.sub({ tab: "profil", id: "signalements", icon: "flag", label: "Signalements", order: 70, render, bind });
})();
