// screens/garden.js — Ville › Jardin, partagé Telegram/Web.
(() => {
  async function render() {
    const r = await EA.api("/garden/home");
    const readyCount = r.plots.filter((p) => p.ready).length;
    const plots = r.plots.map((p) => `<div class="ea-list-row"><div class="ic">${p.emoji}</div><div><div class="t">#${p.plot_id} ${EA.esc(p.plant_type)} ${p.ready ? "· ✅ prête" : `· ⏳ ${EA.fmt(p.remaining)} s`}</div><div class="d">💧 ${p.water_needed - p.water_remaining}/${p.water_needed} · valeur ${EA.fmt(p.value)} €A</div></div><span>${p.ready ? `<button class="ea-pill-btn gold" data-garden-harvest="${p.plot_id}">Récolter</button>` : p.water_remaining ? `<button class="ea-pill-btn" data-garden-water="${p.plot_id}">Arroser</button>` : ""}</span></div>`).join("");
    const plants = r.plants.map((p) => `<option value="${EA.esc(p.type)}">${p.emoji} ${EA.esc(p.type)} · ${EA.fmt(p.seed_cost)} €A</option>`).join("");
    const batch = readyCount ? `<button class="ea-btn secondary" id="garden-harvest-all" style="margin-top:8px">🌾 Tout récolter (${readyCount})</button>` : "";
    return `<div class="ea-card accent"><div class="ea-title">🌿 Mon jardin</div><p class="ea-sub">${r.plots.length}/${r.max_plots} parcelles · saison ×${r.season_multiplier.toFixed(1)}</p><select class="ea-input" id="garden-plant">${plants}</select><button class="ea-btn" id="garden-plant-btn" style="margin-top:8px">Planter</button>${batch}</div><div class="ea-section-title">Parcelles</div><div class="ea-list">${plots || `<p class="ea-muted">Ton jardin est vide.</p>`}</div>`;
  }
  async function act(path, body) { const r = await EA.post(path, body); EA.toast(r.message, "success"); EA.refresh(); }
  function bind() {
    const p = document.getElementById("garden-plant-btn"); if (p) EA.act(p, () => act("/garden/plant", { plant_type: document.getElementById("garden-plant").value }));
    const all = document.getElementById("garden-harvest-all"); if (all) EA.act(all, () => act("/garden/harvest/all"));
    EA.onAll("[data-garden-water]", (b) => act("/garden/water", { plot_id: Number(b.dataset.gardenWater) }));
    EA.onAll("[data-garden-harvest]", (b) => act("/garden/harvest", { plot_id: Number(b.dataset.gardenHarvest) }));
  }
  EA.sub({ tab: "jeux", id: "garden", icon: "spark", label: "Jardin", order: 25, render, bind });
})();
