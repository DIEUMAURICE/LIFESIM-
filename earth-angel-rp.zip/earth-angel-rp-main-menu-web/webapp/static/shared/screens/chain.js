// screens/chain.js — Économie › Production : rang de métier, biens produits, vente.
(() => {
  async function openSell(good) {
    const o = await EA.api(`/chain/sell/${good}`);
    const buyers = o.buyers.map((b) => `<div class="ea-admin-row">
      <div><div>${o.emoji} <b>${EA.esc(b.name)}</b></div>
        <div class="ea-sub">${EA.fmt(b.price)} €A/u · place ${b.room} · caisse ${EA.fmt(b.treasury)}</div></div>
      <button class="ea-pill-btn gold" data-sell="${b.company_id}">Vendre tout</button>
    </div>`).join("") || `<p class="ea-sub">Aucune entreprise acheteuse pour l'instant.</p>`;
    const deposit = o.can_deposit_to_own_company
      ? `<div class="ea-admin-row"><div>📥 Déposer chez ${EA.esc(o.own_company_name)}</div>
          <button class="ea-pill-btn" data-deposit="${o.own_company_id}">Déposer tout</button></div>` : "";
    const s = EA.sheet(`
      <div class="ea-row"><b>${o.emoji} ${EA.esc(o.name)} — tu en as ${o.have}</b><span class="ea-pill-btn" data-close>Fermer ✕</span></div>
      <div class="ea-card">${buyers}${deposit}
        <div class="ea-admin-row"><div>🏛️ Comptoir national — ${EA.fmt(o.counter_price)} €A/u (max ${o.counter_daily_cap}/j)</div>
          <button class="ea-pill-btn" data-counter>Vendre tout</button></div>
      </div>`);
    s.el.classList.add("tall");
    s.el.querySelector("[data-close]").onclick = s.close;
    EA.onAll("[data-sell]", (b) => EA.post("/chain/sell", { good, company_id: Number(b.dataset.sell), quantity: o.have })
      .then((r) => { EA.toast(r.message.replace(/<[^>]+>/g, " "), "success"); s.close(); EA.refresh(); })
      .catch((e) => EA.toast(e.message, "error")), s.el);
    EA.onAll("[data-deposit]", (b) => EA.post("/chain/deposit", { good, company_id: Number(b.dataset.deposit), quantity: o.have })
      .then((r) => { EA.toast(r.message.replace(/<[^>]+>/g, " "), "success"); s.close(); EA.refresh(); })
      .catch((e) => EA.toast(e.message, "error")), s.el);
    const counterBtn = s.el.querySelector("[data-counter]");
    if (counterBtn) counterBtn.onclick = () => EA.post("/chain/counter-sell", { good, quantity: o.have })
      .then((r) => { EA.toast(r.message.replace(/<[^>]+>/g, " "), "success"); s.close(); EA.refresh(); })
      .catch((e) => EA.toast(e.message, "error"));
  }

  EA.sub({
    tab: "economie", id: "chain", icon: "trending-up", label: "Production", order: 18,
    async render() {
      let promo;
      try { promo = await EA.api("/chain/promotion"); }
      catch (e) { return `<div class="ea-card ea-center"><p class="ea-sub">${EA.esc(e.message)}</p></div>`; }
      const g = await EA.api("/chain/goods");

      const reqs = promo.next_rank !== undefined ? promo.requirements.map((r) => `
        <div class="ea-admin-row"><div>${r.ok ? "✅" : "⬜"} ${EA.esc(r.label)}</div><div class="ea-sub">${r.have}/${r.need}</div></div>
      `).join("") : "";

      return `
        <div class="ea-card ea-center">
          <div class="ea-fortune" style="font-size:20px">${EA.esc(promo.rank_name)}</div>
          <p class="ea-sub">${EA.esc(promo.job)} · ${promo.missions} missions · gains ×${promo.pay_mult}</p>
        </div>
        ${promo.next_rank !== undefined ? `
          <div class="ea-section-title">Prochain rang : ${EA.esc(promo.next_rank_name)}</div>
          <div class="ea-card">${reqs}
            ${promo.can_promote ? `<button class="ea-btn" id="chain-promote" style="margin-top:8px">⬆️ Être promu</button>` : ""}
          </div>` : `<div class="ea-card ea-center"><p class="ea-sub">🏆 Rang maximal atteint.</p></div>`}
        <div class="ea-section-title">Biens de base</div>
        <div class="ea-card">
          ${g.raw_goods.length ? g.raw_goods.map((r) => `<div class="ea-admin-row">
            <div>${r.emoji} <b>${EA.esc(r.name)}</b> ×${r.quantity}</div>
            <button class="ea-pill-btn gold" data-good="${r.key}">Vendre</button>
          </div>`).join("") : `<p class="ea-sub">Travaille pour en produire.</p>`}
        </div>
        ${g.finished_goods.length ? `
          <div class="ea-section-title">Produits finis</div>
          <div class="ea-card">${g.finished_goods.map((f) => `<div class="ea-admin-row">
            <div>${f.emoji} <b>${EA.esc(f.name)}</b> ×${f.quantity}</div><div class="ea-sub">${EA.esc(f.effects)}</div>
          </div>`).join("")}</div>` : ""}
        ${g.stats ? `<p class="ea-sub" style="text-align:center;margin-top:6px">Fourni : ${EA.fmt(g.stats.goods_supplied)} unités · ${EA.fmt(g.stats.supply_value)} €A</p>` : ""}`;
    },
    bind() {
      EA.onAll("[data-good]", (b) => openSell(b.dataset.good));
      const p = document.getElementById("chain-promote");
      if (p) EA.act(p, async () => {
        const r = await EA.post("/chain/promote");
        EA.toast(r.message.replace(/<[^>]+>/g, " "), "success");
        EA.refresh();
      });
    },
  });
})();
