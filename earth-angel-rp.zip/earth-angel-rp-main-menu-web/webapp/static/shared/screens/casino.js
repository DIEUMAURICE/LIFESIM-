// screens/casino.js — Ville › Loisirs : parcours casino partagés Bot / Mini App / Web.
(() => {
  let lastBet = 500;

  EA.sub({
    tab: "jeux", id: "casino", icon: "dice", label: "Loisirs", order: 10,
    async render() {
      const s = await EA.api("/casino/status");
      return `
        <div class="ea-card ea-center">
          <p class="ea-sub">${s.open ? "🟢 Ouvert maintenant" : "🔴 Fermé en ce moment"} · ${EA.fmt(s.balance)} 💵 en poche</p>
          <div id="slots-reels" style="font-size:34px;letter-spacing:6px;margin:6px 0 14px">🍒 🍋 🍊 🍇 🔔</div>
          <input class="ea-input" id="slots-amount" type="number" value="${lastBet}"
            min="${s.min_bet}" max="${s.max_bet}" placeholder="Mise (${s.min_bet}–${s.max_bet})" />
          <button class="ea-btn" id="slots-spin" style="margin-top:10px" ${s.open ? "" : "disabled"}>🎰 SPIN</button>
          <p class="ea-muted" style="margin-top:8px">Mise min ${EA.fmt(s.min_bet)} · max ${EA.fmt(s.max_bet)}</p>
        </div>
        <div class="ea-card ea-center">
          <h3>♠️ Poker vidéo</h3>
          <p class="ea-muted">Compare ta main de cinq cartes à celle du croupier.</p>
          <input class="ea-input" id="poker-amount" type="number" value="${lastBet}"
            min="${s.min_bet}" max="${s.max_bet}" placeholder="Mise (${s.min_bet}–${s.max_bet})" />
          <button class="ea-btn" id="poker-play" style="margin-top:10px" ${s.open ? "" : "disabled"}>♠️ Jouer</button>
          <div id="poker-result" class="ea-muted" style="margin-top:12px"></div>
        </div>
        <div class="ea-card ea-center">
          <h3>🃏 Blackjack</h3>
          <input class="ea-input" id="blackjack-amount" type="number" value="${lastBet}" min="${s.min_bet}" max="${s.max_bet}" />
          <button class="ea-btn" id="blackjack-start" style="margin-top:10px" ${s.open ? "" : "disabled"}>🃏 Nouvelle partie</button>
          <div id="blackjack-state" class="ea-muted" style="margin-top:12px"></div>
          <div id="blackjack-actions" style="display:none;margin-top:8px">
            <button class="ea-btn" id="blackjack-hit">Tirer</button>
            <button class="ea-btn" id="blackjack-stand">Rester</button>
            <button class="ea-btn" id="blackjack-double">Doubler</button>
          </div>
        </div>
        <div class="ea-card ea-center">
          <h3>🎡 Roulette</h3>
          <input class="ea-input" id="roulette-amount" type="number" value="${lastBet}" min="${s.min_bet}" max="${s.max_bet}" />
          <select class="ea-input" id="roulette-type">
            <option value="rouge">Rouge ×2</option><option value="noir">Noir ×2</option>
            <option value="pair">Pair ×2</option><option value="impair">Impair ×2</option>
            <option value="1-18">1–18 ×2</option><option value="19-36">19–36 ×2</option>
            <option value="1-12">1–12 ×3</option><option value="13-24">13–24 ×3</option><option value="25-36">25–36 ×3</option>
            <option value="number">Numéro exact ×36</option>
          </select>
          <input class="ea-input" id="roulette-number" type="number" min="0" max="36" placeholder="Numéro 0–36" />
          <button class="ea-btn" id="roulette-play" style="margin-top:10px" ${s.open ? "" : "disabled"}>🎡 Lancer la bille</button>
          <div id="roulette-result" class="ea-muted" style="margin-top:12px"></div>
        </div>
        <div class="ea-card ea-center">
          <h3>🏇 Paris hippiques</h3>
          <input class="ea-input" id="pmu-amount" type="number" value="${lastBet}" min="${s.min_bet}" max="${s.max_bet}" />
          <select class="ea-input" id="pmu-horse">
            <option value="0">🐴 Éclair Noir · ×2,5</option><option value="1">🐎 Tonnerre · ×4</option>
            <option value="2">🏇 Vent du Nord · ×6</option><option value="3">⭐ Galaxie · ×10</option>
            <option value="4">👻 Fantôme · ×15</option><option value="5">🎯 Miracle · ×25</option>
          </select>
          <button class="ea-btn" id="pmu-play" style="margin-top:10px" ${s.open ? "" : "disabled"}>🏇 Lancer la course</button>
          <div id="pmu-result" class="ea-muted" style="margin-top:12px"></div>
        </div>
        <div class="ea-card ea-center">
          <h3>💣 Mines</h3>
          <input class="ea-input" id="mines-amount" type="number" value="${lastBet}" min="${s.min_bet}" max="200000" />
          <button class="ea-btn" id="mines-start" style="margin-top:10px" ${s.open ? "" : "disabled"}>Lancer Mines</button>
          <div id="mines-state" class="ea-muted" style="margin-top:8px">5 mines cachées dans 25 cases · +0,05× par diamant sûr.</div>
          <div id="mines-grid" style="display:grid;grid-template-columns:repeat(5,1fr);gap:5px;margin:10px auto;max-width:310px"></div>
          <button class="ea-btn" id="mines-cashout" style="display:none">💰 Encaisser</button>
        </div>
        <div class="ea-card ea-center">
          <h3>🚀 Crash</h3>
          <input class="ea-input" id="crash-amount" type="number" value="${lastBet}" min="${s.min_bet}" max="${s.max_bet}" />
          <button class="ea-btn" id="crash-start" style="margin-top:10px" ${s.open ? "" : "disabled"}>Lancer Crash</button>
          <p id="crash-state" class="ea-muted">Le multiplicateur monte : encaisse avant le crash.</p>
          <button class="ea-btn" id="crash-cashout" style="display:none">💸 Encaisser</button>
        </div>
        <div class="ea-section-title">Autres loisirs</div>
        <div class="ea-list">
          ${EA.botRow("trophy", "Arène", "Duels entre joueurs")}
        </div>`;
    },
    bind() {
      let blackjackGameId = null;
      const btn = document.getElementById("slots-spin");
      if (!btn) return;
      EA.act(btn, async () => {
        const amount = parseInt(document.getElementById("slots-amount").value, 10);
        if (!amount || amount <= 0) return EA.toast("Mise invalide", "error");
        lastBet = amount;
        btn.disabled = true;
        btn.textContent = "🎰 ...";
        try {
          const r = await EA.post("/casino/slots/spin", { amount });
          document.getElementById("slots-reels").textContent = r.reels.join(" ");
          if (r.win > 0) EA.toast(`🎉 Gagné ${EA.fmt(r.win)} ! (x${r.multiplier})` + (r.loot ? ` + ${r.loot}` : ""), "success");
          else EA.toast(`💸 Perdu ${EA.fmt(amount)}`, "error");
          setTimeout(EA.refresh, 900);
        } catch (e) {
          btn.disabled = false;
          btn.textContent = "🎰 SPIN";
          throw e;
        }
      });
      const poker = document.getElementById("poker-play");
      EA.act(poker, async () => {
        const amount = parseInt(document.getElementById("poker-amount").value, 10);
        if (!amount || amount <= 0) return EA.toast("Mise invalide", "error");
        lastBet = amount;
        poker.disabled = true;
        poker.textContent = "♠️ ...";
        try {
          const r = await EA.post("/casino/poker/play", { amount });
          const result = r.outcome === "win" ? `Gagné ×${r.multiplier} · ${EA.fmt(r.gross_payout)}`
            : r.outcome === "push" ? `Égalité · mise rendue ${EA.fmt(r.bet)}` : `Perdu · ${EA.fmt(r.bet)}`;
          const loot = r.loot ? ` · 🎁 ${r.loot}` : "";
          document.getElementById("poker-result").textContent = `Ta main : ${r.player_hand.join(" ")} (${r.player_name}) · Croupier : ${r.dealer_hand.join(" ")} (${r.dealer_name}) · ${result}${loot}`;
          EA.toast(result + loot, r.outcome === "loss" ? "error" : "success");
          setTimeout(EA.refresh, 900);
        } catch (e) {
          poker.disabled = false;
          poker.textContent = "♠️ Jouer";
          throw e;
        }
      });
      const roulette = document.getElementById("roulette-play");
      EA.act(roulette, async () => {
        const amount = Number(document.getElementById("roulette-amount").value);
        const bet_type = document.getElementById("roulette-type").value;
        const payload = { amount, bet_type };
        if (bet_type === "number") payload.number = Number(document.getElementById("roulette-number").value);
        roulette.disabled = true;
        try {
          const r = await EA.post("/casino/roulette/spin", payload);
          const won = r.gross_payout > 0;
          document.getElementById("roulette-result").textContent = `${r.color === "red" ? "🔴" : r.color === "black" ? "⚫" : "🟢"} ${r.number} · ${won ? `Gain ${EA.fmt(r.gross_payout)}` : `Perdu ${EA.fmt(r.bet)}`}${r.loot ? ` · 🎁 ${r.loot}` : ""}`;
          EA.toast(won ? `Gagné ${EA.fmt(r.gross_payout)}` : `Perdu ${EA.fmt(r.bet)}`, won ? "success" : "error");
          setTimeout(EA.refresh, 900);
        } catch (e) { throw e; } finally { roulette.disabled = false; }
      });
      const pmu = document.getElementById("pmu-play");
      EA.act(pmu, async () => {
        const amount = Number(document.getElementById("pmu-amount").value);
        const horse_index = Number(document.getElementById("pmu-horse").value);
        pmu.disabled = true;
        try {
          const r = await EA.post("/casino/pmu/run", { amount, horse_index });
          const podium = r.ranking.slice(0, 3).map((idx, pos) => `${pos + 1}. ${r.horses[idx].emoji} ${r.horses[idx].name}`).join(" · ");
          document.getElementById("pmu-result").textContent = `${podium} · ${r.won ? `Gagné ${EA.fmt(r.gross_payout)}` : `Perdu ${EA.fmt(r.bet)}`}${r.loot ? ` · 🎁 ${r.loot}` : ""}`;
          EA.toast(r.won ? `Ton cheval gagne ${EA.fmt(r.gross_payout)}` : "Ton cheval a perdu", r.won ? "success" : "error");
          setTimeout(EA.refresh, 900);
        } catch (e) { throw e; } finally { pmu.disabled = false; }
      });
      const bjStart = document.getElementById("blackjack-start");
      const showBlackjack = (r) => {
        const active = r.status === "active";
        const result = active ? "À toi de jouer." : (r.status === "blackjack" ? `Blackjack naturel · gain ${EA.fmt(r.gross_payout)}` : `${r.status} · ${r.gross_payout ? `gain ${EA.fmt(r.gross_payout)}` : `perdu ${EA.fmt(r.bet)}`}`);
        document.getElementById("blackjack-state").textContent = `Ta main : ${r.player_hand.join(" ")}${r.player_value != null ? ` (${r.player_value})` : ""} · Croupier : ${r.dealer_hand.join(" ")}${active ? " ?" : ` (${r.dealer_value ?? ""})`} · ${result}${r.loot ? ` · 🎁 ${r.loot}` : ""}`;
        document.getElementById("blackjack-actions").style.display = active ? "block" : "none";
        if (!active) blackjackGameId = null;
        if (!active) setTimeout(EA.refresh, 900);
      };
      EA.act(bjStart, async () => {
        bjStart.disabled = true;
        try {
          const amount = Number(document.getElementById("blackjack-amount").value);
          const r = await EA.post("/casino/blackjack/start", { amount });
          blackjackGameId = r.game_id || null;
          showBlackjack(r);
        } catch (e) { throw e; } finally { bjStart.disabled = false; }
      });
      ["hit", "stand", "double"].forEach((action) => {
        const button = document.getElementById(`blackjack-${action}`);
        EA.act(button, async () => {
          if (!blackjackGameId) return EA.toast("Aucune partie active", "error");
          button.disabled = true;
          try {
            const r = await EA.post(`/casino/blackjack/${blackjackGameId}/action`, { action });
            showBlackjack(r);
          } catch (e) { throw e; } finally { button.disabled = false; }
        });
      });
      let minesGameId = null;
      let minesRevealed = [];
      let minesOver = false;
      const paintMines = (minePositions = []) => {
        const grid = document.getElementById("mines-grid");
        grid.innerHTML = Array.from({ length: 25 }, (_, i) => {
          const revealed = minesRevealed.includes(i);
          const mine = minePositions.includes(i);
          const label = revealed ? (mine ? "💣" : "💎") : (minesOver && mine ? "💣" : "⬛");
          return `<button class="ea-btn" data-cell="${i}" ${revealed || minesOver || !minesGameId ? "disabled" : ""}>${label}</button>`;
        }).join("");
      };
      EA.act(document.getElementById("mines-start"), async () => {
        const button = document.getElementById("mines-start");
        button.disabled = true;
        try {
          const amount = Number(document.getElementById("mines-amount").value);
          const r = await EA.post("/casino/mines/start", { amount });
          minesGameId = r.game_id;
          minesRevealed = [];
          minesOver = false;
          paintMines();
          document.getElementById("mines-cashout").style.display = "inline-block";
          document.getElementById("mines-state").textContent = `Mise ${EA.fmt(r.bet)} · multiplicateur ×1,00`;
        } catch (e) { throw e; } finally { button.disabled = false; }
      });
      document.getElementById("mines-grid").addEventListener("click", async (event) => {
        const cell = event.target.closest("[data-cell]");
        if (!cell || !minesGameId || minesOver) return;
        cell.disabled = true;
        try {
          const r = await EA.post(`/casino/mines/${minesGameId}/action`, { action: "click", index: Number(cell.dataset.cell) });
          if (r.status === "loss") {
            minesOver = true;
            minesGameId = null;
            minesRevealed.push(Number(cell.dataset.cell));
            paintMines(r.mines || []);
            document.getElementById("mines-state").textContent = `Mine ! Mise perdue : ${EA.fmt(r.bet)}`;
            document.getElementById("mines-cashout").style.display = "none";
            EA.toast("Mine ! Mise perdue", "error");
            setTimeout(EA.refresh, 900);
          } else {
            minesRevealed = r.revealed;
            paintMines();
            document.getElementById("mines-state").textContent = `${minesRevealed.length} diamant(s) · gain possible ${EA.fmt(r.potential_payout)} · ×${r.multiplier.toFixed(2)}`;
          }
        } catch (e) { cell.disabled = false; throw e; }
      });
      EA.act(document.getElementById("mines-cashout"), async () => {
        if (!minesGameId) return;
        const r = await EA.post(`/casino/mines/${minesGameId}/action`, { action: "cashout" });
        minesOver = true;
        minesGameId = null;
        paintMines(r.mines || []);
        document.getElementById("mines-cashout").style.display = "none";
        document.getElementById("mines-state").textContent = `Encaissé ${EA.fmt(r.gross_payout)} · solde ${EA.fmt(r.balance)}${r.loot ? ` · 🎁 ${r.loot}` : ""}`;
        EA.toast(`Encaissé ${EA.fmt(r.gross_payout)}`, "success");
        setTimeout(EA.refresh, 900);
      });
      let crashGameId = null;
      let crashPoll = null;
      const crashState = document.getElementById("crash-state");
      EA.act(document.getElementById("crash-start"), async () => {
        const start = document.getElementById("crash-start");
        start.disabled = true;
        try {
          const amount = Number(document.getElementById("crash-amount").value);
          const r = await EA.post("/casino/crash/start", { amount });
          crashGameId = r.game_id;
          crashState.textContent = `Mise ${EA.fmt(r.bet)} · ×1,00 · gain possible ${EA.fmt(r.potential_payout)}`;
          document.getElementById("crash-cashout").style.display = "inline-block";
          crashPoll = setInterval(async () => {
            if (!crashGameId) return;
            try {
              const state = await EA.api(`/casino/crash/${crashGameId}`);
              crashState.textContent = state.status === "crashed" ? `Crash à ×${state.multiplier.toFixed(2)} · mise perdue ${EA.fmt(amount)}` : `×${state.multiplier.toFixed(2)} · gain possible ${EA.fmt(state.potential_payout)}`;
              if (state.status === "crashed") {
                clearInterval(crashPoll); crashPoll = null; crashGameId = null;
                document.getElementById("crash-cashout").style.display = "none";
                EA.toast("Crash ! Mise perdue", "error");
                setTimeout(EA.refresh, 900);
              }
            } catch (_e) { clearInterval(crashPoll); crashPoll = null; }
          }, 160);
        } catch (e) { throw e; } finally { start.disabled = false; }
      });
      EA.act(document.getElementById("crash-cashout"), async () => {
        if (!crashGameId) return;
        try {
          const r = await EA.post(`/casino/crash/${crashGameId}/cashout`, {});
          clearInterval(crashPoll); crashPoll = null; crashGameId = null;
          document.getElementById("crash-cashout").style.display = "none";
          crashState.textContent = `Encaissé ×${r.multiplier.toFixed(2)} · ${EA.fmt(r.gross_payout)}${r.loot ? ` · 🎁 ${r.loot}` : ""}`;
          EA.toast(`Encaissé ${EA.fmt(r.gross_payout)}`, "success");
          setTimeout(EA.refresh, 900);
        } catch (e) { throw e; }
      });
    },
  });
})();
