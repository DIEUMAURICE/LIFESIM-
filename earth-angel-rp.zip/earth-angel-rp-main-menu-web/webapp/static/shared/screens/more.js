// screens/more.js — Plus : classement des fortunes + compte (déconnexion).
(() => {
  EA.plusBlock({
    order: 20,
    async render({ user: u }) {
      const r = await EA.api("/rankings/rich?limit=15");
      const rows = r.top.map((p, i) =>
        `<div class="ea-rank-row ${p.user_id === u.user_id ? "me" : ""}">
          <span class="pos">${i + 1}</span>
          <span>${EA.esc(p.full_name || p.username || ("Joueur " + p.user_id))}</span>
          <span class="amt">${EA.fmt(p.balance)} €</span>
        </div>`).join("");
      return `<div class="ea-card"><div class="ea-title">Classement des fortunes</div>${rows}</div>`;
    },
  });

  EA.plusBlock({
    order: 70,
    async render() {
      const r = await EA.api("/notifications/history");
      const items = (r.notifications || []).slice(0, 5);
      return `<div class="ea-card"><div class="ea-title">Dernières notifications</div>
        ${items.length ? items.map((n) => `<div class="ea-list-row">
          <div class="ic">${EA.esc(n.emoji || "📌")}</div>
          <div><div class="t">${EA.esc(n.title || "Notification")}</div>
          <div class="d">${EA.esc(n.message || "")}</div></div>
        </div>`).join("") : `<p class="ea-sub">Aucune notification récente.</p>`}
        <p class="ea-muted">Ouvre la cloche en haut pour consulter les notifications nouvelles et l’historique complet.</p></div>`;
    },
  });

  EA.plusBlock({
    order: 80,
    async render() {
      const p = await EA.api("/phone/home");
      return `<div class="ea-card">
        <div class="ea-title">Paramètres du téléphone</div>
        <div class="ea-row" style="margin-top:8px;gap:8px">
          <button class="ea-pill-btn ${p.theme === "dark" ? "gold" : ""}" data-theme="dark">🌙 Sombre</button>
          <button class="ea-pill-btn ${p.theme === "light" ? "gold" : ""}" data-theme="light">☀️ Clair</button>
        </div>
        <div class="ea-row" style="margin-top:8px;gap:8px">
          <button class="ea-pill-btn ${p.ringtone === "classic" ? "gold" : ""}" data-ring="classic">🎵 Classique</button>
          <button class="ea-pill-btn ${p.ringtone === "modern" ? "gold" : ""}" data-ring="modern">🎶 Moderne</button>
        </div>
      </div>`;
    },
    bind() {
      EA.onAll("[data-theme]", (b) => EA.post("/phone/settings", { theme: b.dataset.theme }).then(() => EA.refresh()));
      EA.onAll("[data-ring]", (b) => EA.post("/phone/settings", { ringtone: b.dataset.ring }).then(() => EA.refresh()));
    },
  });

  EA.plusBlock({
    order: 90,
    render({ user: u }) {
      return `<div class="ea-card">
        <div class="ea-title">Mon compte</div>
        <p class="ea-sub">#${u.user_id}</p>
        <button class="ea-btn secondary" id="btn-logout" style="margin-top:8px">Changer de compte / Déconnexion</button>
      </div>`;
    },
    bind() {
      const lo = document.getElementById("btn-logout");
      if (lo) EA.act(lo, async () => {
        if (await EA.confirm("Te déconnecter de ce compte ?", { danger: true, ok: "Déconnexion" })) EA.logout();
      });
    },
  });
})();
