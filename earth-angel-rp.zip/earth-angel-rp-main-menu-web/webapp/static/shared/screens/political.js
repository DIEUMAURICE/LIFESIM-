// screens/political.js — Politique & institutions : élections, destitution et mandat présidentiel.
// Mêmes services que le bot (gameplay/elections.py, utils/politics.py) : aucune règle recalculée ici.
// Lois, référendums, constitution : gameplay/laws.py. Gouvernement : gameplay/cabinet.py.
(() => {
  function officeCard(status) {
    const office = status.office;
    const term = status.term_left_seconds;
    const label = office ? office.label : "Citoyen(ne)";
    const termLine = office && office.kind === "president" && Number.isFinite(term)
      ? `<p class="ea-sub">Mandat restant : ${EA.fmtMin(Math.max(0, term))}</p>` : "";
    return `<div class="ea-card accent ea-center">
      <div class="ea-title">🏛️ ${EA.esc(label)}</div>
      ${termLine}
      <p class="ea-sub">${status.registered_players} joueurs inscrits</p>
    </div>`;
  }

  function journal(status) {
    if (!status.journal.length) return `<p class="ea-sub">Aucun événement récent.</p>`;
    return `<div class="ea-list">` + status.journal.map((e) => `
      <div class="ea-list-row">
        <div class="ic">📰</div>
        <div><div class="t">${EA.esc(e.description)}</div><div class="d">${EA.esc(e.type)}</div></div>
      </div>`).join("") + `</div>`;
  }

  function motionRow(m) {
    const voteButtons = m.status === "voting"
      ? `<div class="ea-grid" style="margin-top:6px">
          <button class="ea-btn secondary" data-vote="${m.target}" data-choice="pour">👍 Pour (${m.pour})</button>
          <button class="ea-btn danger" data-vote="${m.target}" data-choice="contre">👎 Contre (${m.contre})</button>
        </div>`
      : `<button class="ea-pill-btn gold" data-sign="${m.target}" style="margin-top:6px">✍️ Signer (${m.signatures}/${m.needed})</button>`;
    return `<div style="display:flex;flex-direction:column;gap:4px;padding:11px 0;border-bottom:1px solid var(--line)">
      <div><b>${EA.esc(m.target_name)}</b> — ${EA.esc(m.office)}</div>
      <div class="ea-sub">${m.status === "voting" ? "Vote en cours" : "Signatures en cours"} · ${EA.fmtMin(Math.max(0, m.left))} restant</div>
      ${voteButtons}
    </div>`;
  }

  function electionBlock(e, info) {
    const voted = info.my_votes[String(e.id)];
    const isCandidate = e.candidates.some((c) => c.user_id === info.me);
    const rows = e.candidates.length ? e.candidates.map((c) => `
      <div class="ea-list-row">
        <div class="ic">🗳️</div>
        <div style="flex:1"><div class="t">${EA.esc(c.full_name || String(c.user_id))} — ${c.votes} voix</div>
          <div class="d">${EA.esc(c.program || "")}</div></div>
        ${info.can_vote && !voted ? `<button class="ea-pill-btn gold" data-elvote="${e.id}:${c.user_id}">Voter</button>` : (voted === c.user_id ? "<span>✅</span>" : "")}
      </div>`).join("") : `<p class="ea-sub">Aucun candidat pour l'instant.</p>`;
    const run = info.can_run && !isCandidate
      ? `<button class="ea-btn secondary" data-elrun="${e.id}" style="margin-top:6px">🙋 Me présenter</button>` : "";
    return `<div class="ea-card"><div class="ea-title" style="font-size:15px">🗳️ ${EA.esc(e.poste)} · élection #${e.id}</div>
      <p class="ea-sub">Clôture dans ${EA.fmtMin(Math.max(0, e.ends_at - Math.floor(Date.now() / 1000)))}</p>
      <div class="ea-list">${rows}</div>${run}</div>`;
  }

  function pollRow(kind, item, title, mine, canVote) {
    const voted = mine[String(item.id)];
    const buttons = canVote && !voted
      ? `<div class="ea-grid" style="margin-top:6px">
          <button class="ea-btn secondary" data-poll="${kind}:${item.id}:pour">👍 Pour (${item.votes_for})</button>
          <button class="ea-btn danger" data-poll="${kind}:${item.id}:contre">👎 Contre (${item.votes_against})</button>
        </div>`
      : `<div class="ea-sub">✅ ${item.votes_for} pour · ❌ ${item.votes_against} contre${voted ? " · ton vote est enregistré" : ""}</div>`;
    return `<div style="padding:10px 0;border-bottom:1px solid var(--line)">
      <div><b>${EA.esc(title)}</b></div>
      ${item.description ? `<div class="ea-sub">${EA.esc(item.description)}</div>` : ""}
      <div class="ea-sub">Clôture dans ${EA.fmtMin(Math.max(0, item.voting_ends_at - Math.floor(Date.now() / 1000)))} · majorité ${Math.round(item.required_majority * 100)} %</div>
      ${buttons}</div>`;
  }

  function lawsHtml(laws, refs, constitution) {
    const inForce = laws.passed.length
      ? laws.passed.map((l) => `<div class="ea-list-row"><div class="ic">📜</div><div><div class="t">${EA.esc(l.title)}</div><div class="d">${EA.esc((l.description || "").slice(0, 140))}</div></div></div>`).join("")
      : `<p class="ea-sub">Aucune loi en vigueur.</p>`;
    return `<div class="ea-section-title">Lois en vote</div>`
      + (laws.voting.length ? laws.voting.map((l) => pollRow("law", l, l.title, laws.my_votes, laws.can_vote)).join("") : `<p class="ea-sub">Aucune loi en vote.</p>`)
      + `<button class="ea-btn secondary" id="pol-new-law" style="margin-top:8px">📜 Proposer une loi (${EA.fmt(laws.cost)})</button>`
      + `<div class="ea-section-title">Lois en vigueur</div><div class="ea-list">${inForce}</div>`
      + `<div class="ea-section-title">Référendums</div>`
      + (refs.referendums.length ? refs.referendums.map((r) => pollRow("ref", r, r.question, refs.my_votes, refs.can_vote)).join("") : `<p class="ea-sub">Aucun référendum en cours.</p>`)
      + `<button class="ea-btn secondary" id="pol-new-ref" style="margin-top:8px">📢 Lancer un référendum (${EA.fmt(refs.cost)})</button>`
      + `<div class="ea-section-title">Constitution</div><p class="ea-sub" style="white-space:pre-wrap">${EA.esc(constitution.text)}</p>`
      + `<button class="ea-btn secondary" id="pol-new-constitution">⚖️ Proposer une modification (Président / ministres)</button>`;
  }

  function governmentHtml(g) {
    const pres = g.president ? EA.esc(g.president.name || String(g.president.user_id)) : "<i>vacant</i>";
    const rows = g.ministries.map((m) => `
      <div class="ea-list-row">
        <div class="ic">${m.emoji}</div>
        <div style="flex:1"><div class="t">Ministre de ${EA.esc(m.position)} — ${m.occupant_id ? EA.esc(m.occupant_name || String(m.occupant_id)) : "<i>vacant</i>"}</div>
          <div class="d">${EA.esc(m.power)}</div></div>
        ${g.is_president ? (m.occupant_id
          ? `<button class="ea-pill-btn" data-dismiss="${EA.esc(m.position)}">Révoquer</button>`
          : `<button class="ea-pill-btn gold" data-appoint="${EA.esc(m.position)}">Nommer</button>`) : ""}
      </div>`).join("");
    return `<div class="ea-section-title">Gouvernement</div><p class="ea-sub">👑 Président — ${pres}</p><div class="ea-list">${rows}</div>`;
  }

  async function render() {
    const [status, motionsResp, elections, laws, refs, constitution, government] = await Promise.all([
      EA.api("/political/status"), EA.api("/political/motions"), EA.api("/political/elections"),
      EA.api("/political/laws"), EA.api("/political/referendums"), EA.api("/political/constitution"),
      EA.api("/political/government"),
    ]);
    const electionHtml = `<div class="ea-section-title">Élections</div>`
      + (elections.elections.length ? elections.elections.map((e) => electionBlock(e, elections)).join("")
        : `<p class="ea-sub">Aucune élection ouverte.</p>`)
      + (elections.can_run ? `<button class="ea-btn secondary" id="pol-new-election" style="margin-top:8px" data-posts="${EA.esc(elections.elected_posts.join("|"))}">🏛️ Lancer une élection</button>` : "");
    const motions = motionsResp.motions;
    const list = motions.length
      ? `<div class="ea-section-title">Motions de destitution en cours</div>${motions.map(motionRow).join("")}`
      : `<p class="ea-sub">Aucune motion de destitution en cours.</p>`;
    return officeCard(status) + electionHtml + governmentHtml(government) + lawsHtml(laws, refs, constitution) + `
      <div class="ea-section-title">Journal officiel</div>${journal(status)}
      ${list}
      <button class="ea-btn secondary" id="pol-new-motion" style="margin-top:10px">⚖️ Lancer une motion de destitution</button>
      <p class="ea-sub" style="margin-top:8px">Le bot Telegram reste synchronisé : mêmes règles, même base.</p>
    `;
  }

  function bind() {
    EA.onAll("[data-sign]", async (b) => {
      const r = await EA.post("/political/motion/sign", { target_id: Number(b.dataset.sign) });
      EA.toast(r.message, "success"); EA.refresh();
    });
    EA.onAll("[data-vote]", async (b) => {
      const r = await EA.post("/political/motion/vote", { target_id: Number(b.dataset.vote), choice: b.dataset.choice });
      EA.toast(r.message, "success"); EA.refresh();
    });
    EA.onAll("[data-elvote]", async (b) => {
      const [election_id, candidate_id] = b.dataset.elvote.split(":").map(Number);
      await EA.post("/political/elections/vote", { election_id, candidate_id });
      EA.toast("Vote enregistré.", "success"); EA.refresh();
    });
    EA.onAll("[data-elrun]", async (b) => {
      const s = EA.sheet(`
        <p class="ea-sheet-msg">Ton programme (optionnel)</p>
        <input class="ea-input" id="el-program" maxlength="500" placeholder="Programme" />
        <div class="ea-grid" style="margin-top:10px">
          <button class="ea-btn secondary" data-no>Annuler</button>
          <button class="ea-btn" data-yes>Candidater</button>
        </div>`);
      s.el.querySelector("[data-no]").onclick = s.close;
      s.el.querySelector("[data-yes]").onclick = async () => {
        const program = s.el.querySelector("#el-program").value;
        s.close();
        await EA.post("/political/elections/candidate", { election_id: Number(b.dataset.elrun), program });
        EA.toast("Candidature enregistrée.", "success"); EA.refresh();
      };
    });
    const newElection = document.getElementById("pol-new-election");
    if (newElection) EA.act(newElection, async () => {
      const posts = newElection.dataset.posts.split("|");
      const s = EA.sheet(`
        <p class="ea-sheet-msg">Lancer une élection</p>
        <select class="ea-input" id="el-post">${posts.map((p) => `<option>${EA.esc(p)}</option>`).join("")}</select>
        <input class="ea-input" id="el-hours" type="number" inputmode="numeric" placeholder="Durée en heures (optionnel)" style="margin-top:8px" />
        <div class="ea-grid" style="margin-top:10px">
          <button class="ea-btn secondary" data-no>Annuler</button>
          <button class="ea-btn" data-yes>Lancer</button>
        </div>`);
      s.el.querySelector("[data-no]").onclick = s.close;
      s.el.querySelector("[data-yes]").onclick = async () => {
        const poste = s.el.querySelector("#el-post").value;
        const hours = parseInt(s.el.querySelector("#el-hours").value, 10);
        s.close();
        await EA.post("/political/elections/start", { poste, duration_hours: Number.isFinite(hours) ? hours : null });
        EA.toast("Élection lancée.", "success"); EA.refresh();
      };
    });
    EA.onAll("[data-poll]", async (b) => {
      const [kind, id, choice] = b.dataset.poll.split(":");
      await EA.post(kind === "law" ? "/political/laws/vote" : "/political/referendums/vote", { id: Number(id), choice });
      EA.toast("Vote enregistré.", "success"); EA.refresh();
    });
    const textSheet = (btnId, label, fields, path, ok) => {
      const btn = document.getElementById(btnId);
      if (!btn) return;
      EA.act(btn, async () => {
        const s = EA.sheet(`<p class="ea-sheet-msg">${label}</p>`
          + fields.map((f, i) => `<textarea class="ea-input" data-f="${f.name}" rows="${f.rows || 2}" maxlength="${f.max}" placeholder="${f.ph}" style="margin-top:${i ? 8 : 0}px"></textarea>`).join("")
          + `<div class="ea-grid" style="margin-top:10px"><button class="ea-btn secondary" data-no>Annuler</button><button class="ea-btn" data-yes>Valider</button></div>`);
        s.el.querySelector("[data-no]").onclick = s.close;
        s.el.querySelector("[data-yes]").onclick = async () => {
          const body = {};
          fields.forEach((f) => { body[f.name] = s.el.querySelector(`[data-f="${f.name}"]`).value; });
          s.close();
          await EA.post(path, body);
          EA.toast(ok, "success"); EA.refresh();
        };
      });
    };
    textSheet("pol-new-law", "Proposer une loi", [
      { name: "title", max: 120, ph: "Titre", rows: 1 }, { name: "description", max: 1000, ph: "Texte de la loi", rows: 4 },
    ], "/political/laws/propose", "Loi proposée.");
    textSheet("pol-new-ref", "Lancer un référendum", [{ name: "question", max: 500, ph: "Question posée aux joueurs", rows: 3 }],
      "/political/referendums/propose", "Référendum lancé.");
    textSheet("pol-new-constitution", "Nouveau texte complet de la constitution", [{ name: "text", max: 1500, ph: "Texte (min. 10 caractères)", rows: 6 }],
      "/political/constitution/propose", "Référendum constitutionnel ouvert.");
    EA.onAll("[data-appoint]", async (b) => {
      const position = b.dataset.appoint;
      const s = EA.sheet(`
        <p class="ea-sheet-msg">Nommer le ministre de ${EA.esc(position)}</p>
        <input class="ea-input" id="appoint-target" type="number" inputmode="numeric" placeholder="ID du joueur" />
        <div class="ea-grid" style="margin-top:10px">
          <button class="ea-btn secondary" data-no>Annuler</button>
          <button class="ea-btn" data-yes>Nommer</button>
        </div>`);
      s.el.querySelector("[data-no]").onclick = s.close;
      s.el.querySelector("[data-yes]").onclick = async () => {
        const target_user_id = parseInt(s.el.querySelector("#appoint-target").value, 10) || 0;
        s.close();
        if (!target_user_id) return EA.toast("ID requis", "error");
        await EA.post("/political/government/appoint", { position, target_user_id });
        EA.toast("Ministre nommé.", "success"); EA.refresh();
      };
    });
    EA.onAll("[data-dismiss]", async (b) => {
      await EA.post("/political/government/dismiss", { position: b.dataset.dismiss });
      EA.toast("Ministère vacant.", "success"); EA.refresh();
    });
    const newMotion = document.getElementById("pol-new-motion");
    if (newMotion) EA.act(newMotion, async () => {
      const s = EA.sheet(`
        <p class="ea-sheet-msg">Motion de destitution</p>
        <input class="ea-input" id="motion-target" placeholder="ID du joueur visé (Président ou ministre)" />
        <div class="ea-grid" style="margin-top:10px">
          <button class="ea-btn secondary" data-no>Annuler</button>
          <button class="ea-btn danger" data-yes>Lancer la motion</button>
        </div>`);
      s.el.querySelector("[data-no]").onclick = s.close;
      s.el.querySelector("[data-yes]").onclick = async () => {
        const targetId = parseInt(s.el.querySelector("#motion-target").value, 10);
        if (!targetId) return;
        s.close();
        await EA.post("/political/motion", { target_id: targetId });
        EA.toast("Motion lancée.", "success");
        EA.refresh();
      };
    });
  }

  EA.sub({ tab: "social", id: "politique", icon: "flag", label: "Politique", order: 60, render, bind });
})();
