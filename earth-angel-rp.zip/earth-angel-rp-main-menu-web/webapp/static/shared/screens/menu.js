// Menu principal commun Bot/Mini App/Web : le catalogue provient du hub Telegram.
(() => {
  let selectedArea = null;
  let showAll = false;
  const AREA_MODULES = {
    vie: [["jeux", "vie", "Vie & besoins"], ["jeux", "sante", "Santé"], ["jeux", "voyages", "Déplacements"]],
    eco: [["economie", "banque", "Banque"], ["economie", "travail", "Travail"], ["economie", "missions", "Missions"]],
    carriere: [["economie", "travail", "Travail"], ["economie", "education", "Études & diplômes"]],
    etat: [],
    invest: [["economie", "chain", "Production & placements"]],
    entreprises: [["economie", "entreprises", "Entreprises"]],
    marche: [["economie", "market", "Marché"]],
    vehicules: [["economie", "vehicules", "Véhicules"]],
    loisirs: [["jeux", "casino", "Casino"], ["jeux", "garden", "Jardin"], ["jeux", "voyages", "Voyages"]],
    social: [["social", "fol", "Mon fil"], ["social", "exp", "Explorer"], ["social", "more", "Publier"], ["social", "creator", "Stories & lives"], ["social", "polls", "Sondages"], ["social", "collabs", "Collaborations"]],
    multi: [["social", "family", "Famille"], ["social", "gangs", "Gangs"], ["jeux", "arena", "Arène"]],
    societe: [["jeux", "crime", "Crime & justice"]],
    politique: [],
    progression: [["economie", "missions", "Missions & progression"]],
    profil: [["profil", "parrainage", "Parrainage"], ["plus", null, "Profil & compte"]],
    phone: [["plus", null, "Téléphone & paramètres"]],
  };
  const ACTION_TARGET = {
    vie: ["jeux", "vie"], dormir: ["jeux", "vie"], gym: ["jeux", "vie"], manger: ["jeux", "vie"],
    sante: ["jeux", "sante"], hopital: ["jeux", "sante"], medicaments: ["jeux", "sante"], assurance: ["jeux", "sante"],
    travailler: ["economie", "travail"], travail: ["economie", "travail"],
    banques: ["economie", "banque"], mescomptes: ["economie", "banque"], ouvrir: ["economie", "banque"],
    pret: ["economie", "banque"], rembourser: ["economie", "banque"], depot: ["economie", "banque"], retrait: ["economie", "banque"],
    chain: ["economie", "chain"], production: ["economie", "chain"],
    entreprises: ["economie", "entreprises"], entreprise: ["economie", "entreprises"],
    marche: ["economie", "market"], market: ["economie", "market"],
    vehicule: ["economie", "vehicules"], vehicules: ["economie", "vehicules"],
    casino: ["jeux", "casino"], blackjack: ["jeux", "casino"], poker: ["jeux", "casino"], roulette: ["jeux", "casino"],
    crash: ["jeux", "casino"], mines: ["jeux", "casino"], pmu: ["jeux", "casino"], slots: ["jeux", "casino"],
    jardin: ["jeux", "garden"], planter: ["jeux", "garden"], arroser: ["jeux", "garden"],
    famille: ["social", "family"], adopter: ["social", "family"], mariage: ["social", "family"],
    gang: ["social", "gangs"], arene: ["jeux", "arena"], crime: ["jeux", "crime"],
    mission: ["economie", "missions"],
    etudes: ["economie", "education"], etudier: ["economie", "education"], reviser: ["economie", "education"],
    cours: ["economie", "education"], examen: ["economie", "education"], formation: ["economie", "education"],
    competences: ["economie", "education"],
    story: ["social", "creator"], live: ["social", "creator"], sondage: ["social", "polls"],
  };

  function areaCard(area) {
    return `<button class="ea-hub-card" data-area="${EA.esc(area.id)}">
      <span class="hub-icon">${EA.esc(area.label.split(" ")[0])}</span>
      <span><b>${EA.esc(area.label.replace(/^\S+\s*/, ""))}</b>
        <small>${area.action_count} action${area.action_count === 1 ? "" : "s"} · ${area.sections.length} rubrique${area.sections.length === 1 ? "" : "s"}</small></span><i>›</i>
    </button>`;
  }

  function moduleCard(module) {
    return `<button class="ea-menu-module" data-module="${EA.esc(module[0])}" data-sub="${EA.esc(module[1] || "")}">
      <span>${EA.ico("spark", "sm")}</span><b>${EA.esc(module[2])}</b><i>Ouvrir ›</i>
    </button>`;
  }

  function actionRow(action) {
    const target = ACTION_TARGET[action.function];
    const linkAttrs = target ? `data-action-tab="${EA.esc(target[0])}" data-action-sub="${EA.esc(target[1])}"` : "disabled";
    return `<button class="ea-menu-action ${target ? "ready" : "coming"}" ${linkAttrs}>
      <span><b>${EA.esc(action.label)}</b><small>${EA.esc(action.description || "")}</small></span>
      <i>${target ? "Ouvrir ›" : "Bot"}</i></button>`;
  }

  EA.tab({
    id: "menu", icon: "grid", label: "Menu", order: 5,
    async render() {
      const result = await EA.api("/hub/menu?show_all=" + (showAll ? "true" : "false"));
      const areas = result.areas || [];
      if (!selectedArea) {
        return `<div class="ea-page-title">Menu principal</div>
          <div class="ea-page-sub">Les mêmes zones et rubriques que dans le bot Telegram.</div>
          <div class="ea-hub-intro">Choisis une zone pour parcourir ses rubriques. Les modules déjà raccordés s’ouvrent ici; les autres apparaissent dans la structure source du bot.</div>
          ${result.simple_menu ? `<div class="ea-menu-onboarding"><b>Pour bien démarrer</b><div class="ea-menu-module-grid">${(result.quick_actions || []).map(actionRow).join("")}</div><button class="ea-btn secondary" data-menu-all>Voir toutes les zones (${result.total_areas})</button></div>` : ""}
          <div class="ea-hub-grid ea-menu-grid">${areas.map(areaCard).join("")}</div>`;
      }
      const area = areas.find((item) => item.id === selectedArea);
      if (!area) { selectedArea = null; return `<div class="ea-card">Le menu a changé. Réouvre-le.</div>`; }
      const modules = AREA_MODULES[area.id] || [];
      const sectionHtml = area.sections.map((section, index) => `<details class="ea-menu-section" ${index === 0 ? "open" : ""}>
        <summary>${EA.esc(section.label)} <span>${section.actions.length}</span></summary>
        <div class="ea-menu-actions">${section.actions.map(actionRow).join("")}</div>
      </details>`).join("");
      return `<div class="ea-detail-head"><button class="ea-back" data-menu-back aria-label="Retour au menu">‹</button>
          <div><div class="ea-page-title">${EA.esc(area.label)}</div><div class="ea-page-sub">${area.action_count} actions · ${area.sections.length} rubriques</div></div></div>
        ${area.description ? `<div class="ea-hub-intro">${EA.esc(area.description)}</div>` : ""}
        ${modules.length ? `<div class="ea-menu-module-grid">${modules.map(moduleCard).join("")}</div>` : `<div class="ea-card ea-center"><p class="ea-sub">Cette zone n’a pas encore de module de jeu équivalent dans l’application. Son menu et ses actions restent visibles pour guider le raccordement.</p></div>`}
        <div class="ea-section-title">Rubriques du bot</div>${sectionHtml || `<div class="ea-card"><p class="ea-sub">Aucune rubrique visible pour ce personnage.</p></div>`}`;
    },
    bind() {
      EA.onAll("[data-area]", async (button) => { selectedArea = button.dataset.area; await EA.refresh(); });
      EA.onAll("[data-menu-back]", async () => { selectedArea = null; await EA.refresh(); });
      EA.onAll("[data-menu-all]", async () => { showAll = true; await EA.refresh(); });
      EA.onAll("[data-module]", async (button) => {
        const tab = button.dataset.module;
        const sub = button.dataset.sub || undefined;
        await EA.go(tab, sub);
      });
      EA.onAll("[data-action-tab]", async (button) => {
        await EA.go(button.dataset.actionTab, button.dataset.actionSub || undefined);
      });
    },
  });
})();
