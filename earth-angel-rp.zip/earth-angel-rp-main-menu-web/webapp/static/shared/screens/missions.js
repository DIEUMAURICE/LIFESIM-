// screens/missions.js — Économie › Missions : quotidiennes/hebdomadaires, versées automatiquement.
(() => {
  function bar(progress, target) {
    const pct = target > 0 ? Math.max(0, Math.min(100, Math.round((progress / target) * 100))) : 0;
    return `<div class="ea-bar-track"><div class="ea-bar-fill ${pct >= 100 ? "" : "mid"}" style="width:${pct}%"></div></div>`;
  }

  function missionRow(m) {
    return `<div class="ea-admin-row" style="flex-direction:column;align-items:stretch;gap:6px">
      <div class="ea-row">
        <div><b>${EA.esc(m.name)}</b></div>
        <div class="ea-sub">${m.completed ? "✅ Accomplie" : EA.fmt(m.progress) + " / " + EA.fmt(m.target)}</div>
      </div>
      ${bar(m.progress, m.target)}
      <div class="ea-sub">🎁 ${EA.fmt(m.reward)} €A · ✨ ${m.xp_reward} XP</div>
    </div>`;
  }

  function section(title, missions) {
    if (!missions.length) return "";
    return `<div class="ea-section-title">${title}</div>
      <div class="ea-card">${missions.map(missionRow).join("")}</div>`;
  }

  EA.sub({
    tab: "economie", id: "missions", icon: "flag", label: "Missions", order: 15,
    async render() {
      const [m, summary] = await Promise.all([EA.api("/missions"), EA.api("/missions/summary")]);
      const blockedHtml = m.blocked.length ? `
        <div class="ea-section-title">Bloquées (cargo insuffisant)</div>
        <div class="ea-card">
          <p class="ea-sub">Véhicule actif : ${EA.fmt(m.vehicle_cargo)} cargo${m.has_vehicle ? "" : " · aucun véhicule actif"}</p>
          ${m.blocked.map((b) => `<div class="ea-admin-row">
            <div><b>${EA.esc(b.name)}</b></div>
            <div class="ea-sub">⛔ nécessite ${EA.fmt(b.cargo_required || 0)} de cargo</div>
          </div>`).join("")}
        </div>` : "";
      return `
        <div class="ea-card ea-center">
          <div class="ea-fortune" style="font-size:22px">${summary.completed_count} accomplie(s)</div>
          <p class="ea-sub">Déjà versé : ${EA.fmt(summary.total_coins)} €A · ${summary.total_xp} XP</p>
        </div>
        ${section("Quotidiennes", m.daily)}
        ${section("Hebdomadaires", m.weekly)}
        ${blockedHtml}
        <p class="ea-sub" style="text-align:center;margin-top:8px">
          Les récompenses sont versées automatiquement dès qu'une mission est complétée.
        </p>`;
    },
  });
})();
