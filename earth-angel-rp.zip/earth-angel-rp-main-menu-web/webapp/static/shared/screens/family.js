// screens/family.js — Social › Famille & mariage, partagé Telegram/Web.
(() => {
  function personName(x) { return EA.esc(x?.name || x?.full_name || `Joueur ${x?.user_id ?? "?"}`); }
  function renderFamily(fam) {
    if (!fam) return `<div class="ea-card"><div class="ea-title">👨‍👩‍👧 Créer un clan familial</div><p class="ea-sub">Coût : ${EA.fmt(30000)} €A</p><input class="ea-input" id="family-name" maxlength="40" placeholder="Nom du clan" /><button class="ea-btn" id="family-create" style="margin-top:8px">Fonder le clan</button></div>`;
    const founder = fam.role === "Fondateur";
    const candidates = fam.members.filter((m) => Number(m.user_id) !== Number(fam.founder_id));
    const leadership = founder
      ? `${candidates.length ? `<div class="ea-card" style="margin-top:10px"><p class="ea-sub">Transférer définitivement le rôle de fondateur à un membre du clan.</p><select class="ea-input" id="family-transfer-target">${candidates.map((m) => `<option value="${Number(m.user_id)}">${personName(m)}</option>`).join("")}</select><button class="ea-btn secondary" id="family-transfer" style="margin-top:8px">Transférer le leadership</button></div>` : ""}<button class="ea-btn danger" id="family-dissolve" style="margin-top:8px">Dissoudre le clan</button>`
      : "";
    return `<div class="ea-card"><div class="ea-title">👨‍👩‍👧 ${EA.esc(fam.name)}</div><p class="ea-sub">Rôle : ${EA.esc(fam.role)} · ${fam.members.length} membre(s)</p>${fam.members.map((m) => `<div class="ea-list-row"><div class="ic">👤</div><div><div class="t">${personName(m)}</div><div class="d">${EA.esc(m.role)}</div></div></div>`).join("")}<input class="ea-input" id="family-invite-target" type="number" placeholder="ID du joueur à inviter" /><button class="ea-btn secondary" id="family-invite" style="margin-top:8px">Inviter dans le clan</button>${leadership}<button class="ea-btn danger" id="family-leave" style="margin-top:8px">Quitter le clan</button></div>`;
  }
  function renderHome() {
    return EA.api("/family/home").then((r) => {
      const marriage = r.marriage
        ? `<div class="ea-card accent"><div class="ea-title">💍 Mariage</div><p class="ea-sub">Tu es marié(e) avec <b>${personName(r.marriage.partner)}</b>.</p><button class="ea-btn danger" id="family-divorce">Divorcer · ${EA.fmt(r.costs.divorce)} €A</button></div>`
        : `<div class="ea-card"><div class="ea-title">💍 Mariage</div><p class="ea-sub">Demande ou accepte un mariage avec un autre joueur majeur.</p><input class="ea-input" id="family-marriage-target" type="number" placeholder="ID du joueur" /><button class="ea-btn" id="family-marriage-request" style="margin-top:8px">Demander · ${EA.fmt(r.costs.marriage)} €A</button>${r.marriage_request ? `<div class="ea-card" style="margin-top:10px"><p class="ea-sub">💌 Demande de <b>${personName(r.marriage_request)}</b></p><button class="ea-btn" id="family-marriage-accept">Accepter · ${EA.fmt(r.costs.marriage)} €A</button></div>` : ""}</div>`;
      const invites = r.family_invites?.length ? `<div class="ea-card"><div class="ea-title">📨 Invitations</div>${r.family_invites.map((i) => `<div class="ea-row" style="margin-top:8px"><span>${EA.esc(i.name)} · par ${personName(i)}</span><button class="ea-pill-btn gold" data-family-join="${i.family_id}">Rejoindre</button></div>`).join("")}</div>` : "";
      const adoptedChildren = r.adoptions?.children || [];
      const parent = r.adoptions?.parent;
      const tree = `<div class="ea-card"><div class="ea-title">🌳 Adoption & arbre familial</div><p class="ea-sub">Un adulte de 25 ans ou plus peut adopter un joueur inscrit de moins de 20 ans. Coût : ${EA.fmt(r.adoptions.cost)} €A · maximum ${r.adoptions.max_children} enfants.</p>${parent ? `<p class="ea-sub">Tu es l’enfant adoptif de <b>${personName(parent)}</b>.</p>` : ""}${adoptedChildren.length ? adoptedChildren.map((child) => `<div class="ea-list-row"><div class="ic">🧒</div><div><div class="t">${personName(child)}</div><div class="d">Enfant adoptif · ${child.age} ans</div></div></div>`).join("") : `<p class="ea-sub">Aucun enfant adopté pour le moment.</p>`}<input class="ea-input" id="family-adopt-target" type="number" placeholder="ID du joueur à adopter" /><button class="ea-btn secondary" id="family-adopt" style="margin-top:8px">Adopter</button></div>`;
      return marriage + renderFamily(r.family) + invites + tree;
    });
  }
  async function action(path, body) { const r = await EA.post(path, body); EA.toast(r.message, "success"); EA.refresh(); }
  function bind() {
    const q = document.getElementById("family-marriage-request");
    if (q) EA.act(q, () => action("/family/marriage/request", { target_id: Number(document.getElementById("family-marriage-target").value) }));
    const a = document.getElementById("family-marriage-accept"); if (a) EA.act(a, () => action("/family/marriage/accept"));
    const d = document.getElementById("family-divorce"); if (d) EA.act(d, async () => { if (await EA.confirm("Confirmer le divorce ?", { danger: true, ok: "Divorcer" })) action("/family/marriage/divorce"); });
    const c = document.getElementById("family-create"); if (c) EA.act(c, () => action("/family/create", { name: document.getElementById("family-name").value }));
    const i = document.getElementById("family-invite"); if (i) EA.act(i, () => action("/family/invite", { target_id: Number(document.getElementById("family-invite-target").value) }));
    const l = document.getElementById("family-leave"); if (l) EA.act(l, async () => { if (await EA.confirm("Quitter ce clan ?", { danger: true, ok: "Quitter" })) action("/family/leave"); });
    const adopt = document.getElementById("family-adopt"); if (adopt) EA.act(adopt, () => action("/family/adopt", { target_id: Number(document.getElementById("family-adopt-target").value) }));
    const transfer = document.getElementById("family-transfer"); if (transfer) EA.act(transfer, async () => {
      const targetId = Number(document.getElementById("family-transfer-target").value);
      if (await EA.confirm("Le rôle de fondateur sera transféré définitivement. Continuer ?", { danger: true, ok: "Transférer" })) action("/family/transfer", { target_id: targetId });
    });
    const dissolve = document.getElementById("family-dissolve"); if (dissolve) EA.act(dissolve, async () => {
      if (await EA.confirm("Dissoudre définitivement le clan et retirer tous ses membres et invitations ? Cette action est irréversible.", { danger: true, ok: "Dissoudre" })) action("/family/dissolve");
    });
    EA.onAll("[data-family-join]", (b) => action("/family/join", { family_id: Number(b.dataset.familyJoin) }));
  }
  EA.sub({ tab: "social", id: "family", icon: "heart", label: "Famille", order: 40, render: renderHome, bind });
})();
