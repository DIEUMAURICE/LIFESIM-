// screens/life.js — Ville › Vie : état vital, dormir, gym, repas, routine, journal.
(() => {
  function vital(label, v) {
    const tone = v.value < 25 ? "low" : v.value < 55 ? "mid" : "";
    return `<div class="ea-vital">
      <div class="ea-vital-top"><span class="n">${label}</span><span class="v">${v.value}% · ${EA.esc(v.label)}</span></div>
      <div class="ea-bar-track"><div class="ea-bar-fill ${tone}" style="width:${v.value}%"></div></div>
    </div>`;
  }

  async function openMeals() {
    const c = await EA.api("/life/meals");
    const rows = c.meals.map((m) => `
      <div class="ea-admin-row">
        <div><div>${m.emoji} <b>${EA.esc(m.name)}</b> ${"⭐".repeat(m.stars)}</div>
          <div class="ea-sub">${EA.fmt(m.cost)} €A ${m.blocked ? "· ⛔ " + EA.esc(m.blocked) : ""}</div></div>
        <button class="ea-pill-btn gold" data-eat="${EA.esc(m.key)}" ${m.blocked ? "disabled" : ""}>Manger</button>
      </div>`).join("");
    const s = EA.sheet(`
      <div class="ea-row"><b>🍽️ Repas</b><span class="ea-pill-btn" data-close>Fermer ✕</span></div>
      ${rows}`);
    s.el.classList.add("tall");
    s.el.querySelector("[data-close]").onclick = s.close;
    EA.onAll("[data-eat]", async (b) => {
      try {
        const r = await EA.post("/life/eat", { meal_key: b.dataset.eat });
        EA.toast(r.message.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(), "success");
        s.close();
        EA.refresh();
      } catch (e) {
        EA.toast(e.message, "error");
      }
    }, s.el);
  }

  EA.sub({
    tab: "jeux", id: "vie", icon: "heart", label: "Vie", order: 5,
    async render() {
      const [st, routine] = await Promise.all([EA.api("/life/status"), EA.api("/life/routine")]);
      const v = st.vitals;
      return `
        <div class="ea-card">
          ${vital("❤️ Santé", v.health)}
          ${vital("⚡ Énergie", v.energy)}
          ${vital("😊 Bonheur", v.happiness)}
          ${vital("🍽️ Faim", v.hunger)}
          ${vital("😰 Stress", { value: v.stress.value, label: v.stress.label })}
        </div>
        ${st.hospital_seconds_left > 0 ? `<div class="ea-card ea-center"><p class="ea-sub">🏥 Hospitalisé(e) encore ${EA.fmtMin(st.hospital_seconds_left)}</p></div>` : ""}
        ${st.gym_seconds_left > 0 ? `<div class="ea-card ea-center"><p class="ea-sub">⏳ Prochaine séance de gym dans environ ${EA.fmtMin(st.gym_seconds_left)}.</p></div>` : ""}
        <div class="ea-card" style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="ea-btn" id="life-sleep">🛌 Dormir</button>
          <button class="ea-btn secondary" id="life-gym" ${st.gym_seconds_left > 0 ? "disabled" : ""}>${st.gym_seconds_left > 0 ? `💪 Gym · encore ${EA.fmtMin(st.gym_seconds_left)}` : "💪 Gym"}</button>
          <button class="ea-btn secondary" id="life-eat">🍽️ Manger</button>
        </div>
        ${routine.actions.length ? `
          <div class="ea-section-title">Routine recommandée</div>
          <div class="ea-card">
            ${routine.actions.map((a) => `<div class="ea-admin-row">
              <div>${a.urgent ? "🔴" : "🔵"} <b>${EA.esc(a.label)}</b> — ${EA.esc(a.reason)}</div>
            </div>`).join("")}
          </div>` : `<div class="ea-card ea-center"><p class="ea-sub">🏆 Tu es au top !</p></div>`}`;
    },
    bind() {
      const sleep = document.getElementById("life-sleep");
      if (sleep) EA.act(sleep, async () => {
        const r = await EA.post("/life/sleep");
        EA.toast(`⚡ Énergie ${r.energy_before}% → ${r.energy_after}%`, "success");
        EA.refresh();
      });
      const gym = document.getElementById("life-gym");
      if (gym) EA.act(gym, async () => {
        const r = await EA.post("/life/gym");
        EA.toast(`💪 Séance terminée · +${r.xp} XP${r.force_boost ? " · +1 Force !" : ""}`, "success");
        EA.refresh();
      });
      const eat = document.getElementById("life-eat");
      if (eat) eat.onclick = openMeals;
    },
  });
})();
