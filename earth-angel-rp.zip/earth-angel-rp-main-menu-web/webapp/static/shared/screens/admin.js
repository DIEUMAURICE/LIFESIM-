// screens/admin.js — Panneau staff (bloc de l'onglet Plus) : recherche et gestion de comptes.
(() => {
  async function adminSearch() {
    const q = document.getElementById("adm-search").value.trim();
    const box = document.getElementById("adm-results");
    box.innerHTML = `<div class="ea-skel"></div><div class="ea-skel" style="width:70%"></div>`;
    try {
      const r = await EA.api("/admin/search?q=" + encodeURIComponent(q));
      if (!r.results.length) { box.innerHTML = `<p class="ea-muted">Aucun joueur trouvé.</p>`; return; }
      box.innerHTML = r.results.map((p) => `
        <div class="ea-admin-row">
          <div>
            <div>${EA.esc(p.full_name || p.username || "Sans nom")} ${p.banned ? "🚫" : ""}</div>
            <div class="ea-sub">#${p.user_id} · 💵 ${EA.fmt(p.balance)}</div>
          </div>
          <button class="ea-pill-btn" data-id="${p.user_id}">Gérer</button>
        </div>`).join("");
      EA.onAll("[data-id]", (b) => renderAdminDetail(parseInt(b.dataset.id, 10)), box);
    } catch (e) { box.innerHTML = `<p class="ea-sub" style="color:var(--danger)">${EA.esc(e.message)}</p>`; }
  }

  async function renderAdminDetail(targetId) {
    const d = await EA.api(`/admin/user/${targetId}`);
    const u = d.user;
    const s = EA.sheet(`
      <div class="ea-row"><b>${EA.esc(u.full_name || u.username || "Joueur")} — #${u.user_id}</b>
        <span class="ea-pill-btn" id="adm-close">Fermer ✕</span></div>
      <p class="ea-sub">💵 ${EA.fmt(u.balance)} · ${u.banned ? "🚫 banni" : "✅ actif"} ${d.active_role ? "· " + EA.esc(d.active_role.role) : ""}</p>

      <div class="ea-section-title" style="margin-top:12px">Ajuster le solde</div>
      <div class="ea-grid">
        <button class="ea-btn secondary" id="adm-credit">+ Créditer</button>
        <button class="ea-btn secondary" id="adm-debit">− Débiter</button>
      </div>

      <div class="ea-section-title" style="margin-top:12px">Modifier un champ</div>
      <input class="ea-input" id="adm-field-name" placeholder="nom du champ (ex: health)" />
      <input class="ea-input" id="adm-field-value" placeholder="nouvelle valeur" />
      <button class="ea-btn secondary" style="margin-top:8px" id="adm-field-save">Enregistrer le champ</button>

      <div class="ea-section-title" style="margin-top:12px">Modération</div>
      <button class="ea-btn ${u.banned ? "secondary" : "danger"}" id="adm-ban-toggle">
        ${u.banned ? "Débannir ce joueur" : "Bannir ce joueur"}
      </button>`);
    s.el.classList.add("tall");
    const reopen = () => { s.close(); return renderAdminDetail(targetId); };
    const $ = (id) => s.el.querySelector("#" + id);

    $("adm-close").onclick = s.close;
    EA.act($("adm-credit"), async () => {
      const v = await EA.promptInt("Montant à créditer");
      if (!v) return;
      await EA.post(`/admin/user/${targetId}/balance`, { delta: v });
      EA.toast("Solde crédité ✅", "success"); reopen();
    });
    EA.act($("adm-debit"), async () => {
      const v = await EA.promptInt("Montant à débiter");
      if (!v) return;
      await EA.post(`/admin/user/${targetId}/balance`, { delta: -v });
      EA.toast("Solde débité ✅", "success"); reopen();
    });
    EA.act($("adm-field-save"), async () => {
      const field = $("adm-field-name").value.trim();
      const value = $("adm-field-value").value.trim();
      if (!field) return;
      await EA.post(`/admin/user/${targetId}/field`, { field, value });
      EA.toast("Champ modifié ✅", "success"); reopen();
    });
    EA.act($("adm-ban-toggle"), async () => {
      await EA.post(`/admin/user/${targetId}/ban`, { banned: !u.banned });
      EA.toast("Mis à jour ✅", "success"); reopen();
    });
  }

  EA.plusBlock({
    order: 10,
    render() {
      const staff = EA.staff();
      if (!staff) return "";
      return `
        <div class="ea-card">
          <div class="ea-row"><span class="ea-title" style="margin:0">Panneau admin</span>
            <span class="ea-role-badge">${EA.esc(staff.label)}</span></div>
          <p class="ea-sub">Chercher et modifier n'importe quel compte joueur.</p>
          <input class="ea-input" id="adm-search" placeholder="Pseudo, nom ou ID..." />
          <button class="ea-btn" id="adm-search-btn" style="margin-top:8px">Rechercher</button>
          <div id="adm-results" style="margin-top:10px"></div>
        </div>`;
    },
    bind() {
      const btn = document.getElementById("adm-search-btn");
      if (btn) btn.onclick = () => adminSearch();
      const input = document.getElementById("adm-search");
      if (input) input.addEventListener("keydown", (e) => { if (e.key === "Enter") adminSearch(); });
    },
  });
})();
