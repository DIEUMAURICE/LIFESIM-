// screens/home.js — Accueil partagé Web + Telegram.
// Les données restent issues des endpoints existants : aucun état de jeu n'est calculé côté client.
(() => {
  function vitalBar(icon, label, value) {
    const v = Math.max(0, Math.min(100, Number(value) || 0));
    const tone = v < 25 ? "low" : v < 55 ? "mid" : "";
    return `<div class="ea-vital"><div class="ea-vital-top"><span class="n">${EA.ico(icon, "sm")}${label}</span><span class="v">${v}%</span></div><div class="ea-bar-track"><div class="ea-bar-fill ${tone}" style="width:${v}%"></div></div></div>`;
  }

  function quick(icon, label, desc, go, ready = false) {
    return `<button class="ea-quick ${ready ? "ready" : ""}" data-go="${go}"><span class="ic">${EA.ico(icon)}</span><span><b>${label}</b><small>${desc}</small></span></button>`;
  }

  EA.tab({
    id: "moi", icon: "home", label: "Accueil", order: 10,
    async render({ profile, user: u }) {
      const ch = profile.character || {};
      const staff = EA.staff();
      let work = null, phone = null;
      try { work = await EA.api("/work/status"); } catch (e) {}
      try { phone = await EA.api("/phone/home"); } catch (e) {}
      const workReady = !!(work && work.work_ready && u.job);
      const k = Number(u.karma || 0);
      const karmaPosition = Math.max(0, Math.min(100, 50 + k / 2));
      const karmaLabel = k >= 25 ? "Lumineuse" : k <= -25 ? "Sombre" : "Équilibrée";
      const hour = phone?.datetime ? `${String(phone.datetime.hour).padStart(2, "0")}:${String(phone.datetime.minute).padStart(2, "0")}` : "08:42";
      const weather = phone?.datetime?.weather || "Éclaircies";
      const firstName = EA.esc(ch.first_name || "joueur");
      const fullName = `${EA.esc(ch.first_name || "")} ${EA.esc(ch.last_name || "")}`.trim();
      return `
        <div class="ea-eyebrow">LUNDI · ${hour} · CENTRE-VILLE</div>
        <h1 class="ea-welcome">Bonjour, ${firstName}.</h1>
        <p class="ea-page-sub ea-welcome-sub">Ta ville continue de vivre. À toi de choisir la suite.</p>
        <div class="ea-location"><span class="pin">${EA.ico("city", "sm")}</span><span><b>Quartier Central</b><small>${phone?.status ? EA.esc(phone.status) : "Tu es chez toi · aucun trajet en cours"}</small></span><strong>EN VILLE</strong></div>

        <div class="ea-dashboard-grid">
          <main>
            <section class="ea-hero ea-hero-dashboard">
              <div class="ea-hero-art"></div>
              <div class="ea-hero-in ea-hero-dashboard-in">
                <div class="ea-hero-row"><div><div class="ea-fortune-label">Ton quotidien</div><h2>Une nouvelle journée s’ouvre.</h2><p>Prends soin de toi, avance dans tes projets ou retrouve les autres en ville.</p></div><span class="ea-weather">☁ ${EA.esc(weather)}</span></div>
                <div class="ea-hero-actions"><button class="ea-btn" data-go="jeux">Explorer la ville&nbsp; →</button><button class="ea-btn secondary" data-go="economie:travail">Voir mes activités</button></div>
              </div>
            </section>
            <div class="ea-section-head"><span class="ea-eyebrow">ÉTAT DU PERSONNAGE</span><button class="ea-text-link" data-go="plus">Détails du profil →</button></div>
            <div class="ea-card ea-vitals">${vitalBar("heart", "Santé", u.health)}${vitalBar("bolt", "Énergie", u.energy)}${vitalBar("smile", "Humeur", u.happiness)}${vitalBar("food", "Faim", u.hunger)}</div>
            <div class="ea-section-head"><span class="ea-eyebrow">RACCOURCIS</span><button class="ea-text-link" data-go="economie:travail">Toutes les activités →</button></div>
            <div class="ea-quick-grid">${quick("briefcase", "Aller travailler", "Carrière · action disponible", "economie:travail", workReady)}${quick("food", "Prendre un repas", "Vie · besoin modéré", "jeux:vie")}${quick("bank", "Gérer mon argent", "Économie · compte actif", "economie:banque")}${quick("flag", "Voir mes missions", "Progression · en cours", "economie:missions")}</div>
          </main>
          <aside class="ea-dashboard-aside">
            <div class="ea-section-head compact"><span class="ea-eyebrow">TON PERSONNAGE</span></div>
            <div class="ea-profile-card"><div class="ea-avatar">${EA.esc(profile.avatar || "🧑")}</div><div><b>${fullName || "Ton personnage"}</b><small>${EA.esc(u.job || "Sans emploi")} · #${u.user_id}</small>${staff ? `<em>${EA.esc(staff.label)}</em>` : ""}</div><span class="ea-level"><small>Niveau</small><b>${u.level || 1}</b></span></div>
            <div class="ea-stats"><div><span>${EA.ico("coin", "sm")} Solde</span><b>${EA.fmt(u.balance)}</b><small>€A disponibles</small></div><div><span>${EA.ico("spark", "sm")} Prestige</span><b>${EA.fmt(u.prestige)}</b><small>points</small></div><div><span>${EA.ico("heart", "sm")} Karma</span><b>${k > 0 ? "+" : ""}${EA.fmt(k)}</b><small>${karmaLabel}</small></div></div>
            <div class="ea-section-head"><span class="ea-eyebrow">CIEL &amp; OMBRE</span></div>
            <div class="ea-card ea-karma"><div class="ea-balance-head"><b>${karmaLabel}</b><span>karma ${k > 0 ? "+" : ""}${EA.fmt(k)}</span></div><div class="ea-balance-track"><i style="left:${karmaPosition}%"></i></div><div class="ea-balance-ends"><span>Ombre</span><span>Ciel</span></div></div>
            <div class="ea-section-head"><span class="ea-eyebrow">DANS LE MONDE</span><button class="ea-text-link" data-go="social:fol">Voir le fil →</button></div>
            <div class="ea-feed"><span>☕</span><div><b>Une matinée au Café Central</b><small>Le fil de la ville · à l’instant</small></div><span>›</span></div>
            ${phone?.notifications_pending ? `<div class="ea-notice">${phone.notifications_pending} nouvelle${phone.notifications_pending > 1 ? "s" : ""} notification${phone.notifications_pending > 1 ? "s" : ""} à consulter.</div>` : ""}
          </aside>
        </div>`;
    },
    bind() {
      document.querySelectorAll("[data-go]").forEach((el) => el.onclick = () => {
        const [tab, sub] = el.dataset.go.split(":");
        EA.go(tab, sub);
      });
    },
  });
})();
