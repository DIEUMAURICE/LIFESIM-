// screens/arena.js — Jeux › Arène. Les deux clients utilisent les mêmes routes serveur.
(() => {
  const KEY = "ea_arena_match";
  const saved = () => localStorage.getItem(KEY) || "";

  function resultCard(r) {
    const winner = r.winner_id === r.challenger_id ? r.challenger_name : r.target_name;
    const loot = r.loot ? `<p>🎁 Butin : ${EA.esc(r.loot)}</p>` : "";
    return `<div class="ea-card"><b>⚔️ ${EA.esc(winner)} remporte le combat</b>
      <p class="ea-sub">${r.logs.map((line) => EA.esc(line)).join("<br>")}</p>
      <p>❤️ ${EA.esc(r.challenger_name)} : ${r.challenger_hp}% · ${EA.esc(r.target_name)} : ${r.target_hp}%</p>
      <p>💰 Pot versé : ${EA.fmt(r.pot)} €A · ✨ +100 XP au vainqueur</p>${loot}</div>`;
  }

  EA.sub({
    tab: "jeux", id: "arena", icon: "swords", label: "Arène", order: 20,
    async render() {
      const id = saved();
      let current = null;
      if (id) { try { current = await EA.api(`/arena/matches/${encodeURIComponent(id)}`); } catch (_) { localStorage.removeItem(KEY); } }
      return `<div class="ea-card">
        <div class="ea-page-title">⚔️ Défier un joueur</div>
        <p class="ea-sub">Le combat utilise les compétences, le niveau, le même pot et les mêmes récompenses sur Telegram et Web.</p>
        <label class="ea-label">ID du joueur défié</label>
        <input class="ea-input" id="arena-target" type="number" placeholder="ID Telegram ou ID Web">
        <label class="ea-label">Mise (€A)</label>
        <input class="ea-input" id="arena-bet" type="number" min="500" value="500">
        <button class="ea-btn" id="arena-create">Envoyer le défi</button>
      </div>
      ${current ? `<div class="ea-card"><b>Défi #${EA.esc(id)}</b><p class="ea-sub">Statut : ${EA.esc(current.status)}</p>
        ${current.status === "pending" ? `<button class="ea-btn secondary" id="arena-accept">Accepter ce défi</button>` : ""}</div>` : ""}`;
    },
    bind() {
      document.querySelector("#arena-create")?.addEventListener("click", async () => {
        const target_id = Number(document.querySelector("#arena-target")?.value);
        const bet = Number(document.querySelector("#arena-bet")?.value);
        if (!target_id || !bet) return EA.toast("Renseigne la cible et la mise.", "error");
        try {
          const r = await EA.post("/arena/challenges", { target_id, bet });
          localStorage.setItem(KEY, r.match_id);
          EA.toast("Défi envoyé.", "success");
          EA.refresh();
        } catch (e) { EA.toast(e.detail || e.message, "error"); }
      });
      document.querySelector("#arena-accept")?.addEventListener("click", async () => {
        try {
          const r = await EA.post(`/arena/matches/${encodeURIComponent(saved())}/accept`);
          localStorage.removeItem(KEY);
          document.querySelector("#arena-accept").outerHTML = resultCard(r);
        } catch (e) { EA.toast(e.detail || e.message, "error"); }
      });
    },
  });
})();
