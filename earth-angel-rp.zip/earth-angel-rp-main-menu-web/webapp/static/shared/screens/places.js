// screens/places.js — Déplacements partagés : EA.travel(destination) ouvre le choix du moyen de transport.
// Utilisé par tous les écrans qui demandent d'être sur place (hôpital, banque, etc.).
(() => {
  function mins(sec) { return sec < 60 ? sec + " s" : Math.ceil(sec / 60) + " min"; }

  EA.travel = async function travel(dest) {
    const o = await EA.api("/places/options?dest=" + encodeURIComponent(dest));
    const rows = o.options.map((x) => {
      const costs = [`${Number(x.km).toFixed(1)} km`, mins(x.duration_seconds)];
      if (x.energy) costs.push(`-${x.energy}% énergie`);
      if (x.fuel) costs.push(`-${x.fuel} carburant`);
      if (x.money) costs.push(`${EA.fmt(x.money)} €`);
      return `<div class="ea-admin-row">
        <div><div><b>${EA.esc(x.label)}</b></div>
          <div class="ea-sub">${EA.esc(costs.join(" · "))}${x.ok ? "" : " · ⛔ " + EA.esc(x.why)}</div></div>
        <button class="ea-pill-btn gold" data-mode="${EA.esc(x.mode)}" ${x.ok ? "" : "disabled"}>Partir</button>
      </div>`;
    }).join("");
    const s = EA.sheet(`
      <div class="ea-row"><b>${EA.esc(o.from_label)} → ${EA.esc(o.dest_label)}</b>
        <span class="ea-pill-btn" data-close>Fermer ✕</span></div>
      ${rows}`);
    s.el.classList.add("tall");
    s.el.querySelector("[data-close]").onclick = s.close;
    EA.onAll("[data-mode]", async (b) => {
      const r = await EA.post("/places/travel", { dest, mode: b.dataset.mode });
      EA.toast(r.message, "success");
      s.close();
      EA.refresh();
    }, s.el);
  };
})();
