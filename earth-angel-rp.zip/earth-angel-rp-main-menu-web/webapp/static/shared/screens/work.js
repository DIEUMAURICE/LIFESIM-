// screens/work.js — Économie › Travail : métier, mission, bonus quotidien.
(() => {
  async function renderJobCatalog() {
    const box = document.getElementById("job-catalog");
    if (!box) return;
    const c = await EA.api("/work/catalog");
    box.innerHTML = `<div class="ea-card">
      <div class="ea-title" style="font-size:15px">Métiers disponibles</div>
      ${c.jobs.map((j) => `
        <div class="ea-admin-row">
          <div><div>${j.emoji} <b>${EA.esc(j.name)}</b> ${j.locked ? "🔒" : ""}</div>
            <div class="ea-sub">${EA.fmt(j.min)}–${EA.fmt(j.max)} 💵 ${j.need ? "· diplôme " + EA.esc(j.need) : ""}</div></div>
          <button class="ea-pill-btn gold" data-choose="${EA.esc(j.name)}" ${j.locked ? "disabled" : ""}>Choisir</button>
        </div>`).join("")}
    </div>`;
    EA.onAll("[data-choose]", async (b) => {
      await EA.post("/work/job/choose", { job_name: b.dataset.choose });
      EA.toast(`💼 Métier : ${b.dataset.choose}`, "success");
      EA.refresh();
    }, box);
  }

  EA.sub({
    tab: "economie", id: "travail", icon: "briefcase", label: "Travail", order: 10,
    async render() {
      const [work, jobState] = await Promise.all([EA.api("/work/status"), EA.api("/work/job")]);
      let jobHtml;
      if (jobState.job) {
        const j = jobState.job;
        jobHtml = `
          <div class="ea-card">
            <div class="ea-row"><b>${j.emoji} ${EA.esc(j.name)}</b>
              <span class="ea-pill-btn" id="job-change">Changer</span></div>
            <p class="ea-sub">${EA.fmt(j.min)}–${EA.fmt(j.max)} 💵 · +${j.xp} XP par mission</p>
            <button class="ea-btn" id="work-btn" style="margin-top:8px" ${work.work_ready ? "" : "disabled"}>
              ${work.work_ready ? "Travailler maintenant" : "Repos : " + EA.fmtMin(work.work_seconds_left)}
            </button>
            <button class="ea-btn secondary" id="job-quit" style="margin-top:8px">Arrêter ce métier</button>
          </div>`;
      } else {
        jobHtml = `<div class="ea-card ea-center">
          <p class="ea-sub">${EA.esc(jobState.no_job_text || "Tu n'as pas de métier.")}</p>
          <button class="ea-btn" id="job-change" style="margin-top:8px">Choisir un métier</button>
        </div>`;
      }
      return `
        <div class="ea-section-title">Mon métier</div>
        ${jobHtml}
        <div id="job-catalog"></div>
        <div class="ea-section-title">Bonus du jour</div>
        <div class="ea-card">
          <p class="ea-sub" style="margin:0 0 10px">Un coup de pouce à réclamer toutes les 24 h réelles.</p>
          <button class="ea-btn secondary" id="daily-btn" ${work.daily_ready ? "" : "disabled"}>
            ${EA.ico("gift", "sm")}${work.daily_ready ? "Réclamer le bonus" : "Déjà réclamé aujourd'hui"}
          </button>
        </div>`;
    },
    bind() {
      const w = document.getElementById("work-btn");
      if (w) EA.act(w, async () => {
        const r = await EA.post("/work/do");
        if (r.success) EA.toast(`+💵 ${EA.fmt(r.gain)} et +${r.xp} XP (-${r.energy_cost}% énergie)`, "success");
        else EA.toast("Encore en repos", "error");
        EA.refresh();
      });
      const change = document.getElementById("job-change");
      if (change) EA.act(change, renderJobCatalog);
      const quit = document.getElementById("job-quit");
      if (quit) EA.act(quit, async () => {
        if (!(await EA.confirm("Arrêter ce métier ?", { danger: true, ok: "Arrêter" }))) return;
        await EA.post("/work/job/quit");
        EA.toast("Métier arrêté", "success");
        EA.refresh();
      });
      const d = document.getElementById("daily-btn");
      if (d) EA.act(d, async () => {
        const r = await EA.post("/work/daily");
        if (r.success) EA.toast(`Bonus : +💵 ${EA.fmt(r.gain)}`, "success");
        else EA.toast("Déjà réclamé", "error");
        EA.refresh();
      });
    },
  });
})();
