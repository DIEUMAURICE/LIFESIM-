// Véhicules : showroom, garage, sélection du véhicule actif, vente et entretien.
(() => {
  EA.sub({
    tab: "economie", id: "vehicules", icon: "🚗", label: "Véhicules", order: 45,
    async render() {
      const [catalog, garage] = await Promise.all([
        EA.api("/vehicles/catalog"), EA.api("/vehicles/garage"),
      ]);
      const garageRows = garage.vehicles.length ? garage.vehicles.map((v) => `
        <div class="ea-admin-row">
          <div><div>${v.emoji} <b>${EA.esc(v.veh_type)}</b> ${v.active ? "<span class='ea-pill-btn gold'>Actif</span>" : ""}</div>
            <div class="ea-sub">État ${v.condition}% · ${v.fuel_capacity ? `⛽ ${v.fuel}/${v.fuel_capacity}` : "sans carburant"}
              · ⚡ ${v.speed} · 📦 ${v.cargo} · ✨ ${v.luxury}${v.insured ? " · assuré" : ""}</div></div>
          <div class="ea-row">
            ${!v.active ? `<button class="ea-pill-btn" data-active="${v.veh_id}">Activer</button>` : ""}
            ${v.condition < 100 ? `<button class="ea-pill-btn" data-repair="${v.veh_id}">Réparer</button>` : ""}
            ${!v.insured ? `<button class="ea-pill-btn" data-insure="${v.veh_id}" data-quote="${v.insurance_quote}">Assurer · ${EA.fmt(v.insurance_quote)} €A</button>` : ""}
            <button class="ea-pill-btn" data-sell="${v.veh_id}" data-type="${EA.esc(v.veh_type)}" data-price="${v.resale_price}" data-condition="${v.condition}">Vendre · estimation ${EA.fmt(v.resale_price)} €A</button>
          </div>
        </div>`).join("") : `<p class="ea-muted">Ton garage est vide. Choisis une monture au showroom.</p>`;
      const catalogRows = catalog.items.map((v) => `
        <div class="ea-admin-row">
          <div><div>${v.emoji} <b>${EA.esc(v.type)}</b></div>
            <div class="ea-sub">${EA.fmt(v.price)} €A · entretien ${EA.fmt(v.maintenance)}/mois · prestige +${v.prestige}
              · vitesse ${v.speed} · cargo ${v.cargo} · luxe ${v.luxury}${v.fuel_capacity ? ` · réservoir ${v.fuel_capacity}` : ""}</div></div>
          <button class="ea-pill-btn gold" data-buy="${EA.esc(v.type)}">Acheter</button>
        </div>`).join("");
      return `
        <div class="ea-card">
          <div class="ea-title" style="font-size:15px">🚘 Garage (${garage.owned_count}/${garage.max_vehicles})</div>
          <p class="ea-sub">Solde : ${EA.fmt(garage.balance)} €A · les véhicules actifs servent notamment aux déplacements.</p>
          ${garageRows}
          ${garage.vehicles.some((v) => v.active && v.fuel_capacity > 0 && v.fuel < v.fuel_capacity)
            ? `<button class="ea-pill-btn gold" data-refuel>⛽ Faire le plein du véhicule actif</button>` : ""}
        </div>
        <div class="ea-card">
          <div class="ea-title" style="font-size:15px">🏁 Showroom</div>
          ${catalogRows}
        </div>`;
    },
    bind() {
      EA.onAll("[data-buy]", async (b) => {
        const r = await EA.post("/vehicles/buy", { veh_type: b.dataset.buy });
        EA.toast(`✅ ${r.bought} acheté pour ${EA.fmt(r.price)} €A`, "success"); EA.refresh();
      });
      EA.onAll("[data-active]", async (b) => {
        await EA.post("/vehicles/active", { veh_id: Number(b.dataset.active) });
        EA.toast("✅ Véhicule actif mis à jour", "success"); EA.refresh();
      });
      EA.onAll("[data-sell]", async (b) => {
        const amount = Number(b.dataset.price) || 0;
        const vehicle = b.dataset.type;
        if (!(await EA.confirm(`Vendre définitivement le ${vehicle} (${b.dataset.condition}% d’état) pour une reprise estimée de ${EA.fmt(amount)} €A ? Le prestige associé au type sera retiré et, s’il est actif, ce véhicule ne sera plus sélectionné.`, { ok: "Vendre définitivement" }))) return;
        const r = await EA.post("/vehicles/sell", { veh_id: Number(b.dataset.sell) });
        EA.toast(`💰 ${r.veh_type} vendu · +${EA.fmt(r.price)} €A`, "success"); EA.refresh();
      });
      EA.onAll("[data-repair]", async (b) => {
        if (!(await EA.confirm("Réparer ce véhicule ? Le coût dépend de son état, de son luxe et de son assurance.", { ok: "Réparer" }))) return;
        const r = await EA.post("/vehicles/repair", { veh_id: Number(b.dataset.repair) });
        EA.toast(`🔧 Réparation terminée · ${EA.fmt(r.price)} €A`, "success"); EA.refresh();
      });
      EA.onAll("[data-insure]", async (b) => {
        const quote = EA.fmt(Number(b.dataset.quote) || 0);
        if (!(await EA.confirm(`Assurer ce véhicule pour une prime unique de ${quote} €A ? Les réparations seront ensuite à moitié prix.`, { ok: "Assurer" }))) return;
        const r = await EA.post("/vehicles/insure", { veh_id: Number(b.dataset.insure) });
        EA.toast(`🛡️ Véhicule assuré · ${EA.fmt(r.price)} €A`, "success"); EA.refresh();
      });
      EA.onAll("[data-refuel]", async () => {
        if (!(await EA.confirm("Faire le plein du véhicule actif ? Le carburant coûte 10 €A par unité.", { ok: "Faire le plein" }))) return;
        const r = await EA.post("/vehicles/refuel", {});
        EA.toast(`⛽ ${r.vehicle} plein · ${EA.fmt(r.price)} €A`, "success"); EA.refresh();
      });
    },
  });
})();
