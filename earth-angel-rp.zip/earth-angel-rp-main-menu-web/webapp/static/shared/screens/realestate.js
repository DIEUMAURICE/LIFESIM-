// screens/realestate.js — Économie › Immobilier : mes biens, catalogue, achat/vente.
(() => {
  EA.sub({
    tab: "economie", id: "immobilier", icon: "home", label: "Immobilier", order: 40,
    async render() {
      const [catalog, mine] = await Promise.all([EA.api("/realestate/catalog"), EA.api("/realestate/mine")]);

      const ownedHtml = mine.properties.length
        ? mine.properties.map((p) => `
          <div class="ea-admin-row">
            <div><div>${p.emoji} <b>${EA.esc(p.prop_type)}</b></div>
              <div class="ea-sub">État : ${p.condition}% ${p.rented_to ? "· loué" : ""}</div></div>
            ${!p.rented_to ? `<button class="ea-pill-btn danger" data-sell="${p.prop_id}">Vendre</button>` : ""}
          </div>`).join("")
        : `<p class="ea-muted">Tu ne possèdes aucun bien.</p>`;

      const catalogHtml = catalog.items.map((it) => `
        <div class="ea-admin-row">
          <div><div>${it.emoji} <b>${EA.esc(it.type)}</b></div>
            <div class="ea-sub">${EA.fmt(it.price)} 💵 · loyer ${EA.fmt(it.rent)}/mois</div></div>
          <button class="ea-pill-btn gold" data-buy="${EA.esc(it.type)}">Acheter</button>
        </div>`).join("");

      return `
        <div class="ea-card">
          <div class="ea-title" style="font-size:15px">🏠 Mes biens (${catalog.owned_count}/${catalog.max_properties})</div>
          ${ownedHtml}
        </div>
        <div class="ea-card">
          <div class="ea-title" style="font-size:15px">🏘️ Catalogue</div>
          ${catalogHtml}
        </div>`;
    },
    bind() {
      EA.onAll("[data-buy]", async (b) => {
        const r = await EA.post("/realestate/buy", { prop_type: b.dataset.buy });
        EA.toast(`✅ Acheté : ${r.bought}`, "success");
        EA.refresh();
      });
      EA.onAll("[data-sell]", async (b) => {
        if (!(await EA.confirm("Vendre ce bien ? (-15% de frais d'agence)", { danger: true, ok: "Vendre" }))) return;
        const r = await EA.post("/realestate/sell", { prop_id: parseInt(b.dataset.sell, 10) });
        EA.toast(`✅ Vendu pour ${EA.fmt(r.price)}`, "success");
        EA.refresh();
      });
    },
  });
})();
