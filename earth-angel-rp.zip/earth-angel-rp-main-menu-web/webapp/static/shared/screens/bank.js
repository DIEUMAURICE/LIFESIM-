// screens/bank.js — Économie › Banque : ouvrir un compte, déposer, retirer.
(() => {
  EA.sub({
    tab: "economie", id: "banque", icon: "bank", label: "Banque", order: 20,
    async render() {
      const bank = await EA.api("/bank");
      const bankRows = bank.banks.map((b) => {
        const mine = bank.accounts.find((a) => a.bank_name === b.name);
        const name = EA.esc(b.name);
        return `
          <div class="ea-card" style="margin-bottom:10px">
            <div class="ea-row"><b>${name}</b><span class="ea-sub">${b.daily_interest_pct}%/jour</span></div>
            ${mine
              ? `<p class="ea-sub">Solde : 💵 ${EA.fmt(mine.balance)}</p>
                 <div class="ea-grid">
                   <button class="ea-btn secondary bq-deposit" data-bank="${name}">Déposer</button>
                   <button class="ea-btn secondary bq-withdraw" data-bank="${name}">Retirer</button>
                 </div>`
              : `<p class="ea-muted">Minimum requis : ${EA.fmt(b.min)}</p>
                 <button class="ea-btn bq-open" data-bank="${name}">Ouvrir un compte</button>`}
          </div>`;
      }).join("");

      return `
        <div class="ea-card accent">
          <div class="ea-fortune-label">Portefeuille</div>
          <div class="ea-fortune" style="font-size:28px;margin-bottom:0">${EA.fmt(bank.wallet_balance)}<span>€</span></div>
        </div>
        <div class="ea-section-title">Banques</div>
        ${bankRows}`;
    },
    bind() {
      EA.onAll(".bq-open", async (b) => {
        await EA.post("/bank/open", { bank_name: b.dataset.bank });
        EA.toast("Compte ouvert ✅", "success");
        EA.refresh();
      });
      EA.onAll(".bq-deposit", async (b) => {
        const amount = await EA.promptInt("Montant à déposer");
        if (!amount) return;
        await EA.post("/bank/deposit", { bank_name: b.dataset.bank, amount });
        EA.toast("Dépôt effectué ✅", "success");
        EA.refresh();
      });
      EA.onAll(".bq-withdraw", async (b) => {
        const amount = await EA.promptInt("Montant à retirer");
        if (!amount) return;
        await EA.post("/bank/withdraw", { bank_name: b.dataset.bank, amount });
        EA.toast("Retrait effectué ✅", "success");
        EA.refresh();
      });
    },
  });
})();
