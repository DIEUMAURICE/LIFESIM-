// screens/companies.js — Économie › Entreprises : ma société, fonder, classement, catalogue.
(() => {
  const CONTRACT_TYPES = ["service", "fourniture", "partenariat", "licence"];

  function contractRow(c, ownCompanyId) {
    const direction = c.from_company === ownCompanyId ? `→ ${EA.esc(c.to_name)}` : `← ${EA.esc(c.from_name)}`;
    const canRespond = c.to_company === ownCompanyId;
    return `<div class="ea-rank-row" data-contract="${c.contract_id}">
      <span>${direction} <span class="ea-sub">${EA.fmt(c.amount)} · ${c.duration}j · ${EA.esc(c.contract_type)} · ${EA.esc(c.status)}</span></span>
      ${canRespond ? `<span class="ea-grid" style="grid-auto-flow:column;gap:6px">
        <button class="ea-btn secondary" data-contract-accept="${c.contract_id}">✅</button>
        <button class="ea-btn secondary" data-contract-refuse="${c.contract_id}">❌</button>
        <button class="ea-btn secondary" data-contract-negotiate="${c.contract_id}">📝</button>
      </span>` : ""}
    </div>`;
  }

  function fusionRow(f, ownCompanyId) {
    const sent = f.from_company === ownCompanyId;
    return `<div class="ea-rank-row"><span>${sent ? `→ ${EA.esc(f.to_name)}` : `← ${EA.esc(f.from_name)}`} <span class="ea-sub">fusion · ${EA.esc(f.status)}</span></span>
      ${sent ? "" : `<span class="ea-grid" style="grid-auto-flow:column;gap:6px">
        <button class="ea-btn secondary" data-fusion-accept>✅</button>
        <button class="ea-btn secondary" data-fusion-refuse>❌</button>
      </span>`}</div>`;
  }

  function productRow(p) {
    const effect = p.effect_type ? ` · ${EA.esc(p.effect_type)} ${EA.esc(String(p.effect_value ?? ""))}` : "";
    const desc = p.description ? ` — ${EA.esc(p.description.slice(0, 40))}${p.description.length > 40 ? "…" : ""}` : "";
    return `<div class="ea-rank-row" data-product="${EA.esc(p.name)}">
      <span>${EA.esc(p.emoji || "📦")} <b>${EA.esc(p.name)}</b> <span class="ea-sub">stock ${p.stock}${effect}${desc}</span></span>
      <span class="ea-grid" style="grid-auto-flow:column;gap:6px">
        <button class="ea-btn secondary" data-price="${EA.esc(p.name)}" data-current="${p.price}">💲 ${EA.fmt(p.price)}</button>
        <button class="ea-btn secondary" data-delete="${EA.esc(p.name)}">🗑️</button>
      </span>
    </div>`;
  }

  function shareholderRow(h) {
    return `<div class="ea-rank-row"><span>${EA.esc(h.full_name)}</span><span>${h.shares} parts</span></div>`;
  }

  EA.sub({
    tab: "economie", id: "entreprises", icon: "city", label: "Entreprises", order: 30,
    async render() {
      const [mine, list] = await Promise.all([EA.api("/companies/mine"), EA.api("/companies")]);

      let mineHtml;
      let productsHtml = "";
      let sharesHtml = "";
      let contractsHtml = "";
      let fusionsHtml = "";
      if (mine.company) {
        const c = mine.company;
        mineHtml = `<div class="ea-card">
          <div class="ea-title" style="font-size:15px">🏢 ${EA.esc(c.name)}</div>
          <p class="ea-sub">${EA.esc(c.sector)} · niveau ${c.level} · réputation ${c.reputation}/100</p>
          <p class="ea-sub">👔 Poste : ${EA.esc(c.poste)} · 💰 Trésorerie : ${EA.fmt(c.treasury)}</p>
        </div>`;

        if (c.poste === "PDG") {
          const { products } = await EA.api("/companies/products");
          const rows = products.map(productRow).join("");
          productsHtml = `<div class="ea-card">
            <div class="ea-title" style="font-size:15px">📦 Catalogue de produits</div>
            ${rows || '<p class="ea-muted">Aucun produit actif.</p>'}
          </div>`;
        }

        const sh = await EA.api("/companies/shares");
        const rows2 = sh.shareholders.slice(0, 10).map(shareholderRow).join("");
        sharesHtml = `<div class="ea-card">
          <div class="ea-title" style="font-size:15px">📊 Parts &amp; capital</div>
          <p class="ea-sub">Valeur par part : ${EA.fmt(sh.share_price)} · Capitalisation : ${EA.fmt(sh.market_cap)}</p>
          ${rows2 || '<p class="ea-muted">Aucun actionnaire.</p>'}
          <div class="ea-grid" style="margin-top:8px;grid-auto-flow:column;gap:6px">
            <button class="ea-btn secondary" id="shares-buy">📈 Acheter</button>
            <button class="ea-btn secondary" id="shares-sell">📉 Vendre</button>
            ${c.poste === "PDG" ? '<button class="ea-btn secondary" id="shares-dividends">💎 Dividendes</button>' : ""}
          </div>
        </div>`;

        if (c.poste === "PDG") {
          const { contracts } = await EA.api("/companies/contracts");
          const rows3 = contracts.map((ct) => contractRow(ct, c.company_id)).join("");
          const otherCompanies = list.companies.filter((o) => o.name !== c.name);
          contractsHtml = `<div class="ea-card">
            <div class="ea-title" style="font-size:15px">📄 Contrats</div>
            ${rows3 || '<p class="ea-muted">Aucun contrat en cours.</p>'}
            <button class="ea-btn secondary" id="contract-propose" style="margin-top:8px">📄 Proposer un contrat</button>
          </div>`;
          const { fusions } = await EA.api("/companies/fusions");
          const rows4 = fusions.map((f) => fusionRow(f, c.company_id)).join("");
          fusionsHtml = `<div class="ea-card">
            <div class="ea-title" style="font-size:15px">🤝 Fusions</div>
            ${rows4 || '<p class="ea-muted">Aucune demande de fusion en attente.</p>'}
            <button class="ea-btn secondary" id="fusion-propose" style="margin-top:8px">🤝 Proposer une fusion</button>
          </div>
          <div class="ea-card">
            <div class="ea-title" style="font-size:15px">👑 Direction</div>
            <p class="ea-sub">Transférer l'entreprise à un employé : tu deviens Ex-PDG.</p>
            <button class="ea-btn secondary" id="company-transfer">👑 Transférer l'entreprise</button>
          </div>`;
        }
      } else {
        mineHtml = `<div class="ea-card">
          <div class="ea-title" style="font-size:15px">🏢 Fonder une entreprise</div>
          <p class="ea-sub">Coût : ${EA.fmt(5000000)} · tu en deviens PDG (100% des parts)</p>
          <input class="ea-input" id="co-name" placeholder="Nom de l'entreprise" />
          <select class="ea-input" id="co-sector">
            ${list.sectors.map((s) => `<option value="${EA.esc(s)}">${EA.esc(s)}</option>`).join("")}
          </select>
          <button class="ea-btn" id="co-create" style="margin-top:8px">Fonder</button>
        </div>`;
      }

      // Équipe, recrutement, salaires (gameplay/hiring.py)
      const apps = await EA.api("/companies/applications");
      let teamHtml = "";
      if (mine.company) {
        const c = mine.company, isOwner = c.poste === "PDG";
        const team = await EA.api("/companies/team");
        const members = team.members.map((m) => `
          <div class="ea-list-row"><div class="ic">👤</div>
            <div style="flex:1"><div class="t">${EA.esc(m.full_name)} — ${EA.esc(m.poste)}</div>
              <div class="d">💰 ${EA.fmt(m.base_salary)}/paie · ⚡ ${m.activity_score} pts</div></div>
            ${isOwner && m.user_id !== c.owner_id ? `<button class="ea-pill-btn" data-pay="${m.user_id}" data-name="${EA.esc(m.full_name)}">💰</button><button class="ea-pill-btn" data-fire="${m.user_id}" data-name="${EA.esc(m.full_name)}">🔨</button>` : ""}
          </div>`).join("");
        const pending = apps.pending.map((a) => `
          <div style="padding:8px 0;border-bottom:1px solid var(--line)">
            <div><b>#${a.app_id} ${EA.esc(a.full_name)}</b> <span class="ea-sub">🎓 ${EA.esc(a.diplome || "Sans diplôme")} · 🌟 ${a.karma} · prétention ${EA.fmt(a.desired_salary)}</span></div>
            <div class="ea-grid" style="margin-top:6px">
              <button class="ea-btn" data-app-accept="${a.app_id}" data-salary="${a.desired_salary}">✅ Accepter</button>
              <button class="ea-btn secondary" data-app-negotiate="${a.app_id}">💬 Contre-offre</button>
              <button class="ea-btn danger" data-app-refuse="${a.app_id}">❌ Refuser</button>
            </div></div>`).join("");
        teamHtml = `<div class="ea-card"><div class="ea-title" style="font-size:15px">👥 Équipe</div>${members}
          ${apps.pending.length ? `<div class="ea-section-title">Candidatures (${apps.pending.length})</div>${pending}` : ""}
          ${isOwner ? "" : `<button class="ea-btn danger" id="company-resign" style="margin-top:8px">👋 Démissionner</button>`}</div>`;
      } else if (apps.mine.length) {
        teamHtml = `<div class="ea-card"><div class="ea-title" style="font-size:15px">📨 Mes candidatures</div>` + apps.mine.map((a) => `
          <div style="padding:8px 0;border-bottom:1px solid var(--line)">
            <div><b>${EA.esc(a.company_name)}</b> — ${a.status === "negotiating" ? "contre-offre" : "en attente"} · ${EA.fmt(a.desired_salary)}</div>
            ${a.status === "negotiating" ? `<div class="ea-grid" style="margin-top:6px"><button class="ea-btn" data-offer="${a.app_id}:1">✅ Accepter</button><button class="ea-btn secondary" data-offer="${a.app_id}:0">❌ Refuser</button></div>` : ""}
          </div>`).join("") + `</div>`;
      }

      const rows = list.companies.slice(0, 20).map((c, i) =>
        `<div class="ea-rank-row"><span>#${i + 1} ${EA.esc(c.name)} <span class="ea-sub">(${EA.esc(c.sector)})</span></span>
          <span>💰 ${EA.fmt(c.treasury)}
            ${mine.company ? "" : `<button class="ea-pill-btn" data-apply="${EA.esc(c.name)}">✉️</button>`}
            <button class="ea-pill-btn" data-trade="buy" data-company="${EA.esc(c.name)}">📈</button>
            <button class="ea-pill-btn" data-trade="sell" data-company="${EA.esc(c.name)}">📉</button></span></div>`).join("");

      return mineHtml + teamHtml + productsHtml + sharesHtml + contractsHtml + fusionsHtml + `<div class="ea-card"><div class="ea-title" style="font-size:15px">📊 Marché des entreprises</div>${rows || '<p class="ea-muted">Aucune entreprise créée pour l\'instant.</p>'}</div>`;
    },
    bind() {
      const btn = document.getElementById("co-create");
      if (btn) {
        EA.act(btn, async () => {
          const name = document.getElementById("co-name").value.trim();
          const sector = document.getElementById("co-sector").value;
          if (!name) return EA.toast("Nom requis", "error");
          await EA.post("/companies/create", { name, sector });
          EA.toast("🏢 Entreprise fondée !", "success");
          EA.refresh();
        });
      }

      EA.onAll("[data-price]", (b) => {
        const name = b.dataset.price;
        const current = Number(b.dataset.current) || 0;
        const s = EA.sheet(`
          <p class="ea-sheet-msg">Nouveau prix conseillé pour ${EA.esc(name)}</p>
          <input class="ea-input" id="product-price" type="number" inputmode="numeric" min="0" value="${current}" placeholder="Prix" />
          <div class="ea-grid" style="margin-top:10px">
            <button class="ea-btn secondary" data-no>Annuler</button>
            <button class="ea-btn" data-yes>Enregistrer</button>
          </div>`);
        s.el.querySelector("[data-no]").onclick = s.close;
        s.el.querySelector("[data-yes]").onclick = async () => {
          const price = Math.max(0, parseInt(s.el.querySelector("#product-price").value, 10) || 0);
          s.close();
          await EA.post("/companies/products/price", { name, price });
          EA.toast("💰 Prix mis à jour", "success");
          EA.refresh();
        };
      });

      EA.onAll("[data-delete]", async (b) => {
        const name = b.dataset.delete;
        const s = EA.sheet(`
          <p class="ea-sheet-msg">Supprimer définitivement <b>${EA.esc(name)}</b> du catalogue ?</p>
          <div class="ea-grid" style="margin-top:10px">
            <button class="ea-btn secondary" data-no>Annuler</button>
            <button class="ea-btn" data-yes>Supprimer</button>
          </div>`);
        s.el.querySelector("[data-no]").onclick = s.close;
        s.el.querySelector("[data-yes]").onclick = async () => {
          s.close();
          await EA.post("/companies/products/delete", { name });
          EA.toast("🗑️ Produit supprimé", "success");
          EA.refresh();
        };
      });

      const buyBtn = document.getElementById("shares-buy");
      if (buyBtn) {
        EA.act(buyBtn, () => {
          const s = EA.sheet(`
            <p class="ea-sheet-msg">Nombre de parts à acheter</p>
            <input class="ea-input" id="shares-qty" type="number" inputmode="numeric" min="1" placeholder="Quantité" />
            <div class="ea-grid" style="margin-top:10px">
              <button class="ea-btn secondary" data-no>Annuler</button>
              <button class="ea-btn" data-yes>Acheter</button>
            </div>`);
          s.el.querySelector("[data-no]").onclick = s.close;
          s.el.querySelector("[data-yes]").onclick = async () => {
            const quantity = parseInt(s.el.querySelector("#shares-qty").value, 10) || 0;
            s.close();
            if (quantity <= 0) return EA.toast("Nombre invalide", "error");
            const r = await EA.post("/companies/shares/buy", { quantity });
            EA.toast(`📈 ${quantity} parts achetées (${EA.fmt(r.total_cost)})`, "success");
            EA.refresh();
          };
        });
      }

      const sellBtn = document.getElementById("shares-sell");
      if (sellBtn) {
        EA.act(sellBtn, () => {
          const s = EA.sheet(`
            <p class="ea-sheet-msg">Nombre de parts à vendre</p>
            <input class="ea-input" id="shares-qty" type="number" inputmode="numeric" min="1" placeholder="Quantité" />
            <div class="ea-grid" style="margin-top:10px">
              <button class="ea-btn secondary" data-no>Annuler</button>
              <button class="ea-btn" data-yes>Vendre</button>
            </div>`);
          s.el.querySelector("[data-no]").onclick = s.close;
          s.el.querySelector("[data-yes]").onclick = async () => {
            const quantity = parseInt(s.el.querySelector("#shares-qty").value, 10) || 0;
            s.close();
            if (quantity <= 0) return EA.toast("Nombre invalide", "error");
            const r = await EA.post("/companies/shares/sell", { quantity });
            EA.toast(`📉 ${quantity} parts vendues (${EA.fmt(r.total_value)})`, "success");
            EA.refresh();
          };
        });
      }

      // Équipe, recrutement, salaires
      const askNumber = (label, initial, go) => {
        const s = EA.sheet(`<p class="ea-sheet-msg">${label}</p>
          <input class="ea-input" id="num-in" type="number" inputmode="numeric" min="0" value="${initial}" />
          <div class="ea-grid" style="margin-top:10px"><button class="ea-btn secondary" data-no>Annuler</button><button class="ea-btn" data-yes>Valider</button></div>`);
        s.el.querySelector("[data-no]").onclick = s.close;
        s.el.querySelector("[data-yes]").onclick = async () => {
          const n = parseInt(s.el.querySelector("#num-in").value, 10);
          s.close();
          if (!Number.isFinite(n) || n < 0) return EA.toast("Montant invalide", "error");
          await go(n); EA.refresh();
        };
      };
      EA.onAll("[data-apply]", (b) => askNumber(`Candidature chez ${EA.esc(b.dataset.apply)} — prétention salariale (0 = à négocier)`, 0, async (n) => {
        await EA.post("/companies/apply", { company_name: b.dataset.apply, desired_salary: n });
        EA.toast("Candidature envoyée.", "success");
      }));
      EA.onAll("[data-offer]", async (b) => {
        const [app_id, accept] = b.dataset.offer.split(":");
        await EA.post("/companies/offer/respond", { app_id: Number(app_id), accept: accept === "1" });
        EA.toast(accept === "1" ? "Offre acceptée." : "Offre refusée.", "success"); EA.refresh();
      });
      EA.onAll("[data-app-accept]", (b) => askNumber("Salaire proposé", b.dataset.salary || 0, async (n) => {
        await EA.post("/companies/applications/accept", { app_id: Number(b.dataset.appAccept), salary: n });
        EA.toast("Employé recruté.", "success");
      }));
      EA.onAll("[data-app-negotiate]", (b) => askNumber("Contre-offre (salaire)", 0, async (n) => {
        await EA.post("/companies/applications/negotiate", { app_id: Number(b.dataset.appNegotiate), salary: n });
        EA.toast("Contre-offre envoyée.", "success");
      }));
      EA.onAll("[data-app-refuse]", async (b) => {
        await EA.post("/companies/applications/refuse", { app_id: Number(b.dataset.appRefuse) });
        EA.toast("Candidature refusée.", "success"); EA.refresh();
      });
      EA.onAll("[data-pay]", (b) => askNumber(`Nouveau salaire de ${EA.esc(b.dataset.name)}`, 0, async (n) => {
        await EA.post("/companies/pay", { target_user_id: Number(b.dataset.pay), salary: n });
        EA.toast("Salaire modifié.", "success");
      }));
      EA.onAll("[data-fire]", async (b) => {
        if (!(await EA.confirm(`Licencier ${b.dataset.name} ?`, { ok: "Licencier", danger: true }))) return;
        const r = await EA.post("/companies/fire", { target_user_id: Number(b.dataset.fire) });
        EA.toast(r.severance_paid ? `Licencié(e) — indemnité ${EA.fmt(r.severance)}` : "Licencié(e) (trésorerie insuffisante pour l'indemnité)", "success");
        EA.refresh();
      });
      const resignBtn = document.getElementById("company-resign");
      if (resignBtn) EA.act(resignBtn, async () => {
        if (!(await EA.confirm("Démissionner de l'entreprise ?", { ok: "Démissionner", danger: true }))) return;
        await EA.post("/companies/resign", {});
        EA.toast("Tu as démissionné.", "success"); EA.refresh();
      });

      // Parts d'une entreprise quelconque (comme /acheterparts "Nom" N sur le bot)
      EA.onAll("[data-trade]", async (b) => {
        const side = b.dataset.trade, company_name = b.dataset.company;
        let info = null;
        try { info = await EA.api(`/companies/shares/quote?name=${encodeURIComponent(company_name)}`); } catch (e) { return EA.toast(e.message, "error"); }
        const s = EA.sheet(`
          <p class="ea-sheet-msg">${side === "buy" ? "Acheter" : "Vendre"} des parts de <b>${EA.esc(info.company.name)}</b></p>
          <p class="ea-sub">Prix par part : ${EA.fmt(info.share_price)} · tu en détiens ${EA.fmt(info.my_shares)}</p>
          <input class="ea-input" id="trade-qty" type="number" inputmode="numeric" min="1" placeholder="Quantité" />
          <div class="ea-grid" style="margin-top:10px">
            <button class="ea-btn secondary" data-no>Annuler</button>
            <button class="ea-btn" data-yes>${side === "buy" ? "Acheter" : "Vendre"}</button>
          </div>`);
        s.el.querySelector("[data-no]").onclick = s.close;
        s.el.querySelector("[data-yes]").onclick = async () => {
          const quantity = parseInt(s.el.querySelector("#trade-qty").value, 10) || 0;
          s.close();
          if (quantity <= 0) return EA.toast("Nombre invalide", "error");
          const r = await EA.post(`/companies/shares/${side}`, { quantity, company_name });
          EA.toast(side === "buy" ? `📈 ${quantity} parts achetées (${EA.fmt(r.total_cost)})` : `📉 ${quantity} parts vendues (${EA.fmt(r.total_value)})`, "success");
          EA.refresh();
        };
      });

      const dividendsBtn = document.getElementById("shares-dividends");
      if (dividendsBtn) {
        EA.act(dividendsBtn, () => {
          const s = EA.sheet(`
            <p class="ea-sheet-msg">Pourcentage de la trésorerie à verser en dividendes</p>
            <input class="ea-input" id="dividends-pct" type="number" inputmode="numeric" min="0" max="100" value="10" placeholder="%" />
            <div class="ea-grid" style="margin-top:10px">
              <button class="ea-btn secondary" data-no>Annuler</button>
              <button class="ea-btn" data-yes>Verser</button>
            </div>`);
          s.el.querySelector("[data-no]").onclick = s.close;
          s.el.querySelector("[data-yes]").onclick = async () => {
            const percent = Math.max(0, Math.min(100, parseInt(s.el.querySelector("#dividends-pct").value, 10) || 0));
            s.close();
            const r = await EA.post("/companies/dividends", { percent });
            EA.toast(`💎 ${EA.fmt(r.dividend_total)} versés à ${r.shareholder_count} actionnaires`, "success");
            EA.refresh();
          };
        });
      }

      const proposeBtn = document.getElementById("contract-propose");
      if (proposeBtn) {
        EA.act(proposeBtn, async () => {
          const { companies } = await EA.api("/companies");
          const mine = await EA.api("/companies/mine");
          const options = companies
            .filter((o) => o.company_id !== mine.company.company_id)
            .map((o) => `<option value="${o.company_id}">${EA.esc(o.name)}</option>`).join("");
          const s = EA.sheet(`
            <p class="ea-sheet-msg">Proposer un contrat</p>
            <select class="ea-input" id="contract-target">${options}</select>
            <input class="ea-input" id="contract-amount" type="number" inputmode="numeric" min="1" placeholder="Montant" style="margin-top:8px" />
            <input class="ea-input" id="contract-duration" type="number" inputmode="numeric" min="1" placeholder="Durée (jours)" style="margin-top:8px" />
            <select class="ea-input" id="contract-type" style="margin-top:8px">
              ${CONTRACT_TYPES.map((t) => `<option value="${t}">${t}</option>`).join("")}
            </select>
            <div class="ea-grid" style="margin-top:10px">
              <button class="ea-btn secondary" data-no>Annuler</button>
              <button class="ea-btn" data-yes>Proposer</button>
            </div>`);
          s.el.querySelector("[data-no]").onclick = s.close;
          s.el.querySelector("[data-yes]").onclick = async () => {
            const target_company_id = Number(s.el.querySelector("#contract-target").value);
            const amount = parseInt(s.el.querySelector("#contract-amount").value, 10) || 0;
            const duration = parseInt(s.el.querySelector("#contract-duration").value, 10) || 0;
            const contract_type = s.el.querySelector("#contract-type").value;
            s.close();
            if (!target_company_id || amount <= 0 || duration <= 0) return EA.toast("Arguments invalides", "error");
            await EA.post("/companies/contracts/propose", { target_company_id, amount, duration, contract_type });
            EA.toast("📄 Contrat proposé", "success");
            EA.refresh();
          };
        });
      }

      const transferBtn = document.getElementById("company-transfer");
      if (transferBtn) {
        EA.act(transferBtn, () => {
          const s = EA.sheet(`
            <p class="ea-sheet-msg">ID du joueur (employé de l'entreprise) qui devient PDG</p>
            <input class="ea-input" id="transfer-target" type="number" inputmode="numeric" placeholder="ID joueur" />
            <div class="ea-grid" style="margin-top:10px">
              <button class="ea-btn secondary" data-no>Annuler</button>
              <button class="ea-btn" data-yes>Transférer</button>
            </div>`);
          s.el.querySelector("[data-no]").onclick = s.close;
          s.el.querySelector("[data-yes]").onclick = async () => {
            const target_user_id = parseInt(s.el.querySelector("#transfer-target").value, 10) || 0;
            s.close();
            if (!target_user_id) return EA.toast("ID requis", "error");
            const r = await EA.post("/companies/transfer", { target_user_id });
            EA.toast(`👑 ${r.company_name} transférée`, "success");
            EA.refresh();
          };
        });
      }

      const fusionBtn = document.getElementById("fusion-propose");
      if (fusionBtn) {
        EA.act(fusionBtn, async () => {
          const { companies } = await EA.api("/companies");
          const mine = await EA.api("/companies/mine");
          const options = companies.filter((o) => o.company_id !== mine.company.company_id)
            .map((o) => `<option value="${o.company_id}">${EA.esc(o.name)}</option>`).join("");
          const s = EA.sheet(`
            <p class="ea-sheet-msg">Proposer d'absorber une entreprise (vous payez sa valorisation)</p>
            <select class="ea-input" id="fusion-target">${options}</select>
            <div class="ea-grid" style="margin-top:10px">
              <button class="ea-btn secondary" data-no>Annuler</button>
              <button class="ea-btn" data-yes>Proposer</button>
            </div>`);
          s.el.querySelector("[data-no]").onclick = s.close;
          s.el.querySelector("[data-yes]").onclick = async () => {
            const target_company_id = Number(s.el.querySelector("#fusion-target").value);
            s.close();
            await EA.post("/companies/fusions/propose", { target_company_id });
            EA.toast("🤝 Demande de fusion envoyée", "success");
            EA.refresh();
          };
        });
      }

      EA.onAll("[data-fusion-accept]", async () => {
        const r = await EA.post("/companies/fusions/respond", { accept: true });
        EA.toast(`🤝 Fusion réussie : ${r.from_company_name} a absorbé ${r.target_name}`, "success");
        EA.refresh();
      });
      EA.onAll("[data-fusion-refuse]", async () => {
        await EA.post("/companies/fusions/respond", { accept: false });
        EA.toast("❌ Fusion refusée", "success");
        EA.refresh();
      });

      EA.onAll("[data-contract-accept]", async (b) => {
        await EA.post("/companies/contracts/respond", { contract_id: Number(b.dataset.contractAccept), accept: true });
        EA.toast("✅ Contrat accepté", "success");
        EA.refresh();
      });

      EA.onAll("[data-contract-refuse]", async (b) => {
        await EA.post("/companies/contracts/respond", { contract_id: Number(b.dataset.contractRefuse), accept: false });
        EA.toast("❌ Contrat refusé", "success");
        EA.refresh();
      });

      EA.onAll("[data-contract-negotiate]", (b) => {
        const contractId = Number(b.dataset.contractNegotiate);
        const s = EA.sheet(`
          <p class="ea-sheet-msg">Contre-offre pour le contrat #${contractId}</p>
          <input class="ea-input" id="negotiate-amount" type="number" inputmode="numeric" min="1" placeholder="Nouveau montant" />
          <input class="ea-input" id="negotiate-duration" type="number" inputmode="numeric" min="1" placeholder="Nouvelle durée (jours)" style="margin-top:8px" />
          <div class="ea-grid" style="margin-top:10px">
            <button class="ea-btn secondary" data-no>Annuler</button>
            <button class="ea-btn" data-yes>Envoyer</button>
          </div>`);
        s.el.querySelector("[data-no]").onclick = s.close;
        s.el.querySelector("[data-yes]").onclick = async () => {
          const amount = parseInt(s.el.querySelector("#negotiate-amount").value, 10) || 0;
          const duration = parseInt(s.el.querySelector("#negotiate-duration").value, 10) || 0;
          s.close();
          if (amount <= 0 || duration <= 0) return EA.toast("Arguments invalides", "error");
          await EA.post("/companies/contracts/negotiate", { contract_id: contractId, amount, duration });
          EA.toast("📝 Contre-offre envoyée", "success");
          EA.refresh();
        };
      });
    },
  });
})();
