// screens/sante.js — Ville › Santé : soins (ambulance, consultation, lit), hôpitaux, pharmacie, assurance.
// Côté patient uniquement ; « Mon poste » (soignants) reste sur le bot.
(() => {
  let view = "soins";
  const VIEWS = [["soins", "Soins"], ["hopitaux", "Hôpitaux"], ["pharmacie", "Pharmacie"], ["assurance", "Assurance"]];

  function chips() {
    return `<div class="ea-chips">` + VIEWS.map(([id, label]) =>
      `<button class="ea-chip ${view === id ? "on" : ""}" data-view="${id}">${label}</button>`).join("") + `</div>`;
  }

  function vital(label, v) {
    const n = Math.max(0, Math.min(100, v || 0));
    const tone = n < 25 ? "low" : n < 55 ? "mid" : "";
    return `<div class="ea-vital"><div class="ea-vital-top"><span class="n">${label}</span><span class="v">${n}%</span></div>
      <div class="ea-bar-track"><div class="ea-bar-fill ${tone}" style="width:${n}%"></div></div></div>`;
  }

  function insuranceLine(ins) {
    return ins
      ? `🛡️ Assurance <b>${EA.esc(ins.type)}</b> · ${ins.left} remboursement(s) restants · expire le ${EA.esc(ins.expires)}`
      : `🛡️ Aucune assurance`;
  }

  async function soins(s) {
    let top = `<div class="ea-card">${vital("❤️ Santé", s.health)}${vital("⚡ Énergie", s.energy)}
      <p class="ea-sub" style="margin:8px 0 0">📍 ${s.in_transit ? "En déplacement…" : EA.esc(s.location_label)}</p>
      <p class="ea-sub" style="margin:4px 0 0">${insuranceLine(s.insurance)}</p></div>`;
    if (s.hospitalized_seconds > 0) {
      top += `<div class="ea-card ea-center"><p class="ea-sub">🏥 Hospitalisé(e) encore <b>${EA.fmtMin(s.hospitalized_seconds)}</b>. Repose-toi !</p></div>`;
    }
    let actions;
    if (s.bed) {
      actions = `<p class="ea-sub">🛏️ Tu es allongé(e) sur un lit.</p>
        <div class="ea-grid"><button class="ea-btn" id="hp-getup">Se lever</button>
        <button class="ea-btn secondary" id="hp-bedquit">Partir sans soin</button></div>`;
    } else if (s.call) {
      actions = `<p class="ea-sub">🚑 Appel #${s.call.id} : ${s.call.status === "pending" ? "en attente d'un soignant" : "un soignant te prend en charge"}.</p>
        <button class="ea-btn secondary" id="hp-callcancel">Annuler mon appel</button>`;
    } else {
      actions = `<button class="ea-btn" id="hp-amb">🚑 Appeler une ambulance (gratuit)</button>
        ${s.at_hospital ? `<div class="ea-grid" style="margin-top:8px">
          <button class="ea-btn secondary" id="hp-consult">🩺 Consultation ici</button>
          <button class="ea-btn secondary" id="hp-bed">🛏️ Prendre un lit</button></div>` : `
        <button class="ea-btn secondary" id="hp-tohosp" style="margin-top:8px">🏥 Aller à un hôpital</button>`}`;
    }
    return top + `<div class="ea-card">${actions}
      <p class="ea-muted" style="margin:10px 0 0">Ambulance gratuite · consultation et médicaments payants (remboursés par l'assurance) · lit gratuit mais limité.</p></div>`;
  }

  function hopitaux(s) {
    return s.hospitals.map((h) => `
      <div class="ea-card" style="margin-bottom:10px">
        <div class="ea-row"><b>${EA.esc(h.name)}</b><span class="ea-sub">${h.kind === "grand" ? "grand" : "petit"}</span></div>
        <p class="ea-sub">🛏️ ${h.beds_free}/${h.beds_cap} lits libres · 🟢 ${h.on_duty} soignant(s) en service<br>
          👔 ${h.head ? EA.esc(h.head) : "<i>poste vacant</i>"}</p>
        ${h.here ? `<span class="ea-tag">📍 Tu es ici</span>`
          : `<button class="ea-btn secondary" data-goto="${EA.esc(h.location)}">📍 Y aller${h.distance_km != null ? " · " + Number(h.distance_km).toFixed(1) + " km" : ""}</button>`}
      </div>`).join("");
  }

  async function pharmacie() {
    const p = await EA.api("/sante/pharmacy");
    const rows = p.items.map((m) => `
      <div class="ea-admin-row">
        <div><div>${m.emoji} <b>${EA.esc(m.name)}</b></div>
          <div class="ea-sub">❤️ +${m.health}% · 💰 ${EA.fmt(m.price)}${m.discounted ? ` <s>${EA.fmt(m.base)}</s> 🛡️` : ""} · ${m.stock > 0 ? "📦 " + m.stock : "❌ rupture"}</div></div>
        <button class="ea-pill-btn gold" data-med="${EA.esc(m.name)}" ${m.stock > 0 ? "" : "disabled"}>Acheter</button>
      </div>`).join("");
    return `<div class="ea-card"><div class="ea-title" style="font-size:15px">💊 Médicaments</div>
      <p class="ea-muted" style="margin:0 0 8px">Fabriqués par les employés de la Santé publique ; chaque achat remplit le coffre qui paie leurs salaires.</p>${rows}</div>`;
  }

  async function assurance(s) {
    const p = await EA.api("/sante/insurance");
    const rows = p.plans.map((pl) => `
      <div class="ea-admin-row">
        <div><div>${pl.emoji} <b>${EA.esc(pl.key.charAt(0).toUpperCase() + pl.key.slice(1))}</b></div>
          <div class="ea-sub">${EA.fmt(pl.cost)}/mois · ${pl.coverage_pct}% pris en charge · ${pl.claims_limit} remboursements</div></div>
        <button class="ea-pill-btn gold" data-plan="${EA.esc(pl.key)}" data-cost="${pl.cost}">Souscrire</button>
      </div>`).join("");
    return `<div class="ea-card"><div class="ea-title" style="font-size:15px">🛡️ Assurance santé</div>
      <p class="ea-sub">${insuranceLine(s.insurance)}</p>
      <p class="ea-muted" style="margin:0 0 8px">Réduit le prix des médicaments et des consultations pendant 1 mois de jeu, dans la limite de remboursements du plan.</p>${rows}</div>`;
  }

  EA.sub({
    tab: "jeux", id: "sante", icon: "heart", label: "Santé", order: 30,
    async render() {
      const s = await EA.api("/sante/status");
      let body;
      if (view === "hopitaux") body = hopitaux(s);
      else if (view === "pharmacie") body = await pharmacie();
      else if (view === "assurance") body = await assurance(s);
      else body = await soins(s);
      return chips() + body;
    },
    bind() {
      document.querySelectorAll("[data-view]").forEach((b) => b.onclick = () => { view = b.dataset.view; EA.refresh(); });

      const doPost = (id, path, body) => {
        const el = document.getElementById(id);
        if (el) EA.act(el, async () => { const r = await EA.post(path, body); EA.toast(r.message, "success"); EA.refresh(); });
      };
      doPost("hp-amb", "/sante/ambulance");
      doPost("hp-callcancel", "/sante/call/cancel");
      doPost("hp-consult", "/sante/consult");
      doPost("hp-bed", "/sante/bed/take");
      doPost("hp-getup", "/sante/bed/leave", { force: false });
      const quit = document.getElementById("hp-bedquit");
      if (quit) EA.act(quit, async () => {
        if (!(await EA.confirm("Partir sans être soigné(e) ?", { danger: true, ok: "Partir" }))) return;
        const r = await EA.post("/sante/bed/leave", { force: true });
        EA.toast(r.message, "success"); EA.refresh();
      });

      const toHosp = document.getElementById("hp-tohosp");
      if (toHosp) toHosp.onclick = () => { view = "hopitaux"; EA.refresh(); };
      EA.onAll("[data-goto]", (b) => EA.travel(b.dataset.goto));

      EA.onAll("[data-med]", async (b) => {
        const r = await EA.post("/sante/pharmacy/buy", { med: b.dataset.med });
        EA.toast(r.message, "success"); EA.refresh();
      });
      EA.onAll("[data-plan]", async (b) => {
        if (!(await EA.confirm(`Souscrire l'assurance ${b.dataset.plan} pour ${EA.fmt(parseInt(b.dataset.cost, 10))} € ?`, { ok: "Souscrire" }))) return;
        const r = await EA.post("/sante/insurance/subscribe", { plan: b.dataset.plan });
        EA.toast(r.message, "success"); EA.refresh();
      });
    },
  });
})();
