// screens/travel.js — Voyages touristiques (distinct des déplacements locaux /places).
(() => {
  EA.sub({
    tab: "jeux", id: "voyages", icon: "✈️", label: "Voyages", order: 35,
    async render() {
      const [catalog, status, log] = await Promise.all([
        EA.api("/travel/catalog"), EA.api("/travel/status"), EA.api("/travel/log"),
      ]);
      const destinations = catalog.destinations.map((d) => `
        <div class="ea-admin-row">
          <div><div><b>${EA.esc(d.emoji)} ${EA.esc(d.name)}</b> ${d.visited ? "✅" : "🔒"}</div>
            <div class="ea-sub">${EA.fmt(d.actual_cost ?? d.cost)} €A · 😊 +${d.actual_happiness ?? d.happiness}% · ✨ +${d.xp} XP</div></div>
          <button class="ea-pill-btn gold" data-destination="${EA.esc(d.name)}"
            ${status.blocked || !d.affordable ? "disabled" : ""}>${d.affordable ? "Partir" : "Solde insuffisant"}</button>
        </div>`).join("");
      const fmtDuration = (seconds) => {
        const total = Math.max(0, Math.ceil(Number(seconds) || 0));
        const hours = Math.floor(total / 3600);
        const minutes = Math.floor((total % 3600) / 60);
        const secs = total % 60;
        return hours ? `${hours} h ${minutes} min` : minutes ? `${minutes} min` : `${secs} s`;
      };
      const journey = status.blocked
        ? `<div class="ea-travel-current"><b>⏳ Voyage et repos en cours</b>
            ${status.current_destination ? `<p>🌍 Destination : <b>${EA.esc(status.current_destination)}</b></p>` : ""}
            <p>Temps restant avant la fin du blocage : <b>${fmtDuration(status.remaining_seconds)}</b></p>
            ${Number.isFinite(status.travel_remaining_seconds) && Number.isFinite(status.rest_remaining_seconds)
              ? `<p class="ea-sub">Trajet restant : ${fmtDuration(status.travel_remaining_seconds)} · Repos restant : ${fmtDuration(status.rest_remaining_seconds)}</p>`
              : `<p class="ea-sub">Ce délai inclut le voyage et le repos obligatoire.</p>`}
          </div>`
        : "<p>✅ Prêt(e) à voyager.</p>";
      const carnet = log.trips.length
        ? log.trips.map((t) => `<div>${EA.esc(t.emoji)} <b>${EA.esc(t.name)}</b> — ${t.visits}× visité</div>`).join("")
        : "<p class=\"ea-sub\">Ton carnet est vide : aucun voyage effectué.</p>";
      return `
        <div class="ea-section-title">Agence de voyage</div>
        <div class="ea-card">
          <div class="ea-row"><b>💰 Solde</b><span>${EA.fmt(catalog.balance)} €A</span></div>
          <div class="ea-row"><b>✈️ Voyages effectués</b><span>${catalog.travel_count}</span></div>
          ${catalog.speed_multiplier < 1 ? "<p>⚡ Boost vitesse VIP actif (-50 %).</p>" : ""}
          ${journey}
        </div>
        <div class="ea-section-title">Destinations</div>
        <div class="ea-card">${destinations}</div>
        <div class="ea-section-title">Carnet de voyage</div>
        <div class="ea-card">${carnet}
          <p class="ea-sub">Total : ${log.total_trips} voyage(s)${log.globe_trotter ? " · 🏆 Globe-trotter accompli !" : ""}</p>
          ${log.unvisited.length ? `<p class="ea-sub">Non visitées : ${log.unvisited.map(EA.esc).join(", ")}</p>` : ""}
        </div>`;
    },
    bind() {
      EA.onAll("[data-destination]", async (button) => {
        if (!(await EA.confirm(`Partir pour ${button.dataset.destination} ? Le coût sera débité et le voyage ne peut pas être annulé.`, { ok: "Partir" }))) return;
        const result = await EA.post("/travel/go", { destination: button.dataset.destination });
        const eventText = result.event ? ` · ${result.event}` : "";
        EA.toast(`Voyage à ${result.destination} lancé : -${EA.fmt(result.cost)} €A, +${result.xp} XP${eventText}`, "success");
        EA.refresh();
      });
    },
  });
})();
