// screens/referral.js — Profil › Parrainage, partagé Telegram/Web.
(() => {
  async function render() {
    const r = await EA.api("/referrals");
    const rows = (r.rows || []).map((x) => `<div class="ea-list-row"><div class="ic">${x.activated_at ? "✅" : "⏳"}</div><div><div class="t">${EA.esc(x.full_name || "Filleul")}</div><div class="d">Niveau ${x.level || 1} · ${x.activated_at ? "activé" : "en attente"}</div></div></div>`).join("");
    return `<div class="ea-card"><div class="ea-title">🤝 Parrainage</div>
      <p class="ea-sub">Partage ton token personnel avec tes amis.</p>
      <div class="ea-row" style="gap:8px"><input class="ea-input" id="ref-token" readonly value="${EA.esc(r.link_token)}"><button class="ea-pill-btn gold" id="ref-copy">Copier</button></div>
      <p class="ea-sub">👥 ${r.total} inscrit(s) · ✅ ${r.activated} activé(s) · ⏳ ${r.pending} en attente<br>💰 Récompenses : ${EA.fmt(r.rewards)} €A</p>
      ${rows ? `<div class="ea-section-title">Derniers filleuls</div>${rows}` : ""}
      <div class="ea-section-title">Activer un parrainage reçu</div>
      <div class="ea-row" style="gap:8px"><input class="ea-input" id="ref-incoming" placeholder="ref_12345"><button class="ea-pill-btn" id="ref-join">Activer</button></div>
    </div>`;
  }
  function bind() {
    const copy = document.getElementById("ref-copy");
    if (copy) copy.onclick = async () => { await navigator.clipboard?.writeText(document.getElementById("ref-token").value); EA.toast("Token copié", "success"); };
    const join = document.getElementById("ref-join");
    if (join) EA.act(join, () => EA.post("/referrals/start", { token: document.getElementById("ref-incoming").value }).then(() => EA.refresh()));
  }
  EA.sub({ tab: "profil", id: "parrainage", icon: "users", label: "Parrainage", order: 65, render, bind });
})();
