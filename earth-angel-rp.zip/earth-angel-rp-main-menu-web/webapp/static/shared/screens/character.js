// screens/character.js — assistant de création du personnage (identique au bot).
(() => {
  let charOptions = null;

  EA.screens.wizard = async function renderCharacterWizard() {
    const root = EA.root();
    if (!charOptions) charOptions = await EA.api("/character/options");
    const state = await EA.api("/character");
    const missing = state.next_missing;

    if (!missing) {
      try {
        await EA.post("/character/finish");
        return EA.refresh();
      } catch (e) { EA.toast(e.message, "error"); }
    }

    const label = charOptions.labels[missing];
    const ch = state.character || {};
    let bodyHtml = "";

    if (missing === "first_name" || missing === "last_name") {
      bodyHtml = `
        <input class="ea-input" id="wiz-input" maxlength="${charOptions.name_max}"
          placeholder="${EA.esc(label)}" value="${EA.esc(ch[missing] || "")}" />
        <button class="ea-btn" style="margin-top:12px" id="wiz-next">Continuer ▶️</button>`;
    } else {
      const options = charOptions.fields[missing];
      bodyHtml = `<div class="ea-choice-grid" id="wiz-choices">` +
        Object.entries(options).map(([code, o]) =>
          `<div class="ea-choice" data-code="${code}"><span class="emoji">${o.emoji}</span>${EA.esc(o.label)}</div>`
        ).join("") + `</div>`;
    }

    const order = Object.keys(charOptions.labels);
    const at = order.indexOf(missing);
    const steps = order.map((_, i) => `<i class="${i < at ? "done" : i === at ? "now" : ""}"></i>`).join("");
    root.innerHTML = `
      <div class="ea-card accent">
        <div class="ea-steps">${steps}</div>
        <div class="ea-title">Qui es-tu sur Terre ?</div>
        <p class="ea-sub">Étape ${at + 1} sur ${order.length} : <b>${EA.esc(label)}</b>. Identité uniquement, aucun impact sur l'argent ou l'XP.</p>
        ${bodyHtml}
      </div>`;

    const submit = async (value) => {
      try {
        await EA.post("/character/field", { field: missing, value });
        EA.screens.wizard();
      } catch (e) { EA.toast(e.message, "error"); }
    };

    if (missing === "first_name" || missing === "last_name") {
      document.getElementById("wiz-next").onclick = () => {
        const v = document.getElementById("wiz-input").value.trim();
        if (!v) return EA.toast("Champ requis", "error");
        submit(v);
      };
    } else {
      document.querySelectorAll("#wiz-choices .ea-choice").forEach((el) => {
        el.onclick = () => submit(el.dataset.code);
      });
    }
  };
})();
