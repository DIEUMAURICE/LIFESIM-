// screens/social.js — Réseau RP : fil, stories, lives et interactions.
(() => {
  function postHtml(p) {
    const initial = EA.esc((p.author || "?").trim().charAt(0).toUpperCase());
    const text = EA.esc(p.text).replace(/(^|\s)#([0-9A-Za-zÀ-ÿ_]+)/g, '$1<span class="ea-hashtag">#$2</span>');
    return `<div class="ea-post" data-post="${p.id}"><div class="ea-post-head"><div class="ea-post-av">${initial}</div><div><div class="ea-post-name">${EA.esc(p.author)}</div><div class="ea-post-meta">${EA.esc(p.platform)} · ${EA.ago(p.created_at)}</div></div>${p.mine ? "" : `<button class="ea-pill-btn ${p.following ? "" : "gold"}" data-follow="${p.author_id}">${p.following ? "Abonné" : "Suivre"}</button>`}</div><div class="ea-post-text">${text}</div><div class="ea-post-foot"><button class="ea-like ${p.liked ? "on" : ""}" data-like="${p.id}">${EA.ico("heart", "sm")}<span>${EA.fmt(p.likes)}</span></button><button type="button" class="ea-post-count" data-comments="${p.id}">${EA.fmt(p.comments)} commentaire${p.comments > 1 ? "s" : ""} · Lire / commenter</button></div></div>`;
  }
  function feedRender(mode) {
    return async () => {
      const [home, feed] = await Promise.all([EA.api("/reseau/home"), EA.api(`/reseau/feed?mode=${mode}&limit=15`)]);
      const stats = `<div class="ea-social-stats"><div><b>${EA.fmt(home.followers)}</b><span>Abonnés</span></div><div><b>${EA.fmt(home.following)}</b><span>Abonnements</span></div><div><b>${EA.fmt(home.posts)}</b><span>Posts</span></div><div><b>${EA.fmt(home.likes)}</b><span>J'aime</span></div></div>`;
      if (!feed.enabled) return stats + `<div class="ea-card ea-center"><p class="ea-sub">Le réseau est momentanément fermé par le staff.</p></div>`;
      if (!feed.posts.length) return stats + `<div class="ea-card ea-center"><p class="ea-sub">${mode === "fol" ? "Ton fil est vide. Abonne-toi à des joueurs dans Explorer, ou publie ton premier post." : "Aucune publication pour l'instant."}</p>${mode === "fol" ? `<button class="ea-btn secondary" id="soc-explore">Découvrir des joueurs</button>` : ""}</div>`;
      return stats + feed.posts.map(postHtml).join("");
    };
  }
  async function creatorRender() {
    const [c, compose] = await Promise.all([EA.api("/reseau/creator"), EA.api("/reseau/compose")]);
    const stories = c.stories.length ? c.stories.map((s) => `<div class="ea-list-row"><div class="ic">📸</div><div><div class="t">${EA.esc(s.platform)} · story active</div><div class="d">${EA.esc(s.text)} · expire ${EA.ago(s.expires_at)}</div></div></div>`).join("") : `<p class="ea-muted">Aucune story active.</p>`;
    const lives = c.lives.length ? c.lives.map((l) => `<div class="ea-list-row"><div class="ic">🔴</div><div><div class="t">${EA.esc(l.author)} · ${EA.esc(l.platform)}</div><div class="d">Live actif · fin dans ${EA.fmt(Math.max(0, l.ends_at - Math.floor(Date.now()/1000)))} s</div></div><button class="ea-pill-btn gold" data-live-tip="${l.live_id}">Soutenir</button></div>`).join("") : `<p class="ea-muted">Aucun live actif.</p>`;
    const wait = compose.ready ? "" : `<p class="ea-muted">Prochaine publication dans ${Math.ceil(compose.game_seconds_left / 60)} min de jeu.</p>`;
    return `<div class="ea-card accent"><div class="ea-title">📸 Publier une story</div><div class="ea-chips">${compose.platforms.map((p,i) => `<button class="ea-chip ${i===0?"on":""}" data-story-platform="${EA.esc(p)}">${EA.esc(p)}</button>`).join("")}</div><textarea class="ea-textarea" id="story-text" maxlength="${compose.max}" placeholder="Le contenu de ta story..."></textarea><button class="ea-btn" id="story-send">Publier la story</button></div><div class="ea-card"><div class="ea-title">🎥 Lancer un live</div><p class="ea-sub">Communauté actuelle : ${EA.fmt(c.followers)} / 5 000 abonnés · coût : 1 000 €A/heure + 50 SocialCoins.</p><div class="ea-row" style="gap:8px"><select class="ea-input" id="live-platform">${compose.platforms.map((p) => `<option>${EA.esc(p)}</option>`).join("")}</select><select class="ea-input" id="live-duration"><option value="1">1 h</option><option value="2">2 h</option><option value="3">3 h</option><option value="4">4 h</option></select></div><button class="ea-btn" id="live-start" style="margin-top:8px">Démarrer le live</button></div><div class="ea-section-title">Mes stories</div><div class="ea-list">${stories}</div><div class="ea-section-title">Lives de la communauté</div><div class="ea-list">${lives}</div>${wait}`;
  }
  async function composeRender() {
    const c = await EA.api("/reseau/compose");
    const wait = c.ready ? "" : `<p class="ea-muted" style="margin:0 0 10px">Prochaine publication dans ${Math.ceil(c.game_seconds_left / 60)} min de jeu.</p>`;
    return `<div class="ea-section-title">Nouvelle publication</div><div class="ea-card accent"><div class="ea-chips" id="pub-platforms">${c.platforms.map((p,i) => `<button class="ea-chip ${i===0?"on":""}" data-platform="${EA.esc(p)}">${EA.esc(p)}</button>`).join("")}</div><textarea class="ea-textarea" id="pub-text" maxlength="${c.max}" placeholder="Que veux-tu dire au monde ?"></textarea><div class="ea-row" style="margin:6px 2px 12px"><span class="ea-muted" id="pub-count">0 / ${c.max}</span><span class="ea-muted">+${c.xp} XP · 1 post toutes les ${c.hours} h de jeu</span></div>${wait}<button class="ea-btn" id="pub-send" ${c.ready ? "" : "disabled"}>Publier</button></div>`;
  }
  async function pollsRender() {
    const r = await EA.api("/reseau/polls");
    if (r.enabled === false) return `<div class="ea-card ea-center"><p class="ea-sub">Le réseau est momentanément fermé par le staff.</p></div>`;
    const c = r.community;
    const scope = c ? `Communauté : ${EA.esc(c.name)} · rôle ${EA.esc(c.role)}. Les sondages des chefs et admins sont réservés aux membres.` : "Aucune communauté : ton sondage sera public.";
    const cards = (r.polls || []).map((p) => {
      const options = p.options.map((option, i) => {
        const count = p.counts[i] || 0;
        const percent = p.vote_count ? Math.round(count * 100 / p.vote_count) : 0;
        const selected = p.my_vote === i ? " · ton choix" : "";
        const vote = !p.closed && p.my_vote === null
          ? `<button class="ea-pill-btn gold" data-poll-vote="${p.poll_id}" data-option="${i}">Voter</button>` : "";
        return `<div class="ea-list-row"><div class="ic">${p.my_vote === i ? "✓" : "○"}</div><div><div class="t">${EA.esc(option)}${selected}</div><div class="d">${count} vote${count === 1 ? "" : "s"} · ${percent}%</div></div>${vote}</div>`;
      }).join("");
      const state = p.closed ? "Sondage clos" : `Clôture dans ${Math.ceil((p.seconds_left || 0) / 3600)} h de jeu`;
      const scopeTag = p.community_id ? ` · ${EA.esc(p.community_name || "Communauté")}` : " · Public";
      const close = p.can_close && !p.closed ? `<button class="ea-pill-btn" data-poll-close="${p.poll_id}">Clôturer</button>` : "";
      return `<div class="ea-card"><div class="ea-title">${EA.esc(p.question)}</div><p class="ea-muted">Par ${EA.esc(p.author)}${scopeTag} · ${p.vote_count} votant${p.vote_count === 1 ? "" : "s"} · ${state}</p><div class="ea-list">${options}</div>${close ? `<div style="margin-top:10px">${close}</div>` : ""}</div>`;
    }).join("");
    return `<div class="ea-card accent"><div class="ea-title">Créer un sondage</div><p class="ea-sub">2 à 4 options, une seule voix par joueur, durée de 2 jours de jeu. Maximum 3 sondages par jour.</p><p class="ea-muted">${scope}</p><input class="ea-input" id="poll-question" maxlength="120" placeholder="Ta question"><textarea class="ea-textarea" id="poll-options" maxlength="200" placeholder="Une option par ligne (2 à 4)"></textarea><button class="ea-btn" id="poll-create">Lancer le sondage</button></div>${cards || `<div class="ea-card ea-center"><p class="ea-sub">Aucun sondage en cours.</p></div>`}`;
  }
  function commentsHtml(data) {
    const items = (data.comments || []).map((c) => `<div class="ea-list-row"><div class="ic">💬</div><div><div class="t">${EA.esc(c.author)}</div><div class="d">${EA.ago(c.created_at)}</div><div class="ea-comment-text">${EA.esc(c.text)}</div></div></div>`).join("");
    return `<div class="ea-comments-panel"><div class="ea-muted">${EA.esc((data.post.text || "").slice(0, 100))}</div><div class="ea-list">${items || `<p class="ea-muted">Aucun commentaire. Sois le premier !</p>`}</div><textarea class="ea-textarea" data-comment-text maxlength="${data.max_length}" placeholder="Ton commentaire (max. ${data.max_length} caractères)"></textarea><div class="ea-row" style="justify-content:space-between;margin-top:6px"><span class="ea-muted">Maximum ${data.max_per_player} commentaires par joueur sur ce post</span><button class="ea-btn" type="button" data-comment-send="${data.post.id}">Commenter</button></div></div>`;
  }
  function bindCommentPanel(root, panel, postId) {
    panel.querySelector("[data-comment-send]")?.addEventListener("click", async () => {
      const textarea = panel.querySelector("[data-comment-text]");
      if (!textarea.value.trim()) return EA.toast("Écris un commentaire avant de l’envoyer.", "error");
      try {
        const result = await EA.post(`/reseau/posts/${postId}/comments`, { text: textarea.value });
        EA.toast(result.message, "success");
        const count = root.querySelector("[data-comments]");
        if (count) count.textContent = `${EA.fmt(result.comments)} commentaire${result.comments === 1 ? "" : "s"} · Lire / commenter`;
        const latest = await EA.api(`/reseau/posts/${postId}/comments`);
        panel.outerHTML = commentsHtml(latest);
        bindCommentPanel(root, root.querySelector(".ea-comments-panel"), postId);
      } catch (e) { EA.toast(e.detail || e.message || "Commentaire impossible.", "error"); }
    });
  }
  async function collabsRender() {
    const data = await EA.api("/reseau/collabs");
    const active = (data.active || []).map((c) => `<div class="ea-list-row"><div class="ic">🤝</div><div><div class="t">Avec ${EA.esc(c.other_name)} · ${EA.esc(c.type_label)}</div><div class="d">Active encore ${Math.ceil(c.seconds_left / 3600)} h</div></div></div>`).join("");
    const incoming = (data.incoming || []).map((r) => `<div class="ea-list-row"><div class="ic">📩</div><div><div class="t">${EA.esc(r.other_name)} propose ${EA.esc(r.type_label)}</div><div class="d">Durée : ${r.duration_h} h · En acceptant, la personne qui a proposé paiera ${EA.fmt(data.cost)} €A; vous gagnez chacun +100 abonnés.</div><div class="ea-row" style="gap:8px;margin-top:8px"><button class="ea-pill-btn gold" data-collab-respond="${r.request_id}" data-action="accept">Accepter</button><button class="ea-pill-btn" data-collab-respond="${r.request_id}" data-action="refuse">Refuser</button></div></div></div>`).join("");
    const outgoing = (data.outgoing || []).map((r) => `<div class="ea-list-row"><div class="ic">⏳</div><div><div class="t">En attente de ${EA.esc(r.other_name)} · ${EA.esc(r.type_label)}</div><div class="d">Tu paieras ${EA.fmt(data.cost)} €A seulement si la demande est acceptée.</div></div></div>`).join("");
    const players = (data.players || []).map((p) => `<option value="${p.user_id}">${EA.esc(p.name)} · ID ${p.user_id}</option>`).join("");
    const types = (data.types || []).map((t) => `<option value="${EA.esc(t.id)}">${EA.esc(t.label)}</option>`).join("");
    return `<div class="ea-card accent"><div class="ea-title">🤝 Proposer une collaboration</div><p class="ea-sub">Durée : ${data.duration_h} h de jeu · coût : ${EA.fmt(data.cost)} €A, débité du proposant uniquement si la demande est acceptée · +100 abonnés chacun.</p><label class="ea-label">Joueur cible (ID, y compris négatif pour un compte Web, ou @pseudo)</label><input class="ea-input" id="collab-target" list="collab-players" placeholder="ID ou @pseudo"><datalist id="collab-players">${players}</datalist><label class="ea-label" style="margin-top:8px">Type</label><select class="ea-input" id="collab-type">${types}</select><button class="ea-btn" id="collab-create" style="margin-top:10px">Envoyer la demande</button></div><div class="ea-section-title">Collaboration active</div><div class="ea-list">${active || `<div class="ea-card ea-center"><p class="ea-sub">Aucune collaboration active.</p></div>`}</div><div class="ea-section-title">Demandes reçues</div><div class="ea-list">${incoming || `<div class="ea-card ea-center"><p class="ea-sub">Aucune demande en attente.</p></div>`}</div><div class="ea-section-title">Demandes envoyées</div><div class="ea-list">${outgoing || `<div class="ea-card ea-center"><p class="ea-sub">Aucune demande en attente.</p></div>`}</div>`;
  }
  async function act(path, body) { const r = await EA.post(path, body); EA.toast(r.message, "success"); EA.refresh(); }
  function bindSocial() {
    const pubText = document.getElementById("pub-text");
    if (pubText) { pubText.addEventListener("input", () => { document.getElementById("pub-count").textContent = pubText.value.length + " / " + pubText.maxLength; }); document.querySelectorAll("[data-platform]").forEach((b) => b.onclick = () => { document.querySelectorAll("[data-platform]").forEach((x) => x.classList.remove("on")); b.classList.add("on"); }); EA.act(document.getElementById("pub-send"), async () => { const platform = document.querySelector("[data-platform].on").dataset.platform; const r = await EA.post("/reseau/post", { platform, text: pubText.value }); EA.toast(`Publié ! +${EA.fmt(r.follower_gain)} abonnés · +${r.xp} XP`, "success"); EA.go("social", "fol"); }); }
    const ex = document.getElementById("soc-explore"); if (ex) ex.onclick = () => EA.go("social", "exp");
    EA.onAll("[data-like]", async (b) => { const r = await EA.post("/reseau/like", { post_id: Number(b.dataset.like) }); b.classList.toggle("on", r.liked); b.querySelector("span").textContent = EA.fmt(r.likes); });
    EA.onAll("[data-follow]", async (b) => { const r = await EA.post("/reseau/follow", { user_id: Number(b.dataset.follow) }); EA.toast(r.following ? "Tu suis maintenant ce joueur" : "Tu ne le suis plus", "success"); EA.refresh(); });
    EA.onAll("[data-comments]", async (b) => {
      const root = b.closest(".ea-post");
      const existing = root.querySelector(".ea-comments-panel");
      if (existing) { existing.remove(); return; }
      const postId = Number(b.dataset.comments);
      const loading = document.createElement("div"); loading.className = "ea-comments-panel"; loading.innerHTML = `<p class="ea-muted">Chargement des commentaires…</p>`; root.appendChild(loading);
      try {
        const data = await EA.api(`/reseau/posts/${postId}/comments`);
        loading.outerHTML = commentsHtml(data);
        bindCommentPanel(root, root.querySelector(".ea-comments-panel"), postId);
      } catch (e) { loading.innerHTML = `<p class="ea-muted">${EA.esc(e.detail || e.message || "Commentaires indisponibles.")}</p>`; }
    });
    const st = document.getElementById("story-send"); if (st) { document.querySelectorAll("[data-story-platform]").forEach((b) => b.onclick = () => { document.querySelectorAll("[data-story-platform]").forEach((x) => x.classList.remove("on")); b.classList.add("on"); }); EA.act(st, () => act("/reseau/story", { platform: document.querySelector("[data-story-platform].on").dataset.storyPlatform, text: document.getElementById("story-text").value })); }
    const ls = document.getElementById("live-start"); if (ls) EA.act(ls, () => act("/reseau/live", { platform: document.getElementById("live-platform").value, duration_h: Number(document.getElementById("live-duration").value) }));
    EA.onAll("[data-live-tip]", async (b) => { const amount = await EA.promptInt("Montant du don en €A"); if (amount) act("/reseau/live/tip", { live_id: Number(b.dataset.liveTip), amount }); });
    const create = document.getElementById("poll-create"); if (create) EA.act(create, async () => {
      const question = document.getElementById("poll-question").value;
      const options = document.getElementById("poll-options").value.split(/[\n|]/).map((x) => x.trim()).filter(Boolean).slice(0, 4);
      const r = await EA.post("/reseau/polls", { question, options });
      EA.toast(r.message, "success"); EA.refresh();
    });
    EA.onAll("[data-poll-vote]", async (b) => {
      const r = await EA.post("/reseau/polls/vote", { poll_id: Number(b.dataset.pollVote), option_index: Number(b.dataset.option) });
      EA.toast(r.message, "success"); EA.refresh();
    });
    EA.onAll("[data-poll-close]", async (b) => {
      if (!await EA.confirm("Clôturer ce sondage ?", { ok: "Clôturer" })) return;
      const r = await EA.post("/reseau/polls/close", { poll_id: Number(b.dataset.pollClose) });
      EA.toast(r.message, "success"); EA.refresh();
    });
    const collabCreate = document.getElementById("collab-create");
    if (collabCreate) collabCreate.addEventListener("click", async () => {
      const target = document.getElementById("collab-target").value.trim();
      if (!target) return EA.toast("Choisis un joueur cible.", "error");
      try {
        const r = await EA.post("/reseau/collabs", { target, collab_type: document.getElementById("collab-type").value });
        EA.toast(r.message, "success"); EA.refresh();
      } catch (e) { EA.toast(e.detail || e.message || "Demande impossible.", "error"); }
    });
    EA.onAll("[data-collab-respond]", async (b) => {
      const action = b.dataset.action;
      const prompt = action === "accept"
        ? "Accepter cette collaboration de 24 h ? Le proposant paiera 50 000 €A et vous gagnerez chacun 100 abonnés."
        : "Refuser cette demande de collaboration ? Aucun coût ne sera débité.";
      if (!await EA.confirm(prompt, { ok: action === "accept" ? "Accepter" : "Refuser" })) return;
      try {
        const r = await EA.post("/reseau/collabs/respond", { request_id: Number(b.dataset.collabRespond), action });
        EA.toast(r.message, "success"); EA.refresh();
      } catch (e) { EA.toast(e.detail || e.message || "Réponse impossible.", "error"); }
    });
  }
  EA.sub({ tab: "social", id: "fol", icon: "users", label: "Mon fil", order: 10, render: feedRender("fol"), bind: bindSocial });
  EA.sub({ tab: "social", id: "exp", icon: "spark", label: "Explorer", order: 20, render: feedRender("exp"), bind: bindSocial });
  EA.sub({ tab: "social", id: "more", icon: "phone", label: "Publier", order: 30, render: composeRender, bind: bindSocial });
  EA.sub({ tab: "social", id: "creator", icon: "bolt", label: "Stories & lives", order: 35, render: creatorRender, bind: bindSocial });
  EA.sub({ tab: "social", id: "polls", icon: "users", label: "Sondages", order: 40, render: pollsRender, bind: bindSocial });
  EA.sub({ tab: "social", id: "collabs", icon: "users", label: "Collaborations", order: 50, render: collabsRender, bind: bindSocial });
})();
