// screens/education.js — Carrière › Études & diplômes, compétences, cours et examen.
// Même service que le bot (gameplay/education.py) : aucune règle recalculée ici.
(() => {
  let view = "formations";
  const VIEWS = [["formations", "Formations"], ["competences", "Compétences"], ["cours", "Mes cours"], ["examen", "Examen"]];

  function chips() {
    return `<div class="ea-chips">` + VIEWS.map(([id, label]) =>
      `<button class="ea-chip ${view === id ? "on" : ""}" data-view="${id}">${label}</button>`).join("") + `</div>`;
  }

  function ongoingCard(o) {
    if (!o) return "";
    return `<div class="ea-card accent ea-center">
      <p class="ea-sub">📚 Formation en cours : <b>${EA.esc(o.diploma)}</b></p>
      <p class="ea-sub">📖 Cours révisés : ${o.revisions}/${o.max_revisions} · ${o.exam_ready ? "✅ examen disponible" : `⏳ examen dans ${EA.fmtMin(o.remaining_seconds)}`}</p>
      <div class="ea-grid" style="margin-top:8px">
        <button class="ea-btn secondary" id="edu-goto-revise" ${o.revisions >= o.max_revisions ? "disabled" : ""}>📖 Réviser</button>
        <button class="ea-btn" id="edu-goto-exam" ${o.exam_ready ? "" : "disabled"}>📝 Examen</button>
      </div>
    </div>`;
  }

  function formations(home) {
    const rows = home.diplomas.map((d) => {
      const status = d.obtained ? `<span class="ea-tag">✅ obtenu</span>`
        : d.is_next ? `<span class="ea-tag gold">👈 suivant</span>` : `<span class="ea-tag">🔒 verrouillé</span>`;
      return `<div class="ea-list-row ${d.locked ? "locked" : ""}">
        <div class="ic">🎓</div>
        <div><div class="t">${EA.esc(d.name)}</div>
          <div class="d">${EA.fmt(d.cost)} €A · ${EA.fmtMin(d.duration)} · ${Math.round(d.pass_rate * 100)}% réussite · ×${d.salary_bonus} salaire</div></div>
        <span class="end">${d.is_next ? `<button class="ea-pill-btn gold" data-enroll="${EA.esc(d.name)}">S'inscrire</button>` : status}</span>
      </div>`;
    }).join("");
    return ongoingCard(home.ongoing) + `<div class="ea-section-title">Formations</div><div class="ea-list">${rows}</div>`;
  }

  function competences(home) {
    const rows = home.skills.map((s) => `
      <div class="ea-admin-row">
        <div><div>🧠 <b>${EA.esc(s.name)}</b></div><div class="ea-sub">Niveau ${s.level} → ${s.level + 1}</div></div>
        <button class="ea-pill-btn gold" data-skill="${EA.esc(s.name)}" ${s.level >= 100 ? "disabled" : ""}>${s.level >= 100 ? "Max" : EA.fmt(s.cost) + " €A"}</button>
      </div>`).join("");
    return `<div class="ea-card"><div class="ea-title">🎯 Compétences</div><p class="ea-sub">Chaque niveau coûte plus cher que le précédent et donne +200 XP.</p></div>
      <div class="ea-list">${rows}</div>`;
  }

  async function cours() {
    const r = await EA.api("/education/courses");
    if (!r.courses.length) return `<div class="ea-card ea-center"><p class="ea-sub">Aucun cours révisé pour l'instant. Inscris-toi à une formation puis révise.</p></div>`;
    return `<div class="ea-list">` + r.courses.map((c) => `
      <div class="ea-list-row">
        <div class="ic">📖</div><div><div class="t">${EA.esc(c.title)}</div><div class="d">${EA.esc(c.theme)} · ${EA.esc(c.diploma)}</div></div>
      </div>`).join("") + `</div>`;
  }

  async function historyBlock() {
    const { history } = await EA.api("/education/exam/history");
    if (!history.length) return "";
    return `<div class="ea-section-title">Historique des examens</div><div class="ea-list">` + history.map((h) => `
      <div class="ea-list-row"><div class="ic">${h.success ? "🎓" : "😢"}</div>
        <div><div class="t">${EA.esc(h.diploma)} — ${h.score}/${h.total}${h.mention ? " · " + EA.esc(h.mention) : ""}</div>
        <div class="d">${h.success ? "Réussi" : `Échec (il fallait ${h.needed}/${h.total})`} · ${EA.ago(h.taken_at)}</div></div></div>`).join("") + `</div>`;
  }

  async function examen(home) {
    const past = await historyBlock();
    if (!home.ongoing) return `<div class="ea-card ea-center"><p class="ea-sub">Inscris-toi d'abord à une formation.</p></div>` + past;
    if (!home.ongoing.exam_ready) return `<div class="ea-card ea-center"><p class="ea-sub">⏳ Examen disponible dans ${EA.fmtMin(home.ongoing.remaining_seconds)}. Révise en attendant.</p></div>` + past;
    try {
      const ex = await EA.api("/education/exam", { method: "POST" });
      if (ex.finished) return examResult(ex);
      const letters = "ABCD";
      const choices = ex.choices.map((c, i) => `<button class="ea-choice" data-answer="${i}" style="text-align:left">${letters[i]}. ${EA.esc(c)}</button>`).join("");
      return `<div class="ea-card">
        <div class="ea-title" style="font-size:15px">📝 ${EA.esc(ex.diploma)} — Question ${ex.pos + 1}/${ex.total}</div>
        <p class="ea-sub">Il faut ${ex.needed}/${ex.total} bonnes réponses · score actuel ${ex.score}</p>
        <p style="margin:10px 0"><b>${EA.esc(ex.question)}</b></p>
        <div class="ea-choice-grid" style="grid-template-columns:1fr">${choices}</div>
      </div>`;
    } catch (e) {
      return `<div class="ea-card ea-center"><p class="ea-sub">${EA.esc(e.message)}</p></div>`;
    }
  }

  function examResult(r) {
    if (r.success) {
      return `<div class="ea-card ea-center">
        <div class="ea-title">🎉 Félicitations !</div>
        <p class="ea-sub">Tu as obtenu ton <b>${EA.esc(r.diploma)}</b> — mention ${EA.esc(r.mention)} (${r.score}/${r.total})</p>
        <p class="ea-sub">+${EA.fmt(r.xp_gain)} XP · +${r.prestige_gain} Prestige · ×${r.salary_bonus} salaire</p>
        ${r.jobs_unlocked.length ? `<p class="ea-sub">Métiers débloqués : ${r.jobs_unlocked.map(EA.esc).join(", ")}</p>` : ""}
        <button class="ea-btn" id="edu-goto-formations" style="margin-top:8px">Voir les formations</button>
      </div>`;
    }
    return `<div class="ea-card ea-center">
      <div class="ea-title">😢 Échec…</div>
      <p class="ea-sub">${r.score}/${r.total} — il fallait ${r.needed}/${r.total} pour <b>${EA.esc(r.diploma)}</b></p>
      <p class="ea-sub">Pour repasser : ${EA.fmt(r.retry_cost)} €A</p>
      <button class="ea-btn" id="edu-goto-formations" style="margin-top:8px">Voir les formations</button>
    </div>`;
  }

  EA.sub({
    tab: "economie", id: "education", icon: "spark", label: "Carrière", order: 40,
    async render() {
      const home = await EA.api("/education/home");
      let body;
      if (view === "competences") body = competences(home);
      else if (view === "cours") body = await cours();
      else if (view === "examen") body = await examen(home);
      else body = formations(home);
      return chips() + body;
    },
    bind() {
      document.querySelectorAll("[data-view]").forEach((b) => b.onclick = () => { view = b.dataset.view; EA.refresh(); });
      EA.onAll("[data-enroll]", async (b) => {
        const r = await EA.post("/education/enroll", { diploma: b.dataset.enroll });
        EA.toast(`Inscrit à ${r.diploma} !`, "success"); EA.refresh();
      });
      EA.onAll("[data-skill]", async (b) => {
        const r = await EA.post("/education/skill/upgrade", { skill: b.dataset.skill });
        EA.toast(`${r.skill} : niveau ${r.level} · +${r.xp_gain} XP`, "success"); EA.refresh();
      });
      EA.onAll("[data-answer]", async (b) => {
        const r = await EA.post("/education/exam/answer", { choice: Number(b.dataset.answer) });
        if (!r.finished) { EA.toast(r.correct ? "Bonne réponse !" : "Faux.", r.correct ? "success" : "error"); EA.refresh(); return; }
        const result = await EA.post("/education/exam/finish");
        EA.toast(result.success ? "Diplôme obtenu !" : "Examen échoué.", result.success ? "success" : "error");
        EA.refresh();
      });
      const revise = document.getElementById("edu-goto-revise");
      if (revise) EA.act(revise, async () => {
        const r = await EA.post("/education/revise");
        EA.toast(`Cours : ${r.lesson.title}`, "success"); view = "cours"; EA.refresh();
      });
      const goExam = document.getElementById("edu-goto-exam");
      if (goExam) goExam.onclick = () => { view = "examen"; EA.refresh(); };
      const goForm = document.getElementById("edu-goto-formations");
      if (goForm) goForm.onclick = () => { view = "formations"; EA.refresh(); };
    },
  });
})();
