// screens/boutique.js — Économie › Boutique : catalogue (partagé), achat en Étoiles (Telegram uniquement).
(() => {
  function itemCard(it, onBuy) {
    const price = it.discount_pct
      ? `<s class="ea-sub">${it.original_price} ⭐</s> <b>${it.price} ⭐</b> (−${it.discount_pct}%)`
      : `<b>${it.price} ⭐</b>`;
    return `<div class="ea-admin-row">
      <div><div><b>${EA.esc(it.label)}</b></div>
        <div class="ea-sub">${price}${it.badges.length ? " · " + it.badges.map(EA.esc).join(" · ") : ""}</div></div>
      <button class="ea-pill-btn gold" data-buy="${EA.esc(it.key)}">Acheter</button>
    </div>`;
  }

  EA.sub({
    tab: "economie", id: "boutique", icon: "gift", label: "Boutique", order: 28,
    async render() {
      const h = await EA.api("/boutique/home");
      const isTelegram = EA.PLATFORM === "telegram"; // défini par shared/core.js au boot
      const sections = [];
      if (!h.payments_enabled) {
        sections.push(`<div class="ea-card ea-center"><p class="ea-sub">⏸️ Les achats sont momentanément suspendus par la direction. Le catalogue reste consultable.</p></div>`);
      }
      if (!isTelegram) {
        sections.push(`<div class="ea-card ea-center"><p class="ea-sub">💳 Les achats en Étoiles ne sont disponibles que dans la mini app Telegram pour l'instant. Tu peux consulter le catalogue ici.</p></div>`);
      }
      if (h.perks.length || h.boosts.length) {
        sections.push(`<div class="ea-card">
          ${h.perks.map((p) => `<p class="ea-sub">${EA.esc(p.label)}${p.expiring_soon ? " ⏳ expire bientôt !" : ""}</p>`).join("")}
          ${h.boosts.length ? `<p class="ea-sub">⚡ ${h.boosts.map((b) => `${EA.esc(b.label)} (${b.hours_left}h)`).join(" · ")}</p>` : ""}
        </div>`);
      }
      if (h.welcome_item) sections.push(`<div class="ea-section-title">🎁 Offre de bienvenue</div><div class="ea-card">${itemCard(h.welcome_item)}</div>`);
      if (h.deal_item) sections.push(`<div class="ea-section-title">⭐ Offre du jour</div><div class="ea-card">${itemCard(h.deal_item)}</div>`);
      if (h.featured.length) sections.push(`<div class="ea-section-title">🌟 À la une</div><div class="ea-card">${h.featured.map((i) => itemCard(i)).join("")}</div>`);

      sections.push(`<div class="ea-section-title">Catégories</div>
        <div class="ea-row" style="flex-wrap:wrap;gap:8px">
          ${h.categories.map((c) => `<button class="ea-pill-btn" data-cat="${c.key}">${c.emoji} ${EA.esc(c.name)} (${c.count})</button>`).join("")}
        </div>`);

      sections.push(`<div class="ea-row" style="margin-top:8px">
        <button class="ea-btn secondary" id="bt-loyalty">🏅 Fidélité · ${h.loyalty_spent} ⭐</button>
        <button class="ea-btn secondary" id="bt-coll">🎒 Collection (${h.collection_count})</button>
      </div>`);

      return sections.join("");
    },
    bind() {
      const isTelegram = EA.PLATFORM === "telegram";

      async function doBuy(key) {
        try {
          const r = await EA.post("/boutique/buy", { key });
          if (isTelegram && window.Telegram?.WebApp?.openInvoice) {
            window.Telegram.WebApp.openInvoice(r.invoice_link, (status) => {
              if (status === "paid") { EA.toast("✅ Achat réussi !", "success"); EA.refresh(); }
              else if (status === "failed") EA.toast("❌ Paiement échoué.", "error");
            });
          } else {
            EA.toast("Facture créée, ouvre-la dans Telegram.", "success");
          }
        } catch (e) { EA.toast(e.message, "error"); }
      }

      EA.onAll("[data-buy]", (b) => doBuy(b.dataset.buy));

      EA.onAll("[data-cat]", async (b) => {
        const c = await EA.api(`/boutique/category/${b.dataset.cat}`);
        const rows = c.items.map((it) => itemCard(it)).join("") || `<p class="ea-sub">Rien à afficher.</p>`;
        const s = EA.sheet(`<div class="ea-row"><b>${c.emoji} ${EA.esc(c.name)}</b><span class="ea-pill-btn" data-close>Fermer ✕</span></div>${rows}`);
        s.el.classList.add("tall");
        s.el.querySelector("[data-close]").onclick = s.close;
        EA.onAll("[data-buy]", (bb) => doBuy(bb.dataset.buy), s.el);
      });

      const loy = document.getElementById("bt-loyalty");
      if (loy) loy.onclick = async () => {
        const l = await EA.api("/boutique/loyalty");
        EA.toast(`🏅 ${l.spent} ⭐ dépensées au total`, "success");
      };
      const coll = document.getElementById("bt-coll");
      if (coll) coll.onclick = async () => {
        const c = await EA.api("/boutique/collection");
        const rows = c.cosmetics.length ? c.cosmetics.map((x) => `<div class="ea-admin-row"><div>${EA.esc(x)}</div></div>`).join("") : `<p class="ea-sub">Collection vide pour l'instant.</p>`;
        const s = EA.sheet(`<div class="ea-row"><b>🎒 Ma collection</b><span class="ea-pill-btn" data-close>Fermer ✕</span></div>${rows}`);
        s.el.querySelector("[data-close]").onclick = s.close;
      };
    },
  });
})();
