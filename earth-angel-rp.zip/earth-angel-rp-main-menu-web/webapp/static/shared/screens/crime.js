// screens/crime.js — Ville › Rue & justice : crimes, prison (caution, tribunal, avocat), et
// pour le personnel de la faction Justice (juge/avocat en service) : dossiers, caution,
// verdicts, mandats d'arrêt, plaidoiries. Réutilise utils/justice.py (même service que le
// bot) via /api/justice/* — voir webapp/routers/crime_router.py.
// NB : la refonte police/armée (crimes du bot vs sur joueurs, menottes, interrogatoire)
// viendra remplacer la partie « rue » de cet écran en vague 5.
(() => {
  // ───────────────────────── personnel judiciaire (juge / avocat en service) ─────────────────────────
  let staffCache = null;

  async function justicePanelHtml() {
    const st = await EA.api("/justice/staff");
    staffCache = st;
    if (!st.post || !st.on_duty) return "";

    if (st.post === "juge") {
      const r = await EA.api("/justice/cases?limit=20");
      const rows = r.cases.length ? r.cases.map((c) => `
        <div class="ea-admin-row">
          <div>
            <div><b>#${c.id} · ${EA.esc(c.suspect_name)}</b> ${c.status === "audience" ? "· 🙋 audience demandée" : ""}</div>
            <div class="ea-sub">${EA.esc(c.crime)} · ${EA.fmtMin(c.jail_secs)} de peine de base</div>
            <div class="ea-sub">💰 Caution : ${c.bail ? EA.fmt(c.effective_bail) + " €A" : "non fixée"} · avocat : ${c.lawyer_name ? EA.esc(c.lawyer_name) : "aucun"}${c.plead === 1 ? " (plaidoirie gagnée)" : ""}</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:6px">
            <button class="ea-pill-btn" data-set-bail="${c.id}">Caution</button>
            <button class="ea-pill-btn gold" data-verdict="${c.id}" data-suspect="${EA.esc(c.suspect_name)}">Juger</button>
          </div>
        </div>`).join("") : `<p class="ea-muted">Aucun dossier ouvert.</p>`;
      return `
        <div class="ea-card" style="margin-top:14px">
          <div class="ea-row"><span class="ea-title" style="margin:0;font-size:15px">⚖️ Dossiers en attente</span>
            <span class="ea-role-badge">Juge en service</span></div>
          ${rows}
          <button class="ea-btn secondary" style="margin-top:10px" id="just-warrant">📜 Délivrer un mandat d'arrêt</button>
        </div>`;
    }

    // avocat
    const r = await EA.api("/justice/my-clients?limit=20");
    const rows = r.cases.length ? r.cases.map((c) => `
      <div class="ea-admin-row">
        <div>
          <div><b>#${c.id} · ${EA.esc(c.suspect_name)}</b></div>
          <div class="ea-sub">${EA.esc(c.crime)} · statut : ${c.status === "audience" ? "audience" : "détenu"}</div>
          <div class="ea-sub">${c.plead === 1 ? "✅ plaidoirie gagnée" : c.plead === -1 ? "❌ plaidoirie perdue" : "Plaidoirie non faite"}</div>
        </div>
        ${c.plead === 0 ? `<button class="ea-pill-btn gold" data-plead="${c.id}">Plaider</button>` : ""}
      </div>`).join("") : `<p class="ea-muted">Aucun client pour l'instant.</p>`;
    return `
      <div class="ea-card" style="margin-top:14px">
        <div class="ea-row"><span class="ea-title" style="margin:0;font-size:15px">👨‍⚖️ Mes clients</span>
          <span class="ea-role-badge">Avocat en service</span></div>
        ${rows}
      </div>`;
  }

  function bindJusticePanel() {
    EA.onAll("[data-plead]", async (b) => {
      const r = await EA.post("/justice/plead", { file_id: Number(b.dataset.plead) });
      EA.toast(r.message, "success");
      EA.refresh();
    });

    EA.onAll("[data-set-bail]", async (b) => {
      const fileId = Number(b.dataset.setBail);
      const limit = (staffCache && staffCache.limits && staffCache.limits.bail_max) || 500000;
      const s = EA.sheet(`
        <p class="ea-sheet-msg">Caution (0 pour refuser la libération sous caution, max ${EA.fmt(limit)} €A)</p>
        <input class="ea-input" id="bail-amount" type="number" inputmode="numeric" min="0" max="${limit}" placeholder="Montant" />
        <div class="ea-grid" style="margin-top:10px">
          <button class="ea-btn secondary" data-no>Annuler</button>
          <button class="ea-btn" data-yes>Fixer la caution</button>
        </div>`);
      s.el.querySelector("[data-no]").onclick = s.close;
      s.el.querySelector("[data-yes]").onclick = async () => {
        const raw = s.el.querySelector("#bail-amount").value;
        const amount = Math.max(0, Math.min(parseInt(raw, 10) || 0, limit));
        s.close();
        const r = await EA.post("/justice/set-bail", { file_id: fileId, amount });
        EA.toast(r.message, "success");
        EA.refresh();
      };
    });

    EA.onAll("[data-verdict]", async (b) => {
      const fileId = Number(b.dataset.verdict);
      const s = EA.sheet(`
        <p class="ea-sheet-msg">Verdict pour ${EA.esc(b.dataset.suspect)} (dossier #${fileId})</p>
        <select class="ea-input" id="verdict-select">
          <option value="acquit">Acquittement</option>
          <option value="amende">Amende</option>
          <option value="prison">Prison</option>
        </select>
        <input class="ea-input" id="verdict-amount" type="number" min="0" placeholder="Montant (€A) ou secondes de prison" style="margin-top:8px;display:none" />
        <div class="ea-grid" style="margin-top:10px">
          <button class="ea-btn secondary" data-no>Annuler</button>
          <button class="ea-btn" data-yes>Rendre le verdict</button>
        </div>`);
      const sel = s.el.querySelector("#verdict-select");
      const amt = s.el.querySelector("#verdict-amount");
      const syncAmount = () => { amt.style.display = sel.value === "acquit" ? "none" : "block"; };
      sel.onchange = syncAmount; syncAmount();
      s.el.querySelector("[data-no]").onclick = s.close;
      s.el.querySelector("[data-yes]").onclick = async () => {
        const verdict = sel.value;
        const amount = verdict === "acquit" ? 0 : (parseInt(amt.value, 10) || 0);
        s.close();
        const r = await EA.post("/justice/verdict", { file_id: fileId, verdict, amount });
        EA.toast(r.message, "success");
        EA.refresh();
      };
    });

    const warrantBtn = document.getElementById("just-warrant");
    if (warrantBtn) EA.act(warrantBtn, async () => {
      const s = EA.sheet(`
        <p class="ea-sheet-msg">Mandat d'arrêt</p>
        <input class="ea-input" id="warrant-id" placeholder="ID du joueur (positif = Telegram, négatif = Web)" />
        <input class="ea-input" id="warrant-reason" placeholder="Motif" style="margin-top:8px" />
        <div class="ea-grid" style="margin-top:10px">
          <button class="ea-btn secondary" data-no>Annuler</button>
          <button class="ea-btn danger" data-yes>Délivrer le mandat</button>
        </div>`);
      s.el.querySelector("[data-no]").onclick = s.close;
      s.el.querySelector("[data-yes]").onclick = async () => {
        const suspectId = parseInt(s.el.querySelector("#warrant-id").value, 10);
        const reason = s.el.querySelector("#warrant-reason").value.trim();
        if (!suspectId || !reason) return;
        s.close();
        const r = await EA.post("/justice/warrant", { suspect_id: suspectId, reason });
        EA.toast(r.message, "success");
        EA.refresh();
      };
    });
  }

  EA.sub({
    tab: "jeux", id: "crime", icon: "shield", label: "Rue &amp; justice", order: 20,
    async render() {
      const panel = await justicePanelHtml();

      const js = await EA.api("/justice/status");
      if (js.case) {
        const c = js.case;
        const pleadText = c.plead === 1 ? "Plaidoirie réussie : caution et peine réduites de 35 %."
          : c.plead === -1 ? "Plaidoirie déjà effectuée, sans réduction." : "Plaidoirie non effectuée.";
        const lawyerRows = !c.lawyer_id && (js.available_lawyers || []).length
          ? js.available_lawyers.map((l) => `<div class="ea-admin-row"><b>👨‍⚖️ ${EA.esc(l.name)}</b>
              <button class="ea-pill-btn" data-justice-lawyer="${Number(l.user_id)}" data-lawyer-name="${EA.esc(l.name)}" data-lawyer-cost="${Number(js.lawyer_cost)}">Engager · ${EA.fmt(js.lawyer_cost)} €A</button></div>`).join("")
          : !c.lawyer_id ? `<p class="ea-sub">Aucun avocat n’est actuellement en service.</p>` : "";
        return `
          <div class="ea-card">
            <div class="ea-title">⚖️ Mon dossier judiciaire · #${Number(c.id)}</div>
            <p class="ea-sub">Motif : <b>${EA.esc(c.crime)}</b> · statut : ${c.status === "audience" ? "audience demandée" : "en attente"}</p>
            <p class="ea-sub">⛓️ Temps de prison restant : <b>${EA.fmtMin(js.seconds_left || 0)}</b></p>
            <p class="ea-sub">👨‍⚖️ Avocat : <b>${EA.esc(c.lawyer_name || "aucun")}</b> · ${pleadText}</p>
            ${c.effective_bail > 0
              ? `<p class="ea-sub">💰 Caution fixée : <b>${EA.fmt(c.effective_bail)} €A</b>${c.effective_bail !== c.bail ? ` (montant initial : ${EA.fmt(c.bail)} €A)` : ""}</p>
                 ${c.can_pay_bail ? `<button class="ea-btn" data-justice-bail>Payer la caution et être libéré</button>` : `<p class="ea-sub">Solde insuffisant pour payer la caution.</p>`}`
              : `<p class="ea-sub">💰 La caution n’a pas encore été fixée par un juge.</p>`}
            ${c.status === "audience" ? `<p>⚖️ Audience demandée : un juge examinera le dossier.</p>`
              : `<button class="ea-btn secondary" data-justice-hearing>Demander une audience</button>`}
            ${!c.lawyer_id ? `<div class="ea-title" style="font-size:15px;margin-top:12px">Avocats en service</div>${lawyerRows}` : ""}
          </div>` + panel;
      }
      if (js.in_prison) {
        if (js.has_judges) {
          return `<div class="ea-card"><div class="ea-title">⛓️ En prison</div>
            <p class="ea-sub">Temps restant : <b>${EA.fmtMin(js.seconds_left)}</b></p>
            <p class="ea-sub">Un juge exerce, mais aucun dossier ouvert n’est associé à ta détention. Les options automatiques sont désactivées; actualise plus tard ou contacte l’équipe.</p></div>` + panel;
        }
        return `
          <div class="ea-card">
            <div class="ea-title">⛓️ En prison</div>
            <p class="ea-sub">Temps restant : <b>${EA.fmtMin(js.seconds_left)}</b></p>
            <p class="ea-sub">Solde : 💵 ${EA.fmt(js.balance)}</p>
            <button class="ea-btn" id="just-caution" ${js.can_pay_caution ? "" : "disabled"} style="margin-top:8px">
              💰 Payer la caution (${EA.fmt(js.caution)})
            </button>
            <div class="ea-grid" style="margin-top:8px">
              <button class="ea-btn secondary" id="just-tribunal">⚖️ Tribunal (${js.tribunal_acquit_chance_pct}%)</button>
              <button class="ea-btn secondary" id="just-lawyer" ${js.can_afford_lawyer ? "" : "disabled"}>👨‍⚖️ Avocat (${EA.fmt(js.lawyer_cost)})</button>
            </div>
          </div>` + panel;
      }

      const cs = await EA.api("/crime/status");
      if (cs.cooldown_seconds_left > 0) {
        return `<div class="ea-card ea-center"><div class="big" style="font-size:32px">⏳</div>
          <p class="ea-sub">Repos avant le prochain crime : <b>${EA.fmtMin(cs.cooldown_seconds_left)}</b></p></div>` + panel;
      }
      if (!cs.in_gang_or_exempt) {
        return `<div class="ea-card ea-center"><div style="font-size:32px">🚫</div>
          <p class="ea-sub">${EA.esc(cs.no_gang_text || "Il faut être dans un gang pour commettre un crime.")}</p></div>` + panel;
      }

      const rows = cs.crimes.map((c) => {
        const risk = c.success_pct >= 60 ? "🟢" : c.success_pct >= 45 ? "🟡" : c.success_pct >= 30 ? "🟠" : "🔴";
        return `<div class="ea-admin-row">
          <div>
            <div>${risk} <b>${EA.esc(c.name)}</b> ${c.needs_firearm ? "🔫" : ""}</div>
            <div class="ea-sub">${c.success_pct}% · ${EA.fmt(c.reward_min)}–${EA.fmt(c.reward_max)} 💵 · karma ${c.karma}</div>
          </div>
          <button class="ea-pill-btn gold" data-crime="${EA.esc(c.name)}">Tenter</button>
        </div>`;
      }).join("");

      return `<div class="ea-card"><div class="ea-title">⚔️ Crimes disponibles</div>${rows}</div>` + panel;
    },
    bind() {
      bindJusticePanel();
      EA.onAll("[data-crime]", async (b) => {
        if (!(await EA.confirm(`Tenter « ${b.dataset.crime} » ? Risque : prison en cas d'échec.`, { danger: true, ok: "Tenter" }))) return;
        try {
          const r = await EA.post("/crime/commit", { crime_name: b.dataset.crime });
          if (r.success) {
            EA.toast(`✅ ${r.flavor} +💵 ${EA.fmt(r.reward)} (karma ${r.karma_change >= 0 ? "+" : ""}${r.karma_change})` + (r.loot ? ` 🎁 ${r.loot}` : ""), "success");
          }
          EA.refresh();
        } catch (e) {
          // 422 / 423 / 403 : l'état du joueur a changé (prison, repos...) → on réaffiche.
          if ([422, 423, 403].includes(e.status) && e.detail) EA.refresh();
          throw e;
        }
      });

      const caution = document.getElementById("just-caution");
      if (caution) EA.act(caution, async () => {
        const r = await EA.post("/justice/caution");
        EA.toast(`🔓 Libéré ! Caution payée : ${EA.fmt(r.caution_paid)}`, "success");
        EA.refresh();
      });
      const tribunal = document.getElementById("just-tribunal");
      if (tribunal) EA.act(tribunal, async () => {
        const r = await EA.post("/justice/tribunal");
        const msg = { acquitted: "⚖️ Acquitté !", reduced: "⚖️ Peine réduite.", convicted: "⚖️ Condamné, peine allongée." }[r.verdict];
        EA.toast(msg, r.verdict === "convicted" ? "error" : "success");
        EA.refresh();
      });
      const lawyer = document.getElementById("just-lawyer");
      if (lawyer) EA.act(lawyer, async () => {
        const r = await EA.post("/justice/lawyer");
        EA.toast(r.won ? "👨‍⚖️ Peine réduite !" : "👨‍⚖️ L'avocat a échoué…", r.won ? "success" : "error");
        EA.refresh();
      });
      EA.onAll("[data-justice-hearing]", async () => {
        const r = await EA.post("/justice/hearing", {});
        EA.toast(r.message, "success"); EA.refresh();
      });
      EA.onAll("[data-justice-bail]", async () => {
        const r = await EA.post("/justice/bail", {});
        EA.toast(r.message, "success"); EA.refresh();
      });
      EA.onAll("[data-justice-lawyer]", async (b) => {
        if (!(await EA.confirm(`Engager ${b.dataset.lawyerName} pour ${EA.fmt(Number(b.dataset.lawyerCost))} €A ? Les honoraires lui seront versés.`, { ok: "Engager l’avocat" }))) return;
        const r = await EA.post("/justice/hire-lawyer", { lawyer_id: Number(b.dataset.justiceLawyer) });
        EA.toast(r.message, "success"); EA.refresh();
      });
    },
  });
})();
