// screens/market.js — Économie › Marché : annonces entre joueurs.
(() => {
  let page = 1;

  function listingRow(l, mineView) {
    return `<div class="ea-admin-row">
      <div><div>${l.emoji} <b>${EA.esc(l.name)}</b> <span class="ea-sub">(${EA.esc(l.rarity)})</span></div>
        <div class="ea-sub">${EA.fmt(l.price)} €A / unité · stock ×${l.quantity}${!mineView ? " · 👤 " + EA.esc(l.seller_name) : ""}</div></div>
      ${mineView
        ? `<button class="ea-pill-btn" data-cancel="${l.listing_id}">Annuler</button>`
        : (l.mine ? `<span class="ea-sub">à toi</span>` : `<button class="ea-pill-btn gold" data-buy="${l.listing_id}" data-name="${EA.esc(l.name)}" data-price="${l.price}" data-max="${l.quantity}">Acheter</button>`)}
    </div>`;
  }

  EA.sub({
    tab: "economie", id: "market", icon: "shopping-cart", label: "Marché", order: 25,
    async render() {
      const [data, mine] = await Promise.all([EA.api(`/market/listings?page=${page}`), EA.api("/market/mine")]);
      return `
        <div class="ea-row" style="margin-bottom:4px">
          <button class="ea-btn secondary" id="mk-sell">📦 Mettre en vente</button>
          <button class="ea-btn secondary" id="mk-use">🎒 Mon inventaire</button>
        </div>
        ${mine.listings.length ? `
          <div class="ea-section-title">Mes annonces actives</div>
          <div class="ea-card">${mine.listings.map((l) => listingRow(l, true)).join("")}</div>` : ""}
        <div class="ea-section-title">Annonces (page ${data.page}/${data.total_pages})</div>
        <div class="ea-card">
          ${data.listings.length ? data.listings.map((l) => listingRow(l, false)).join("") : `<p class="ea-sub">🏪 Marché vide pour l'instant.</p>`}
        </div>
        <div class="ea-row" style="justify-content:center;gap:12px">
          <button class="ea-pill-btn" id="mk-prev" ${data.page <= 1 ? "disabled" : ""}>◀️</button>
          <button class="ea-pill-btn" id="mk-next" ${data.page >= data.total_pages ? "disabled" : ""}>▶️</button>
        </div>`;
    },
    bind() {
      EA.onAll("[data-buy]", async (b) => {
        const max = Math.max(0, Number(b.dataset.max) || 0);
        const price = Math.max(0, Number(b.dataset.price) || 0);
        const itemName = EA.esc(b.dataset.name || "cet article");
        const modal = EA.sheet(`<div class="ea-title">Acheter ${itemName}</div>
          <p class="ea-sub">${EA.fmt(price)} €A par unité · stock disponible : ${EA.fmt(max)}</p>
          <label class="ea-sub" for="mk-buy-quantity">Quantité</label>
          <input class="ea-input" id="mk-buy-quantity" type="number" inputmode="numeric" min="1" max="${max}" step="1" value="1">
          <p class="ea-sub">Total estimé : <b id="mk-buy-total">${EA.fmt(price)} €A</b></p>
          <div class="ea-grid"><button class="ea-btn secondary" data-buy-cancel>Annuler</button>
          <button class="ea-btn" data-buy-confirm>Confirmer l’achat</button></div>`);
        const input = modal.el.querySelector("#mk-buy-quantity");
        const total = modal.el.querySelector("#mk-buy-total");
        input.addEventListener("input", () => {
          const quantity = Number(input.value);
          total.textContent = quantity > 0 && quantity <= max && Number.isInteger(quantity)
            ? `${EA.fmt(price * quantity)} €A`
            : "Quantité invalide";
        });
        modal.el.querySelector("[data-buy-cancel]").onclick = modal.close;
        modal.el.querySelector("[data-buy-confirm]").onclick = async (event) => {
          const quantity = Number(input.value);
          if (!Number.isInteger(quantity) || quantity < 1 || quantity > max) {
            EA.toast(`Choisis une quantité entre 1 et ${max}.`, "error");
            return;
          }
          const confirm = event.currentTarget;
          if (confirm.dataset.busy) return;
          confirm.dataset.busy = "1";
          try {
            const r = await EA.post("/market/buy", { listing_id: Number(b.dataset.buy), quantity });
            modal.close();
            EA.toast(`✅ ${r.quantity} × ${r.name} acheté(s) pour ${EA.fmt(r.total)} €A`, "success");
            EA.refresh();
          } catch (e) {
            EA.toast(e.message, "error");
          } finally {
            delete confirm.dataset.busy;
          }
        };
      });
      EA.onAll("[data-cancel]", async (b) => {
        try {
          const r = await EA.post("/market/cancel", { listing_id: Number(b.dataset.cancel) });
          EA.toast(`✅ Annonce annulée, ${r.quantity_returned} récupéré(s)`, "success");
          EA.refresh();
        } catch (e) { EA.toast(e.message, "error"); }
      });
      const prev = document.getElementById("mk-prev");
      if (prev) prev.onclick = () => { if (page > 1) { page--; EA.refresh(); } };
      const next = document.getElementById("mk-next");
      if (next) next.onclick = () => { page++; EA.refresh(); };

      const sellBtn = document.getElementById("mk-sell");
      if (sellBtn) sellBtn.onclick = async () => {
        const inv = await EA.api("/market/inventory");
        const rows = inv.items.map((it) => `<div class="ea-admin-row">
          <div>${it.item_name} <span class="ea-sub">×${it.quantity}</span></div>
          <button class="ea-pill-btn gold" data-sell-item="${it.item_id}" data-max="${it.quantity}">Vendre</button>
        </div>`).join("") || `<p class="ea-sub">Ton inventaire est vide.</p>`;
        const s = EA.sheet(`<div class="ea-row"><b>📦 Mettre en vente</b><span class="ea-pill-btn" data-close>Fermer ✕</span></div>${rows}`);
        s.el.classList.add("tall");
        s.el.querySelector("[data-close]").onclick = s.close;
        EA.onAll("[data-sell-item]", (b) => {
          const price = prompt("Prix unitaire (€A) ?");
          const qty = prompt(`Quantité (max ${b.dataset.max}) ?`, "1");
          if (!price || !qty) return;
          EA.post("/market/sell", { item_id: Number(b.dataset.sellItem), price: Number(price), quantity: Number(qty) })
            .then((r) => { EA.toast(`✅ Mis en vente : ${r.name} ×${r.quantity} à ${EA.fmt(r.unit_price)} €A`, "success"); s.close(); EA.refresh(); })
            .catch((e) => EA.toast(e.message, "error"));
        }, s.el);
      };

      const useBtn = document.getElementById("mk-use");
      if (useBtn) useBtn.onclick = async () => {
        const inv = await EA.api("/market/inventory");
        const rows = inv.items.map((it) => `<div class="ea-admin-row">
          <div>${it.item_name} <span class="ea-sub">×${it.quantity}</span></div>
          <button class="ea-pill-btn" data-use-item="${it.item_id}">Utiliser</button>
        </div>`).join("") || `<p class="ea-sub">Ton inventaire est vide.</p>`;
        const s = EA.sheet(`<div class="ea-row"><b>🎒 Inventaire</b><span class="ea-pill-btn" data-close>Fermer ✕</span></div>${rows}`);
        s.el.classList.add("tall");
        s.el.querySelector("[data-close]").onclick = s.close;
        EA.onAll("[data-use-item]", (b) => {
          EA.post("/market/use", { item_id: Number(b.dataset.useItem), quantity: 1 })
            .then(() => { EA.toast("✨ Item utilisé", "success"); s.close(); EA.refresh(); })
            .catch((e) => EA.toast(e.message, "error"));
        }, s.el);
      };
    },
  });
})();
