// screens/gangs.js — Social › Gangs, partagé Telegram/Web.
(() => {
  function name(x) { return EA.esc(x?.full_name || x?.username || x?.name || `Joueur ${x?.user_id ?? "?"}`); }
  function memberRows(r) {
    if (!r.members?.length) return "";
    const manage = ["Chef", "Bras droit"].includes(r.mine.role);
    return `<div class="ea-section-title">Membres</div>${r.members.map((m) => {
      const self = m.user_id === r.mine.user_id;
      const actions = manage && !self ? `<button class="ea-pill-btn" data-gang-role="${m.user_id}" data-role="Soldat">Soldat</button><button class="ea-pill-btn danger" data-gang-exclude="${m.user_id}">Exclure</button>${r.mine.role === "Chef" ? `<button class="ea-pill-btn gold" data-gang-transfer="${m.user_id}">Passer chef</button>` : ""}` : "";
      return `<div class="ea-row" style="gap:6px;margin-top:6px"><span style="flex:1">${name(m)} · ${EA.esc(m.role)}</span>${actions}</div>`;
    }).join("")}`;
  }
  async function render() {
    const r = await EA.api("/gangs/home");
    const mine = r.mine;
    const mineHtml = mine ? `<div class="ea-card accent"><div class="ea-title">🔫 ${EA.esc(mine.name)}</div><p class="ea-sub">Rôle : ${EA.esc(mine.role)} · réputation ${mine.reputation} · caisse ${EA.fmt(mine.treasury)} €A</p><div class="ea-row" style="gap:8px"><input class="ea-input" id="gang-amount" type="number" min="1" placeholder="Montant" /><button class="ea-pill-btn gold" id="gang-deposit">Déposer</button></div><div class="ea-row" style="margin-top:8px;gap:8px"><button class="ea-btn secondary" id="gang-upgrade">Améliorer · ${EA.fmt(r.costs.upgrade)} €A</button><button class="ea-btn secondary" id="gang-hold">Hold-up</button><button class="ea-btn danger" id="gang-leave">Quitter</button>${mine.role === "Chef" ? `<button class="ea-btn danger" id="gang-dissolve">Dissoudre</button>` : ""}</div>${memberRows(r)}${r.applications.length ? `<div class="ea-section-title">Candidatures</div>${r.applications.map((a) => `<div class="ea-row"><span>${name(a)}</span><button class="ea-pill-btn gold" data-gang-accept="${a.app_id}">Accepter</button></div>`).join("")}` : ""}</div>` : `<div class="ea-card"><div class="ea-title">🔫 Créer un gang</div><p class="ea-sub">Coût : ${EA.fmt(r.costs.create)} €A</p><input class="ea-input" id="gang-name" maxlength="40" placeholder="Nom du gang" /><button class="ea-btn" id="gang-create" style="margin-top:8px">Créer</button></div>`;
    const list = r.gangs.map((g) => `<div class="ea-list-row"><div class="ic">🔫</div><div><div class="t">${EA.esc(g.name)}</div><div class="d">${g.members} membre(s) · réputation ${g.reputation} · caisse ${EA.fmt(g.treasury)} €A</div></div>${mine ? "" : `<button class="ea-pill-btn gold" data-gang-apply="${g.gang_id}">Postuler</button>`}</div>`).join("");
    return mineHtml + `<div class="ea-section-title">Annuaire des gangs</div><div class="ea-list">${list || `<p class="ea-muted">Aucun gang créé pour l'instant.</p>`}</div>`;
  }
  async function act(path, body) { const r = await EA.post(path, body); EA.toast(r.message, "success"); EA.refresh(); }
  function bind() {
    const c = document.getElementById("gang-create"); if (c) EA.act(c, () => act("/gangs/create", { name: document.getElementById("gang-name").value }));
    const d = document.getElementById("gang-deposit"); if (d) EA.act(d, () => act("/gangs/treasury/deposit", { amount: Number(document.getElementById("gang-amount").value) }));
    const u = document.getElementById("gang-upgrade"); if (u) EA.act(u, () => act("/gangs/upgrade"));
    const h = document.getElementById("gang-hold"); if (h) EA.act(h, async () => { if (await EA.confirm("Lancer un hold-up ?", { danger: true, ok: "Lancer" })) act("/gangs/hold-up"); });
    const l = document.getElementById("gang-leave"); if (l) EA.act(l, async () => { if (await EA.confirm("Quitter ce gang ?", { danger: true, ok: "Quitter" })) act("/gangs/leave"); });
    const x = document.getElementById("gang-dissolve"); if (x) EA.act(x, async () => { if (await EA.confirm("Dissoudre définitivement ce gang ?", { danger: true, ok: "Dissoudre" })) act("/gangs/dissolve"); });
    EA.onAll("[data-gang-apply]", (b) => act("/gangs/apply", { gang_id: Number(b.dataset.gangApply) }));
    EA.onAll("[data-gang-accept]", (b) => act("/gangs/applications/decide", { app_id: Number(b.dataset.gangAccept) }));
    EA.onAll("[data-gang-role]", (b) => act("/gangs/role", { user_id: Number(b.dataset.gangRole), role: b.dataset.role }));
    EA.onAll("[data-gang-exclude]", (b) => EA.act(b, async () => { if (await EA.confirm("Exclure ce membre ?", { danger: true, ok: "Exclure" })) act("/gangs/exclude", { user_id: Number(b.dataset.gangExclude) }); }));
    EA.onAll("[data-gang-transfer]", (b) => EA.act(b, async () => { if (await EA.confirm("Transférer le poste de chef ?", { danger: true, ok: "Transférer" })) act("/gangs/transfer", { user_id: Number(b.dataset.gangTransfer) }); }));
  }
  EA.sub({ tab: "social", id: "gangs", icon: "shield", label: "Gangs", order: 50, render, bind });
})();
