// webapp/static/web/app.js — bootstrap spécifique à l'application web (joueurs sans Telegram).
// Authentification via Google (OAuth2). Après connexion, Google redirige vers "/app/#token=...";
// le jeton est récupéré depuis le fragment d'URL (jamais envoyé au serveur), stocké, puis on
// délègue tout le reste (écrans, données de jeu) au module partagé EA (shared/core.js + shared/screens/*.js).

(() => {
  EA.PLATFORM = "web";   // lu par certains écrans partagés (ex. boutique.js : pas d'Étoiles hors Telegram)
  const root = document.getElementById("app");

  // Jeton reçu après un retour de connexion Google ?
  if (location.hash.startsWith("#token=")) {
    const token = decodeURIComponent(location.hash.slice("#token=".length));
    EA.setToken(token);
    history.replaceState(null, "", location.pathname);
  } else if (location.hash.includes("auth_error")) {
    EA.toast("Connexion Google impossible, réessaie.", "error");
    history.replaceState(null, "", location.pathname);
  }

  EA.setLoggedOutRenderer(() => {
    root.innerHTML = `
      <div class="ea-login">
        <div class="ea-login-art" style="background-image:url(/shared/banner.jpg)"></div>
        <h1>Deux faces.<br>Un seul monde.</h1>
        <p>Crée ton personnage et rejoins le même monde que les joueurs sur Telegram : mêmes règles, même économie, mêmes destins.</p>
        <button class="ea-btn" id="google-login">Continuer avec Google</button>
      </div>`;
    document.getElementById("google-login").onclick = () => {
      location.href = "/api/auth/google/login";
    };
  });

  EA.loadScreens()
    .then(() => EA.boot(root))
    .catch((e) => {
      console.error(e);
      root.innerHTML = `<div class="ea-card ea-center"><p class="ea-sub">Chargement impossible : ${e.message}</p></div>`;
    });
})();
