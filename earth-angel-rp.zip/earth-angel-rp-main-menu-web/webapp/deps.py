"""webapp/deps.py — Dépendances FastAPI communes aux routers."""
from __future__ import annotations

from dataclasses import dataclass

from fastapi import Depends, HTTPException

from fastapi import Header

from webapp.auth import current_user_id, decode_session_token_full
import database
from config import ROLE_LABELS, role_level
from utils import character as character_mod
from utils.decorators import get_user_role_async

__all__ = [
    "current_user_id", "get_active_user_id", "require_character_complete",
    "StaffContext", "require_staff", "get_session_source",
]


async def get_session_source(authorization: str | None = Header(default=None)) -> str:
    """'telegram' ou 'google' — lu depuis le même JWT, pour les fonctionnalités qui n'existent
    que côté Telegram (paiement en Étoiles, par exemple : il n'y a pas d'équivalent « argent
    réel » pour les comptes Google pour l'instant)."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Non connecté.")
    token = authorization.split(" ", 1)[1].strip()
    return decode_session_token_full(token).get("src", "unknown")


async def get_active_user_id(
    user_id: int = Depends(current_user_id),
    source: str = Depends(get_session_source),
) -> int:
    """Retourne le joueur actif sans recréer silencieusement un compte Web supprimé.

    Telegram peut recréer son profil depuis un nouvel initData signé. En revanche, un JWT
    Google conservé dans localStorage ne doit pas ressusciter un compte après une remise à
    zéro SQLite : il faut renvoyer 401 pour que le frontend efface `ea_token` et affiche
    de nouveau le bouton de connexion Google.
    """
    if source == "google":
        async with database.db_read() as db:
            async with db.execute("SELECT 1 FROM users WHERE user_id=?", (user_id,)) as cur:
                if not await cur.fetchone():
                    raise HTTPException(status_code=401, detail="Compte Web supprimé, reconnecte-toi avec Google.")
        return user_id
    await database.get_user(user_id)
    return user_id


async def require_character_complete(user_id: int = Depends(get_active_user_id)) -> int:
    """Porte d'entrée obligatoire : même règle que côté bot Telegram (utils/character.gate),
    mais renvoyée ici comme une erreur HTTP exploitable par le front-end (redirection vers
    l'écran de création de personnage) plutôt que comme un message Telegram."""
    if not await character_mod.is_complete(user_id):
        raise HTTPException(
            status_code=409,
            detail="character_incomplete",
        )
    return user_id


@dataclass
class StaffContext:
    user_id: int
    role: str
    label: str
    level: int


async def require_staff(user_id: int = Depends(get_active_user_id)) -> StaffContext:
    """Réutilise EXACTEMENT la même hiérarchie de rôles que le bot (ADMIN_N1, ADMIN_N2,
    GAME_LEADER... voir config.ROLE_HIERARCHY) : un joueur promu staff via le bot a
    automatiquement accès au panneau admin web, sans rien reconfigurer."""
    role = await get_user_role_async(user_id)
    if role_level(role) < role_level("ADMIN_N1"):
        raise HTTPException(status_code=403, detail="Accès réservé au staff.")
    return StaffContext(user_id=user_id, role=role, label=ROLE_LABELS.get(role, role), level=role_level(role))
