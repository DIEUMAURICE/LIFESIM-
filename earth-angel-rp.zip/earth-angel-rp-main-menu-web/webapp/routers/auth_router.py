"""webapp/routers/auth_router.py — Connexion mini app Telegram + connexion web Google.

Les deux chemins débouchent sur le même jeton de session (JWT), utilisé ensuite par
TOUTE l'API (voir webapp/deps.py). Le front-end (mini app ou site) stocke ce jeton et
l'envoie dans l'en-tête `Authorization: Bearer <jwt>`.
"""
from __future__ import annotations

import secrets

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from pydantic import BaseModel

import database
from config import WEB_BASE_URL
from webapp.auth import (
    current_user_id, exchange_google_code, google_login_url,
    issue_session_token, verify_telegram_init_data,
)

router = APIRouter(prefix="/api/auth", tags=["auth"])

# État anti-CSRF pour le flux Google (en mémoire : suffisant pour un seul processus webapp).
_pending_states: set[str] = set()


class TelegramAuthIn(BaseModel):
    init_data: str


class SessionOut(BaseModel):
    token: str
    user_id: int
    is_new: bool = False


@router.post("/telegram", response_model=SessionOut)
async def auth_telegram(body: TelegramAuthIn):
    """Appelé par la mini app Telegram au démarrage avec `Telegram.WebApp.initData`."""
    tg_user = verify_telegram_init_data(body.init_data)
    user_id = int(tg_user["id"])
    username = tg_user.get("username", "") or ""
    full_name = " ".join(filter(None, [tg_user.get("first_name"), tg_user.get("last_name")]))

    existing = await database.get_user(user_id, username=username, full_name=full_name)
    is_new = existing.get("registered", 0) == 0
    if is_new:
        await database.update_field(user_id, "registered", 1)

    token = issue_session_token(user_id, source="telegram")
    return SessionOut(token=token, user_id=user_id, is_new=is_new)


@router.get("/google/login")
async def auth_google_login():
    """Redirige le navigateur vers l'écran de connexion Google."""
    state = secrets.token_urlsafe(24)
    _pending_states.add(state)
    return RedirectResponse(google_login_url(state))


@router.get("/google/callback")
async def auth_google_callback(code: str | None = None, state: str | None = None, error: str | None = None):
    """Google revient ici après connexion. On échange le code, on crée/retrouve le compte
    de jeu correspondant, puis on renvoie le navigateur vers le site avec le jeton en fragment
    d'URL (jamais envoyé au serveur, donc jamais logué côté nginx)."""
    if error or not code:
        return RedirectResponse(f"{WEB_BASE_URL}/#auth_error=1")
    if not state or state not in _pending_states:
        return RedirectResponse(f"{WEB_BASE_URL}/#auth_error=state")
    _pending_states.discard(state)

    profile = await exchange_google_code(code)
    account = await database.get_or_create_web_account(profile.sub, profile.email)
    user_id = account["user_id"]

    full_name = profile.name or profile.email or f"Joueur {user_id}"
    existing = await database.get_user(user_id, full_name=full_name)
    if existing.get("registered", 0) == 0:
        await database.update_field(user_id, "registered", 1)

    token = issue_session_token(user_id, source="google")
    return RedirectResponse(f"{WEB_BASE_URL}/#token={token}")


@router.get("/me", response_model=SessionOut)
async def auth_me(user_id: int = Depends(current_user_id)):
    """Vérifie qu'un jeton stocké côté client est toujours valide."""
    return SessionOut(token="", user_id=user_id)
