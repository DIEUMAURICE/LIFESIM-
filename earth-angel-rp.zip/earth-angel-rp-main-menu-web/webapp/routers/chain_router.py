"""webapp/routers/chain_router.py — Chaîne de production, côté JOUEUR (utils/chain.py +
handlers/chain.py). Entièrement réutilisé depuis utils/chain.py, qui est déjà pur (aucune
dépendance Telegram) — rien n'est réécrit.

Portée de cette première passe : l'essentiel pour un joueur (biens produits par son métier,
rang/promotion, vente — au comptoir, à une entreprise, ou dépôt gratuit dans sa propre
entreprise). La gestion d'entreprise côté staff (lignes de production, équipe, prix/enchères,
parts, grossistes, prestations) n'est PAS encore branchée ici — c'est une suite logique mais
plus consultée par les dirigeants d'entreprise que par le joueur moyen ; à faire dans un second
temps si tu veux la webapp complète pour les entreprises aussi.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from config import SMALL_JOBS
from config_chain import (
    COUNTER_DAILY_CAP, COUNTER_PRICE_RATIO, INTRANTS, RECIPES, describe_effects,
    job_rank_mult, job_rank_name, sector_inputs, stage_emoji,
)
from database import db_connection, get_user, get_user_company
from utils import chain
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/chain", tags=["chain"])


@router.get("/promotion")
async def promotion(user_id: int = Depends(require_character_complete)):
    u = await get_user(user_id)
    job = u.get("job", "") or ""
    if job not in SMALL_JOBS:
        raise HTTPException(status_code=422, detail="💼 Tu n'as pas de métier.")

    st = await chain.promotion_status(user_id, job)
    rank = st["rank"]
    m = job_rank_mult(rank)
    out = {
        "job": job, "rank": rank, "rank_name": job_rank_name(rank), "missions": st["missions"],
        "pay_mult": m["pay"], "goods_mult": m["goods"], "energy_mult": m["energy"],
        "next_rank": st["next"], "can_promote": st["ok"],
        "requirements": [
            {"label": label, "have": have, "need": need, "ok": ok}
            for label, have, need, ok in st["reqs"]
        ],
    }
    if st["next"] is not None:
        nm = job_rank_mult(st["next"])
        out["next_rank_name"] = job_rank_name(st["next"])
        out["next_pay_mult"] = nm["pay"]
        out["next_goods_mult"] = nm["goods"]
    return out


@router.post("/promote")
async def promote(user_id: int = Depends(require_character_complete)):
    u = await get_user(user_id)
    job = u.get("job", "") or ""
    if job not in SMALL_JOBS:
        raise HTTPException(status_code=422, detail="💼 Tu n'as pas de métier.")
    ok, msg = await chain.promote_job(user_id, job)
    if not ok:
        raise HTTPException(status_code=422, detail=msg)
    return {"message": msg}


@router.get("/goods")
async def goods(user_id: int = Depends(require_character_complete)):
    g = await chain.user_goods(user_id)
    raw = {k: q for k, q in g.items() if k in INTRANTS}
    fin = {k: q for k, q in g.items() if k in RECIPES}

    async def _stats():
        async with db_connection() as db:
            async with db.execute(
                "SELECT goods_made, goods_supplied, supply_value, big_orders FROM user_chain_stats WHERE user_id=?",
                (user_id,),
            ) as cur:
                r = await cur.fetchone()
        return {"goods_made": r[0], "goods_supplied": r[1], "supply_value": r[2], "big_orders": r[3]} if r else None

    return {
        "raw_goods": [
            {"key": k, "name": INTRANTS[k]["name"], "emoji": INTRANTS[k]["emoji"], "quantity": q, "ref_price": INTRANTS[k]["ref"]}
            for k, q in raw.items()
        ],
        "finished_goods": [
            {"key": k, "name": RECIPES[k]["name"], "emoji": RECIPES[k]["emoji"], "quantity": q, "effects": describe_effects(RECIPES[k]["effects"])}
            for k, q in fin.items()
        ],
        "stats": await _stats(),
    }


@router.get("/sell/{good}")
async def sell_options(good: str, user_id: int = Depends(require_character_complete)):
    if good not in INTRANTS:
        raise HTTPException(status_code=404, detail="❌ Bien inconnu.")
    g = INTRANTS[good]
    have = (await chain.user_goods(user_id)).get(good, 0)
    buyers = await chain.companies_buying(good, 5)
    counter_price = max(1, int(g["ref"] * COUNTER_PRICE_RATIO))

    comp = await get_user_company(user_id)
    can_deposit = bool(comp and good in sector_inputs(comp["sector"]))

    return {
        "good": good, "name": g["name"], "emoji": g["emoji"], "have": have,
        "buyers": [
            {"company_id": c["company_id"], "name": c["name"], "stage": stage_emoji(c["level"]),
             "price": c["price"], "multiplier": c["mult"], "room": c["room"], "treasury": c["treasury"]}
            for c in buyers
        ],
        "counter_price": counter_price, "counter_daily_cap": COUNTER_DAILY_CAP,
        "can_deposit_to_own_company": can_deposit,
        "own_company_name": comp["name"] if can_deposit else None,
        "own_company_id": comp["company_id"] if can_deposit else None,
    }


class SellIn(BaseModel):
    good: str
    company_id: int
    quantity: int


@router.post("/sell")
async def sell(body: SellIn, user_id: int = Depends(require_character_complete)):
    ok, msg = await chain.sell_to_company(user_id, body.company_id, body.good, body.quantity)
    if not ok:
        raise HTTPException(status_code=422, detail=msg)
    return {"message": msg}


class CounterSellIn(BaseModel):
    good: str
    quantity: int


@router.post("/counter-sell")
async def counter_sell(body: CounterSellIn, user_id: int = Depends(require_character_complete)):
    ok, msg = await chain.counter_sell(user_id, body.good, body.quantity)
    if not ok:
        raise HTTPException(status_code=422, detail=msg)
    return {"message": msg}


class DepositIn(BaseModel):
    good: str
    company_id: int
    quantity: int


@router.post("/deposit")
async def deposit(body: DepositIn, user_id: int = Depends(require_character_complete)):
    ok, msg = await chain.deposit_to_company(user_id, body.company_id, body.good, body.quantity)
    if not ok:
        raise HTTPException(status_code=422, detail=msg)
    return {"message": msg}
