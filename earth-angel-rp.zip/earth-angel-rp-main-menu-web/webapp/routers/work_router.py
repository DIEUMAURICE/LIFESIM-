"""webapp/routers/work_router.py — Le vrai système de métier du bot (handlers/work.py) :
choisir/changer de métier (parmi SMALL_JOBS, selon le diplôme), travailler (gain + XP + coût
d'énergie), arrêter son métier. + bonus quotidien.

Portée : le mini-jeu interactif (appuis chronométrés par catégorie) n'est pas porté tel quel
— ce serait un projet d'interface à part entière. Un score (0-3) est tiré aléatoirement à la
place, et réutilisé tel quel dans TOUTES les formules du bot (XP, biens produits, promotion) :
c'est la seule différence assumée avec le bot.

Tout le reste réutilise les mêmes fonctions que le bot, pour rester conforme :
  • cooldown effectif avec bonus VIP/Premium (utils.vip.effective_cooldown) — pas le cooldown brut.
  • multiplicateur de rang de métier sur le gain et le coût en énergie (config_chain.job_rank_mult).
  • robinet économique du staff (utils.gamerules.faucet) — un réglage staff doit s'appliquer ici aussi.
  • vérification de présence RP (le joueur doit être au bon endroit pour travailler).
  • production de biens (intrants) et statut de promotion (utils.chain), sinon un joueur en
    entreprise/faction perdrait une partie de son revenu réel en passant par la webapp.
  • progression des missions/quêtes liées au travail (handlers.missions.update_mission_progress).
  • grandes commandes (big=True), avec le même verrou de rang et d'énergie que le bot.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
from config import (
    DAILY_MAX, DAILY_MIN, DAILY_COOLDOWN, SHIFT_ENERGY, SMALL_JOBS, SMALL_JOB_PLACE, WORK_COOLDOWN,
)
from handlers.work import DIP_ORDER, NO_JOB_TEXT, _dip_rank
from utils.cooldowns import claim_cooldown, cooldown_left, release_cooldown
from utils.gamerules import faucet
from utils.location import is_exempt, presence_error
from utils.vip import add_xp, effective_cooldown
from gameplay import work as work_gameplay
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/work", tags=["work"])

KEY_SMALL = "freelance_last"
DAILY_KEY = "api_bonus_quotidien"


def _vital_problem(u: dict) -> str | None:
    if u.get("energy", 100) < 20:
        return "😴 Tu es épuisé(e) ! Repose-toi avant de retravailler."
    if u.get("hunger", 100) < 12:
        return "🍽️ Tu es trop affamé(e) pour travailler. Mange d'abord."
    if u.get("health", 100) < 15:
        return "🏥 Ton état est trop critique pour travailler. Soigne-toi d'abord."
    return None


@router.get("/catalog")
async def catalog(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    dip = u.get("diplome") or ""
    jobs = [
        {
            "name": name,
            "emoji": data["emoji"],
            "category": data["category"],
            "min": data["min"],
            "max": data["max"],
            "xp": data["xp"],
            "need": data.get("need"),
            "locked": bool(data.get("need")) and _dip_rank(dip) < _dip_rank(data["need"]),
        }
        for name, data in SMALL_JOBS.items()
    ]
    return {"jobs": jobs, "diplome": dip}


@router.get("/job")
async def current_job(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    name = u.get("job", "") or ""
    job = {"name": name, **SMALL_JOBS[name]} if name in SMALL_JOBS else None
    return {"job": job, "no_job_text": NO_JOB_TEXT if not job else None}


class ChooseJobIn(BaseModel):
    job_name: str


@router.post("/job/choose")
async def choose_job(body: ChooseJobIn, user_id: int = Depends(require_character_complete)):
    if body.job_name not in SMALL_JOBS:
        raise HTTPException(status_code=404, detail="Métier inconnu.")
    data = SMALL_JOBS[body.job_name]
    u = await database.get_user(user_id)
    need = data.get("need")
    if need and _dip_rank(u.get("diplome") or "") < _dip_rank(need):
        raise HTTPException(status_code=403, detail=f"Le métier « {body.job_name} » nécessite le diplôme {need}.")
    await database.update_field(user_id, "job", body.job_name)
    return {"job": body.job_name}


@router.post("/job/quit")
async def quit_job(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    old = u.get("job", "") or ""
    await database.update_field(user_id, "job", "")
    return {"quit": old or None}


@router.get("/status")
async def status(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    work_left = await cooldown_left(user_id, KEY_SMALL, effective_cooldown(u, WORK_COOLDOWN, work=True))
    daily_left = await cooldown_left(user_id, DAILY_KEY, DAILY_COOLDOWN)
    return {
        "work_ready": work_left == 0,
        "work_seconds_left": work_left,
        "daily_ready": daily_left == 0,
        "daily_seconds_left": daily_left,
    }


class DoWorkIn(BaseModel):
    big: bool = False   # "grande commande" : nécessite le rang Confirmé + 50 % d'énergie


@router.post("/do")
async def do_work(body: DoWorkIn = DoWorkIn(), user_id: int = Depends(require_character_complete)):
    try:
        preparation = await work_gameplay.prepare(user_id, big=bool(body.big))
        # Le Web ne possède pas le mini-jeu Telegram : il utilise le même score final
        # et les mêmes formules de résolution, sans dupliquer la mutation métier.
        import random
        return await work_gameplay.resolve(preparation, random.randint(0, 3))
    except work_gameplay.WorkError as exc:
        raise HTTPException(status_code=exc.status, detail=exc.message) from exc


@router.post("/daily")
async def do_daily(user_id: int = Depends(require_character_complete)):
    ok, remaining = await claim_cooldown(user_id, DAILY_KEY, DAILY_COOLDOWN)
    if not ok:
        return {"success": False, "seconds_left": remaining}
    gain = random.randint(DAILY_MIN, DAILY_MAX)
    await database.update_balance(user_id, gain)
    return {"success": True, "gain": gain}
