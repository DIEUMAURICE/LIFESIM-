"""Authenticated Web/Mini App vehicle showroom and garage.

Catalogue and gameplay values are sourced from config.VEHICLES and the bot's
vehicle/VIP/location helpers. Automated maintenance remains bot-managed.
"""
from __future__ import annotations

import aiosqlite
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
from config import VEHICLES
from handlers.vehicles import MAX_VEHICLES, get_active_vehicle, get_max_vehicles
from utils.decorators import cooldown_problem, free_problem
from utils.cooldowns import release_cooldown
from utils.vip import max_vehicles as vip_max_vehicles
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/vehicles", tags=["vehicles"])


def _resale_price(vehicle: dict) -> int:
    data = VEHICLES.get(vehicle["veh_type"], {})
    condition = int(vehicle.get("condition", 100))
    return int(data.get("price", 0) * 0.6 * (condition / 100))


def _vehicle(v: dict, active_id: int = 0) -> dict:
    data = VEHICLES.get(v["veh_type"], {})
    return {
        "veh_id": v["veh_id"], "veh_type": v["veh_type"],
        "emoji": data.get("emoji", "🚗"), "price": data.get("price", 0),
        "resale_price": _resale_price(v),
        "maintenance": data.get("maint", 0), "prestige": data.get("status", 0),
        "speed": v.get("speed", 0) or data.get("speed", 0),
        "cargo": v.get("cargo", 0) or data.get("cargo", 0),
        "luxury": v.get("luxury", 0) or data.get("luxury", 0),
        "condition": int(v.get("condition", 100)), "insured": bool(v.get("insured", 0)),
        "fuel": int(v.get("fuel", 0) or 0),
        "fuel_capacity": int(data.get("fuel_capacity", 0)),
        "insurance_quote": max(100, int(data.get("price", 10_000) * 0.05)),
        "active": v["veh_id"] == active_id,
        "last_maintenance": int(v.get("last_maintenance", 0) or 0),
    }


async def _get_vehicle_rows(user_id: int):
    async with database.db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM vehicles WHERE user_id=? ORDER BY veh_id", (user_id,)) as cur:
            return [dict(r) for r in await cur.fetchall()]


@router.get("/catalog")
async def catalog(user_id: int = Depends(require_character_complete)):
    user = await database.get_user(user_id)
    owned = await _get_vehicle_rows(user_id)
    max_count = vip_max_vehicles(user, MAX_VEHICLES)
    return {
        "items": [{"type": name, "emoji": data.get("emoji", "🚗"), "price": data["price"],
                   "maintenance": data["maint"], "prestige": data["status"], "speed": data.get("speed", 0),
                   "cargo": data.get("cargo", 0), "luxury": data.get("luxury", 0),
                   "fuel_capacity": data.get("fuel_capacity", 0)} for name, data in VEHICLES.items()],
        "owned_count": len(owned), "max_vehicles": max_count,
        "balance": int(user.get("balance", 0)),
    }


@router.get("/garage")
async def garage(user_id: int = Depends(require_character_complete)):
    vehicles = await _get_vehicle_rows(user_id)
    active = await get_active_vehicle(user_id)
    user = await database.get_user(user_id)
    return {"vehicles": [_vehicle(v, active["veh_id"] if active else 0) for v in vehicles],
            "active_vehicle_id": active["veh_id"] if active else None,
            "owned_count": len(vehicles), "max_vehicles": vip_max_vehicles(user, MAX_VEHICLES),
            "balance": int(user.get("balance", 0))}


class BuyIn(BaseModel):
    veh_type: str


@router.post("/buy")
async def buy(body: BuyIn, user_id: int = Depends(require_character_complete)):
    if body.veh_type not in VEHICLES:
        raise HTTPException(status_code=404, detail="Véhicule inconnu.")
    blocked = await free_problem(user_id, "handlers.vehicles")
    if blocked:
        raise HTTPException(status_code=422, detail=blocked)
    error, claimed = await cooldown_problem(user_id, "buy_vehicle", 10,
        "⏳ Attends un instant avant d'acheter un autre véhicule.")
    if error:
        raise HTTPException(status_code=429, detail=error)
    data = VEHICLES[body.veh_type]
    user = await database.get_user(user_id)
    limit = vip_max_vehicles(user, MAX_VEHICLES)
    try:
        async with database.db_connection() as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                async with db.execute("SELECT COUNT(*) FROM vehicles WHERE user_id=?", (user_id,)) as cur:
                    count = (await cur.fetchone())[0]
                if count >= limit:
                    raise HTTPException(status_code=422, detail=f"Maximum de {limit} véhicules atteint.")
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+?, prestige=prestige+? "
                    "WHERE user_id=? AND balance>=?",
                    (data["price"], data["price"], data["status"], user_id, data["price"]))
                if debit.rowcount != 1:
                    raise HTTPException(status_code=422, detail="Fonds insuffisants.")
                await db.execute(
                    "INSERT INTO vehicles (user_id,veh_type,condition,insured,purchased_at,last_maintenance,speed,cargo,luxury,fuel) "
                    "VALUES (?,?,100,0,?,?,?,?,?,?)",
                    (user_id, body.veh_type, database.now(), database.now(), data.get("speed", 0),
                     data.get("cargo", 0), data.get("luxury", 0), data.get("fuel_capacity", 0)))
                await database.snapshot_user_core_stats(user_id, db)
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except HTTPException:
        raise
    except Exception:
        if claimed:
            await release_cooldown(user_id, "buy_vehicle")
        raise
    return {"bought": body.veh_type, "price": data["price"], "prestige": data["status"]}


class VehicleIn(BaseModel):
    veh_id: int


@router.post("/sell")
async def sell(body: VehicleIn, user_id: int = Depends(require_character_complete)):
    claimed = await _reserve(user_id, "sell_vehicle", 10,
        "⏳ Attends un instant avant de vendre un autre véhicule.")
    try:
        async with database.db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                async with db.execute(
                    "SELECT * FROM vehicles WHERE veh_id=? AND user_id=?", (body.veh_id, user_id)
                ) as cur:
                    row = await cur.fetchone()
                if not row:
                    raise HTTPException(status_code=404, detail="Véhicule introuvable dans ton garage.")
                vehicle = dict(row)
                data = VEHICLES.get(vehicle["veh_type"], {})
                price = _resale_price(vehicle)
                if price <= 0:
                    raise HTTPException(status_code=422, detail="Ce véhicule ne vaut plus rien.")
                prestige = int(data.get("status", 0))
                updated = await db.execute(
                    "UPDATE users SET balance=balance+?, total_earned=total_earned+?, "
                    "prestige=prestige-? WHERE user_id=?",
                    (price, price, prestige, user_id),
                )
                if updated.rowcount != 1:
                    raise HTTPException(status_code=404, detail="Joueur introuvable.")
                deleted = await db.execute(
                    "DELETE FROM vehicles WHERE veh_id=? AND user_id=?", (body.veh_id, user_id)
                )
                if deleted.rowcount != 1:
                    raise HTTPException(status_code=404, detail="Véhicule introuvable dans ton garage.")
                await db.execute(
                    "UPDATE users SET active_vehicle_id=NULL WHERE user_id=? AND active_vehicle_id=?",
                    (user_id, body.veh_id),
                )
                await database.snapshot_user_core_stats(user_id, db)
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except HTTPException:
        raise
    except Exception:
        if claimed:
            await release_cooldown(user_id, "sell_vehicle")
        raise
    return {"sold": body.veh_id, "veh_type": vehicle["veh_type"], "price": price,
            "prestige_removed": prestige}


@router.post("/active")
async def set_active(body: VehicleIn, user_id: int = Depends(require_character_complete)):
    blocked = await free_problem(user_id, "handlers.vehicles")
    if blocked:
        raise HTTPException(status_code=422, detail=blocked)
    async with database.db_connection() as db:
        cur = await db.execute("UPDATE users SET active_vehicle_id=? WHERE user_id=? AND EXISTS "
                                "(SELECT 1 FROM vehicles WHERE veh_id=? AND user_id=?)",
                                (body.veh_id, user_id, body.veh_id, user_id))
        if cur.rowcount != 1:
            raise HTTPException(status_code=404, detail="Véhicule introuvable dans ton garage.")
        await db.commit()
    return {"active_vehicle_id": body.veh_id}


async def _reserve(user_id: int, key: str, duration: int, error: str):
    blocked = await free_problem(user_id, "handlers.vehicles")
    if blocked:
        raise HTTPException(status_code=422, detail=blocked)
    message, claimed = await cooldown_problem(user_id, key, duration, error)
    if message:
        raise HTTPException(status_code=429, detail=message)
    return claimed


@router.post("/insure")
async def insure(body: VehicleIn, user_id: int = Depends(require_character_complete)):
    claimed = await _reserve(user_id, "insure_vehicle", 10, "⏳ Attends encore {remaining} avant d'assurer un véhicule.")
    try:
        async with database.db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                async with db.execute(
                    "SELECT * FROM vehicles WHERE veh_id=? AND user_id=?", (body.veh_id, user_id)
                ) as cur:
                    row = await cur.fetchone()
                if not row:
                    raise HTTPException(status_code=404, detail="Véhicule introuvable.")
                vehicle = dict(row)
                if vehicle.get("insured"):
                    raise HTTPException(status_code=422, detail="Ce véhicule est déjà assuré.")
                data = VEHICLES.get(vehicle["veh_type"], {})
                price = max(100, int(data.get("price", 10_000) * 0.05))
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?,total_spent=total_spent+? "
                    "WHERE user_id=? AND balance>=?", (price, price, user_id, price)
                )
                if debit.rowcount != 1:
                    raise HTTPException(status_code=422, detail=f"Fonds insuffisants. Prime : {price} €A.")
                await db.execute("UPDATE vehicles SET insured=1 WHERE veh_id=? AND user_id=?", (body.veh_id, user_id))
                from utils.treasury import collect
                await collect(db, price, "vehicules")
                await database.snapshot_user_core_stats(user_id, db)
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except HTTPException:
        raise
    except Exception:
        if claimed:
            await release_cooldown(user_id, "insure_vehicle")
        raise
    return {"insured": body.veh_id, "price": price}


@router.post("/repair")
async def repair(body: VehicleIn, user_id: int = Depends(require_character_complete)):
    claimed = await _reserve(user_id, "repair_vehicle", 10, "⏳ Attends encore {remaining} avant de réparer.")
    try:
        async with database.db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                async with db.execute("SELECT * FROM vehicles WHERE veh_id=? AND user_id=?", (body.veh_id, user_id)) as cur:
                    row = await cur.fetchone()
                if not row:
                    raise HTTPException(status_code=404, detail="Véhicule introuvable.")
                v = dict(row)
                if v["condition"] >= 100:
                    raise HTTPException(status_code=422, detail="Ce véhicule est déjà en parfait état.")
                luxury = v.get("luxury", 0) or VEHICLES.get(v["veh_type"], {}).get("luxury", 0)
                cost = max(100, int((100 - v["condition"]) * (luxury * 2 + 50) / 100))
                if v.get("insured"):
                    cost = max(50, cost // 2)
                debit = await db.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                                         "WHERE user_id=? AND balance>=?", (cost, cost, user_id, cost))
                if debit.rowcount != 1:
                    raise HTTPException(status_code=422, detail=f"Fonds insuffisants. Coût de réparation : {cost}.")
                await db.execute("UPDATE vehicles SET condition=100,last_maintenance=? WHERE veh_id=? AND user_id=?",
                                 (database.now(), body.veh_id, user_id))
                from utils.treasury import collect
                await collect(db, cost, "vehicules")
                await database.snapshot_user_core_stats(user_id, db)
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except HTTPException:
        raise
    except Exception:
        if claimed:
            await release_cooldown(user_id, "repair_vehicle")
        raise
    return {"repaired": body.veh_id, "price": cost, "condition": 100}


@router.post("/refuel")
async def refuel(user_id: int = Depends(require_character_complete)):
    claimed = await _reserve(user_id, "refuel", 60, "⏳ Attends encore {remaining} avant de refaire le plein.")
    try:
        async with database.db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                async with db.execute("SELECT v.* FROM vehicles v JOIN users u ON u.active_vehicle_id=v.veh_id "
                                      "WHERE v.user_id=? AND u.user_id=?", (user_id, user_id)) as cur:
                    row = await cur.fetchone()
                if not row:
                    raise HTTPException(status_code=422, detail="Aucun véhicule actif.")
                v = dict(row)
                capacity = int(VEHICLES.get(v["veh_type"], {}).get("fuel_capacity", 0))
                if capacity <= 0:
                    raise HTTPException(status_code=422, detail="Ce véhicule n'utilise pas de carburant.")
                fuel = int(v.get("fuel", 0) or 0)
                if fuel >= capacity:
                    raise HTTPException(status_code=422, detail="Le réservoir est déjà plein.")
                cost = (capacity - fuel) * 10
                debit = await db.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                                         "WHERE user_id=? AND balance>=?", (cost, cost, user_id, cost))
                if debit.rowcount != 1:
                    raise HTTPException(status_code=422, detail=f"Fonds insuffisants. Coût : {cost}.")
                await db.execute("UPDATE vehicles SET fuel=? WHERE veh_id=? AND user_id=?", (capacity, v["veh_id"], user_id))
                from utils.treasury import collect
                await collect(db, cost, "vehicules")
                await database.snapshot_user_core_stats(user_id, db)
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except HTTPException:
        raise
    except Exception:
        if claimed:
            await release_cooldown(user_id, "refuel")
        raise
    return {"vehicle": v["veh_type"], "fuel": capacity, "fuel_capacity": capacity, "price": cost}
