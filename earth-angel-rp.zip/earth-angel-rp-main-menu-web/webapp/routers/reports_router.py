"""webapp/routers/reports_router.py — Signalements (Mini App + Web).

Mêmes règles que le bot : tout vient de `gameplay/reports.py` (types, saisie minimale, cooldown
5 min hors staff, 1 h par cible, traitement staff avec notification de l'auteur).
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from gameplay import reports as reports_service
from utils.helpers import fmt_time
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/reports", tags=["reports"])


def _type_view(code: str) -> dict:
    t = reports_service.REPORT_TYPES.get(code, {"name": code, "emoji": "📝"})
    return {"name": t["name"], "emoji": t["emoji"]}


def _row(r: dict) -> dict:
    return {
        "id": r["id"], "type": r["report_type"], **{f"type_{k}": v for k, v in _type_view(r["report_type"]).items()},
        "message": r["message"], "target_id": r.get("target_id"), "status": r["status"],
        "status_emoji": reports_service.STATUS_EMOJI.get(r["status"], "❓"),
        "admin_response": r.get("admin_response"), "created_at": r["created_at"],
        **({"reporter_name": r["reporter_name"]} if "reporter_name" in r else {}),
    }


async def _staff(user_id: int) -> None:
    if not await reports_service.is_staff(user_id):
        raise HTTPException(status_code=403, detail="Réservé au staff.")


@router.get("")
async def overview(user_id: int = Depends(require_character_complete)):
    mine = await reports_service.get_user_reports(user_id, 20)
    return {
        "types": [{"code": c, **_type_view(c)} for c in reports_service.REPORT_TYPES],
        "min_length": reports_service.MIN_LEN,
        "mine": [_row(r) for r in mine],
        "open_count": sum(1 for r in mine if r["status"] in ("pending", "in_progress")),
        "is_staff": await reports_service.is_staff(user_id),
    }


class ReportIn(BaseModel):
    type: str = "other"
    message: str
    target_id: int | None = None


@router.post("")
async def submit(body: ReportIn, user_id: int = Depends(require_character_complete)):
    result = await reports_service.submit(user_id, body.type, body.message, body.target_id)
    if not result["ok"]:
        reason = result["reason"]
        if reason == "cooldown":
            raise HTTPException(status_code=429, detail=f"Tu as déjà envoyé un signalement récemment. Attends encore {fmt_time(result['remaining'])}.")
        detail = {
            "too_short": f"Trop court (minimum {reports_service.MIN_LEN} caractères).",
            "self_target": "Tu ne peux pas te signaler toi-même.",
            "recent_target": "Tu as déjà signalé ce joueur récemment. Attends 1 heure.",
            "unknown_target": "Joueur introuvable.",
        }.get(reason, "Signalement impossible.")
        raise HTTPException(status_code=422, detail=detail)
    return result


@router.get("/staff")
async def staff_list(status: str = "pending", user_id: int = Depends(require_character_complete)):
    await _staff(user_id)
    if status not in reports_service.STATUS_LABEL:
        raise HTTPException(status_code=422, detail="Statut invalide.")
    return {"reports": [_row(r) for r in await reports_service.get_reports(status, 50)],
            "stats": await reports_service.get_report_stats()}


class HandleIn(BaseModel):
    status: str
    response: str | None = None


@router.post("/staff/{report_id}")
async def staff_handle(report_id: int, body: HandleIn, user_id: int = Depends(require_character_complete)):
    await _staff(user_id)
    if body.status not in reports_service.STATUS_LABEL:
        raise HTTPException(status_code=422, detail="Statut invalide.")
    reporter = await reports_service.set_status(report_id, body.status, (body.response or "").strip() or None)
    if reporter is None:
        raise HTTPException(status_code=404, detail="Signalement introuvable.")
    return {"ok": True, "report_id": report_id, "status": body.status}
