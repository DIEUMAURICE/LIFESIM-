"""webapp/routers/political_router.py — Vie politique : destitution et mandat présidentiel.

Réutilise `utils/politics.py`, le même service pur déjà partagé avec `handlers/political.py` —
aucune règle n'est recalculée ici (quorum, majorité, immunité, délais de signature/vote).

Élections (lancement, candidature, vote) : `gameplay/elections.py`, le même service que le bot ;
le dépouillement reste automatique (`political_maintenance`). Lois, référendums et constitution :
`gameplay/laws.py`. Gouvernement (nominations/révocations) : `gameplay/cabinet.py`.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import re

from config import LAW_PROPOSAL_COST, REFERENDUM_COST, ELECTION_COST, ELECTION_COOLDOWN, ELECTION_KARMA_REQUIRED, ELECTED_POSTS
from gameplay import elections as elections_service
from gameplay import laws as laws_service
from gameplay import cabinet as cabinet_service
from utils import politics as politics_service
from utils.cooldowns import release_cooldown
from utils.decorators import cooldown_problem, free_problem
from utils.roles import can_play, is_politician, is_president
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/political", tags=["political"])


@router.get("/status")
async def status(user_id: int = Depends(require_character_complete)):
    office = await politics_service.office_info(user_id)
    term_left = None
    if office and office["kind"] == "president":
        term_left = await politics_service.term_left(user_id)
    events = await politics_service.recent_events(limit=12)
    return {
        "office": office,
        "term_left_seconds": term_left,
        "registered_players": await politics_service.registered_count(),
        "journal": [
            {"type": event_type, "description": description, "timestamp": timestamp}
            for event_type, description, timestamp in events
        ],
    }


@router.get("/motions")
async def motions(user_id: int = Depends(require_character_complete)):
    return {"motions": await politics_service.motions_overview()}


class MotionTargetIn(BaseModel):
    target_id: int


@router.post("/motion")
async def start_motion(body: MotionTargetIn, user_id: int = Depends(require_character_complete)):
    ok, message, _info = await politics_service.check_motion(user_id, body.target_id)
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    motion_id = await politics_service.create_motion(user_id, body.target_id)
    return {"started": True, "motion_id": motion_id}


@router.post("/motion/sign")
async def sign_motion(body: MotionTargetIn, user_id: int = Depends(require_character_complete)):
    ok, message = await politics_service.sign_motion(user_id, body.target_id)
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    return {"signed": True, "message": message}


class MotionVoteIn(BaseModel):
    choice: str  # "pour" | "contre"
    target_id: int | None = None


@router.post("/motion/vote")
async def vote_motion(body: MotionVoteIn, user_id: int = Depends(require_character_complete)):
    ok, message = await politics_service.vote_motion(user_id, body.choice, body.target_id)
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    return {"voted": True, "message": message}


# ─── Élections ───────────────────────────────────────────────────────────────────────────────────
_ELECTION_REFUSALS = {
    "unknown_post": (422, "Poste inconnu."),
    "not_elected_post": (422, "Ce poste n'est pas élu : les ministres sont nommés par le président."),
    "already_open": (422, "Une élection pour ce poste est déjà en cours."),
    "insufficient_funds": (422, "Solde insuffisant."),
    "karma": (422, f"Karma insuffisant ({ELECTION_KARMA_REQUIRED} requis)."),
    "not_politician": (403, "Réservé aux Admins N1."),
    "not_player": (403, "Les élections sont réservées aux joueurs."),
    "no_election": (422, "Aucune élection ouverte avec cet identifiant."),
    "already_candidate": (422, "Tu es déjà candidat à cette élection."),
    "already_voted": (422, "Tu as déjà voté."),
    "not_candidate": (422, "Ce joueur n'est pas candidat."),
    "empty": (422, "Texte requis."),
    "too_short": (422, "Le texte doit faire au moins 10 caractères."),
    "not_found": (422, "Scrutin introuvable ou terminé."),
    "bad_choice": (422, "Choix invalide : pour ou contre."),
    "unknown_position": (422, "Ministère inconnu."),
    "not_president": (403, "Seul le Président élu peut le faire."),
    "target_not_player": (422, "Cette personne n'intervient pas dans la politique."),
    "vacant": (422, "Ce ministère est déjà vacant."),
    "not_government": (403, "Seuls le Président et les ministres peuvent proposer une modification de la constitution."),
}


def _refuse(result: dict):
    status, detail = _ELECTION_REFUSALS.get(result.get("reason"), (422, "Action impossible."))
    raise HTTPException(status_code=status, detail=detail)


def _plain(message: str) -> str:
    return re.sub(r"<[^>]+>", "", message)


@router.get("/elections")
async def elections(user_id: int = Depends(require_character_complete)):
    return {
        "elections": await elections_service.list_open_elections(),
        "my_votes": {str(k): v for k, v in (await elections_service.my_votes(user_id)).items()},
        "can_vote": await can_play(user_id),
        "can_run": await is_politician(user_id),
        "me": user_id,
        "costs": dict(ELECTION_COST),
        "elected_posts": list(ELECTED_POSTS),
    }


class ElectionStartIn(BaseModel):
    poste: str
    duration_hours: int | None = None


@router.post("/elections/start")
async def start_election(body: ElectionStartIn, user_id: int = Depends(require_character_complete)):
    # Mêmes garde-fous que /lancerelection : politicien, libre d'agir, cooldown atomique.
    if not await is_politician(user_id):
        _refuse({"reason": "not_politician"})
    blocked = await free_problem(user_id, "handlers.political")
    if blocked:
        raise HTTPException(status_code=403, detail=_plain(blocked))
    poste = elections_service.resolve_poste(body.poste)
    if not poste:
        _refuse({"reason": "unknown_post"})
    message, reserved = await cooldown_problem(
        user_id, "last_election", ELECTION_COOLDOWN, "⏳ Tu as déjà lancé une élection récemment.")
    if message:
        raise HTTPException(status_code=429, detail=_plain(message))
    try:
        result = await elections_service.start_election(user_id, poste, body.duration_hours)
    except Exception:
        if reserved:
            await release_cooldown(user_id, "last_election")
        raise
    if not result["ok"]:
        if reserved:
            await release_cooldown(user_id, "last_election")
        _refuse(result)
    return result


class CandidateIn(BaseModel):
    election_id: int
    program: str = ""


@router.post("/elections/candidate")
async def candidate(body: CandidateIn, user_id: int = Depends(require_character_complete)):
    blocked = await free_problem(user_id, "handlers.political")
    if blocked:
        raise HTTPException(status_code=403, detail=_plain(blocked))
    result = await elections_service.register_candidate(user_id, body.election_id, body.program)
    if not result["ok"]:
        _refuse(result)
    return result


class VoteIn(BaseModel):
    election_id: int
    candidate_id: int


@router.post("/elections/vote")
async def vote(body: VoteIn, user_id: int = Depends(require_character_complete)):
    result = await elections_service.cast_vote(user_id, body.election_id, body.candidate_id)
    if not result["ok"]:
        _refuse(result)
    return result


# ─── Lois, référendums, constitution ─────────────────────────────────────────────────────────────
async def _players_only_free(user_id: int, *, free: bool = True):
    if not await can_play(user_id):
        _refuse({"reason": "not_player"})
    if free:
        blocked = await free_problem(user_id, "handlers.political")
        if blocked:
            raise HTTPException(status_code=403, detail=_plain(blocked))


@router.get("/laws")
async def laws(user_id: int = Depends(require_character_complete)):
    votes = await laws_service.my_votes(user_id)
    return {**await laws_service.list_laws(), "my_votes": {str(k): v for k, v in votes["laws"].items()},
            "can_vote": await can_play(user_id), "cost": LAW_PROPOSAL_COST}


class LawIn(BaseModel):
    title: str
    description: str


@router.post("/laws/propose")
async def propose_law(body: LawIn, user_id: int = Depends(require_character_complete)):
    await _players_only_free(user_id)
    result = await laws_service.propose_law(user_id, body.title, body.description)
    if not result["ok"]:
        _refuse(result)
    return result


class PollVoteIn(BaseModel):
    id: int
    choice: str  # "pour" | "contre"


@router.post("/laws/vote")
async def vote_law(body: PollVoteIn, user_id: int = Depends(require_character_complete)):
    await _players_only_free(user_id, free=False)
    result = await laws_service.vote_law(user_id, body.id, laws_service.parse_choice(body.choice) or 0)
    if not result["ok"]:
        _refuse(result)
    return result


@router.get("/referendums")
async def referendums(user_id: int = Depends(require_character_complete)):
    votes = await laws_service.my_votes(user_id)
    return {"referendums": await laws_service.list_referendums(),
            "my_votes": {str(k): v for k, v in votes["referendums"].items()},
            "can_vote": await can_play(user_id), "cost": REFERENDUM_COST}


class ReferendumIn(BaseModel):
    question: str


@router.post("/referendums/propose")
async def propose_referendum(body: ReferendumIn, user_id: int = Depends(require_character_complete)):
    await _players_only_free(user_id)
    result = await laws_service.propose_referendum(user_id, body.question)
    if not result["ok"]:
        _refuse(result)
    return result


@router.post("/referendums/vote")
async def vote_referendum(body: PollVoteIn, user_id: int = Depends(require_character_complete)):
    await _players_only_free(user_id, free=False)
    result = await laws_service.vote_referendum(user_id, body.id, laws_service.parse_choice(body.choice) or 0)
    if not result["ok"]:
        _refuse(result)
    return result


@router.get("/constitution")
async def constitution(user_id: int = Depends(require_character_complete)):
    return await laws_service.get_constitution()


class ConstitutionIn(BaseModel):
    text: str


@router.post("/constitution/propose")
async def propose_constitution(body: ConstitutionIn, user_id: int = Depends(require_character_complete)):
    # Mêmes garde-fous que /modifierconstitution : libre d'agir, cooldown hebdomadaire atomique.
    blocked = await free_problem(user_id, "handlers.political")
    if blocked:
        raise HTTPException(status_code=403, detail=_plain(blocked))
    message, reserved = await cooldown_problem(
        user_id, "last_constitution", laws_service.CONSTITUTION_COOLDOWN,
        "⏳ La constitution ne peut être modifiée qu'une fois par semaine.")
    if message:
        raise HTTPException(status_code=429, detail=_plain(message))
    try:
        result = await laws_service.propose_constitution(user_id, body.text)
    except Exception:
        if reserved:
            await release_cooldown(user_id, "last_constitution")
        raise
    if not result["ok"]:
        if reserved:
            await release_cooldown(user_id, "last_constitution")
        _refuse(result)
    return result


# ─── Gouvernement ────────────────────────────────────────────────────────────────────────────────
@router.get("/government")
async def government(user_id: int = Depends(require_character_complete)):
    return {**await cabinet_service.government(), "is_president": await is_president(user_id)}


class AppointIn(BaseModel):
    position: str
    target_user_id: int


@router.post("/government/appoint")
async def appoint_minister(body: AppointIn, user_id: int = Depends(require_character_complete)):
    position = cabinet_service.resolve_position(body.position)
    if not position:
        _refuse({"reason": "unknown_position"})
    result = await cabinet_service.appoint(user_id, body.target_user_id, position)
    if not result["ok"]:
        if result["reason"] == "refused":
            raise HTTPException(status_code=422, detail=result.get("message") or "Nomination impossible.")
        _refuse(result)
    return result


class DismissIn(BaseModel):
    position: str


@router.post("/government/dismiss")
async def dismiss_minister(body: DismissIn, user_id: int = Depends(require_character_complete)):
    position = cabinet_service.resolve_position(body.position)
    if not position:
        _refuse({"reason": "unknown_position"})
    result = await cabinet_service.dismiss(user_id, position)
    if not result["ok"]:
        _refuse(result)
    return result
