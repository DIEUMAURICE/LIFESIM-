"""webapp/routers/notifications_router.py — File de notifications (handlers/notifications.py).

Le bot délivre les notifications « en attente » en les envoyant en message Telegram, puis les
marque sent=1 (`mark_notification_sent`). Pour la webapp, consulter `/pending` EST l'acte de
délivrance — il n'y a pas d'autre canal pour un joueur connecté en Google : on marque donc
aussi sent=1 au passage, avec exactement la même fonction que le bot. Si un joueur Telegram
utilise la mini app ET le bot, la notification sera donc vue une seule fois (webapp ou Telegram,
celui qui la consulte en premier) plutôt que livrée deux fois — comportement voulu.

Les commandes admin (broadcast, notifier un joueur précis) ne sont pas exposées ici : elles
relèvent du panneau staff, pas du joueur.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends

from database import db_connection
from handlers.notifications import (
    NOTIF_TYPES, get_notification_history, get_pending_notifications, mark_notification_sent,
)
from utils.helpers import now
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/notifications", tags=["notifications"])


def _out(n: dict) -> dict:
    return {
        "id": n["id"], "title": n["title"], "message": n["message"],
        "type": n.get("type", "info"), "emoji": NOTIF_TYPES.get(n.get("type"), "📌"),
        "created_at": n["created_at"],
    }


@router.get("/pending")
async def pending(user_id: int = Depends(require_character_complete)):
    notifs = await get_pending_notifications(user_id)
    for n in notifs:
        await mark_notification_sent(n["id"])
    return {"notifications": [_out(n) for n in notifs]}


@router.get("/history")
async def history(user_id: int = Depends(require_character_complete)):
    notifs = await get_notification_history(user_id, 30)
    return {
        "notifications": [
            {**_out(n), "sent_at": n.get("sent_at")} for n in notifs
        ]
    }


@router.post("/clear")
async def clear(user_id: int = Depends(require_character_complete)):
    async with db_connection() as db:
        cur = await db.execute("DELETE FROM notifications WHERE user_id = ? AND sent = 0", (user_id,))
        await db.commit()
    return {"deleted": cur.rowcount}
