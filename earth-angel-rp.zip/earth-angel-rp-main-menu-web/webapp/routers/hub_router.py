"""Catalogue en lecture seule du menu principal Telegram, partagé avec Mini App et Web."""
from __future__ import annotations

from fastapi import APIRouter, Depends

from handlers.hub import ESSENTIAL_ZONES, _item_idx, _visible, is_beginner
from handlers.hub_data import AREAS, ITEMS, ZONE_INTRO
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/hub", tags=["game hub"])


@router.get("/menu")
async def main_menu(
    show_all: bool = False,
    user_id: int = Depends(require_character_complete),
):
    simple_menu = await is_beginner(user_id) and not show_all
    areas = []
    for area_id, label, _legacy_menu in AREAS:
        if simple_menu and area_id not in ESSENTIAL_ZONES:
            continue
        visible_sections = await _visible(area_id, user_id)
        sections = []
        for section_index, section_label, entries in visible_sections:
            actions = []
            for entry in entries:
                kind, ref, action_label, description = entry[:4]
                function = str(ref) if kind == "form" else ITEMS[int(ref)][1]
                actions.append({
                    "id": f"{kind}:{ref}", "function": function, "label": action_label,
                    "description": description, "kind": kind,
                })
            sections.append({"id": section_index, "label": section_label, "actions": actions})
        areas.append({
            "id": area_id, "label": label, "description": ZONE_INTRO.get(area_id, ""), "sections": sections,
            "action_count": sum(len(section["actions"]) for section in sections),
        })
    quick_actions = []
    if simple_menu:
        for function, label in (("quotidien", "Bonus du jour"), ("travailler", "Travailler"), ("tutorial", "Tutoriel")):
            index = _item_idx(function)
            if index is not None:
                item = ITEMS[index]
                quick_actions.append({"function": function, "label": label, "description": item[6]})
    return {
        "areas": areas, "source": "handlers.hub_data.AREAS", "simple_menu": simple_menu,
        "quick_actions": quick_actions, "total_areas": len(AREAS),
    }
