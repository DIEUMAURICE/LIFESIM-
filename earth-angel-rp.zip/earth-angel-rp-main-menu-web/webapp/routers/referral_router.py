"""API Web du parrainage, utilisant le même moteur que le bot."""
from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from gameplay.referrals import ReferralError, start_referral, summary
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/referrals", tags=["referrals"])

class ReferralIn(BaseModel):
    token: str = Field(min_length=5, max_length=40)

@router.get("")
async def get_summary(uid: int = Depends(require_character_complete)):
    return await summary(uid)

@router.post("/start")
async def start(body: ReferralIn, uid: int = Depends(require_character_complete)):
    token = body.token.strip()
    if token.startswith("ref_"): token = token[4:]
    if not token.isdigit(): raise HTTPException(422, "Token de parrainage invalide.")
    try: result = await start_referral(uid, int(token))
    except ReferralError as exc: raise HTTPException(409, str(exc))
    return {"ok": True, "message": "Parrainage activé.", **result}

@router.post("/activate")
async def activate(uid: int = Depends(require_character_complete)):
    from gameplay.referrals import process_activation
    result = await process_activation(uid)
    if not result: raise HTTPException(409, "Les conditions d’activation ne sont pas encore atteintes.")
    return {"ok": True, "message": "Récompense d’activation attribuée.", **result}
