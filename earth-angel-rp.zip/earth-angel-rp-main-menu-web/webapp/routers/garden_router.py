"""API Jardin : mêmes plantes, saisons, cooldowns et récompenses que le bot."""
from __future__ import annotations

import random
import aiosqlite
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from config import PLANTS
from database import db_connection, get_user, now, update_balance, update_field, increment_field
from handlers.garden import WATER_COOLDOWN, get_max_plots, get_season_multiplier, _grant_recolte
from handlers.missions import update_mission_progress
from utils.decorators import free_problem
from utils.vip import add_coins, add_xp
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/garden", tags=["garden"])
MAX_PLOTS = 10

async def _free(uid: int):
    problem = await free_problem(uid, "handlers.garden")
    if problem:
        import re
        raise HTTPException(409, re.sub(r"<[^>]+>", "", problem))

class PlantIn(BaseModel):
    plant_type: str
class PlotIn(BaseModel):
    plot_id: int = Field(gt=0)

async def _plots(uid: int):
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM garden WHERE user_id=? ORDER BY plot_id", (uid,)) as cur:
            return [dict(x) for x in await cur.fetchall()]

def _view(plot, mult, t):
    p = PLANTS.get(plot["plant_type"], {})
    grow = int(p.get("grow_time", 0) / mult)
    elapsed = max(0, t - plot["planted_at"])
    ready = elapsed >= grow
    water_need = p.get("water_needed", 1)
    return {**plot, "emoji": p.get("emoji", "🌱"), "value": int(p.get("value", 0) * mult), "illegal": bool(p.get("illegal")), "water_needed": water_need, "ready": ready, "remaining": max(0, grow - elapsed), "water_remaining": max(0, water_need - plot.get("water_count", 0))}

@router.get("/home")
async def home(uid: int = Depends(require_character_complete)):
    plots = await _plots(uid); mult = await get_season_multiplier(uid); max_plots = await get_max_plots(uid); t = now()
    return {"plots": [_view(p, mult, t) for p in plots], "max_plots": max_plots, "season_multiplier": mult, "plants": [{"type": k, **v, "seed_cost": int(v["value"] * mult // 10)} for k, v in PLANTS.items()]}

@router.post("/plant")
async def plant(body: PlantIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    if body.plant_type not in PLANTS: raise HTTPException(422, "Plante inconnue.")
    plots = await _plots(uid)
    if len(plots) >= await get_max_plots(uid): raise HTTPException(409, "Toutes tes parcelles sont occupées.")
    mult = await get_season_multiplier(uid); data = PLANTS[body.plant_type]; cost = int(data["value"] * mult // 10); me = await get_user(uid)
    if (me.get("balance") or 0) < cost: raise HTTPException(400, "Fonds insuffisants pour les graines.")
    await update_balance(uid, -cost, sink="agriculture")
    async with db_connection() as db:
        await db.execute("INSERT INTO garden (user_id,plant_type,planted_at,watered_at,water_count,ready) VALUES (?,?,?,0,0,0)", (uid, body.plant_type, now())); await db.commit()
    await update_mission_progress(uid, "plant", 1)
    return {"ok": True, "message": f"{data['emoji']} {body.plant_type} planté !", "cost": cost}

@router.post("/water")
async def water(body: PlotIn, uid: int = Depends(require_character_complete)):
    await _free(uid); plots = await _plots(uid); plot = next((p for p in plots if p["plot_id"] == body.plot_id), None)
    if not plot: raise HTTPException(404, "Parcelle introuvable.")
    need = PLANTS[plot["plant_type"]].get("water_needed", 1)
    if plot.get("water_count", 0) >= need: raise HTTPException(409, "Cette plante a déjà assez d'eau.")
    last = plot.get("watered_at") or 0
    if last and now() - last < WATER_COOLDOWN: raise HTTPException(429, f"Attends encore {WATER_COOLDOWN - (now()-last)} secondes.")
    async with db_connection() as db:
        await db.execute("UPDATE garden SET water_count=water_count+1,watered_at=? WHERE plot_id=? AND user_id=?", (now(),body.plot_id,uid)); await db.commit()
    return {"ok": True, "message": "Parcelle arrosée !"}

@router.post("/harvest")
async def harvest(body: PlotIn, uid: int = Depends(require_character_complete)):
    await _free(uid); plots = await _plots(uid); plot = next((p for p in plots if p["plot_id"] == body.plot_id), None)
    if not plot: raise HTTPException(404, "Parcelle introuvable.")
    mult = await get_season_multiplier(uid); view = _view(plot, mult, now())
    if not view["ready"]: raise HTTPException(409, f"La plante sera prête dans {view['remaining']} secondes.")
    data = PLANTS[plot["plant_type"]]; water_bonus = min(1.5, 1.0 + (plot.get("water_count", 0) / max(1, data.get("water_needed", 1))) * .5); value = int(data["value"] * water_bonus * mult)
    me = await get_user(uid)
    if data.get("illegal"):
        risk = max(.05, min(.4, .2 - (me.get("karma", 0) / 5000)))
        if random.random() < risk:
            await update_field(uid, "prison_until", now() + 7200)
            async with db_connection() as db: await db.execute("DELETE FROM garden WHERE plot_id=? AND user_id=?", (body.plot_id,uid)); await db.commit()
            raise HTTPException(409, "Arrestation pendant la récolte illégale.")
    async with db_connection() as db: await db.execute("DELETE FROM garden WHERE plot_id=? AND user_id=?", (body.plot_id,uid)); await db.commit()
    await add_coins(uid, value); await increment_field(uid, "plants_grown"); await _grant_recolte(uid, 1); await add_xp(uid, 50); await update_mission_progress(uid, "harvest", 1)
    return {"ok": True, "message": f"Récolte : +{value:,} €A et +50 XP.", "value": value}


@router.post("/harvest/all")
async def harvest_all(uid: int = Depends(require_character_complete)):
    await _free(uid)
    from gameplay.garden import GardenError, harvest_all_ready
    try:
        result = await harvest_all_ready(uid)
    except GardenError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    if result["arrested"]:
        message = f"Récolte groupée : +{result['total']:,} €A, +{result['xp']} XP. Arrestation : {', '.join(result['arrested'])}."
    else:
        message = f"Récolte groupée : +{result['total']:,} €A et +{result['xp']} XP."
    return {"ok": True, "message": message, **result}
