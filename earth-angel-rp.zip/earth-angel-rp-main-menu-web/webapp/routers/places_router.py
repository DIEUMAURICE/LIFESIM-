"""webapp/routers/places_router.py — Position du joueur et déplacements (utils/location.py).

Réutilisé par tous les lieux (hôpital, banque, etc.) : l'écran demande les moyens de transport
possibles vers une destination, puis lance le trajet. Même logique que le bot (énergie,
carburant, taxi, véhicules).
"""
from __future__ import annotations

import html
import re

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from config import LOCATIONS
from utils import location as loc
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/places", tags=["places"])

_TAG = re.compile(r"<[^>]+>")


def plain(msg: str) -> str:
    """Les messages du bot sont en HTML Telegram : on les rend en texte brut pour l'API."""
    return html.unescape(_TAG.sub("", msg or ""))


@router.get("/here")
async def here(user_id: int = Depends(require_character_complete)):
    pos = await loc.get_position(user_id)
    return {
        "location": pos["location"],
        "label": loc.location_label(pos["location"]),
        "in_transit": pos["in_transit"],
        "travel_to": pos["travel_to"] or None,
        "travel_to_label": loc.location_label(pos["travel_to"]) if pos["in_transit"] else None,
        "remaining_seconds": pos["remaining"],
    }


@router.get("/options")
async def options(dest: str, user_id: int = Depends(require_character_complete)):
    if dest not in LOCATIONS:
        raise HTTPException(status_code=404, detail="Lieu inconnu.")
    pos = await loc.get_position(user_id)
    if pos["in_transit"]:
        raise HTTPException(
            status_code=423,
            detail=f"Tu es déjà en route vers {plain(loc.location_label(pos['travel_to']))}.",
        )
    if pos["location"] == dest:
        raise HTTPException(status_code=422, detail="Tu es déjà sur place.")
    opts = await loc.plan_options(user_id, pos["location"], dest)
    return {
        "dest": dest,
        "dest_label": loc.location_label(dest),
        "from_label": loc.location_label(pos["location"]),
        "options": [
            {"mode": o["mode"], "label": o["label"], "km": o["km"], "duration_seconds": o["duration"],
             "energy": o["energy"], "fuel": o["fuel"], "money": o["money"], "ok": o["ok"], "why": o["why"]}
            for o in opts
        ],
    }


class TravelIn(BaseModel):
    dest: str
    mode: str


@router.post("/travel")
async def travel(body: TravelIn, user_id: int = Depends(require_character_complete)):
    ok, msg = await loc.start_travel(user_id, body.dest, body.mode)
    if not ok:
        raise HTTPException(status_code=422, detail=plain(msg))
    return {"ok": True, "message": plain(msg)}
