"""API commune des défis Combat pour la Mini App Telegram et le Web."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from database import get_user
from gameplay.combat import resolve_combat
from utils.arena_store import accept_and_fund_match, create_match, get_match
from utils.notify import notify
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/arena", tags=["arena"])


class ChallengeIn(BaseModel):
    target_id: int
    bet: int = Field(gt=0)


async def _participant(match_id: str, user_id: int) -> dict:
    match = await get_match(match_id)
    if not match or user_id not in (match["challenger_id"], match["target_id"]):
        raise HTTPException(status_code=404, detail="Défi introuvable.")
    return match


@router.post("/challenges")
async def challenge(body: ChallengeIn, user_id: int = Depends(require_character_complete)):
    if body.target_id == user_id:
        raise HTTPException(status_code=422, detail="Tu ne peux pas te défier toi-même.")
    challenger = await get_user(user_id)
    target = await get_user(body.target_id)
    if not target or not target.get("registered"):
        raise HTTPException(status_code=404, detail="Joueur cible introuvable ou non enregistré.")
    if target.get("banned"):
        raise HTTPException(status_code=403, detail="Ce joueur est banni.")
    if body.bet < 500:
        raise HTTPException(status_code=422, detail="La mise minimale du combat est de 500 €A.")
    if int(challenger.get("balance", 0)) < body.bet:
        raise HTTPException(status_code=422, detail="Fonds insuffisants.")
    match_id = await create_match(user_id, body.target_id, "combat", body.bet, ttl=600)
    await notify(body.target_id, "🎮 Nouveau défi", f"{challenger.get('full_name', 'Joueur')} te défie en combat pour {body.bet:,} €A.", "event")
    return {"match_id": match_id, "status": "pending", "game": "combat", "bet": body.bet}


@router.get("/matches/{match_id}")
async def match_status(match_id: str, user_id: int = Depends(require_character_complete)):
    match = await _participant(match_id, user_id)
    return match


@router.post("/matches/{match_id}/accept")
async def accept(match_id: str, user_id: int = Depends(require_character_complete)):
    match = await _participant(match_id, user_id)
    if match["target_id"] != user_id:
        raise HTTPException(status_code=403, detail="Seul le joueur défié peut accepter.")
    if match["game"] != "combat":
        raise HTTPException(status_code=422, detail="Ce type de jeu n'est pas exposé par cette route.")
    funded = await accept_and_fund_match(match_id, user_id)
    if not funded:
        raise HTTPException(status_code=409, detail="Défi expiré, déjà traité ou fonds insuffisants.")
    result = await resolve_combat(match_id)
    if result is None:
        raise HTTPException(status_code=409, detail="Combat déjà résolu.")
    return result.as_dict()
