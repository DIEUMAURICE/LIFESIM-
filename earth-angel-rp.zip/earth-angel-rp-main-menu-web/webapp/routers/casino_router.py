"""API casino commune aux clients Web/Mini App; les règles de chaque jeu sont côté serveur."""
from __future__ import annotations

import random
import uuid
import time

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
from config import CASINO_MAX_BET, CASINO_MIN_BET
from handlers.casino import add_random_item, get_casino_status_text, is_casino_open, track_casino
from gameplay.casino import MINES_MAX_BET, PMU_HORSES, blackjack_action, blackjack_start, crash_multiplier_at, crash_point_from_roll, mines_cashout, mines_layout, mines_lost, mines_reveal, play_video_poker, resolve_pmu, resolve_roulette, settle_crash_cashout
from gameplay.casino_sessions import (
    claim_active_session, create_session, create_session_with_stake, find_resumable_session,
    get_session, save_claimed_session, save_claimed_session_with_payout,
)
from utils.decorators import cooldown_problem, free_problem
from utils.cooldowns import release_cooldown
from utils.location import get_position, is_exempt
from utils.vip import add_xp, chance_boost_bonus
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/casino", tags=["casino"])

SLOT_SYMBOLS = ["🍒", "🍋", "🍊", "🍇", "🔔", "💎", "7️⃣", "🌟", "🍀", "💰"]
SLOT_WEIGHTS = [20, 20, 15, 15, 10, 5, 5, 3, 4, 3]


@router.get("/status")
async def status(user_id: int = Depends(require_character_complete)):
    user = await database.get_user(user_id)
    return {
        "open": is_casino_open(),
        "status_text": get_casino_status_text(),
        "min_bet": CASINO_MIN_BET,
        "max_bet": CASINO_MAX_BET,
        "balance": user["balance"],
    }


class SpinIn(BaseModel):
    amount: int


class PokerIn(BaseModel):
    amount: int


class RouletteIn(BaseModel):
    amount: int
    bet_type: str
    number: int | None = None


class PmuIn(BaseModel):
    amount: int
    horse_index: int


class BlackjackStartIn(BaseModel):
    amount: int


class BlackjackActionIn(BaseModel):
    action: str


class MinesStartIn(BaseModel):
    amount: int


class MinesActionIn(BaseModel):
    action: str
    index: int | None = None


class CrashStartIn(BaseModel):
    amount: int


def _slot_multiplier(reels: list[str]) -> float:
    unique = set(reels)
    if len(unique) == 1:
        return 50
    if reels[0] == reels[1] == reels[2]:
        return 7
    if len(unique) == 2 and max(reels.count(s) for s in unique) >= 4:
        return 12
    if len(unique) <= 2:
        return 5
    if len(unique) == 3:
        return 1
    if "💎" in reels or "7️⃣" in reels:
        return 0.5
    return 0


@router.post("/slots/spin")
async def spin_slots(body: SpinIn, user_id: int = Depends(require_character_complete)):
    if not is_casino_open():
        raise HTTPException(status_code=423, detail=get_casino_status_text())

    user = await database.get_user(user_id)
    amount = body.amount
    if not amount or amount < CASINO_MIN_BET:
        raise HTTPException(status_code=422, detail=f"Mise minimum : {CASINO_MIN_BET}")
    if amount > CASINO_MAX_BET:
        raise HTTPException(status_code=422, detail=f"Mise maximum : {CASINO_MAX_BET}")
    if amount > user["balance"]:
        raise HTTPException(status_code=422, detail="Fonds insuffisants.")

    await database.update_balance(user_id, -amount, sink="casino")

    reels = [random.choices(SLOT_SYMBOLS, weights=SLOT_WEIGHTS)[0] for _ in range(5)]
    mult = _slot_multiplier(reels)
    win = int(amount * mult)

    if win > 0:
        await database.update_balance(user_id, win)
        await add_xp(user_id, 30)
    await track_casino(user_id, amount, win)

    loot = None
    if win > 0:
        u = await database.get_user(user_id)
        loot_chance = 0.2 + chance_boost_bonus(u)
        if random.random() < loot_chance:
            loot = await add_random_item(user_id, "common", "epic")

    final_user = await database.get_user(user_id)
    return {
        "reels": reels,
        "multiplier": mult,
        "bet": amount,
        "win": win,
        "net": win - amount,
        "loot": loot,
        "balance": final_user["balance"],
    }


@router.post("/poker/play")
async def play_poker(body: PokerIn, user_id: int = Depends(require_character_complete)):
    """Partie instantanée, réglée par le même service métier que la commande Telegram."""
    blocked = await free_problem(user_id, "handlers.casino")
    if blocked:
        raise HTTPException(status_code=422, detail=blocked)
    if not await is_exempt(user_id):
        position = await get_position(user_id)
        if position.get("location") != "casino" or position.get("in_transit"):
            raise HTTPException(status_code=422, detail="Tu dois être au casino pour jouer.")
    if not is_casino_open():
        raise HTTPException(status_code=423, detail=get_casino_status_text())

    amount = body.amount
    if amount < CASINO_MIN_BET:
        raise HTTPException(status_code=422, detail=f"Mise minimum : {CASINO_MIN_BET}")
    if amount > CASINO_MAX_BET:
        raise HTTPException(status_code=422, detail=f"Mise maximum : {CASINO_MAX_BET}")
    user = await database.get_user(user_id)
    if amount > user["balance"]:
        raise HTTPException(status_code=422, detail="Fonds insuffisants.")
    try:
        return await play_video_poker(user_id, amount)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


async def _check_table_access(user_id: int, amount: int, *, max_bet: int = CASINO_MAX_BET, require_funds: bool = True):
    blocked = await free_problem(user_id, "handlers.casino")
    if blocked:
        raise HTTPException(status_code=422, detail=blocked)
    if not await is_exempt(user_id):
        position = await get_position(user_id)
        if position.get("location") != "casino" or position.get("in_transit"):
            raise HTTPException(status_code=422, detail="Tu dois être au casino pour jouer.")
    if not is_casino_open():
        raise HTTPException(status_code=423, detail=get_casino_status_text())
    if amount < CASINO_MIN_BET or amount > max_bet:
        raise HTTPException(status_code=422, detail=f"Mise autorisée : {CASINO_MIN_BET}–{max_bet}.")
    if require_funds:
        player = await database.get_user(user_id)
        if amount > player["balance"]:
            raise HTTPException(status_code=422, detail="Fonds insuffisants.")


async def _claim_and_resolve(session: dict, resolve_fn, status_of) -> tuple[dict, dict | None]:
    """Réserve une session active (CAS) puis règle le résultat et le gain dans LA MÊME
    transaction que la transition d'état (voir `save_claimed_session_with_payout`) : plus
    de fenêtre où la mise serait débitée sans que le gain soit crédité, ou l'inverse."""
    if session["status"] != "active" or not await claim_active_session(session):
        raise HTTPException(status_code=409, detail="Cette action est déjà en cours de traitement.")
    game = session["state"]
    result = resolve_fn(game)
    saved = await save_claimed_session_with_payout(session, game, status_of(result), result["gross_payout"])
    if saved is None:
        raise HTTPException(status_code=409, detail="Impossible d'enregistrer le résultat de la partie.")
    return result, saved


@router.post("/roulette/spin")
async def play_roulette(body: RouletteIn, user_id: int = Depends(require_character_complete)):
    valid_types = {"rouge", "noir", "pair", "impair", "1-18", "19-36", "1-12", "13-24", "25-36", "number"}
    if body.bet_type not in valid_types:
        raise HTTPException(status_code=422, detail="Type de pari invalide.")
    choice = body.bet_type
    if choice == "number":
        if body.number is None or not 0 <= body.number <= 36:
            raise HTTPException(status_code=422, detail="Choisis un numéro entre 0 et 36.")
        choice = f"number:{body.number}"

    # Reprise : une mise déjà prélevée mais pas encore réglée (redémarrage serveur entre les
    # deux) est reprise telle quelle plutôt que d'en débiter une seconde — on ne revérifie
    # alors pas le solde, déjà débité de cette mise au moment de la réservation.
    session = await find_resumable_session(user_id, "roulette")
    await _check_table_access(user_id, body.amount, require_funds=session is None)
    if session is None:
        game_id = uuid.uuid4().hex
        try:
            await create_session_with_stake(game_id, user_id, "roulette", {"amount": body.amount, "bet_type": choice}, body.amount)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        session = await get_session(game_id, user_id, "roulette")

    result, saved = await _claim_and_resolve(
        session,
        lambda game: resolve_roulette(game["amount"], game["bet_type"]),
        lambda result: "win" if result["gross_payout"] else "loss",
    )
    await track_casino(user_id, result["bet"], result["gross_payout"])
    loot = None
    if result["gross_payout"]:
        await add_xp(user_id, 25)
        user = await database.get_user(user_id)
        if random.random() < 0.15 + chance_boost_bonus(user):
            loot = await add_random_item(user_id, "common", "rare")
    result["loot"] = loot
    result["balance"] = saved["balance"] if saved["balance"] is not None else (await database.get_user(user_id))["balance"]
    return result


@router.post("/pmu/run")
async def play_pmu(body: PmuIn, user_id: int = Depends(require_character_complete)):
    if not 0 <= body.horse_index < len(PMU_HORSES):
        raise HTTPException(status_code=422, detail="Cheval invalide.")

    session = await find_resumable_session(user_id, "pmu")
    await _check_table_access(user_id, body.amount, require_funds=session is None)
    if session is None:
        game_id = uuid.uuid4().hex
        try:
            await create_session_with_stake(game_id, user_id, "pmu", {"amount": body.amount, "chosen_index": body.horse_index}, body.amount)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        session = await get_session(game_id, user_id, "pmu")

    result, saved = await _claim_and_resolve(
        session,
        lambda game: resolve_pmu(game["amount"], game["chosen_index"]),
        lambda result: "win" if result["won"] else "loss",
    )
    await track_casino(user_id, result["bet"], result["gross_payout"])
    loot = None
    if result["won"]:
        await add_xp(user_id, 40)
        user = await database.get_user(user_id)
        if random.random() < 0.2 + chance_boost_bonus(user):
            loot = await add_random_item(user_id, "common", "epic")
    result["loot"] = loot
    result["balance"] = saved["balance"] if saved["balance"] is not None else (await database.get_user(user_id))["balance"]
    return result


@router.post("/blackjack/start")
async def start_blackjack(body: BlackjackStartIn, user_id: int = Depends(require_character_complete)):
    await _check_table_access(user_id, body.amount)
    try:
        result = await blackjack_start(user_id, body.amount)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if result["status"] == "active":
        game_id = uuid.uuid4().hex
        game = {"status": "active", "bet": body.amount,
                "player_hand": result["player_hand"], "dealer_hand": result["dealer_hand"]}
        await create_session(game_id, user_id, "blackjack", game)
        result["game_id"] = game_id
        result["dealer_hand"] = result["dealer_hand"][:1]
    return result


@router.post("/blackjack/{game_id}/action")
async def action_blackjack(game_id: str, body: BlackjackActionIn, user_id: int = Depends(require_character_complete)):
    session = await get_session(game_id, user_id, "blackjack")
    if not session:
        raise HTTPException(status_code=404, detail="Partie Blackjack introuvable.")
    if session["status"] != "active" or not await claim_active_session(session):
        raise HTTPException(status_code=409, detail="Cette action a déjà été traitée ou la partie n’est plus active.")
    game = session["state"]
    try:
        result = await blackjack_action(user_id, game, body.action)
    except ValueError as exc:
        await save_claimed_session(session, game, "active")
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if not await save_claimed_session(session, game, result["status"]):
        raise HTTPException(status_code=409, detail="Impossible d’enregistrer le nouvel état de la partie.")
    if result["status"] == "active":
        result["dealer_hand"] = result["dealer_hand"][:1]
    return result


@router.post("/mines/start")
async def start_mines(body: MinesStartIn, user_id: int = Depends(require_character_complete)):
    blocked = await free_problem(user_id, "handlers.casino")
    if blocked:
        raise HTTPException(status_code=422, detail=blocked)
    if not await is_exempt(user_id):
        position = await get_position(user_id)
        if position.get("location") != "casino" or position.get("in_transit"):
            raise HTTPException(status_code=422, detail="Tu dois être au casino pour jouer.")
    cooldown_message, _reserved = await cooldown_problem(user_id, "casino_last", 10, "⏳ Attends 10 secondes avant de rejouer.")
    if cooldown_message:
        raise HTTPException(status_code=429, detail=cooldown_message)
    if not is_casino_open():
        raise HTTPException(status_code=423, detail=get_casino_status_text())
    if body.amount < CASINO_MIN_BET or body.amount > MINES_MAX_BET:
        raise HTTPException(status_code=422, detail=f"Mise Mines autorisée : {CASINO_MIN_BET}–{MINES_MAX_BET}.")
    game_id = uuid.uuid4().hex
    game = {"amount": body.amount, "mines": mines_layout(), "revealed": set(),
            "multiplier": 1.0, "status": "active"}
    try:
        # Mise débitée et session créée dans UNE SEULE transaction : plus de fenêtre où la
        # mise serait prélevée sans que la partie n'existe (voir `create_session_with_stake`).
        await create_session_with_stake(game_id, user_id, "mines", game, body.amount)
    except ValueError as exc:
        await release_cooldown(user_id, "casino_last")
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"game_id": game_id, "status": "active", "bet": body.amount, "multiplier": 1.0,
            "revealed": [], "grid_size": 25, "mine_count": 5}


@router.post("/mines/{game_id}/action")
async def action_mines(game_id: str, body: MinesActionIn, user_id: int = Depends(require_character_complete)):
    session = await get_session(game_id, user_id, "mines")
    if not session:
        raise HTTPException(status_code=404, detail="Partie Mines introuvable.")
    if session["status"] != "active" or not await claim_active_session(session):
        raise HTTPException(status_code=409, detail="Cette action a déjà été traitée ou la partie n’est plus active.")
    game = session["state"]
    try:
        if body.action == "click":
            if body.index is None:
                raise ValueError("Case invalide.")
            result = mines_reveal(game, body.index)
            if result["status"] == "loss":
                result.update(await mines_lost(user_id, game))
                result["mines"] = sorted(game["mines"])
                if not await save_claimed_session(session, game, "loss"):
                    raise HTTPException(status_code=409, detail="Impossible d’enregistrer le résultat Mines.")
            else:
                result["revealed"] = sorted(game["revealed"])
                result["potential_payout"] = int(game["amount"] * game["multiplier"])
                if not await save_claimed_session(session, game, "active"):
                    raise HTTPException(status_code=409, detail="Impossible d’enregistrer le nouvel état Mines.")
        elif body.action == "cashout":
            result = await mines_cashout(user_id, game)
            result["mines"] = sorted(game["mines"])
            if not await save_claimed_session(session, game, "win"):
                raise HTTPException(status_code=409, detail="Impossible d’enregistrer le résultat Mines.")
        else:
            raise ValueError("Action Mines invalide.")
    except ValueError as exc:
        await save_claimed_session(session, game, "active")
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return result


@router.post("/crash/start")
async def start_crash(body: CrashStartIn, user_id: int = Depends(require_character_complete)):
    await _check_table_access(user_id, body.amount)
    game_id = uuid.uuid4().hex
    game = {"amount": body.amount, "crash_point": crash_point_from_roll(random.random()),
            "current_mult": 1.0, "started_at": time.time(), "running": True, "status": "active"}
    try:
        # Mise débitée et session créée dans UNE SEULE transaction (voir `create_session_with_stake`).
        await create_session_with_stake(game_id, user_id, "crash", game, body.amount)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"game_id": game_id, "status": "active", "bet": body.amount, "multiplier": 1.0,
            "potential_payout": body.amount}


@router.get("/crash/{game_id}")
async def status_crash(game_id: str, user_id: int = Depends(require_character_complete)):
    session = await get_session(game_id, user_id, "crash")
    if not session:
        raise HTTPException(status_code=404, detail="Partie Crash introuvable.")
    if session["status"] == "processing":
        raise HTTPException(status_code=409, detail="Une action Crash est en cours de règlement.")
    game = session["state"]
    if session["status"] == "active":
        current = crash_multiplier_at(game["started_at"])
        if current >= game["crash_point"]:
            if await claim_active_session(session):
                game.update(current_mult=current, running=False, status="crashed")
                if not await save_claimed_session(session, game, "crashed"):
                    raise HTTPException(status_code=409, detail="Impossible d’enregistrer le Crash.")
                session["status"] = "crashed"
            else:
                session = await get_session(game_id, user_id, "crash")
                if session["status"] == "processing":
                    raise HTTPException(status_code=409, detail="Une action Crash est en cours de règlement.")
                game = session["state"]
                current = crash_multiplier_at(game["started_at"]) if session["status"] == "active" else game["current_mult"]
        else:
            game["current_mult"] = current
    else:
        current = game["current_mult"]
    return {"status": session["status"], "multiplier": current,
            "potential_payout": int(game["amount"] * current)}


@router.post("/crash/{game_id}/cashout")
async def cashout_crash(game_id: str, user_id: int = Depends(require_character_complete)):
    session = await get_session(game_id, user_id, "crash")
    if not session:
        raise HTTPException(status_code=404, detail="Partie Crash introuvable.")
    game = session["state"]
    if session["status"] != "active":
        raise HTTPException(status_code=409, detail="Le jeu a déjà crashé ou été encaissé.")
    current = crash_multiplier_at(game["started_at"])
    if current >= game["crash_point"]:
        if await claim_active_session(session):
            game.update(current_mult=current, running=False, status="crashed")
            if await save_claimed_session(session, game, "crashed"):
                session["status"] = "crashed"
        raise HTTPException(status_code=409, detail="Le jeu a déjà crashé !")
    if not await claim_active_session(session):
        raise HTTPException(status_code=409, detail="Cette action a déjà été traitée.")
    game["current_mult"] = current
    game["running"] = True
    try:
        result = await settle_crash_cashout(user_id, game)
    except ValueError as exc:
        await save_claimed_session(session, game, "active")
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    if not await save_claimed_session(session, game, "cashed_out"):
        raise HTTPException(status_code=409, detail="Impossible d’enregistrer l’encaissement.")
    return result
