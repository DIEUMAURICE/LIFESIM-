"""webapp/routers/boutique_router.py — Boutique (handlers/boutique.py), via utils/shop.py
(déjà pur, sans dépendance Telegram — rien n'est réécrit pour la partie catalogue).

⚠️ Point d'architecture à trancher avec toi, pas une simple question de code :
La boutique vend des articles en <b>Étoiles Telegram (XTR)</b> — une monnaie qui n'existe QUE
dans l'écosystème Telegram (`bot.create_invoice_link` + `Telegram.WebApp.openInvoice` côté
mini app). Il n'existe dans tout le projet AUCUNE intégration de paiement pour le site web
(pas de Stripe, PayPal, etc.) : un joueur connecté avec Google n'a donc aujourd'hui aucun moyen
de payer. Ce routeur gère : (1) tout le catalogue en lecture (identique sur les 2 interfaces),
(2) l'achat via Étoiles pour les sessions Telegram uniquement — explicitement bloqué pour les
sessions Google avec un message clair, plutôt que de laisser un bouton « Acheter » ne rien
faire. Il faudra décider ensemble quoi faire pour les joueurs web : pas de boutique du tout,
ou un vrai prestataire de paiement (carte bancaire) à intégrer — c'est un choix produit/juridique,
pas un détail technique, donc je ne l'ai pas inventé à ta place.
"""
from __future__ import annotations

import time

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from config import STARS_RETIRED_ITEMS, STARS_SHOP
from database import get_user
from handlers.boutique import _can_receive
from utils import shop
from utils import vip as vip_utils
from utils.bot_registry import get_bot
from utils.gamerules import switch_on
from webapp.deps import get_session_source, require_character_complete

router = APIRouter(prefix="/api/boutique", tags=["boutique"])


async def _context(uid: int) -> dict:
    items = await shop.items()
    return {"items": items, "deal": shop.deal_key(items), "welcome": await shop.delivered_count(uid) == 0}


def _item_out(item: dict, ctx: dict) -> dict:
    m = shop.meta(item)
    price, pct, why = shop.price(item, welcome=ctx["welcome"], deal=ctx["deal"])
    badges = []
    if item["ends_at"]:
        left = item["ends_at"] - int(time.time())
        badges.append(f"⏳ {max(1, left // 3600)} h" if left < 172800 else f"⏳ {left // 86400} j")
    if item["stock"] >= 0:
        badges.append(f"🔥 {max(0, item['stock'] - item['sold'])} restant(s)")
    return {
        "key": item["item_key"], "label": m["label"], "desc": m.get("desc", ""), "tag": m.get("tag", ""),
        "category": item["category"], "price": price, "discount_pct": pct, "discount_reason": why,
        "original_price": item["stars"], "badges": badges,
    }


@router.get("/home")
async def home(user_id: int = Depends(require_character_complete)):
    await shop.seed()
    u = await get_user(user_id)
    ctx = await _context(user_id)
    byk = {i["item_key"]: i for i in ctx["items"]}

    perks = []
    tier = vip_utils.get_tier(u)
    if tier != "none":
        field = "premium_until" if tier == "premium" else "vip_until"
        until = u.get(field, 0)
        perks.append({"label": vip_utils.status_label(u), "until": until, "expiring_soon": 0 < until - int(time.time()) < 172800})
    boosts = []
    for key, it in STARS_SHOP.items():
        if key in STARS_RETIRED_ITEMS or it.get("type") != "boost":
            continue
        field = it["field"]
        if vip_utils.has_boost(u, field):
            boosts.append({"label": it["label"].split(" (")[0], "hours_left": max(1, (u.get(field, 0) - int(time.time())) // 3600)})

    welcome = byk.get(shop.WELCOME_ITEM) if ctx["welcome"] else None
    deal = byk.get(ctx["deal"]) if ctx["deal"] else None
    featured = [i for i in ctx["items"] if (i["featured"] or i["ends_at"]) and i["item_key"] not in (ctx["deal"], shop.WELCOME_ITEM)][:3]

    counts: dict = {}
    for it in ctx["items"]:
        counts[it["category"]] = counts.get(it["category"], 0) + 1
    categories = [{"key": c, "emoji": e, "name": n, "count": counts.get(c, 0)} for c, (e, n) in shop.CATEGORIES.items() if counts.get(c)]

    loyalty = await shop.loyalty(user_id)
    collection = await shop.cosmetics_of(user_id)

    return {
        "payments_enabled": await switch_on("real_payments"),
        "perks": perks,
        "boosts": boosts,
        "welcome_item": _item_out(welcome, ctx) if welcome else None,
        "deal_item": _item_out(deal, ctx) if deal else None,
        "featured": [_item_out(i, ctx) for i in featured],
        "categories": categories,
        "loyalty_spent": loyalty["spent"],
        "collection_count": len(collection),
    }


@router.get("/category/{cat}")
async def category(cat: str, page: int = 0, user_id: int = Depends(require_character_complete)):
    if cat not in shop.CATEGORIES:
        raise HTTPException(status_code=404, detail="Catégorie inconnue.")
    ctx = await _context(user_id)
    its = [i for i in ctx["items"] if i["category"] == cat]
    per_page = 6
    pages = max(1, -(-len(its) // per_page))
    page = max(0, min(page, pages - 1))
    chunk = its[page * per_page:(page + 1) * per_page]
    emoji, name = shop.CATEGORIES[cat]
    return {"category": cat, "emoji": emoji, "name": name, "page": page, "total_pages": pages,
            "items": [_item_out(i, ctx) for i in chunk]}


@router.get("/item/{key}")
async def item_detail(key: str, user_id: int = Depends(require_character_complete)):
    item = await shop.get_item(key)
    if not item or not shop.visible(item, await switch_on("shop_money"))[0]:
        raise HTTPException(status_code=404, detail="ℹ️ Cet article n'est plus disponible.")
    ctx = await _context(user_id)
    return _item_out(item, ctx)


@router.get("/history")
async def history(user_id: int = Depends(require_character_complete)):
    return {"orders": await shop.history(user_id)}


@router.get("/loyalty")
async def loyalty(user_id: int = Depends(require_character_complete)):
    return await shop.loyalty(user_id)


@router.get("/collection")
async def collection(user_id: int = Depends(require_character_complete)):
    return {"cosmetics": await shop.cosmetics_of(user_id)}


class BuyIn(BaseModel):
    key: str
    target_id: int | None = None   # pour offrir à un autre joueur ; par défaut, pour soi


@router.post("/buy")
async def buy(body: BuyIn, user_id: int = Depends(require_character_complete),
              src: str = Depends(get_session_source)):
    if src != "telegram":
        raise HTTPException(
            status_code=409,
            detail="💳 Les achats en Étoiles ne sont disponibles que dans la mini app Telegram "
                   "pour l'instant — il n'y a pas encore de moyen de paiement pour les comptes Google.",
        )
    if not await switch_on("real_payments"):
        raise HTTPException(status_code=422, detail="💳 Les paiements sont momentanément suspendus par la direction. Réessaie plus tard.")

    target = body.target_id or user_id
    item = await shop.get_item(body.key)
    if not item or not shop.visible(item, await switch_on("shop_money"))[0]:
        raise HTTPException(status_code=404, detail="ℹ️ Cet article n'est plus disponible.")

    ok, why = await _can_receive(item["kind"], body.key, target)
    if not ok:
        raise HTTPException(status_code=422, detail=f"⛔ {why}")

    ctx = await _context(user_id)
    stars, _pct, _why = shop.price(item, welcome=ctx["welcome"] and target == user_id, deal=ctx["deal"])
    m = shop.meta(item)

    bot = get_bot()
    if not bot:
        raise HTTPException(status_code=503, detail="Service de paiement indisponible pour l'instant.")

    payload = f"v2:{user_id}:{body.key}:{target}:{stars}"
    try:
        from telegram import LabeledPrice
        link = await bot.create_invoice_link(
            title=m["label"][:32],
            description=(m.get("desc") or m["label"])[:250] or "Article de la boutique",
            payload=payload,
            provider_token="",
            currency="XTR",
            prices=[LabeledPrice(m["label"][:32], stars)],
        )
    except Exception as exc:  # pragma: no cover — remonté tel quel au front pour diagnostic
        raise HTTPException(status_code=502, detail=f"Impossible de créer la facture : {exc}")

    # Le paiement lui-même (pre_checkout_query / successful_payment) est traité par le BOT
    # (handlers/boutique.py:precheckout / successful_payment) — même si la facture a été ouverte
    # depuis la mini app via Telegram.WebApp.openInvoice(link), c'est Telegram qui gère l'écran
    # de paiement et renvoie l'événement au bot normalement. Rien à dupliquer ici.
    return {"invoice_link": link, "stars": stars, "label": m["label"]}
