"""webapp/routers/reseau_router.py — Réseau RP (fil, explorer, likes, abonnements, publication).

Mêmes tables, mêmes récompenses et MÊMES RÈGLES que le bot (handlers/reseau.py) : la publication appelle
le moteur unique `handlers.social.run_post`, avec les mêmes garde-fous (utils.decorators.free_problem,
cooldown_problem sur la même clé `post_cooldown`) — le délai est donc partagé entre le bot et l'application.
"""
from __future__ import annotations

import logging
import time

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
import database
from database import db_connection, now
from utils import gamerules as gr
from config import SOCIAL_PLATFORMS
from utils.cooldowns import cooldown_left, release_cooldown
from utils.decorators import cooldown_problem, free_problem
from utils.reseau_rules import FOLLOW_BONUS_FOLLOWERS, POST_COOLDOWN_HOURS, POST_COOLDOWN_KEY, POST_COOLDOWN_SECONDS, POST_MAX, XP_POST
from gameplay.social_comments import CommentError, create_comment, list_comments
from gameplay.social_collabs import SocialCollabError, collaborations_for_user, create_request as create_collab_request, respond_to_request
from gameplay.social_polls import PollError, close_poll, create_poll, polls_for_user, vote_poll
from webapp.deps import require_character_complete

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/reseau", tags=["reseau"])

FEED_WINDOW = 3 * 86400


def _ts() -> int:
    return int(time.time())


async def _muted(uid: int) -> bool:
    async with db_connection() as db:
        async with db.execute("SELECT until FROM rp_mutes WHERE user_id=?", (uid,)) as cur:
            row = await cur.fetchone()
    return bool(row and int(row[0]) > _ts())


async def _writing_gate(uid: int) -> None:
    if not await gr.switch_on("rp_network"):
        raise HTTPException(status_code=403, detail="Le réseau est momentanément fermé par le staff.")
    if await _muted(uid):
        raise HTTPException(status_code=403, detail="Tu es en sourdine sur le réseau.")


@router.get("/home")
async def home(uid: int = Depends(require_character_complete)):
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM rp_follows WHERE followee_id=?", (uid,)) as c:
            followers = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM rp_follows WHERE follower_id=?", (uid,)) as c:
            following = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*), COALESCE(SUM(likes),0) FROM rp_posts "
                              "WHERE author_id=? AND deleted=0 AND kind='post'", (uid,)) as c:
            posts, likes = await c.fetchone()
    return {"enabled": await gr.switch_on("rp_network"), "followers": followers, "following": following,
            "posts": posts, "likes": likes}


@router.get("/feed")
async def feed(mode: str = Query("fol", pattern="^(fol|exp)$"), offset: int = Query(0, ge=0),
               limit: int = Query(10, ge=1, le=30), uid: int = Depends(require_character_complete)):
    if not await gr.switch_on("rp_network"):
        return {"enabled": False, "posts": [], "total": 0}
    since = _ts() - FEED_WINDOW
    if mode == "exp":
        where, params, order = "p.deleted=0 AND p.kind='post' AND p.created_at>?", [since], "p.likes DESC, p.created_at DESC"
    else:
        where = ("p.deleted=0 AND p.kind='post' AND p.created_at>? AND (p.author_id=? OR p.author_id IN "
                 "(SELECT followee_id FROM rp_follows WHERE follower_id=?))")
        params, order = [since, uid, uid], "p.created_at DESC"
    async with db_connection() as db:
        async with db.execute(f"SELECT COUNT(*) FROM rp_posts p WHERE {where}", params) as c:
            total = (await c.fetchone())[0]
        async with db.execute(
            f"""SELECT p.id, p.author_id, p.platform, p.text, p.created_at, p.likes, p.comments,
                       COALESCE(NULLIF(u.full_name, ''), u.username, '') AS author,
                       EXISTS(SELECT 1 FROM rp_likes l WHERE l.post_id=p.id AND l.user_id=?) AS liked,
                       EXISTS(SELECT 1 FROM rp_follows f WHERE f.follower_id=? AND f.followee_id=p.author_id) AS following
                FROM rp_posts p LEFT JOIN users u ON u.user_id=p.author_id
                WHERE {where} ORDER BY {order} LIMIT ? OFFSET ?""",
            [uid, uid] + params + [limit, offset],
        ) as c:
            rows = await c.fetchall()
    posts = [{
        "id": r["id"], "author_id": r["author_id"], "author": r["author"] or f"Joueur {r['author_id']}",
        "platform": r["platform"], "text": r["text"], "created_at": r["created_at"],
        "likes": r["likes"], "comments": r["comments"], "liked": bool(r["liked"]),
        "following": bool(r["following"]), "mine": r["author_id"] == uid,
    } for r in rows]
    return {"enabled": True, "posts": posts, "total": total}


class LikeIn(BaseModel):
    post_id: int


@router.post("/like")
async def like(body: LikeIn, uid: int = Depends(require_character_complete)):
    await _writing_gate(uid)
    async with db_connection() as db:
        async with db.execute("SELECT author_id, platform FROM rp_posts WHERE id=? AND deleted=0", (body.post_id,)) as c:
            post = await c.fetchone()
        if not post:
            raise HTTPException(status_code=404, detail="Publication introuvable.")
        if post["author_id"] == uid:
            raise HTTPException(status_code=400, detail="Tu ne peux pas liker ton propre post.")
        res = await db.execute("INSERT OR IGNORE INTO rp_likes (post_id, user_id, created_at) VALUES (?,?,?)",
                               (body.post_id, uid, _ts()))
        added = res.rowcount > 0
        if added:
            await db.execute("UPDATE rp_posts SET likes=likes+1 WHERE id=?", (body.post_id,))
        else:
            await db.execute("DELETE FROM rp_likes WHERE post_id=? AND user_id=?", (body.post_id, uid))
            await db.execute("UPDATE rp_posts SET likes=MAX(0,likes-1) WHERE id=?", (body.post_id,))
        await db.commit()
        async with db.execute("SELECT likes FROM rp_posts WHERE id=?", (body.post_id,)) as c:
            likes = (await c.fetchone())[0]
    if added:  # mêmes récompenses que sur le bot : 1 social coin + 1 abonné sur la plateforme du post
        try:
            from handlers.social import add_social_followers_atomic, give_social_coins
            await give_social_coins(post["author_id"], 1)
            if post["platform"]:
                await add_social_followers_atomic(post["author_id"], post["platform"], 1)
        except Exception:
            logger.exception("Récompenses du like non attribuées")
    return {"liked": added, "likes": likes}


class FollowIn(BaseModel):
    user_id: int


@router.post("/follow")
async def follow(body: FollowIn, uid: int = Depends(require_character_complete)):
    await _writing_gate(uid)
    target = body.user_id
    if target == uid:
        raise HTTPException(status_code=400, detail="Tu ne peux pas te suivre toi-même.")
    t = await database.get_user(target)
    if not t.get("registered"):
        raise HTTPException(status_code=404, detail="Joueur introuvable.")
    async with db_connection() as db:
        res = await db.execute("INSERT OR IGNORE INTO rp_follows (follower_id, followee_id, since) VALUES (?,?,?)",
                               (uid, target, _ts()))
        added = res.rowcount > 0
        if not added:
            await db.execute("DELETE FROM rp_follows WHERE follower_id=? AND followee_id=?", (uid, target))
        await db.commit()
        async with db.execute("SELECT platform FROM rp_posts WHERE author_id=? AND deleted=0 AND kind='post' "
                              "ORDER BY created_at DESC LIMIT 1", (target,)) as c:
            row = await c.fetchone()
    platform = row[0] if row else ""
    try:
        if added and platform:
            from handlers.social import add_social_followers_atomic
            await add_social_followers_atomic(target, platform, FOLLOW_BONUS_FOLLOWERS)
        elif not added and platform:
            async with db_connection() as db:
                await db.execute("UPDATE social_media SET followers=MAX(0,followers-?) WHERE user_id=? AND platform=?",
                                 (FOLLOW_BONUS_FOLLOWERS, target, platform))
                await db.execute("UPDATE users SET social_followers=MAX(0,COALESCE(social_followers,0)-?) WHERE user_id=?",
                                 (FOLLOW_BONUS_FOLLOWERS, target))
                await db.commit()
    except Exception:
        logger.exception("Synchro audience (abonnement) non appliquée")
    return {"following": added}


@router.get("/compose")
async def compose(uid: int = Depends(require_character_complete)):
    left = await cooldown_left(uid, POST_COOLDOWN_KEY, POST_COOLDOWN_SECONDS)
    return {"platforms": list(SOCIAL_PLATFORMS), "max": POST_MAX, "xp": XP_POST, "hours": POST_COOLDOWN_HOURS,
            "ready": left == 0, "game_seconds_left": left}


class PostIn(BaseModel):
    platform: str
    text: str


def _plain(html_text: str) -> str:
    """Les refus du bot sont en HTML Telegram : on retire les balises pour l'affichage web."""
    import re
    return re.sub(r"<[^>]+>", "", html_text)


@router.post("/post")
async def post(body: PostIn, uid: int = Depends(require_character_complete)):
    from handlers.social import run_post   # import tardif : même moteur que le bot
    from handlers.reseau import publish_post  # noqa: F401  (utilisé par run_post)
    await _writing_gate(uid)
    if body.platform not in SOCIAL_PLATFORMS:
        raise HTTPException(status_code=422, detail="Plateforme inconnue.")
    text = " ".join(str(body.text).split())[:POST_MAX]   # même normalisation que le flux du bot
    if len(text) < 1:
        raise HTTPException(status_code=422, detail="Écris quelque chose avant de publier.")
    problem = await free_problem(uid, "handlers.social")
    if problem:
        raise HTTPException(status_code=409, detail=_plain(problem))
    message, claimed = await cooldown_problem(uid, POST_COOLDOWN_KEY, POST_COOLDOWN_SECONDS)
    if message:
        raise HTTPException(status_code=429, detail=_plain(message))
    try:
        r = await run_post(uid, body.platform, text)
    except Exception:
        if claimed:
            await release_cooldown(uid, POST_COOLDOWN_KEY)
        logger.exception("Publication échouée")
        raise HTTPException(status_code=500, detail="Publication impossible pour le moment.")
    return {"ok": True, "platform": body.platform, "xp": XP_POST, **r}


# ───────────────────────── Stories & lives : mêmes helpers/règles que le bot ─────────────────────────
from config import (
    SOCIAL_STORY_DURATION, SOCIAL_MIN_FOLLOWERS_FOR_LIVE,
    SOCIAL_LIVE_COST_PER_HOUR, SOCIAL_LIVE_COST_COINS,
    SOCIAL_LIVE_CHAT_COOLDOWN, SOCIAL_LIVE_CHAT_MAX_LEN, SOCIAL_COIN_NAME,
)
from handlers.social import (
    compute_follower_gain_simple, get_active_collab_bonus, get_community_bonus,
    get_platform_engagement_multiplier, get_total_followers, add_social_history,
    add_social_followers_atomic, add_xp, give_social_coins, get_social_coins,
    spend_social_coins, check_live_launch_requirements, register_live,
    get_live_info, is_follower, set_engagement_boost, get_active_vehicle,
)
from utils.cooldowns import claim_cooldown


@router.get("/creator")
async def creator(uid: int = Depends(require_character_complete)):
    """État du créateur partagé par les deux interfaces."""
    async with db_connection() as db:
        async with db.execute(
            "SELECT id, platform, text, created_at, expires_at FROM rp_posts "
            "WHERE author_id=? AND kind='story' AND deleted=0 AND expires_at>? ORDER BY created_at DESC",
            (uid, _ts()),
        ) as cur:
            stories = [dict(r) for r in await cur.fetchall()]
        async with db.execute(
            "SELECT l.live_id,l.user_id,l.platform,l.started_at,l.ends_at,"
            "COALESCE(NULLIF(u.full_name,''),u.username,?) AS author "
            "FROM social_lives l LEFT JOIN users u ON u.user_id=l.user_id "
            "WHERE l.active=1 AND l.ends_at>? ORDER BY l.ends_at ASC",
            (f"Joueur {uid}", _ts()),
        ) as cur:
            lives = [dict(r) for r in await cur.fetchall()]
    return {"stories": stories, "lives": lives, "followers": await get_total_followers(uid), "social_coins": await get_social_coins(uid)}


@router.post("/story")
async def story(body: PostIn, uid: int = Depends(require_character_complete)):
    await _writing_gate(uid)
    if body.platform not in SOCIAL_PLATFORMS: raise HTTPException(422, "Plateforme inconnue.")
    text = " ".join(str(body.text).split())[:POST_MAX]
    if not text: raise HTTPException(422, "Écris quelque chose avant de publier.")
    message, claimed = await cooldown_problem(uid, "story_cooldown", 1800)
    if message: raise HTTPException(429, detail=_plain(message))
    try:
        gain = await compute_follower_gain_simple(uid, body.platform, factor=0.4)
        collab_mult, _ = await get_active_collab_bonus(uid)
        community_mult, _, _ = await get_community_bonus(uid)
        engagement_mult = await get_platform_engagement_multiplier(uid, body.platform)
        gain = max(1, int(gain * collab_mult * community_mult * engagement_mult))
        vehicle = await get_active_vehicle(uid)
        if vehicle and vehicle.get("luxury", 0) > 80: gain = int(gain * (1 + (vehicle["luxury"] - 80) / 100))
        coins = max(1, gain // 400)
        async with db_connection() as db:
            await db.execute("INSERT INTO rp_posts (author_id,platform,text,created_at,kind,expires_at) VALUES (?,?,?,?,?,?)", (uid, body.platform, text, _ts(), "story", _ts() + SOCIAL_STORY_DURATION))
            await db.commit()
        await add_social_history(uid, body.platform, "story", gain)
        await add_social_followers_atomic(uid, body.platform, gain)
        await add_xp(uid, 15); await give_social_coins(uid, coins); await set_engagement_boost(uid, body.platform, 1.15, 3600)
        return {"ok": True, "message": f"Story publiée : +{gain} abonnés, +{coins} {SOCIAL_COIN_NAME}, +15 XP.", "gain": gain, "coins": coins}
    except Exception:
        if claimed: await release_cooldown(uid, "story_cooldown")
        raise


class LiveIn(BaseModel):
    platform: str
    duration_h: int = Field(ge=1, le=4)


@router.post("/live")
async def live(body: LiveIn, uid: int = Depends(require_character_complete)):
    await _writing_gate(uid)
    if body.platform not in SOCIAL_PLATFORMS: raise HTTPException(422, "Plateforme inconnue.")
    ok, err = await check_live_launch_requirements(uid)
    if not ok: raise HTTPException(409, detail=_plain(err))
    total_followers = await get_total_followers(uid)
    cost = SOCIAL_LIVE_COST_PER_HOUR * body.duration_h
    u = await database.get_user(uid)
    if (u.get("balance") or 0) < cost: raise HTTPException(400, "Solde insuffisant pour ce live.")
    await database.update_balance(uid, -cost, sink="live")
    await spend_social_coins(uid, SOCIAL_LIVE_COST_COINS)
    collab_mult, _ = await get_active_collab_bonus(uid); community_mult, _, _ = await get_community_bonus(uid)
    from utils.vip import social_bonus
    vip_mult = 1 + social_bonus(u)
    import random
    gain = int((total_followers * .01 * body.duration_h + random.randint(10, 500)) * collab_mult * community_mult * vip_mult)
    vehicle = await get_active_vehicle(uid)
    if vehicle and vehicle.get("luxury", 0) > 80: gain = int(gain * (1 + (vehicle["luxury"] - 80) / 100))
    coins = max(2, gain // 300)
    await add_social_history(uid, body.platform, "live", gain); await add_social_followers_atomic(uid, body.platform, gain); await give_social_coins(uid, coins)
    live_id = await register_live(uid, body.platform, body.duration_h)
    return {"ok": True, "live_id": live_id, "message": f"Live démarré : +{gain} abonnés et +{coins} {SOCIAL_COIN_NAME}.", "gain": gain, "ends_in": body.duration_h * 3600}


class LiveMessageIn(BaseModel):
    live_id: int
    text: str = Field(min_length=1, max_length=SOCIAL_LIVE_CHAT_MAX_LEN)


@router.post("/live/chat")
async def live_chat(body: LiveMessageIn, uid: int = Depends(require_character_complete)):
    live = await get_live_info(body.live_id)
    if not live or live["ends_at"] <= now(): raise HTTPException(404, "Live terminé.")
    if live["user_id"] != uid: raise HTTPException(403, "Seul l’émetteur peut écrire à sa communauté.")
    allowed, remaining = await claim_cooldown(uid, f"live_chat:{body.live_id}", SOCIAL_LIVE_CHAT_COOLDOWN)
    if not allowed: raise HTTPException(429, f"Attends encore {remaining} secondes.")
    async with db_connection() as db:
        async with db.execute("SELECT follower_id FROM rp_follows WHERE followee_id=?", (uid,)) as cur: followers = [r[0] for r in await cur.fetchall()]
    from database import add_notification
    for follower in followers: await add_notification(follower, f"🔴 Message du live : {body.text}")
    return {"ok": True, "message": f"Message envoyé à {len(followers)} membre(s)."}


class LiveTipIn(BaseModel):
    live_id: int
    amount: int = Field(gt=0, le=10_000_000)


@router.post("/live/tip")
async def live_tip(body: LiveTipIn, uid: int = Depends(require_character_complete)):
    live = await get_live_info(body.live_id)
    if not live or live["ends_at"] <= now(): raise HTTPException(404, "Live terminé.")
    if live["user_id"] == uid: raise HTTPException(400, "Tu ne peux pas te donner à toi-même.")
    if not await is_follower(uid, live["user_id"]): raise HTTPException(403, "Suis ce joueur pour soutenir son live.")
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT balance FROM users WHERE user_id=?", (uid,)) as cur: row = await cur.fetchone()
        if not row or row[0] < body.amount: await db.rollback(); raise HTTPException(400, "Solde insuffisant.")
        await db.execute("UPDATE users SET balance=balance-?,total_spent=total_spent+? WHERE user_id=?", (body.amount, body.amount, uid))
        await db.execute("UPDATE users SET balance=balance+?,total_earned=total_earned+? WHERE user_id=?", (body.amount, body.amount, live["user_id"]))
        await db.commit()
    bonus = max(1, body.amount // 1500); coins = max(1, body.amount // 5000)
    await add_social_followers_atomic(live["user_id"], "live_tip", bonus); await give_social_coins(live["user_id"], coins)
    from database import add_notification
    await add_notification(live["user_id"], f"💸 Tu as reçu un don de {body.amount:,} €A en live (+{bonus} abonnés).")
    return {"ok": True, "message": "Don envoyé !", "bonus_followers": bonus}


class PollCreateIn(BaseModel):
    question: str
    options: list[str]


class PollVoteIn(BaseModel):
    poll_id: int
    option_index: int


class PollIdIn(BaseModel):
    poll_id: int


def _poll_error(exc: PollError) -> HTTPException:
    status = 404 if exc.code == "not_found" else 403 if exc.code in ("forbidden", "community_only") else 422 if exc.code.startswith("invalid_") else 409
    return HTTPException(status_code=status, detail=str(exc))


async def _poll_staff(uid: int) -> bool:
    from handlers.reseau import _is_staff
    return await _is_staff(uid)


@router.get("/polls")
async def polls(uid: int = Depends(require_character_complete)):
    if not await gr.switch_on("rp_network"):
        return {"enabled": False, "polls": [], "community": None}
    return await polls_for_user(uid, staff=await _poll_staff(uid))


@router.post("/polls")
async def poll_create(body: PollCreateIn, uid: int = Depends(require_character_complete)):
    await _writing_gate(uid)
    try:
        result = await create_poll(uid, body.question, body.options)
    except PollError as exc:
        raise _poll_error(exc)
    scope = f" pour {result['community_name']}" if result["community_name"] else " pour tous les joueurs"
    return {"ok": True, "message": f"Sondage lancé{scope}.", **result}


@router.post("/polls/vote")
async def poll_vote(body: PollVoteIn, uid: int = Depends(require_character_complete)):
    await _writing_gate(uid)
    try:
        result = await vote_poll(body.poll_id, uid, body.option_index)
    except PollError as exc:
        raise _poll_error(exc)
    return {"message": "Vote enregistré (+1 SocialCoin).", **result}


@router.post("/polls/close")
async def poll_close(body: PollIdIn, uid: int = Depends(require_character_complete)):
    await _writing_gate(uid)
    try:
        result = await close_poll(body.poll_id, uid, staff=await _poll_staff(uid))
    except PollError as exc:
        raise _poll_error(exc)
    return {"message": "Sondage clôturé.", **result}


class CommentIn(BaseModel):
    text: str


@router.get("/posts/{post_id}/comments")
async def comments_read(post_id: int, uid: int = Depends(require_character_complete)):
    try:
        return await list_comments(post_id)
    except CommentError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.post("/posts/{post_id}/comments")
async def comments_create(post_id: int, body: CommentIn, uid: int = Depends(require_character_complete)):
    await _writing_gate(uid)
    try:
        return await create_comment(uid, post_id, body.text)
    except CommentError as exc:
        status = 404 if exc.code == "not_found" else 422 if exc.code == "empty" else 409
        raise HTTPException(status_code=status, detail=str(exc))


class CollabCreateIn(BaseModel):
    target: str = Field(min_length=1, max_length=128)
    collab_type: str = Field(min_length=1, max_length=24)


class CollabRespondIn(BaseModel):
    request_id: int
    action: str


def _collab_error(exc: SocialCollabError) -> HTTPException:
    if exc.code == "forbidden":
        status = 403
    elif exc.code in ("not_found", "target_missing", "requester_missing"):
        status = 404
    elif exc.code in ("invalid_type", "invalid_action", "invalid_duration", "self_target"):
        status = 422
    else:
        status = 409
    return HTTPException(status_code=status, detail=str(exc))


@router.get("/collabs")
async def collabs(uid: int = Depends(require_character_complete)):
    return await collaborations_for_user(uid)


@router.post("/collabs")
async def collab_create(body: CollabCreateIn, uid: int = Depends(require_character_complete)):
    try:
        result = await create_collab_request(uid, body.target, body.collab_type)
    except SocialCollabError as exc:
        raise _collab_error(exc)
    return {"message": f"Demande envoyée à {result['target_name']}. Les {result['cost']:,} €A seront débités si elle est acceptée.", **result}


@router.post("/collabs/respond")
async def collab_respond(body: CollabRespondIn, uid: int = Depends(require_character_complete)):
    try:
        result = await respond_to_request(body.request_id, uid, body.action)
    except SocialCollabError as exc:
        raise _collab_error(exc)
    message = "Collaboration acceptée : +100 abonnés chacun." if body.action == "accept" else "Collaboration refusée."
    return {"message": message, **result}
