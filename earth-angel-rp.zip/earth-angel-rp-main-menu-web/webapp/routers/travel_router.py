"""Voyages touristiques : port des règles de handlers/travel.py (distinct de /places)."""
from __future__ import annotations

import random

import aiosqlite
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
from config import DESTINATIONS
from handlers.missions import update_mission_progress
from handlers.vehicles import get_active_vehicle
from utils.gamerules import faucet
from utils.decorators import free_problem
from utils.vip import add_xp, travel_time_multiplier
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/travel", tags=["travel"])
TRAVEL_COOLDOWN = 7200


async def _event_effect() -> dict:
    try:
        from handlers.events import get_event_effect
        return await get_event_effect()
    except ImportError:
        return {}


async def _visited(user_id: int) -> set[str]:
    async with database.db_connection() as db:
        async with db.execute(
            "SELECT DISTINCT destination FROM travel_log WHERE user_id=?", (user_id,)
        ) as cur:
            return {row[0] for row in await cur.fetchall()}


@router.get("/catalog")
async def catalog(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    visited = await _visited(user_id)
    effect = await _event_effect()
    return {
        "balance": u["balance"],
        "travel_count": u.get("travel_count", 0),
        "travel_until": u.get("travel_until", 0),
        "server_now": database.now(),
        "speed_multiplier": travel_time_multiplier(u),
        "destinations": [
            {"name": name, **data,
             "actual_cost": int(data["cost"] * effect.get("travel_cost_mult", 1.0)),
             "actual_happiness": int(data["happiness"] * effect.get("travel_happiness_mult", 1.0)),
             "visited": name in visited,
             "affordable": u["balance"] >= int(data["cost"] * effect.get("travel_cost_mult", 1.0))}
            for name, data in DESTINATIONS.items()
        ],
    }


@router.get("/status")
async def status(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    now = database.now()
    until = u.get("travel_until", 0)
    remaining = max(0, until - now)
    current_trip = None
    travel_remaining = None
    rest_remaining = None
    if until > now:
        # Phase persistée au départ (voir `go()` / `handlers/travel.py`) : `travel_log` porte
        # directement l'heure d'arrivée et la fin de repos de CE voyage, donc on retrouve le
        # trajet courant par égalité exacte sur `travel_until` plutôt qu'en devinant une plage
        # de durée plausible depuis le seul horodatage de départ.
        async with database.db_connection() as db:
            async with db.execute(
                "SELECT destination, arrival_at FROM travel_log WHERE user_id=? AND travel_until=? "
                "ORDER BY timestamp DESC, log_id DESC LIMIT 1", (user_id, until),
            ) as cur:
                latest = await cur.fetchone()
        if latest:
            current_trip = latest[0]
            travel_remaining = max(0, latest[1] - now)
            rest_remaining = max(0, min(TRAVEL_COOLDOWN, remaining))
    return {
        "balance": u["balance"], "travel_count": u.get("travel_count", 0),
        "travel_until": until, "server_now": now,
        "blocked": until > now, "remaining_seconds": remaining,
        "current_destination": current_trip,
        "travel_remaining_seconds": travel_remaining,
        "rest_remaining_seconds": rest_remaining,
        "speed_multiplier": travel_time_multiplier(u),
    }


@router.get("/log")
async def travel_log(user_id: int = Depends(require_character_complete)):
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT destination, COUNT(*) AS visits FROM travel_log WHERE user_id=? "
            "GROUP BY destination ORDER BY visits DESC", (user_id,)
        ) as cur:
            trips = [dict(row) for row in await cur.fetchall()]
    by_name = {row["destination"]: row["visits"] for row in trips}
    return {
        "trips": [
            {"name": name, "emoji": DESTINATIONS.get(name, {}).get("emoji", "🌍"),
             "visits": count}
            for name, count in by_name.items()
        ],
        "unvisited": [name for name in DESTINATIONS if name not in by_name],
        "total_trips": sum(by_name.values()),
        "globe_trotter": sum(by_name.values()) >= len(DESTINATIONS),
    }


class TravelIn(BaseModel):
    destination: str


@router.post("/go")
async def go(body: TravelIn, user_id: int = Depends(require_character_complete)):
    data = DESTINATIONS.get(body.destination)
    if data is None:
        raise HTTPException(status_code=404, detail="Destination inconnue.")

    blocked = await free_problem(user_id, "handlers.travel")
    if blocked:
        raise HTTPException(status_code=422, detail=blocked)

    u = await database.get_user(user_id)
    effect = await _event_effect()
    cost = int(data["cost"] * effect.get("travel_cost_mult", 1.0))
    happiness = int(data["happiness"] * effect.get("travel_happiness_mult", 1.0))
    vehicle = await get_active_vehicle(user_id)
    speed = vehicle.get("speed", 0) if vehicle else 0
    duration = random.randint(3600, 10800)
    reduction = max(0.3, min(1.0, 1 - speed / 200))
    duration = int(duration * reduction * travel_time_multiplier(u))
    xp = int(data["xp"] * (1 + speed / 200))
    now = database.now()
    arrival_at = now + duration
    blocked_until = arrival_at + TRAVEL_COOLDOWN

    # Réserver le voyage et débiter dans la même transaction : deux clics concurrents
    # ne peuvent ni lancer deux voyages ni provoquer un solde négatif.
    try:
        async with database.db_connection(row_factory=aiosqlite.Row) as db:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT balance, travel_until, travel_count FROM users WHERE user_id=?", (user_id,)
            ) as cur:
                current = await cur.fetchone()
            if not current:
                await db.rollback()
                raise HTTPException(status_code=404, detail="Joueur introuvable.")
            if current["travel_until"] > database.now():
                await db.rollback()
                raise HTTPException(status_code=423, detail="Tu es déjà en voyage / repos.")
            if current["balance"] < cost:
                await db.rollback()
                raise HTTPException(status_code=422, detail="Fonds insuffisants pour ce voyage.")

            count = current["travel_count"] + 1
            prestige = {5: 25, 10: 50, 25: 150, 50: 500}.get(count, 0)
            await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+?, travel_until=?, "
                "happiness=MIN(100,happiness+?), stress=MAX(0,stress-20), "
                "travel_count=travel_count+1, prestige=prestige+? WHERE user_id=?",
                (cost, cost, blocked_until, happiness, prestige, user_id),
            )
            from utils.treasury import collect
            await collect(db, cost, "transports")
            await database.snapshot_user_core_stats(user_id, db)
            await db.execute(
                "INSERT INTO travel_log (user_id, destination, cost, timestamp, arrival_at, travel_until) "
                "VALUES (?,?,?,?,?,?)",
                (user_id, body.destination, cost, now, arrival_at, blocked_until),
            )
            await db.commit()
    except HTTPException:
        raise
    except Exception:
        # Le gestionnaire de contexte ferme/annule toute transaction non validée.
        raise

    # XP et mission reprennent leurs fonctions partagées du bot après validation du départ.
    await add_xp(user_id, xp)
    await update_mission_progress(user_id, "travel", 1)

    # Événement aléatoire identique au bot (y compris probabilités et robinet staff).
    events = [
        ("✨ Tu rencontres une célébrité et obtiens un contact VIP !", 50_000, 10),
        ("🍽️ Restaurant exceptionnel — expérience inoubliable !", 0, 5),
        (f"🎲 Casino de {body.destination} : tu gagnes !", random.randint(10_000, 50_000), 5),
        ("😊 Voyage parfait, retour ressourcé !", 0, 10),
        ("📸 Tes photos deviennent virales !", 0, 15),
        ("💼 Tu rencontres un business partner potentiel !", 0, 20),
        ("🌧️ Mauvaise météo… voyage gâché.", -10_000, -10),
        ("🦠 Épidémie locale ! Tu tombes malade.", -20_000, -20),
    ]
    event, bonus, karma = random.choices(events, weights=[5, 20, 15, 40, 10, 10, 5, 2])[0]
    if bonus > 0:
        bonus = await faucet("travel", bonus)
    if bonus > 0:
        await database.update_balance(user_id, bonus)
    elif bonus < 0:
        # Le prix du billet a déjà été payé et la mission peut avoir crédité
        # une récompense : la perte ne peut dépasser le solde actuellement disponible.
        current_balance = (await database.get_user(user_id))["balance"]
        bonus = max(bonus, -current_balance)
        if bonus:
            await database.update_balance(user_id, bonus)
    if karma:
        await database.increment_field(user_id, "karma", karma)

    return {
        "destination": body.destination, "emoji": data["emoji"], "cost": cost,
        "travel_seconds": duration, "cooldown_seconds": TRAVEL_COOLDOWN,
        "travel_until": blocked_until, "happiness": happiness, "stress": -20,
        "xp": xp, "event": event, "money_event": bonus, "karma": karma,
        "prestige": prestige, "travel_count": count,
    }
