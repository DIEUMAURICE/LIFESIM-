"""API Marché joueur et inventaire : adaptateur HTTP du moteur partagé."""
from __future__ import annotations

import aiosqlite
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from database import db_connection, get_inventory, get_user
from gameplay.market import MarketError, buy_listing, cancel_listing, cargo_bonus, create_listing, use_item
from handlers.market import can_sell_on_market
from webapp.deps import require_character_complete
from utils.helpers import now

router = APIRouter(prefix="/api/market", tags=["market"])
PER_PAGE = 10


def _error(exc: MarketError) -> HTTPException:
    return HTTPException(status_code=422, detail=str(exc))


@router.get("/listings")
async def listings(page: int = 1, user_id: int = Depends(require_character_complete)):
    page = max(1, page)
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT ml.listing_id,ml.seller_id,ml.item_id,ml.quantity,ml.price,i.name,i.emoji,i.rarity,u.full_name seller_name "
            "FROM market_listings ml JOIN items i ON i.item_id=ml.item_id JOIN users u ON u.user_id=ml.seller_id "
            "WHERE ml.status='active' AND ml.expires_at>? ORDER BY ml.price ASC,ml.created_at ASC LIMIT ? OFFSET ?",
            (now(), PER_PAGE, (page - 1) * PER_PAGE),
        ) as cur:
            rows = await cur.fetchall()
        async with db.execute("SELECT COUNT(*) FROM market_listings WHERE status='active' AND expires_at>?", (now(),)) as cur:
            total = (await cur.fetchone())[0] or 0
    return {"page": page, "total_pages": max(1, (total + PER_PAGE - 1) // PER_PAGE), "listings": [
        {"listing_id": r["listing_id"], "item_id": r["item_id"], "name": r["name"], "emoji": r["emoji"],
         "rarity": r["rarity"], "quantity": r["quantity"], "price": r["price"], "seller_id": r["seller_id"],
         "seller_name": r["seller_name"], "mine": r["seller_id"] == user_id} for r in rows
    ]}


@router.get("/mine")
async def mine(user_id: int = Depends(require_character_complete)):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT ml.listing_id,ml.item_id,ml.quantity,ml.price,ml.expires_at,i.name,i.emoji,i.rarity "
            "FROM market_listings ml JOIN items i ON i.item_id=ml.item_id WHERE ml.seller_id=? AND ml.status='active' ORDER BY ml.created_at DESC",
            (user_id,),
        ) as cur:
            rows = await cur.fetchall()
    t = now()
    return {"listings": [{"listing_id": r["listing_id"], "item_id": r["item_id"], "name": r["name"], "emoji": r["emoji"],
                           "rarity": r["rarity"], "quantity": r["quantity"], "price": r["price"],
                           "seconds_left": max(0, r["expires_at"] - t)} for r in rows]}


@router.get("/inventory")
async def inventory(user_id: int = Depends(require_character_complete)):
    return {"items": await get_inventory(user_id)}


@router.get("/cargo-bonus")
async def cargo(user_id: int = Depends(require_character_complete)):
    return await cargo_bonus(user_id)


class SellIn(BaseModel):
    item_id: int
    price: int
    quantity: int = 1


@router.post("/sell")
async def sell(body: SellIn, user_id: int = Depends(require_character_complete)):
    if not await can_sell_on_market(user_id):
        raise HTTPException(status_code=403, detail="🛍️ Seuls les commerçants peuvent vendre sur le marché.")
    try:
        return await create_listing(user_id, body.item_id, body.price, body.quantity)
    except MarketError as exc:
        raise _error(exc)


class ListingIdIn(BaseModel):
    listing_id: int


@router.post("/cancel")
async def cancel(body: ListingIdIn, user_id: int = Depends(require_character_complete)):
    try:
        return await cancel_listing(user_id, body.listing_id)
    except MarketError as exc:
        raise _error(exc)


class BuyIn(BaseModel):
    listing_id: int
    quantity: int = 1


@router.post("/buy")
async def buy(body: BuyIn, user_id: int = Depends(require_character_complete)):
    try:
        return await buy_listing(user_id, body.listing_id, body.quantity)
    except MarketError as exc:
        raise _error(exc)


class UseIn(BaseModel):
    item_id: int
    quantity: int = 1


@router.post("/use")
async def use(body: UseIn, user_id: int = Depends(require_character_complete)):
    try:
        return await use_item(user_id, body.item_id, body.quantity)
    except MarketError as exc:
        raise _error(exc)
