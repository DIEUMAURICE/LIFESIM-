"""API commune des gangs, branchée sur les mêmes mutations que le bot."""
from __future__ import annotations
import aiosqlite
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from config import GANG_RECRUIT_ROLES
from database import db_connection
from gameplay.gangs import GangError, CREATE_COST, UPGRADE_COST, apply_to_gang, change_role, create_gang, deposit as gang_deposit, dissolve_gang, exclude_member, hold_up, leave_gang, membership, transfer_chief, upgrade as gang_upgrade, withdraw as gang_withdraw
from handlers.gangs import decide_application
from utils.decorators import free_problem
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/gangs", tags=["gangs"])

async def _free(uid: int):
    problem = await free_problem(uid, "handlers.gangs")
    if problem:
        import re
        raise HTTPException(409, re.sub(r"<[^>]+>", "", problem))

class NameIn(BaseModel):
    name: str = Field(min_length=2, max_length=40)
class GangIdIn(BaseModel):
    gang_id: int
class AppIn(BaseModel):
    app_id: int
class AmountIn(BaseModel):
    amount: int = Field(gt=0)
class TargetIn(BaseModel):
    user_id: int
class RoleIn(TargetIn):
    role: str = Field(min_length=2, max_length=30)

def _error(exc: GangError) -> HTTPException:
    return HTTPException(409, str(exc))

@router.get("/home")
async def home(uid: int = Depends(require_character_complete)):
    mine = await membership(uid)
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT g.gang_id,g.name,g.founder_id,g.treasury,g.reputation,COUNT(gm2.user_id) members FROM gangs g LEFT JOIN gang_members gm2 ON gm2.gang_id=g.gang_id GROUP BY g.gang_id ORDER BY g.reputation DESC,g.treasury DESC LIMIT 50") as cur:
            gangs = [dict(x) for x in await cur.fetchall()]
        applications = []
        if mine and mine["role"] in GANG_RECRUIT_ROLES:
            async with db.execute("SELECT a.app_id,a.user_id,u.full_name,u.username,a.created_at FROM gang_applications a JOIN users u ON u.user_id=a.user_id WHERE a.gang_id=? AND a.status='pending' ORDER BY a.app_id", (mine["gang_id"],)) as cur:
                applications = [dict(x) for x in await cur.fetchall()]
        members = []
        if mine:
            async with db.execute("SELECT gm.user_id,gm.role,u.full_name,u.username FROM gang_members gm JOIN users u ON u.user_id=gm.user_id WHERE gm.gang_id=? ORDER BY CASE gm.role WHEN 'Chef' THEN 0 WHEN 'Bras droit' THEN 1 WHEN 'Lieutenant' THEN 2 WHEN 'Soldat' THEN 3 ELSE 4 END, u.full_name", (mine["gang_id"],)) as cur:
                members = [dict(x) for x in await cur.fetchall()]
    return {"mine": mine, "gangs": gangs, "members": members, "applications": applications, "costs": {"create": CREATE_COST, "upgrade": UPGRADE_COST}}

@router.post("/create")
async def create(body: NameIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await create_gang(uid, body.name)
    except GangError as exc: raise _error(exc)
    return {"ok": True, "message": "Gang créé !", **result}

@router.post("/apply")
async def apply(body: GangIdIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await apply_to_gang(uid, body.gang_id)
    except GangError as exc: raise _error(exc)
    message = f"Tu rejoins {result['name']} comme Recrue." if result["status"] == "joined" else "Candidature envoyée."
    return {"ok": True, "message": message, **result}

@router.post("/applications/decide")
async def decide(body: AppIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    ok, msg = await decide_application(body.app_id, uid, True)
    if not ok: raise HTTPException(403 if "Réservé" in msg else 409, msg)
    return {"ok": True, "message": msg}

@router.post("/leave")
async def leave(uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await leave_gang(uid)
    except GangError as exc: raise _error(exc)
    return {"ok": True, "message": "Gang dissous." if result["dissolved"] else "Tu as quitté le gang.", **result}

@router.post("/treasury/deposit")
async def deposit(body: AmountIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await gang_deposit(uid, body.amount)
    except GangError as exc: raise _error(exc)
    return {"ok": True, "message": "Dépôt effectué.", **result}

@router.post("/treasury/withdraw")
async def withdraw(body: AmountIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await gang_withdraw(uid, body.amount)
    except GangError as exc: raise _error(exc)
    return {"ok": True, "message": "Retrait effectué.", **result}

@router.post("/upgrade")
async def upgrade(uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await gang_upgrade(uid)
    except GangError as exc: raise _error(exc)
    return {"ok": True, "message": "Gang amélioré : réputation +10.", **result}

@router.post("/role")
async def role(body: RoleIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await change_role(uid, body.user_id, body.role)
    except GangError as exc: raise _error(exc)
    return {"ok": True, "message": "Rôle modifié.", **result}

@router.post("/exclude")
async def exclude(body: TargetIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await exclude_member(uid, body.user_id)
    except GangError as exc: raise _error(exc)
    return {"ok": True, "message": "Membre exclu.", **result}

@router.post("/transfer")
async def transfer(body: TargetIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await transfer_chief(uid, body.user_id)
    except GangError as exc: raise _error(exc)
    return {"ok": True, "message": "Chef transféré.", **result}

@router.post("/dissolve")
async def dissolve(uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await dissolve_gang(uid)
    except GangError as exc: raise _error(exc)
    return {"ok": True, "message": "Gang dissous.", **result}

@router.post("/hold-up")
async def gang_hold_up(uid: int = Depends(require_character_complete)):
    await _free(uid)
    try: result = await hold_up(uid)
    except GangError as exc: raise _error(exc)
    message = "Hold-up réussi." if result["success"] else "Hold-up échoué."
    return {"ok": True, "message": message, **result}
