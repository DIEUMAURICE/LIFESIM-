"""webapp/routers/realestate_router.py — Immobilier (MVP) : acheter/vendre un bien, voir ses
biens. Réutilise la même logique que handlers/realestate.py (prix, multiplicateurs de ville,
plafond de biens, frais d'agence à la revente). Hypothèque, location à d'autres joueurs,
entretien, logement... restent sur le bot pour l'instant (prochaine itération).
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
from config import PROPERTIES
from handlers.realestate import get_city_multipliers, get_max_properties
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/realestate", tags=["realestate"])


@router.get("/catalog")
async def catalog(user_id: int = Depends(require_character_complete)):
    mult = await get_city_multipliers(user_id)
    rmult = mult.get("realestate_mult", 1.0)
    items = [
        {
            "type": name,
            "emoji": data["emoji"],
            "price": int(data["price"] * rmult),
            "rent": int(data["rent"] * rmult),
            "maintenance": int(data["maint"] * rmult),
        }
        for name, data in PROPERTIES.items()
    ]
    owned = await database.get_properties(user_id)
    max_props = await get_max_properties(user_id)
    return {"items": items, "owned_count": len(owned), "max_properties": max_props}


@router.get("/mine")
async def mine(user_id: int = Depends(require_character_complete)):
    props = await database.get_properties(user_id)
    for p in props:
        data = PROPERTIES.get(p["prop_type"], {})
        p["emoji"] = data.get("emoji", "🏠")
    return {"properties": props}


class BuyIn(BaseModel):
    prop_type: str


@router.post("/buy")
async def buy(body: BuyIn, user_id: int = Depends(require_character_complete)):
    if body.prop_type not in PROPERTIES:
        raise HTTPException(status_code=404, detail="Type de bien inconnu.")
    data = PROPERTIES[body.prop_type]
    mult = await get_city_multipliers(user_id)
    rmult = mult.get("realestate_mult", 1.0)
    price = int(data["price"] * rmult)

    props = await database.get_properties(user_id)
    max_props = await get_max_properties(user_id)
    if len(props) >= max_props:
        raise HTTPException(status_code=422, detail=f"Maximum de {max_props} biens atteint.")

    u = await database.get_user(user_id)
    if u["balance"] < price:
        raise HTTPException(status_code=422, detail=f"Fonds insuffisants. Prix : {price}")

    name = f"{body.prop_type} de {u.get('full_name') or user_id}"[:50]
    async with database.db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            debit = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
                (price, price, user_id, price),
            )
            if debit.rowcount != 1:
                await db.rollback()
                raise HTTPException(status_code=422, detail="Fonds insuffisants.")
            await db.execute(
                "INSERT INTO properties (user_id,prop_type,name,purchased_at,condition,last_maintenance) "
                "VALUES (?,?,?,?,100,?)",
                (user_id, body.prop_type, name, database.now(), database.now()),
            )
            await db.commit()
        except HTTPException:
            raise
        except Exception:
            await db.rollback()
            raise

    rent_m, maint_m = int(data["rent"] * rmult), int(data["maint"] * rmult)
    return {"bought": body.prop_type, "price": price, "rent": rent_m, "maintenance": maint_m}


class SellIn(BaseModel):
    prop_id: int


@router.post("/sell")
async def sell(body: SellIn, user_id: int = Depends(require_character_complete)):
    mult = await get_city_multipliers(user_id)
    mult_val = mult.get("realestate_mult", 1.0)

    props = await database.get_properties(user_id)
    prop = next((p for p in props if p["prop_id"] == body.prop_id), None)
    if not prop:
        raise HTTPException(status_code=404, detail="Bien introuvable.")
    if prop.get("rented_to"):
        raise HTTPException(status_code=422, detail="Impossible de vendre un bien actuellement loué.")

    data = PROPERTIES.get(prop["prop_type"], {})
    condition = prop.get("condition", 100)
    base_price = data.get("price", 0) * mult_val
    sell_price = int(base_price * 0.85 * condition / 100)
    mortgage = int(prop.get("mortgage") or 0)
    if mortgage > 0:
        if sell_price < mortgage:
            raise HTTPException(status_code=422, detail="La vente ne couvrirait pas l'hypothèque.")
        sell_price -= mortgage

    async with database.db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            deletion = await db.execute(
                "DELETE FROM properties WHERE prop_id=? AND user_id=? AND COALESCE(rented_to,0)=0",
                (prop["prop_id"], user_id),
            )
            if deletion.rowcount != 1:
                await db.rollback()
                raise HTTPException(status_code=409, detail="Bien indisponible ou déjà vendu.")
            await db.execute(
                "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                (sell_price, sell_price, user_id),
            )
            await db.commit()
        except HTTPException:
            raise
        except Exception:
            await db.rollback()
            raise

    return {"sold": prop["prop_type"], "price": sell_price, "condition": condition}
