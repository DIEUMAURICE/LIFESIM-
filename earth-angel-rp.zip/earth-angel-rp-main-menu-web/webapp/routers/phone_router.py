"""webapp/routers/phone_router.py — « Téléphone » (handlers/phone.py).

Le téléphone du bot est surtout un lanceur de raccourcis (banque, garage, réseaux,
classements, marché, immobilier...) : dans la webapp, c'est déjà le rôle de la barre de
navigation du bas — pas besoin de le reproduire, ce serait redondant. Ce qui est vraiment
nouveau et branché ici :
  • l'horloge/météo du jeu (même heure, même saison, même météo pour tout le monde) ;
  • le statut personnel (visible 24h, comme un statut WhatsApp) ;
  • les paramètres cosmétiques du téléphone (thème, sonnerie).

Volontairement PAS encore fait (dette technique assumée, comme pour la boutique) :
  • la messagerie privée entre joueurs (start_msg_flow/cmd_phone_msg) — un vrai message privé
    doit être livré même à un joueur hors ligne, donc ça demande le même genre de décision
    que la boutique (notifications poussées ? stockage + polling ?) ; je ne l'ai pas inventé.
  • les événements de calendrier (start_event_flow/cmd_phone_event) — fonctionnalité annexe,
    à faire après le cœur de la boucle de jeu.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from database import db_connection, get_user
from handlers.phone import STATUS_TTL, get_game_datetime, get_status
from utils.helpers import now
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/phone", tags=["phone"])


@router.get("/home")
async def home(user_id: int = Depends(require_character_complete)):
    u = await get_user(user_id)
    dt = get_game_datetime()
    status = await get_status(user_id)

    async with db_connection() as db:
        async with db.execute(
            "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND sent = 0", (user_id,)
        ) as cur:
            notif_count = (await cur.fetchone())[0] or 0
        async with db.execute(
            "SELECT phone_theme, phone_ringtone FROM users WHERE user_id = ?", (user_id,)
        ) as cur:
            row = await cur.fetchone()

    return {
        "datetime": {
            "hour": dt["hour"], "minute": dt["minute"], "day": dt["day"], "month": dt["month"],
            "year": dt["year"], "season": dt["season"], "weather": dt["weather"],
        },
        "status": status,
        "status_ttl_seconds": STATUS_TTL,
        "notifications_pending": notif_count,
        "theme": (row[0] if row else None) or "dark",
        "ringtone": (row[1] if row else None) or "classic",
    }


class StatusIn(BaseModel):
    text: str


@router.post("/status")
async def post_status(body: StatusIn, user_id: int = Depends(require_character_complete)):
    text = body.text.strip()
    if not text:
        raise HTTPException(status_code=422, detail="❌ Statut vide.")
    if len(text) > 200:
        raise HTTPException(status_code=422, detail="❌ Statut trop long (max 200 caractères).")

    async with db_connection() as db:
        await db.execute(
            "INSERT INTO phone_status (user_id, text, created_at) VALUES (?, ?, ?)",
            (user_id, text, now()),
        )
        await db.commit()
    return {"text": text, "message": "✅ Statut publié ! Visible 24 h sur ton profil et le fil."}


@router.delete("/status")
async def clear_status(user_id: int = Depends(require_character_complete)):
    async with db_connection() as db:
        await db.execute("DELETE FROM phone_status WHERE user_id = ?", (user_id,))
        await db.commit()
    return {"message": "🗑️ Statut effacé."}


class SettingsIn(BaseModel):
    theme: str | None = None       # "dark" | "light"
    ringtone: str | None = None    # "classic" | "modern"


@router.post("/settings")
async def settings(body: SettingsIn, user_id: int = Depends(require_character_complete)):
    if body.theme and body.theme not in ("dark", "light"):
        raise HTTPException(status_code=422, detail="❌ Thème invalide.")
    if body.ringtone and body.ringtone not in ("classic", "modern"):
        raise HTTPException(status_code=422, detail="❌ Sonnerie invalide.")

    async with db_connection() as db:
        if body.theme:
            await db.execute("UPDATE users SET phone_theme = ? WHERE user_id = ?", (body.theme, user_id))
        if body.ringtone:
            await db.execute("UPDATE users SET phone_ringtone = ? WHERE user_id = ?", (body.ringtone, user_id))
        await db.commit()
    return {"theme": body.theme, "ringtone": body.ringtone}
