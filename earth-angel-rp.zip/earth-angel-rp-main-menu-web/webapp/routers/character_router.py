"""webapp/routers/character_router.py — Création / consultation du personnage.

Réutilise directement `utils/character.py`, déjà écrit en pur Python (pas de dépendance à
Telegram) précisément pour être partagé avec une future mini app / app web — voir le
commentaire d'en-tête de ce fichier dans le projet d'origine.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from utils import character as character_mod
from webapp.deps import get_active_user_id

router = APIRouter(prefix="/api/character", tags=["character"])


@router.get("/options")
async def get_options():
    """Les choix possibles pour chaque champ (identiques à ceux affichés dans le bot),
    pour construire le formulaire de création côté mini app / web."""
    return {
        "steps": character_mod.STEPS,
        "labels": character_mod.FIELD_LABEL,
        "fields": {
            field: {code: {"emoji": e, "label": label} for code, (e, label) in character_mod.options(field).items()}
            for field in character_mod.FIELDS.keys()
        },
        "name_max": character_mod.NAME_MAX,
    }


@router.get("")
async def get_character(user_id: int = Depends(get_active_user_id)):
    ch = await character_mod.ensure(user_id)
    return {
        "character": ch,
        "complete": bool(ch and ch.get("complete")),
        "next_missing": character_mod.next_missing(ch) if ch else character_mod.STEPS[0],
        "avatar": character_mod.avatar(ch.get("gender", "")) if ch else "",
    }


class FieldIn(BaseModel):
    field: str
    value: str


@router.post("/field")
async def set_field(body: FieldIn, user_id: int = Depends(get_active_user_id)):
    if body.field not in character_mod.FIELD_LABEL:
        raise HTTPException(status_code=400, detail="Champ inconnu.")
    ok = await character_mod.set_field(user_id, body.field, body.value)
    if not ok:
        raise HTTPException(status_code=422, detail="Valeur refusée pour ce champ.")
    ch = await character_mod.get(user_id)
    return {
        "character": ch,
        "complete": bool(ch and ch.get("complete")),
        "next_missing": character_mod.next_missing(ch),
    }


@router.post("/finish")
async def finish_character(user_id: int = Depends(get_active_user_id)):
    ok = await character_mod.finish(user_id)
    if not ok:
        ch = await character_mod.get(user_id)
        missing = character_mod.next_missing(ch) if ch else character_mod.STEPS[0]
        raise HTTPException(status_code=422, detail=f"Personnage incomplet : champ manquant '{missing}'.")
    return {"complete": True}
