"""API commune Famille & mariage.

Les deux clients appellent ici les mêmes tables et les mêmes règles que handlers/family.py.
L'identité vient exclusivement du JWT via require_character_complete.
"""
from __future__ import annotations

import aiosqlite
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

import database
from database import db_connection, get_marriage, now, update_balance
from utils.decorators import free_problem
from webapp.deps import require_character_complete
from gameplay.family import (
    FamilyError, adoptions_for_user, adopt_child, dissolve_family,
    transfer_family_founder,
)

router = APIRouter(prefix="/api/family", tags=["family"])
MARRY_COST = 50_000
DIVORCE_COST = 25_000
FAMILY_COST = 30_000


def _public_user(row: dict | None) -> dict | None:
    if not row:
        return None
    return {
        "user_id": row.get("user_id"),
        "name": row.get("full_name") or row.get("username") or f"Joueur {row.get('user_id')}",
        "age": row.get("age", 0),
    }


async def _free(uid: int) -> None:
    problem = await free_problem(uid, "handlers.family")
    if problem:
        import re
        raise HTTPException(status_code=409, detail=re.sub(r"<[^>]+>", "", problem))


async def _family_for(uid: int):
    async with db_connection() as db:
        db.row_factory = database.aiosqlite.Row if hasattr(database, "aiosqlite") else None
        async with db.execute(
            "SELECT f.family_id, f.name, f.founder_id, fm.role "
            "FROM family_members fm JOIN family f ON f.family_id=fm.family_id WHERE fm.user_id=?",
            (uid,),
        ) as cur:
            fam = await cur.fetchone()
        if not fam:
            return None, []
        async with db.execute(
            "SELECT u.user_id, u.full_name, u.username, fm.role, fm.joined_at "
            "FROM family_members fm JOIN users u ON u.user_id=fm.user_id "
            "WHERE fm.family_id=? ORDER BY fm.joined_at",
            (fam[0],),
        ) as cur:
            members = await cur.fetchall()
    return dict(fam), [dict(m) for m in members]


@router.get("/home")
async def home(uid: int = Depends(require_character_complete)):
    marriage = await get_marriage(uid)
    partner = _public_user(await database.get_user(marriage["partner_id"])) if marriage else None
    family, members = await _family_for(uid)
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT mr.from_id, mr.created_at, u.full_name, u.username "
            "FROM marriage_requests mr JOIN users u ON u.user_id=mr.from_id "
            "WHERE mr.to_id=? ORDER BY mr.created_at DESC LIMIT 1", (uid,)
        ) as cur:
            req = await cur.fetchone()
        async with db.execute(
            "SELECT fi.family_id, fi.invited_by, f.name, u.full_name, u.username "
            "FROM family_invites fi JOIN family f ON f.family_id=fi.family_id "
            "JOIN users u ON u.user_id=fi.invited_by WHERE fi.invited_id=? "
            "ORDER BY fi.created_at DESC", (uid,)
        ) as cur:
            invites = await cur.fetchall()
    adoptions = await adoptions_for_user(uid)
    return {
        "marriage": {"partner": partner, "married_at": marriage.get("married_at")} if marriage else None,
        "marriage_request": (dict(req) if req else None),
        "family": ({"family_id": family["family_id"], "name": family["name"], "founder_id": family["founder_id"],
                    "role": family["role"], "members": members} if family else None),
        "family_invites": [dict(i) for i in invites],
        "adoptions": adoptions,
        "costs": {"marriage": MARRY_COST, "divorce": DIVORCE_COST, "family": FAMILY_COST},
    }


class TargetIn(BaseModel):
    target_id: int


@router.post("/adopt")
async def adopt(body: TargetIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    try:
        result = await adopt_child(uid, body.target_id)
    except FamilyError as exc:
        status = 404 if exc.code in ("parent_missing", "child_missing") else 400 if exc.code in ("parent_too_young", "child_too_old", "self_adoption") else 409
        raise HTTPException(status_code=status, detail=str(exc))
    return {
        "ok": True,
        "message": f"Adoption réussie : {result['child_name']} rejoint ta famille.",
        **result,
    }


@router.post("/transfer")
async def family_transfer(body: TargetIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    try:
        result = await transfer_family_founder(uid, body.target_id)
    except FamilyError as exc:
        status = 403 if exc.code == "not_founder" else 404 if exc.code == "target_not_member" else 400
        raise HTTPException(status_code=status, detail=str(exc))
    return {"ok": True, "message": f"{result['family_name']} : le leadership a été transféré.", **result}


@router.post("/dissolve")
async def family_dissolve(uid: int = Depends(require_character_complete)):
    await _free(uid)
    try:
        result = await dissolve_family(uid)
    except FamilyError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    return {"ok": True, "message": f"Le clan {result['family_name']} a été dissous.", **result}


@router.post("/marriage/request")
async def marriage_request(body: TargetIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    if body.target_id == uid:
        raise HTTPException(400, "Tu ne peux pas te marier à toi-même.")
    me = await database.get_user(uid)
    target = await database.get_user(body.target_id)
    if not target.get("registered"):
        raise HTTPException(404, "Joueur introuvable.")
    if (me.get("age") or 0) < 18 or (target.get("age") or 0) < 18:
        raise HTTPException(400, "Les deux joueurs doivent avoir au moins 18 ans.")
    if await get_marriage(uid) or await get_marriage(body.target_id):
        raise HTTPException(409, "Un des deux joueurs est déjà marié.")
    if (me.get("balance") or 0) < MARRY_COST:
        raise HTTPException(400, f"Le mariage coûte {MARRY_COST:,} €A.")
    async with db_connection() as db:
        await db.execute("DELETE FROM marriage_requests WHERE to_id=?", (body.target_id,))
        await db.execute("INSERT INTO marriage_requests (from_id,to_id,created_at) VALUES (?,?,?)", (uid, body.target_id, now()))
        await db.commit()
    return {"ok": True, "message": "Demande en mariage envoyée."}


@router.post("/marriage/accept")
async def marriage_accept(uid: int = Depends(require_character_complete)):
    await _free(uid)
    me = await database.get_user(uid)
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM marriage_requests WHERE to_id=? ORDER BY created_at DESC LIMIT 1", (uid,)) as cur:
            req = await cur.fetchone()
    if not req:
        raise HTTPException(404, "Aucune demande en mariage en attente.")
    other = await database.get_user(req["from_id"])
    if (me.get("balance") or 0) < MARRY_COST or (other.get("balance") or 0) < MARRY_COST:
        raise HTTPException(400, f"Chaque joueur doit payer {MARRY_COST:,} €A.")
    await update_balance(uid, -MARRY_COST, sink="etat_civil")
    await update_balance(req["from_id"], -MARRY_COST, sink="etat_civil")
    t = now()
    async with db_connection() as db:
        await db.execute("INSERT OR REPLACE INTO marriages (user_id,partner_id,married_at,status) VALUES (?,?,?, 'active')", (uid, req["from_id"], t))
        await db.execute("INSERT OR REPLACE INTO marriages (user_id,partner_id,married_at,status) VALUES (?,?,?, 'active')", (req["from_id"], uid, t))
        await db.execute("DELETE FROM marriage_requests WHERE to_id=?", (uid,))
        await db.commit()
    return {"ok": True, "message": "Mariage célébré !"}


@router.post("/marriage/divorce")
async def divorce(uid: int = Depends(require_character_complete)):
    await _free(uid)
    if not await get_marriage(uid):
        raise HTTPException(400, "Tu n'es pas marié(e).")
    me = await database.get_user(uid)
    if (me.get("balance") or 0) < DIVORCE_COST:
        raise HTTPException(400, f"Le divorce coûte {DIVORCE_COST:,} €A.")
    await update_balance(uid, -DIVORCE_COST, sink="etat_civil")
    async with db_connection() as db:
        await db.execute("UPDATE marriages SET status='divorced', divorced_at=? WHERE user_id=? OR partner_id=?", (now(), uid, uid))
        await db.commit()
    return {"ok": True, "message": "Divorce prononcé."}


class NameIn(BaseModel):
    name: str = Field(min_length=2, max_length=40)


@router.post("/create")
async def create_family(body: NameIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    name = " ".join(body.name.split())
    me = await database.get_user(uid)
    if (me.get("balance") or 0) < FAMILY_COST:
        raise HTTPException(400, f"Créer un clan coûte {FAMILY_COST:,} €A.")
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM family_members WHERE user_id=?", (uid,)) as cur:
            if await cur.fetchone(): raise HTTPException(409, "Tu es déjà membre d'un clan.")
        async with db.execute("SELECT 1 FROM family WHERE LOWER(name)=LOWER(?)", (name,)) as cur:
            if await cur.fetchone(): raise HTTPException(409, "Ce nom de clan est déjà pris.")
        await db.execute("INSERT INTO family (name,founder_id,created_at) VALUES (?,?,?)", (name, uid, now()))
        fam_id = (await (await db.execute("SELECT last_insert_rowid()" )).fetchone())[0]
        await db.execute("INSERT INTO family_members (family_id,user_id,role,joined_at) VALUES (?,?, 'Fondateur',?)", (fam_id, uid, now()))
        await db.commit()
    await update_balance(uid, -FAMILY_COST, sink="etat_civil")
    return {"ok": True, "message": "Clan fondé !", "family_id": fam_id}


@router.post("/invite")
async def invite(body: TargetIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    target = await database.get_user(body.target_id)
    if body.target_id == uid or not target.get("registered"):
        raise HTTPException(400, "Joueur cible invalide.")
    family, _ = await _family_for(uid)
    if not family: raise HTTPException(400, "Tu n'es dans aucun clan.")
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM family_members WHERE user_id=?", (body.target_id,)) as cur:
            if await cur.fetchone(): raise HTTPException(409, "Ce joueur est déjà dans un clan.")
        await db.execute("INSERT OR REPLACE INTO family_invites (family_id,invited_id,invited_by,created_at) VALUES (?,?,?,?)", (family["family_id"], body.target_id, uid, now()))
        await db.commit()
    return {"ok": True, "message": "Invitation envoyée."}


class JoinIn(BaseModel):
    family_id: int


@router.post("/join")
async def join(body: JoinIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM family_members WHERE user_id=?", (uid,)) as cur:
            if await cur.fetchone(): raise HTTPException(409, "Tu es déjà dans un clan.")
        async with db.execute("SELECT 1 FROM family_invites WHERE family_id=? AND invited_id=?", (body.family_id, uid)) as cur:
            if not await cur.fetchone(): raise HTTPException(403, "Aucune invitation pour ce clan.")
        await db.execute("INSERT INTO family_members (family_id,user_id,role,joined_at) VALUES (?,?, 'Membre',?)", (body.family_id, uid, now()))
        await db.execute("DELETE FROM family_invites WHERE family_id=? AND invited_id=?", (body.family_id, uid))
        await db.commit()
    return {"ok": True, "message": "Tu as rejoint le clan."}


@router.post("/leave")
async def leave(uid: int = Depends(require_character_complete)):
    await _free(uid)
    family, members = await _family_for(uid)
    if not family: raise HTTPException(400, "Tu n'es dans aucun clan.")
    if family["role"] == "Fondateur" and len(members) > 1:
        raise HTTPException(409, "Transfère le clan ou attends qu'il soit vide avant de partir.")
    async with db_connection() as db:
        await db.execute("DELETE FROM family_members WHERE user_id=? AND family_id=?", (uid, family["family_id"]))
        if len(members) == 1:
            await db.execute("DELETE FROM family WHERE family_id=?", (family["family_id"],))
            await db.execute("DELETE FROM family_invites WHERE family_id=?", (family["family_id"],))
        await db.commit()
    return {"ok": True, "message": "Tu as quitté le clan."}
