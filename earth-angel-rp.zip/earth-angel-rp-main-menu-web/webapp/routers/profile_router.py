"""webapp/routers/profile_router.py — Écran « hub » : identité + stats vitales du joueur."""
from __future__ import annotations

from fastapi import APIRouter, Depends

import database
from utils import character as character_mod
from webapp.deps import get_active_user_id

router = APIRouter(prefix="/api/profile", tags=["profile"])

_PUBLIC_FIELDS = (
    "user_id", "username", "full_name", "balance", "xp", "level", "karma", "prestige",
    "health", "energy", "happiness", "hunger", "stress", "age", "diplome", "job",
    "job_level", "lifestyle_score", "social_followers", "influence_score", "created_at",
)


@router.get("")
async def get_profile(user_id: int = Depends(get_active_user_id)):
    user = await database.get_user(user_id)
    ch = await character_mod.get(user_id)
    accounts = await database.get_all_bank_accounts(user_id)
    bank_total = sum(a["balance"] for a in accounts)

    return {
        "user": {k: user.get(k) for k in _PUBLIC_FIELDS},
        "net_worth": (user.get("balance") or 0) + bank_total,
        "character": ch,
        "character_complete": bool(ch and ch.get("complete")),
        "avatar": character_mod.avatar(ch.get("gender", ""), ch.get("skin", ""), ch.get("hair", "")) if ch else "",
    }
