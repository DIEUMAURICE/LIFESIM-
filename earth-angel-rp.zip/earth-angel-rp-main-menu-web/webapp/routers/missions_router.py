"""webapp/routers/missions_router.py — Missions quotidiennes/hebdomadaires (handlers/missions.py).

Les récompenses sont versées AUTOMATIQUEMENT dès qu'une mission est complétée (côté bot comme
côté web) : `update_mission_progress()`, appelée par tous les autres modules (travail, crime,
banque...), crédite le solde/XP dès que la cible est atteinte. Il n'y a donc pas de bouton
« réclamer » — seulement un écran qui liste les missions en cours et un résumé de ce qui a déjà
été payé, comme `do_claim_rewards()` côté bot.

Toute la logique (création des missions du jour/de la semaine, filtre cargo pour les livraisons,
barème des récompenses) vient de `handlers/missions.py` : rien n'est réécrit ici.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

import database
from gameplay.missions import reward_summary
from handlers.missions import get_missions_with_cargo_filter
from utils.helpers import now
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/missions", tags=["missions"])


def _mission_out(m: dict) -> dict:
    return {
        "name": m["mission_name"],
        "type": m["mission_type"],
        "period": m["period"],
        "progress": m["progress"],
        "target": m["target"],
        "reward": m["reward"],
        "xp_reward": m["xp_reward"],
        "completed": bool(m["completed"]),
        "cargo_required": m.get("cargo_required"),
    }


@router.get("")
async def list_missions(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    if u.get("hospital_until", 0) > now():
        raise HTTPException(
            status_code=422,
            detail="🏥 Tu es hospitalisé(e) ! Repose-toi avant de consulter tes missions.",
        )

    data = await get_missions_with_cargo_filter(user_id)
    available = [_mission_out(m) for m in data["available"]]
    blocked = [_mission_out(m) for m in data["blocked"]]

    return {
        "daily": [m for m in available if m["period"] == "daily"],
        "weekly": [m for m in available if m["period"] == "weekly"],
        "blocked": blocked,   # livraisons qui demandent plus de cargo que le véhicule actif
        "vehicle_cargo": data["vehicle_cargo"],
        "has_vehicle": data["has_vehicle"],
    }


@router.get("/summary")
async def rewards_summary(user_id: int = Depends(require_character_complete)):
    """Ce qui a déjà été versé pour les missions accomplies (équivalent web de do_claim_rewards)."""
    u = await database.get_user(user_id)
    summary = await reward_summary(user_id)
    # Les boosts sont conservés comme information d’affichage, mais les montants
    # viennent du journal : ils ne sont jamais recalculés avec le profil actuel.
    from utils.vip import coins_boost_multiplier, xp_boost_multiplier
    summary.update({
        "coins_boost": coins_boost_multiplier(u),
        "xp_boost": xp_boost_multiplier(u),
    })
    return summary
