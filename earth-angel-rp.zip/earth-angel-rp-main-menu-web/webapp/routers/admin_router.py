"""webapp/routers/admin_router.py — Panneau admin web : gérer comptes/données des joueurs
SANS toucher au code (contrairement aux commandes staff du bot, qui nécessitent de connaître
les commandes). Accès réservé au staff : réutilise exactement la même hiérarchie de rôles que
le bot Telegram (config.ROLE_HIERARCHY, utils.decorators.get_user_role_async) — un membre du
staff nommé via le bot a directement accès ici, rien à reconfigurer séparément.
"""
from __future__ import annotations

import aiosqlite
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
from config import ROLE_HIERARCHY, ROLE_LABELS, can_manage_role
from utils import character as character_mod
from webapp.deps import StaffContext, require_staff

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/whoami")
async def whoami(ctx: StaffContext = Depends(require_staff)):
    return {"user_id": ctx.user_id, "role": ctx.role, "label": ctx.label, "level": ctx.level}


@router.get("/search")
async def search_users(q: str = "", limit: int = 25, ctx: StaffContext = Depends(require_staff)):
    limit = max(1, min(limit, 100))
    async with database.db_read(row_factory=aiosqlite.Row) as db:
        if q.strip().lstrip("-").isdigit():
            async with db.execute(
                "SELECT user_id, username, full_name, balance, banned, registered FROM users "
                "WHERE user_id = ? LIMIT ?", (int(q.strip()), limit)
            ) as cur:
                rows = await cur.fetchall()
        else:
            like = f"%{q.strip()}%"
            async with db.execute(
                "SELECT user_id, username, full_name, balance, banned, registered FROM users "
                "WHERE username LIKE ? OR full_name LIKE ? ORDER BY last_seen DESC LIMIT ?",
                (like, like, limit),
            ) as cur:
                rows = await cur.fetchall()
    return {"results": [dict(r) for r in rows]}


@router.get("/user/{target_id}")
async def get_user_detail(target_id: int, ctx: StaffContext = Depends(require_staff)):
    user = await database.get_user(target_id)
    ch = await character_mod.get(target_id)
    accounts = await database.get_all_bank_accounts(target_id)
    active_role = await database.get_active_admin_role(target_id)
    return {
        "user": user,
        "character": ch,
        "bank_accounts": accounts,
        "active_role": active_role,
        "editable_fields": sorted(database.ALLOWED_FIELDS),
    }


class BalanceAdjustIn(BaseModel):
    delta: int
    reason: str = ""


@router.post("/user/{target_id}/balance")
async def adjust_balance(target_id: int, body: BalanceAdjustIn, ctx: StaffContext = Depends(require_staff)):
    try:
        await database.update_balance(target_id, body.delta)
    except ValueError:
        raise HTTPException(status_code=422, detail="Solde insuffisant pour ce retrait.")
    user = await database.get_user(target_id)
    return {"balance": user["balance"]}


class FieldEditIn(BaseModel):
    field: str
    value: str | int | float


@router.post("/user/{target_id}/field")
async def edit_field(target_id: int, body: FieldEditIn, ctx: StaffContext = Depends(require_staff)):
    if body.field not in database.ALLOWED_FIELDS:
        raise HTTPException(status_code=400, detail=f"Champ non autorisé : {body.field}")
    try:
        await database.update_field(target_id, body.field, body.value)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    user = await database.get_user(target_id)
    return {"user": user}


class BanIn(BaseModel):
    banned: bool


@router.post("/user/{target_id}/ban")
async def set_ban(target_id: int, body: BanIn, ctx: StaffContext = Depends(require_staff)):
    await database.update_field(target_id, "banned", 1 if body.banned else 0)
    return {"banned": body.banned}


@router.get("/roles")
async def roles(ctx: StaffContext = Depends(require_staff)):
    return {
        "hierarchy": ROLE_HIERARCHY,
        "labels": ROLE_LABELS,
        "active": await database.list_admin_roles(),
    }


class RoleAssignIn(BaseModel):
    role: str


@router.post("/user/{target_id}/role")
async def assign_role(target_id: int, body: RoleAssignIn, ctx: StaffContext = Depends(require_staff)):
    if body.role not in ROLE_HIERARCHY:
        raise HTTPException(status_code=400, detail="Rôle inconnu.")
    if not can_manage_role(ctx.role, body.role):
        raise HTTPException(status_code=403, detail="Ton rôle ne permet pas d'attribuer ce rôle.")
    await database.assign_admin_role(ctx.user_id, target_id, body.role, notes="via panneau admin web")
    return {"assigned": body.role}


@router.post("/user/{target_id}/role/revoke")
async def revoke_role(target_id: int, ctx: StaffContext = Depends(require_staff)):
    current = await database.get_active_admin_role(target_id)
    if current and not can_manage_role(ctx.role, current["role"]):
        raise HTTPException(status_code=403, detail="Ton rôle ne permet pas de révoquer celui-ci.")
    revoked = await database.revoke_admin_role(ctx.user_id, target_id)
    return {"revoked": revoked}
