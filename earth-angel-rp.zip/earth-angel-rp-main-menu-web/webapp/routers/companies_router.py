"""webapp/routers/companies_router.py — Entreprises (MVP) : consulter le marché, voir son
entreprise, en créer une, gérer son catalogue de produits, ses parts, ses contrats et ses fusions. Réutilise
la même logique que handlers/companies.py (coût de création, secteurs, parts initiales) et,
pour les produits, les parts et les contrats, `gameplay/companies.py` — le même service que
`handlers/company_products.py`/`handlers/company_shares.py`/`handlers/company_deals.py`, aucune
règle n'est recalculée ici. Embauche, salaires et R&D restent sur le bot pour l'instant
(systèmes non encore extraits en service pur, prochaine itération, voir TODO.md).
"""
from __future__ import annotations

import aiosqlite
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
import gameplay.companies as companies_service
import gameplay.hiring as hiring_service
from config import COMPANY_CREATION_COST, SECTORS
from utils.company_roles import can_manage
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/companies", tags=["companies"])


@router.get("")
async def list_companies(sector: str | None = None, user_id: int = Depends(require_character_complete)):
    companies = await database.get_all_companies(sector)
    return {"sectors": SECTORS, "companies": companies[:50]}


@router.get("/mine")
async def my_company(user_id: int = Depends(require_character_complete)):
    company = await database.get_user_company(user_id)
    return {"company": company}


class CreateCompanyIn(BaseModel):
    name: str
    sector: str


@router.post("/create")
async def create_company(body: CreateCompanyIn, user_id: int = Depends(require_character_complete)):
    name = body.name.strip()[:50]
    matched_sector = next((s for s in SECTORS if s.lower() == body.sector.strip().lower()), None)
    if not name or len(name) < 2:
        raise HTTPException(status_code=422, detail="Nom invalide.")
    if not matched_sector:
        raise HTTPException(status_code=422, detail=f"Secteur inconnu. Choix : {', '.join(SECTORS)}")

    u = await database.get_user(user_id)
    if u["balance"] < COMPANY_CREATION_COST:
        raise HTTPException(status_code=422, detail=f"Fonds insuffisants. Coût : {COMPANY_CREATION_COST}")

    existing_company = await database.get_user_company(user_id)
    if existing_company and existing_company.get("owner_id") == user_id:
        raise HTTPException(status_code=409, detail="Tu diriges déjà une entreprise !")

    async with database.db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT company_id, dissolved FROM companies WHERE name=?", (name,)
            ) as cur:
                existing = await cur.fetchone()
            if existing and existing[1] == 0:
                await db.rollback()
                raise HTTPException(status_code=409, detail=f"Une entreprise nommée '{name}' existe déjà.")
            if existing and existing[1] != 0:
                cid = existing[0]
                for table in ("company_members", "company_shares", "company_applications",
                              "company_logs", "company_products", "company_ads", "company_invitations"):
                    await db.execute(f"DELETE FROM {table} WHERE company_id=?", (cid,))
                await db.execute("DELETE FROM companies WHERE company_id=?", (cid,))

            debit = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
                (COMPANY_CREATION_COST, COMPANY_CREATION_COST, user_id, COMPANY_CREATION_COST),
            )
            if debit.rowcount != 1:
                await db.rollback()
                raise HTTPException(status_code=422, detail="Fonds insuffisants.")

            cur = await db.execute(
                "INSERT INTO companies (name,owner_id,sector,treasury,reputation,level,dissolved,created_at) "
                "VALUES (?,?,?,0,50,1,0,?)",
                (name, user_id, matched_sector, database.now()),
            )
            company_id = cur.lastrowid
            await db.execute(
                "INSERT INTO company_members (user_id,company_id,poste,salary,base_salary,activity_score,joined_at) "
                "VALUES (?,?,'PDG',0,0,0,?)",
                (user_id, company_id, database.now()),
            )
            await db.execute(
                "INSERT INTO company_shares (user_id,company_id,shares) VALUES (?,?,100)",
                (user_id, company_id),
            )
            await db.commit()
        except HTTPException:
            raise
        except aiosqlite.IntegrityError:
            await db.rollback()
            raise HTTPException(status_code=409, detail="Nom déjà pris ou tu appartiens déjà à une entreprise.")
        except Exception:
            await db.rollback()
            raise

    return {"company_id": company_id, "name": name, "sector": matched_sector}


async def _owned_company(user_id: int) -> dict:
    """Entreprise du PDG appelant (correspondance stricte owner_id, comme `cmd_produits`)."""
    company = await database.get_user_company(user_id)
    if not company or company.get("owner_id") != user_id:
        raise HTTPException(status_code=403, detail="Seul le PDG peut voir les produits de l'entreprise.")
    return company


async def _managed_company(user_id: int) -> dict:
    """Entreprise de l'appelant, s'il peut la gérer (créateur ou gérant)."""
    company = await database.get_user_company(user_id)
    if not company or not await can_manage(user_id, company):
        raise HTTPException(status_code=403, detail="Seul le PDG ou un gérant peut gérer les produits.")
    return company


@router.get("/products")
async def products(user_id: int = Depends(require_character_complete)):
    company = await _owned_company(user_id)
    return {"products": await companies_service.list_products(user_id, company["company_id"])}


class ProductPriceIn(BaseModel):
    name: str
    price: int


@router.post("/products/price")
async def set_product_price(body: ProductPriceIn, user_id: int = Depends(require_character_complete)):
    company = await _managed_company(user_id)
    if body.price < 0:
        raise HTTPException(status_code=422, detail="Prix invalide.")
    ok = await companies_service.set_product_price(company["company_id"], body.name, body.price)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Produit '{body.name}' introuvable.")
    return {"updated": True, "name": body.name, "price": body.price}


class ProductNameIn(BaseModel):
    name: str


@router.post("/products/delete")
async def delete_product(body: ProductNameIn, user_id: int = Depends(require_character_complete)):
    company = await _managed_company(user_id)
    ok = await companies_service.delete_product(company["company_id"], user_id, body.name)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Produit '{body.name}' introuvable dans le catalogue.")
    return {"deleted": True, "name": body.name}


class ProductWithdrawIn(BaseModel):
    item_id: int
    quantity: int


@router.post("/products/withdraw")
async def withdraw_product(body: ProductWithdrawIn, user_id: int = Depends(require_character_complete)):
    await _managed_company(user_id)
    if body.quantity <= 0:
        raise HTTPException(status_code=422, detail="Quantité invalide.")
    ok, message, name = await companies_service.withdraw_product(user_id, body.item_id, body.quantity)
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    return {"withdrawn": True, "name": name, "quantity": body.quantity, "message": message}


# ─────────────── Parts / capital : sa propre entreprise par défaut ; `company_name` cible
# n'importe quelle entreprise active, comme `/acheterparts "Nom" N` et `/vendreparts "Nom" N` ───────────────


async def _member_company(user_id: int) -> dict:
    company = await database.get_user_company(user_id)
    if not company:
        raise HTTPException(status_code=403, detail="Tu n'es pas dans une entreprise.")
    return company


async def _target_company(user_id: int, company_name: str | None) -> dict:
    """Entreprise visée par un achat/une vente de parts : celle du nom donné, sinon la sienne (comme le bot)."""
    if company_name and company_name.strip():
        company = await database.get_company_by_name(company_name.strip())
        if not company:
            raise HTTPException(status_code=404, detail=f"Entreprise '{company_name.strip()}' introuvable.")
        return company
    return await _member_company(user_id)


@router.get("/shares/quote")
async def share_quote(name: str, user_id: int = Depends(require_character_complete)):
    """Prix de la part d'une entreprise quelconque, avec ce que l'appelant y détient."""
    company = await _target_company(user_id, name)
    return {
        "company": {"name": company["name"], "treasury": company["treasury"], "reputation": company["reputation"]},
        "share_price": companies_service.share_price(company["treasury"], company["reputation"], company.get("rd_level", 0)),
        "my_shares": await companies_service.get_user_shares(user_id, company["company_id"]),
    }


@router.get("/shares")
async def shares(user_id: int = Depends(require_character_complete)):
    company = await _member_company(user_id)
    holders = await companies_service.shareholders(company["company_id"])
    total_shares = sum(h["shares"] for h in holders) or 1
    rd_level = company.get("rd_level", 0)
    price = companies_service.share_price(company["treasury"], company["reputation"], rd_level)
    return {
        "company": {"name": company["name"], "treasury": company["treasury"], "reputation": company["reputation"]},
        "share_price": price,
        "market_cap": total_shares * price,
        "shareholders": holders,
    }


class SharesQuantityIn(BaseModel):
    quantity: int
    company_name: str | None = None


_BUY_REASONS = {
    "invalid_quantity": "Nombre invalide.",
    "total_too_large": "Le coût total est trop élevé. Contactez un administrateur.",
}

_SELL_REASONS = {
    "invalid_quantity": "Nombre invalide.",
    "no_shares": "Tu ne possèdes aucune part de cette entreprise.",
    "total_too_large": "La valeur totale est trop élevée. Contactez un administrateur.",
}


@router.post("/shares/buy")
async def buy_shares(body: SharesQuantityIn, user_id: int = Depends(require_character_complete)):
    company = await _target_company(user_id, body.company_name)
    rd_level = company.get("rd_level", 0)
    result = await companies_service.buy_shares(
        user_id, company["company_id"], company["treasury"], company["reputation"], rd_level, body.quantity
    )
    if not result["ok"]:
        if result["reason"] == "insufficient_funds":
            raise HTTPException(status_code=422, detail=f"Fonds insuffisants. Coût : {result['total_cost']}")
        raise HTTPException(status_code=422, detail=_BUY_REASONS.get(result["reason"], "Achat refusé."))
    await database.log_company_action(
        company["company_id"], "achat_parts", user_id, f"{body.quantity} parts ({result['total_cost']})"
    )
    return result


@router.post("/shares/sell")
async def sell_shares(body: SharesQuantityIn, user_id: int = Depends(require_character_complete)):
    company = await _target_company(user_id, body.company_name)
    rd_level = company.get("rd_level", 0)
    result = await companies_service.sell_shares(
        user_id, company["company_id"], company["treasury"], company["reputation"], rd_level, body.quantity
    )
    if not result["ok"]:
        if result["reason"] == "not_enough_shares":
            raise HTTPException(
                status_code=422, detail=f"Tu ne possèdes que {result['current_shares']} parts de cette entreprise."
            )
        raise HTTPException(status_code=422, detail=_SELL_REASONS.get(result["reason"], "Vente refusée."))
    await database.log_company_action(
        company["company_id"], "vente_parts", user_id, f"{body.quantity} parts ({result['total_value']})"
    )
    return result


class DividendPercentIn(BaseModel):
    percent: int = 10


@router.post("/dividends")
async def distribute_dividends(body: DividendPercentIn, user_id: int = Depends(require_character_complete)):
    company = await database.get_user_company(user_id)
    if not company or company.get("owner_id") != user_id:
        raise HTTPException(status_code=403, detail="Seul le PDG peut verser des dividendes.")
    result = await companies_service.distribute_dividends(company["company_id"], company["treasury"], body.percent)
    if not result["ok"]:
        if result["reason"] == "treasury_too_low":
            raise HTTPException(
                status_code=422,
                detail=f"Trésorerie trop faible pour verser {result['percent']}% de dividendes significatifs.",
            )
        raise HTTPException(status_code=422, detail="Aucune part en circulation.")
    await database.log_company_action(
        company["company_id"], "dividendes", user_id, f"{result['percent']}% ({result['dividend_total']})"
    )
    return result


# ─────────────────────────── Contrats inter-entreprises ───────────────────────────


@router.get("/contracts")
async def contracts(user_id: int = Depends(require_character_complete)):
    company = await _member_company(user_id)
    return {"contracts": await companies_service.list_contracts(company["company_id"])}


class ProposeContractIn(BaseModel):
    target_company_id: int
    amount: int
    duration: int
    contract_type: str


_PROPOSE_REASONS = {
    "invalid_args": "Arguments invalides.",
    "same_company": "Entreprise cible introuvable.",
    "target_not_found": "Entreprise cible introuvable.",
    "target_dissolved": "Cette entreprise est dissoute.",
    "already_pending": "Un contrat est déjà en attente entre ces deux entreprises.",
}


@router.post("/contracts/propose")
async def propose_contract(body: ProposeContractIn, user_id: int = Depends(require_character_complete)):
    company = await database.get_user_company(user_id)
    if not company or company.get("owner_id") != user_id:
        raise HTTPException(status_code=403, detail="Seul le PDG peut proposer un contrat.")
    result = await companies_service.propose_contract(
        company["company_id"], company["name"], body.target_company_id, body.amount, body.duration,
        body.contract_type,
    )
    if not result["ok"]:
        raise HTTPException(status_code=422, detail=_PROPOSE_REASONS.get(result["reason"], "Contrat refusé."))
    return result


class ContractDecisionIn(BaseModel):
    contract_id: int
    accept: bool


_RESPOND_REASONS = {
    "not_found": "Contrat introuvable ou déjà traité.",
    "not_target_owner": "Vous n'êtes pas le PDG de l'entreprise cible.",
    "source_dissolved": "L'entreprise émettrice a été dissoute.",
    "insufficient_treasury": "L'entreprise émettrice n'a pas assez de trésorerie.",
}


@router.post("/contracts/respond")
async def respond_contract(body: ContractDecisionIn, user_id: int = Depends(require_character_complete)):
    result = await companies_service.respond_contract(user_id, body.contract_id, body.accept)
    if not result["ok"]:
        raise HTTPException(status_code=422, detail=_RESPOND_REASONS.get(result["reason"], "Réponse refusée."))
    return result


class NegotiateContractIn(BaseModel):
    contract_id: int
    amount: int
    duration: int


@router.post("/contracts/negotiate")
async def negotiate_contract(body: NegotiateContractIn, user_id: int = Depends(require_character_complete)):
    result = await companies_service.negotiate_contract(user_id, body.contract_id, body.amount, body.duration)
    if not result["ok"]:
        if result["reason"] == "not_target_owner":
            raise HTTPException(status_code=403, detail="Vous n'êtes pas le PDG de l'entreprise cible.")
        if result["reason"] == "not_found":
            raise HTTPException(status_code=404, detail="Contrat introuvable ou déjà traité.")
        raise HTTPException(status_code=422, detail="Arguments invalides.")
    return result


# ─────────────────────────── Fusions ───────────────────────────


@router.get("/fusions")
async def fusions(user_id: int = Depends(require_character_complete)):
    company = await _member_company(user_id)
    return {"fusions": await companies_service.list_fusions(company["company_id"])}


class ProposeFusionIn(BaseModel):
    target_company_id: int


_FUSION_PROPOSE_REASONS = {
    "same_company": "Entreprise cible introuvable.",
    "target_not_found": "Entreprise cible introuvable.",
    "target_dissolved": "Cette entreprise est dissoute.",
    "already_pending": "Une demande de fusion est déjà en attente entre ces deux entreprises.",
}


@router.post("/fusions/propose")
async def propose_fusion(body: ProposeFusionIn, user_id: int = Depends(require_character_complete)):
    company = await database.get_user_company(user_id)
    if not company or company.get("owner_id") != user_id:
        raise HTTPException(status_code=403, detail="Seul le PDG peut proposer une fusion.")
    result = await companies_service.propose_fusion(company["company_id"], company["name"], body.target_company_id)
    if not result["ok"]:
        raise HTTPException(status_code=422, detail=_FUSION_PROPOSE_REASONS.get(result["reason"], "Fusion refusée."))
    return result


class FusionDecisionIn(BaseModel):
    accept: bool


_FUSION_RESPOND_REASONS = {
    "not_owner": "Vous n'êtes pas le PDG de cette entreprise.",
    "no_request": "Aucune demande de fusion en attente pour cette entreprise.",
    "source_dissolved": "L'entreprise émettrice a été dissoute entre-temps.",
    "insufficient_treasury": "L'entreprise émettrice n'a pas assez de trésorerie pour absorber votre entreprise.",
}


@router.post("/fusions/respond")
async def respond_fusion(body: FusionDecisionIn, user_id: int = Depends(require_character_complete)):
    company = await database.get_user_company(user_id)
    if not company or company.get("owner_id") != user_id:
        raise HTTPException(status_code=403, detail="Vous n'êtes pas le PDG de cette entreprise.")
    result = await companies_service.respond_fusion(user_id, company["company_id"], body.accept)
    if not result["ok"]:
        raise HTTPException(status_code=422, detail=_FUSION_RESPOND_REASONS.get(result["reason"], "Réponse refusée."))
    return result


# ─────────────────────────── Transfert de PDG ───────────────────────────


class TransferIn(BaseModel):
    target_user_id: int


@router.post("/transfer")
async def transfer_ownership(body: TransferIn, user_id: int = Depends(require_character_complete)):
    company = await database.get_user_company(user_id)
    if not company or company.get("owner_id") != user_id:
        raise HTTPException(status_code=403, detail="Seul le PDG peut transférer l'entreprise.")
    result = await companies_service.transfer_ownership(user_id, company["company_id"], body.target_user_id)
    if not result["ok"]:
        detail = {
            "same_user": "Tu ne peux pas te transférer l'entreprise à toi-même.",
            "target_not_member": "Ce joueur n'est pas employé dans cette entreprise.",
        }.get(result["reason"], "Seul le PDG peut transférer l'entreprise.")
        raise HTTPException(status_code=422, detail=detail)
    return result



# ─────────────── Équipe, recrutement, salaires (gameplay/hiring.py, même service que le bot) ───────────────
_HIRING_REFUSALS = {
    "not_manager": (403, "Réservé au créateur et aux gérants."),
    "not_owner": (403, "Réservé au PDG."),
    "invalid_salary": (422, "Salaire invalide."),
    "state_employee": (422, "Cette personne travaille pour l'État."),
    "already_employed": (422, "Cette personne travaille déjà dans une entreprise."),
    "already_pending": (422, "Candidature déjà en attente."),
    "unknown_company": (404, "Entreprise introuvable."),
    "unknown_application": (404, "Candidature introuvable."),
    "no_offer": (404, "Aucune offre en négociation trouvée."),
    "no_company": (403, "Tu ne travailles dans aucune entreprise."),
    "is_owner": (422, "Tu es PDG : transfère ou dissous l'entreprise."),
    "target_not_member": (422, "Cet employé ne travaille pas dans ton entreprise."),
    "self": (422, "Tu ne peux pas te licencier toi-même."),
    "owner_only": (422, "Seul le créateur peut licencier un gérant ou le créateur."),
}


def _hiring_refuse(result: dict):
    status, detail = _HIRING_REFUSALS.get(result.get("reason"), (422, "Action impossible."))
    raise HTTPException(status_code=status, detail=detail)


async def _full_name(user_id: int) -> str:
    user = await database.get_user(user_id)
    return (user or {}).get("full_name") or str(user_id)


@router.get("/team")
async def team(name: str | None = None, user_id: int = Depends(require_character_complete)):
    company = await _target_company(user_id, name)
    return {"company": {"company_id": company["company_id"], "name": company["name"]},
            "members": await hiring_service.team(company["company_id"])}


@router.get("/applications")
async def applications(user_id: int = Depends(require_character_complete)):
    """Candidatures en attente (créateur et gérants) + mes propres candidatures/contre-offres."""
    mine = await hiring_service.my_applications(user_id)
    company = await database.get_user_company(user_id)
    pending = []
    if company and await can_manage(user_id, company):
        pending = await hiring_service.pending_applications(company["company_id"])
    return {"pending": pending, "mine": mine}


class ApplyIn(BaseModel):
    company_name: str
    desired_salary: int = 0


@router.post("/apply")
async def apply_to_company(body: ApplyIn, user_id: int = Depends(require_character_complete)):
    company = await database.get_company_by_name(body.company_name.strip())
    if not company:
        _hiring_refuse({"reason": "unknown_company"})
    result = await hiring_service.apply(user_id, company["company_id"], body.desired_salary)
    if not result["ok"]:
        _hiring_refuse(result)
    return result


class ApplicationSalaryIn(BaseModel):
    app_id: int
    salary: int


@router.post("/applications/accept")
async def accept_application(body: ApplicationSalaryIn, user_id: int = Depends(require_character_complete)):
    result = await hiring_service.accept_application(user_id, body.app_id, body.salary)
    if not result["ok"]:
        _hiring_refuse(result)
    return result


@router.post("/applications/negotiate")
async def negotiate_application(body: ApplicationSalaryIn, user_id: int = Depends(require_character_complete)):
    result = await hiring_service.counter_offer(user_id, body.app_id, body.salary)
    if not result["ok"]:
        _hiring_refuse(result)
    return result


class ApplicationIn(BaseModel):
    app_id: int


@router.post("/applications/refuse")
async def refuse_application(body: ApplicationIn, user_id: int = Depends(require_character_complete)):
    result = await hiring_service.refuse_application(user_id, body.app_id)
    if not result["ok"]:
        _hiring_refuse(result)
    return result


class OfferResponseIn(BaseModel):
    app_id: int
    accept: bool


@router.post("/offer/respond")
async def respond_offer(body: OfferResponseIn, user_id: int = Depends(require_character_complete)):
    result = await hiring_service.respond_offer(user_id, await _full_name(user_id), body.app_id, body.accept)
    if not result["ok"]:
        _hiring_refuse(result)
    return result


@router.post("/resign")
async def resign(user_id: int = Depends(require_character_complete)):
    result = await hiring_service.resign(user_id, await _full_name(user_id))
    if not result["ok"]:
        _hiring_refuse(result)
    return result


class PayIn(BaseModel):
    target_user_id: int
    salary: int
    poste: str | None = None


@router.post("/pay")
async def set_pay(body: PayIn, user_id: int = Depends(require_character_complete)):
    result = await hiring_service.set_pay(user_id, body.target_user_id, body.salary, body.poste)
    if not result["ok"]:
        _hiring_refuse(result)
    return result


class FireIn(BaseModel):
    target_user_id: int


@router.post("/fire")
async def fire(body: FireIn, user_id: int = Depends(require_character_complete)):
    result = await hiring_service.fire(user_id, body.target_user_id)
    if not result["ok"]:
        _hiring_refuse(result)
    return result
