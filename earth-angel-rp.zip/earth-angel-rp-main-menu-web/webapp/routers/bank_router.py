"""webapp/routers/bank_router.py — Ouvrir un compte, déposer, retirer (MVP).

Même logique et mêmes règles que `handlers/bank.py` côté bot (mêmes banques, mêmes seuils),
réécrites ici en JSON plutôt qu'en messages Telegram. Les prêts et les intérêts composés
restent gérés par le bot pour l'instant (viendront dans une prochaine itération de l'API).
"""
from __future__ import annotations

import aiosqlite
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
from config import BANKS
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/bank", tags=["bank"])


def _bank_config(name: str):
    return next((b for b in BANKS if b["name"] == name), None)


@router.get("")
async def list_accounts(user_id: int = Depends(require_character_complete)):
    user = await database.get_user(user_id)
    accounts = await database.get_all_bank_accounts(user_id)
    opened_names = {a["bank_name"] for a in accounts}
    return {
        "wallet_balance": user["balance"],
        "accounts": accounts,
        "banks": [
            {**b, "opened": b["name"] in opened_names, "daily_interest_pct": round(b["interest"] * 100, 4)}
            for b in BANKS
        ],
    }


class BankNameIn(BaseModel):
    bank_name: str


@router.post("/open")
async def open_account(body: BankNameIn, user_id: int = Depends(require_character_complete)):
    bank = _bank_config(body.bank_name)
    if not bank:
        raise HTTPException(status_code=404, detail="Banque introuvable.")
    user = await database.get_user(user_id)
    if user["balance"] < bank["min"]:
        raise HTTPException(status_code=422, detail=f"Il faut au moins {bank['min']} dans ton portefeuille.")

    async with database.db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            await db.execute(
                "INSERT INTO bank_accounts (user_id, bank_name, balance, loan, loan_due, "
                "loan_penalty_applied, opened_at, last_interest) VALUES (?, ?, 0, 0, 0, 0, ?, ?)",
                (user_id, bank["name"], database.now(), database.now()),
            )
            await db.commit()
        except aiosqlite.IntegrityError:
            await db.rollback()
            raise HTTPException(status_code=409, detail="Tu as déjà un compte dans cette banque.")
        except Exception:
            await db.rollback()
            raise
    return {"opened": bank["name"]}


class AmountIn(BaseModel):
    bank_name: str
    amount: int


@router.post("/deposit")
async def deposit(body: AmountIn, user_id: int = Depends(require_character_complete)):
    if body.amount <= 0:
        raise HTTPException(status_code=422, detail="Montant invalide.")
    account = await database.get_bank_account(user_id, body.bank_name)
    if not account:
        raise HTTPException(status_code=404, detail="Ouvre d'abord un compte dans cette banque.")

    async with database.db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            debit = await db.execute(
                "UPDATE users SET balance = balance - ?, total_spent = total_spent + ? "
                "WHERE user_id = ? AND balance >= ?",
                (body.amount, body.amount, user_id, body.amount),
            )
            if debit.rowcount != 1:
                await db.rollback()
                raise HTTPException(status_code=422, detail="Fonds insuffisants.")
            await db.execute(
                "UPDATE bank_accounts SET balance = balance + ? WHERE user_id = ? AND bank_name = ?",
                (body.amount, user_id, body.bank_name),
            )
            await db.commit()
        except HTTPException:
            raise
        except Exception:
            await db.rollback()
            raise
    return {"deposited": body.amount, "bank_name": body.bank_name}


@router.post("/withdraw")
async def withdraw(body: AmountIn, user_id: int = Depends(require_character_complete)):
    if body.amount <= 0:
        raise HTTPException(status_code=422, detail="Montant invalide.")
    account = await database.get_bank_account(user_id, body.bank_name)
    if not account:
        raise HTTPException(status_code=404, detail="Compte introuvable.")

    async with database.db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            debit = await db.execute(
                "UPDATE bank_accounts SET balance = balance - ? "
                "WHERE user_id = ? AND bank_name = ? AND balance >= ?",
                (body.amount, user_id, body.bank_name, body.amount),
            )
            if debit.rowcount != 1:
                await db.rollback()
                raise HTTPException(status_code=422, detail="Fonds bancaires insuffisants.")
            await db.execute(
                "UPDATE users SET balance = balance + ?, total_earned = total_earned + ? WHERE user_id = ?",
                (body.amount, body.amount, user_id),
            )
            await db.commit()
        except HTTPException:
            raise
        except Exception:
            await db.rollback()
            raise
    return {"withdrawn": body.amount, "bank_name": body.bank_name}
