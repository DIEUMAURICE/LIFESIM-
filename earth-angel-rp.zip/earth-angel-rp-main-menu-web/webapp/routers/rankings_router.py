"""API des classements, adaptateur du moteur Telegram/Web partagé."""
from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from utils.rankings import GROUPS, RANKINGS, get_page
from webapp.deps import get_active_user_id

router = APIRouter(prefix="/api/rankings", tags=["rankings"])

@router.get("/menu")
async def menu():
    return {"groups": [{"title": title, "items": [{"key": key, "title": RANKINGS[key].title, "emoji": RANKINGS[key].emoji, "desc": RANKINGS[key].desc} for key in keys]} for title, keys in GROUPS]}

@router.get("/rich")
async def rich(limit: int = 20, user_id: int = Depends(get_active_user_id)):
    page = await get_page("richesse", 1, user_id, max(1, min(limit, 100)))
    top = [{**row, "user_id": row["id"], "full_name": row["name"], "balance": row["value"]} for row in page["rows"]]
    return {"top": top, "me": page["me"], "total": page["total"], "page": page["page"], "pages": page["pages"]}

@router.get("/{key}")
async def ranking(key: str, page: int = 1, limit: int = 15, user_id: int = Depends(get_active_user_id)):
    if key not in RANKINGS:
        raise HTTPException(404, "Classement introuvable.")
    return await get_page(key, page, user_id, max(1, min(limit, 100)))
