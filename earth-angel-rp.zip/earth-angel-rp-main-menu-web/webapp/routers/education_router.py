"""webapp/routers/education_router.py — Études, compétences et examens (Mini App + Web).

Aucune règle recalculée ici : chaque mutation appelle gameplay/education.py, le même service
utilisé par handlers/education.py (bot Telegram). Ce routeur ne fait que lire l'état et
traduire les refus (EducationError) en réponses HTTP.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

import gameplay.education as edu_service
from config import SKILLS, SKILL_LEVEL_COST
from database import get_all_skills, get_user
from utils.courses import MAX_REVISIONS
from utils.decorators import free_problem
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/education", tags=["education"])


async def _free(uid: int) -> None:
    problem = await free_problem(uid, "handlers.education")
    if problem:
        import re
        raise HTTPException(status_code=409, detail=re.sub(r"<[^>]+>", "", problem))


def _raise(e: edu_service.EducationError):
    status = {
        "insufficient_funds": 400, "already_enrolled": 409, "already_obtained": 409,
        "wrong_order": 409, "invalid_diploma": 422, "not_enrolled": 409, "max_revisions": 409,
        "too_tired": 409, "too_early": 409, "no_lessons": 409, "no_exam": 404,
        "invalid_answer": 422, "invalid_skill": 422, "max_level": 409,
    }.get(e.code, 400)
    raise HTTPException(status_code=status, detail=str(e))


@router.get("/home")
async def home(uid: int = Depends(require_character_complete)):
    """Catalogue des diplômes + compétences, dans le même ordre que le menu du bot."""
    u = await get_user(uid)
    current = u.get("diplome", "")
    diplomas = [edu_service.diplome_view(d, current) for d in edu_service.DIPLOME_ORDER]
    skills_raw = await get_all_skills(uid)
    skills = [{"name": s, "level": skills_raw.get(s, 0), "cost": SKILL_LEVEL_COST * (skills_raw.get(s, 0) + 1)}
              for s in SKILLS]
    study_dip = u.get("study_diplome") or ""
    ongoing = None
    if study_dip:
        from database import now
        rem = max(0, (u.get("study_start", 0) + edu_service.ALL_STUDY_TIME.get(study_dip, 0)) - now())
        ongoing = {"diploma": study_dip, "revisions": u.get("study_revisions", 0),
                   "max_revisions": MAX_REVISIONS,
                   "remaining_seconds": rem, "exam_ready": rem <= 0}
    return {"diplomas": diplomas, "skills": skills, "ongoing": ongoing, "current_diploma": current}


class EnrollIn(BaseModel):
    diploma: str


@router.post("/enroll")
async def enroll(body: EnrollIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    if body.diploma not in edu_service.DIPLOME_ORDER:
        raise HTTPException(status_code=422, detail="Diplôme inconnu.")
    try:
        return {"ok": True, **await edu_service.enroll(uid, edu_service.DIPLOME_ORDER.index(body.diploma))}
    except edu_service.EducationError as e:
        _raise(e)


@router.post("/revise")
async def revise(uid: int = Depends(require_character_complete)):
    await _free(uid)
    try:
        return {"ok": True, **await edu_service.revise(uid)}
    except edu_service.EducationError as e:
        _raise(e)


@router.get("/courses")
async def my_courses(uid: int = Depends(require_character_complete)):
    return {"courses": await edu_service.my_courses(uid)}


@router.get("/exam/history")
async def exam_history(uid: int = Depends(require_character_complete)):
    return {"history": await edu_service.exam_history(uid)}


@router.post("/exam")
async def exam(uid: int = Depends(require_character_complete)):
    """Démarre ou reprend l'examen et renvoie la question courante (ou le résultat s'il est déjà fini)."""
    await _free(uid)
    try:
        return {"ok": True, **await edu_service.start_or_continue_exam(uid)}
    except edu_service.EducationError as e:
        _raise(e)


class AnswerIn(BaseModel):
    choice: int = Field(ge=0, le=3)


@router.post("/exam/answer")
async def exam_answer(body: AnswerIn, uid: int = Depends(require_character_complete)):
    await _free(uid)
    try:
        return {"ok": True, **await edu_service.answer_exam(uid, body.choice)}
    except edu_service.EducationError as e:
        _raise(e)


@router.post("/exam/finish")
async def exam_finish(uid: int = Depends(require_character_complete)):
    """Équivalent du bouton « Voir mon résultat » (callback edu_suite) une fois la dernière question répondue."""
    try:
        return {"ok": True, **await edu_service.finalize_exam(uid)}
    except edu_service.EducationError as e:
        _raise(e)


class SkillIn(BaseModel):
    skill: str


@router.post("/skill/upgrade")
async def skill_upgrade(body: SkillIn, uid: int = Depends(require_character_complete)):
    if body.skill not in SKILLS:
        raise HTTPException(status_code=422, detail="Compétence inconnue.")
    try:
        return {"ok": True, **await edu_service.upgrade_skill_level(uid, SKILLS.index(body.skill))}
    except edu_service.EducationError as e:
        _raise(e)
