"""webapp/routers/sante_router.py — Santé publique, côté PATIENT (handlers/sante.py + utils/sante.py).

Hôpitaux, ambulance (gratuite), consultation, lit, pharmacie, assurance. Toute la logique métier
(prix, remboursements, stocks, lits) est celle du bot : ici on ne fait que l'exposer en JSON.

Pas encore porté (reste sur le bot) : le côté SOIGNANT / employé (« Mon poste » : récolte,
laboratoire, industrie, service, prise en charge des appels, équipe) et les commandes de direction.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
from config import INSURANCE_PLANS, MEDICINES
from utils import sante
from utils.gametime import add_game_months, fmt_game_datetime
from utils.helpers import now
from utils.location import distance_km, get_position, location_label
from webapp.deps import require_character_complete
from webapp.routers.places_router import plain

router = APIRouter(prefix="/api/sante", tags=["sante"])


def _fail(msg: str, status: int = 422):
    raise HTTPException(status_code=status, detail=plain(msg))


def _result(ok: bool, msg: str) -> dict:
    if not ok:
        _fail(msg)
    return {"ok": True, "message": plain(msg)}


@router.get("/status")
async def status(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    pos = await get_position(user_id)
    in_transit = bool(pos["in_transit"])
    here = None if in_transit else pos["location"]
    here_hospital = None if in_transit else sante.hospital_at(pos["location"])

    ins = await sante.get_insurance(user_id)
    insurance = None
    if ins:
        insurance = {
            "type": ins["type"], "claims": ins["claims"], "limit": ins["limit"], "left": ins["left"],
            "expires": plain(fmt_game_datetime(add_game_months(ins["since"], 1))),
        }
    bed = await sante.get_bed(user_id)
    call = await sante.get_open_call(user_id)

    hospitals = []
    for h in await sante.hospital_overview():
        head = h["head"]
        hospitals.append({
            "id": h["id"], "name": h["name"], "kind": h["kind"], "location": h["location"],
            "beds_free": h["beds_cap"] - h["beds_used"], "beds_cap": h["beds_cap"],
            "on_duty": h["on_duty"],
            "head": (head.get("full_name") or str(head["user_id"])) if head else None,
            "here": here == h["location"],
            "distance_km": None if (not here or here == h["location"]) else distance_km(here, h["location"]),
        })

    hospital_left = max(0, int(u.get("hospital_until", 0) or 0) - now())
    return {
        "health": u["health"], "energy": u["energy"], "balance": u["balance"],
        "hospitalized_seconds": hospital_left,
        "location_label": plain(location_label(pos["location"])) if not in_transit else None,
        "in_transit": in_transit,
        "at_hospital": bool(here_hospital),
        "insurance": insurance,
        "bed": bool(bed),
        "call": ({"id": call["call_id"], "status": call["status"]} if call else None),
        "hospitals": hospitals,
    }


@router.post("/ambulance")
async def ambulance(user_id: int = Depends(require_character_complete)):
    ok, msg = await sante.call_ambulance(user_id)
    return _result(ok, msg)


@router.post("/call/cancel")
async def cancel_call(user_id: int = Depends(require_character_complete)):
    await sante.cancel_call(user_id)
    return {"ok": True, "message": "Appel annulé."}


@router.post("/consult")
async def consult(user_id: int = Depends(require_character_complete)):
    ok, msg = await sante.request_consult(user_id)
    return _result(ok, msg)


@router.post("/bed/take")
async def take_bed(user_id: int = Depends(require_character_complete)):
    ok, msg = await sante.take_bed(user_id)
    return _result(ok, msg)


class LeaveBedIn(BaseModel):
    force: bool = False     # « partir sans soin » (même règle que le bot)


@router.post("/bed/leave")
async def leave_bed(body: LeaveBedIn, user_id: int = Depends(require_character_complete)):
    ok, msg = await sante.leave_bed(user_id, force=body.force)
    return _result(ok, msg)


@router.get("/pharmacy")
async def pharmacy(user_id: int = Depends(require_character_complete)):
    cat = await sante.pharmacy_catalog(user_id)
    return {
        "items": [
            {"name": m["name"], "emoji": m["emoji"], "health": m["health"], "price": m["price"],
             "base": m["base"], "discounted": m["discounted"], "stock": m["stock"]}
            for m in cat
        ],
    }


class BuyIn(BaseModel):
    med: str


@router.post("/pharmacy/buy")
async def buy(body: BuyIn, user_id: int = Depends(require_character_complete)):
    if body.med not in MEDICINES:
        _fail("Médicament inconnu.")
    ok, msg = await sante.buy_medicine(user_id, body.med)
    return _result(ok, msg)


@router.get("/insurance")
async def insurance_plans(user_id: int = Depends(require_character_complete)):
    return {
        "plans": [
            {"key": k, "emoji": p["emoji"], "cost": p["cost"], "coverage_pct": int(p["coverage"] * 100),
             "claims_limit": p["claims_limit"]}
            for k, p in INSURANCE_PLANS.items()
        ],
    }


class PlanIn(BaseModel):
    plan: str


@router.post("/insurance/subscribe")
async def subscribe(body: PlanIn, user_id: int = Depends(require_character_complete)):
    if body.plan not in INSURANCE_PLANS:
        _fail("Plan inconnu.")
    ok, msg = await sante.subscribe_insurance(user_id, body.plan)
    if ok:
        msg = f"Assurance {body.plan.capitalize()} souscrite : la prime va au coffre de la Santé publique."
    return _result(ok, msg)
