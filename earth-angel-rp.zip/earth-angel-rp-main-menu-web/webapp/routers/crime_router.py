"""webapp/routers/crime_router.py — Crime & Justice, en réutilisant la VRAIE logique du bot
(handlers/crime.py, utils/ordre.py, utils/weapons.py, handlers/gangs.py) : mêmes règles
(obligation d'être en gang, bonus de compétences/karma/arme/gang, système de fuite/enquête,
caution, tribunal, avocat). Seule la présentation change : un appel API JSON au lieu d'un
message Telegram avec boutons.
"""
from __future__ import annotations

import random

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
from config import BAIL_COST_RATIO, CRIME_COOLDOWN, CRIMES, JUSTICE, LAWYER_COST, ORDRE, WEAPON_REQUIRED_CRIMES
from database import get_skill, now
from handlers.crime import add_random_item
from handlers.gangs import NO_GANG_CRIME_TEXT, require_gang
from utils import justice as justice_service
from utils import ordre, weapons
from utils.helpers import roll_success
from utils.ordre import restraint_reason
from utils.vip import add_xp, chance_boost_bonus
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/crime", tags=["crime"])
justice_router = APIRouter(prefix="/api/justice", tags=["justice"])

CRIME_FLAVOR = {
    "Pickpocket":       "Tu glisses ta main dans une poche… Jackpot ! 🤫",
    "Vol à l'étalage":  "Tu sors du magasin sans te faire remarquer 😏",
    "Cambriolage":      "La maison était vide — parfait ! 🏠💨",
    "Arnaque":          "L'idiot a mordu à l'hameçon ! 🎣",
    "Braquage":         "Le coffre était plein ! Tu fuis dans une voiture volée 🚗💨",
    "Trafic drogue":    "La marchandise est livrée sans accroc 💊",
    "Cybercriminalité": "Les virements sont passés avant l'alerte 💻",
    "Hold-up banque":   "La police aux trousses mais tu t'en sors ! 🏦🔫",
}
CRIME_FAILS = [
    "La police t'attendait… Tu te fais menotter 👮",
    "Un témoin a tout vu et appelé le 17 ! 📞",
    "Une alarme silencieuse te trahit 🚨",
    "Ton complice t'a dénoncé ! 🐀",
    "Tu as laissé des empreintes partout 🔍",
    "Un passant t'a filmé en direct 📱",
]


@router.get("/status")
async def crime_status(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    prison_left = max(0, u.get("prison_until", 0) - now())
    cd_left = max(0, CRIME_COOLDOWN - (now() - u.get("last_crime", 0)))
    crimes = [
        {
            "name": name,
            "reward_min": data["reward"][0],
            "reward_max": data["reward"][1],
            "success_pct": round(data["success"] * 100),
            "karma": data["karma"],
            "needs_firearm": name in WEAPON_REQUIRED_CRIMES,
        }
        for name, data in CRIMES.items()
    ]
    return {
        "prison_seconds_left": prison_left,
        "cooldown_seconds_left": cd_left,
        "in_gang_or_exempt": await require_gang(user_id),
        "no_gang_text": NO_GANG_CRIME_TEXT if not await require_gang(user_id) else None,
        "crimes": crimes,
    }


class CommitCrimeIn(BaseModel):
    crime_name: str


@router.post("/commit")
async def commit_crime(body: CommitCrimeIn, user_id: int = Depends(require_character_complete)):
    if body.crime_name not in CRIMES:
        raise HTTPException(status_code=404, detail="Crime inconnu.")
    data = CRIMES[body.crime_name]
    u = await database.get_user(user_id)

    if u.get("health", 100) <= 0 and not u.get("god_mode"):
        raise HTTPException(status_code=422, detail="💀 Ta santé est à zéro : soigne-toi d'abord.")
    restrained = await restraint_reason(user_id)
    if restrained:
        raise HTTPException(status_code=423, detail=f"⛓️ Impossible : tu es {restrained}")
    if u.get("prison_until", 0) > now():
        raise HTTPException(status_code=423, detail="⛓️ Tu es en prison !")
    if now() - u.get("last_crime", 0) < CRIME_COOLDOWN:
        rem = CRIME_COOLDOWN - (now() - u.get("last_crime", 0))
        raise HTTPException(status_code=429, detail=f"⏳ Attends encore {rem} s.")
    if not await require_gang(user_id):
        raise HTTPException(status_code=403, detail=NO_GANG_CRIME_TEXT)

    discretion = await get_skill(user_id, "Discrétion")
    agility = await get_skill(user_id, "Agilité")
    skill_bonus = (discretion * 0.02) + (agility * 0.01)
    karma_bonus = max(-0.1, min(0.1, u.get("karma", 0) / 1000))
    chance_boost = chance_boost_bonus(u)

    gang_bonus = 0.0
    async with database.db_connection() as db:
        async with db.execute(
            "SELECT g.reputation FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
            (user_id,),
        ) as cur:
            gang_row = await cur.fetchone()
        if gang_row:
            gang_bonus = (gang_row[0] - 50) / 200

    weapon_bonus, weapon_msg, weapon_ok = await weapons.use_for_action(
        user_id, need_firearm=body.crime_name in WEAPON_REQUIRED_CRIMES
    )
    if not weapon_ok:
        raise HTTPException(status_code=422, detail=f"🔫 {body.crime_name} : {weapon_msg}")

    success = roll_success(data["success"], skill_bonus + gang_bonus + chance_boost + weapon_bonus, karma_bonus)
    await database.update_field(user_id, "last_crime", now())
    await database.increment_field(user_id, "crimes_done")

    if success:
        from handlers.gangs import split_crime_reward
        min_r, max_r = data["reward"]
        reward = random.randint(min_r, max_r)
        reward = await split_crime_reward(user_id, reward)
        await database.increment_field(user_id, "karma", data["karma"])
        await database.increment_field(user_id, "crimes_success")
        await add_xp(user_id, 150)
        await ordre.register_bot_crime(user_id, body.crime_name, reward)
        async with database.db_connection() as db:
            await db.execute(
                "INSERT INTO crime_log (user_id, crime_type, success, reward, timestamp) VALUES (?,?,1,?,?)",
                (user_id, body.crime_name, reward, now()),
            )
            await db.commit()

        loot = None
        if random.random() < 0.2:
            if body.crime_name in ("Hold-up banque", "Cybercriminalité"):
                loot = await add_random_item(user_id, "rare", "legendary")
            elif body.crime_name in ("Braquage", "Trafic drogue"):
                loot = await add_random_item(user_id, "common", "epic")
            else:
                loot = await add_random_item(user_id, "common", "rare")

        return {
            "success": True,
            "crime_name": body.crime_name,
            "flavor": CRIME_FLAVOR.get(body.crime_name, "Mission accomplie !"),
            "reward": reward,
            "karma_change": data["karma"],
            "xp": 150,
            "loot": loot,
            "weapon_message": weapon_msg or None,
            "flee_delay_minutes": ORDRE["flee_delay"] // 60,
        }

    prison_time = ordre.jail_for_bot_crime(body.crime_name)
    await database.update_field(user_id, "prison_until", now() + prison_time)
    await ordre.register_arrest(user_id, body.crime_name, "crime", prison_time)
    async with database.db_connection() as db:
        await db.execute(
            "INSERT INTO crime_log (user_id, crime_type, success, jail_time, timestamp) VALUES (?,?,0,?,?)",
            (user_id, body.crime_name, prison_time, now()),
        )
        await db.commit()
    caution = int((data["reward"][0] + data["reward"][1]) / 2 * BAIL_COST_RATIO)

    return {
        "success": False,
        "crime_name": body.crime_name,
        "flavor": random.choice(CRIME_FAILS),
        "prison_seconds": prison_time,
        "caution": caution,
        "lawyer_cost": LAWYER_COST,
        "weapon_message": weapon_msg or None,
    }


# ═══════════════════════════════════════════════════════════════════
#                          JUSTICE
# ═══════════════════════════════════════════════════════════════════

@justice_router.get("/status")
async def justice_status(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    prison_until = u.get("prison_until", 0)
    remaining = max(0, prison_until - now())
    has_judges = await justice_service.has_judges()
    file = await justice_service.my_file(user_id)
    karma = u.get("karma", 0)
    if karma >= 100:
        chance = 60
    elif karma >= 0:
        chance = 40
    elif karma >= -100:
        chance = 25
    else:
        chance = 10
    case = None
    available_lawyers = []
    if file:
        due = justice_service.effective_bail(file) if int(file.get("bail", 0) or 0) > 0 else 0
        case = {
            "id": int(file["id"]), "crime": file.get("crime") or "arrestation",
            "status": file["status"], "bail": int(file.get("bail", 0) or 0),
            "effective_bail": due, "can_pay_bail": due > 0 and u["balance"] >= due,
            "lawyer_id": file.get("lawyer_id"), "lawyer_name": file.get("lawyer_name"),
            "plead": int(file.get("plead", 0) or 0),
        }
        if not case["lawyer_id"]:
            available_lawyers = [
                {"user_id": int(lawyer["user_id"]),
                 "name": lawyer.get("full_name") or f"Avocat {lawyer['user_id']}"}
                for lawyer in await justice_service.list_lawyers(on_duty_only=True)
            ]

    if remaining <= 0 and not case:
        return {"in_prison": False, "has_judges": has_judges, "case": None,
                "available_lawyers": [], "balance": int(u["balance"])}

    caution = int(remaining / 3600 * 5_000)
    return {
        "in_prison": remaining > 0, "has_judges": has_judges, "case": case,
        "available_lawyers": available_lawyers,
        "seconds_left": remaining, "caution": caution,
        "can_pay_caution": u["balance"] >= caution,
        "tribunal_acquit_chance_pct": chance,
        "lawyer_cost": LAWYER_COST,
        "can_afford_lawyer": u["balance"] >= LAWYER_COST,
        "balance": int(u["balance"]),
    }


async def _require_no_judges():
    if await justice_service.has_judges():
        raise HTTPException(status_code=409,
                            detail="Un juge exerce : utilise ton dossier dans le parcours Justice.")


@justice_router.post("/hearing")
async def request_case_hearing(user_id: int = Depends(require_character_complete)):
    ok, message = await justice_service.request_hearing(user_id)
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    return {"requested": True, "message": message}


@justice_router.post("/bail")
async def pay_judicial_bail(user_id: int = Depends(require_character_complete)):
    ok, message = await justice_service.pay_bail(user_id)
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    return {"paid": True, "message": message}


class HireLawyerIn(BaseModel):
    lawyer_id: int


@justice_router.post("/hire-lawyer")
async def hire_case_lawyer(body: HireLawyerIn, user_id: int = Depends(require_character_complete)):
    ok, message = await justice_service.hire_lawyer(user_id, body.lawyer_id)
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    return {"hired": body.lawyer_id, "message": message}


@justice_router.post("/caution")
async def pay_caution(user_id: int = Depends(require_character_complete)):
    await _require_no_judges()
    u = await database.get_user(user_id)
    if u.get("prison_until", 0) <= now():
        raise HTTPException(status_code=422, detail="Tu n'es pas en prison !")
    remaining = u["prison_until"] - now()
    caution = int(remaining / 3600 * 5_000)
    if u["balance"] < caution:
        raise HTTPException(status_code=422, detail=f"Fonds insuffisants. Caution : {caution}")
    await database.update_balance(user_id, -caution, sink="amendes")
    await database.update_field(user_id, "prison_until", 0)
    return {"freed": True, "caution_paid": caution}


@justice_router.post("/tribunal")
async def go_to_tribunal(user_id: int = Depends(require_character_complete)):
    await _require_no_judges()
    u = await database.get_user(user_id)
    if u.get("prison_until", 0) <= now():
        raise HTTPException(status_code=422, detail="Tu n'es pas en prison !")
    remaining = u["prison_until"] - now()
    karma = u.get("karma", 0)
    if karma >= 100:
        acquit_chance = 0.60
    elif karma >= 0:
        acquit_chance = 0.40
    elif karma >= -100:
        acquit_chance = 0.25
    else:
        acquit_chance = 0.10

    roll = random.random()
    if roll < acquit_chance:
        await database.update_field(user_id, "prison_until", 0)
        await database.increment_field(user_id, "karma", 5)
        return {"verdict": "acquitted", "karma_change": 5}
    if roll < acquit_chance + 0.3:
        new_remaining = remaining // 2
        await database.update_field(user_id, "prison_until", now() + new_remaining)
        return {"verdict": "reduced", "new_seconds_left": new_remaining}

    extra = random.randint(1, 3) * 3600
    fine = random.randint(10_000, 100_000)
    await database.update_field(user_id, "prison_until", u["prison_until"] + extra)
    if u["balance"] >= fine:
        await database.update_balance(user_id, -fine, sink="amendes")
    await database.increment_field(user_id, "karma", -10)
    return {"verdict": "convicted", "extra_seconds": extra, "fine": fine, "karma_change": -10}


@justice_router.post("/lawyer")
async def hire_lawyer(user_id: int = Depends(require_character_complete)):
    await _require_no_judges()
    u = await database.get_user(user_id)
    if u.get("prison_until", 0) <= now():
        raise HTTPException(status_code=422, detail="Tu n'es pas en prison !")
    if u["balance"] < LAWYER_COST:
        raise HTTPException(status_code=422, detail=f"Fonds insuffisants. Coût : {LAWYER_COST}")
    await database.update_balance(user_id, -LAWYER_COST, sink="justice")
    remaining = u["prison_until"] - now()

    if random.random() < 0.70:
        new_remaining = remaining // 3
        await database.update_field(user_id, "prison_until", now() + new_remaining)
        return {"won": True, "new_seconds_left": new_remaining, "cost": LAWYER_COST}

    return {"won": False, "seconds_left": remaining, "cost": LAWYER_COST}


# ═══════════════════════════════════════════════════════════════════
#     PERSONNEL JUDICIAIRE — juge / avocat (outils de la faction Justice)
# ═══════════════════════════════════════════════════════════════════
# Réutilise exactement utils/justice.py, le même service que le bot (handlers/justice.py) :
# mêmes contrôles de poste/service, mêmes plafonds (config.JUSTICE), mêmes transactions et
# notifications. Rien n'est recalculé ici — seule la présentation JSON change.

def _file_out(f: dict) -> dict:
    return {
        "id": int(f["id"]),
        "suspect_id": int(f["suspect_id"]),
        "suspect_name": f.get("suspect_name") or f"Joueur #{f['suspect_id']}",
        "crime": f.get("crime") or "arrestation",
        "status": f["status"],
        "bail": int(f.get("bail", 0) or 0),
        "effective_bail": justice_service.effective_bail(f),
        "plead": int(f.get("plead", 0) or 0),
        "lawyer_id": f.get("lawyer_id"),
        "lawyer_name": f.get("lawyer_name"),
        "jail_secs": int(f.get("jail_secs", 0) or 0),
        "created_at": int(f.get("created_at", 0) or 0),
    }


@justice_router.get("/staff")
async def justice_staff_status(user_id: int = Depends(require_character_complete)):
    st = await justice_service.staff(user_id)
    return {
        "post": st["post"] if st else None,
        "on_duty": bool(st and st["on_duty"]),
        "limits": {
            "bail_max": JUSTICE["bail_max"],
            "fine_max": JUSTICE["fine_max"],
            "sentence_max_seconds": JUSTICE["sentence_max"],
        },
    }


@justice_router.get("/cases")
async def judge_case_list(limit: int = 20, user_id: int = Depends(require_character_complete)):
    _, err = await justice_service.judge_check(user_id)
    if err:
        raise HTTPException(status_code=403, detail=err)
    files = await justice_service.list_files(limit=min(max(limit, 1), 50))
    return {"cases": [_file_out(f) for f in files]}


@justice_router.get("/my-clients")
async def lawyer_client_list(limit: int = 20, user_id: int = Depends(require_character_complete)):
    _, err = await justice_service.lawyer_check(user_id)
    if err:
        raise HTTPException(status_code=403, detail=err)
    files = await justice_service.list_files(limit=min(max(limit, 1), 50), lawyer_id=user_id)
    return {"cases": [_file_out(f) for f in files]}


class PleadIn(BaseModel):
    file_id: int


@justice_router.post("/plead")
async def lawyer_plead(body: PleadIn, user_id: int = Depends(require_character_complete)):
    ok, message = await justice_service.plead(user_id, body.file_id)
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    return {"pleaded": True, "message": message}


class SetBailIn(BaseModel):
    file_id: int
    amount: int


@justice_router.post("/set-bail")
async def judge_set_bail(body: SetBailIn, user_id: int = Depends(require_character_complete)):
    ok, message = await justice_service.set_bail(user_id, body.file_id, body.amount)
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    return {"set": True, "message": message}


class VerdictIn(BaseModel):
    file_id: int
    verdict: str  # "acquit" | "amende" | "prison"
    amount: int = 0


@justice_router.post("/verdict")
async def judge_render_verdict(body: VerdictIn, user_id: int = Depends(require_character_complete)):
    if body.verdict not in ("acquit", "amende", "prison"):
        raise HTTPException(status_code=400, detail="Verdict inconnu.")
    ok, message = await justice_service.judge_file(user_id, body.file_id, body.verdict, body.amount)
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    return {"judged": True, "message": message}


class WarrantIn(BaseModel):
    suspect_id: int
    reason: str


@justice_router.post("/warrant")
async def judge_issue_warrant(body: WarrantIn, user_id: int = Depends(require_character_complete)):
    reason = body.reason.strip()
    if not reason:
        raise HTTPException(status_code=422, detail="Un motif est requis.")
    ok, message = await justice_service.issue_warrant(user_id, body.suspect_id, reason[:80])
    if not ok:
        raise HTTPException(status_code=422, detail=message)
    return {"issued": True, "message": message}
