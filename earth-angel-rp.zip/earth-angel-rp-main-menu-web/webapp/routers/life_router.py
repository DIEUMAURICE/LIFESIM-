"""webapp/routers/life_router.py — Vie quotidienne (handlers/life.py) :
état vital, dormir, gym, repas, journal de vie, routine recommandée.

Mêmes règles que le bot : coûts, gains, blocages (prison/hôpital/faim), XP, compétence Force
au gym. Le seul écart assumé : le mini-jeu « bouchées » du repas est remplacé par le score
MEAL_FINISH_SCORE du bot lui-même (un repas qui va à son terme sans minigame = score normal),
ce n'est pas une valeur inventée pour la webapp.
"""
from __future__ import annotations

import random

import aiosqlite
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

import database
from config import (
    DAILY_COOLDOWN, GYM_COST, MEAL_CATEGORIES, MEAL_FINISH_SCORE, MEAL_LEGACY,
    MEALS, NOT_HUNGRY_AT, WORK_COOLDOWN,
)
from database import add_life_journal, db_connection, update_balance, update_field, upgrade_skill
from handlers.life import _eat_blocker, apply_meal, eat_meal, pay_meal
from utils.cooldowns import cooldown_left, release_cooldown
from utils.helpers import fmt_duration, now
from utils.vip import add_xp
from utils.decorators import cooldown_problem, free_problem
from webapp.deps import require_character_complete

router = APIRouter(prefix="/api/life", tags=["life"])
GYM_COOLDOWN = 12 * 60 * 60


def _status_label(val: int) -> str:
    if val >= 80:
        return "Excellent"
    if val >= 60:
        return "Bon"
    if val >= 40:
        return "Moyen"
    if val >= 20:
        return "Mauvais"
    return "Critique"


@router.get("/status")
async def status(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    t = now()
    gym_seconds_left = await cooldown_left(user_id, "gym_last", GYM_COOLDOWN)
    fields = ("health", "energy", "happiness", "hunger", "stress")
    vitals = {f: {"value": u.get(f, 100), "label": _status_label(u.get(f, 100) if f != "stress" else 100 - u.get(f, 0))} for f in fields}
    return {
        "vitals": vitals,
        "hospital_until": u.get("hospital_until", 0),
        "hospital_seconds_left": max(0, u.get("hospital_until", 0) - t),
        "prison_until": u.get("prison_until", 0),
        "prison_seconds_left": max(0, u.get("prison_until", 0) - t),
        "gym_seconds_left": gym_seconds_left,
    }


@router.post("/sleep")
async def sleep(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    if u.get("hospital_until", 0) > now():
        raise HTTPException(status_code=422, detail=f"🏥 Tu es hospitalisé pour encore {fmt_duration(u['hospital_until'] - now())}.")
    if u["energy"] >= 100:
        raise HTTPException(status_code=422, detail="🛌 Tu n'as pas besoin de dormir, tu es en pleine forme !")

    gain = random.randint(20, 45)
    new_energy = min(100, u["energy"] + gain)
    await update_field(user_id, "energy", new_energy)
    return {"energy_before": u["energy"], "energy_after": new_energy, "gain": gain}


@router.post("/gym")
async def gym(user_id: int = Depends(require_character_complete)):
    # Reproduit l'ordre du handler bot : statut libre, puis réservation atomique
    # du cooldown (qui s'applique aussi si le joueur échoue aux préconditions).
    blocked = await free_problem(user_id, "handlers.health")
    if blocked:
        raise HTTPException(status_code=422, detail=blocked)
    cooldown_message, cooldown_claimed = await cooldown_problem(
        user_id,
        "gym_last",
        GYM_COOLDOWN,
        "⏳ Tu es fatigué de la salle. Reviens dans {remaining}.",
    )
    if cooldown_message:
        raise HTTPException(status_code=422, detail=cooldown_message)

    try:
        u = await database.get_user(user_id)
    except Exception:
        if cooldown_claimed:
            await release_cooldown(user_id, "gym_last")
        raise
    if u.get("hospital_until", 0) > now():
        raise HTTPException(status_code=422, detail=f"🏥 Tu es hospitalisé pour encore {fmt_duration(u['hospital_until'] - now())}.")
    if u["balance"] < GYM_COST:
        raise HTTPException(status_code=422, detail=f"❌ La salle de sport coûte {GYM_COST:,} €A.")
    if u["energy"] < 20:
        raise HTTPException(status_code=422, detail="😴 Tu es trop fatigué(e) pour faire du sport !")
    if u["hunger"] < 10:
        raise HTTPException(status_code=422, detail="🍽️ Tu as trop faim pour faire du sport ! Mange d'abord.")

    try:
        await update_balance(user_id, -GYM_COST, sink="loisirs")

        energy_cost = random.randint(25, 35)
        health_gain = random.randint(5, 15)
        happiness_gain = random.randint(5, 15)
        stress_loss = random.randint(10, 20)
        hunger_loss = random.randint(10, 20)

        force_boost = random.random() < 0.3
        if force_boost:
            await upgrade_skill(user_id, "Force")

        new_energy = max(0, u["energy"] - energy_cost)
        new_health = min(100, u["health"] + health_gain)
        new_happiness = min(100, u["happiness"] + happiness_gain)
        new_stress = max(0, u["stress"] - stress_loss)
        new_hunger = max(0, u["hunger"] - hunger_loss)

        await update_field(user_id, "energy", new_energy)
        await update_field(user_id, "health", new_health)
        await update_field(user_id, "happiness", new_happiness)
        await update_field(user_id, "stress", new_stress)
        await update_field(user_id, "hunger", new_hunger)

        xp_gain = 80
        await add_xp(user_id, xp_gain)
        await update_field(user_id, "gym_last", now())

        return {
            "cost": GYM_COST,
            "energy_cost": energy_cost, "energy_left": new_energy,
            "health_gain": health_gain, "health_left": new_health,
            "happiness_gain": happiness_gain, "happiness_left": new_happiness,
            "stress_loss": stress_loss, "stress_left": new_stress,
            "hunger_loss": hunger_loss, "hunger_left": new_hunger,
            "xp": xp_gain,
            "force_boost": force_boost,
        }
    except Exception:
        # Une erreur technique ne doit pas enfermer le joueur dans le cooldown.
        if cooldown_claimed:
            await release_cooldown(user_id, "gym_last")
        raise


@router.get("/meals")
async def meals_catalog(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    categories = [
        {"key": k, "emoji": c["emoji"], "name": c["name"], "desc": c["desc"]}
        for k, c in MEAL_CATEGORIES.items()
    ]
    meals = [
        {
            "key": key, "name": m["name"], "emoji": m["emoji"], "stars": m["stars"],
            "cost": m["cost"], "category": m["cat"],
            "hunger": m["hunger"], "energy": m["energy"], "health": m["health"],
            "happiness": m["happiness"], "stress": m["stress"],
            "blocked": _eat_blocker(u, m),
        }
        for key, m in MEALS.items()
    ]
    return {"categories": categories, "meals": meals, "not_hungry_at": NOT_HUNGRY_AT}


class EatIn(BaseModel):
    meal_key: str


@router.post("/eat")
async def eat(body: EatIn, user_id: int = Depends(require_character_complete)):
    ok, msg = await eat_meal(user_id, body.meal_key, MEAL_FINISH_SCORE)
    if not ok:
        raise HTTPException(status_code=422, detail=msg)
    u = await database.get_user(user_id)
    return {"message": msg, "hunger": u["hunger"], "energy": u["energy"], "health": u["health"],
            "happiness": u["happiness"], "stress": u["stress"]}


@router.get("/journal")
async def journal(user_id: int = Depends(require_character_complete)):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT category, summary, severity, created_at FROM life_journal "
            "WHERE user_id=? ORDER BY created_at DESC LIMIT 15",
            (user_id,),
        ) as cur:
            rows = await cur.fetchall()
    t = now()
    return {
        "entries": [
            {
                "category": r["category"], "summary": r["summary"], "severity": r["severity"],
                "seconds_ago": t - r["created_at"],
            }
            for r in rows
        ]
    }


@router.get("/routine")
async def routine(user_id: int = Depends(require_character_complete)):
    u = await database.get_user(user_id)
    actions = []

    if u.get("hunger", 100) < 40:
        actions.append({"action": "eat", "label": "Manger", "urgent": True, "reason": "ta faim est critique"})
    elif u.get("hunger", 100) < 60:
        actions.append({"action": "eat", "label": "Manger", "urgent": False, "reason": "restaure ta faim"})

    if u.get("energy", 100) < 30:
        actions.append({"action": "sleep", "label": "Dormir", "urgent": True, "reason": "tu es épuisé(e)"})
    elif u.get("energy", 100) < 50:
        actions.append({"action": "sleep", "label": "Dormir", "urgent": False, "reason": "regagne de l'énergie"})

    if u.get("health", 100) < 50:
        actions.append({"action": "hospital", "label": "Hôpital", "urgent": True, "reason": "consulte vite"})
    if u.get("stress", 0) > 60:
        actions.append({"action": "gym", "label": "Gym", "urgent": False, "reason": "baisse ton stress"})

    if await cooldown_left(user_id, "daily_last", DAILY_COOLDOWN) == 0:
        actions.append({"action": "daily", "label": "Quotidien", "urgent": False, "reason": "ton bonus journalier est dispo"})
    if await cooldown_left(user_id, "freelance_last", WORK_COOLDOWN) == 0:
        actions.append({"action": "work", "label": "Travailler", "urgent": False, "reason": "ton job peut te payer"})

    return {"actions": actions[:5]}
