"""webapp/auth.py — Authentification partagée par la mini app Telegram et le site web.

Deux portes d'entrée, UN SEUL format de session ensuite :

  • Mini app Telegram : on vérifie la signature HMAC du `initData` fourni par le client
    Telegram WebApp (garantit que la requête vient bien de Telegram, pour ce bot précis) et on
    récupère l'ID Telegram de l'utilisateur → c'est le `user_id` déjà utilisé par le bot.

  • Site web : connexion Google (OAuth2 "Authorization Code"). Le `sub` Google est mappé à un
    user_id de jeu (négatif, jamais en collision avec un ID Telegram) via
    `database.get_or_create_web_account`.

Dans les deux cas, on émet ensuite le MÊME jeton de session (JWT) que les deux interfaces
utilisent pour parler à l'API. Le reste du code (routers, front-end) ne sait même pas d'où
vient le joueur.
"""
from __future__ import annotations

import hashlib
import hmac
import time
import urllib.parse
from dataclasses import dataclass

import httpx
import jwt
from fastapi import HTTPException, Header

from config import (
    BOT_TOKEN, JWT_ALGORITHM, JWT_EXPIRE_DAYS, JWT_SECRET,
    GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, PUBLIC_API_BASE_URL,
)

GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v3/userinfo"


def _require_jwt_secret() -> None:
    if not JWT_SECRET:
        raise HTTPException(
            status_code=500,
            detail="JWT_SECRET n'est pas configuré côté serveur (voir .env).",
        )


# ─────────────────────────── Session JWT (commune) ───────────────────────────

def issue_session_token(user_id: int, source: str) -> str:
    """source: 'telegram' ou 'google' — stocké dans le jeton, utile pour l'UI / les logs."""
    _require_jwt_secret()
    now = int(time.time())
    payload = {
        "sub": str(user_id),
        "src": source,
        "iat": now,
        "exp": now + JWT_EXPIRE_DAYS * 86400,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_session_token_full(token: str) -> dict:
    """Comme decode_session_token, mais renvoie tout le payload (dont 'src': 'telegram'/'google')."""
    _require_jwt_secret()
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Session expirée, reconnecte-toi.")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Session invalide.")


def decode_session_token(token: str) -> int:
    return int(decode_session_token_full(token)["sub"])


async def current_user_id(authorization: str | None = Header(default=None)) -> int:
    """Dépendance FastAPI : exige `Authorization: Bearer <jwt>`."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Non connecté.")
    token = authorization.split(" ", 1)[1].strip()
    return decode_session_token(token)


# ─────────────────────────── Telegram Mini App ───────────────────────────

def verify_telegram_init_data(init_data: str, max_age_seconds: int = 86400) -> dict:
    """Vérifie la signature HMAC-SHA256 d'un `initData` Telegram WebApp.

    Algorithme officiel : https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
    secret_key = HMAC_SHA256("WebAppData", BOT_TOKEN)
    hash attendu = HMAC_SHA256(secret_key, data_check_string)
    """
    if not BOT_TOKEN or BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        raise HTTPException(status_code=500, detail="BOT_TOKEN non configuré côté serveur.")
    if not init_data:
        raise HTTPException(status_code=401, detail="initData manquant.")

    parsed = dict(urllib.parse.parse_qsl(init_data, strict_parsing=True))
    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise HTTPException(status_code=401, detail="initData invalide (hash manquant).")

    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    expected_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(expected_hash, received_hash):
        raise HTTPException(status_code=401, detail="initData invalide (signature).")

    auth_date = int(parsed.get("auth_date", "0"))
    if max_age_seconds and (int(time.time()) - auth_date) > max_age_seconds:
        raise HTTPException(status_code=401, detail="initData expiré, relance la mini app.")

    import json
    user = json.loads(parsed["user"]) if "user" in parsed else None
    if not user or "id" not in user:
        raise HTTPException(status_code=401, detail="initData invalide (utilisateur manquant).")
    return user


# ─────────────────────────── Connexion Google (site web) ───────────────────────────

def google_login_url(state: str) -> str:
    if not GOOGLE_CLIENT_ID:
        raise HTTPException(status_code=500, detail="GOOGLE_CLIENT_ID non configuré côté serveur.")
    params = {
        "client_id": GOOGLE_CLIENT_ID,
        "redirect_uri": f"{PUBLIC_API_BASE_URL}/auth/google/callback",
        "response_type": "code",
        "scope": "openid email profile",
        "state": state,
        "prompt": "select_account",
    }
    return f"{GOOGLE_AUTH_URL}?{urllib.parse.urlencode(params)}"


@dataclass
class GoogleProfile:
    sub: str
    email: str
    name: str


async def exchange_google_code(code: str) -> GoogleProfile:
    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        raise HTTPException(status_code=500, detail="Connexion Google non configurée côté serveur.")
    async with httpx.AsyncClient(timeout=10) as client:
        token_resp = await client.post(GOOGLE_TOKEN_URL, data={
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "code": code,
            "grant_type": "authorization_code",
            "redirect_uri": f"{PUBLIC_API_BASE_URL}/auth/google/callback",
        })
        if token_resp.status_code != 200:
            raise HTTPException(status_code=401, detail="Échec de la connexion Google (token).")
        access_token = token_resp.json().get("access_token")

        info_resp = await client.get(
            GOOGLE_USERINFO_URL, headers={"Authorization": f"Bearer {access_token}"}
        )
        if info_resp.status_code != 200:
            raise HTTPException(status_code=401, detail="Échec de la connexion Google (profil).")
        info = info_resp.json()

    return GoogleProfile(sub=info["sub"], email=info.get("email", ""), name=info.get("name", ""))
