# handlers/weapons.py — 🔫 Marché noir (armes), arsenal personnel, chambres d'armes (100 % boutons, préfixe `wp:`)
from utils.swallow import swallowed
import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from config import WEAPONS, WEAPON_MAX_MAGS, ARMS_CRAFT_ROLES, ARMS_DELIVER_ROLES, WEAPON_REQUIRED_CRIMES, ARMS
from database import get_user, now
from utils import ordre, weapons
from utils.decorators import require_registered, require_free
from utils.helpers import send_or_edit as _send

logger = logging.getLogger(__name__)
CB = "wp:"


def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text, callback_data=data)


# ─────────────────────────────────────────────────────────────────────────────
#  Marché noir : armes uniquement
# ─────────────────────────────────────────────────────────────────────────────
async def show_shop(update: Update, uid: int, note: str = "") -> None:
    u = await get_user(uid)
    mine = {w["key"]: w for w in await weapons.list_weapons(uid)}
    lines = ["🕶️ <b>Marché noir</b>", "<i>Des armes, rien d'autre. Munitions limitées.</i>", ""]
    if note:
        lines = [note, ""] + lines
    lines.append(f"💵 Liquide : <b>{u['balance']:,}</b>")
    rows = []
    for k, w in WEAPONS.items():
        if not w["market"]:
            continue
        have = mine.get(k)
        tag = f" · tu as {have['ammo']} munitions" if have else ""
        lines.append(f"{w['emoji']} <b>{w['name']}</b> — {w['price']:,} · {w['mag']} munitions · "
                     f"+{int(w['bonus'] * 100)} pts de chance{tag}")
        label = f"{w['emoji']} {'Racheter' if have else 'Acheter'} {w['name']} ({w['price']:,})"
        rows.append([_btn(label, CB + f"buy:{k}")])
        if have:
            rows.append([_btn(f"🔶 +{w['mag']} munitions ({w['ammo_price'] * w['mag']:,})", CB + f"ammo:{k}")])
    lines += ["", f"<i>Racheter une arme ajoute un chargeur (max {WEAPON_MAX_MAGS}). "
                  f"Il faut une arme à feu pour : {', '.join(WEAPON_REQUIRED_CRIMES)} et l'attaque mortelle.</i>"]
    rows.append([_btn("🎒 Mes armes", CB + "inv"), _btn("⬅️ Menu", "hub:societe:0")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Arsenal personnel
# ─────────────────────────────────────────────────────────────────────────────
async def show_inventory(update: Update, uid: int, note: str = "") -> None:
    ws = await weapons.list_weapons(uid)
    lines = ["🎒 <b>Mes armes</b>", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    if not ws:
        lines.append("Tu n'as aucune arme. 🕶️ Marché noir ou (agents) 🛠️ chambre d'armes.")
    for w in ws:
        src = {"noir": "marché noir", "armee": "dotation armée", "police": "dotation police"}.get(w["source"], w["source"])
        lines.append(f"{'✅ ' if w['equipped'] else ''}{w['emoji']} <b>{w['name']}</b> — "
                     f"<b>{w['ammo']}</b>/{weapons.max_ammo(w['key'])} munitions · {src}")
        if w["equipped"]:
            rows.append([_btn(f"🎒 Ranger {w['name']}", CB + "uneq")])
        else:
            rows.append([_btn(f"✅ Équiper {w['name']}", CB + f"eq:{w['key']}")])
        if w["source"] in ("armee", "police"):
            rows.append([_btn(f"🔶 Recharger {w['name']}", CB + f"rld:{w['key']}"),
                         _btn(f"↩️ Rendre {w['name']}", CB + f"ret:{w['key']}")])
    lines += ["", "<i>L'arme équipée augmente tes chances de crime, mais chaque usage consomme des munitions.</i>"]
    rows.append([_btn("🕶️ Marché noir", CB + "shop"), _btn("⬅️ Ordre public", "ord:home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Chambre d'armes (armée & police)
# ─────────────────────────────────────────────────────────────────────────────
async def show_armory(update: Update, uid: int, note: str = "") -> None:
    st = await ordre.get_staff(uid)
    if not st or st["faction"] not in weapons.ARMORY_FACTIONS:
        await _send(update, "❌ Réservé aux membres de l'armée et de la police.",
                    InlineKeyboardMarkup([[_btn("⬅️ Retour", "ord:home")]]))
        return
    faction = st["faction"]
    stock = await weapons.armory_stock(faction)
    can_use = st["level"] >= 1
    lines = [f"🛠️ <b>Chambre d'armes — {st['faction_name']}</b>", ""]
    if note:
        lines = [note, ""] + lines
    if faction == "police":
        lines.append("<i>Alimentée uniquement par les livraisons de l'armée.</i>")
    rows = []
    craft_ok = faction == "armee" and st["role"] in ARMS_CRAFT_ROLES
    deliver_ok = faction == "armee" and st["role"] in ARMS_DELIVER_ROLES
    for w in stock:
        lines.append(f"{w['emoji']} <b>{w['name']}</b> : {w['qty']} en chambre · {w['rounds']} munitions")
        line = []
        if can_use and w["qty"] > 0:
            line.append(_btn(f"📥 Prendre {w['name']}", CB + f"take:{w['key']}"))
        if craft_ok:
            line.append(_btn(f"🛠️ Fabriquer ({w['craft']:,})", CB + f"cr:{w['key']}"))
        if line:
            rows.append(line)
        line2 = []
        if craft_ok:
            line2.append(_btn(f"🔶 Munitions ({max(1, int(w['craft'] * ARMS['ammo_craft_ratio'])):,})", CB + f"cra:{w['key']}"))
        if deliver_ok and w["qty"] > 0:
            line2.append(_btn(f"🚓 Livrer à la police", CB + f"dl:{w['key']}"))
        if line2:
            rows.append(line2)
    rows.append([_btn("🎒 Mes armes", CB + "inv"), _btn("⬅️ Ordre public", "ord:home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Commandes & callbacks
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_noir(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """🕶️ Marché noir : armes uniquement."""
    await show_shop(update, update.effective_user.id)


@require_registered
async def cmd_armes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_inventory(update, update.effective_user.id)


@require_registered
async def cmd_armurerie(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_armory(update, update.effective_user.id)


async def wp_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    parts = (q.data or "").split(":")
    action = parts[1] if len(parts) > 1 else "inv"
    arg = parts[2] if len(parts) > 2 else ""
    try:
        u = await get_user(uid)
        if not u.get("registered") or u.get("banned"):
            await q.answer("Termine d'abord /start.", show_alert=True)
            return
        await q.answer()
        if arg and arg not in WEAPONS:
            arg = ""
        restrained = await ordre.restraint_reason(uid)
        if action in ("shop", "buy", "ammo") and (u.get("prison_until", 0) > now() or restrained):
            await show_inventory(update, uid, "⛓️ Impossible de trafiquer maintenant.")
            return
        if action == "shop":
            await show_shop(update, uid)
        elif action == "buy":
            ok, msg = await weapons.buy_weapon(uid, arg)
            await show_shop(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "ammo":
            ok, msg = await weapons.buy_ammo(uid, arg)
            await show_shop(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "inv":
            await show_inventory(update, uid)
        elif action == "eq":
            ok, msg = await weapons.equip(uid, arg)
            await show_inventory(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "uneq":
            ok, msg = await weapons.equip(uid, None)
            await show_inventory(update, uid, msg)
        elif action == "arm":
            await show_armory(update, uid)
        elif action == "take":
            ok, msg = await weapons.take_weapon(uid, arg)
            await show_armory(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "rld":
            ok, msg = await weapons.reload_weapon(uid, arg)
            await show_inventory(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "ret":
            ok, msg = await weapons.return_weapon(uid, arg)
            await show_inventory(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "cr":
            ok, msg = await weapons.craft_weapon(uid, arg)
            await show_armory(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "cra":
            ok, msg = await weapons.craft_ammo(uid, arg)
            await show_armory(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "dl":
            ok, msg = await weapons.deliver_to_police(uid, arg, 1)
            await show_armory(update, uid, ("✅ " if ok else "❌ ") + msg)
        else:
            await show_inventory(update, uid)
    except Exception:
        logger.exception("wp_callback : %s", q.data)
        try:
            await q.message.reply_text("⚠️ Une erreur est survenue, réessaie depuis le menu.")
        except Exception:
            swallowed('handlers/weapons.py')
