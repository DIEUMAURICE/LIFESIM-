# handlers/campaigns.py — 📣 Droits admin du LEAD INFLUENCEURS (charte GAME FRENCH, article 14)
"""
Le Lead Influenceurs n'a AUCUN pouvoir de modération ni d'ordre sur le staff. Son cadre : les campagnes
(communication vers les joueurs). Règle de la charte : toute campagne est planifiée avec le Lead Staff Global
AVANT d'être diffusée dans le jeu.

  /campagne titre | message       → Lead Influenceurs : soumet une campagne (statut « en attente »)
  /campagnes                      → Lead Influenceurs : ses campagnes · Lead Staff Global+ : celles à traiter
  /campagne_valider id            → Lead Staff Global+ : valide ET diffuse à tous les joueurs
  /campagne_refuser id motif      → Lead Staff Global+ : refuse ; le motif est envoyé tel quel à l'auteur
"""
from __future__ import annotations

import logging
import time

import aiosqlite
from telegram import Update
from telegram.ext import CommandHandler, ContextTypes

from config import CAMPAIGN_MAX_PENDING, CAMPAIGN_MIN_GAP_HOURS, role_level
from database import add_notification, db_connection, log_admin_action
from utils.aesthetics import card
from utils.decorators import get_user_role_async, lead_staff_only
from utils.helpers import escape_html
from utils.staff import role_holders

logger = logging.getLogger(__name__)
TITLE_MAX, MSG_MAX = 50, 500


async def _is_influenceurs(user_id: int) -> bool:
    return await get_user_role_async(user_id) in ("LEAD_INFLUENCEURS", "LEAD_PRINCIPAL")


async def _reviewers() -> list[int]:
    ids = set(await role_holders("LEAD_STAFF_GLOBAL"))
    from config import LEAD_PRINCIPAL_IDS, LEAD_STAFF_GLOBAL_IDS
    return sorted(ids | set(LEAD_STAFF_GLOBAL_IDS) | set(LEAD_PRINCIPAL_IDS))


async def cmd_campagne(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not await _is_influenceurs(uid):
        await update.message.reply_text("🚫 Réservé au Lead Influenceurs.")
        return
    raw = " ".join(context.args or [])
    if "|" not in raw:
        await update.message.reply_text("❌ Format : <code>/campagne titre | message</code>\n"
                                        "<i>Elle sera relue par le Lead Staff Global avant diffusion.</i>", parse_mode="HTML")
        return
    title, _, message = (p.strip() for p in raw.partition("|"))
    if len(title) < 3 or len(message) < 10:
        await update.message.reply_text("❌ Titre (3 caractères min.) et message (10 caractères min.) requis.")
        return
    title, message = title[:TITLE_MAX], message[:MSG_MAX]
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM staff_campaigns WHERE author_id=? AND status='pending'", (uid,)) as cur:
            pending = (await cur.fetchone())[0]
        if pending >= CAMPAIGN_MAX_PENDING:
            await update.message.reply_text(f"❌ Tu as déjà {pending} campagne(s) en attente de validation.")
            return
        cur = await db.execute("INSERT INTO staff_campaigns(author_id, title, message, created_at) VALUES(?,?,?,?)",
                               (uid, title, message, int(time.time())))
        cid = cur.lastrowid
        await db.commit()
    await log_admin_action(uid, "campagne_soumise", 0, f"#{cid} {title}")
    for r in await _reviewers():
        await add_notification(r, f"📣 Campagne #{cid} à valider : « {title} ». /campagnes puis /campagne_valider {cid}")
    await update.message.reply_text(f"✅ Campagne <b>#{cid}</b> envoyée au Lead Staff Global pour validation.", parse_mode="HTML")


async def cmd_campagnes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    role = await get_user_role_async(uid)
    reviewer = role_level(role) >= role_level("LEAD_STAFF_GLOBAL") and role not in ("LEAD_STUDIO", "LEAD_INFLUENCEURS")
    if not reviewer and not await _is_influenceurs(uid):
        await update.message.reply_text("🚫 Réservé au Lead Influenceurs et au Lead Staff Global.")
        return
    async with db_connection(row_factory=aiosqlite.Row) as db:
        if reviewer:
            q, args = "SELECT * FROM staff_campaigns WHERE status='pending' ORDER BY created_at LIMIT 10", ()
        else:
            q, args = "SELECT * FROM staff_campaigns WHERE author_id=? ORDER BY campaign_id DESC LIMIT 10", (uid,)
        async with db.execute(q, args) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
    icons = {"pending": "⏳ en attente", "approved": "✅ diffusée", "rejected": "❌ refusée"}
    body = []
    for r in rows:
        body.append(f"<b>#{r['campaign_id']}</b> {escape_html(r['title'])} — {icons.get(r['status'], r['status'])}")
        body.append(f"   {escape_html(r['message'])[:140]}")
        if r["status"] == "rejected" and r["reason"]:
            body.append(f"   📝 Motif : {escape_html(r['reason'])}")
    await update.message.reply_text(
        card("CAMPAGNES À TRAITER" if reviewer else "MES CAMPAGNES", body or ["<i>Aucune campagne.</i>"], icon="📣", style="thick"),
        parse_mode="HTML")


async def _load(cid_text: str):
    if not cid_text.isdigit():
        return None
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM staff_campaigns WHERE campaign_id=?", (int(cid_text),)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


@lead_staff_only
async def cmd_campagne_valider(update: Update, context: ContextTypes.DEFAULT_TYPE):
    actor = update.effective_user.id
    camp = await _load((context.args or [""])[0])
    if not camp:
        await update.message.reply_text("❌ Usage : <code>/campagne_valider id</code>", parse_mode="HTML")
        return
    if camp["status"] != "pending":
        await update.message.reply_text("❌ Cette campagne a déjà été traitée.")
        return
    t = int(time.time())
    async with db_connection() as db:
        async with db.execute("SELECT MAX(sent_at) FROM staff_campaigns WHERE status='approved'") as cur:
            last = (await cur.fetchone())[0] or 0
        if t - last < CAMPAIGN_MIN_GAP_HOURS * 3600:
            wait = (CAMPAIGN_MIN_GAP_HOURS * 3600 - (t - last)) // 60
            await update.message.reply_text(f"❌ Une campagne vient d'être diffusée : réessaie dans {wait} min "
                                            f"(un joueur ne doit pas être submergé).")
            return
        await db.execute("UPDATE staff_campaigns SET status='approved', reviewed_by=?, reviewed_at=?, sent_at=? "
                         "WHERE campaign_id=?", (actor, t, t, camp["campaign_id"]))
        await db.commit()
    from handlers.notifications import queue_broadcast_notification
    await queue_broadcast_notification(camp["title"], camp["message"], "info")
    await log_admin_action(actor, "campagne_validee", camp["author_id"], f"#{camp['campaign_id']} {camp['title']}")
    await add_notification(camp["author_id"], f"✅ Ta campagne #{camp['campaign_id']} « {camp['title']} » est validée et diffusée.")
    await update.message.reply_text(f"✅ Campagne <b>#{camp['campaign_id']}</b> diffusée à tous les joueurs.", parse_mode="HTML")


@lead_staff_only
async def cmd_campagne_refuser(update: Update, context: ContextTypes.DEFAULT_TYPE):
    actor = update.effective_user.id
    args = list(context.args or [])
    camp = await _load(args[0]) if args else None
    motif = " ".join(args[1:]).strip()
    if not camp or len(motif) < 3:
        await update.message.reply_text("❌ Usage : <code>/campagne_refuser id motif</code> (le motif est obligatoire "
                                        "et envoyé tel quel à l'auteur).", parse_mode="HTML")
        return
    if camp["status"] != "pending":
        await update.message.reply_text("❌ Cette campagne a déjà été traitée.")
        return
    motif = motif[:300]
    async with db_connection() as db:
        await db.execute("UPDATE staff_campaigns SET status='rejected', reviewed_by=?, reviewed_at=?, reason=? "
                         "WHERE campaign_id=?", (actor, int(time.time()), motif, camp["campaign_id"]))
        await db.commit()
    await log_admin_action(actor, "campagne_refusee", camp["author_id"], f"#{camp['campaign_id']} motif: {motif}")
    await add_notification(camp["author_id"], f"❌ Ta campagne #{camp['campaign_id']} « {camp['title']} » est refusée. "
                                              f"Motif : {escape_html(motif)}")
    await update.message.reply_text(f"✅ Campagne <b>#{camp['campaign_id']}</b> refusée, motif envoyé à l'auteur.", parse_mode="HTML")


def register(app) -> None:
    for name, fn in {"campagne": cmd_campagne, "campagnes": cmd_campagnes,
                     "campagne_valider": cmd_campagne_valider, "campagne_refuser": cmd_campagne_refuser}.items():
        app.add_handler(CommandHandler(name, fn))
