# handlers/arena.py
import random
import html
import asyncio
import aiosqlite
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import DB_PATH, get_user, update_balance, increment_field, now, add_notification, db_connection
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, parse_amount, get_level
from utils.vip import add_xp
from utils.arena_store import (
    accept_and_fund_match,
    create_match,
    decline_match,
    expire_arena_matches,
    get_match,
    refund_match,
    save_choice,
    settle_draw,
    settle_winner,
)

async def _with_names(match: dict | None) -> dict | None:
    """Les matchs stockés en base n'ont pas les noms : on les ajoute pour l'affichage du résultat."""
    if not match:
        return match
    for role in ("challenger", "target"):
        if not match.get(f"{role}_name"):
            u = await get_user(match[f"{role}_id"])
            match[f"{role}_name"] = (u or {}).get("full_name") or "Joueur"
    return match


logger = logging.getLogger(__name__)

# ─── Quiz en cours (temporaire, à migrer en DB plus tard) ───
active_quizzes = {}

# ─────────────────────────────────────────────────────────────────────────────
# Helper pour ajouter un item aléatoire
# ─────────────────────────────────────────────────────────────────────────────
async def add_random_item(user_id: int, min_rarity: str = "common", max_rarity: str = "legendary"):
    """Ajoute un item aléatoire à l'inventaire du joueur. Retourne le nom de l'item ou None."""
    rarity_order = ["common", "rare", "epic", "legendary"]
    min_idx = rarity_order.index(min_rarity)
    max_idx = rarity_order.index(max_rarity)
    possible = [r for r in rarity_order if min_idx <= rarity_order.index(r) <= max_idx]
    chosen_rarity = random.choice(possible)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT item_id, name, emoji, rarity FROM items WHERE rarity = ? ORDER BY RANDOM() LIMIT 1",
            (chosen_rarity,)
        ) as cur:
            item = await cur.fetchone()
        if not item:
            return None

        async with db.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?",
            (user_id, item["item_id"])
        ) as cur2:
            existing = await cur2.fetchone()
        if existing:
            await db.execute(
                "UPDATE inventory SET quantity = quantity + 1 WHERE user_id = ? AND item_id = ?",
                (user_id, item["item_id"])
            )
        else:
            await db.execute("""
                INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, item["item_id"], "loot", item["name"], 1, now()))
        await db.commit()
    return f"{item['emoji']} {item['name']} ({item['rarity']})"

# Jeux disponibles
PVP_GAMES = {
    "combat": {
        "name": "⚔️ Combat",
        "desc": "Combat 1v1 basé sur Force, Agilité et niveau",
        "min_bet": 500,
    },
    "pierre_papier_ciseaux": {
        "name": "✊ Pierre - Papier - Ciseaux",
        "desc": "Jeu classique, le gagnant remporte la mise",
        "min_bet": 100,
    },
    "pile_face": {
        "name": "🪙 Pile ou Face",
        "desc": "50/50, le gagnant remporte la mise x2",
        "min_bet": 100,
    },
    "des": {
        "name": "🎲 Dés",
        "desc": "Celui qui fait le plus grand nombre gagne",
        "min_bet": 200,
    },
    "course": {
        "name": "🏃 Course",
        "desc": "Course aléatoire, bonus de vitesse",
        "min_bet": 300,
    },
    "quiz": {
        "name": "❓ Quiz",
        "desc": "Question aléatoire, bonus d'intelligence",
        "min_bet": 500,
    }
}

def escape_html(text: str) -> str:
    return html.escape(str(text))

# ----------------------------------------------------------------------
# Commande /defier (avec persistance)
# ----------------------------------------------------------------------
@require_registered
@require_free
async def cmd_defier(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not update.message.reply_to_message:
        games_list = "\n".join([f"• <b>{g['name']}</b> : {g['desc']} (min {fmt(g['min_bet'])})" for g in PVP_GAMES.values()])
        await update.message.reply_text(
            f"🎮 <b>Défier un joueur</b>\n\n"
            f"Pour défier quelqu'un : Menu → 🎲 Loisirs → Arène.\n"
            f"<b>Jeux disponibles :</b>\n{games_list}\n\n"
            f"Ouvre l'action depuis le 🎮 Menu principal.",
            parse_mode="HTML"
        )
        return

    target = update.message.reply_to_message.from_user
    if target.id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas te défier toi-même !")
        return

    if not context.args or len(context.args) < 2:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 🎲 Loisirs → Arène."
            f"Jeux : {', '.join(PVP_GAMES.keys())}\n"
            f"Ouvre l'action depuis le 🎮 Menu principal."
        )
        return

    game_name = context.args[0].lower()
    if game_name not in PVP_GAMES:
        await update.message.reply_text(f"❌ Jeu inconnu. Jeux : {', '.join(PVP_GAMES.keys())}")
        return

    game = PVP_GAMES[game_name]
    amount = parse_amount(context.args[1], u["balance"])
    if not amount or amount < game["min_bet"]:
        await update.message.reply_text(f"❌ Mise minimale pour {game['name']} : {fmt(game['min_bet'])}")
        return
    if amount > u["balance"]:
        await update.message.reply_text(f"❌ Fonds insuffisants ! Solde : {fmt(u['balance'])}")
        return

    t_data = await get_user(target.id)
    if not t_data or not t_data.get("registered"):
        await update.message.reply_text("❌ Ce joueur n'est pas enregistré.")
        return
    if t_data.get("banned"):
        await update.message.reply_text("❌ Ce joueur est banni.")
        return

    # Création du match en base de données
    # ✅ Fix #16 : gestion des erreurs de validation / techniques
    try:
        challenge_id = await create_match(
            challenger_id=user.id,
            target_id=target.id,
            game=game_name,
            bet=amount,
            ttl=600,
        )
    except ValueError as e:
        await update.message.reply_text(f"❌ Défi impossible : {e}")
        return
    except Exception:
        logger.exception("Échec de create_match pour %s vs %s", user.id, target.id)
        await update.message.reply_text(
            "❌ Erreur technique lors de la création du défi. Réessaie."
        )
        return

    keyboard = [[
        InlineKeyboardButton("✅ Accepter", callback_data=f"challenge_accept|{challenge_id}"),
        InlineKeyboardButton("❌ Refuser", callback_data=f"challenge_refuse|{challenge_id}")
    ]]
    await update.message.reply_text(
        f"🎮 <b>DÉFI ENVOYÉ !</b>\n\n"
        f"👤 De : {escape_html(user.full_name)}\n"
        f"👤 Vers : {escape_html(target.full_name)}\n"
        f"🎲 Jeu : {escape_html(game['name'])}\n"
        f"💰 Mise : {escape_html(fmt(amount))}\n\n"
        f"<i>En attente de la réponse de {escape_html(target.full_name)}...</i>",
        parse_mode="HTML"
    )
    await context.bot.send_message(
        target.id,
        f"🎮 <b>NOUVEAU DÉFI !</b>\n\n"
        f"👤 <b>{escape_html(user.full_name)}</b> te défie à <b>{escape_html(game['name'])}</b> !\n"
        f"💰 Mise : {escape_html(fmt(amount))}\n\n"
        f"Souhaites-tu relever le défi ?",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="HTML"
    )

# ----------------------------------------------------------------------
# Callback de gestion des défis (avec persistance)
# ----------------------------------------------------------------------
async def challenge_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if "|" not in query.data:
        await query.edit_message_text("❌ Format invalide.")
        return

    action_text, match_id = query.data.split("|", 1)
    match = await get_match(match_id)
    if not match:
        await query.edit_message_text("❌ Défi introuvable.")
        return
    if query.from_user.id != match["target_id"]:
        await query.answer("Ce n'est pas ton défi.", show_alert=True)
        return

    if action_text == "challenge_refuse":
        success = await decline_match(match_id, query.from_user.id)
        await query.edit_message_text(
            "❌ Défi refusé." if success else "⚠️ Défi déjà traité."
        )
        return

    if action_text != "challenge_accept":
        await query.edit_message_text("❌ Action inconnue.")
        return

    # Acceptation et financement atomique
    match = await accept_and_fund_match(match_id, query.from_user.id)
    if not match:
        await query.edit_message_text(
            "❌ Défi expiré, déjà traité ou fonds insuffisants."
        )
        return

    challenger = await get_user(match["challenger_id"])
    target = await get_user(match["target_id"])
    challenge = {
        "match_id": match_id,
        "challenger_id": match["challenger_id"],
        "challenger_name": challenger.get("full_name", "Joueur"),
        "target_id": match["target_id"],
        "target_name": target.get("full_name", "Joueur"),
        "game": match["game"],
        "bet": match["bet"],
        "created_at": match["created_at"],
        "status": "accepted",
    }

    await query.edit_message_text(
        f"✅ Défi accepté. Pot sécurisé : {fmt(match['pot'])}."
    )

    try:
        if match["game"] == "combat":
            await start_combat_game(context, challenge)
        elif match["game"] == "pierre_papier_ciseaux":
            await start_rps_game(context, challenge)
        elif match["game"] == "pile_face":
            await start_coinflip_game(context, challenge)
        elif match["game"] == "des":
            await start_dice_game(context, challenge)
        elif match["game"] == "course":
            await start_race_game(context, challenge)
        elif match["game"] == "quiz":
            await start_quiz_game(context, challenge)
        else:
            raise ValueError("Jeu inconnu")
    except Exception:
        logger.exception("Échec du match %s", match_id)
        await refund_match(match_id, "cancelled")
        await context.bot.send_message(
            match["challenger_id"],
            "❌ Partie interrompue, mise remboursée.",
        )
        await context.bot.send_message(
            match["target_id"],
            "❌ Partie interrompue, mise remboursée.",
        )

# ----------------------------------------------------------------------
# JEU 1 : COMBAT (avec settlement atomique)
# ⭐ XP avec boost appliqué via add_xp()
# ----------------------------------------------------------------------
async def start_combat_game(context, challenge):
    from gameplay.combat import resolve_combat
    result = await resolve_combat(challenge["match_id"])
    if result is None:
        logger.warning("Match combat déjà réglé ou indisponible : %s", challenge["match_id"])
        return
    winner_name = result.challenger_name if result.winner_id == result.challenger_id else result.target_name
    loot_msg = f"\n\n🎁 Tu as gagné un item : {result.loot} !" if result.loot else ""
    text = (
        f"⚔️ <b>COMBAT</b>\n\n{escape_html(chr(10).join(result.logs))}\n\n"
        f"❤️ HP final : {escape_html(result.challenger_name)}: {result.challenger_hp}% | {escape_html(result.target_name)}: {result.target_hp}%\n\n"
        f"🏆 <b>{escape_html(winner_name)} remporte le combat !</b>\n💰 Gain : {escape_html(fmt(result.pot))} (+100 XP){escape_html(loot_msg)}"
    )
    await context.bot.send_message(challenge["challenger_id"], text, parse_mode="HTML")
    await context.bot.send_message(challenge["target_id"], text, parse_mode="HTML")

# ----------------------------------------------------------------------
# JEU 2 : PIERRE-PAPIER-CISEAUX (avec save_choice)
# ⭐ XP avec boost appliqué
# ----------------------------------------------------------------------
async def start_rps_game(context, challenge):
    match_id = challenge["match_id"]
    keyboard = [
        [InlineKeyboardButton("✊ Pierre", callback_data=f"rps|{match_id}|pierre")],
        [InlineKeyboardButton("📄 Papier", callback_data=f"rps|{match_id}|papier")],
        [InlineKeyboardButton("✂️ Ciseaux", callback_data=f"rps|{match_id}|ciseaux")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    msg = f"✊ <b>Pierre - Papier - Ciseaux</b>\n\n💰 Mise : {escape_html(fmt(challenge['bet']))}\n👤 Adversaire : {escape_html(challenge['target_name'])}\n\nChoisis ton coup :"
    await context.bot.send_message(challenge["challenger_id"], msg, reply_markup=reply_markup, parse_mode="HTML")
    await context.bot.send_message(challenge["target_id"], msg, reply_markup=reply_markup, parse_mode="HTML")

async def rps_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    parts = data.split("|")
    if len(parts) != 3:
        await query.answer("Format invalide.", show_alert=True)
        return
    _, match_id, player_choice = parts

    match = await _with_names(await save_choice(match_id, query.from_user.id, player_choice))
    if not match:
        await query.edit_message_text("❌ Match indisponible.")
        return

    await query.edit_message_text(
        f"✅ Choix {player_choice} enregistré."
    )

    challenger_choice = match["challenger_choice"]
    target_choice = match["target_choice"]
    if not challenger_choice or not target_choice:
        return

    rules = {
        "pierre": "ciseaux",
        "papier": "pierre",
        "ciseaux": "papier",
    }
    if challenger_choice == target_choice:
        settled = await settle_draw(
            match_id,
            {"game": "rps", "draw": True},
        )
        winner_id = 0
    elif rules[challenger_choice] == target_choice:
        winner_id = match["challenger_id"]
        settled = await settle_winner(
            match_id,
            winner_id,
            {"game": "rps", "winner_id": winner_id},
        )
    else:
        winner_id = match["target_id"]
        settled = await settle_winner(
            match_id,
            winner_id,
            {"game": "rps", "winner_id": winner_id},
        )

    if not settled:
        return

    emojis = {"pierre":"✊","papier":"📄","ciseaux":"✂️"}
    if winner_id:
        loser_id = match["target_id"] if winner_id == match["challenger_id"] else match["challenger_id"]
        # ⭐ XP avec boost appliqué
        await add_xp(winner_id, 50)
        await add_xp(loser_id, 25)
        loot_msg = ""
        if random.random() < 0.2:
            item = await add_random_item(winner_id, "common", "rare")
            if item:
                loot_msg = f"\n\n🎁 Item gagné : {item} !"
        result_text = f"🏆 {match['challenger_name'] if winner_id == match['challenger_id'] else match['target_name']} gagne !"
        gain_msg = f"💰 Gain : {fmt(match['bet'] * 2)}"
    else:
        result_text = "🤝 Égalité, remboursement."
        gain_msg = f"💰 Remboursement : {fmt(match['bet'])}"
        loot_msg = ""

    text = (
        f"✊ <b>Résultat</b>\n\n"
        f"{escape_html(match['challenger_name'])} : {escape_html(emojis[challenger_choice])}\n"
        f"{escape_html(match['target_name'])} : {escape_html(emojis[target_choice])}\n\n"
        f"{result_text}\n{escape_html(gain_msg)}{escape_html(loot_msg)}"
    )
    await context.bot.send_message(match["challenger_id"], text, parse_mode="HTML")
    await context.bot.send_message(match["target_id"], text, parse_mode="HTML")

# ----------------------------------------------------------------------
# JEU 3 : PILE OU FACE (avec save_choice)
# ⭐ XP avec boost appliqué
# ----------------------------------------------------------------------
async def start_coinflip_game(context, challenge):
    match_id = challenge["match_id"]
    keyboard = [
        [InlineKeyboardButton("🪙 Pile", callback_data=f"coinflip|{match_id}|pile")],
        [InlineKeyboardButton("🪙 Face", callback_data=f"coinflip|{match_id}|face")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    msg = f"🪙 <b>Pile ou Face</b>\n\n💰 Mise : {escape_html(fmt(challenge['bet']))}\n👤 Adversaire : {escape_html(challenge['target_name'])}\n\nChoisis ton camp :"
    await context.bot.send_message(challenge["challenger_id"], msg, reply_markup=reply_markup, parse_mode="HTML")
    await context.bot.send_message(challenge["target_id"], msg, reply_markup=reply_markup, parse_mode="HTML")

async def coinflip_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    parts = data.split("|")
    if len(parts) != 3:
        await query.answer("Format invalide.", show_alert=True)
        return
    _, match_id, choice = parts

    match = await _with_names(await save_choice(match_id, query.from_user.id, choice))
    if not match:
        await query.edit_message_text("❌ Match indisponible.")
        return

    await query.edit_message_text(f"✅ Choix {choice.upper()} enregistré ! En attente de l'adversaire...")

    challenger_choice = match["challenger_choice"]
    target_choice = match["target_choice"]
    if not challenger_choice or not target_choice:
        return

    result = random.choice(["pile", "face"])
    total_bet = match["bet"] * 2

    if challenger_choice == result and target_choice == result:
        settled = await settle_draw(
            match_id,
            {"game": "coinflip", "draw": True},
        )
        result_text = "🤝 <b>Égalité parfaite !</b> Les deux ont choisi la bonne face. Remboursement."
        gain_msg = ""
        loot_msg = ""
    elif challenger_choice == result:
        settled = await settle_winner(
            match_id,
            match["challenger_id"],
            {"game": "coinflip", "winner_id": match["challenger_id"]},
        )
        if settled:
            # ⭐ XP avec boost appliqué
            await add_xp(match["challenger_id"], 30)
        result_text = f"🏆 <b>{match['challenger_name']} gagne !</b>"
        gain_msg = f"💰 Gain : {fmt(total_bet)}"
        loot_msg = ""
        if random.random() < 0.2:
            item = await add_random_item(match["challenger_id"], "common", "rare")
            if item:
                loot_msg = f"\n\n🎁 Item gagné : {item} !"
    elif target_choice == result:
        settled = await settle_winner(
            match_id,
            match["target_id"],
            {"game": "coinflip", "winner_id": match["target_id"]},
        )
        if settled:
            # ⭐ XP avec boost appliqué
            await add_xp(match["target_id"], 30)
        result_text = f"🏆 <b>{match['target_name']} gagne !</b>"
        gain_msg = f"💰 Gain : {fmt(total_bet)}"
        loot_msg = ""
        if random.random() < 0.2:
            item = await add_random_item(match["target_id"], "common", "rare")
            if item:
                loot_msg = f"\n\n🎁 Item gagné : {item} !"
    else:
        settled = await settle_winner(
            match_id,
            0,
            {"game": "coinflip", "winner_id": 0},
        )
        result_text = "💀 <b>Personne n'a gagné !</b> Les deux perdent leur mise."
        gain_msg = "💸 Mise perdue pour les deux."
        loot_msg = ""

    if not settled:
        return

    text = (
        f"🪙 <b>Pile ou Face</b>\n\n"
        f"🎲 Résultat : <b>{escape_html(result.upper())}</b>\n"
        f"👤 {escape_html(match['challenger_name'])} a choisi : {escape_html(challenger_choice.upper())}\n"
        f"👤 {escape_html(match['target_name'])} a choisi : {escape_html(target_choice.upper())}\n\n"
        f"{result_text}\n{escape_html(gain_msg)}{escape_html(loot_msg)}"
    )
    await context.bot.send_message(match["challenger_id"], text, parse_mode="HTML")
    await context.bot.send_message(match["target_id"], text, parse_mode="HTML")

# ----------------------------------------------------------------------
# JEU 4 : DÉS (avec settlement atomique)
# ⭐ XP avec boost appliqué
# ----------------------------------------------------------------------
async def start_dice_game(context, challenge):
    from database import get_skill
    match_id = challenge["match_id"]
    c_roll = random.randint(1,6)
    t_roll = random.randint(1,6)
    c_intel = await get_skill(challenge["challenger_id"], "Intelligence") or 0
    t_intel = await get_skill(challenge["target_id"], "Intelligence") or 0
    c_total = c_roll + (c_intel//5)
    t_total = t_roll + (t_intel//5)

    if c_total > t_total:
        winner_id = challenge["challenger_id"]
        winner_name = challenge["challenger_name"]
    elif t_total > c_total:
        winner_id = challenge["target_id"]
        winner_name = challenge["target_name"]
    else:
        winner_id = None
        winner_name = None

    if winner_id:
        settled = await settle_winner(
            match_id,
            winner_id,
            {"game": "des", "winner_id": winner_id},
        )
        if settled:
            # ⭐ XP avec boost appliqué
            await add_xp(winner_id, 40)
        loser_id = challenge["target_id"] if winner_id == challenge["challenger_id"] else challenge["challenger_id"]
        loot_msg = ""
        if random.random() < 0.2:
            item = await add_random_item(winner_id, "common", "rare")
            if item:
                loot_msg = f"\n\n🎁 Item gagné : {item} !"
    else:
        settled = await settle_draw(
            match_id,
            {"game": "des", "draw": True},
        )
        loot_msg = ""

    if not settled:
        return

    text = (
        f"🎲 <b>Dés</b>\n\n"
        f"{escape_html(challenge['challenger_name'])} : {escape_html(c_roll)} (Intel +{escape_html(c_intel//5)}) = {escape_html(c_total)}\n"
        f"{escape_html(challenge['target_name'])} : {escape_html(t_roll)} (Intel +{escape_html(t_intel//5)}) = {escape_html(t_total)}\n\n"
        f"{escape_html('🏆 '+winner_name+' gagne !' if winner_id else '🤝 Égalité, remboursement')}\n"
        f"💰 {escape_html('Gain '+fmt(challenge['bet'] * 2) if winner_id else 'Remboursement '+fmt(challenge['bet']))}{escape_html(loot_msg)}"
    )
    await context.bot.send_message(challenge["challenger_id"], text, parse_mode="HTML")
    await context.bot.send_message(challenge["target_id"], text, parse_mode="HTML")

# ----------------------------------------------------------------------
# JEU 5 : COURSE (avec settlement atomique)
# ⭐ XP avec boost appliqué
# ----------------------------------------------------------------------
async def start_race_game(context, challenge):
    from database import get_skill
    match_id = challenge["match_id"]
    c_agi = await get_skill(challenge["challenger_id"], "Agilité") or 0
    t_agi = await get_skill(challenge["target_id"], "Agilité") or 0
    c_end = await get_skill(challenge["challenger_id"], "Endurance") or 0
    t_end = await get_skill(challenge["target_id"], "Endurance") or 0
    c_speed = random.randint(20,80) + c_agi*4 + c_end*2
    t_speed = random.randint(20,80) + t_agi*4 + t_end*2

    winner_id = challenge["challenger_id"] if c_speed > t_speed else challenge["target_id"]
    winner_name = challenge["challenger_name"] if c_speed > t_speed else challenge["target_name"]

    settled = await settle_winner(
        match_id,
        winner_id,
        {"game": "course", "winner_id": winner_id},
    )
    if settled:
        # ⭐ XP avec boost appliqué
        await add_xp(winner_id, 60)

    loser_id = challenge["target_id"] if winner_id == challenge["challenger_id"] else challenge["challenger_id"]
    loot_msg = ""
    if random.random() < 0.2:
        item = await add_random_item(winner_id, "common", "rare")
        if item:
            loot_msg = f"\n\n🎁 Item gagné : {item} !"

    if not settled:
        return

    text = (
        f"🏃 <b>Course</b>\n\n"
        f"{escape_html(challenge['challenger_name'])} : {escape_html(c_speed)} km/h\n"
        f"{escape_html(challenge['target_name'])} : {escape_html(t_speed)} km/h\n\n"
        f"🏆 <b>{escape_html(winner_name)} remporte la course !</b>\n💰 Gain : {escape_html(fmt(challenge['bet'] * 2))} (+60 XP){escape_html(loot_msg)}"
    )
    await context.bot.send_message(challenge["challenger_id"], text, parse_mode="HTML")
    await context.bot.send_message(challenge["target_id"], text, parse_mode="HTML")

# ----------------------------------------------------------------------
# JEU 6 : QUIZ (settlement atomique)
# ⭐ XP avec boost appliqué
# ----------------------------------------------------------------------
QUESTIONS = [
    {"question": "Quelle est la capitale de la France ?", "answer": "paris", "options": ["paris","londres","berlin","madrid"]},
    {"question": "Combien font 7 x 8 ?", "answer": "56", "options": ["48","56","64","72"]},
    {"question": "Qui a peint la Joconde ?", "answer": "leonard de vinci", "options": ["van gogh","picasso","leonard de vinci","monet"]},
    {"question": "Quel est le plus grand océan ?", "answer": "pacifique", "options": ["atlantique","indien","pacifique","arctique"]},
    {"question": "Année de la Révolution française ?", "answer": "1789", "options": ["1776","1789","1799","1804"]},
    {"question": "Auteur des Misérables ?", "answer": "victor hugo", "options": ["zola","hugo","flaubert","balzac"]},
    {"question": "Planète la plus proche du soleil ?", "answer": "mercure", "options": ["vénus","terre","mercure","mars"]},
    {"question": "Joueurs dans une équipe de foot ?", "answer": "11", "options": ["9","10","11","12"]},
]

async def start_quiz_game(context, challenge):
    from database import get_skill
    match_id = challenge["match_id"]
    c_intel = await get_skill(challenge["challenger_id"], "Intelligence") or 0
    t_intel = await get_skill(challenge["target_id"], "Intelligence") or 0
    q = random.choice(QUESTIONS)
    quiz_id = f"quiz_{match_id}"
    active_quizzes[quiz_id] = {
        "question": q,
        "correct_answer": q["answer"],
        "match_id": match_id,
        "challenger_id": challenge["challenger_id"],
        "target_id": challenge["target_id"],
        "challenger_name": challenge["challenger_name"],
        "target_name": challenge["target_name"],
        "bet": challenge["bet"],
        "answered": False,
        "winner_id": None,
    }
    keyboard = [[InlineKeyboardButton(opt.upper(), callback_data=f"quiz_answer|{quiz_id}|{opt.lower()}")] for opt in q["options"]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    text = (
        f"❓ <b>QUIZ</b>\n\n📝 {escape_html(q['question'])}\n\n💰 Mise : {escape_html(fmt(challenge['bet']))} (x2)\n"
        f"⚡ Premier à répondre gagne !\n📚 Intel: {escape_html(challenge['challenger_name'])} +{escape_html(c_intel)} | {escape_html(challenge['target_name'])} +{escape_html(t_intel)}"
    )
    await context.bot.send_message(challenge["challenger_id"], text, reply_markup=reply_markup, parse_mode="HTML")
    await context.bot.send_message(challenge["target_id"], text, reply_markup=reply_markup, parse_mode="HTML")
    asyncio.create_task(quiz_timeout(context, quiz_id))

async def quiz_timeout(context, quiz_id):
    await asyncio.sleep(60)
    game = active_quizzes.get(quiz_id)
    if game and not game["answered"]:
        game["answered"] = True
        await refund_match(game["match_id"], "expired")
        timeout_text = f"⏰ Quiz expiré ! Mise remboursée : {escape_html(fmt(game['bet']))}"
        await context.bot.send_message(game["challenger_id"], timeout_text, parse_mode="HTML")
        await context.bot.send_message(game["target_id"], timeout_text, parse_mode="HTML")
        del active_quizzes[quiz_id]

async def quiz_answer_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    parts = data.split("|")
    if len(parts) != 3:
        await query.answer("Format invalide.", show_alert=True)
        return
    _, quiz_id, answer = parts
    answer = answer.lower()
    user_id = query.from_user.id
    game = active_quizzes.get(quiz_id)
    if not game:
        await query.answer("Quiz expiré.", show_alert=True)
        return
    if user_id not in (game["challenger_id"], game["target_id"]):
        await query.answer("Tu ne participes pas.", show_alert=True)
        return
    if game["answered"]:
        await query.answer("Déjà terminé.", show_alert=True)
        return

    if answer == game["correct_answer"]:
        game["answered"] = True
        game["winner_id"] = user_id
        winner_id = user_id
        loser_id = game["target_id"] if winner_id == game["challenger_id"] else game["challenger_id"]

        # Settlement atomique
        settled = await settle_winner(
            game["match_id"],
            winner_id,
            {"game": "quiz", "winner_id": winner_id},
        )
        if settled:
            # ⭐ XP avec boost appliqué
            await add_xp(winner_id, 75)
            await add_xp(loser_id, 25)

        loot_msg = ""
        if random.random() < 0.25:
            item = await add_random_item(winner_id, "common", "epic")
            if item:
                loot_msg = f"\n\n🎁 Item gagné : {item} !"

        winner_name = game["challenger_name"] if winner_id == game["challenger_id"] else game["target_name"]
        result_text = f"❓ <b>QUIZ - RÉPONSE CORRECTE !</b>\n\n✅ {escape_html(winner_name)} a gagné !\n📝 Réponse : {escape_html(game['correct_answer'])}\n💰 Gain : {escape_html(fmt(game['bet'] * 2))}{escape_html(loot_msg)}"
        await query.edit_message_text(result_text, parse_mode="HTML")
        await context.bot.send_message(loser_id, result_text, parse_mode="HTML")
        del active_quizzes[quiz_id]
    else:
        await query.answer(f"Mauvaise réponse ! La bonne était {game['correct_answer']}", show_alert=True)

# ----------------------------------------------------------------------
# Autres commandes : /defis, /classementarene, /parier
# ----------------------------------------------------------------------
@require_registered
async def cmd_defis(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    # Récupération des défis en attente depuis la base
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM arena_matches WHERE target_id=? AND status='pending'",
            (user_id,)
        ) as cur:
            matches = [dict(row) for row in await cur.fetchall()]
    if not matches:
        await update.message.reply_text("📭 Aucun défi en attente.")
        return
    text = "🎮 <b>Défis en attente</b>\n\n"
    for ch in matches:
        challenger = await get_user(ch["challenger_id"])
        challenger_name = challenger.get("full_name", "Joueur")
        game_name = PVP_GAMES.get(ch["game"], {}).get("name", ch["game"])
        text += f"• De <b>{escape_html(challenger_name)}</b> - {escape_html(game_name)} - Mise {escape_html(fmt(ch['bet']))}\n"
    await update.message.reply_text(text, parse_mode="HTML")

@require_registered
async def cmd_classement_arene(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_for_update
    await show_for_update(update, 'arene')


@require_registered
@require_free
@cooldown("parier_cooldown", 10, "⏳ Attends 10 secondes avant de parier à nouveau.")
async def cmd_parier(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    if not update.message.reply_to_message or not context.args:
        await update.message.reply_text("🎰 <b>Paris sur combats</b>\n\nRéponds à un message depuis le menu")
        return
    target = update.message.reply_to_message.from_user
    if target.id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas parier sur toi-même.")
        return
    amount = parse_amount(context.args[0])
    if not amount or amount < 500:
        await update.message.reply_text("❌ Mise minimale : 500 €A.")
        return
    MAX_BET = 1_000_000
    if amount > MAX_BET:
        await update.message.reply_text(f"❌ Mise maximale pour parier : {fmt(MAX_BET)}")
        return
    if u["balance"] < amount:
        await update.message.reply_text("❌ Solde insuffisant.")
        return
    t_data = await get_user(target.id)
    if not t_data or not t_data.get("registered"):
        await update.message.reply_text("❌ Ce joueur n'est pas enregistré.")
        return

    # 50% de chance de gagner
    if random.random() < 0.5:
        gain = int(amount * 1.8)
        await update_balance(user.id, gain)
        await update.message.reply_text(f"🎰 <b>PARI GAGNÉ !</b>\n\n💰 Gain : {fmt(gain)}")
    else:
        await update_balance(user.id, -amount, sink="arene")
        await update.message.reply_text(f"🎰 <b>PARI PERDU !</b>\n\n💸 Perte : {fmt(amount)}")
