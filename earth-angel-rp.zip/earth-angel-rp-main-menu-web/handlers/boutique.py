# handlers/boutique.py — 🛍️ Boutique v2 (préfixe `sh:`) : vitrine, achat en Étoiles, cadeaux, fidélité, gestion staff
"""
Joueur : offre du jour, offre de bienvenue, à la une, catégories, fiche article, achat ou cadeau, historique, fidélité.
Paiement : factures en Étoiles Telegram (XTR). Chaque paiement devient une COMMANDE (identifiant de transaction unique) :
livrée une seule fois ; en cas de problème (effet impossible, article épuisé, plafond atteint) le joueur est REMBOURSÉ
automatiquement ; une tâche reprend les commandes restées en suspens (arrêt du bot en plein achat).
Staff : catalogue (activer, mettre en avant, prix, promo, stock, dates), exclusivités de fête, test d'achat sans paiement,
commandes à traiter (réessayer / rembourser) et chiffres de vente. Le Lead Principal garde la main sur les paiements réels.
"""
from utils.swallow import swallowed
import html
import logging
import time

from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M, LabeledPrice, Update
from telegram.ext import ContextTypes

from database import get_user
from config import STARS_RETIRED_ITEMS, STARS_SHOP, role_level
from utils import shop
from utils import vip as vip_utils
from utils.bot_registry import get_bot
from utils.decorators import get_user_role_async, require_registered
from utils.gamerules import switch_on
from utils.input_flow import ask, flow
from utils.notify import notify
from utils.ui import esc, layout

logger = logging.getLogger(__name__)
CB = "sh:"
SEP = "━━━━━━━━━━━━━━━━━━"
PAGE = 6
LVL_EDIT = role_level("GAME_LEADER")
LVL_MONEY = role_level("LEAD_STAFF_GLOBAL")


async def _send(update: Update, text: str, markup: M) -> None:
    q = update.callback_query
    if q:
        try:
            await q.edit_message_text(text[:4000], parse_mode="HTML", reply_markup=markup)
            return
        except Exception:
            await q.message.reply_text(text[:4000], parse_mode="HTML", reply_markup=markup)
            return
    await update.effective_message.reply_text(text[:4000], parse_mode="HTML", reply_markup=markup)


def _nav(rows=None, back: str = CB + "home", back_label: str = "⬅️ Boutique") -> M:
    rows = list(rows or [])
    rows.append([B(back_label, callback_data=back), B("🎮 Menu principal", callback_data="hub:home")])
    return M(rows)


async def _level(uid: int) -> int:
    return role_level(await get_user_role_async(uid))


def _until_midnight() -> str:
    left = 86400 - int(time.time()) % 86400
    return f"{left // 3600} h {left % 3600 // 60:02d}"


def _fmt_price(item: dict, p: tuple[int, int, str]) -> str:
    price, pct, why = p
    if pct:
        return f"<s>{item['stars']}</s> <b>{price} ⭐</b> (−{pct} %)"
    return f"<b>{price} ⭐</b>"


def _badges(item: dict) -> str:
    out = []
    if item["ends_at"]:
        left = item["ends_at"] - int(time.time())
        out.append(f"⏳ {max(1, left // 3600)} h" if left < 172800 else f"⏳ {left // 86400} j")
    if item["stock"] >= 0:
        out.append(f"🔥 {max(0, item['stock'] - item['sold'])} restant(s)")
    return " · ".join(out)


def _perks_lines(u: dict) -> list[str]:
    """Résumé lisible des avantages déjà actifs : abonnement en cours (+ rappel s'il expire bientôt)
    et boosts temporaires en cours. Sert à rappeler au joueur ce qu'il a déjà, avant de lui proposer d'acheter."""
    out = []
    tier = vip_utils.get_tier(u)
    if tier != "none":
        field = "premium_until" if tier == "premium" else "vip_until"
        until = u.get(field, 0)
        left = until - int(time.time())
        soon = "  ⏳ <b>expire bientôt, pense à renouveler !</b>" if 0 < left < 172800 else ""
        out.append(f"{vip_utils.status_label(u)} actif jusqu'au {time.strftime('%d/%m %H:%M', time.gmtime(until))}{soon}")
    actifs = []
    for key, it in STARS_SHOP.items():
        if key in STARS_RETIRED_ITEMS or it.get("type") != "boost":
            continue
        field = it["field"]
        if vip_utils.has_boost(u, field):
            left = max(1, (u.get(field, 0) - int(time.time())) // 3600)
            actifs.append(f"{it['label'].split(' (')[0]} ({left} h)")
    if actifs:
        out.append("⚡ Boosts actifs : " + " · ".join(actifs))
    return out


async def _context(uid: int) -> dict:
    items = await shop.items()
    return {"items": items, "deal": shop.deal_key(items), "welcome": await shop.delivered_count(uid) == 0}


def _line(item: dict, ctx: dict) -> str:
    m = shop.meta(item)
    p = shop.price(item, welcome=ctx["welcome"], deal=ctx["deal"])
    extra = _badges(item)
    return f"{m['label']} — {_fmt_price(item, p)}" + (f"  {extra}" if extra else "")


# ─────────────────────────────────────────────────────────────────────────────
#  Vitrine
# ─────────────────────────────────────────────────────────────────────────────
async def show_home(update: Update, uid: int, note: str = "") -> None:
    await shop.seed()
    ctx = await _context(uid)
    byk = {i["item_key"]: i for i in ctx["items"]}
    lines = [f"🛍️ <b>BOUTIQUE</b>\n{SEP}"] + ([note] if note else [])
    perks = _perks_lines(await get_user(uid))
    if perks:
        lines.append("\n".join(perks))
    if not await switch_on("real_payments"):
        lines.append("⏸️ <i>Les achats sont momentanément suspendus par la direction. Tu peux toujours consulter le catalogue.</i>")
    welcome = byk.get(shop.WELCOME_ITEM)
    if ctx["welcome"] and welcome:
        lines.append(f"🎁 <b>OFFRE DE BIENVENUE</b>\n{_line(welcome, ctx)}\n<i>Une seule fois, pour bien démarrer.</i>")
    deal = byk.get(ctx["deal"]) if ctx["deal"] else None
    if deal:
        lines.append(f"⭐ <b>OFFRE DU JOUR</b> (encore {_until_midnight()})\n{_line(deal, ctx)}")
    featured = [i for i in ctx["items"] if (i["featured"] or i["ends_at"]) and i["item_key"] not in (ctx["deal"], shop.WELCOME_ITEM)][:3]
    if featured:
        lines.append("🌟 <b>À LA UNE</b>\n" + "\n".join(_line(i, ctx) for i in featured))
    lines.append("🔒 <i>Paiement par Étoiles Telegram · livraison immédiate · remboursement automatique en cas de souci.</i>")
    btns, rows = [], []
    for key in (ctx["deal"],) if ctx["deal"] else ():
        pass
    show = ([welcome] if ctx["welcome"] and welcome else []) + ([deal] if deal else []) + featured
    for it in show:
        p = shop.price(it, welcome=ctx["welcome"], deal=ctx["deal"])
        rows.append([B(f"{shop.meta(it)['label']} · {p[0]} ⭐"[:60], callback_data=f"{CB}i:{it['item_key']}")])
    counts = {}
    for it in ctx["items"]:
        counts[it["category"]] = counts.get(it["category"], 0) + 1
    cats = [B(f"{e} {n} ({counts[c]})", callback_data=f"{CB}c:{c}:0") for c, (e, n) in shop.CATEGORIES.items() if counts.get(c)]
    rows += layout(cats)
    loy = await shop.loyalty(uid)
    rows.append([B(f"🏅 Fidélité · {loy['spent']} ⭐", callback_data=CB + "loy"), B("🧾 Mes achats", callback_data=CB + "hist")])
    coll = await shop.cosmetics_of(uid)
    rows.append([B(f"🎒 Ma collection ({len(coll)})", callback_data=CB + "coll")])
    if await _level(uid) >= LVL_EDIT:
        rows.append([B("🛠️ Gérer la boutique (staff)", callback_data=CB + "adm:0")])
    await _send(update, "\n\n".join(lines), M(rows + [[B("⬅️ Retour", callback_data="hub:profil"), B("🎮 Menu principal", callback_data="hub:home")]]))


async def show_category(update: Update, uid: int, cat: str, page: int = 0) -> None:
    if cat not in shop.CATEGORIES:
        await show_home(update, uid)
        return
    ctx = await _context(uid)
    its = [i for i in ctx["items"] if i["category"] == cat]
    pages = max(1, -(-len(its) // PAGE))
    page = max(0, min(page, pages - 1))
    chunk = its[page * PAGE:(page + 1) * PAGE]
    emoji, name = shop.CATEGORIES[cat]
    lines = [f"{emoji} <b>{name.upper()}</b>\n{SEP}"]
    rows = []
    for it in chunk:
        m = shop.meta(it)
        lines.append(f"{_line(it, ctx)}\n<i>{esc(m['short'][:90], quote=False)}</i>")
        rows.append([B(f"{m['label']} · {shop.price(it, welcome=ctx['welcome'], deal=ctx['deal'])[0]} ⭐"[:60], callback_data=f"{CB}i:{it['item_key']}")])
    if not its:
        lines.append("Rien à afficher pour le moment.")
    if pages > 1:
        nav = []
        if page > 0:
            nav.append(B("◀️", callback_data=f"{CB}c:{cat}:{page - 1}"))
        nav.append(B(f"{page + 1}/{pages}", callback_data=f"{CB}c:{cat}:{page}"))
        if page < pages - 1:
            nav.append(B("▶️", callback_data=f"{CB}c:{cat}:{page + 1}"))
        rows.append(nav)
    await _send(update, "\n\n".join(lines), _nav(rows))


async def show_item(update: Update, uid: int, key: str, note: str = "") -> None:
    item = await shop.get_item(key)
    ctx = await _context(uid)
    if not item or not shop.visible(item, await switch_on("shop_money"))[0]:
        await show_home(update, uid, "ℹ️ Cet article n'est plus disponible.")
        return
    m = shop.meta(item)
    p = shop.price(item, welcome=ctx["welcome"], deal=ctx["deal"])
    lines = [f"{m['label']}\n{SEP}"] + ([note] if note else [])
    if m["tag"]:
        lines.append(f"<b>{esc(m['tag'])}</b>")
    lines.append(esc(re_clean(m["desc"]), quote=False)[:700])
    lines.append(f"💰 Prix : {_fmt_price(item, p)}" + (f" — <i>{p[2]}</i>" if p[2] else ""))
    if _badges(item):
        lines.append(_badges(item))
    rows = [[B(f"⭐ Acheter · {p[0]} ⭐", callback_data=f"{CB}buy:{key}:{uid}")],
            [B("🎁 Offrir à un joueur", callback_data=f"{CB}gift:{key}")]]
    cat = item["category"]
    await _send(update, "\n\n".join(lines), _nav(rows, back=f"{CB}c:{cat}:0", back_label="⬅️ Catégorie"))


def re_clean(text: str) -> str:
    return " ".join(str(text).split())


@flow("sh_gift")
async def _flow_gift(update, context, value, data):
    target, _name = value
    uid = update.effective_user.id
    if target == uid:
        await _send(update, "ℹ️ Pour t'acheter l'article, utilise « Acheter ».", _nav())
        return
    item = await shop.get_item(data["key"])
    if not item:
        await show_home(update, uid)
        return
    from database import get_user
    t = await get_user(target)
    if not t.get("registered"):
        await _send(update, "❌ Joueur introuvable.", _nav())
        return
    ctx = await _context(uid)
    p = shop.price(item, welcome=False, deal=ctx["deal"])
    who = esc(t.get("full_name") or t.get("username") or str(target))
    await _send(update, f"🎁 <b>OFFRIR</b>\n{SEP}\n{shop.meta(item)['label']}\npour <b>{who}</b>\n\n💰 {_fmt_price(item, p)}\n\n"
                        "<i>Il le recevra tout de suite avec ton message.</i>",
                _nav([[B(f"🎁 Payer {p[0]} ⭐ et offrir", callback_data=f"{CB}buy:{item['item_key']}:{target}")]],
                     back=f"{CB}i:{item['item_key']}", back_label="⬅️ Article"))


# ─────────────────────────────────────────────────────────────────────────────
#  Achat
# ─────────────────────────────────────────────────────────────────────────────
async def apply_item(kind: str, key: str, target: int) -> str:
    """Applique l'effet d'une commande (réutilise les effets éprouvés de handlers/shop_stars)."""
    from handlers import shop_stars as old
    if kind == "sub":
        return await old._apply_subscription(target, key)
    if kind == "custom":
        return await shop.grant_cosmetic(target, key)
    return await old._apply_shop_item(target, key)


async def _can_receive(kind: str, key: str, target: int) -> tuple[bool, str]:
    if kind != "shop":
        return True, ""
    from handlers import shop_stars as old
    return await old._check_stack_available(target, key)


async def checkout(update: Update, context, uid: int, key: str, target: int) -> None:
    q = update.callback_query
    item = await shop.get_item(key)
    if not item or not shop.visible(item, await switch_on("shop_money"))[0]:
        await show_home(update, uid, "ℹ️ Cet article n'est plus disponible.")
        return
    ok, why = await _can_receive(item["kind"], key, target)
    if not ok:
        await show_item(update, uid, key, f"⛔ {esc(why)}\n<i>Aucun débit effectué.</i>")
        return
    ctx = await _context(uid)
    stars, _pct, _why = shop.price(item, welcome=ctx["welcome"] and target == uid, deal=ctx["deal"])
    m = shop.meta(item)
    # direction : essai gratuit, sans paiement (commande de test, jamais comptée dans les chiffres)
    if await _level(uid) >= LVL_MONEY:
        oid, _ = await shop.create_order(f"TEST-{uid}-{int(time.time() * 1000)}", uid, target, key, item["kind"], 0, test=True)
        st, txt = await shop.deliver(oid, apply_item)
        await show_item(update, uid, key, f"🧪 <b>Test sans paiement</b> : {esc(txt)}" if st == "delivered" else f"🧪 Échec du test : {esc(txt)}")
        return
    if not await switch_on("real_payments"):
        await show_item(update, uid, key, "💳 Les paiements sont momentanément suspendus par la direction. Réessaie plus tard.")
        return
    payload = f"v2:{uid}:{key}:{target}:{stars}"
    await context.bot.send_invoice(
        chat_id=(q.message.chat_id if q else update.effective_chat.id),
        title=re_clean(m["label"])[:32], description=re_clean(m["desc"] or m["label"])[:250] or "Article de la boutique",
        payload=payload, provider_token="", currency="XTR", prices=[LabeledPrice(re_clean(m["label"])[:32], stars)])


def _parse(payload: str) -> tuple[int, str, str, int, int | None] | None:
    """→ (acheteur, clé, kind, cible, prix attendu). Accepte l'ancien format `uid:kind:clé`."""
    try:
        parts = payload.split(":")
        if parts[0] == "v2":
            return int(parts[1]), parts[2], "", int(parts[3]), int(parts[4])
        return int(parts[0]), parts[2], parts[1], int(parts[0]), None
    except (ValueError, IndexError):
        return None


async def precheckout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.pre_checkout_query
    if not await switch_on("real_payments"):
        await query.answer(ok=False, error_message="Paiements suspendus par la direction.")
        return
    parsed = _parse(query.invoice_payload)
    if not parsed:
        await query.answer(ok=False, error_message="Facture invalide.")
        return
    buyer, key, kind, target, expected = parsed
    item = await shop.get_item(key)
    if not item or not shop.visible(item, await switch_on("shop_money"))[0]:
        await query.answer(ok=False, error_message="Cet article n'est plus disponible.")
        return
    ok, why = await _can_receive(item["kind"], key, target)
    if not ok:
        await query.answer(ok=False, error_message=f"{why}\nAucun débit effectué.")
        return
    items = await shop.items()
    price_now = shop.price(item, welcome=(await shop.delivered_count(buyer) == 0 and target == buyer), deal=shop.deal_key(items))[0]
    if query.total_amount not in {price_now, expected or price_now, item["stars"]}:
        await query.answer(ok=False, error_message="Le prix a changé : rouvre la boutique.")
        return
    await query.answer(ok=True)


async def refund(order: dict, reason: str) -> bool:
    """Rembourse une commande en Étoiles. Marque 'refunded' si Telegram accepte, sinon prévient la direction."""
    bot = get_bot()
    if order["test"] or not bot:
        return False
    try:
        await bot.refund_star_payment(user_id=order["user_id"], telegram_payment_charge_id=order["charge_id"])
        await shop.mark(order["id"], "refunded", reason)
        return True
    except Exception:
        logger.exception("Remboursement Étoiles impossible (commande %s)", order["id"])
        from config import LEAD_PRINCIPAL_IDS
        for lead in LEAD_PRINCIPAL_IDS:
            await notify(lead, "⚠️ Remboursement manuel requis",
                         f"Commande #{order['id']} · joueur <code>{order['user_id']}</code> · {order['stars_paid']} ⭐\n"
                         f"Transaction : <code>{esc(order['charge_id'])}</code>\nRaison : {esc(reason)}", "warning")
        return False


async def successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    payment = update.message.successful_payment
    parsed = _parse(payment.invoice_payload)
    if not parsed:
        logger.error("Payload Étoiles invalide : %s", payment.invoice_payload)
        return
    buyer, key, kind, target, _p = parsed
    item = await shop.get_item(key)
    kind = (item or {}).get("kind") or ("sub" if kind == "sub" else "shop")
    oid, is_new = await shop.create_order(payment.telegram_payment_charge_id, buyer, target, key, kind, payment.total_amount)
    if not is_new:
        await update.message.reply_text("ℹ️ <b>Paiement déjà traité.</b> Aucune action supplémentaire n'est nécessaire.", parse_mode="HTML")
        return
    await _deliver_and_report(update.message.reply_text, oid)


async def _deliver_and_report(reply, oid: int) -> None:
    st, text = await shop.deliver(oid, apply_item)
    order = await shop.get_order(oid)
    if st == "delivered":
        loy = await shop.loyalty(order["user_id"])
        nxt = loy["next"]
        extra = f"\n🏅 Fidélité : {loy['spent']} ⭐" + (f" — prochain palier à {nxt['need']} ⭐" if nxt else " — tous les paliers atteints !")
        await reply(f"✅ <b>Achat confirmé</b>\n{esc(text)}\n🧾 Commande n°{oid}{extra}", parse_mode="HTML")
        if order["target_id"] != order["user_id"]:
            await notify(order["target_id"], "🎁 Cadeau reçu", f"Un joueur t'offre : <b>{esc(text)}</b>.", "reward")
        return
    if st == "already":
        return
    refunded = await refund(order, text)
    why = {"soldout": "L'article vient d'être épuisé.", "refused": text}.get(st, "La livraison a rencontré un problème.")
    if refunded:
        await reply(f"⚠️ <b>Achat annulé</b>\n{esc(why)}\n💸 <b>Tu es remboursé automatiquement.</b>\n🧾 Commande n°{oid}", parse_mode="HTML")
    elif st in ("soldout", "refused"):
        await reply(f"⚠️ <b>Achat annulé</b>\n{esc(why)}\n💸 Remboursement en cours de traitement par la direction.\n🧾 Commande n°{oid}", parse_mode="HTML")
    else:
        await reply(f"⏳ <b>Livraison en cours</b>\nTon paiement est bien reçu (commande n°{oid}). Si l'article n'arrive pas dans quelques minutes, "
                    "il sera livré ou remboursé automatiquement.", parse_mode="HTML")


async def run_shop_recovery() -> None:
    """Tâche planifiée : reprend les commandes payées jamais livrées ; rembourse celles qui échouent trop."""
    for order in await shop.recoverable():
        try:
            st, text = await shop.deliver(order["id"], apply_item)
            if st == "delivered":
                await notify(order["target_id"], "✅ Commande livrée", f"Ta commande n°{order['id']} est arrivée : <b>{esc(text)}</b>.", "success")
            elif st in ("soldout", "refused") or (await shop.get_order(order["id"]))["attempts"] >= shop.MAX_ATTEMPTS:
                if await refund(await shop.get_order(order["id"]), text):
                    await notify(order["user_id"], "💸 Commande remboursée", f"Ta commande n°{order['id']} n'a pas pu être livrée : tu es remboursé.", "info")
        except Exception:
            logger.exception("Reprise de la commande %s", order["id"])


# ─────────────────────────────────────────────────────────────────────────────
#  Historique & fidélité
# ─────────────────────────────────────────────────────────────────────────────
STATUS = {"delivered": "✅ livré", "paid": "⏳ en cours", "failed": "⏳ en cours", "refunded": "💸 remboursé"}


async def show_history(update: Update, uid: int) -> None:
    hist = await shop.history(uid)
    lines = [f"🧾 <b>MES ACHATS</b>\n{SEP}"]
    if not hist:
        lines.append("Aucun achat pour le moment.")
    for o in hist:
        it = await shop.get_item(o["item_key"])
        name = shop.meta(it)["label"] if it else o["item_key"]
        gift = " 🎁" if o["target_id"] != o["user_id"] else ""
        lines.append(f"• #{o['id']} {name}{gift} — {o['stars_paid']} ⭐ — {STATUS.get(o['status'], o['status'])}")
    await _send(update, "\n".join(lines), _nav())


async def show_loyalty(update: Update, uid: int, note: str = "") -> None:
    loy = await shop.loyalty(uid)
    lines = [f"🏅 <b>FIDÉLITÉ</b>\n{SEP}"] + ([note] if note else []) + [
        f"Étoiles dépensées : <b>{loy['spent']} ⭐</b>", "<i>Chaque palier offre un cosmétique gratuit.</i>", ""]
    rows = []
    for t in loy["tiers"]:
        it = await shop.get_item(t["item"])
        name = shop.meta(it)["label"] if it else t["item"]
        icon = "✅" if t["claimed"] else ("🎁" if t["reached"] else "🔒")
        lines.append(f"{icon} {t['need']} ⭐ → {name}")
        if t["reached"] and not t["claimed"]:
            rows.append([B(f"🎁 Récupérer : {name}"[:50], callback_data=f"{CB}claim:{t['tier']}")])
    if loy["next"]:
        need = loy["next"]["need"]
        full = round(min(1, loy["spent"] / need) * 10)
        lines += ["", f"Prochain palier : {'█' * full}{'░' * (10 - full)} {loy['spent']}/{need} ⭐"]
    await _send(update, "\n".join(lines), _nav(rows))


async def show_collection(update: Update, uid: int) -> None:
    coll = await shop.cosmetics_of(uid)
    lines = [f"🎒 <b>MA COLLECTION</b>\n{SEP}"]
    if not coll:
        lines.append("Vide pour le moment.\n<i>Les exclusivités de la boutique (éditions limitées, fidélité) rejoignent ta collection pour toujours — même quand elles ne sont plus en vente.</i>")
    else:
        lines.append(f"<b>{len(coll)}</b> article(s), à toi pour toujours :")
        lines += [f"• {esc(label)}" for label in coll]
    await _send(update, "\n".join(lines), _nav())


# ─────────────────────────────────────────────────────────────────────────────
#  Gestion staff
# ─────────────────────────────────────────────────────────────────────────────
async def show_admin(update: Update, uid: int, page: int = 0, note: str = "") -> None:
    if await _level(uid) < LVL_EDIT:
        await show_home(update, uid)
        return
    rows_all = await shop.items(include_hidden=True)
    pages = max(1, -(-len(rows_all) // 8))
    page = max(0, min(page, pages - 1))
    chunk = rows_all[page * 8:(page + 1) * 8]
    st = await shop.stats(7)
    lines = [f"🛠️ <b>GESTION DE LA BOUTIQUE</b>\n{SEP}"] + ([note] if note else [])
    if await _level(uid) >= LVL_MONEY:
        lines.append(f"📈 7 jours : <b>{st['stars']} ⭐</b> · {st['orders']} commande(s) · {st['buyers']} acheteur(s) · {st['refunded']} remboursée(s)")
        if st["attention"]:
            lines.append(f"⚠️ <b>{st['attention']}</b> commande(s) à traiter")
    rows = []
    for it in chunk:
        m = shop.meta(it)
        ok, why = shop.visible(it, True)
        icon = "🟢" if ok else "⚪"
        if it["featured"]:
            icon += "⭐"
        rows.append([B(f"{icon} {m['label']} · {it['stars']}⭐"[:60], callback_data=f"{CB}ai:{it['item_key']}")])
    if pages > 1:
        nav = []
        if page > 0:
            nav.append(B("◀️", callback_data=f"{CB}adm:{page - 1}"))
        nav.append(B(f"{page + 1}/{pages}", callback_data=f"{CB}adm:{page}"))
        if page < pages - 1:
            nav.append(B("▶️", callback_data=f"{CB}adm:{page + 1}"))
        rows.append(nav)
    rows.append([B("➕ Nouvelle exclusivité", callback_data=CB + "an")])
    if await _level(uid) >= LVL_MONEY:
        rows.append([B("📦 Commandes à traiter", callback_data=CB + "ao"), B("📊 Ventes", callback_data=CB + "ast")])
    await _send(update, "\n".join(lines), _nav(rows))


def _cycle(values, cur):
    vals = list(values)
    i = min(range(len(vals)), key=lambda k: abs(vals[k] - cur))
    return vals[(i + 1) % len(vals)]


async def show_item_admin(update: Update, uid: int, key: str, note: str = "") -> None:
    if await _level(uid) < LVL_EDIT:
        return
    it = await shop.get_item(key)
    if not it:
        await show_admin(update, uid)
        return
    m = shop.meta(it)
    ok, why = shop.visible(it, True)
    lines = [f"🛠️ <b>{m['label']}</b>\n{SEP}"] + ([note] if note else []) + [
        f"État : {'🟢 visible' if ok else '⚪ ' + why}", f"💰 Prix : <b>{it['stars']} ⭐</b> · promo : <b>{it['promo_pct']} %</b>",
        f"📦 Stock : <b>{'illimité' if it['stock'] < 0 else str(it['sold']) + '/' + str(it['stock'])}</b>",
        f"⏳ Fin : <b>{time.strftime('%d/%m %H:%M', time.gmtime(it['ends_at'])) if it['ends_at'] else 'aucune'}</b>",
        f"🌟 À la une : <b>{'oui' if it['featured'] else 'non'}</b>"
        + (" · 💰 vend de l'argent" if it["money_item"] else "")]
    k = key
    rows = [[B("🔴 Désactiver" if it["active"] else "🟢 Activer", callback_data=f"{CB}as:{k}:active:{0 if it['active'] else 1}"),
             B("🌟 Retirer de la une" if it["featured"] else "🌟 Mettre à la une", callback_data=f"{CB}as:{k}:featured:{0 if it['featured'] else 1}")],
            [B("➖ 10 ⭐", callback_data=f"{CB}as:{k}:stars:{max(1, it['stars'] - 10)}"), B("➕ 10 ⭐", callback_data=f"{CB}as:{k}:stars:{it['stars'] + 10}")],
            [B(f"🏷️ Promo → {_cycle(shop.PROMO_STEPS, it['promo_pct'])} %", callback_data=f"{CB}as:{k}:promo_pct:{_cycle(shop.PROMO_STEPS, it['promo_pct'])}"),
             B(f"📦 Stock → {'∞' if _cycle(shop.STOCK_STEPS, it['stock']) < 0 else _cycle(shop.STOCK_STEPS, it['stock'])}",
               callback_data=f"{CB}as:{k}:stock:{_cycle(shop.STOCK_STEPS, it['stock'])}")],
            [B("⏳ Édition limitée : 24 h", callback_data=f"{CB}aw:{k}:24"), B("3 j", callback_data=f"{CB}aw:{k}:72"),
             B("7 j", callback_data=f"{CB}aw:{k}:168"), B("∞", callback_data=f"{CB}aw:{k}:0")],
            [B("🧪 Tester l'achat (sans paiement)", callback_data=f"{CB}at:{k}")]]
    await _send(update, "\n".join(lines), _nav(rows, back=CB + "adm:0", back_label="⬅️ Catalogue"))


async def show_orders(update: Update, uid: int, note: str = "") -> None:
    if await _level(uid) < LVL_MONEY:
        return
    orders = await shop.attention_orders()
    lines = [f"📦 <b>COMMANDES À TRAITER</b>\n{SEP}"] + ([note] if note else [])
    rows = []
    if not orders:
        lines.append("✅ Aucune commande en suspens.")
    for o in orders:
        lines.append(f"• #{o['id']} joueur <code>{o['user_id']}</code> · {o['item_key']} · {o['stars_paid']} ⭐ · {o['status']} ({o['attempts']} essai(s))"
                     + (f"\n   <i>{esc(o['error'])}</i>" if o["error"] else ""))
        rows.append([B(f"🔁 Réessayer #{o['id']}", callback_data=f"{CB}ar:{o['id']}"), B(f"💸 Rembourser #{o['id']}", callback_data=f"{CB}af:{o['id']}")])
    await _send(update, "\n".join(lines), _nav(rows, back=CB + "adm:0", back_label="⬅️ Catalogue"))


async def show_stats(update: Update, uid: int) -> None:
    if await _level(uid) < LVL_MONEY:
        return
    s7, s30 = await shop.stats(7), await shop.stats(30)
    lines = [f"📊 <b>VENTES</b>\n{SEP}",
             f"7 jours : <b>{s7['stars']} ⭐</b> · {s7['orders']} commande(s) · {s7['buyers']} acheteur(s)",
             f"30 jours : <b>{s30['stars']} ⭐</b> · {s30['orders']} commande(s) · {s30['buyers']} acheteur(s)",
             f"Remboursements (30 j) : {s30['refunded']}", "", "<b>Top articles (7 j)</b>"]
    for t in s7["top"]:
        it = await shop.get_item(t["item_key"])
        lines.append(f"• {shop.meta(it)['label'] if it else t['item_key']} — {t['n']} vente(s), {t['s']} ⭐")
    if not s7["top"]:
        lines.append("Aucune vente.")
    await _send(update, "\n".join(lines), _nav(back=CB + "adm:0", back_label="⬅️ Catalogue"))


@flow("sh_new")
async def _flow_new(update, context, value, data):
    uid = update.effective_user.id
    if data.get("step") == "label":
        await ask(update, context, "sh_new", f"💰 Prix en Étoiles de « <b>{esc(str(value)[:40])}</b> » ? (un nombre, ex. 30)",
                  kind="text", data={"step": "price", "label": str(value)[:40]}, back=CB + "adm:0")
        return
    try:
        stars = max(1, min(5000, int(str(value).strip())))
    except ValueError:
        await ask(update, context, "sh_new", "❌ Entre un nombre (ex. 30) :", kind="text", data=data, back=CB + "adm:0")
        return
    code = await shop.create_custom(data["label"], stars, stock=50, hours=72)
    await show_item_admin(update, uid, code, "✅ Exclusivité créée (50 exemplaires, 72 h, à la une). Ajuste-la ci-dessous.")


# ─────────────────────────────────────────────────────────────────────────────
#  Entrées
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_boutique(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update, update.effective_user.id)


async def star_redirect(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Anciens boutons « star_… » / « starbuy:… » : ils ouvrent la nouvelle boutique."""
    q = update.callback_query
    await q.answer()
    uid = q.from_user.id
    data = q.data or ""
    if data == "star_close":
        try:
            await q.message.delete()
        except Exception:
            swallowed('handlers/boutique.py')
    elif data.startswith("starbuy:"):
        await show_item(update, uid, data.split(":", 2)[-1])
    elif data == "star_vip":
        await show_category(update, uid, "pass")
    elif data.startswith("star_cat:") and data.split(":")[-1].isdigit():
        await show_category(update, uid, shop._CAT_OF_ID.get(int(data.split(":")[-1]), "upgrade"))
    elif data != "star_noop":
        await show_home(update, uid)


async def sh_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    p = (q.data or "").split(":")
    act = p[1] if len(p) > 1 else "home"
    a = p[2:] + ["", "", ""]
    try:
        await q.answer()
        lvl = await _level(uid)
        if act == "c":
            await show_category(update, uid, a[0], int(a[1]) if a[1].isdigit() else 0)
        elif act == "i":
            await show_item(update, uid, a[0])
        elif act == "buy":
            await checkout(update, context, uid, a[0], int(a[1]) if a[1].lstrip("-").isdigit() else uid)
        elif act == "gift":
            await ask(q, context, "sh_gift", "🎁 À qui offrir ? Envoie son <b>@pseudo</b> ou son <b>ID</b>.", kind="user",
                      data={"key": a[0]}, back=f"{CB}i:{a[0]}")
        elif act == "hist":
            await show_history(update, uid)
        elif act == "loy":
            await show_loyalty(update, uid)
        elif act == "coll":
            await show_collection(update, uid)
        elif act == "claim" and a[0].isdigit():
            ok, msg = await shop.claim_reward(uid, int(a[0]), apply_item)
            await show_loyalty(update, uid, ("🎉 " if ok else "ℹ️ ") + esc(msg))
        elif act == "adm":
            await show_admin(update, uid, int(a[0]) if a[0].isdigit() else 0)
        elif act == "ai":
            await show_item_admin(update, uid, a[0])
        elif act == "as" and lvl >= LVL_EDIT:
            field = {"promo_pct": "promo_pct"}.get(a[1], a[1])
            await shop.set_field(a[0], field, int(a[2]))
            await show_item_admin(update, uid, a[0], "✅ Enregistré.")
        elif act == "aw" and lvl >= LVL_EDIT:
            hours = int(a[1])
            await shop.set_field(a[0], "ends_at", int(time.time()) + hours * 3600 if hours else 0)
            await show_item_admin(update, uid, a[0], "✅ Fenêtre mise à jour." if hours else "✅ Sans limite de temps.")
        elif act == "at" and lvl >= LVL_EDIT:
            it = await shop.get_item(a[0])
            oid, _ = await shop.create_order(f"TEST-{uid}-{int(time.time() * 1000)}", uid, uid, a[0], it["kind"], 0, test=True)
            st, txt = await shop.deliver(oid, apply_item)
            await show_item_admin(update, uid, a[0], "🧪 " + esc(txt if st != "delivered" else f"Test réussi : {txt}"))
        elif act == "an" and lvl >= LVL_EDIT:
            await ask(q, context, "sh_new", "🌟 <b>Nouvelle exclusivité</b>\nQuel est son <b>nom</b> ? (ex. « 🎄 Couronne de Noël »)",
                      kind="text", data={"step": "label"}, back=CB + "adm:0")
        elif act == "ao":
            await show_orders(update, uid)
        elif act == "ar" and lvl >= LVL_MONEY and a[0].isdigit():
            await shop.mark(int(a[0]), "failed", "")
            st, txt = await shop.deliver(int(a[0]), apply_item)
            await show_orders(update, uid, f"🔁 #{a[0]} : {esc(st)} {esc(str(txt))[:80]}")
        elif act == "af" and lvl >= LVL_MONEY and a[0].isdigit():
            order = await shop.get_order(int(a[0]))
            ok = bool(order) and await refund(order, "remboursement par la direction")
            await show_orders(update, uid, f"{'💸 Remboursé' if ok else '⚠️ Remboursement impossible'} (#{a[0]}).")
        elif act == "ast":
            await show_stats(update, uid)
        else:
            await show_home(update, uid)
    except Exception:
        logger.exception("Boutique : erreur sur %s", q.data)
