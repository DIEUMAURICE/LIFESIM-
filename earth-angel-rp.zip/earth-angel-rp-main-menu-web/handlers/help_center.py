"""
handlers/help_center.py — 📖 Centre d'aide et d'apprentissage
═══════════════════════════════════════════════════════════════════════
Remplace /aide, /guide et la page « Aide » du menu. Pages courtes (lisibles sur
téléphone), classées dans l'ordre où un nouveau joueur en a besoin.
Callbacks : help:home · help:<page> · help:news
"""
from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from config import GAME_LORE, GAME_NAME, GAME_PANTHEON, GAME_PHASES, GAME_TAGLINE

SEP = "━━━━━━━━━━━━━━━━━━"

# (clé, bouton, titre, contenu)
PAGES: list[tuple[str, str, str, str]] = [
    ("lore", "📜 L'histoire", "L'HISTOIRE D'EARTH ANGEL", GAME_LORE),

    ("phases", "🌗 Les 3 phases", "TON DESTIN EN 3 PHASES",
     "\n\n".join(f"{i} <b>{t}</b>{'' if ok else ' <i>(bientôt)</i>'}\n{d}" for i, t, d, ok in GAME_PHASES)
     + "\n\n" + GAME_PANTHEON),

    ("start", "🚀 Premiers pas", "PREMIERS PAS",
     "Tu apparais sur Terre en <b>humain</b> : <b>18 ans</b>, une grande métropole, <b>10 000 €A</b> et un job de <b>livreur</b>.\n\n"
     "<b>Ta routine de départ</b>\n"
     "1. 💼 <b>Économie</b> → récupère ton <b>bonus quotidien</b>\n"
     "2. 💼 <b>Économie</b> → <b>Travailler</b> (possible toutes les heures de jeu)\n"
     "3. 🧬 <b>Vie</b> → mange et dors quand les jauges baissent\n"
     "4. 🎮 <b>Progression</b> → suis le <b>tutoriel</b> : il te donne des récompenses\n"
     "5. 🎯 <b>Missions</b> → fais celles du jour pour gagner de l'XP\n\n"
     "<i>Tout se fait depuis 🎮 Menu → 🎮 Menu principal : aucune commande à retenir.</i>"),

    ("survive", "❤️ Survivre", "SURVIVRE",
     "Ton personnage a 5 jauges (menu 🧬 <b>Vie</b>) :\n\n"
     "❤️ <b>Santé</b> — à 0 %, tu es à terre : va à l'hôpital pour te soigner\n"
     "⚡ <b>Énergie</b> — nécessaire pour travailler, étudier, agir\n"
     "🍽️ <b>Faim</b> — mange pour la restaurer\n"
     "😊 <b>Bonheur</b> — augmente tes chances de réussir\n"
     "😰 <b>Stress</b> — au-dessus de 70 %, il détruit ta santé\n\n"
     "<b>Réflexes à prendre</b>\n"
     "• Dormir redonne de l'énergie, manger calme la faim\n"
     "• Hôpital, médecin et assurance soignent et protègent"),

    ("health", "🏥 Santé publique", "SANTÉ PUBLIQUE",
     "<b>Se soigner</b> (menu Vie → Hôpital)\n"
     "• 🚑 <b>Ambulance</b> : gratuite ; les soignants EN SERVICE sont prévenus et viennent te soigner\n"
     "• 🏥 <b>Hôpital</b> : va-y (trajet), puis consultation payante (l'assurance réduit le prix)\n"
     "• 🛏️ <b>Lit</b> : gratuit, reste 2 min au moins ; lits limités et partagés entre tous les joueurs\n"
     "• 💊 <b>Médicaments</b> : fabriqués par les employés de la faction ; achetés = argent versé à son coffre\n"
     "• 🛡️ <b>Assurance</b> : réduit le prix des consultations et des médicaments (1 mois de jeu)\n\n"
     "<b>Y travailler</b> (menu État & factions → Rejoindre une faction)\n"
     "Récolteur → Technicien de labo → Opérateur industriel fabriquent les médicaments ; "
     "Ambulancier, Infirmier, Médecin, Chirurgien soignent. Chaque poste a son salaire <b>par heure de jeu</b>, "
     "payé par le coffre général. 1 grand hôpital (PDG) + 4 petits (DG) : la direction recrute, promeut et renvoie ; "
     "les admins surveillent."),

    ("money", "💰 Gagner de l'argent", "GAGNER DE L'ARGENT",
     "<b>Revenus réguliers</b>\n"
     "• Bonus quotidien (toutes les 24 h réelles) + travail toutes les heures de jeu\n"
     "• Un meilleur <b>diplôme</b> débloque des métiers mieux payés (🎓 Carrière)\n"
     "• Monte en <b>rang</b> dans ton métier (🎖️ Promotion) : plus de gains et de biens\n\n"
     "<b>Faire fructifier</b>\n"
     "• 🏦 L'argent en banque rapporte des intérêts ; un prêt se rembourse\n"
     "• 🏠 Un bien immobilier peut rapporter des loyers\n"
     "• 📈 La bourse récompense la patience\n"
     "• 🏢 Une entreprise rapporte, mais demande de la gestion\n"
     "• 🏪 Le marché te permet de vendre aux autres joueurs (annonces valables 7 jours)\n\n"
     "<b>À savoir</b> : les gros transferts sont taxés de 1 % (au-dessus de 100 000 €A pour un paiement, 50 000 €A pour un don)."),

    ("chain", "🏭 Métiers & entreprises", "MÉTIERS ET ENTREPRISES",
     "<b>🛠️ Les métiers (personnel)</b>\n"
     "Chaque mission te paie tout de suite <b>et</b> te fait gagner des <b>biens</b> (matières, transport, création…). "
     "Tu les vends aux entreprises qui en ont besoin (🎮 Carrière → Mes biens) au prix qu'elles affichent, "
     "ou au comptoir national si personne n'achète.\n"
     "🎖️ <b>Promotion</b> : Apprenti → Compagnon → Confirmé → Expert → Maître → Grand maître. Il faut des missions, "
     "des compétences et parfois un diplôme. Chaque rang augmente gains et biens ; dès Confirmé, les "
     "<b>grandes commandes</b> (gros gains, repos plus long) s'ouvrent.\n\n"
     "<b>🏭 Les entreprises</b>\n"
     "Chaque secteur a ses équipes et ses 2 produits finis, fabriqués en plusieurs étapes à partir des biens des "
     "métiers. Tes employés produisent quand ils sont <b>en service</b>, chacun dans son équipe : "
     "l'entreprise produit <b>à chaque heure de jeu</b> ; le « 📖 Guide pas à pas » de la chaîne te dit où tu en es. "
     "Une entreprise grandit : Atelier → PME → Entreprise → Groupe → Multinationale (plus de lignes et de capacité).\n\n"
     "<b>🛒 Les produits finis</b>\n"
     "• <b>Biens</b> (repas, carburant, pièces, pare-feu…) : les commerçants les achètent en gros (🏪 Marché → Grossiste) "
     "et les revendent ; tu les utilises depuis Marché → Mes objets.\n"
     "• <b>Services</b> (menu gastronomique, séance de sport…) : un employé en service te les rend (🏪 Marché → Prestations).\n"
     "📚 Le <b>Catalogue des secteurs</b> (🏢 Entreprises → Production) montre ce que fait chaque produit."),

    ("progress", "📈 Progresser", "PROGRESSER",
     "• <b>XP et niveau</b> : missions, études, arène, activités\n"
     "• <b>Études</b> : passe des diplômes pour accéder aux meilleurs jobs\n"
     "• <b>Compétences</b> : forme-toi pour les améliorer\n"
     "• <b>Missions</b> : quotidiennes, hebdomadaires et livraisons\n"
     "• <b>Succès, badges et titres</b> : récompensent tes exploits\n"
     "<i>Le tutoriel (🎮 Progression) te guide à travers les 8 premières étapes.</i>"),

    ("social", "🌐 Réseau RP", "LE RÉSEAU ENTRE JOUEURS",
     "Un seul réseau : ce que tu publies est lu, liké et commenté par les autres joueurs.\n\n"
     "<b>Menu → 🌐 Réseaux sociaux → Réseau RP</b>\n"
     "• ✍️ <b>Publier</b> sur 6 plateformes avec des <b>#hashtags</b> (+40 XP, 1 post toutes les 2 h de jeu)\n"
     "• 📰 <b>Mon fil</b> · 🔥 <b>Explorer</b> · #️⃣ <b>Tendances</b>\n"
     "• ❤️ likes, 💬 commentaires, ➕ abonnements, 💌 messages privés, 👤 profils\n"
     "• 👥 <b>Communauté</b> : hashtag officiel, fil et <b>sondages</b> réservés aux membres\n"
     "• 🗳️ <b>Sondages</b> : vote (+1 SocialCoin) et résultats en direct\n\n"
     "Un abonné réel te rapporte de l'audience. Le staff peut retirer un post ou mettre un joueur en sourdine 24 h.\n"
     "<i>Live, story, collaborations et analyses se trouvent dans la même zone.</i>"),

    ("family", "👪 Famille & clan", "FAMILLE, AMIS ET CLAN",
     "<b>Les liens</b> (Menu → 👥 Multijoueur & famille)\n"
     "• 🤗 <b>Amis</b> : ajoute et retire des amis ; ils comptent pour les échanges et cadeaux\n"
     "• 💍 <b>Mariage</b> : demande, acceptation, divorce ; le couple partage une vie RP\n"
     "• 👶 <b>Adoption</b> et 🌳 <b>arbre généalogique</b> : ta lignée\n"
     "• 🛡️ <b>Clan</b> : un chef, des membres, des invitations ; transfert de chef ou dissolution\n\n"
     "<b>Jouer en famille</b>\n"
     "Échanges sécurisés et cadeaux entre proches, messages privés du 🌐 Réseau RP, "
     "entreprises montées à plusieurs. Une famille soudée progresse plus vite qu'un joueur seul."),

    ("study", "🎓 Études & cours", "ÉTUDES ET COURS",
     "<b>Réviser = recevoir un cours.</b> L'examen pose des questions sur les cours que tu as révisés.\n\n"
     "1. Menu → 🎓 Carrière → <b>Étudier</b> : choisis un diplôme (temps de formation + prix)\n"
     "2. <b>Réviser</b> : chaque cours coûte 15 d'énergie (5 cours max par formation)\n"
     "3. <b>Examen</b> : plus tu as révisé, plus tu réussis ; un échec coûte un tiers du prix\n"
     "4. <b>Mes cours</b> : relis ce que tu as appris\n\n"
     "Du <b>Brevet</b> au <b>Doctorat honoris causa</b> : 11 diplômes, dont l'<b>École de commerce</b> et la <b>Grande École</b>.\n"
     "<b>Les cours couvrent tout le jeu</b> : économie, crimes et justice, factions, entreprises, santé, politique, "
     "mais aussi le 🌐 réseau, la 👪 famille, le logement et la progression. "
     "Étudier est la meilleure façon de comprendre le jeu <i>et</i> de débloquer de meilleurs métiers."),

    ("staff", "🛠️ Pour les admins", "CONSOLE DU STAFF",
     "<b>Menu → 📜 Profil & infos → 🛠️ Console staff</b>\n\n"
     "• 🔁 <b>Transition du bot</b> (Game Leader+) : le bot fournit et achète encore (fournisseur, marché et comptoir "
     "nationaux). Quand les entreprises produisent et vendent seules, tu <b>réduis puis fermes</b> ces rôles — "
     "avec des indicateurs de relais\n"
     "• 🎁 <b>Récompenses du bot</b> : bonus, missions, succès, tutoriel, compétitions, voyages (0 à 200 %)\n"
     "• 📊 <b>Économie</b> : argent en circulation, créé par le bot, récupéré par le Trésor public\n"
     "• ⚙️ <b>Réglages</b> : réseau RP, abonnés offerts, 💳 <b>paiements réels</b> (<b>Lead Principal</b> seul)\n"
     "• 📜 <b>Journal</b> de tous les changements · 🛡️ modération du réseau\n\n"
     "<i>Hiérarchie : Lead Principal › Lead Studio › Lead Staff › Game Leader › Admin N2 › Admin N1.</i>"),

    ("rules", "📜 Règlement RP", "RÈGLEMENT DU JEU",
     "<b>Menu → 📜 Profil & infos → Règles du jeu</b>\n\n"
     "• Vis ton personnage : pas de métagaming, pas de powergaming, fair-play\n"
     "• Ceux qui ont du pouvoir (police, justice, Administration…) servent le jeu, pas eux-mêmes\n"
     "• Les <b>chefs de faction</b> sont nommés par le staff après un <b>entretien RP</b>\n"
     "• Sanctions graduées : avertissement, sourdine, suspension, bannissement\n\n"
     "<i>Ici, on ne joue pas seulement : on vit. Chaque histoire compte.</i>"),

    ("treasury", "🏛️ Trésor public", "TRÉSOR PUBLIC ET ADMINISTRATION",
     "<b>Menu → 🎖️ État & factions → Trésor public</b>\n\n"
     "• Ce que les joueurs dépensent envers le jeu (études, casino, transports, état civil, politique…) "
     "et l'impôt sur la fortune arrivent dans le <b>Trésor public</b>\n"
     "• Tout le monde voit le solde et d'où vient l'argent\n"
     "• Le <b>Président</b> redistribue le Trésor à toutes les factions ; chaque <b>ministre</b> alimente la faction "
     "qu'il dirige (Intérieur → Police, Défense → Armée, Justice, Santé, Économie → Administration)\n"
     "• Le <b>Ministre de l'Économie</b> (ou le Président) règle le coefficient de l'impôt sur la fortune (×0,5 à ×1,5)\n"
     "• Garde-fous : dotation minimale, jamais plus de la moitié du Trésor d'un coup, tout est journalisé\n\n"
     "<i>Quand un Président ou un ministre est en place, c'est lui qui répartit : le bot ne verse plus que la dotation de base.</i>"),

    ("character", "🪪 Mon personnage", "TON PERSONNAGE",
     "<b>Menu → 📜 Profil & infos → Identité → Mon personnage</b>\n\n"
     "Crée ton personnage en 11 étapes : prénom, nom, <b>sexe</b>, ville d'origine, silhouette, teint, cheveux, "
     "tenue, deux traits de caractère et une histoire.\n\n"
     "• Ton <b>avatar</b> se compose tout seul (ex. 👩🏽‍🦱) et ta <b>carte d'identité</b> apparaît sur ton profil\n"
     "• Tu peux quitter et reprendre la création, et tout modifier plus tard\n"
     "• Ce sont des choix de personnalité : ils ne changent ni l'argent, ni l'XP, ni la production"),

    ("shop", "🛍️ Boutique", "LA BOUTIQUE",
     "<b>Menu → 🏎️ Véhicules & luxe → Boutiques → 🛍️ Boutique</b>\n\n"
     "• ⭐ <b>Offre du jour</b> et 🎁 <b>offre de bienvenue</b> (−40 % sur le pack de départ, une seule fois)\n"
     "• 🌟 <b>Éditions limitées</b> : stock et durée affichés, parfois pour les fêtes\n"
     "• 🎁 <b>Offrir</b> un article à un autre joueur\n"
     "• 🏅 <b>Fidélité</b> : chaque palier d'Étoiles dépensées offre un cosmétique\n"
     "• 🧾 <b>Mes achats</b> : l'historique de tes commandes\n\n"
     "<b>Sécurité</b> : paiement par Étoiles Telegram, une commande n'est jamais livrée deux fois, et si la livraison "
     "échoue tu es <b>remboursé automatiquement</b>. Le Lead Principal contrôle les paiements réels."),

    ("people", "👥 Vivre avec les autres", "VIVRE AVEC LES AUTRES",
     "• 🌐 <b>Réseau RP</b> : publie, like, commente, suis et écris aux joueurs (voir 🌐 Réseau RP)\n"
     "• 👥 <b>Famille et clan</b> : amis, mariage, adoption (voir 👪 Famille)\n"
     "• 🤝 <b>Échanges sécurisés</b> et cadeaux entre joueurs\n"
     "• 🏢 <b>Entreprises</b> : fonde la tienne ou postule dans une autre\n"
     "• 🏛️ <b>Politique</b> : élections, lois, référendums\n\n"
     "<b>Pour désigner un joueur</b>, envoie son <b>@pseudo</b> ou son <b>ID</b> quand le jeu te le demande."),

    ("risk", "🔫 Risques & société", "RISQUES ET SOCIÉTÉ",
     "<b>Le crime</b> rapporte vite mais coûte cher : chaque crime a un taux de réussite, des gains, une peine de prison et un impact sur ton <b>karma</b>.\n\n"
     "<b>Si tu es arrêté</b> : paie la <b>caution</b>, prends un <b>avocat</b> ou passe au <b>tribunal</b>.\n\n"
     "<b>Les gangs</b> : en créer un coûte 50 000 €A ; ils ont une caisse commune et des hold-ups collectifs.\n\n"
     "<b>⚖️ Le karma</b> influence tout : succès, salaires, événements. Les bonnes actions le font monter, les crimes le font baisser.\n\n"
     "<b>Marché noir et hack</b> : actions illégales à fort risque."),

    ("where", "🧭 Où trouver quoi", "OÙ TROUVER QUOI",
     "• 🎮 <b>Menu principal</b> : le menu unique du jeu, avec toutes les actions rangées par zone\n"
     "• 📱 <b>Téléphone</b> : banque, garage, réseaux, inventaire, classements au même endroit\n\n"
     "<b>Comment se repérer ?</b>\n"
     "Menu → zone → rubrique → action. Chaque écran a son « ⬅️ Retour » et son « 🎮 Menu principal ». "
     "<b>Quand le jeu te pose une question</b>, réponds par un message (ex : <code>2k</code>, <code>50%</code>, <code>tout</code>, ou un @pseudo). Appuie sur ❌ <b>Annuler</b> pour abandonner."),

    ("roadmap", "🗺️ Feuille de route", "ÉTAT DU JEU ET À VENIR",
     "<b>✅ Disponible</b>\n"
     "Économie, banques, immobilier, bourse, entreprises, marché, études et métiers, santé publique, "
     "factions, police et justice, crime et gangs, politique, réseaux sociaux, famille, véhicules, casino, jardin, téléphone.\n\n"
     "<b>🛠️ En préparation</b>\n"
     + "\n".join(f"{i} <b>{t}</b>" for i, t, _d, ok in GAME_PHASES if not ok)
     + "\n\n<i>Ces phases s'ouvriront quand les joueurs auront bâti leur monde : "
       "les annonces sont publiées dans 🆕 Nouveautés.</i>"),

    ("tips", "💡 Astuces", "ASTUCES",
     "• Reviens au moins <b>une fois par jour</b> : certaines pénalités s'accumulent en ton absence\n"
     "• Garde un œil sur ton <b>stress</b> avant qu'il ne dépasse 70 %\n"
     "• Entretiens tes <b>véhicules</b> : leur état se dégrade et le carburant se consomme chaque jour\n"
     "• Le <b>casino</b> n'est ouvert que la nuit (17 h à 5 h, heure du jeu)\n"
     "• Les <b>diplômes</b> sont le moyen le plus sûr d'augmenter ton salaire\n"
     "• Avant un gros achat, vérifie ton <b>solde</b> dans 💼 Économie"),

    ("faq", "❓ Questions fréquentes", "QUESTIONS FRÉQUENTES",
     "<b>Une saisie est restée ouverte ?</b>\nAppuie sur ❌ Annuler. Elle expire d'elle-même après 5 minutes.\n\n"
     "<b>Je ne trouve pas une action.</b>\nOuvre le 🎮 Menu principal : toutes les actions y sont, avec leur zone.\n\n"
     "<b>Mon joueur est « introuvable ».</b>\nVérifie le @pseudo (ou utilise l'ID) : il doit être inscrit au jeu.\n\n"
     "<b>Un bug ?</b>\nMenu → ❓ Aide → Report."),
]
_BY_KEY = {k: (b, t, c) for k, b, t, c in PAGES}


def _nav(extra: list | None = None) -> InlineKeyboardMarkup:
    rows = list(extra or [])
    rows.append([InlineKeyboardButton("📖 Aide", callback_data="help:home"),
                 InlineKeyboardButton("🧭 Gameplay", callback_data="hub:home")])
    rows.append([InlineKeyboardButton("🎮 Menu principal", callback_data="menu_main")])
    return InlineKeyboardMarkup(rows)


def home_text() -> str:
    return (f"📖 <b>AIDE — {GAME_NAME}</b>\n{SEP}\n"
            f"<i>{GAME_TAGLINE}</i>\n\n"
            "Choisis un sujet. Chaque page tient en un écran.\n\n"
            "<i>Nouveau ? Lis 📜 L'histoire, puis 🚀 Premiers pas.</i>")


def home_markup() -> InlineKeyboardMarkup:
    btns = [InlineKeyboardButton(b, callback_data=f"help:{k}") for k, b, _, _ in PAGES]
    rows = [btns[i:i + 2] for i in range(0, len(btns), 2)]
    rows.append([InlineKeyboardButton("🆕 Nouveautés", callback_data="help:news"),
                 InlineKeyboardButton("🎓 Tutoriel", callback_data="help:tuto")])
    rows.append([InlineKeyboardButton("🎮 Menu principal", callback_data="menu_main")])
    return InlineKeyboardMarkup(rows)


def page_text(key: str) -> str:
    _b, title, content = _BY_KEY[key]
    return f"📖 <b>{title}</b>\n{SEP}\n{content}"


async def send_home(update) -> None:
    """Pour les anciennes commandes le menu et le menu."""
    await update.message.reply_text(home_text(), parse_mode="HTML", reply_markup=home_markup())


async def show_home(query) -> None:
    await query.edit_message_text(home_text(), parse_mode="HTML", reply_markup=home_markup())


async def help_callback(update, context) -> None:
    q = update.callback_query
    await q.answer()
    key = q.data.split(":", 1)[1]
    if key == "home":
        await show_home(q)
    elif key == "news":
        from handlers.general import cmd_nouveautes
        from utils.input_flow import call_cmd
        await call_cmd(q, context, cmd_nouveautes, [])
    elif key == "tuto":
        from handlers.progression import cmd_tutorial
        from utils.input_flow import call_cmd
        await call_cmd(q, context, cmd_tutorial, [])
    elif key in _BY_KEY:
        idx = [k for k, *_ in PAGES].index(key)
        prev_k = PAGES[idx - 1][0] if idx > 0 else None
        next_k = PAGES[idx + 1][0] if idx < len(PAGES) - 1 else None
        row = []
        if prev_k:
            row.append(InlineKeyboardButton("◀️", callback_data=f"help:{prev_k}"))
        if next_k:
            row.append(InlineKeyboardButton("▶️", callback_data=f"help:{next_k}"))
        await q.edit_message_text(page_text(key), parse_mode="HTML",
                                  reply_markup=_nav([row] if row else None))
    else:
        await show_home(q)
