# handlers/reseau.py — 🌐 Réseau RP entre joueurs (100 % boutons, préfixe `rs:`)
"""
Un vrai réseau social ENTRE JOUEURS :
  • ✍️ publier sur une plateforme (YouTube, Instagram, TikTok…) : tes posts sont lus par les autres
  • 📰 fil « abonnements » et 🔥 « explorer » ; ❤️ likes, 💬 commentaires
  • ➕ abonnements réels, 👤 profils, 💌 messages privés (livrés par notification)
  • 🛡️ modération : l'auteur ou le staff supprime ; le staff peut mettre un joueur en sourdine
Les gains sont à la charge des autres joueurs : on est lu, liké et suivi pour de vrai.
Le staff peut couper tout le réseau (réglage « Réseau RP » de la console staff).
"""
from utils.swallow import swallowed
from utils.ui import esc
import html
import json
import logging
import re
import time

try:
    from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M, Update
except ImportError:  # tests unitaires qui fournissent un stub minimal de telegram
    from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M
    Update = object
try:
    from telegram.ext import ContextTypes
except ImportError:  # stub Telegram utilisé par les tests de helpers
    class ContextTypes:
        DEFAULT_TYPE = object

from config import SOCIAL_PLATFORMS, role_level
from database import db_connection, get_user, update_field
from utils import gamerules as gr
from utils.decorators import get_user_role_async, require_registered
from utils.input_flow import ask, flow
from utils.notify import notify
from utils.reseau_rules import (
    COMMENT_MAX, COMMENTS_PER_POST, DM_MAX, DMS_PER_HOUR, FOLLOW_BONUS_FOLLOWERS, MUTE_HOURS, POST_COOLDOWN_HOURS,
    POST_MAX, XP_POST,
)
from gameplay.social_polls import PollError, close_poll, create_poll as create_shared_poll, vote_poll
logger = logging.getLogger(__name__)
CB = "rs:"
SEP = "━━━━━━━━━━━━━━━━━━"

LIKE_MILESTONES = (1, 5, 10, 25, 50, 100, 250, 500, 1000)
FEED_WINDOW = 3 * 86400
MUTE_SECONDS = MUTE_HOURS * 3600
PLATFORM_ICON = {"YouTube": "▶️", "Instagram": "📸", "TikTok": "🎵", "Twitter": "🐦", "Twitch": "🎮", "Podcast": "🎙️"}


def _e(s) -> str:
    return esc(str(s))


def _ts() -> int:
    return int(time.time())


def _ago(ts: int) -> str:
    d = max(0, _ts() - int(ts))
    if d < 60:
        return "à l'instant"
    if d < 3600:
        return f"il y a {d // 60} min"
    if d < 86400:
        return f"il y a {d // 3600} h"
    return f"il y a {d // 86400} j"


async def _send(update: Update, text: str, markup: M) -> None:
    q = update.callback_query
    if q:
        try:
            await q.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
            return
        except Exception:
            await q.message.reply_text(text, parse_mode="HTML", reply_markup=markup)
            return
    await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


async def _name(uid: int) -> str:
    u = await get_user(uid)
    return u.get("full_name") or (("@" + u["username"]) if u.get("username") else str(uid))


async def _is_staff(uid: int) -> bool:
    return role_level(await get_user_role_async(uid)) >= role_level("ADMIN_N1")


async def _muted(uid: int) -> int:
    async with db_connection() as db:
        async with db.execute("SELECT until FROM rp_mutes WHERE user_id=?", (uid,)) as cur:
            row = await cur.fetchone()
    return int(row[0]) if row and int(row[0]) > _ts() else 0


async def _gate(update: Update, uid: int, writing: bool = False) -> str | None:
    """Message de refus si le réseau est coupé ou si le joueur est en sourdine (écriture)."""
    if not await gr.switch_on("rp_network"):
        return "🌐 Le réseau est momentanément fermé par le staff."
    if writing:
        until = await _muted(uid)
        if until:
            return f"🔇 Tu es en sourdine sur le réseau pour encore {max(1, (until - _ts()) // 60)} min."
    return None


def _nav(extra=None) -> M:
    rows = list(extra or [])
    rows.append([B("🌐 Réseau", callback_data=CB + "home"), B("🎮 Menu", callback_data="menu_main")])
    return M(rows)


# ─────────────────────────────────────────────────────────────────────────────
#  Accueil
# ─────────────────────────────────────────────────────────────────────────────
async def _stats(uid: int) -> dict:
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM rp_follows WHERE followee_id=?", (uid,)) as c:
            followers = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM rp_follows WHERE follower_id=?", (uid,)) as c:
            following = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*), COALESCE(SUM(likes),0) FROM rp_posts WHERE author_id=? AND deleted=0 AND kind='post'",
                              (uid,)) as c:
            posts, likes = await c.fetchone()
        async with db.execute("SELECT COUNT(*) FROM rp_dms WHERE to_id=? AND is_read=0", (uid,)) as c:
            unread = (await c.fetchone())[0]
    return {"followers": followers, "following": following, "posts": posts, "likes": likes, "unread": unread}


async def show_home(update: Update, uid: int, note: str = "") -> None:
    gate = await _gate(update, uid)
    if gate:
        await _send(update, gate, _nav())
        return
    s = await _stats(uid)
    lines = [f"🌐 <b>RÉSEAU RP</b>\n{SEP}"]
    if note:
        lines.append(note)
    lines += [f"👤 <b>{_e(await _name(uid))}</b>",
              f"👥 <b>{s['followers']}</b> abonnés · ➡️ <b>{s['following']}</b> abonnements",
              f"📝 <b>{s['posts']}</b> publications · ❤️ <b>{s['likes']}</b> likes reçus", "",
              "<i>Un seul réseau : ce que tu publies (ici ou via Publier) est lu par les autres joueurs.</i>"]
    dm = f"💌 Messages ({s['unread']})" if s["unread"] else "💌 Messages"
    rows = [[B("📰 Mon fil", callback_data=CB + "feed:fol:0"), B("🔥 Explorer", callback_data=CB + "feed:exp:0")],
            [B("✍️ Publier", callback_data=CB + "post"), B("👤 Mon profil", callback_data=f"{CB}pf:{uid}")],
            [B(dm, callback_data=CB + "inbox"), B("🔎 Trouver un joueur", callback_data=CB + "find")],
            [B("#️⃣ Tendances", callback_data=CB + "trend"), B("👥 Communauté", callback_data=CB + "co")],
            [B("🗳️ Sondages", callback_data=CB + "pl"), B("🏆 Les plus suivis", callback_data=CB + "top")]]
    try:                                               # 🌐 tout le social au même endroit (live, story, sondages…)
        from handlers.phone import _hub_cb
        more = [("🎥 Live", "live"), ("📸 Story", "story"), ("🤝 Collab", "collab"),
                ("📈 Analyses", "analytiques"), ("⭐ Noter", "noter_social"), ("💎 SocialCoins", "socialcoins")]
        btns = [B(lbl, callback_data=_hub_cb(fn, "social")) for lbl, fn in more]
        from utils.ui import esc, layout
        rows += layout(btns, per_row=2)
    except Exception:
        logger.exception("Raccourcis sociaux indisponibles")
    await _send(update, "\n".join(lines), M(rows + [[B("🎮 Menu principal", callback_data="menu_main")]]))


# ─────────────────────────────────────────────────────────────────────────────
#  Publier
# ─────────────────────────────────────────────────────────────────────────────
TAG_RE = re.compile(r"#([0-9A-Za-zÀ-ÿ_]{2,24})")
MAX_TAGS = 5


def extract_tags(text: str) -> list[str]:
    """Hashtags d'un texte : minuscules, uniques, 5 maximum (dans l'ordre d'apparition)."""
    seen: list[str] = []
    for m in TAG_RE.finditer(text or ""):
        tag = m.group(1).lower()
        if tag not in seen:
            seen.append(tag)
    return seen[:MAX_TAGS]


def slug(name: str) -> str:
    """Hashtag officiel d'une communauté : son nom sans espaces ni accents superflus."""
    s = re.sub(r"[^0-9A-Za-zÀ-ÿ_]", "", name or "").lower()
    return s[:24] or "communaute"


async def publish_post(uid: int, platform: str, text: str) -> int | list[str]:
    """Ajoute une publication au fil commun (utilisé par le Réseau RP ET par les posts classiques)
    et la compte sur le compte de la plateforme (nombre de posts, dernier post)."""
    muted_until = await _muted(uid)
    if muted_until:
        return [f"🔇 Tu es en sourdine sur le réseau pour encore {max(1, (muted_until - _ts()) // 60)} min."]
    text = str(text).strip()[:POST_MAX]
    async with db_connection() as db:
        cur = await db.execute("INSERT INTO rp_posts (author_id, platform, text, created_at) VALUES (?,?,?,?)",
                               (uid, platform, text, _ts()))
        post_id = cur.lastrowid
        for tag in extract_tags(text):
            await db.execute("INSERT OR IGNORE INTO rp_hashtags (post_id, tag, created_at) VALUES (?,?,?)",
                             (post_id, tag, _ts()))
        await db.execute("INSERT OR IGNORE INTO social_media (user_id, platform, followers, posts, revenue_per_day, last_post) "
                         "VALUES (?,?,0,0,0,0)", (uid, platform))
        await db.execute("UPDATE social_media SET last_post=? WHERE user_id=? AND platform=?", (_ts(), uid, platform))
        await db.commit()
    return post_id



async def show_platforms(update: Update, uid: int) -> None:
    gate = await _gate(update, uid, writing=True)
    if gate:
        await _send(update, gate, _nav())
        return
    btns = [B(f"{PLATFORM_ICON.get(p, '🌐')} {p}", callback_data=f"{CB}pp:{i}") for i, p in enumerate(SOCIAL_PLATFORMS)]
    rows = [btns[i:i + 2] for i in range(0, len(btns), 2)]
    await _send(update, f"✍️ <b>PUBLIER</b>\n{SEP}\nChoisis la plateforme. Ton post sera visible par tous les joueurs "
                        f"(max {POST_MAX} caractères). Ajoute des <b>#hashtags</b> pour être trouvé.\n<i>+{XP_POST} XP · 1 publication toutes les {POST_COOLDOWN_HOURS} h de jeu.</i>", _nav(rows))


@flow("rs_post")
async def _flow_post(update, context, value, data):
    """Un SEUL moteur de publication pour tout le jeu : celui du réseau social classique (`cmd_poster`),
    qui applique le délai, l'XP, l'audience et publie dans le fil des joueurs (voir publish_post)."""
    uid = update.effective_user.id
    platform = data["platform"]
    gate = await _gate(update, uid, writing=True)
    if gate:
        await _send(update, gate, _nav())
        return
    text = " ".join(str(value).split())
    official = data.get("tag")
    if official and f"#{official}" not in text.lower():
        text = f"{text} #{official}"
    text = text[:POST_MAX]
    from handlers.social import cmd_poster
    from utils.input_flow import call_cmd
    await call_cmd(update, context, cmd_poster, [platform, *text.split(" ")])


# ─────────────────────────────────────────────────────────────────────────────
#  Fil
# ─────────────────────────────────────────────────────────────────────────────
def _scope(mode: str, uid: int):
    """→ (WHERE, params, ORDER BY) pour un mode de fil : fol | exp | u<id>."""
    if mode.startswith("u") and mode[1:].isdigit():
        return "p.deleted=0 AND p.kind='post' AND p.author_id=?", [int(mode[1:])], "p.created_at DESC"
    if mode.startswith("#"):
        return ("p.deleted=0 AND p.kind='post' AND p.kind='post' AND p.id IN (SELECT post_id FROM rp_hashtags WHERE tag=?)", [mode[1:].lower()],
                "p.created_at DESC")
    if mode == "exp":
        return "p.deleted=0 AND p.kind='post' AND p.created_at>?", [_ts() - FEED_WINDOW], "p.likes DESC, p.created_at DESC"
    return ("p.deleted=0 AND p.kind='post' AND p.kind='post' AND p.created_at>? AND (p.author_id=? OR p.author_id IN "
            "(SELECT followee_id FROM rp_follows WHERE follower_id=?))",
            [_ts() - FEED_WINDOW, uid, uid], "p.created_at DESC")


async def show_feed(update: Update, uid: int, mode: str, offset: int, note: str = "") -> None:
    gate = await _gate(update, uid)
    if gate:
        await _send(update, gate, _nav())
        return
    where, params, order = _scope(mode, uid)
    async with db_connection() as db:
        async with db.execute(f"SELECT COUNT(*) FROM rp_posts p WHERE {where}", params) as c:
            total = (await c.fetchone())[0]
        offset = max(0, min(offset, max(0, total - 1)))
        async with db.execute(f"SELECT p.* FROM rp_posts p WHERE {where} ORDER BY {order} LIMIT 1 OFFSET ?",
                              params + [offset]) as c:
            post = await c.fetchone()
        liked = False
        if post:
            async with db.execute("SELECT 1 FROM rp_likes WHERE post_id=? AND user_id=?", (post["id"], uid)) as c:
                liked = await c.fetchone() is not None
            async with db.execute("SELECT 1 FROM rp_follows WHERE follower_id=? AND followee_id=?",
                                  (uid, post["author_id"])) as c:
                following = await c.fetchone() is not None
    title = {"fol": "📰 MON FIL", "exp": "🔥 EXPLORER"}.get(mode, f"#️⃣ {mode}" if mode.startswith("#") else "📝 PUBLICATIONS")
    if not post:
        hint = ("Abonne-toi à des joueurs ou publie ton premier post !" if mode == "fol"
                else "Aucune publication pour l'instant.")
        await _send(update, f"{title}\n{SEP}\n{note}\n{hint}".replace("\n\n\n", "\n\n"),
                    _nav([[B("🔥 Explorer", callback_data=CB + "feed:exp:0"),
                           B("✍️ Publier", callback_data=CB + "post")]]))
        return
    author = post["author_id"]
    icon = PLATFORM_ICON.get(post["platform"], "🌐")
    text = (f"{title}  ·  {offset + 1}/{total}\n{SEP}\n"
            + (f"{note}\n" if note else "")
            + f"{icon} <b>{_e(await _name(author))}</b> · {_e(post['platform'])}\n"
              f"<i>{_ago(post['created_at'])}</i>\n\n{_e(post['text'])}\n\n"
              f"❤️ <b>{post['likes']}</b>   💬 <b>{post['comments']}</b>")
    tail = f"{mode}:{offset}"
    rows = [[B(("💔 Retirer" if liked else "❤️ Liker") + f" ({post['likes']})", callback_data=f"{CB}lk:{post['id']}:{tail}"),
             B(f"💬 Commenter", callback_data=f"{CB}cm:{post['id']}"),
             B("🗨️ Lire", callback_data=f"{CB}cv:{post['id']}:{tail}")]]
    row2 = [B("👤 Profil", callback_data=f"{CB}pf:{author}")]
    if author != uid:
        row2.insert(0, B("✔️ Abonné" if following else "➕ Suivre", callback_data=f"{CB}fo:{author}:{tail}"))
    rows.append(row2)
    tags = extract_tags(post["text"])
    if tags:
        rows.append([B(f"#{t}", callback_data=f"{CB}feed:#{t}:0") for t in tags[:3]])
    staff = await _is_staff(uid)
    if author == uid or staff:
        mod = [B("🗑️ Supprimer", callback_data=f"{CB}del:{post['id']}:{mode}")]
        if staff and author != uid:
            mod.append(B("🔇 Muter 24 h", callback_data=f"{CB}mute:{author}:{tail}"))
        rows.append(mod)
    pager = []
    if offset > 0:
        pager.append(B("◀️", callback_data=f"{CB}feed:{mode}:{offset - 1}"))
    pager.append(B("🔄", callback_data=f"{CB}feed:{mode}:{offset}"))
    if offset < total - 1:
        pager.append(B("▶️", callback_data=f"{CB}feed:{mode}:{offset + 1}"))
    rows.append(pager)
    await _send(update, text, _nav(rows))


async def _like(update: Update, uid: int, post_id: int, mode: str, offset: int) -> None:
    gate = await _gate(update, uid, writing=True)
    if gate:
        await show_feed(update, uid, mode, offset, note="ℹ️ " + gate)
        return
    async with db_connection() as db:
        async with db.execute("SELECT author_id, likes FROM rp_posts WHERE id=? AND deleted=0", (post_id,)) as c:
            post = await c.fetchone()
        if not post:
            await show_feed(update, uid, mode, offset, note="ℹ️ Publication introuvable.")
            return
        if post["author_id"] == uid:
            await show_feed(update, uid, mode, offset, note="ℹ️ Tu ne peux pas liker ton propre post.")
            return
        res = await db.execute("INSERT OR IGNORE INTO rp_likes (post_id, user_id, created_at) VALUES (?,?,?)",
                               (post_id, uid, _ts()))
        added = res.rowcount > 0
        if added:
            await db.execute("UPDATE rp_posts SET likes=likes+1 WHERE id=?", (post_id,))
        else:
            await db.execute("DELETE FROM rp_likes WHERE post_id=? AND user_id=?", (post_id, uid))
            await db.execute("UPDATE rp_posts SET likes=MAX(0,likes-1) WHERE id=?", (post_id,))
        await db.commit()
        async with db.execute("SELECT likes FROM rp_posts WHERE id=?", (post_id,)) as c:
            likes = (await c.fetchone())[0]
    if added:
        try:
            from handlers.social import add_social_followers_atomic, give_social_coins
            await give_social_coins(post["author_id"], 1)
            async with db_connection() as db:      # un like réel = un abonné de plus sur la plateforme du post
                async with db.execute("SELECT platform FROM rp_posts WHERE id=?", (post_id,)) as c:
                    prow = await c.fetchone()
            if prow and prow[0]:
                await add_social_followers_atomic(post["author_id"], prow[0], 1)
        except Exception:
            logger.exception("Récompenses du like non attribuées")
        if likes in LIKE_MILESTONES:
            await notify(post["author_id"], "❤️ Ton post cartonne",
                         f"Ta publication atteint <b>{likes}</b> like(s) !", "social")
    await show_feed(update, uid, mode, offset)


# ─────────────────────────────────────────────────────────────────────────────
#  Commentaires
# ─────────────────────────────────────────────────────────────────────────────
@flow("rs_comment")
async def _flow_comment(update, context, value, data):
    uid = update.effective_user.id
    gate = await _gate(update, uid, writing=True)
    if gate:
        await _send(update, gate, _nav())
        return
    post_id = data["post_id"]
    from gameplay.social_comments import CommentError, create_comment
    try:
        await create_comment(uid, post_id, value)
    except CommentError as exc:
        await _send(update, "❌ " + _e(str(exc)), _nav())
        return
    await show_comments(update, uid, post_id, "fol:0", note="✅ Commentaire publié.")


async def show_comments(update: Update, uid: int, post_id: int, tail: str, note: str = "") -> None:
    from gameplay.social_comments import CommentError, list_comments
    try:
        data = await list_comments(post_id)
    except CommentError:
        await _send(update, "❌ Publication introuvable.", _nav())
        return
    lines = [f"🗨️ <b>COMMENTAIRES</b>\n{SEP}", f"<i>{_e(data['post']['text'][:100])}</i>\n"]
    if note:
        lines.insert(1, note)
    if not data["comments"]:
        lines.append("Aucun commentaire. Sois le premier !")
    for cm in data["comments"]:
        lines.append(f"• <b>{_e(cm['author'])}</b> ({_ago(cm['created_at'])}) : {_e(cm['text'])}")
    mode, _, off = tail.partition(":")
    rows = [[B("💬 Commenter", callback_data=f"{CB}cm:{post_id}")],
            [B("⬅️ Retour au fil", callback_data=f"{CB}feed:{mode}:{off or 0}")]]
    await _send(update, "\n".join(lines), _nav(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Abonnements & profils
# ─────────────────────────────────────────────────────────────────────────────
async def _toggle_follow(uid: int, target: int) -> tuple[bool, str]:
    if target == uid:
        return False, "Tu ne peux pas te suivre toi-même."
    t = await get_user(target)
    if not t.get("registered"):
        return False, "Joueur introuvable."
    async with db_connection() as db:
        res = await db.execute("INSERT OR IGNORE INTO rp_follows (follower_id, followee_id, since) VALUES (?,?,?)",
                               (uid, target, _ts()))
        added = res.rowcount > 0
        if not added:
            await db.execute("DELETE FROM rp_follows WHERE follower_id=? AND followee_id=?", (uid, target))
        await db.commit()
        platform = ""
        if added:
            async with db.execute("SELECT platform FROM rp_posts WHERE author_id=? AND deleted=0 AND kind='post' "
                                  "ORDER BY created_at DESC LIMIT 1", (target,)) as c:
                row = await c.fetchone()
            platform = row[0] if row else ""
    if not added:
        # Unfollow : soustraire le bonus accordé lors du follow
        if platform:
            try:
                async with db_connection() as db:
                    await db.execute(
                        "UPDATE social_media SET followers=MAX(0,followers-?) WHERE user_id=? AND platform=?",
                        (FOLLOW_BONUS_FOLLOWERS, target, platform))
                    await db.execute(
                        "UPDATE users SET social_followers=MAX(0,COALESCE(social_followers,0)-?) WHERE user_id=?",
                        (FOLLOW_BONUS_FOLLOWERS, target))
                    await db.commit()
            except Exception:
                logger.exception("Synchro social_media (unfollow) non appliquée")
        return False, "Tu ne suis plus ce joueur."
    if platform:
        try:
            from handlers.social import add_social_followers_atomic
            await add_social_followers_atomic(target, platform, FOLLOW_BONUS_FOLLOWERS)
        except Exception:
            logger.exception("Abonnés sociaux du suivi non attribués")
    await notify(target, "➕ Nouvel abonné", f"<b>{_e(await _name(uid))}</b> te suit maintenant.", "social")
    return True, "Tu suis maintenant ce joueur."


async def show_profile(update: Update, uid: int, target: int) -> None:
    gate = await _gate(update, uid)
    if gate:
        await _send(update, gate, _nav())
        return
    t = await get_user(target)
    if not t.get("registered"):
        await _send(update, "❌ Joueur introuvable.", _nav())
        return
    s = await _stats(target)
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM rp_follows WHERE follower_id=? AND followee_id=?", (uid, target)) as c:
            following = await c.fetchone() is not None
        async with db.execute("SELECT COALESCE(SUM(followers),0) FROM social_media WHERE user_id=?", (target,)) as c:
            audience = (await c.fetchone())[0]
    bio = (t.get("bio") or "").strip()
    from utils import character as chr_
    ch = await chr_.get(target)
    av = chr_.avatar(ch["gender"], ch["skin"], ch["hair"]) + " " if ch and ch["complete"] else "👤 "
    lines = [f"{av}<b>{_e(await _name(target))}</b>\n{SEP}"]
    if t.get("job"):
        lines.append(f"💼 {_e(t['job'])}")
    if bio:
        lines.append(f"<i>{_e(bio[:200])}</i>")
    lines += [f"👥 <b>{s['followers']}</b> abonnés · ➡️ <b>{s['following']}</b> abonnements",
              f"📝 <b>{s['posts']}</b> publications · ❤️ <b>{s['likes']}</b> likes",
              f"🌍 Audience globale : <b>{int(audience):,}</b>".replace(",", " ")]
    rows = []
    if target != uid:
        rows.append([B("✔️ Abonné" if following else "➕ Suivre", callback_data=f"{CB}fp:{target}"),
                     B("💌 Écrire", callback_data=f"{CB}dmw:{target}")])
    rows.append([B("📝 Ses publications", callback_data=f"{CB}feed:u{target}:0")])
    if ch and ch["complete"]:
        rows.append([B("🪪 Son personnage", callback_data=f"pc:view:{target}")])
    if target != uid and await _is_staff(uid):
        rows.append([B("🔇 Muter 24 h (staff)", callback_data=f"{CB}mute:{target}:fol:0")])
    await _send(update, "\n".join(lines), _nav(rows))


@flow("rs_find")
async def _flow_find(update, context, value, data):
    target, _name_ = value
    await show_profile(update, update.effective_user.id, target)


async def show_top(update: Update, uid: int) -> None:
    async with db_connection() as db:
        async with db.execute(
                "SELECT followee_id AS id, COUNT(*) AS n FROM rp_follows GROUP BY followee_id "
                "ORDER BY n DESC LIMIT 10") as c:
            rows_ = await c.fetchall()
    lines = [f"🏆 <b>LES PLUS SUIVIS</b>\n{SEP}"]
    if not rows_:
        lines.append("Personne n'a encore d'abonnés. Lance-toi !")
    buttons = []
    for i, r in enumerate(rows_, 1):
        nm = await _name(r["id"])
        lines.append(f"{i}. <b>{_e(nm)}</b> — {r['n']} abonnés")
        buttons.append([B(f"{i}. {nm[:24]}", callback_data=f"{CB}pf:{r['id']}")])
    await _send(update, "\n".join(lines), _nav(buttons))


# ─────────────────────────────────────────────────────────────────────────────
#  Messages privés
# ─────────────────────────────────────────────────────────────────────────────
async def show_inbox(update: Update, uid: int) -> None:
    gate = await _gate(update, uid)
    if gate:
        await _send(update, gate, _nav())
        return
    async with db_connection() as db:
        async with db.execute(
                "SELECT CASE WHEN from_id=? THEN to_id ELSE from_id END AS other, MAX(created_at) AS last, "
                "SUM(CASE WHEN to_id=? AND is_read=0 THEN 1 ELSE 0 END) AS unread FROM rp_dms "
                "WHERE from_id=? OR to_id=? GROUP BY other ORDER BY last DESC LIMIT 8",
                (uid, uid, uid, uid)) as c:
            convs = await c.fetchall()
    lines = [f"💌 <b>MESSAGES</b>\n{SEP}"]
    rows = []
    if not convs:
        lines.append("Aucune conversation. Ouvre un profil et appuie sur « Écrire ».")
    for cv in convs:
        nm = await _name(cv["other"])
        lines.append(f"• <b>{_e(nm)}</b> — {_ago(cv['last'])}" + (f" · 🔴 {cv['unread']}" if cv["unread"] else ""))
        rows.append([B(f"{'🔴 ' if cv['unread'] else ''}{nm[:28]}", callback_data=f"{CB}dm:{cv['other']}")])
    rows.append([B("✉️ Nouveau message", callback_data=CB + "dmnew")])
    await _send(update, "\n".join(lines), _nav(rows))


async def show_conversation(update: Update, uid: int, other: int, note: str = "") -> None:
    async with db_connection() as db:
        await db.execute("UPDATE rp_dms SET is_read=1 WHERE to_id=? AND from_id=?", (uid, other))
        await db.commit()
        async with db.execute(
                "SELECT * FROM rp_dms WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?) "
                "ORDER BY created_at DESC LIMIT 8", (uid, other, other, uid)) as c:
            msgs = await c.fetchall()
    lines = [f"💌 <b>{_e(await _name(other))}</b>\n{SEP}"]
    if note:
        lines.insert(1, note)
    if not msgs:
        lines.append("Aucun message. Écris le premier !")
    for m in reversed(msgs):
        who = "Moi" if m["from_id"] == uid else _e((await _name(other)).split(" ")[0])
        lines.append(f"<b>{who}</b> <i>({_ago(m['created_at'])})</i> : {_e(m['text'])}")
    rows = [[B("✍️ Répondre", callback_data=f"{CB}dmw:{other}"), B("👤 Profil", callback_data=f"{CB}pf:{other}")],
            [B("⬅️ Messages", callback_data=CB + "inbox")]]
    await _send(update, "\n".join(lines), _nav(rows))


@flow("rs_dm_who")
async def _flow_dm_who(update, context, value, data):
    target, _n = value
    uid = update.effective_user.id
    if target == uid:
        await _send(update, "❌ Tu ne peux pas t'écrire à toi-même.", _nav())
        return
    await ask(update, context, "rs_dm", f"✉️ Message pour <b>{_e(await _name(target))}</b> (max {DM_MAX} caractères) :",
              kind="text", data={"to": target}, back=CB + "inbox")


@flow("rs_dm")
async def _flow_dm(update, context, value, data):
    uid = update.effective_user.id
    to = data["to"]
    gate = await _gate(update, uid, writing=True)
    if gate:
        await _send(update, gate, _nav())
        return
    text = str(value).strip()[:DM_MAX]
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM rp_dms WHERE from_id=? AND created_at>?",
                              (uid, _ts() - 3600)) as c:
            sent = (await c.fetchone())[0]
        if sent >= DMS_PER_HOUR:
            await _send(update, f"📵 Limite de {DMS_PER_HOUR} messages par heure atteinte.", _nav())
            return
        await db.execute("INSERT INTO rp_dms (from_id, to_id, text, created_at) VALUES (?,?,?,?)",
                         (uid, to, text, _ts()))
        await db.commit()
    await notify(to, f"💌 Message de {await _name(uid)}", _e(text[:200]), "social")
    await show_conversation(update, uid, to, note="✅ Message envoyé.")


# ─────────────────────────────────────────────────────────────────────────────
#  #️⃣ Tendances & 👥 Communauté
# ─────────────────────────────────────────────────────────────────────────────
async def show_trends(update: Update, uid: int) -> None:
    async with db_connection() as db:
        async with db.execute(
                "SELECT h.tag, COUNT(*) AS n FROM rp_hashtags h JOIN rp_posts p ON p.id=h.post_id "
                "WHERE p.deleted=0 AND h.created_at>? GROUP BY h.tag ORDER BY n DESC, MAX(h.created_at) DESC LIMIT 8",
                (_ts() - 2 * 86400,)) as c:
            tags = await c.fetchall()
    lines = [f"#️⃣ <b>TENDANCES</b>\n{SEP}", "Les sujets dont on parle depuis 48 h.", ""]
    rows = []
    if not tags:
        lines.append("Aucune tendance pour l'instant. Ajoute un <b>#hashtag</b> à ta prochaine publication !")
    for i, t in enumerate(tags, 1):
        lines.append(f"{i}. <b>#{_e(t['tag'])}</b> — {t['n']} post(s)")
        rows.append([B(f"#{t['tag']} ({t['n']})", callback_data=f"{CB}feed:#{t['tag']}:0")])
    await _send(update, "\n".join(lines), _nav(rows))


async def _my_community(uid: int) -> dict | None:
    from handlers.social import get_user_community
    return await get_user_community(uid)


async def show_community(update: Update, uid: int, note: str = "") -> None:
    gate = await _gate(update, uid)
    if gate:
        await _send(update, gate, _nav())
        return
    com = await _my_community(uid)
    if not com:
        from handlers.phone import _hub_cb
        rows = [[B("➕ Créer une communauté", callback_data=_hub_cb("creer_communaute", "social"))],
                [B("🔑 Rejoindre une communauté", callback_data=_hub_cb("rejoindre_communaute", "social"))]]
        await _send(update, f"👥 <b>COMMUNAUTÉ</b>\n{SEP}\nTu n'es dans aucune communauté.\n\n"
                            "Une communauté a son <b>hashtag officiel</b>, son fil, ses <b>sondages</b> et un bonus "
                            "d'audience pour ses membres.", _nav(rows))
        return
    tag = slug(com["name"])
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM rp_hashtags h JOIN rp_posts p ON p.id=h.post_id "
                              "WHERE h.tag=? AND p.deleted=0", (tag,)) as c:
            posts = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM social_polls WHERE community_id=? AND active=1", (com["community_id"],)) as c:
            polls = (await c.fetchone())[0]
    role = {"owner": "👑 Chef", "admin": "🛡️ Admin"}.get(com.get("role"), "• Membre")
    lines = [f"👥 <b>{_e(com['name'])}</b>\n{SEP}"]
    if note:
        lines.append(note)
    lines += [f"{role} · <b>{com['member_count']}</b> membre(s)", f"#️⃣ Hashtag officiel : <b>#{_e(tag)}</b>",
              f"📝 <b>{posts}</b> publication(s) · 🗳️ <b>{polls}</b> sondage(s) en cours", "",
              "<i>Publie avec le hashtag officiel pour apparaître dans le fil de la communauté.</i>"]
    rows = [[B("📰 Fil de la communauté", callback_data=f"{CB}feed:#{tag}:0")],
            [B("✍️ Publier pour la communauté", callback_data=f"{CB}cpost")],
            [B(f"🗳️ Sondages ({polls})", callback_data=f"{CB}pl")]]
    try:
        from handlers.phone import _hub_cb
        rows.append([B("👥 Membres & invitations", callback_data=_hub_cb("communaute", "social"))])
    except Exception:
        logger.exception("Lien membres indisponible")
    await _send(update, "\n".join(lines), _nav(rows))


async def show_platforms_for(update: Update, uid: int) -> None:
    com = await _my_community(uid)
    if not com:
        await show_community(update, uid)
        return
    btns = [B(f"{PLATFORM_ICON.get(p, '🌐')} {p}", callback_data=f"{CB}cp:{i}") for i, p in enumerate(SOCIAL_PLATFORMS)]
    from utils.ui import layout
    await _send(update, f"✍️ <b>PUBLIER POUR {_e(com['name']).upper()}</b>\n{SEP}\nChoisis la plateforme : "
                        f"<b>#{_e(slug(com['name']))}</b> sera ajouté à ton post.", _nav(layout(btns)))


# ─────────────────────────────────────────────────────────────────────────────
#  🗳️ Sondages
# ─────────────────────────────────────────────────────────────────────────────
POLL_DURATION = 2 * 86400            # 2 jours de jeu
POLL_MILESTONES = (5, 10, 25, 50, 100)
POLL_BAR = 10


async def _poll_rows(com: dict | None) -> list:
    from database import now as game_now
    cid = com["community_id"] if com else -1
    async with db_connection() as db:
        async with db.execute(
                "SELECT p.poll_id, p.question, p.community_id, (SELECT COUNT(*) FROM social_poll_votes v WHERE v.poll_id=p.poll_id) AS n "
                "FROM social_polls p WHERE p.active=1 AND (p.closes_at=0 OR p.closes_at>?) "
                "AND (p.community_id=? OR p.community_id=0) ORDER BY (p.community_id=?) DESC, p.poll_id DESC LIMIT 8",
                (game_now(), cid, cid)) as c:
            return await c.fetchall()


async def show_polls(update: Update, uid: int, note: str = "") -> None:
    gate = await _gate(update, uid)
    if gate:
        await _send(update, gate, _nav())
        return
    com = await _my_community(uid)
    polls = await _poll_rows(com)
    lines = [f"🗳️ <b>SONDAGES</b>\n{SEP}"]
    if note:
        lines.append(note)
    if not polls:
        lines.append("Aucun sondage en cours. Lance le premier !")
    rows = []
    for p in polls:
        tag = "👥 " if p["community_id"] else "🌍 "
        lines.append(f"{tag}<b>{_e(p['question'][:70])}</b> — {p['n']} vote(s)")
        rows.append([B(f"{tag}{p['question'][:30]} ({p['n']})", callback_data=f"{CB}pv:{p['poll_id']}")])
    rows.append([B("➕ Créer un sondage", callback_data=CB + "pn")])
    await _send(update, "\n".join(lines), _nav(rows))


async def show_poll(update: Update, uid: int, poll_id: int, note: str = "") -> None:
    from database import now as game_now
    async with db_connection() as db:
        async with db.execute("SELECT * FROM social_polls WHERE poll_id=?", (poll_id,)) as c:
            poll = await c.fetchone()
        if not poll:
            await show_polls(update, uid, "ℹ️ Sondage introuvable.")
            return
        async with db.execute("SELECT option_index, COUNT(*) AS n FROM social_poll_votes WHERE poll_id=? GROUP BY option_index",
                              (poll_id,)) as c:
            votes = {r[0]: r[1] for r in await c.fetchall()}
        async with db.execute("SELECT option_index FROM social_poll_votes WHERE poll_id=? AND user_id=?", (poll_id, uid)) as c:
            mine = await c.fetchone()
    options = json.loads(poll["options"] or "[]")
    total = sum(votes.values())
    closed = (not poll["active"]) or (poll["closes_at"] and poll["closes_at"] <= game_now())
    lines = [f"🗳️ <b>SONDAGE</b>\n{SEP}"]
    if note:
        lines.append(note)
    lines += [f"❓ <b>{_e(poll['question'])}</b>", f"<i>par {_e(await _name(poll['user_id']))}</i>", ""]
    for i, opt in enumerate(options):
        n = votes.get(i, 0)
        pct = (n / total * 100) if total else 0
        bar = "█" * round(pct / 100 * POLL_BAR) + "░" * (POLL_BAR - round(pct / 100 * POLL_BAR))
        mark = " ✅" if mine and mine[0] == i else ""
        lines.append(f"{i + 1}. {_e(opt)}{mark}\n   {bar} {n} ({pct:.0f} %)")
    lines.append(f"\n👥 {total} votant(s)" + (" · 🔒 clos" if closed else ""))
    rows = []
    if not closed and not mine:
        for i, opt in enumerate(options):
            rows.append([B(f"🗳️ {opt[:34]}", callback_data=f"{CB}vt:{poll_id}:{i}")])
    elif mine:
        lines.append("✅ Tu as voté.")
    if not closed and (poll["user_id"] == uid or await _is_staff(uid)):
        rows.append([B("🔒 Clôturer le sondage", callback_data=f"{CB}pc:{poll_id}")])
    rows.append([B("⬅️ Sondages", callback_data=CB + "pl")])
    await _send(update, "\n".join(lines), _nav(rows))


async def _vote(update: Update, uid: int, poll_id: int, idx: int) -> None:
    gate = await _gate(update, uid, writing=True)
    if gate:
        await show_poll(update, uid, poll_id, note="ℹ️ " + gate)
        return
    try:
        await vote_poll(poll_id, uid, idx)
    except PollError as exc:
        await show_poll(update, uid, poll_id, note="ℹ️ " + str(exc))
        return
    await show_poll(update, uid, poll_id, note="✅ Vote enregistré (+1 SocialCoin).")


@flow("rs_poll_q")
async def _flow_poll_q(update, context, value, data):
    uid = update.effective_user.id
    question = str(value).strip()[:120]
    await ask(update, context, "rs_poll_o",
              f"🗳️ <b>{_e(question)}</b>\n\nÉcris les <b>options</b> séparées par « | » (2 à 4).\nEx : Oui | Non | Peut-être",
              kind="text", data={"q": question}, back=CB + "pl")


@flow("rs_poll_o")
async def _flow_poll_o(update, context, value, data):
    uid = update.effective_user.id
    gate = await _gate(update, uid, writing=True)
    if gate:
        await _send(update, gate, _nav())
        return
    options = [o.strip()[:40] for o in re.split(r"[|\n]", str(value)) if o.strip()][:4]
    if len(options) < 2:
        await ask(update, context, "rs_poll_o", "❌ Il faut au moins 2 options séparées par « | ». Réessaie :",
                  kind="text", data=data, back=CB + "pl")
        return
    try:
        created = await create_shared_poll(uid, data["q"], options)
    except PollError as exc:
        await _send(update, "📵 " + _e(str(exc)), _nav())
        return
    poll_id = created["poll_id"]
    scope = f" pour <b>{_e(created['community_name'])}</b>." if created["community_name"] else " pour tous les joueurs."
    await show_poll(update, uid, poll_id, note="✅ Sondage lancé" + scope)


# ─────────────────────────────────────────────────────────────────────────────
#  Entrées
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_reseau(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update, update.effective_user.id)


async def rs_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    p = (q.data or "").split(":")
    action = p[1] if len(p) > 1 else "home"
    a = p[2:] + ["", "", ""]
    try:
        u = await get_user(uid)
        if not u.get("registered") or u.get("banned"):
            await q.answer("Entre d'abord dans le monde avec le menu de départ.", show_alert=True)
            return
        await q.answer()
        if action == "home":
            await show_home(update, uid)
        elif action == "feed":
            await show_feed(update, uid, a[0] or "fol", int(a[1]) if a[1].isdigit() else 0)
        elif action == "post":
            await show_platforms(update, uid)
        elif action == "pp" and a[0].isdigit() and int(a[0]) < len(SOCIAL_PLATFORMS):
            gate = await _gate(update, uid, writing=True)
            if gate:
                await _send(update, gate, _nav())
                return
            plat = SOCIAL_PLATFORMS[int(a[0])]
            await ask(q, context, "rs_post", f"✍️ <b>{_e(plat)}</b> — écris ta publication (max {POST_MAX} caractères) :",
                      kind="text", data={"platform": plat}, back=CB + "post")
        elif action == "lk" and a[0].isdigit():
            await _like(update, uid, int(a[0]), a[1] or "fol", int(a[2]) if a[2].isdigit() else 0)
        elif action == "cm" and a[0].isdigit():
            gate = await _gate(update, uid, writing=True)
            if gate:
                await _send(update, gate, _nav())
                return
            await ask(q, context, "rs_comment", f"💬 Ton commentaire (max {COMMENT_MAX} caractères) :",
                      kind="text", data={"post_id": int(a[0])}, back=CB + "feed:fol:0")
        elif action == "cv" and a[0].isdigit():
            await show_comments(update, uid, int(a[0]), f"{a[1] or 'fol'}:{a[2] or 0}")
        elif action == "fo" and a[0].isdigit():
            ok, msg = await _toggle_follow(uid, int(a[0]))
            await show_feed(update, uid, a[1] or "fol", int(a[2]) if a[2].isdigit() else 0, note=("✅ " if ok else "ℹ️ ") + msg)
        elif action == "fp" and a[0].isdigit():
            await _toggle_follow(uid, int(a[0]))
            await show_profile(update, uid, int(a[0]))
        elif action == "pf" and a[0].isdigit():
            await show_profile(update, uid, int(a[0]))
        elif action == "find":
            await ask(q, context, "rs_find", "🔎 Quel joueur ? Envoie son <b>@pseudo</b> ou son <b>ID</b>.",
                      kind="user", back=CB + "home")
        elif action == "top":
            await show_top(update, uid)
        elif action == "trend":
            await show_trends(update, uid)
        elif action == "co":
            await show_community(update, uid)
        elif action == "cpost":
            await show_platforms_for(update, uid)
        elif action == "cp" and a[0].isdigit() and int(a[0]) < len(SOCIAL_PLATFORMS):
            gate = await _gate(update, uid, writing=True)
            com = await _my_community(uid)
            if gate or not com:
                await _send(update, gate or "Tu n'es dans aucune communauté.", _nav())
                return
            plat = SOCIAL_PLATFORMS[int(a[0])]
            tag = slug(com["name"])
            await ask(q, context, "rs_post", f"✍️ <b>{_e(plat)}</b> pour <b>{_e(com['name'])}</b> — écris ta publication "
                      f"(<b>#{_e(tag)}</b> sera ajouté) :", kind="text", data={"platform": plat, "tag": tag}, back=CB + "co")
        elif action == "pl":
            await show_polls(update, uid)
        elif action == "pv" and a[0].isdigit():
            await show_poll(update, uid, int(a[0]))
        elif action == "vt" and a[0].isdigit() and a[1].isdigit():
            await _vote(update, uid, int(a[0]), int(a[1]))
        elif action == "pn":
            gate = await _gate(update, uid, writing=True)
            if gate:
                await _send(update, gate, _nav())
                return
            await ask(q, context, "rs_poll_q", f"🗳️ Quelle est ta <b>question</b> ? (120 caractères max)",
                      kind="text", back=CB + "pl")
        elif action == "pc" and a[0].isdigit():
            try:
                await close_poll(int(a[0]), uid, staff=await _is_staff(uid))
                note = "🔒 Sondage clôturé."
            except PollError as exc:
                note = "ℹ️ " + str(exc)
            await show_poll(update, uid, int(a[0]), note=note)
        elif action == "inbox":
            await show_inbox(update, uid)
        elif action == "dm" and a[0].isdigit():
            await show_conversation(update, uid, int(a[0]))
        elif action == "dmw" and a[0].isdigit():
            gate = await _gate(update, uid, writing=True)
            if gate:
                await _send(update, gate, _nav())
                return
            await ask(q, context, "rs_dm", f"✉️ Message pour <b>{_e(await _name(int(a[0])))}</b> (max {DM_MAX} caractères) :",
                      kind="text", data={"to": int(a[0])}, back=f"{CB}dm:{a[0]}")
        elif action == "dmnew":
            await ask(q, context, "rs_dm_who", "✉️ À qui écrire ? Envoie son <b>@pseudo</b> ou son <b>ID</b>.",
                      kind="user", back=CB + "inbox")
        elif action == "del" and a[0].isdigit():
            async with db_connection() as db:
                async with db.execute("SELECT author_id FROM rp_posts WHERE id=?", (int(a[0]),)) as c:
                    row = await c.fetchone()
                if row and (row["author_id"] == uid or await _is_staff(uid)):
                    await db.execute("UPDATE rp_posts SET deleted=1 WHERE id=?", (int(a[0]),))
                    await db.commit()
                    if row["author_id"] != uid:
                        await notify(row["author_id"], "🛡️ Publication supprimée",
                                     "Un membre du staff a retiré l'une de tes publications.", "warning")
            await show_feed(update, uid, a[1] or "fol", 0, note="🗑️ Publication supprimée.")
        elif action == "mute" and a[0].isdigit():
            if not await _is_staff(uid):
                await show_home(update, uid, "🚫 Réservé au staff.")
                return
            async with db_connection() as db:
                await db.execute("INSERT INTO rp_mutes (user_id, until, reason, by_id) VALUES (?,?,?,?) "
                                 "ON CONFLICT(user_id) DO UPDATE SET until=excluded.until, by_id=excluded.by_id",
                                 (int(a[0]), _ts() + MUTE_SECONDS, "modération", uid))
                await db.commit()
            await notify(int(a[0]), "🔇 Sourdine sur le réseau",
                         "Le staff t'a mis en sourdine 24 h : tu peux lire, mais plus publier.", "warning")
            await show_feed(update, uid, a[1] or "fol", int(a[2]) if a[2].isdigit() else 0, note="🔇 Joueur muté 24 h.")
        else:
            await show_home(update, uid)
    except Exception:
        logger.exception("Réseau RP : erreur sur %s", q.data)
        try:
            await q.answer("Une erreur est survenue, réessaie.", show_alert=True)
        except Exception:
            swallowed('handlers/reseau.py')
