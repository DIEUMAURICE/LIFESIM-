# handlers/sante.py — 🏥 Santé publique : hôpitaux, ambulance, lits, médicaments, assurance, postes
"""
Tout se joue avec des boutons (callbacks `hop:…`) à partir du menu « 🏥 Hôpital » :

  🚑 Ambulance (gratuite) · 🏥 Hôpitaux (trajet) · 🩺 Consultation · 🛏️ Lit · 💊 Médicaments
  🛡️ Assurance · 👔 Mon poste (récolte, laboratoire, industrie, service, appels, équipe)

Commandes de direction (réponse à un joueur ou @pseudo) :
  /nommer_pdg (Game Leader) · /nommer_dg (PDG) · /sante_poste (DG/PDG) · /sante_renvoyer (DG/PDG/admins)
  /sante_audit · /sante_lits (admins)
La logique est dans utils/sante.py.
"""
from utils.swallow import swallowed
import html
import logging
import unicodedata

import aiosqlite
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from config import (
    SANTE_HOSPITALS, SANTE_POSTS, SANTE_ASSIGNABLE, SANTE_RAW, SANTE_INTER,
    SANTE_LAB_RECIPES, SANTE_MED_RECIPES, INSURANCE_PLANS, MEDICINES,
    SANTE_FACTION, SANTE_HEAD_LEVEL,
)
from database import db_connection, get_user
from utils import sante
from utils.decorators import (
    require_registered, get_user_role_async,
)
from utils.factions import coffre_balance
from utils.gametime import fmt_game_datetime, add_game_months
from utils.location import get_position, is_exempt, location_label, presence_error, distance_km
from utils.helpers import send_or_edit as _send

logger = logging.getLogger(__name__)

CB = "hop:"


# ─────────────────────────────────────────────────────────────────────────────
#  Outils d'affichage
# ─────────────────────────────────────────────────────────────────────────────
def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text, callback_data=data)


def _norm(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s.lower()) if unicodedata.category(c) != "Mn").strip()


def _parse_hospital(token: str) -> str | None:
    """Clé (« residences »), numéro (1-4 = petits hôpitaux dans l'ordre) ou « grand »."""
    t = _norm(token)
    if t in SANTE_HOSPITALS:
        return t
    petits = [k for k, h in SANTE_HOSPITALS.items() if h["kind"] == "petit"]
    if t.isdigit() and 1 <= int(t) <= len(petits):
        return petits[int(t) - 1]
    for k, h in SANTE_HOSPITALS.items():
        if t and t in _norm(h["name"]):
            return k
    return None


def _parse_post(token: str) -> str | None:
    t = _norm(token)
    for k, p in SANTE_POSTS.items():
        if t == k or t == _norm(p["name"]):
            return k
    return None


async def _is_admin(user_id: int) -> bool:
    """Staff autorisé à agir sans condition de poste : Admin N2 et plus."""
    from config import role_level
    return role_level(await get_user_role_async(user_id)) >= role_level("ADMIN_N2")


async def _find_user(token: str):
    from utils.user_lookup import find_user       # ID d'abord, puis @pseudo
    return await find_user(token)


async def _target(update: Update, context: ContextTypes.DEFAULT_TYPE, arg_index: int = 0):
    """Cible : @pseudo / id à la position `arg_index` (formulaires), sinon réponse à un message (staff).
    Les arguments passent AVANT la réponse : un bouton envoie un message du bot, qui peut « répondre » au joueur."""
    if len(context.args or []) > arg_index:
        row = await _find_user(context.args[arg_index])
        if row:
            return row["user_id"], row["full_name"] or row["username"] or str(row["user_id"])
        return None
    msg = update.message
    if msg and msg.reply_to_message and msg.reply_to_message.from_user:
        u = msg.reply_to_message.from_user
        return u.id, u.full_name
    return None


async def _housing_error(user_id: int) -> str | None:
    """Même règle que /travailler : sans logement, pas de service en entreprise ou en faction."""
    from config import HOUSING_REQUIRED_FOR_JOBS
    if HOUSING_REQUIRED_FOR_JOBS and not await is_exempt(user_id):
        from handlers.realestate import get_residence
        if not await get_residence(user_id):
            return "🏚️ Sans logement, pas de service en faction : ton employeur exige une adresse. 👉 Menu Investissements → Immobilier → Mon logement"
    return None


async def _presence_ok(user_id: int, location: str) -> str | None:
    """Message d'erreur si le joueur n'est pas à `location` (admins exemptés)."""
    if await is_exempt(user_id):
        return None
    return await presence_error(user_id, (location,))


# ─────────────────────────────────────────────────────────────────────────────
#  Écrans
# ─────────────────────────────────────────────────────────────────────────────
async def show_home(update: Update, uid: int, note: str = "") -> None:
    u = await get_user(uid)
    ins = await sante.get_insurance(uid)
    pos = await get_position(uid)
    hid = None if pos["in_transit"] else sante.hospital_at(pos["location"])
    bed = await sante.get_bed(uid)
    call = await sante.get_open_call(uid)
    staff = await sante.get_staff(uid)

    lines = [f"🏥 <b>Santé publique</b>", ""]
    if note:
        lines += [note, ""]
    lines.append(f"❤️ Santé : <b>{u['health']}%</b> · ⚡ Énergie : <b>{u['energy']}%</b>")
    lines.append("🛡️ Assurance : " + (f"<b>{ins['type'].capitalize()}</b> ({ins['left']} remboursement(s) restants)"
                                      if ins else "aucune"))
    lines.append("📍 " + ("En déplacement…" if pos["in_transit"] else f"Tu es : <b>{location_label(pos['location'])}</b>"))
    if bed:
        lines.append("🛏️ Tu es <b>allongé(e) sur un lit</b>.")
    if call:
        lines.append(f"🚑 Appel #{call['call_id']} : " + ("en attente d'un soignant" if call["status"] == "pending"
                                                          else "un soignant te prend en charge"))
    lines += ["", "🚑 Ambulance = gratuite · 🩺 Consultation et 💊 médicaments = payants (remboursés par l'assurance) · "
                  "🛏️ Lit = gratuit mais limité."]

    rows = []
    if bed:
        rows.append([_btn("🛏️ Se lever", CB + "getup"), _btn("🚪 Partir sans soin", CB + "bedquit")])
    elif call:
        rows.append([_btn("❌ Annuler mon appel", CB + "callcancel")])
    else:
        rows.append([_btn("🚑 Appeler une ambulance (gratuit)", CB + "amb")])
    rows.append([_btn("🏥 Hôpitaux & trajet", CB + "list"), _btn("💊 Médicaments", CB + "pharma")])
    if hid and not bed:
        rows.append([_btn("🩺 Consultation ici", CB + "consult"), _btn("🛏️ Prendre un lit", CB + "bed")])
    rows.append([_btn("🛡️ Assurance", CB + "ins"), _btn("👔 Mon poste", CB + "job")])
    from utils import ordre as _ordre       # recrutement par entretien (même système que la police)
    _rec = await _ordre.recruiter(uid)
    if _rec and _rec["faction"] == "sante" and _rec["is_head"]:
        rows.append([_btn("📨 Candidatures (entretien)", "ord:apps")])
    rows.append([_btn("🔄 Actualiser", CB + "home"), _btn("⬅️ Menu", "hub:etat:0")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_hospitals(update: Update, uid: int) -> None:
    pos = await get_position(uid)
    here = pos["location"] if not pos["in_transit"] else None
    lines = ["🏥 <b>Les hôpitaux de la ville</b>", ""]
    rows = []
    for h in await sante.hospital_overview():
        head = h["head"]
        head_txt = (f"{head['post_emoji']} {html.escape(head.get('full_name') or str(head['user_id']))}"
                    if head else "<i>poste vacant</i>")
        dist = "" if not here else (" · 📍 tu es ici" if here == h["location"]
                                    else f" · {distance_km(here, h['location']):g} km")
        lines.append(f"<b>{h['name']}</b> ({'grand' if h['kind'] == 'grand' else 'petit'}){dist}\n"
                     f"   🛏️ {h['beds_cap'] - h['beds_used']}/{h['beds_cap']} lits libres · "
                     f"🟢 {h['on_duty']} soignant(s) en service · {head_txt}")
        if here != h["location"]:
            rows.append([_btn(f"📍 Aller : {h['name']}", f"loc_go:{h['location']}")])
    rows.append([_btn("⬅️ Retour", CB + "home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_pharmacy(update: Update, uid: int, note: str = "") -> None:
    cat = await sante.pharmacy_catalog(uid)
    lines = ["💊 <b>Médicaments</b>", "<i>Fabriqués par les employés de la Santé publique ; chaque achat remplit "
                                       "le coffre qui paie leurs salaires.</i>", ""]
    if note:
        lines += [note, ""]
    rows = []
    for i, m in enumerate(cat):
        price = f"{m['price']:,}" + (f" <s>{m['base']:,}</s> 🛡️" if m["discounted"] else "")
        stock = f"📦 {m['stock']}" if m["stock"] > 0 else "❌ rupture"
        lines.append(f"{m['emoji']} <b>{m['name']}</b> — ❤️ +{m['health']}% · 💰 {price} · {stock}")
        if m["stock"] > 0:
            rows.append([_btn(f"{m['emoji']} {m['name']} — {m['price']:,}", f"{CB}buy:{i}")])
    rows.append([_btn("⬅️ Retour", CB + "home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_insurance(update: Update, uid: int, note: str = "") -> None:
    ins = await sante.get_insurance(uid)
    lines = ["🛡️ <b>Assurance santé</b>", "<i>Réduit le prix des médicaments et des consultations pendant 1 mois de jeu "
                                        "(dans la limite de remboursements du plan).</i>", ""]
    if note:
        lines += [note, ""]
    if ins:
        lines.append(f"✅ Plan actuel : <b>{ins['type'].capitalize()}</b> — remboursements : "
                     f"{ins['claims']}/{ins['limit']} utilisés\n📅 Expire le {fmt_game_datetime(add_game_months(ins['since'], 1))}\n")
    rows = []
    for key, p in INSURANCE_PLANS.items():
        lines.append(f"{p['emoji']} <b>{key.capitalize()}</b> — {p['cost']:,}/mois · {int(p['coverage'] * 100)}% pris en charge · "
                     f"{p['claims_limit']} remboursements")
        rows.append([_btn(f"{p['emoji']} {key.capitalize()} — {p['cost']:,}", f"{CB}insbuy:{key}")])
    rows.append([_btn("⬅️ Retour", CB + "home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


def _stock_lines(stock: dict) -> list[str]:
    out = []
    for title, kind, ref in (("🌾 Ressources", "raw", SANTE_RAW), ("🧪 Laboratoire", "inter", SANTE_INTER)):
        items = [f"{ref[k][1]} {ref[k][0]} ×{stock[kind].get(k, 0)}" for k in ref]
        out.append(f"<b>{title}</b> : " + " · ".join(items))
    meds = [f"{MEDICINES[k]['emoji']} {k} ×{stock['med'].get(k, 0)}" for k in MEDICINES]
    out.append("<b>💊 En vente</b> : " + " · ".join(meds))
    return out


async def show_stock(update: Update, uid: int) -> None:
    stock = await sante.get_stock()
    coffre = await coffre_balance(SANTE_FACTION)
    lines = ["📦 <b>Stocks de la Santé publique</b>", "", *_stock_lines(stock), "",
             f"🏦 Coffre général : <b>{coffre:,}</b>"]
    await _send(update, "\n".join(lines), InlineKeyboardMarkup([[_btn("⬅️ Mon poste", CB + "job")]]))


async def show_job(update: Update, uid: int, note: str = "") -> None:
    st = await sante.get_staff(uid)
    if not st:
        txt = ("👔 <b>Travailler dans la santé publique</b>\n\n"
               "Les postes : " + ", ".join(f"{p['emoji']} {p['name']} ({p['salary_h']:,}/h)"
                                           for k, p in SANTE_POSTS.items() if p["role"] != "head") +
               "\n\n<i>Salaire par heure de jeu, payé par le coffre de la faction.</i>\n"
               "📝 Candidature : menu 🎖️ État & factions → Rejoindre une faction → Santé publique. "
               "Un DG ou le PDG t'accepte puis te donne un poste.")
        await _send(update, txt, InlineKeyboardMarkup([[_btn("⬅️ Retour", CB + "home")]]))
        return
    coffre = await coffre_balance(SANTE_FACTION)
    lines = [f"👔 <b>Mon poste</b> — {st['post_emoji']} {st['post_name']}",
             f"🏥 {st['hospital_name']} · 💰 <b>{st['salary_h']:,}</b> par heure de jeu"]
    if st["role"] in sante.CARE_ROLES:
        lines.append("🟢 <b>EN SERVICE</b> (tu reçois les appels)" if st["on_duty"] else "⚪ Hors service")
    lines.append(f"🏦 Coffre général : <b>{coffre:,}</b>")
    if note:
        lines += ["", note]
    rows = []
    role = st["role"]
    if role == "gather":
        lines.append("\n🌿 Récolte des ressources brutes (coûte de l'énergie).")
        rows.append([_btn(f"{e} {n}", f"{CB}gather:{k}") for k, (n, e) in SANTE_RAW.items()])
    if role == "lab":
        lines.append("\n🧪 Transforme les ressources en produits intermédiaires.")
        for k, r in SANTE_LAB_RECIPES.items():
            need = " + ".join(f"{n}×{SANTE_RAW[i][0]}" for i, n in r["in"].items())
            n, e = SANTE_INTER[k]
            lines.append(f"   {e} {n} ×{r['out']} ← {need}")
            rows.append([_btn(f"{e} Fabriquer : {n}", f"{CB}lab:{k}")])
    if role == "industry":
        lines.append("\n🏭 Fabrique les médicaments (mis en vente automatiquement).")
        for k, r in SANTE_MED_RECIPES.items():
            need = " + ".join(f"{n}×{SANTE_INTER[i][0]}" for i, n in r["in"].items())
            lines.append(f"   {MEDICINES[k]['emoji']} {k} ×{r['out']} ← {need}")
            rows.append([_btn(f"{MEDICINES[k]['emoji']} Fabriquer : {k}", f"{CB}ind:{k}")])
    if role in sante.CARE_ROLES:
        rows.append([_btn("⚪ Quitter le service" if st["on_duty"] else "🟢 Prendre mon service",
                          CB + ("duty:off" if st["on_duty"] else "duty:on")),
                     _btn("📟 Appels en attente", CB + "calls")])
    if st["level"] >= SANTE_HEAD_LEVEL:
        rows.append([_btn("👥 Équipe & commandes de direction", CB + "team")])
    rows.append([_btn("📦 Stocks", CB + "stock"), _btn("⬅️ Retour", CB + "home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_calls(update: Update, uid: int, note: str = "") -> None:
    calls = await sante.pending_calls_for(uid)
    lines = ["📟 <b>Appels en attente</b>", ""]
    if note:
        lines += [note, ""]
    rows = []
    if not calls:
        lines.append("Aucun appel pour le moment.")
    for c in calls:
        who = html.escape(c.get("full_name") or str(c["patient_id"]))
        kind = "🚑 ambulance" if c["kind"] == "ambulance" else f"🩺 accueil ({sante.hospital_info(c['hospital_id'])['name']})"
        lines.append(f"#{c['call_id']} — {who} (❤️ {c.get('health', '?')}%) · {kind}")
        if c["status"] == "pending":
            rows.append([_btn(f"✋ Prendre #{c['call_id']}", f"{CB}take:{c['call_id']}")])
        else:
            rows.append([_btn(f"✅ Soigner #{c['call_id']}", f"{CB}treat:{c['call_id']}")])
    rows.append([_btn("🔄 Actualiser", CB + "calls"), _btn("⬅️ Mon poste", CB + "job")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_team(update: Update, uid: int) -> None:
    st = await sante.get_staff(uid)
    admin = await _is_admin(uid)
    if not admin and (not st or st["level"] < SANTE_HEAD_LEVEL):
        await _send(update, "❌ Réservé à la direction.", InlineKeyboardMarkup([[_btn("⬅️ Retour", CB + "job")]]))
        return
    hid = None if (admin or st["post"] == "pdg") else st["hospital_id"]
    team = await sante.list_staff(hid)
    lines = ["👥 <b>Équipe</b>", ""]
    for s in team[:40]:
        flag = "🟢" if s["on_duty"] else "⚪"
        lines.append(f"{flag} {s['post_emoji']} {html.escape(s.get('full_name') or str(s['user_id']))} — "
                     f"{s['post_name']} · {s['hospital_name']} · <code>{s['user_id']}</code>")
    if not team:
        lines.append("Personne pour l'instant.")
    lines += ["", "<b>Direction</b> (🎮 Menu principal → Vie) :",
              "• <b>Poste santé</b> — promouvoir / affecter un employé",
              "• <b>Renvoyer (santé)</b> — renvoyer un employé",
              "• Menu État & factions → Direction de faction : <b>Candidatures reçues</b> → <b>Accepter</b> / <b>Refuser</b> une recrue"]
    if admin or (st and st["post"] == "pdg"):
        lines.append("• <b>Nommer un DG</b> — directeur d'un petit hôpital")
    await _send(update, "\n".join(lines), InlineKeyboardMarkup([[_btn("⬅️ Mon poste", CB + "job")]]))


# ─────────────────────────────────────────────────────────────────────────────
#  Callback unique : hop:<action>[:<arg>]
# ─────────────────────────────────────────────────────────────────────────────
async def hop_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    parts = (q.data or "").split(":")
    action = parts[1] if len(parts) > 1 else "home"
    arg = parts[2] if len(parts) > 2 else ""
    try:
        u = await get_user(uid)
        if not u.get("registered") or u.get("banned"):
            await q.answer("Termine d'abord /start.", show_alert=True)
            return
        await q.answer()

        if action == "home":
            await show_home(update, uid)
        elif action == "list":
            await show_hospitals(update, uid)
        elif action == "pharma":
            await show_pharmacy(update, uid)
        elif action == "buy":
            names = list(MEDICINES)
            ok, msg = await sante.buy_medicine(uid, names[int(arg)]) if arg.isdigit() and int(arg) < len(names) \
                else (False, "Médicament inconnu.")
            await show_pharmacy(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "ins":
            await show_insurance(update, uid)
        elif action == "insbuy":
            ok, msg = await sante.subscribe_insurance(uid, arg)
            note = (f"✅ Assurance <b>{arg.capitalize()}</b> souscrite : la prime va au coffre de la Santé publique."
                    if ok else f"❌ {msg}")
            await show_insurance(update, uid, note)
        elif action == "amb":
            ok, msg = await sante.call_ambulance(uid)
            await show_home(update, uid, msg if ok else f"❌ {msg}")
        elif action == "callcancel":
            await sante.cancel_call(uid)
            await show_home(update, uid, "Appel annulé.")
        elif action == "consult":
            ok, msg = await sante.request_consult(uid)
            await show_home(update, uid, msg if ok else f"❌ {msg}")
        elif action == "bed":
            ok, msg = await sante.take_bed(uid)
            await show_home(update, uid, msg if ok else f"❌ {msg}")
        elif action in ("getup", "bedquit"):
            ok, msg = await sante.leave_bed(uid, force=(action == "bedquit"))
            await show_home(update, uid, msg if ok else f"❌ {msg}")
        elif action == "job":
            await show_job(update, uid)
        elif action == "stock":
            await show_stock(update, uid)
        elif action == "team":
            await show_team(update, uid)
        elif action == "calls":
            await show_calls(update, uid)
        elif action == "duty":
            err = await _housing_error(uid) if arg == "on" else None
            ok, msg = (False, err) if err else await sante.set_duty(uid, arg == "on")
            await show_job(update, uid, msg if ok else f"❌ {msg}")
        elif action == "take":
            ok, msg = await sante.take_call(uid, int(arg))
            await show_calls(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "treat":
            ok, msg = await sante.treat_call(uid, int(arg))
            await show_calls(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action in ("gather", "lab", "ind"):
            st = await sante.get_staff(uid)
            err = await _housing_error(uid) if st else None
            if not err and action != "gather" and st:      # laboratoire et industrie : sur place, à l'hôpital d'affectation
                err = await _presence_ok(uid, st["location"])
            if err:
                await show_job(update, uid, f"❌ {err}")
                return
            if action == "gather":
                ok, msg = await sante.gather(uid, arg)
            elif action == "lab":
                ok, msg = await sante.lab_make(uid, arg)
            else:
                ok, msg = await sante.industry_make(uid, arg)
            await show_job(update, uid, ("✅ " if ok else "❌ ") + msg)
        else:
            await show_home(update, uid)
    except Exception:
        logger.exception("hop_callback %s", q.data)
        try:
            await q.answer("Erreur, réessaie.", show_alert=True)
        except Exception:
            swallowed('handlers/sante.py')


# ─────────────────────────────────────────────────────────────────────────────
#  Commandes joueur (ouvrent l'écran à boutons)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_hopital(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update, update.effective_user.id)


@require_registered
async def cmd_medecin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update, update.effective_user.id)


@require_registered
async def cmd_ambulance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ok, msg = await sante.call_ambulance(update.effective_user.id)
    await show_home(update, update.effective_user.id, msg if ok else f"❌ {msg}")


@require_registered
async def cmd_medicaments(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_pharmacy(update, update.effective_user.id)


@require_registered
async def cmd_assurance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_insurance(update, update.effective_user.id)


@require_registered
async def cmd_poste_sante(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_job(update, update.effective_user.id)


# ─────────────────────────────────────────────────────────────────────────────
#  Direction et contrôle (commandes)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_nommer_dg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/nommer_dg <hôpital> [@joueur] — le PDG nomme le DG d'un petit hôpital."""
    uid = update.effective_user.id
    hid = _parse_hospital(context.args[0]) if context.args else None
    if not hid:
        await update.message.reply_text("❌ Hôpital inconnu. Relance l'action depuis le menu.")
        return
    tgt = await _target(update, context, 1)
    if not tgt:
        await update.message.reply_text("❌ Joueur introuvable (il doit être inscrit au jeu).")
        return
    ok, msg = await sante.appoint_dg(uid, tgt[0], hid, is_admin=await _is_admin(uid))
    await update.message.reply_text(("✅ " if ok else "❌ ") + f"{html.escape(tgt[1])} : {msg}", parse_mode="HTML")


@require_registered
async def cmd_sante_poste(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/sante_poste <poste> [@joueur] [hôpital] — promouvoir / changer le poste / affecter (DG, PDG)."""
    uid = update.effective_user.id
    args = list(context.args or [])
    post = _parse_post(args[0]) if args else None
    if not post:
        await update.message.reply_text("❌ Poste inconnu. Relance l'action depuis le menu.")
        return
    hid = None
    rest = []
    for tok in args[1:]:
        is_hosp = (not tok.startswith("@")) and (len(tok) == 1 and tok.isdigit() or (not tok.isdigit() and _parse_hospital(tok)))
        if is_hosp and hid is None:
            hid = _parse_hospital(tok)
        else:
            rest.append(tok)

    class _Ctx:      # arguments restants (pseudo / id) pour _target
        args = rest

    tgt = await _target(update, _Ctx, 0)
    if not tgt:
        await update.message.reply_text("❌ Joueur introuvable (il doit être inscrit au jeu).")
        return
    ok, msg = await sante.assign_post(uid, tgt[0], post, hid, is_admin=await _is_admin(uid))
    await update.message.reply_text(("✅ " if ok else "❌ ") + f"{html.escape(tgt[1])} : {msg}", parse_mode="HTML")


@require_registered
async def cmd_sante_renvoyer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/sante_renvoyer @joueur [motif] — renvoyer un employé (DG de son hôpital, PDG, admins ; le PDG : Game Leader+).
    Avec un motif, le @pseudo est obligatoire ; sans motif on peut aussi répondre au message du joueur."""
    uid = update.effective_user.id
    args = list(context.args or [])
    tgt = await _target(update, context, 0)
    if not tgt:
        await update.message.reply_text("❌ Joueur introuvable. Relance l'action depuis le menu.")
        return
    reason = " ".join(args[1:])
    admin = await _is_admin(uid)
    if admin:     # révoquer un PDG = décision du Game Leader et plus (comme sa nomination)
        from config import role_level
        victim = await sante.get_staff(tgt[0])
        if victim and victim["post"] == "pdg" and role_level(await get_user_role_async(uid)) < role_level("GAME_LEADER"):
            await update.message.reply_text("❌ Seul un Game Leader (ou plus) peut révoquer le PDG : utilise /revoquer_pdg.")
            return
    ok, msg = await sante.dismiss(uid, tgt[0], is_admin=admin, reason=reason)
    await update.message.reply_text(("✅ " if ok else "❌ ") + msg)
