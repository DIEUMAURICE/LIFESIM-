import asyncio
# handlers/luxury.py
import random
import aiosqlite
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import db_connection, DB_PATH, get_user, increment_field
from utils.vip import add_xp
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, now, escape_html
from config import LUXURY_ITEMS, PRESTIGE_RANKS, VIP_LUXE_REQUIRED, VIP_LIEUX
from handlers.missions import update_mission_progress
from handlers.vehicles import get_active_vehicle, get_vehicle_stats
from utils.gametime import fmt_game_datetime


def _fmt_datetime(ts: int) -> str:
    """Formate un timestamp en date lisible JJ/MM/AAAA à HH:MM."""
    try:
        return fmt_game_datetime(ts)
    except Exception:
        return "date inconnue"


@require_registered
async def cmd_luxe(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    # Récupérer le véhicule actif pour le luxe
    active_vehicle = await get_active_vehicle(user.id)
    vehicle_luxe = active_vehicle.get("luxury", 0) if active_vehicle else 0

    luxe_msg = ""
    if active_vehicle:
        luxe_msg = f"\n🚗 <b>Luxe de votre véhicule</b> : {vehicle_luxe}/100\n"
        if vehicle_luxe >= VIP_LUXE_REQUIRED:
            luxe_msg += "✅ <b>Accès VIP débloqué !</b> Tu as accès à tous les lieux prestigieux.\n"
        else:
            luxe_msg += f"🔒 Besoin de {VIP_LUXE_REQUIRED - vehicle_luxe} points de luxe pour l'accès VIP.\n"
    else:
        luxe_msg = "\n🚫 <b>Aucun véhicule actif</b> - Achète ou sélectionne un véhicule pour accéder aux lieux VIP.\n"

    text = "👑 <b>Boutique de Luxe</b>\n\n"
    text += luxe_msg + "\n"
    text += "━" * 30 + "\n\n"

    for item, data in LUXURY_ITEMS.items():
        text += (
            f"{data['emoji']} <b>{item}</b>\n"
            f"  💰 Prix : {fmt(data['price'])}\n"
            f"  ✨ Prestige : +{data['prestige']} pts\n\n"
        )
    text += f"_Ton prestige actuel : {u.get('prestige', 0)} pts_\n"
    text += "<i>Achat de luxe et accès VIP : menu → 🚗 Véhicules &amp; luxe.</i>"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
@cooldown("luxury_buy", 5, "⏳ Attends quelques secondes avant de faire un autre achat.")
async def cmd_acheter_luxe(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not context.args:
        await update.message.reply_text("Choisis un article dans le menu Véhicules &amp; luxe → Boutique de luxe.")
        return

    item_name = " ".join(context.args).title()
    matched = None
    for item in LUXURY_ITEMS:
        if item.lower() == item_name.lower():
            matched = item
            break
    if not matched:
        for item in LUXURY_ITEMS:
            if item_name.lower() in item.lower():
                matched = item
                break
    if not matched:
        await update.message.reply_text("❌ Article inconnu : choisis-le dans la boutique de luxe.")
        return

    data = LUXURY_ITEMS[matched]

    if u["balance"] < data["price"]:
        await update.message.reply_text(
            f"❌ Fonds insuffisants !\n"
            f"💰 Prix : {fmt(data['price'])}\n"
            f"💵 Ton solde : {fmt(u['balance'])}"
        )
        return

    async with db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            debit = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+?, prestige=prestige+? "
                "WHERE user_id=? AND balance>=?",
                (data["price"], data["price"], data["prestige"], user.id, data["price"]),
            )
            if debit.rowcount != 1:
                await db.rollback()
                await update.message.reply_text("❌ Fonds insuffisants.")
                return
            await db.commit()
        except Exception:
            await db.rollback()
            raise

    # 1. Créer ou récupérer l'item dans la table `items`
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT item_id FROM items WHERE name = ?", (matched,)) as cur:
            row = await cur.fetchone()
        if row:
            item_id = row["item_id"]
        else:
            await db.execute("""
                INSERT INTO items (name, type, rarity, value, effect_type, effect_value, emoji, description)
                VALUES (?, 'luxury', 'epic', ?, NULL, 0, ?, ?)
            """, (matched, data["price"], data["emoji"], f"Article de luxe : {matched}"))
            async with db.execute("SELECT last_insert_rowid()") as cur2:
                item_id = (await cur2.fetchone())[0]

        # 2. Ajouter l'item à l'inventaire du joueur
        async with db.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?",
            (user.id, item_id)
        ) as cur3:
            existing = await cur3.fetchone()
        if existing:
            await db.execute(
                "UPDATE inventory SET quantity = quantity + 1 WHERE user_id = ? AND item_id = ?",
                (user.id, item_id)
            )
        else:
            await db.execute("""
                INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at)
                VALUES (?, ?, 'Luxe', ?, 1, ?)
            """, (user.id, item_id, matched, now()))
        await db.commit()

    await add_xp(user.id, 50)   # ✅ Fix #11
    await increment_field(user.id, "karma", data.get("karma", 0))
    await update_mission_progress(user.id, "luxury", data["price"])

    # Message bonus paliers
    async with db_connection() as db:
        async with db.execute(
            "SELECT SUM(quantity) FROM inventory WHERE user_id=? AND item_type='Luxe'",
            (user.id,)
        ) as cur:
            total_items = (await cur.fetchone())[0] or 0
    achievement = ""
    if total_items == 10:
        achievement = "\n🏆 <b>10 articles de luxe</b> → +100 Prestige !"
        await increment_field(user.id, "prestige", 100)
    elif total_items == 50:
        achievement = "\n🏆 <b>50 articles de luxe</b> → +500 Prestige !"
        await increment_field(user.id, "prestige", 500)
    elif total_items == 100:
        achievement = "\n🏆 <b>100 articles de luxe</b> → +1000 Prestige !"
        await increment_field(user.id, "prestige", 1000)

    final_prestige = (await get_user(user.id)).get("prestige", 0)

    await update.message.reply_text(
        f"✨ <b>Article de luxe acquis !</b>\n\n"
        f"{data['emoji']} <b>{matched}</b>\n"
        f"💰 Prix : {fmt(data['price'])}\n"
        f"✨ Prestige : +{data['prestige']}\n"
        + (f"🌟 Karma : +{data['karma']}\n" if data.get('karma') else "") +
        f"💎 Prestige total : {final_prestige}{achievement}\n\n"
        f"<i>Un vrai connaisseur !</i>",
        parse_mode="HTML"
    )


@require_registered
async def cmd_prestige(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    prestige = u.get("prestige", 0)

    # Détermination du rang
    rank = "🥚 Inconnu"
    for r in PRESTIGE_RANKS:
        if prestige >= r["min"]:
            rank = r["name"]
        else:
            break

    # Récupérer les articles de luxe
    async with db_connection() as db:
        async with db.execute(
            "SELECT item_name, quantity FROM inventory WHERE user_id=? AND item_type='Luxe' ORDER BY acquired_at DESC",
            (user.id,)
        ) as cur:
            luxury = await cur.fetchall()

    lux_text = "\n".join(f"  • {l[0]} x{l[1]}" for l in luxury[:10]) if luxury else "  <i>Aucun article de luxe</i>"
    if len(luxury) > 10:
        lux_text += f"\n  _... et {len(luxury)-10} autres_"

    # Classement général des plus prestigieux (top 5) — le staff N2+ n'y figure jamais
    from utils.staff_scope import excluded_sql
    async with db_connection() as db:
        async with db.execute(
            "SELECT full_name, prestige FROM users WHERE prestige > 0 AND "
            + excluded_sql("user_id")
            + " ORDER BY prestige DESC LIMIT 5"
        ) as cur:
            top = await cur.fetchall()
    top_text = ""
    if top:
        top_text = "\n🏆 <b>Top Prestige :</b>\n"
        for i, t in enumerate(top, 1):
            top_text += f"{i}. {t[0]} — {t[1]} pts\n"

    await update.message.reply_text(
        f"✨ <b>Prestige de {escape_html(user.full_name)}</b>\n\n"
        f"🎖️ Points : <b>{prestige}</b>\n"
        f"🏅 Rang : <b>{rank}</b>\n\n"
        f"👑 <b>Collection luxe :</b>\n{lux_text}\n\n"
        f"<i>Comment augmenter son prestige :</i>\n"
        f"• 🛒 Acheter des articles de luxe\n"
        f"• 🏠 Acheter des propriétés\n"
        f"• 🚗 Acheter des véhicules haut de gamme\n"
        f"• 🎓 Obtenir des diplômes\n"
        f"• 🏛️ Exercer un poste politique\n"
        f"{top_text}",
        parse_mode="HTML"
    )


@require_registered
async def cmd_classementprestige(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_for_update
    await show_for_update(update, 'prestige')


@require_registered
async def cmd_prestigelog(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche l'historique des achats de luxe (les 10 derniers)."""
    user = update.effective_user
    async with db_connection() as db:
        async with db.execute(
            "SELECT item_name, acquired_at FROM inventory WHERE user_id=? AND item_type='Luxe' ORDER BY acquired_at DESC LIMIT 10",
            (user.id,)
        ) as cur:
            logs = await cur.fetchall()
    if not logs:
        await update.message.reply_text("📜 Aucun achat de luxe enregistré.")
        return
    text = "📜 <b>Derniers achats de luxe</b>\n\n"
    for l in logs:
        date = _fmt_datetime(l[1])
        text += f"• {l[0]} — le {date}\n"
    await update.message.reply_text(text, parse_mode="HTML")


# ─── ACCÈS VIP ─────────────────────────────────────────────

@require_registered
@require_free
@cooldown("vip_access", 3600, "⏳ Tu viens déjà de profiter des lieux VIP : reviens dans une heure.")
async def cmd_acces_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Vérifie l'accès aux lieux VIP selon le luxe du véhicule."""
    user = update.effective_user

    active_vehicle = await get_active_vehicle(user.id)

    if not active_vehicle:
        await update.message.reply_text(
            "🚫 <b>Accès VIP refusé</b>\n\n"
            "Vous devez posséder un véhicule pour accéder aux lieux prestigieux.\n"
            "Achète ou sélectionne un véhicule dans le menu Véhicules &amp; luxe.\n\n"
            "💡 <i>Un véhicule de luxe vous ouvre toutes les portes.</i>"
        )
        return

    veh_data = await get_vehicle_stats(active_vehicle["veh_type"])
    vehicle_luxe = active_vehicle.get("luxury", 0)

    if vehicle_luxe == 0 and veh_data.get("luxury", 0) > 0:
        vehicle_luxe = veh_data.get("luxury", 0)
        async with db_connection() as db:
            await db.execute(
                "UPDATE vehicles SET luxury = ? WHERE veh_id = ?",
                (vehicle_luxe, active_vehicle["veh_id"])
            )
            await db.commit()

    if vehicle_luxe < VIP_LUXE_REQUIRED:
        missing = VIP_LUXE_REQUIRED - vehicle_luxe
        await update.message.reply_text(
            f"🚫 <b>Accès refusé</b>\n\n"
            f"Votre véhicule n'est pas assez luxueux pour entrer dans les lieux VIP.\n"
            f"🔒 Luxe requis : <b>{VIP_LUXE_REQUIRED}</b>\n"
            f"🚗 Luxe actuel : <b>{vehicle_luxe}/100</b>\n\n"
            f"💡 Il vous manque <b>{missing}</b> points de luxe.\n\n"
            f"🏎️ Pour améliorer votre luxe :\n"
            f"  • Achète un véhicule plus luxueux (menu Véhicules &amp; luxe)\n"
            f"  • Certains véhicules comme le Jet privé ou le Yacht ont un luxe élevé\n"
            f"  • Compare le luxe de chaque véhicule dans le catalogue",
            parse_mode="HTML"
        )
        return

    lieu = random.choice(VIP_LIEUX)

    bonus_prestige = 0
    if vehicle_luxe >= 90:
        bonus_prestige = 5
        await increment_field(user.id, "prestige", bonus_prestige)

    social_bonus_msg = ""
    if vehicle_luxe > 80:
        social_bonus = 1 + (vehicle_luxe - 80) / 100
        social_bonus_msg = f"\n📱 Bonus social actif : vos posts gagnent <b>+{int((social_bonus - 1) * 100)}%</b> d'abonnés."

    await update.message.reply_text(
        f"✅ <b>Accès VIP accordé</b>\n\n"
        f"🚗 Votre véhicule (luxe {vehicle_luxe}/100) vous ouvre toutes les portes.\n\n"
        f"🎯 Vous avez accès au : <b>{lieu}</b>\n\n"
        f"🥂 Profitez des salons privés et des événements exclusifs !\n"
        f"{'✨ +' + str(bonus_prestige) + ' Prestige (luxe exceptionnel) !' if bonus_prestige else ''}"
        f"{social_bonus_msg}\n\n"
        f"💎 <i>Le luxe attire le luxe...</i>",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_lieux_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche la liste des lieux VIP accessibles."""
    user = update.effective_user

    active_vehicle = await get_active_vehicle(user.id)

    if not active_vehicle:
        text = "🏛️ <b>Lieux VIP accessibles</b>\n\n"
        text += "🚫 Aucun véhicule actif. Sélectionne-en un dans ton Garage.\n"
        text += "\n💡 Les lieux VIP nécessitent un véhicule de luxe."
        await update.message.reply_text(text)
        return

    veh_data = await get_vehicle_stats(active_vehicle["veh_type"])
    vehicle_luxe = active_vehicle.get("luxury", 0)

    if vehicle_luxe == 0 and veh_data.get("luxury", 0) > 0:
        vehicle_luxe = veh_data.get("luxury", 0)
        async with db_connection() as db:
            await db.execute(
                "UPDATE vehicles SET luxury = ? WHERE veh_id = ?",
                (vehicle_luxe, active_vehicle["veh_id"])
            )
            await db.commit()

    text = "🏛️ <b>Lieux VIP accessibles</b>\n\n"
    text += f"🚗 Luxe de votre véhicule : <b>{vehicle_luxe}/100</b>\n"
    text += f"🔒 Seuil requis : <b>{VIP_LUXE_REQUIRED}</b>\n\n"

    if vehicle_luxe >= VIP_LUXE_REQUIRED:
        text += "✅ <b>Accès complet</b>\n\n"
        for lieu in VIP_LIEUX:
            text += f"  • {lieu}\n"
        text += "\n🥂 <i>Profitez de vos privilèges !</i>"
    else:
        missing = VIP_LUXE_REQUIRED - vehicle_luxe
        text += f"🔒 <b>Accès restreint</b>\n\n"
        text += f"Il vous manque <b>{missing}</b> points de luxe.\n\n"
        text += "Voici ce qui vous attend :\n"
        for lieu in VIP_LIEUX[:4]:
            text += f"  • {lieu}\n"
        if len(VIP_LIEUX) > 4:
            text += f"  _... et {len(VIP_LIEUX) - 4} autres lieux exclusifs_"
        text += "\n\n🏎️ Achète un véhicule plus luxueux dans le menu Véhicules &amp; luxe"

    await update.message.reply_text(text, parse_mode="HTML")


# ─── MAINTENANCE (appelée par le scheduler) ─────────────────────────

PRESTIGE_BATCH = 2000


async def process_prestige_decay():
    """Réduit le prestige de 1% par mois (arrondi à l'inférieur), par lots d'identifiants."""
    last_id = 0
    while True:
        async with db_connection() as db:
            async with db.execute(
                "SELECT user_id FROM users WHERE prestige > 0 AND user_id > ? "
                "ORDER BY user_id LIMIT ?",
                (last_id, PRESTIGE_BATCH),
            ) as cur:
                ids = [r[0] for r in await cur.fetchall()]
            if not ids:
                break
            await db.execute(
                "UPDATE users SET prestige = MAX(0, prestige - (prestige / 100)) "
                "WHERE prestige > 0 AND user_id BETWEEN ? AND ?",
                (ids[0], ids[-1]),
            )
            await db.commit()
        last_id = ids[-1]
        await asyncio.sleep(0)   # laisse passer les autres tâches entre deux lots