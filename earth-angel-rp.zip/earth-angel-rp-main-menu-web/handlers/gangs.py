# handlers/gangs.py — gangs : candidatures, hiérarchie, partage quotidien du coffre
"""
• Pas de gang = pas de crime (contrôlé dans handlers/crime.py via `require_gang`).
• Rejoindre un gang = candidature, acceptée par l'encadrement (Chef / Bras droit / Lieutenant).
• Hiérarchie : Chef > Bras droit > Lieutenant > Soldat > Recrue (config.GANG_ROLES).
• Butin d'un crime : une part (GANG_CRIME_CUT) alimente le coffre du gang.
• Chaque jour de jeu, le coffre est partagé entre les membres selon leur poste.

Tout se fait en boutons (menu Gangs) : candidatures, changer un poste, exclure.
"""
from utils.swallow import swallowed
import logging

import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from config import (
    GANG_ROLES, GANG_ROLE_WEIGHT, GANG_RECRUIT_ROLES, GANG_MANAGE_ROLES,
    GANG_PAYOUT_RATIO, GANG_CRIME_CUT,
)
from database import db_connection, get_user, update_balance, now
from utils.decorators import require_registered, require_free, get_user_role_async
from utils.helpers import fmt, escape_html
from utils.notify import notify

logger = logging.getLogger(__name__)

DAY = 86400
ROLE_NAMES = [r for r, _ in GANG_ROLES]
NO_GANG_CRIME_TEXT = (
    "🔫 Sans gang, pas de crime : les affaires se font en bande.\n"
    "👉 Menu Gangs → Rejoindre ou Créer un gang"
)


def role_rank(role: str) -> int:
    """0 = plus haut (Chef). Poste inconnu → tout en bas."""
    return ROLE_NAMES.index(role) if role in ROLE_NAMES else len(ROLE_NAMES)


def game_day() -> int:
    return now() // DAY


async def get_gang_membership(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT g.gang_id, g.name, g.treasury, g.reputation, gm.role FROM gang_members gm "
                "JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def is_crime_exempt(user_id: int) -> bool:
    u = await get_user(user_id)
    return bool(u.get("god_mode")) or await get_user_role_async(user_id) != "PLAYER"


async def require_gang(user_id: int) -> bool:
    """True si le joueur peut commettre un crime (membre d'un gang, ou admin/god mode)."""
    return await is_crime_exempt(user_id) or await get_gang_membership(user_id) is not None


async def split_crime_reward(user_id: int, reward: int) -> int:
    """Verse la part du gang dans son coffre, paie le reste au joueur. Retourne le net reçu."""
    gang = await get_gang_membership(user_id)
    cut = int(reward * GANG_CRIME_CUT) if gang else 0
    if cut > 0:
        async with db_connection() as db:
            await db.execute("UPDATE gangs SET treasury=treasury+? WHERE gang_id=?", (cut, gang["gang_id"]))
            await db.commit()
    await update_balance(user_id, reward - cut)
    return reward - cut


async def share_text(gang_id: int, user_id: int, role: str) -> str:
    """Ligne « ta part du partage quotidien » pour la fiche du gang."""
    async with db_connection() as db:
        async with db.execute("SELECT role FROM gang_members WHERE gang_id=?", (gang_id,)) as cur:
            roles = [r[0] for r in await cur.fetchall()]
    total = sum(GANG_ROLE_WEIGHT.get(r, 1) for r in roles) or 1
    pct = GANG_ROLE_WEIGHT.get(role, 1) * 100 / total
    return (f"🎖️ Poste : <b>{role}</b> — part du partage quotidien : <b>{pct:.0f} %</b> "
            f"({int(GANG_PAYOUT_RATIO * 100)} % du coffre est partagé chaque jour)")


# ─────────────────────────────────────────────────────────────────────────────
# Candidatures
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_rejoindregang(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """le menu : envoie une candidature à l'encadrement du gang."""
    user = update.effective_user
    from gameplay.gangs import GangError, apply_to_gang
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🔫 Crime & sécurité.")
        return
    async with db_connection() as db:
        async with db.execute("SELECT gang_id FROM gangs WHERE LOWER(name)=LOWER(?)", (" ".join(context.args),)) as cur:
            found = await cur.fetchone()
    if not found:
        await update.message.reply_text(f"❌ Gang « {' '.join(context.args)} » introuvable.")
        return
    try:
        result = await apply_to_gang(user.id, found[0])
    except GangError as exc:
        await update.message.reply_text(f"❌ {exc}")
        return
    if result["status"] == "joined":
        await update.message.reply_text(f"✅ Tu rejoins <b>{result['name']}</b> comme Recrue.", parse_mode="HTML")
    else:
        await update.message.reply_text(f"📨 Candidature envoyée à <b>{result['name']}</b>.", parse_mode="HTML")
    return

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🔫 Crime & sécurité.")
        return
    name = " ".join(context.args)
    if await get_gang_membership(user.id):
        await update.message.reply_text("❌ Tu es déjà dans un gang !")
        return
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT gang_id, name FROM gangs WHERE LOWER(name)=LOWER(?)", (name,)) as cur:
            gang = await cur.fetchone()
        if not gang:
            await update.message.reply_text(f"❌ Gang « {name} » introuvable.")
            return
        placeholders = ",".join("?" * len(GANG_RECRUIT_ROLES))
        async with db.execute(
                f"SELECT user_id FROM gang_members WHERE gang_id=? AND role IN ({placeholders})",
                (gang["gang_id"], *GANG_RECRUIT_ROLES)) as cur:
            recruiters = [r[0] for r in await cur.fetchall()]
        if not recruiters:       # gang sans encadrement (créé par un admin) : entrée directe en Recrue
            await db.execute("INSERT INTO gang_members (gang_id, user_id, role, joined_at) VALUES (?,?,'Recrue',?)",
                             (gang["gang_id"], user.id, now()))
            await db.commit()
            await update.message.reply_text(f"✅ Tu rejoins <b>{gang['name']}</b> comme Recrue.", parse_mode="HTML")
            return
        cur = await db.execute(
            "INSERT OR IGNORE INTO gang_applications(gang_id, user_id, status, created_at) VALUES (?,?,'pending',?)",
            (gang["gang_id"], user.id, now()))
        await db.commit()
        if not cur.rowcount:
            await update.message.reply_text("⏳ Ta candidature est déjà en attente.")
            return
        app_id = cur.lastrowid
    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ Accepter", callback_data=f"gjoin_accept_{app_id}"),
        InlineKeyboardButton("❌ Refuser", callback_data=f"gjoin_refuse_{app_id}"),
    ]])
    for rid in recruiters:
        try:
            await context.bot.send_message(
                rid, f"🔫 <b>Candidature</b> pour {gang['name']} : {user.full_name}", parse_mode="HTML",
                reply_markup=kb)
        except Exception:
            await notify(rid, "🔫 Candidature", f"{user.full_name} veut rejoindre {gang['name']}. 👉 Menu Gangs → Candidatures",
                         "info")
    await update.message.reply_text(f"📨 Candidature envoyée à <b>{gang['name']}</b>. Tu seras notifié(e) de la réponse.",
                                    parse_mode="HTML")


async def decide_application(app_id: int, decider_id: int, accept: bool) -> tuple[bool, str]:
    notes: list[tuple[int, str, str, str]] = []
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                    "SELECT a.*, g.name FROM gang_applications a JOIN gangs g ON g.gang_id=a.gang_id "
                    "WHERE a.app_id=?", (app_id,)) as cur:
                a = await cur.fetchone()
            if not a or a["status"] != "pending":
                await db.rollback()
                return False, "⌛ Candidature introuvable ou déjà traitée."
            async with db.execute("SELECT role FROM gang_members WHERE gang_id=? AND user_id=?",
                                  (a["gang_id"], decider_id)) as cur:
                dm = await cur.fetchone()
            if not dm or dm["role"] not in GANG_RECRUIT_ROLES:
                await db.rollback()
                return False, "❌ Réservé à l'encadrement du gang."
            if accept:
                async with db.execute("SELECT 1 FROM gang_members WHERE user_id=?", (a["user_id"],)) as cur:
                    if await cur.fetchone():
                        await db.execute("UPDATE gang_applications SET status='void' WHERE app_id=?", (app_id,))
                        await db.commit()
                        return False, "⚠️ Cette personne est déjà dans un gang."
                await db.execute("INSERT INTO gang_members (gang_id, user_id, role, joined_at) VALUES (?,?,'Recrue',?)",
                                 (a["gang_id"], a["user_id"], now()))
                await db.execute("UPDATE gang_applications SET status='accepted' WHERE app_id=?", (app_id,))
                notes.append((a["user_id"], "🔫 Candidature acceptée",
                              f"Tu rejoins <b>{a['name']}</b> comme <b>Recrue</b>.", "success"))
                msg = "✅ Recrue acceptée."
            else:
                await db.execute("UPDATE gang_applications SET status='refused' WHERE app_id=?", (app_id,))
                notes.append((a["user_id"], "🔫 Candidature refusée",
                              f"<b>{a['name']}</b> n'a pas retenu ta candidature.", "warning"))
                msg = "Candidature refusée."
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    for uid, title, body, kind in notes:
        await notify(uid, title, body, kind)
    return True, msg


async def gang_join_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    try:
        _, action, aid = (q.data or "").split("_")
        app_id = int(aid)
    except ValueError:
        return
    ok, msg = await decide_application(app_id, q.from_user.id, action == "accept")
    try:
        await q.edit_message_text(msg)
    except Exception:
        swallowed('handlers/gangs.py')


@require_registered
async def cmd_gang_candidatures(update: Update, context: ContextTypes.DEFAULT_TYPE):
    gang = await get_gang_membership(update.effective_user.id)
    if not gang or gang["role"] not in GANG_RECRUIT_ROLES:
        await update.message.reply_text("❌ Réservé à l'encadrement du gang.")
        return
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT a.app_id, u.full_name FROM gang_applications a JOIN users u ON u.user_id=a.user_id "
                "WHERE a.gang_id=? AND a.status='pending' ORDER BY a.app_id LIMIT 15", (gang["gang_id"],)) as cur:
            rows = await cur.fetchall()
    if not rows:
        await update.message.reply_text("Aucune candidature en attente.")
        return
    for r in rows:
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ Accepter", callback_data=f"gjoin_accept_{r['app_id']}"),
            InlineKeyboardButton("❌ Refuser", callback_data=f"gjoin_refuse_{r['app_id']}")]])
        await update.message.reply_text(f"🔫 Candidature #{r['app_id']} : {r['full_name']}", reply_markup=kb)


# ─────────────────────────────────────────────────────────────────────────────
# Hiérarchie : nommer / exclure
# ─────────────────────────────────────────────────────────────────────────────
async def _gang_target(update, context):
    """(id, nom, arguments restants) : le membre visé = joueur auquel on répond, sinon 1er argument (ID, via bouton)."""
    msg = update.message
    if msg and msg.reply_to_message:
        t = msg.reply_to_message.from_user
        return t.id, t.full_name, list(context.args)
    if context.args and context.args[0].isdigit():
        uid = int(context.args[0])
        async with db_connection() as db:
            async with db.execute("SELECT full_name FROM users WHERE user_id=?", (uid,)) as cur:
                row = await cur.fetchone()
        return uid, (row[0] if row and row[0] else str(uid)), list(context.args[1:])
    return None, None, list(context.args)


@require_registered
@require_free
async def cmd_gang_role(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Nommer un membre (Chef / Bras droit, jamais au-dessus de son propre rang). Boutons : Gangs → Changer un poste."""
    user = update.effective_user
    from gameplay.gangs import GangError, change_role
    tid, tname, rest = await _gang_target(update, context)
    try:
        result = await change_role(user.id, tid, " ".join(rest).strip().title())
    except GangError as exc:
        await update.effective_message.reply_text(f"❌ {exc}")
        return
    await update.effective_message.reply_text(f"✅ {escape_html(tname or str(tid))} est maintenant {escape_html(result['role'])}.")
    return

    me = await get_gang_membership(user.id)
    if not me or me["role"] not in GANG_MANAGE_ROLES:
        await update.effective_message.reply_text("❌ Réservé au Chef et au Bras droit.")
        return
    tid, tname, rest = await _gang_target(update, context)
    wanted = " ".join(rest).strip().lower()
    new_role = next((r for r in ROLE_NAMES if r.lower() == wanted), None)
    if not tid or not new_role or new_role == "Chef":
        await update.effective_message.reply_text("❌ Choisis un membre et un poste (le Chef change via « Passer chef »).")
        return
    tgt = await get_gang_membership(tid)
    if not tgt or tgt["gang_id"] != me["gang_id"] or tid == user.id:
        await update.effective_message.reply_text("❌ Ce joueur n'est pas un autre membre de ton gang.")
        return
    if role_rank(new_role) <= role_rank(me["role"]) or role_rank(tgt["role"]) <= role_rank(me["role"]):
        await update.effective_message.reply_text("❌ Tu ne peux gérer que des postes strictement inférieurs au tien.")
        return
    async with db_connection() as db:
        await db.execute("UPDATE gang_members SET role=? WHERE gang_id=? AND user_id=?",
                         (new_role, me["gang_id"], tid))
        await db.commit()
    verb = "promu(e)" if role_rank(new_role) < role_rank(tgt["role"]) else "rétrogradé(e)"
    await notify(tid, "🎖️ Changement de poste",
                 f"Dans <b>{me['name']}</b>, tu es {verb} <b>{new_role}</b>.",
                 "achievement" if verb == "promu(e)" else "warning")
    await update.effective_message.reply_text(f"✅ {tname} est maintenant {new_role}.")


@require_registered
@require_free
async def cmd_gang_exclure(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    from gameplay.gangs import GangError, exclude_member
    tid, tname, _ = await _gang_target(update, context)
    try:
        await exclude_member(user.id, tid)
    except GangError as exc:
        await update.effective_message.reply_text(f"❌ {exc}")
        return
    await update.effective_message.reply_text(f"✅ {escape_html(tname or str(tid))} est exclu(e).")
    return

    me = await get_gang_membership(user.id)
    if not me or me["role"] not in GANG_MANAGE_ROLES:
        await update.effective_message.reply_text("❌ Réservé au Chef et au Bras droit.")
        return
    tid, tname, _ = await _gang_target(update, context)
    tgt = await get_gang_membership(tid) if tid else None
    if not tgt or tgt["gang_id"] != me["gang_id"] or role_rank(tgt["role"]) <= role_rank(me["role"]):
        await update.effective_message.reply_text("❌ Tu ne peux exclure qu'un membre de rang inférieur.")
        return
    async with db_connection() as db:
        await db.execute("DELETE FROM gang_members WHERE gang_id=? AND user_id=?", (me["gang_id"], tid))
        await db.commit()
    await notify(tid, "🚪 Exclusion", f"Tu as été exclu(e) du gang <b>{me['name']}</b>.", "warning")
    await update.effective_message.reply_text(f"✅ {tname} est exclu(e).")


# ─────────────────────────────────────────────────────────────────────────────
# Partage quotidien du coffre
# ─────────────────────────────────────────────────────────────────────────────
async def payout_gang(gang_id: int, day: int | None = None) -> dict:
    """Partage GANG_PAYOUT_RATIO du coffre entre les membres selon leur poste. Idempotent par jour."""
    day = game_day() if day is None else day
    result = {"gang_id": gang_id, "status": "none", "pool": 0, "paid": 0, "count": 0}
    notes: list[tuple[int, str, str, str]] = []
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT name, treasury FROM gangs WHERE gang_id=?", (gang_id,)) as cur:
                g = await cur.fetchone()
            if not g:
                await db.rollback()
                return result
            done = await db.execute(
                "INSERT OR IGNORE INTO payroll_log VALUES ('gang_share',?,0,?,0,'done')", (str(gang_id), day))
            if not done.rowcount:                      # déjà partagé aujourd'hui
                await db.rollback()
                return result
            async with db.execute("SELECT user_id, role FROM gang_members WHERE gang_id=?", (gang_id,)) as cur:
                members = [(r["user_id"], r["role"]) for r in await cur.fetchall()]
            weights = {uid: GANG_ROLE_WEIGHT.get(role, 1) for uid, role in members}
            total_w = sum(weights.values())
            pool = int((g["treasury"] or 0) * GANG_PAYOUT_RATIO)
            if not members or pool < total_w:          # trop peu pour être partagé
                await db.commit()
                return result
            paid = 0
            for uid, role in members:
                amount = pool * weights[uid] // total_w
                if amount <= 0:
                    continue
                paid += amount
                await db.execute("UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                                 (amount, amount, uid))
                notes.append((uid, "🔫 Partage du coffre",
                              f"<b>{g['name']}</b> partage son coffre : ton poste (<b>{role}</b>) te rapporte "
                              f"<b>+{fmt(amount)}</b>.", "economy"))
            await db.execute("UPDATE gangs SET treasury=treasury-? WHERE gang_id=?", (paid, gang_id))
            await db.commit()
            result.update(status="paid", pool=pool, paid=paid, count=len(members))
        except Exception:
            await db.rollback()
            raise
    for uid, title, body, kind in notes:
        await notify(uid, title, body, kind)
    return result


async def run_gang_payout() -> None:
    async with db_connection() as db:
        async with db.execute("SELECT gang_id FROM gangs") as cur:
            ids = [r[0] for r in await cur.fetchall()]
    for gid in ids:
        try:
            await payout_gang(gid)
        except Exception:
            logger.exception("Partage du gang %s impossible", gid)
