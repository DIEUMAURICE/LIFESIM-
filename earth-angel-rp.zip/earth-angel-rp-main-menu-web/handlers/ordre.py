# handlers/ordre.py — 🚓 Ordre public : police & armée, papiers, signalements, crimes sur joueurs (100 % boutons)
"""
Entrées : /ordre (menu État & factions → Police & Armée), /papiers, /signaler, /antihack.
Tous les écrans sont des boutons (callbacks `ord:…`) ; les saisies (pseudo, motif) passent par utils/input_flow.
La logique est dans utils/ordre.py. Les discussions d'interrogatoire / d'entretien sont relayées par
`relay_message_handler` (à enregistrer en groupe -2, avant la saisie guidée).
"""
from utils.swallow import swallowed
import asyncio
import html
import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ApplicationHandlerStop, ContextTypes

from config import (
    ORDRE, ORDRE_FACTIONS, ORDRE_STATIONS, ORDRE_POSTS, ORDRE_DG_POST, ORDRE_CHIEF_POST, ORDRE_HEAD_LEVEL,
    ORDRE_PLAYER_CRIMES, ANTI_HACK_PLANS, CRIME_COOLDOWN, GOV_FACTIONS, role_level, ORDRE_CENTRAL_HEAD,
)
from database import db_connection, get_user, now, update_field
from utils import ordre
from utils.decorators import require_registered, get_user_role_async
from utils.factions import coffre_balance
from utils.gametime import fmt_game_datetime
from utils.input_flow import ask, flow
from utils.location import location_label
from utils.helpers import send_or_edit as _send

logger = logging.getLogger(__name__)

CB = "ord:"
_TASKS: set = set()   # références des tâches de fond (sinon le ramasse-miettes peut les tuer)


# ─────────────────────────────────────────────────────────────────────────────
#  Outils d'affichage
# ─────────────────────────────────────────────────────────────────────────────
def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text, callback_data=data)


def _e(s) -> str:
    return html.escape(str(s))


async def _reply(update: Update, text: str, markup: InlineKeyboardMarkup | None = None) -> None:
    """Réponse à une saisie guidée (toujours un nouveau message)."""
    await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


async def _is_leader(uid: int) -> bool:
    """Game Leader et plus : nomment les DG."""
    return role_level(await get_user_role_async(uid)) >= role_level("GAME_LEADER")


async def _can_direct(uid: int, faction: str) -> bool:
    """Game Leader et plus, ou ministre de cette faction (Intérieur → police, Défense → armée, Justice → justice)."""
    from utils.roles import can_direct_faction
    return await can_direct_faction(uid, faction, await get_user_role_async(uid))


async def _directable(uid: int) -> list[str]:
    """Factions d'ordre dont `uid` nomme la direction."""
    return [f for f in ORDRE_FACTIONS if await _can_direct(uid, f)]


async def _is_admin(uid: int) -> bool:
    return role_level(await get_user_role_async(uid)) >= role_level("ADMIN_N2")


def _faction_label(f: str) -> str:
    return f"{GOV_FACTIONS[f]['emoji']} {GOV_FACTIONS[f]['name']}"


def _back(to: str = "home") -> list:
    return [_btn("⬅️ Retour", CB + to)]


# ─────────────────────────────────────────────────────────────────────────────
#  Accueil
# ─────────────────────────────────────────────────────────────────────────────
async def show_home(update: Update, uid: int, note: str = "") -> None:
    u = await get_user(uid)
    st = await ordre.get_staff(uid)
    rec = None if st else await ordre.recruiter(uid)          # santé : direction qui recrute
    flee = await ordre.flee_case(uid)
    lines = ["🚓 <b>Ordre public</b>", ""]
    if note:
        lines += [note, ""]
    karma = u.get("karma", 0)
    lines.append(f"☯️ Karma : <b>{karma:+d}</b>")
    restrained = await ordre.restraint_reason(uid)
    if restrained:
        lines.append(f"⛓️ Tu es {restrained}")
    if u.get("prison_until", 0) > now():
        lines.append("⛓️ Tu es en prison (caution / tribunal / avocat : menu État & factions → Justice).")
    if flee and flee["open_at"] > ordre.rnow():
        lines.append(f"🏃 En fuite : enquête dans ~<b>{ordre.fmt_s(flee['open_at'] - ordre.rnow())}</b>.")
    elif flee:
        lines.append("🚨 Une enquête est ouverte sur ton dernier coup.")
    if st:
        lines.append(f"{st['faction_emoji']} <b>{st['post_name']}</b> · {_e(st['station_name'])} · "
                     f"{st['code']} · {'🟢 en service' if st['on_duty'] else '⚪ hors service'}")
    rows = []
    if flee and flee["open_at"] > ordre.rnow():
        rows.append([_btn("🫥 Se cacher", CB + "hide")])
    rows.append([_btn("📄 Mes papiers", CB + "papers"), _btn("📢 Signaler un joueur", CB + "report")])
    rows.append([_btn("🛡️ Anti-piratage", CB + "ah"), _btn("🏢 Postes & effectifs", CB + "stations")])
    rows.append([_btn("⚖️ Justice", "jus:home"), _btn("🔫 Mes armes", "wp:inv")])
    if st:
        rows.append([_btn("👔 Mon poste", CB + "job")])
        if st["can_act"]:
            rows.append([_btn("🚓 Joueurs", CB + "pl:0"), _btn("📢 Signalements", CB + "reps")])
        if st["faction"] in ("police", "armee"):
            rows.append([_btn("🛠️ Chambre d'armes", "wp:arm")])
        if st["faction"] == "police" and st["role"] in ("enquete", "head"):
            rows.append([_btn("🕵️ Enquêtes", CB + "cases")])
        if st["is_head"]:
            rows.append([_btn("📨 Candidatures", CB + "apps"), _btn("👥 Équipe", CB + "team")])
    elif rec:
        if rec["is_head"]:
            rows.append([_btn("📨 Candidatures", CB + "apps")])
    else:
        rows.append([_btn("📝 Postuler dans une faction", CB + "apply")])
    if await _directable(uid):
        rows.append([_btn("👑 Nommer un DG", CB + "dg")])
    rows.append([_btn("🔄 Actualiser", CB + "home"), _btn("⬅️ Menu", "hub:etat:0")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Postes & effectifs, candidature
# ─────────────────────────────────────────────────────────────────────────────
async def show_stations(update: Update, uid: int) -> None:
    lines = ["🏢 <b>Postes & effectifs</b>", ""]
    for f in ORDRE_FACTIONS:
        lines.append(f"{_faction_label(f)} — 🏦 coffre : <b>{await coffre_balance(f):,}</b>")
        for s in await ordre.overview(f):
            head = s["head"]
            h = f"{head['post_emoji']} {_e(head.get('full_name') or head['user_id'])}" if head else "<i>direction vacante</i>"
            lines.append(f"  • {_e(s['name'])} : {s['count']} agent(s), 🟢 {s['on_duty']} · {h}")
        lines.append("")
    await _send(update, "\n".join(lines), InlineKeyboardMarkup([_back()]))


async def show_apply(update: Update, uid: int) -> None:
    rows = [[_btn(_faction_label(f), CB + f"apf:{f}")] for f in ordre.RECRUIT_FACTIONS]
    rows.append(_back())
    await _send(update, "📝 <b>Postuler</b>\n\nChoisis la faction. Un entretien d'embauche (discussion via le bot) "
                        "avec le DG ou un chef de poste décidera de ton recrutement.", InlineKeyboardMarkup(rows))


async def show_apply_station(update: Update, uid: int, faction: str) -> None:
    rows = [[_btn(ordre.station_name(faction, sid), CB + f"ap:{faction}:{sid}")] for sid in ordre.station_ids(faction)]
    rows.append(_back("apply"))
    await _send(update, f"📝 {_faction_label(faction)} — dans quel poste veux-tu servir ?", InlineKeyboardMarkup(rows))


async def do_apply(update: Update, uid: int, faction: str, station: str) -> None:
    from handlers.sante import _housing_error
    err = await _housing_error(uid)
    if err:
        await show_home(update, uid, err)
        return
    ok, msg = await ordre.apply_for_job(uid, faction, station)
    await show_home(update, uid, msg if ok else f"❌ {msg}")


# ─────────────────────────────────────────────────────────────────────────────
#  Papiers
# ─────────────────────────────────────────────────────────────────────────────
async def show_papers(update: Update, uid: int) -> None:
    st = await ordre.get_staff(uid)
    rows = [[_btn("🪪 Carte d'identité", CB + "doc:id"), _btn("📒 Carnet de travail", CB + "doc:work")],
            [_btn("🚗 Carte grise", CB + "doc:car")]]
    if st:
        rows[1].append(_btn("🎖️ Insigne", CB + "doc:badge"))
        if st["is_head"]:
            rows.append([_btn("📊 Activité des employés", CB + "act")])
    rows.append(_back())
    await _send(update, "📄 <b>Mes papiers</b>\n\nChoisis un document.", InlineKeyboardMarkup(rows))


def _date(ts: int) -> str:
    """Date de JEU (created_at des joueurs)."""
    try:
        return fmt_game_datetime(ts)
    except Exception:
        return "—"


def _rdate(ts: int) -> str:
    """Date de JEU (journal des événements Ordre public)."""
    from utils.gametime import fmt_game_date, fmt_game_time
    return f"{fmt_game_date(ts)[:5]} {fmt_game_time(ts)}"


async def show_doc(update: Update, uid: int, doc: str) -> None:
    rows = [_back("papers")]
    if doc == "id":
        c = await ordre.id_card(uid)
        text = (f"🪪 <b>CARTE D'IDENTITÉ</b>\n━━━━━━━━━━━━━━\n"
                f"N° : <code>{c['number']}</code>\nNom : <b>{_e(c['name'])}</b>\nPseudo : @{_e(c['username'])}\n"
                f"ID : <code>{c['user_id']}</code>\nInscrit(e) depuis : {_date(c['created_at'])}\n"
                f"☯️ Karma : {c['karma']:+d}")
    elif doc == "work":
        w = await ordre.work_book(uid)
        lines = [f"📒 <b>CARNET DE TRAVAIL</b>\n━━━━━━━━━━━━━━\nN° : <code>{w['number']}</code>"]
        if w["staff"]:
            s = w["staff"]
            lines.append(f"{s['faction_emoji']} {s['faction_name']} — <b>{s['post_name']}</b> ({_e(s['station_name'])}) "
                         f"· {s['salary_h']:,}/h de jeu")
        elif w["company"]:
            lines.append(f"🏢 {_e(w['company']['name'])} — {_e(w['company']['poste'])}")
        elif w["job"]:
            lines.append(f"💼 Petit métier : {_e(w['job'])}")
        else:
            lines.append("Aucun emploi actuellement.")
        if w["events"]:
            lines.append("\n<b>Derniers événements</b>")
            for ev in w["events"]:
                lines.append(f"• {_rdate(ev['ts'])} — {_e(ev['action'].replace('_', ' '))} {_e(ev['details'])}")
        text = "\n".join(lines)
    elif doc == "car":
        cars = await ordre.vehicle_papers(uid)
        lines = ["🚗 <b>CARTE GRISE</b>\n━━━━━━━━━━━━━━"]
        lines += [f"<code>{c['plate']}</code> — {_e(c['type'])} · état {c['condition']}% · "
                  f"{'assuré' if c['insured'] else 'non assuré'}" for c in cars] or ["Aucun véhicule immatriculé."]
        text = "\n".join(lines)
    else:
        b = await ordre.badge(uid)
        if not b:
            await show_papers(update, uid)
            return
        text = (f"🎖️ <b>INSIGNE — {b['faction_name'].upper()}</b>\n━━━━━━━━━━━━━━\n"
                f"N° d'agent : <code>{b['code']}</code>\nNom : <b>{_e(b['name'])}</b> (@{_e(b['username'])})\n"
                f"ID : <code>{b['user_id']}</code>\nPoste : <b>{b['post_emoji']} {b['post_name']}</b>\n"
                f"Affectation : {_e(b['station_name'])}\nActivité : <b>{b['activity']}</b> action(s)\n"
                f"Statut : {'🟢 en service' if b['on_duty'] else '⚪ hors service'}")
    await _send(update, text, InlineKeyboardMarkup(rows))


async def show_activity(update: Update, uid: int) -> None:
    rows, err = await ordre.staff_activity(uid)
    if err:
        await _send(update, f"❌ {err}", InlineKeyboardMarkup([_back("papers")]))
        return
    lines = ["📊 <b>Activité des employés</b>", ""]
    for r in rows[:25]:
        lines.append(f"{r['post_emoji']} <code>{r['code']}</code> {_e(r.get('full_name') or r['user_id'])} — "
                     f"{r['post_name']} · {_e(r['station_name'])} · <b>{r['activity']}</b> "
                     f"{'🟢' if r['on_duty'] else '⚪'}")
    await _send(update, "\n".join(lines) or "Aucun employé.", InlineKeyboardMarkup([_back("papers")]))


# ─────────────────────────────────────────────────────────────────────────────
#  Mon poste
# ─────────────────────────────────────────────────────────────────────────────
async def show_job(update: Update, uid: int, note: str = "") -> None:
    st = await ordre.get_staff(uid)
    if not st:
        await show_home(update, uid)
        return
    lines = [f"{st['faction_emoji']} <b>{st['faction_name']}</b>", ""]
    if note:
        lines += [note, ""]
    lines += [f"🎖️ Poste : <b>{st['post_emoji']} {st['post_name']}</b>",
              f"📍 {_e(st['station_name'])} ({location_label(st['location'])})",
              f"🪪 Matricule : <code>{st['code']}</code>",
              f"💰 Salaire : <b>{st['salary_h']:,}</b> par heure de jeu (payé par le coffre)",
              f"🏦 Coffre de la faction : <b>{await coffre_balance(st['faction']):,}</b>",
              f"⚡ Activité : <b>{st['activity']}</b>",
              f"Statut : {'🟢 en service' if st['on_duty'] else '⚪ hors service'}"]
    rows = []
    if st["can_act"] or st["faction"] == "justice":
        rows.append([_btn("⚪ Quitter le service", CB + "duty:off")] if st["on_duty"]
                    else [_btn("🟢 Prendre mon service (sur place)", CB + "duty:on")])
    rows.append([_btn("🎖️ Mon insigne", CB + "doc:badge")])
    rows.append(_back())
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Liste des joueurs & pouvoirs
# ─────────────────────────────────────────────────────────────────────────────
async def show_players(update: Update, uid: int, page: int = 0, query: str = "") -> None:
    st = await ordre.get_staff(uid)
    if not st or not st["can_act"]:
        await _send(update, "❌ Réservé aux agents.", InlineKeyboardMarkup([_back()]))
        return
    rows_db, total = await ordre.list_players(uid, page, query)
    lines = [f"🚓 <b>Joueurs</b> ({total})" + (f" — « {_e(query)} »" if query else ""),
             "<i>⚠️ = recherché · ☯️ = karma</i>", ""]
    rows = []
    for r in rows_db:
        name = r["full_name"] or r["username"] or str(r["user_id"])
        rows.append([_btn(f"{'⚠️ ' if r['wanted'] else ''}{name[:22]} · ☯️ {r['karma']:+d}", CB + f"p:{r['user_id']}")])
    nav = []
    if page > 0:
        nav.append(_btn("⬅️", CB + f"pl:{page - 1}"))
    if (page + 1) * ordre.PAGE_PLAYERS < total:
        nav.append(_btn("➡️", CB + f"pl:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([_btn("🔎 Chercher un joueur", CB + "pf")])
    rows.append(_back())
    if not rows_db:
        lines.append("Aucun joueur.")
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_player(update: Update, uid: int, target: int, note: str = "") -> None:
    st = await ordre.get_staff(uid)
    card = await ordre.player_card(target)
    if not st or not st["can_act"] or not card:
        await show_home(update, uid, "❌ Action impossible.")
        return
    lines = [f"👤 <b>{_e(card['name'])}</b>" + (f" (@{_e(card['username'])})" if card["username"] else ""),
             f"🆔 <code>{card['user_id']}</code> · ☯️ Karma : <b>{card['karma']:+d}</b>"]
    if card["prison"]:
        lines.append(f"⛓️ En prison ({ordre.fmt_s(card['prison'])})")
    if card["flags"]:
        lines.append("État : " + ", ".join(card["flags"]))
    if card["case"]:
        lines.append(f"⚠️ <b>Recherché(e)</b> — dossier #{card['case']['id']} ({_e(card['case']['crime'])})")
    if card["army_wanted"]:
        lines.append("🪖 Recherché(e) par l'ARMÉE (tueur d'un membre du gouvernement).")
    if note:
        lines += ["", note]
    cuffs = await ordre.active_cuffs(uid)
    lines.append(f"\n⛓️ Menottes : {len(cuffs)}/{ORDRE['cuffs_max']}")
    rows = [[_btn(f"⚡ Neutraliser ({ORDRE['stun_seconds']} s)", CB + f"a:stun:{target}"),
             _btn("⛓️ Menotter", CB + f"a:cuff:{target}")]]
    mine = await ordre.get_status(target, "cuffs")
    if mine and mine["by_id"] == uid:
        rows.append([_btn("🧑‍⚖️ Escorter en salle d'interrogatoire", CB + f"a:esc:{target}"),
                     _btn("🔓 Retirer les menottes", CB + f"a:unc:{target}")])
    inter = await ordre.get_status(target, "interro")
    if inter and inter["by_id"] == uid:
        rows.append([_btn("🧑‍⚖️ Décision (emprisonner / libérer)", CB + f"in:{target}")])
    if st["faction"] == "armee" and card["army_wanted"]:
        rows.append([_btn("🪖 Capturer (tueur du gouvernement)", CB + f"a:cap:{target}")])
    hold = await ordre.get_status(target, "hold")
    if hold and hold["by_id"] == uid:
        rows.append([_btn("🚓 Livrer à la police", CB + f"ad:deliver:{target}"),
                     _btn("💀 Exécuter", CB + f"ad:execute:{target}")])
    rows.append([_btn("⬅️ Joueurs", CB + "pl:0")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_interrogation(update: Update, uid: int, target: int, note: str = "") -> None:
    st = await ordre.get_status(target, "interro")
    if not st or st["by_id"] != uid:
        await show_player(update, uid, target, "ℹ️ Aucun interrogatoire en cours avec cette personne.")
        return
    name = await ordre._display_name(target)
    lines = [f"🧑‍⚖️ <b>Interrogatoire — {_e(name)}</b>",
             f"⏳ Temps restant : <b>{ordre.fmt_s(st['until'] - ordre.rnow())}</b>",
             "", "Écris simplement ici : le bot transmet tes messages au suspect (et ses réponses te reviennent).",
             "À la fin, décide :"]
    if note:
        lines = [note, ""] + lines
    rows = [[_btn(f"⛓️ {s // 60} min", CB + f"jail:{target}:{s}") for s in ORDRE["jail_choices"][:2]],
            [_btn(f"⛓️ {s // 60} min", CB + f"jail:{target}:{s}") for s in ORDRE["jail_choices"][2:]],
            [_btn("🔓 Libérer", CB + f"free:{target}")]]
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Enquêtes (mini-jeu)
# ─────────────────────────────────────────────────────────────────────────────
async def show_cases(update: Update, uid: int, note: str = "") -> None:
    me, err = await ordre.investigator_check(uid)
    if err:
        await _send(update, f"❌ {err}", InlineKeyboardMarkup([_back()]))
        return
    cases = await ordre.list_cases(10)
    lines = ["🕵️ <b>Enquêtes</b>", "",
             f"Mini-jeu : mémorise une séquence de {ORDRE['mg_len']}+ symboles ({ORDRE['mg_show']} s), puis reproduis-la. "
             f"{ORDRE['mg_attempts']} essais par dossier.", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    for c in cases:
        who = f" — {_e(c['suspect_name'])}" if c["status"] == "solved" or c["kind"] != "bot" else ""
        label = "✅ résolu" if c["status"] == "solved" else f"essai {c['attempts']}/{ORDRE['mg_attempts']}"
        rows.append([_btn(f"#{c['id']} {c['crime'][:18]} ({label})", CB + f"case:{c['id']}")])
        lines.append(f"#{c['id']} · {_e(c['crime'])}{who} · {label}")
    if not cases:
        lines.append("Aucun dossier ouvert.")
    rows.append(_back())
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_case(update: Update, uid: int, case_id: int) -> None:
    c = await ordre.get_case(case_id)
    if not c or c["status"] not in ("open", "solved"):
        await show_cases(update, uid, "ℹ️ Ce dossier n'est plus ouvert.")
        return
    lines = [f"📁 <b>Dossier #{c['id']}</b> — {_e(c['crime'])}",
             f"Type : {'crime contre le bot' if c['kind'] == 'bot' else 'crime sur un joueur' if c['kind'] == 'joueur' else 'signalement'}",
             f"Essais utilisés : {c['attempts']}/{ORDRE['mg_attempts']}"]
    rows = []
    if c["status"] == "solved":
        lines.append(f"✅ Résolu — suspect : <b>{_e(c['suspect_name'])}</b>")
        rows.append([_btn("🚨 Arrêter le suspect", CB + f"arrest:{c['id']}")])
    else:
        lines.append("🔒 Suspect inconnu : réussis le mini-jeu pour le retrouver.")
        rows.append([_btn("🧠 Lancer l'enquête (mini-jeu)", CB + f"mg:{c['id']}")])
    rows.append([_btn("⬅️ Enquêtes", CB + "cases")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


def _symbol_keyboard() -> InlineKeyboardMarkup:
    syms = ORDRE["mg_symbols"]
    rows = [[_btn(s, CB + f"mgp:{i}") for i, s in enumerate(syms[:3])],
            [_btn(s, CB + f"mgp:{i + 3}") for i, s in enumerate(syms[3:])]]
    return InlineKeyboardMarkup(rows)


async def _hide_sequence(bot, chat_id: int, message_id: int, total: int, case_id: int) -> None:
    """Cache la séquence après quelques secondes et affiche le clavier de saisie (tâche de fond)."""
    try:
        await asyncio.sleep(ORDRE["mg_show"])
        await bot.edit_message_text(
            chat_id=chat_id, message_id=message_id, parse_mode="HTML", reply_markup=_symbol_keyboard(),
            text=f"🧠 <b>Dossier #{case_id}</b>\nReproduis la séquence dans l'ordre.\n\nProgression : <b>0/{total}</b>")
    except Exception:
        logger.exception("Masquage de la séquence impossible")


async def start_minigame(update: Update, context: ContextTypes.DEFAULT_TYPE, uid: int, case_id: int) -> None:
    ok, err, seq = await ordre.mg_start(uid, case_id)
    if not ok:
        await show_cases(update, uid, f"❌ {err}")
        return
    q = update.callback_query
    text = (f"🧠 <b>Dossier #{case_id}</b> — mémorise (<b>{ORDRE['mg_show']} s</b>) :\n\n"
            f"<b>{ordre.seq_to_text(seq)}</b>\n\n<i>{len(seq)} symboles.</i>")
    await _send(update, text, None)
    msg = q.message
    t = asyncio.create_task(_hide_sequence(context.bot, msg.chat_id, msg.message_id, len(seq), case_id))
    _TASKS.add(t)
    t.add_done_callback(_TASKS.discard)


async def press_symbol(update: Update, uid: int, symbol: int) -> None:
    r = await ordre.mg_press(uid, symbol)
    st = r["state"]
    if st == "none":
        await show_cases(update, uid, "ℹ️ Aucun mini-jeu en cours.")
    elif st == "wait":
        return      # la séquence est encore affichée : on ignore le clic
    elif st == "continue":
        await _send(update, f"🧠 <b>Dossier #{r['case_id']}</b>\nReproduis la séquence dans l'ordre.\n\n"
                            f"Progression : <b>{r['pos']}/{r['total']}</b>", _symbol_keyboard())
    elif st == "win":
        await _send(update, f"✅ <b>Enquête réussie !</b> Le suspect du dossier #{r['case_id']} est identifié.",
                    InlineKeyboardMarkup([[_btn("🚨 Arrêter le suspect", CB + f"arrest:{r['case_id']}")],
                                          [_btn("⬅️ Enquêtes", CB + "cases")]]))
    else:
        rows = []
        if r.get("retry"):
            rows.append([_btn("🔁 Réessayer (nouvelle séquence)", CB + f"mg:{r['case_id']}")])
        rows.append([_btn("⬅️ Enquêtes", CB + "cases")])
        txt = (f"❌ <b>Raté !</b> Un symbole était faux. " +
               ("Il te reste un essai sur ce dossier." if r.get("retry") else "Plus d'essai : <b>affaire classée</b>."))
        await _send(update, txt, InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Signalements
# ─────────────────────────────────────────────────────────────────────────────
async def show_reports(update: Update, uid: int, note: str = "") -> None:
    st = await ordre.get_staff(uid)
    if not st or st["faction"] != "police" or not st["can_act"]:
        await _send(update, "❌ Les signalements sont traités par la police.", InlineKeyboardMarkup([_back()]))
        return
    reps = await ordre.list_reports(8)
    lines = ["📢 <b>Signalements en attente</b>", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    for r in reps:
        lines.append(f"#{r['id']} · {_e(r['reporter_name'])} → <b>{_e(r['target_name'])}</b>\n   « {_e(r['reason'])} »")
        rows.append([_btn(f"✅ Fondé #{r['id']}", CB + f"repd:{r['id']}:1"),
                     _btn(f"🗂️ Sans suite #{r['id']}", CB + f"repd:{r['id']}:0")])
    if not reps:
        lines.append("Aucun signalement.")
    rows.append(_back())
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Candidatures, entretien, équipe
# ─────────────────────────────────────────────────────────────────────────────
async def show_apps(update: Update, uid: int, note: str = "") -> None:
    apps = await ordre.list_apps(uid)
    lines = ["📨 <b>Candidatures</b>", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    for a in apps:
        flag = "🗣️" if a["status"] == "interview" else "🆕"
        name = a["full_name"] or a["username"] or a["user_id"]
        lines.append(f"{flag} #{a['id']} · {_e(name)} → {_e(ordre.station_name(a['faction'], a['station_id']))}")
        rows.append([_btn(f"{flag} #{a['id']} {str(name)[:20]}", CB + f"app:{a['id']}")])
    if not apps:
        lines.append("Aucune candidature en attente.")
    rows.append(_back())
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_app(update: Update, uid: int, app_id: int, note: str = "") -> None:
    apps = {a["id"]: a for a in await ordre.list_apps(uid)}
    a = apps.get(app_id)
    if not a:
        await show_apps(update, uid, "ℹ️ Cette candidature n'existe plus.")
        return
    card = await ordre.id_card(a["user_id"])
    wb = await ordre.work_book(a["user_id"])
    cars = await ordre.vehicle_papers(a["user_id"])
    u = await get_user(a["user_id"])
    lines = [f"📝 <b>Candidature #{a['id']}</b> — {_faction_label(a['faction'])}",
             f"Poste visé : {_e(ordre.station_name(a['faction'], a['station_id']))}", "",
             "<b>Papiers du candidat</b>",
             f"🪪 Carte d'identité : <code>{card['number']}</code> — {_e(card['name'])} (@{_e(card['username'])}) · ☯️ {card['karma']:+d}",
             f"📒 Carnet de travail : " + ("faction " + wb["staff"]["faction_name"] if wb["staff"] else
                                          (_e(wb["company"]["name"]) if wb["company"] else (_e(wb["job"]) or "aucun emploi"))),
             f"🚗 Carte grise : {len(cars)} véhicule(s)",
             f"⛓️ Casier : " + ("EN PRISON" if u.get("prison_until", 0) > now() else
                              f"{u.get('crimes_success', 0)} crime(s) réussi(s)")]
    if note:
        lines = [note, ""] + lines
    rows = [[_btn("🗣️ Entretien (discussion)", CB + f"int:{a['id']}")],
            [_btn("✅ Recruter", CB + f"acc:{a['id']}"), _btn("❌ Refuser", CB + f"ref:{a['id']}")],
            [_btn("⬅️ Candidatures", CB + "apps")]]
    chat = await ordre.active_chat(uid)
    if chat and chat["kind"] == "entretien" and chat["ref"] == app_id:
        rows.insert(0, [_btn("⏹️ Terminer l'entretien", CB + "endchat")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_team(update: Update, uid: int, note: str = "") -> None:
    me = await ordre.get_staff(uid)
    if not me or not me["is_head"]:
        await _send(update, "❌ Réservé à la direction (DG, chefs de poste, juges).", InlineKeyboardMarkup([_back()]))
        return
    sid = me["station_id"] if me["post"] == ORDRE_CHIEF_POST else None
    staff = await ordre.list_staff(me["faction"], sid)
    lines = [f"👥 <b>Équipe — {me['faction_name']}</b>", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    for s in staff:
        if s["user_id"] == uid:
            continue
        name = s.get("full_name") or s["user_id"]
        rows.append([_btn(f"{s['post_emoji']} {str(name)[:16]} · {s['post_name'][:14]} · {s['station_id']}", CB + f"m:{s['user_id']}")])
    if not rows:
        lines.append("Aucun autre membre.")
    if me["central_head"] and len(ORDRE_STATIONS[me["faction"]]) > 1:
        rows.append([_btn("🛡️ Nommer un chef de poste", CB + "chief")])
    rows.append(_back())
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_member(update: Update, uid: int, target: int, note: str = "") -> None:
    me = await ordre.get_staff(uid)
    t = await ordre.get_staff(target)
    if not me or not t or not me["is_head"] or me["faction"] != t["faction"]:
        await show_team(update, uid, "ℹ️ Membre introuvable.")
        return
    lines = [f"{t['post_emoji']} <b>{_e(await ordre._display_name(target))}</b>",
             f"Poste : <b>{t['post_name']}</b> · {_e(t['station_name'])}", f"🪪 <code>{t['code']}</code> · ⚡ {t['activity']}"]
    if note:
        lines = [note, ""] + lines
    rows = [[_btn("🎖️ Changer de poste", CB + f"mp:{target}"), _btn("🏢 Affecter", CB + f"ms:{target}")],
            [_btn("🚪 Renvoyer", CB + f"mf:{target}")], [_btn("⬅️ Équipe", CB + "team")]]
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Crimes contre des joueurs & défense anti-hack
# ─────────────────────────────────────────────────────────────────────────────
async def show_player_crimes(update: Update, uid: int, note: str = "") -> None:
    lines = ["🎯 <b>Crimes sur des joueurs</b>", "",
             "<i>Réservé aux membres d'un gang. Réussi : la police est alertée (police + armée si le gouvernement "
             "est concerné). Raté : prison.</i>", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    for k, c in ORDRE_PLAYER_CRIMES.items():
        extra = f" · 🧠 {c['need'][0]} {c['need'][1]}+" if c["need"] else ""
        lines.append(f"{c['emoji']} <b>{c['name']}</b> · {int(c['success'] * 100)}%{extra}")
        rows.append([_btn(f"{c['emoji']} {c['name']}", CB + f"pcx:{k}")])
    rows.append([_btn("⬅️ Crimes", "crime_list")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_defense(update: Update, uid: int, note: str = "") -> None:
    d = await ordre.get_defense(uid)
    lines = ["🛡️ <b>Défense anti-hack</b>", ""]
    if note:
        lines = [note, ""] + lines
    lines.append(f"Actuelle : {d['emoji']} <b>{d['name']}</b> (encore {ordre.fmt_s(d['left'])} de jeu)" if d
                 else "Actuelle : <b>aucune</b> — les pirates te visent librement.")
    rows = []
    for k, p in ANTI_HACK_PLANS.items():
        lines.append(f"{p['emoji']} {p['name']} — {p['cost']:,} · bloque tous les piratages · {p['days']} jours de jeu")
        rows.append([_btn(f"{p['emoji']} {p['name']} ({p['cost']:,})", CB + f"ahb:{k}")])
    rows.append(_back())
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def _crime_gate(uid: int) -> str:
    """Message d'erreur si le joueur ne peut pas commettre de crime maintenant."""
    u = await get_user(uid)
    if u.get("health", 100) <= 0 and not u.get("god_mode"):
        return "💀 Ta santé est à zéro : tu es hors d'état d'agir."
    if u.get("prison_until", 0) > now():
        return "⛓️ Tu es en prison !"
    if u.get("hospital_until", 0) > now():
        return "🏥 Tu es à l'hôpital !"
    r = await ordre.restraint_reason(uid)
    if r:
        return f"⛓️ Tu es {r}"
    if now() - u.get("last_crime", 0) < CRIME_COOLDOWN:
        from utils.helpers import fmt_time
        return f"⏳ Calme-toi ! Attends <b>{fmt_time(CRIME_COOLDOWN - (now() - u.get('last_crime', 0)))}</b>."
    from handlers.gangs import require_gang, NO_GANG_CRIME_TEXT
    if not await require_gang(uid):
        return NO_GANG_CRIME_TEXT
    return ""


# ─────────────────────────────────────────────────────────────────────────────
#  Saisies guidées (pseudo / motif)
# ─────────────────────────────────────────────────────────────────────────────
@flow("ord_pc_target")
async def _flow_pc_target(update, context, value, data):
    uid = update.effective_user.id
    target_id, name = value
    err = await _crime_gate(uid)
    if err:
        await _reply(update, err, InlineKeyboardMarkup([_back("home")]))
        return
    res = await ordre.commit_player_crime(uid, data["key"], target_id)
    if not res["ok"]:
        await _reply(update, f"❌ {res['msg']}", InlineKeyboardMarkup([[_btn("🎯 Autre crime", CB + "pc")]]))
        return
    await update_field(uid, "last_crime", now())
    cfg = ORDRE_PLAYER_CRIMES[data["key"]]
    if res["success"]:
        body = [f"✅ <b>{cfg['name']} — RÉUSSI</b>", f"<i>{res['msg']}</i>", "",
                f"🎯 Cible : <b>{_e(name)}</b>"]
        if res["amount"]:
            body.append(f"💰 Butin : <b>{res['amount']:,}</b>")
        body += [f"🌟 Karma : <b>{cfg['karma']:+d}</b>", "", "🚨 <b>La police est alertée</b> : tu es recherché(e)."]
    else:
        from utils.helpers import fmt_time
        body = [f"❌ <b>{cfg['name']} — ÉCHEC</b>", f"<i>{res['msg']}</i>", "",
                f"⛓️ Prison : <b>{fmt_time(res['jail'])}</b>"]
    await _reply(update, "\n".join(body), InlineKeyboardMarkup([[_btn("⬅️ Crimes", "crime_list")]]))


@flow("ord_search")
async def _flow_search(update, context, value, data):
    uid = update.effective_user.id
    st = await ordre.get_staff(uid)
    if not st or not st["can_act"]:
        return
    target_id, _name = value
    await _reply(update, "🔎 Joueur trouvé :", InlineKeyboardMarkup([[_btn("👤 Ouvrir la fiche", CB + f"p:{target_id}")]]))


@flow("ord_report_target")
async def _flow_report_target(update, context, value, data):
    target_id, name = value
    if target_id == update.effective_user.id:
        await _reply(update, "❌ Tu ne peux pas te signaler toi-même.", InlineKeyboardMarkup([_back()]))
        return
    await ask(update, context, "ord_report_reason",
              f"📢 Signalement de <b>{_e(name)}</b> : quel est le problème ? (une phrase)",
              kind="text", data={"target": target_id}, back=CB + "home")


@flow("ord_report_reason")
async def _flow_report_reason(update, context, value, data):
    ok, msg = await ordre.report_player(update.effective_user.id, data["target"], value)
    await _reply(update, ("✅ " if ok else "❌ ") + msg, InlineKeyboardMarkup([_back()]))


@flow("ord_dg_target")
async def _flow_dg(update, context, value, data):
    uid = update.effective_user.id
    if not await _can_direct(uid, data["faction"]):
        return
    target_id, name = value
    ok, msg = await ordre.appoint_dg(uid, target_id, data["faction"])
    await _reply(update, ("✅ " if ok else "❌ ") + f"{_e(name)} : {msg}", InlineKeyboardMarkup([_back()]))


@flow("ord_chief_target")
async def _flow_chief(update, context, value, data):
    uid = update.effective_user.id
    target_id, name = value
    ok, msg = await ordre.appoint_chief(uid, target_id, data["faction"], data["station"], is_admin=await _is_admin(uid))
    await _reply(update, ("✅ " if ok else "❌ ") + f"{_e(name)} : {msg}", InlineKeyboardMarkup([_back("team")]))


# ─────────────────────────────────────────────────────────────────────────────
#  Commandes (ouvrent les écrans à boutons)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_ordre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update, update.effective_user.id)


@require_registered
async def cmd_papiers(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_papers(update, update.effective_user.id)


@require_registered
async def cmd_signaler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask(update, context, "ord_report_target", "📢 Qui veux-tu signaler à la police ? (@pseudo ou ID)",
              kind="user", back=CB + "home")


@require_registered
async def cmd_crimes_joueurs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_player_crimes(update, update.effective_user.id)


@require_registered
async def cmd_antihack(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_defense(update, update.effective_user.id)


@require_registered
async def cmd_ordre_audit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/ordre_audit [@joueur] — journal anti-triche (Admin N2+)."""
    uid = update.effective_user.id
    if not await _is_admin(uid):
        await update.message.reply_text("❌ Réservé aux admins N2+.")
        return
    target = 0
    if context.args:
        from utils.input_flow import resolve_user
        found = await resolve_user(context.args[0])
        target = found[0] if found else 0
    rows = await ordre.audit(25, target)
    lines = ["🧾 <b>Journal Ordre public</b>"] + [
        f"{_rdate(r['ts'])} {r['actor_id']} → {_e(r['action'])} → {r['target_id']} {_e(r['details'])}"
        for r in rows]
    await update.message.reply_text("\n".join(lines)[:3900], parse_mode="HTML")


# ─────────────────────────────────────────────────────────────────────────────
#  Relais des discussions (interrogatoire / entretien) — groupe -2, avant la saisie guidée
# ─────────────────────────────────────────────────────────────────────────────
async def relay_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    user = update.effective_user
    if not msg or not msg.text or not user or msg.text.startswith("/"):
        return
    r = await ordre.relay_target(user.id)
    if not r:
        from handlers.team import team_relay          # 💬 sinon : chat d'équipe (faction / entreprise / gouvernement)
        await team_relay(update, context)
        return
    chat = r["chat"]
    rows = []
    if r["to"] == chat["a_id"]:       # destinataire = l'agent / le recruteur : lui donner le bouton de décision
        rows = [[_btn("🧑‍⚖️ Décision", CB + f"in:{chat['b_id']}")]] if chat["kind"] == "interro" \
            else [[_btn("📨 Candidature", CB + f"app:{chat['ref']}")]]
    else:
        rows = [[_btn("⏹️ Quitter la discussion", CB + "endchat")]] if chat["kind"] == "entretien" else []
    try:
        await context.bot.send_message(
            r["to"], f"💬 <b>{r['label']}</b> : {html.escape(msg.text[:800])}", parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(rows) if rows else None)
    except Exception:
        await msg.reply_text("⚠️ Message non transmis (l'autre personne est injoignable).")
    raise ApplicationHandlerStop


# ─────────────────────────────────────────────────────────────────────────────
#  Callbacks
# ─────────────────────────────────────────────────────────────────────────────
async def ord_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    parts = (q.data or "").split(":")
    action = parts[1] if len(parts) > 1 else "home"
    a2 = parts[2] if len(parts) > 2 else ""
    a3 = parts[3] if len(parts) > 3 else ""
    try:
        u = await get_user(uid)
        if not u.get("registered") or u.get("banned"):
            await q.answer("Termine d'abord /start.", show_alert=True)
            return
        await q.answer()

        if action == "home":
            await show_home(update, uid)
        elif action == "hide":
            ok, msg = await ordre.hide(uid)
            await show_home(update, uid, msg if ok else f"❌ {msg}")
        elif action == "stations":
            await show_stations(update, uid)
        elif action == "apply":
            await show_apply(update, uid)
        elif action == "apf":
            if a2 in ordre.RECRUIT_FACTIONS:
                await show_apply_station(update, uid, a2)
            else:
                await show_apply(update, uid)
        elif action == "ap":
            if a2 in ordre.RECRUIT_FACTIONS and a3 in ordre.station_ids(a2):
                await do_apply(update, uid, a2, a3)
            else:
                await show_apply(update, uid)
        elif action == "papers":
            await show_papers(update, uid)
        elif action == "doc":
            await show_doc(update, uid, a2)
        elif action == "act":
            await show_activity(update, uid)
        elif action == "job":
            await show_job(update, uid)
        elif action == "duty":
            from handlers.sante import _housing_error
            err = await _housing_error(uid) if a2 == "on" else None
            if err:
                await show_job(update, uid, f"❌ {err}")
            else:
                from handlers.work import toggle_duty      # service commun : le temps de jeu devient de l'activité
                await show_job(update, uid, await toggle_duty(uid, a2 == "on"))
        # ── joueurs & pouvoirs ──
        elif action == "pl":
            await show_players(update, uid, int(a2) if a2.isdigit() else 0)
        elif action == "pf":
            await ask(q, context, "ord_search", "🔎 Quel joueur ? (@pseudo ou ID)", kind="user", back=CB + "pl:0")
        elif action == "p":
            await show_player(update, uid, int(a2))
        elif action == "a":
            target = int(a3)
            fn = {"stun": ordre.stun, "cuff": ordre.cuff, "unc": ordre.uncuff,
                  "esc": ordre.escort_to_interrogation, "cap": ordre.army_capture}.get(a2)
            if not fn:
                return
            ok, msg = await fn(uid, target)
            if ok and a2 == "esc":
                await show_interrogation(update, uid, target, "✅ " + msg)
            else:
                await show_player(update, uid, target, ("✅ " if ok else "❌ ") + msg)
        elif action == "in":
            await show_interrogation(update, uid, int(a2))
        elif action == "jail":
            ok, msg = await ordre.finish_interrogation(uid, int(a2), int(a3))
            if ok:
                await show_players(update, uid, 0)
                await q.message.reply_text("✅ " + msg)
            else:
                await show_player(update, uid, int(a2), "❌ " + msg)
        elif action == "free":
            ok, msg = await ordre.finish_interrogation(uid, int(a2), 0)
            if ok:
                await show_players(update, uid, 0)
                await q.message.reply_text("✅ " + msg)
            else:
                await show_player(update, uid, int(a2), "❌ " + msg)
        elif action == "ad":
            ok, msg = await ordre.army_decide(uid, int(a3), a2)
            await show_players(update, uid, 0)
            await q.message.reply_text(("✅ " if ok else "❌ ") + msg)
        # ── enquêtes ──
        elif action == "cases":
            await show_cases(update, uid)
        elif action == "case":
            await show_case(update, uid, int(a2))
        elif action == "mg":
            await start_minigame(update, context, uid, int(a2))
        elif action == "mgp":
            await press_symbol(update, uid, int(a2))
        elif action == "arrest":
            ok, msg = await ordre.arrest_case(uid, int(a2))
            await show_cases(update, uid, ("✅ " if ok else "❌ ") + msg)
        # ── signalements ──
        elif action == "report":
            await ask(q, context, "ord_report_target", "📢 Qui veux-tu signaler à la police ? (@pseudo ou ID)",
                      kind="user", back=CB + "home")
        elif action == "reps":
            await show_reports(update, uid)
        elif action == "repd":
            ok, msg = await ordre.handle_report(uid, int(a2), a3 == "1")
            await show_reports(update, uid, ("✅ " if ok else "❌ ") + msg)
        # ── recrutement ──
        elif action == "apps":
            await show_apps(update, uid)
        elif action == "app":
            await show_app(update, uid, int(a2))
        elif action == "int":
            ok, msg = await ordre.start_interview(uid, int(a2))
            await show_app(update, uid, int(a2), ("✅ " if ok else "❌ ") + msg)
        elif action in ("acc", "ref"):
            ok, msg = await ordre.decide_application(uid, int(a2), action == "acc")
            if ok:
                await show_apps(update, uid, "✅ " + msg)
            else:
                await show_app(update, uid, int(a2), "❌ " + msg)
        elif action == "endchat":
            c = await ordre.active_chat(uid)
            if c and c["kind"] == "entretien":
                await ordre.end_chat(c["id"], "manual")
                other = c["b_id"] if c["a_id"] == uid else c["a_id"]
                from utils.notify import notify
                await notify(other, "🗣️ Entretien terminé", "La discussion est terminée.", "info")
            await show_home(update, uid, "🗣️ Discussion terminée.")
        # ── équipe ──
        elif action == "team":
            await show_team(update, uid)
        elif action == "m":
            await show_member(update, uid, int(a2))
        elif action == "mp":
            t = await ordre.get_staff(int(a2))
            if not t:
                await show_team(update, uid)
                return
            rows = [[_btn(f"{p['emoji']} {p['name']} ({p['salary_h']:,}/h)", CB + f"mpo:{a2}:{k}")]
                    for k, p in ORDRE_POSTS[t["faction"]].items() if k in ordre.assignable_posts(t["faction"])]
            rows.append([_btn("⬅️ Retour", CB + f"m:{a2}")])
            await _send(update, "🎖️ Choisis le nouveau poste :", InlineKeyboardMarkup(rows))
        elif action == "mpo":
            ok, msg = await ordre.assign_post(uid, int(a2), a3, is_admin=await _is_admin(uid))
            await show_member(update, uid, int(a2), ("✅ " if ok else "❌ ") + msg)
        elif action == "ms":
            t = await ordre.get_staff(int(a2))
            if not t:
                await show_team(update, uid)
                return
            rows = [[_btn(s["name"], CB + f"mst:{a2}:{sid}")] for sid, s in ORDRE_STATIONS[t["faction"]].items()]
            rows.append([_btn("⬅️ Retour", CB + f"m:{a2}")])
            await _send(update, "🏢 Choisis le nouveau lieu d'affectation :", InlineKeyboardMarkup(rows))
        elif action == "mst":
            t = await ordre.get_staff(int(a2))
            ok, msg = (await ordre.assign_post(uid, int(a2), t["post"], a3, is_admin=await _is_admin(uid))) if t \
                else (False, "Membre introuvable.")
            await show_member(update, uid, int(a2), ("✅ " if ok else "❌ ") + msg)
        elif action == "mf":
            await _send(update, "🚪 Confirmer le renvoi ?", InlineKeyboardMarkup(
                [[_btn("✅ Oui, renvoyer", CB + f"mfy:{a2}"), _btn("↩️ Non", CB + f"m:{a2}")]]))
        elif action == "mfy":
            ok, msg = await ordre.dismiss(uid, int(a2), is_admin=await _is_admin(uid))
            await show_team(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "chief":
            me = await ordre.get_staff(uid)
            if not me or not me["central_head"]:
                await show_team(update, uid, "❌ Seul le DG nomme les chefs de poste.")
                return
            rows = [[_btn(s["name"], CB + f"chs:{sid}")] for sid, s in ORDRE_STATIONS[me["faction"]].items()
                    if s["kind"] != "central"]
            rows.append(_back("team"))
            await _send(update, "🛡️ Quel poste doit recevoir un nouveau chef ?", InlineKeyboardMarkup(rows))
        elif action == "chs":
            me = await ordre.get_staff(uid)
            if me and me["central_head"] and a2 in ORDRE_STATIONS[me["faction"]]:
                await ask(q, context, "ord_chief_target", "🛡️ Qui nommer chef de ce poste ? (@pseudo ou ID)",
                          kind="user", data={"faction": me["faction"], "station": a2}, back=CB + "chief")
        # ── direction (Game Leader+ ou ministre de la faction) ──
        elif action == "dg":
            directable = await _directable(uid)
            if not directable:
                await show_home(update, uid, "❌ Réservé au Game Leader et au ministre concerné.")
                return
            rows = []
            for f in directable:
                if f == "justice":      # plusieurs juges possibles
                    rows.append([_btn("⚖️ Nommer un juge", CB + "dgn:justice")])
                    for j in [x for x in await ordre.list_staff("justice") if x["post"] == "juge"][:8]:
                        rows.append([_btn(f"🚫 Révoquer {str(j.get('full_name') or j['user_id'])[:20]}", CB + f"jrv:{j['user_id']}")])
                    continue
                head = await ordre.get_head(f, "central")
                rows.append([_btn(f"👑 DG {GOV_FACTIONS[f]['name']}" + (f" (actuel : {head.get('full_name') or head['user_id']})"
                                                                     if head else " (vacant)"), CB + f"dgn:{f}")])
                if head:
                    rows.append([_btn(f"🚫 Révoquer le DG {GOV_FACTIONS[f]['name']}", CB + f"dgr:{f}")])
            rows.append(_back())
            await _send(update, "👑 <b>Nommer la direction</b>\n\nLe DG nomme ensuite les chefs de poste et recrute ; "
                                "les juges recrutent les avocats.", InlineKeyboardMarkup(rows))
        elif action == "jrv":
            if await _can_direct(uid, "justice"):
                ok, msg = await ordre.revoke_judge(uid, int(a2), "révocation par la direction du jeu")
                await show_home(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "dgn":
            if a2 in ORDRE_FACTIONS and await _can_direct(uid, a2):
                await ask(q, context, "ord_dg_target", (f"⚖️ Qui nommer juge ? (@pseudo ou ID)" if a2 == "justice" else f"👑 Qui nommer DG de {GOV_FACTIONS[a2]['name']} ? (@pseudo ou ID)"),
                          kind="user", data={"faction": a2}, back=CB + "dg")
        elif action == "dgr":
            if a2 in ("police", "armee") and await _can_direct(uid, a2):
                ok, msg = await ordre.revoke_dg(uid, a2, "révocation par le ministre ou la direction du jeu")
                await show_home(update, uid, ("✅ " if ok else "❌ ") + msg)
        # ── crimes sur joueurs & défense ──
        elif action == "pc":
            await show_player_crimes(update, uid)
        elif action == "pcx":
            err = await _crime_gate(uid)
            if err or a2 not in ORDRE_PLAYER_CRIMES:
                await show_player_crimes(update, uid, err or "❌ Crime inconnu.")
                return
            await ask(q, context, "ord_pc_target", f"🎯 {ORDRE_PLAYER_CRIMES[a2]['name']} : quelle cible ? (@pseudo ou ID)",
                      kind="user", data={"key": a2}, back=CB + "pc")
        elif action == "ah":
            await show_defense(update, uid)
        elif action == "ahb":
            ok, msg = await ordre.buy_defense(uid, a2)
            await show_defense(update, uid, ("✅ " if ok else "❌ ") + msg)
        else:
            await show_home(update, uid)
    except ApplicationHandlerStop:
        raise
    except Exception:
        logger.exception("ord_callback : %s", q.data)
        try:
            await q.message.reply_text("⚠️ Une erreur est survenue, réessaie depuis le menu.")
        except Exception:
            swallowed('handlers/ordre.py')
