# handlers/travel.py
from utils.gamerules import faucet
import random
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import db_connection, DB_PATH, get_user, update_balance, update_field, increment_field
from utils.decorators import require_registered, require_free
from utils.helpers import fmt, fmt_time, now, escape_html
from utils.aesthetics import card
from utils.vip import travel_time_multiplier, add_xp
from config import DESTINATIONS
from handlers.missions import update_mission_progress
from handlers.vehicles import get_active_vehicle
from utils.helpers import safe_edit

TRAVEL_COOLDOWN = 7200


async def get_event_effect():
    try:
        from handlers.events import get_event_effect as _get_event_effect
        return await _get_event_effect()
    except ImportError:
        return {}


# ═══════════════════════════════════════════════════════════════════
#              ✈️ MENU PRINCIPAL VOYAGES
# ═══════════════════════════════════════════════════════════════════
async def show_travel_menu(query, user_id: int):
    u = await get_user(user_id)
    travel_until = u.get("travel_until", 0)
    travel_count = u.get("travel_count", 0)

    body = [
        f"💰 Solde : <b>{fmt(u['balance'])}</b>",
        f"✈️ Voyages effectués : <b>{travel_count}</b>",
    ]

    # ⭐ Indiquer si le boost vitesse est actif
    if travel_time_multiplier(u) < 1.0:
        body.append("⚡ <b>Boost Vitesse -50% ACTIF !</b>")

    if travel_until > now():
        remaining = travel_until - now()
        body += [
            "",
            f"⏳ <b>Tu es en voyage / repos</b>",
            f"Temps restant : <b>{fmt_time(remaining)}</b>",
        ]
        can_travel = False
    else:
        body += ["", "✅ <b>Prêt(e) à voyager</b>"]
        can_travel = True

    keyboard = []
    if can_travel:
        keyboard.append([InlineKeyboardButton("✈️ Voyager", callback_data="travel_choose")])
    keyboard.append([InlineKeyboardButton("🗺️ Voir les destinations", callback_data="travel_list")])
    keyboard.append([InlineKeyboardButton("📖 Mon carnet de voyage", callback_data="travel_log")])
    keyboard.append([InlineKeyboardButton("⬅️ Loisirs", callback_data="fun_menu")])

    await safe_edit(
        query,
        "✈️ <b>AGENCE DE VOYAGE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


# ═══════════════════════════════════════════════════════════════════
#              🗺️ LISTE DES DESTINATIONS
# ═══════════════════════════════════════════════════════════════════
async def show_destinations_list(query, user_id: int):
    async with db_connection() as db:
        async with db.execute(
            "SELECT DISTINCT destination FROM travel_log WHERE user_id=?", (user_id,)
        ) as cur:
            visited = {row[0] for row in await cur.fetchall()}

    body = ["<i>Destinations disponibles :</i>", ""]
    for dest, data in DESTINATIONS.items():
        status = "✅" if dest in visited else "🔒"
        body.append(
            f"{status} {data['emoji']} <b>{dest}</b>\n"
            f"   💰 {fmt(data['cost'])} | 😊 +{data['happiness']}% | ✨ +{data['xp']} XP"
        )

    await safe_edit(
        query,
        card("🗺️ DESTINATIONS", body, icon="🗺️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✈️ Choisir une destination", callback_data="travel_choose")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="travel_menu")],
        ])
    )


# ═══════════════════════════════════════════════════════════════════
#              ✈️ CHOISIR UNE DESTINATION
# ═══════════════════════════════════════════════════════════════════
async def show_choose_destination(query, user_id: int):
    u = await get_user(user_id)

    if u.get("travel_until", 0) > now():
        rem = u["travel_until"] - now()
        await safe_edit(
            query,
            f"⏳ Tu es déjà en voyage / repos pour <b>{fmt_time(rem)}</b>.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="travel_menu")]])
        )
        return

    keyboard = []
    for i, (dest, data) in enumerate(DESTINATIONS.items()):
        can_afford = "✅" if u["balance"] >= data["cost"] else "❌"
        keyboard.append([
            InlineKeyboardButton(
                f"{can_afford} {data['emoji']} {dest} — {fmt(data['cost'])}",
                callback_data=f"travel_go_{i}"
            )
        ])

    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="travel_menu")])

    await safe_edit(
        query,
        "✈️ <b>CHOISIR UNE DESTINATION</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💰 Ton solde : <b>{fmt(u['balance'])}</b>\n\n"
        "<i>Tape sur une destination pour partir.</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_travel(query, user_id: int, dest_index: int):
    dest_names = list(DESTINATIONS.keys())
    if dest_index < 0 or dest_index >= len(dest_names):
        await safe_edit(query, "❌ Destination invalide.")
        return

    dest_name = dest_names[dest_index]
    data = DESTINATIONS[dest_name]
    u = await get_user(user_id)

    if u.get("travel_until", 0) > now():
        rem = u["travel_until"] - now()
        await safe_edit(
            query,
            f"✈️ Tu es déjà en voyage !\n⏳ Reviens dans <b>{fmt_time(rem)}</b>.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="travel_menu")]])
        )
        return

    event_effect = await get_event_effect()
    cost_mult = event_effect.get("travel_cost_mult", 1.0)
    happiness_mult = event_effect.get("travel_happiness_mult", 1.0)
    actual_cost = int(data["cost"] * cost_mult)
    actual_happiness = int(data["happiness"] * happiness_mult)

    if u["balance"] < actual_cost:
        await safe_edit(
            query,
            f"❌ Fonds insuffisants.\n✈️ Coût : <b>{fmt(actual_cost)}</b>\n💵 Ton solde : <b>{fmt(u['balance'])}</b>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="travel_choose")]])
        )
        return

    # Véhicule actif pour la vitesse
    active_vehicle = await get_active_vehicle(user_id)
    vehicle_speed = active_vehicle.get("speed", 0) if active_vehicle else 0

    travel_duration = random.randint(3600, 10800)
    speed_reduction = 1 - (vehicle_speed / 200)
    speed_reduction = max(0.3, min(1.0, speed_reduction))
    # ⭐ Boost vitesse VIP
    vip_speed = travel_time_multiplier(u)
    travel_duration = int(travel_duration * speed_reduction * vip_speed)
    xp_bonus = int(data["xp"] * (1 + vehicle_speed / 200))

    speed_msg = ""
    if active_vehicle and vehicle_speed > 0:
        reduction_pct = int((1 - speed_reduction) * 100)
        speed_msg = f"🏎️ Vitesse véhicule → <b>-{reduction_pct}%</b> de temps"
    elif active_vehicle:
        speed_msg = "🏎️ Véhicule lent → temps normal"
    else:
        speed_msg = "🚫 Aucun véhicule actif → temps normal"

    if vip_speed < 1.0:
        speed_msg += f"\n⚡ Boost Vitesse VIP → <b>-50%</b> supplémentaires"

    total_blocked = travel_duration + TRAVEL_COOLDOWN
    # Un seul `now()` pour le départ, la fin de trajet et la fin de repos : la phase de voyage
    # enregistrée dans travel_log ci-dessous reste exactement cohérente avec `travel_until`,
    # sans dérive possible entre deux appels séparés.
    departed_at = now()
    arrival_at = departed_at + travel_duration
    travel_until = departed_at + total_blocked

    await update_balance(user_id, -actual_cost, sink="transports")
    await update_field(user_id, "travel_until", travel_until)
    await update_field(user_id, "happiness", min(100, u["happiness"] + actual_happiness))
    await update_field(user_id, "stress", max(0, u["stress"] - 20))
    # ⭐ Utilisation de add_xp (boost XP appliqué automatiquement)
    await add_xp(user_id, xp_bonus)
    await increment_field(user_id, "travel_count")
    await update_mission_progress(user_id, "travel", 1)

    travel_count = u.get("travel_count", 0) + 1
    prestige_msg = ""
    if travel_count == 5:
        await increment_field(user_id, "prestige", 25)
        prestige_msg = "\n🏆 +25 Prestige (5 voyages) !"
    elif travel_count == 10:
        await increment_field(user_id, "prestige", 50)
        prestige_msg = "\n🏆 +50 Prestige (10 voyages) !"
    elif travel_count == 25:
        await increment_field(user_id, "prestige", 150)
        prestige_msg = "\n🏆 +150 Prestige (25 voyages) !"
    elif travel_count == 50:
        await increment_field(user_id, "prestige", 500)
        prestige_msg = "\n🏆 +500 Prestige (50 voyages) !"

    async with db_connection() as db:
        await db.execute(
            "INSERT INTO travel_log (user_id, destination, cost, timestamp, arrival_at, travel_until) "
            "VALUES (?,?,?,?,?,?)",
            (user_id, dest_name, actual_cost, departed_at, arrival_at, travel_until)
        )
        await db.commit()

    # Événement
    events = [
        ("✨ Tu rencontres une célébrité et obtiens un contact VIP !", 50_000, 10),
        ("🍽️ Restaurant exceptionnel — expérience inoubliable !", 0, 5),
        (f"🎲 Casino de {dest_name} : tu gagnes !", random.randint(10_000, 50_000), 5),
        ("😊 Voyage parfait, retour ressourcé !", 0, 10),
        ("📸 Tes photos deviennent virales !", 0, 15),
        ("💼 Tu rencontres un business partner potentiel !", 0, 20),
        ("🌧️ Mauvaise météo… voyage gâché.", -10_000, -10),
        ("🦠 Épidémie locale ! Tu tombes malade.", -20_000, -20),
    ]
    event, bonus, karma = random.choices(
        events, weights=[5, 20, 15, 40, 10, 10, 5, 2]
    )[0]

    bonus_text = ""
    if bonus > 0:
        bonus = await faucet("travel", bonus)         # ⚙️ réglage du staff
    if bonus > 0:
        await update_balance(user_id, bonus)
        bonus_text = f"\n💰 Bonus : <b>+{fmt(bonus)}</b>"
    elif bonus < 0:
        if u["balance"] + bonus < 0:
            bonus = -u["balance"]
        if bonus != 0:
            await update_balance(user_id, bonus)
        bonus_text = f"\n💸 Perte : <b>{fmt(abs(bonus))}</b>"

    karma_text = ""
    if karma != 0:
        await increment_field(user_id, "karma", karma)
        karma_text = f"\n🌟 Karma : <b>{karma:+d}</b>"

    body = [
        f"{data['emoji']} Destination : <b>{dest_name}</b>",
        f"💰 Coût : <b>{fmt(actual_cost)}</b>",
        f"⏳ Voyage : <b>{fmt_time(travel_duration)}</b>",
        f"🛌 Repos obligatoire : <b>{fmt_time(TRAVEL_COOLDOWN)}</b>",
        f"{speed_msg}",
        "",
        f"<b>Événement :</b> <i>{event}</i>{bonus_text}{karma_text}",
        "",
        f"😊 +{actual_happiness}% bonheur | 😰 -20% stress",
        f"✨ +{xp_bonus} XP{prestige_msg}",
    ]

    await safe_edit(
        query,
        card("✈️ VOYAGE EN COURS", body, icon="✈️", style="stars"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✈️ Mon carnet", callback_data="travel_log")],
            [InlineKeyboardButton("⬅️ Menu voyage", callback_data="travel_menu")],
        ])
    )


# ═══════════════════════════════════════════════════════════════════
#              📖 CARNET DE VOYAGE
# ═══════════════════════════════════════════════════════════════════
async def show_travel_log(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT destination, COUNT(*) as visits FROM travel_log WHERE user_id=? GROUP BY destination ORDER BY visits DESC",
            (user_id,)
        ) as cur:
            trips = await cur.fetchall()

    if not trips:
        await safe_edit(
            query,
            "✈️ <b>Carnet vide</b>\n\nTu n'as jamais voyagé.\nTape sur <b>✈️ Voyager</b> pour commencer.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="travel_menu")]])
        )
        return

    body = []
    total_trips = 0
    for t in trips:
        dest_data = DESTINATIONS.get(t["destination"], {})
        emoji = dest_data.get("emoji", "🌍")
        body.append(f"{emoji} <b>{t['destination']}</b> — {t['visits']}× visité")
        total_trips += t["visits"]

    visited_names = [t["destination"] for t in trips]
    not_visited = [d for d in DESTINATIONS if d not in visited_names]
    if not_visited:
        body.append("")
        body.append(f"🔒 <b>Non visités :</b> {', '.join(not_visited)}")

    body.append("")
    body.append(f"✈️ Total voyages : <b>{total_trips}</b>")

    if total_trips >= len(DESTINATIONS):
        body.append("")
        body.append("🏆 <b>Globe-trotter accompli !</b>")

    await safe_edit(
        query,
        card("📖 MON CARNET DE VOYAGE", body, icon="📖", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="travel_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              🎯 CALLBACK ROUTEUR VOYAGES
# ═══════════════════════════════════════════════════════════════════
async def travel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "travel_menu":
        await show_travel_menu(query, user_id)
        return
    if data == "travel_list":
        await show_destinations_list(query, user_id)
        return
    if data == "travel_choose":
        await show_choose_destination(query, user_id)
        return
    if data == "travel_log":
        await show_travel_log(query, user_id)
        return
    if data.startswith("travel_go_"):
        try:
            idx = int(data.replace("travel_go_", ""))
        except ValueError:
            return
        await do_travel(query, user_id, idx)
        return


# ═══════════════════════════════════════════════════════════════════
#              COMMANDES TEXTE EXISTANTES (compatibilité)
# ═══════════════════════════════════════════════════════════════════
@require_registered
@require_free
async def cmd_destinations(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        async with db.execute(
            "SELECT DISTINCT destination FROM travel_log WHERE user_id=?", (user.id,)
        ) as cur:
            visited = {row[0] for row in await cur.fetchall()}

    u = await get_user(user.id)

    text = "🌍 <b>Destinations disponibles</b>\n\n"

    # ⭐ Indiquer si le boost vitesse est actif
    if travel_time_multiplier(u) < 1.0:
        text += "⚡ <b>Boost Vitesse -50% ACTIF !</b>\n\n"

    for dest, data in DESTINATIONS.items():
        status = "✅" if dest in visited else "🔒"
        text += (
            f"{escape_html(status)} {escape_html(data['emoji'])} <b>{escape_html(dest)}</b>\n"
            f"  💰 Coût : {escape_html(fmt(data['cost']))}\n"
            f"  😊 Bonheur : +{escape_html(data['happiness'])}%\n"
            f"  ✨ XP : +{escape_html(data['xp'])}\n\n"
        )
    text += "<i>🏎️ La vitesse de ton véhicule réduit le temps de trajet !</i>"
    text += "\n<i>Ou utilise le menu → 🎲 Loisirs → ✈️ Voyages</i>"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
async def cmd_voyager(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not context.args:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 🎲 Loisirs → Voyages."
        )
        return

    dest_name = " ".join(context.args).title()
    matched = None
    for d in DESTINATIONS:
        if d.lower() == dest_name.lower():
            matched = d
            break
    if not matched:
        await update.message.reply_text(f"❌ Destination inconnue. Utilise le menu pour voir la liste.")
        return

    data = DESTINATIONS[matched]

    if u.get("travel_until", 0) > now():
        remaining = u["travel_until"] - now()
        await update.message.reply_text(
            f"✈️ Tu es déjà en voyage ou en période de repos !\n"
            f"⏳ Reviens dans {fmt_time(remaining)}."
        )
        return

    if u["balance"] < data["cost"]:
        await update.message.reply_text(
            f"❌ Fonds insuffisants !\n"
            f"✈️ Coût du voyage : {fmt(data['cost'])}\n"
            f"💵 Ton solde : {fmt(u['balance'])}"
        )
        return

    event_effect = await get_event_effect()
    cost_mult = event_effect.get("travel_cost_mult", 1.0)
    happiness_mult = event_effect.get("travel_happiness_mult", 1.0)
    actual_cost = int(data["cost"] * cost_mult)
    actual_happiness = int(data["happiness"] * happiness_mult)

    if u["balance"] < actual_cost:
        await update.message.reply_text(
            f"❌ Fonds insuffisants !\n"
            f"✈️ Coût du voyage (événement) : {fmt(actual_cost)}"
        )
        return

    active_vehicle = await get_active_vehicle(user.id)
    vehicle_speed = active_vehicle.get("speed", 0) if active_vehicle else 0

    travel_duration = random.randint(3600, 10800)
    speed_reduction = 1 - (vehicle_speed / 200)
    speed_reduction = max(0.3, min(1.0, speed_reduction))
    # ⭐ Boost vitesse VIP
    vip_speed = travel_time_multiplier(u)
    travel_duration = int(travel_duration * speed_reduction * vip_speed)
    xp_bonus = int(data["xp"] * (1 + vehicle_speed / 200))

    total_blocked = travel_duration + TRAVEL_COOLDOWN
    # Un seul `now()` pour le départ, la fin de trajet et la fin de repos (voir cmd_travel).
    departed_at = now()
    arrival_at = departed_at + travel_duration
    travel_until = departed_at + total_blocked

    await update_balance(user.id, -actual_cost, sink="transports")
    await update_field(user.id, "travel_until", travel_until)
    await update_field(user.id, "happiness", min(100, u["happiness"] + actual_happiness))
    await update_field(user.id, "stress", max(0, u["stress"] - 20))
    # ⭐ Utilisation de add_xp (boost XP appliqué automatiquement)
    await add_xp(user.id, xp_bonus)
    await increment_field(user.id, "travel_count")
    await update_mission_progress(user.id, "travel", 1)

    async with db_connection() as db:
        await db.execute(
            "INSERT INTO travel_log (user_id, destination, cost, timestamp, arrival_at, travel_until) "
            "VALUES (?,?,?,?,?,?)",
            (user.id, matched, actual_cost, departed_at, arrival_at, travel_until)
        )
        await db.commit()

    await update.message.reply_text(
        f"✈️ <b>Voyage à {escape_html(matched)} !</b>\n\n"
        f"💰 Coût : {escape_html(fmt(actual_cost))}\n"
        f"⏳ Voyage + repos : {escape_html(fmt_time(total_blocked))}\n"
        f"😊 +{escape_html(actual_happiness)}% bonheur | 😰 -20% stress\n"
        f"✨ +{escape_html(xp_bonus)} XP",
        parse_mode="HTML"
    )


@require_registered
async def cmd_monstimbre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT destination, COUNT(*) as visits FROM travel_log WHERE user_id=? GROUP BY destination ORDER BY visits DESC",
            (user.id,)
        ) as cur:
            trips = await cur.fetchall()

    if not trips:
        await update.message.reply_text(
            "✈️ Tu n'as jamais voyagé !\n/destinations pour voir les options."
        )
        return

    text = f"🗺️ <b>Collection de voyages — {escape_html(user.full_name)}</b>\n\n"
    total_trips = 0
    for t in trips:
        dest_data = DESTINATIONS.get(t["destination"], {})
        emoji = dest_data.get("emoji", "🌍")
        text += f"{escape_html(emoji)} <b>{escape_html(t['destination'])}</b> — {escape_html(t['visits'])}x visité\n"
        total_trips += t["visits"]

    not_visited = [d for d in DESTINATIONS if d not in [t["destination"] for t in trips]]
    if not_visited:
        text += f"\n🔒 <b>Non visités :</b> {escape_html(', '.join(not_visited))}"
    text += f"\n\n✈️ Total voyages : <b>{escape_html(total_trips)}</b>"

    await update.message.reply_text(text, parse_mode="HTML")


async def process_travel_maintenance():
    async with db_connection() as db:
        await db.execute("UPDATE users SET travel_until=0 WHERE travel_until > 0 AND travel_until < ?", (now(),))
        await db.commit()