"""Entreprises — accords entre entreprises : fusions et contrats (avec consentement).

Les contrats délèguent à `gameplay/companies.py`, le même service pur que
`webapp/routers/companies_router.py` — aucune règle n'est recalculée ici. Les fusions
aussi (`propose_fusion`/`respond_fusion`)."""
from utils.company_ops import CONTRACT_TYPES
from telegram.ext import ContextTypes
from database import get_company_by_name, get_user_company
from telegram import Update
import gameplay.companies as companies_service
from utils.helpers import fmt
from utils.decorators import require_registered, require_free


@require_registered
@require_free
async def cmd_proposer_fusion(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Seul le PDG peut proposer une fusion.")
        return
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    target_name = " ".join(context.args)
    target = await get_company_by_name(target_name)
    if not target or target["company_id"] == company["company_id"]:
        await update.message.reply_text("❌ Entreprise cible introuvable.")
        return
    if target["dissolved"]:
        await update.message.reply_text("❌ Cette entreprise est dissoute.")
        return

    result = await companies_service.propose_fusion(company["company_id"], company["name"], target["company_id"])
    if not result["ok"]:
        if result["reason"] == "already_pending":
            await update.message.reply_text("❌ Une demande de fusion est déjà en attente entre ces deux entreprises.")
        elif result["reason"] == "target_dissolved":
            await update.message.reply_text("❌ Cette entreprise est dissoute.")
        else:
            await update.message.reply_text("❌ Entreprise cible introuvable.")
        return
    await update.message.reply_text(f"📨 Demande de fusion envoyée à **{target['name']}**.")


@require_registered
@require_free
async def cmd_repondre_fusion(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if len(context.args) != 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    try:
        target_id = int(context.args[0])
        decision = context.args[1].lower()
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return
    # Vérifier que l'utilisateur est PDG de cette entreprise
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id or company["company_id"] != target_id:
        await update.message.reply_text("❌ Vous n'êtes pas le PDG de cette entreprise.")
        return

    result = await companies_service.respond_fusion(user.id, target_id, decision == "accepter")
    if not result["ok"]:
        reason = result["reason"]
        if reason == "source_dissolved":
            await update.message.reply_text("❌ L'entreprise émettrice a été dissoute entre-temps.")
        elif reason == "insufficient_treasury":
            await update.message.reply_text("❌ L'entreprise émettrice n'a pas assez de trésorerie pour absorber votre entreprise.")
        elif reason == "no_request":
            await update.message.reply_text("❌ Aucune demande de fusion en attente pour cette entreprise.")
        else:
            await update.message.reply_text("❌ Vous n'êtes pas le PDG de cette entreprise.")
        return
    if not result["accepted"]:
        await update.message.reply_text("❌ Fusion refusée.")
        return
    await update.message.reply_text(f"🤝 **Fusion réussie !** {result['from_company_name']} a absorbé {result['target_name']}.")


@require_registered
@require_free
async def cmd_proposer_contrat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Seul le PDG peut proposer un contrat.")
        return
    if len(context.args) < 4:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises."
            f"Types : {', '.join(CONTRACT_TYPES)}\n"
        )
        return
    # Extraction : le dernier argument est le type, avant la durée, avant le montant, le reste est le nom
    # On va récupérer les arguments en partant de la fin
    try:
        contract_type = context.args[-1].lower()
        duration = int(context.args[-2])
        amount = int(context.args[-3])
        target_name = " ".join(context.args[:-3])
        if duration <= 0 or amount <= 0 or contract_type not in CONTRACT_TYPES:
            raise ValueError
    except ValueError:
        await update.message.reply_text(f"❌ Arguments invalides. Types : {', '.join(CONTRACT_TYPES)}")
        return

    target = await get_company_by_name(target_name)
    if not target or target["company_id"] == company["company_id"]:
        await update.message.reply_text("❌ Entreprise cible introuvable.")
        return
    if target["dissolved"]:
        await update.message.reply_text("❌ Cette entreprise est dissoute.")
        return

    result = await companies_service.propose_contract(
        company["company_id"], company["name"], target["company_id"], amount, duration, contract_type
    )
    if not result["ok"]:
        if result["reason"] == "already_pending":
            await update.message.reply_text("❌ Un contrat est déjà en attente entre ces deux entreprises.")
        elif result["reason"] == "target_dissolved":
            await update.message.reply_text("❌ Cette entreprise est dissoute.")
        else:
            await update.message.reply_text("❌ Entreprise cible introuvable.")
        return

    await update.message.reply_text(
        f"📄 Contrat proposé à **{target['name']}**\n"
        f"💰 Montant : {fmt(amount)}\n"
        f"⏳ Durée : {duration} jours\n"
        f"📌 Type : {contract_type}\n"
        f"_En attente de réponse._"
    )


@require_registered
@require_free
async def cmd_repondre_contrat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if len(context.args) != 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    try:
        contract_id = int(context.args[0])
        decision = context.args[1].lower()
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return

    accept = decision == "accepter"
    result = await companies_service.respond_contract(user.id, contract_id, accept)
    if not result["ok"]:
        reason = result["reason"]
        if reason == "not_target_owner":
            await update.message.reply_text("❌ Vous n'êtes pas le PDG de l'entreprise cible.")
        elif reason == "source_dissolved":
            await update.message.reply_text("❌ L'entreprise émettrice a été dissoute.")
        elif reason == "insufficient_treasury":
            await update.message.reply_text("❌ L'entreprise émettrice n'a pas assez de trésorerie.")
        else:
            await update.message.reply_text("❌ Contrat introuvable ou déjà traité.")
        return
    if not result["accepted"]:
        await update.message.reply_text("❌ Contrat refusé.")
        return
    await update.message.reply_text(
        f"✅ Contrat accepté !\n\n"
        f"💰 {fmt(result['amount'])} transféré de {result['from_company_name']} vers {result['target_name']}.\n"
        f"⏳ Durée : {result['duration']} jours.\n"
        f"📌 Type : {result['contract_type']}\n"
        f"⭐ Réputation gagnée : +{result['bonus_reputation']} chacune."
    )


@require_registered
@require_free
async def cmd_negocier_contrat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Permet de négocier un contrat en attente (changer montant et/ou durée)."""
    user = update.effective_user
    if len(context.args) < 3:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    try:
        contract_id = int(context.args[0])
        new_amount = int(context.args[1])
        new_duration = int(context.args[2])
        if new_amount <= 0 or new_duration <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return
    result = await companies_service.negotiate_contract(user.id, contract_id, new_amount, new_duration)
    if not result["ok"]:
        if result["reason"] == "not_target_owner":
            await update.message.reply_text("❌ Vous n'êtes pas le PDG de l'entreprise cible.")
        elif result["reason"] == "not_found":
            await update.message.reply_text("❌ Contrat introuvable ou déjà traité.")
        else:
            await update.message.reply_text("❌ Arguments invalides.")
        return
    await update.message.reply_text("📝 Contre-offre envoyée. En attente de réponse.")
