# handlers/controle.py — 🛠️ Console du staff (100 % boutons, préfixe `gc:`)
"""
handlers/controle.py — 🛠️ Console du staff (préfixe `gc:`)
  • 🔁 Transition du bot  : réduire puis fermer ce que le bot fournit ou achète, quand les entreprises prennent le relais
  • 🎁 Récompenses du bot  : réduire ou couper l'argent que le bot distribue (Game Leader et au-dessus)
  • ⚙️ Réglages du jeu     : paiements réels (Lead Principal uniquement), réseau RP, abonnés offerts
  • 📊 Économie            : argent en circulation, créé par le bot, récupéré par le Trésor public
  • 📜 Journal             : qui a changé quoi, et quand
Voir utils/gamerules.py pour la liste des réglages.
"""
from utils.swallow import swallowed
from utils.ui import esc
import html
import logging
import time

from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M, Update
from telegram.ext import ContextTypes

from config import ROLE_LABELS, role_level
from database import db_connection
from utils import gamerules as gr
from utils.decorators import get_user_role_async, require_registered

logger = logging.getLogger(__name__)
CB = "gc:"
LVL_ADMIN = role_level("ADMIN_N1")
LVL_TUNE = role_level("GAME_LEADER")
SEP = "━━━━━━━━━━━━━━━━━━"


async def _send(update: Update, text: str, markup: M) -> None:
    q = update.callback_query
    if q:
        try:
            await q.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
            return
        except Exception:
            await q.message.reply_text(text, parse_mode="HTML", reply_markup=markup)
            return
    await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


def _back(extra=None) -> M:
    rows = list(extra or [])
    rows.append([B("🛠️ Console", callback_data=CB + "home"), B("🎮 Menu", callback_data="menu_main")])
    return M(rows)


async def show_home(update: Update, uid: int, note: str = "") -> None:
    role = await get_user_role_async(uid)
    lvl = role_level(role)
    if lvl < LVL_ADMIN:
        await _send(update, "🛠️ <b>Console du staff</b>\nRéservée aux admins.", _back())
        return
    lines = [f"🛠️ <b>CONSOLE DU STAFF</b>\n{SEP}", f"Ton rang : <b>{esc(ROLE_LABELS.get(role, role))}</b>", ""]
    if note:
        lines.insert(1, note)
    lines.append("Pilote le rôle du <b>bot</b> pendant que les entreprises et les joueurs prennent le relais : "
                 "tu le réduis, puis tu le fermes au bon moment.")
    rows = []
    if lvl >= LVL_TUNE:
        rows.append([B("🔁 Transition du bot", callback_data=CB + "r")])
        rows.append([B("🎁 Récompenses du bot", callback_data=CB + "f")])
    if lvl >= role_level("ADMIN_N2"):
        rows.append([B("👤 Actions joueur", callback_data=CB + "p")])
    rows.append([B("📊 Économie", callback_data=CB + "e")])
    rows.append([B("⚙️ Réglages du jeu", callback_data=CB + "s")])
    rows.append([B("📜 Journal des changements", callback_data=CB + "l")])
    rows.append([B("🎮 Menu principal", callback_data="menu_main")])
    await _send(update, "\n".join(lines), M(rows))


async def show_faucets(update: Update, uid: int, note: str = "") -> None:
    if role_level(await get_user_role_async(uid)) < LVL_TUNE:
        await show_home(update, uid, "🚫 Réservé aux Game Leaders et au-dessus.")
        return
    lines = ["🎁 <b>RÉCOMPENSES DU BOT</b>", SEP,
             "L'argent que le bot distribue. <b>0 %</b> = coupé, <b>100 %</b> = normal, <b>200 %</b> = double.", ""]
    if note:
        lines.insert(1, note)
    rows = []
    for key, (label, desc) in gr.FAUCETS.items():
        pct = await gr.faucet_pct(key)
        icon = "⛔" if pct == 0 else ("🟢" if pct == 100 else "🟡")
        lines.append(f"{icon} <b>{esc(label)}</b> — {pct} %\n<i>{esc(desc)}</i>")
        rows.append([B("➖", callback_data=f"{CB}d:{key}"), B(f"{label} · {pct} %", callback_data=CB + "f"),
                     B("➕", callback_data=f"{CB}u:{key}")])
    await _send(update, "\n".join(lines), _back(rows))


async def show_switches(update: Update, uid: int, note: str = "") -> None:
    lvl = role_level(await get_user_role_async(uid))
    lines = ["⚙️ <b>RÉGLAGES DU JEU</b>", SEP, ""]
    if note:
        lines.insert(1, note)
    rows = []
    for key, (label, _default, lead_only) in gr.SWITCHES.items():
        on = await gr.switch_on(key)
        lock = " 🔒" if lead_only else ""
        lines.append(f"{'🟢' if on else '🔴'} <b>{esc(label)}</b>{lock} — {'ACTIF' if on else 'COUPÉ'}")
        rows.append([B(f"{'🟢' if on else '🔴'} {label}", callback_data=f"{CB}t:{key}")])
    lines.append("\n🔒 = réservé au Lead Principal (contrôle total des paiements réels).")
    if lvl < LVL_TUNE:
        lines.append("<i>Tu peux consulter ces réglages ; les modifier demande le rang Game Leader.</i>")
    await _send(update, "\n".join(lines), _back(rows))


async def _sum(db, sql: str, params=()) -> int:
    async with db.execute(sql, params) as cur:
        row = await cur.fetchone()
    return int(row[0] or 0) if row else 0


async def show_roles(update: Update, uid: int, note: str = "") -> None:
    """Transition : le bot assure encore certains rôles ; on les réduit puis on les ferme quand les joueurs suivent."""
    if role_level(await get_user_role_async(uid)) < LVL_TUNE:
        await show_home(update, uid, "🚫 Réservé aux Game Leaders et au-dessus.")
        return
    from database import now
    since = now() // 86400 - 6
    async with db_connection() as db:
        companies = await _sum(db, "SELECT COUNT(DISTINCT company_id) FROM company_production_log WHERE day>=? AND produced>0", (since,))
        produced = await _sum(db, "SELECT SUM(produced) FROM company_production_log WHERE day>=?", (since,))
        sold = await _sum(db, "SELECT SUM(sold) FROM company_production_log WHERE day>=?", (since,))
        used = {}
        for key, kind in (("npc_supply", "bot"), ("npc_orders", "created"), ("npc_counter", "created")):
            used[key] = await _sum(db, "SELECT SUM(amount) FROM treasury_flow WHERE day>=? AND source=? AND kind=?", (since, key, kind))
    relay = 100 if not produced else max(0, 100 - round(sold / produced * 100))
    lines = ["🔁 <b>TRANSITION DU BOT</b>", SEP,
             "Le bot fournit et achète encore une partie de l'économie. Quand les entreprises produisent et vendent "
             "elles-mêmes, <b>réduis puis ferme</b> ces rôles : 0 % = fermé.", ""]
    if note:
        lines.insert(1, note)
    rows = []
    for key, (label, desc) in gr.BOT_ROLES.items():
        pct = await gr.bot_pct(key)
        icon = "⛔" if pct == 0 else ("🟢" if pct == 100 else "🟡")
        lines.append(f"{icon} <b>{esc(label)}</b> — {pct} %\n<i>{esc(desc)}</i>\n"
                     f"   7 jours : <b>{used[key]:,}</b> €A")
        rows.append([B("➖", callback_data=f"{CB}rd:{key}"), B(f"{label} · {pct} %", callback_data=CB + "r"),
                     B("➕", callback_data=f"{CB}ru:{key}")])
    verdict = ("✅ Les joueurs absorbent déjà l'essentiel : le marché national peut être réduit." if relay >= 80 and produced
               else "⏳ Les entreprises dépendent encore du marché national : attends avant de le réduire.")
    lines += ["", "<b>Relais des entreprises (7 jours)</b>", f"🏢 Entreprises actives : <b>{companies}</b>",
              f"📦 Produit : <b>{produced:,}</b> · vendu au marché national : <b>{sold:,}</b>",
              f"🤝 Part absorbée hors bot : <b>{relay} %</b>", verdict]
    await _send(update, "\n".join(lines), _back(rows))


async def show_economy(update: Update, uid: int) -> None:
    """Tableau de bord : combien d'argent circule, combien le bot en crée, combien le Trésor public en récupère."""
    from database import now
    from utils import treasury as tr
    day = now() // 86400
    async with db_connection() as db:
        circulation = await _sum(db, "SELECT SUM(balance) FROM users WHERE registered=1")
        players = await _sum(db, "SELECT COUNT(*) FROM users WHERE registered=1")
        top10 = await _sum(db, "SELECT SUM(balance) FROM (SELECT balance FROM users WHERE registered=1 ORDER BY balance DESC LIMIT 10)")
        created = {}
        async with db.execute("SELECT source, SUM(amount) FROM treasury_flow WHERE day>=? AND kind='created' GROUP BY source "
                              "ORDER BY 2 DESC", (day - 6,)) as cur:
            for r in await cur.fetchall():
                created[r[0]] = int(r[1])
        collected = await _sum(db, "SELECT SUM(amount) FROM treasury_flow WHERE day>=? AND kind='in'", (day - 6,))
        redistributed = await _sum(db, "SELECT SUM(amount) FROM treasury_flow WHERE day>=? AND kind='out'", (day - 6,))
    total_created = sum(created.values())
    lines = ["📊 <b>ÉCONOMIE</b>", SEP,
             f"💰 Argent en circulation : <b>{circulation:,}</b> €A · 👥 {players} joueur(s)",
             f"🏆 Part des 10 plus riches : <b>{round(top10 / circulation * 100) if circulation else 0} %</b>", "",
             "<b>7 derniers jours de jeu</b>",
             f"🏭 Créé par le bot : <b>{total_created:,}</b>",
             f"🏛️ Récupéré par le Trésor public : <b>{collected:,}</b> (redistribué : {redistributed:,})",
             f"⚖️ Bilan : <b>{collected - total_created:+,}</b> " + ("(le Trésor compense le bot)" if collected >= total_created else "(le bot injecte plus qu'il ne récupère)"),
             f"🏦 Solde du Trésor public : <b>{await tr.balance():,}</b>"]
    if created:
        lines += ["", "<b>Argent créé, par source</b>"]
        for src, amount in list(created.items())[:8]:
            name = (gr.BOT_ROLES.get(src, (None,))[0] or (gr.FAUCETS.get(src.split(":", 1)[-1], (src,))[0] if src.startswith("faucet:") else src))
            lines.append(f"• {esc(str(name))} : {amount:,}")
    await _send(update, "\n".join(lines), _back())


async def show_log(update: Update, uid: int) -> None:
    rows_ = await gr.recent_changes(10)
    lines = ["📜 <b>JOURNAL DES CHANGEMENTS</b>", SEP]
    if not rows_:
        lines.append("Aucun changement enregistré.")
    for r in rows_:
        when = time.strftime("%d/%m %H:%M", time.gmtime(r["created_at"]))
        lines.append(f"• {when} — <code>{esc(r['key'])}</code> : {esc(r['old_value'] or '—')} → "
                     f"<b>{esc(r['new_value'])}</b> (par <code>{r['actor_id']}</code>)")
    await _send(update, "\n".join(lines), _back())


@require_registered

async def process_admin_roles_cleanup() -> None:
    """Nettoie les rôles admin révoqués depuis plus d'un an (ancien admin_roles.py)."""
    from database import cleanup_old_admin_roles
    await cleanup_old_admin_roles(days=365)


_PLAYER_ACTIONS: dict[str, tuple[str, str, str]] = {
    "info":        ("userinfo",     "@user_ou_id",                    "Fiche complète d\'un joueur."),
    "hist":        ("playerhistory","@user_ou_id [jours]",            "Historique admin sur ce joueur."),
    "warn":        ("warn",         "@user_ou_id raison",             "Ajoute un avertissement (Admin N2+)."),
    "ban":         ("banuser",      "@user_ou_id [jours] [raison]",   "Bannit le joueur (0 = permanent)."),
    "unban":       ("unbanuser",    "@user_ou_id",                    "Lève le bannissement."),
    "freeze":      ("freezeuser",   "@user_ou_id [jours] [raison]",   "Gèle le compte temporairement."),
    "unfreeze":    ("unfreezeuser", "@user_ou_id",                    "Lève le gel."),
    "hospital":    ("sethospital",  "@user_ou_id heures",             "Place le joueur à l\'hôpital."),
    "addmoney":    ("addmoney",     "@user_ou_id montant [raison]",   "Ajoute des €A au solde."),
    "remmoney":    ("removemoney",  "@user_ou_id montant [raison]",   "Retire des €A du solde."),
    "addxp":       ("addxp",        "@user_ou_id montant",            "Ajoute de l\'XP."),
    "prestige":    ("addprestige",  "@user_ou_id montant",            "Ajoute du prestige."),
    "resetcd":     ("resetcooldown","@user_ou_id clé_cooldown",       "Remet un cooldown à zéro."),
    "kill":        ("killuser",     "@user_ou_id raison",             "Tue le joueur en RP."),
}


async def show_players(update: Update, uid: int, note: str = "") -> None:
    """Panneau d\'actions rapides sur un joueur (Admin N2+)."""
    from config import role_level as rl
    if role_level(await get_user_role_async(uid)) < rl("ADMIN_N2"):
        await show_home(update, uid, "🚫 Réservé aux Admins N2 et au-dessus.")
        return
    lines = ["👤 <b>ACTIONS JOUEUR</b>", SEP,
             "Clique sur une action — le bot affiche la syntaxe à taper.", ""]
    if note:
        lines.insert(1, note)
    rows = [
        [B("ℹ️ Infos",        f"{CB}pa:info"),  B("📜 Historique",  f"{CB}pa:hist")],
        [B("⚠️ Avertir",      f"{CB}pa:warn"),  B("🚫 Bannir",      f"{CB}pa:ban")],
        [B("🔓 Débannir",     f"{CB}pa:unban"), B("❄️ Geler",       f"{CB}pa:freeze")],
        [B("❤️ Dégeler",      f"{CB}pa:unfreeze"), B("🏥 Hospitaliser",f"{CB}pa:hospital")],
        [B("💰 Donner €A",    f"{CB}pa:addmoney"), B("💸 Retirer €A",f"{CB}pa:remmoney")],
        [B("✨ Donner XP",    f"{CB}pa:addxp"), B("⭐ Prestige",     f"{CB}pa:prestige")],
        [B("🔄 Reset CD",     f"{CB}pa:resetcd"), B("💀 Tuer (RP)",  f"{CB}pa:kill")],
        [B("⬅️ Retour console", f"{CB}home")],
    ]
    await _send(update, "\n".join(lines), M([[b for b in row] for row in rows]))

async def cmd_controle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update, update.effective_user.id)


async def gc_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    parts = (q.data or "").split(":")
    action = parts[1] if len(parts) > 1 else "home"
    key = parts[2] if len(parts) > 2 else ""
    try:
        role = await get_user_role_async(uid)
        lvl = role_level(role)
        await q.answer()
        if lvl < LVL_ADMIN:
            await show_home(update, uid)
            return
        if action == "f":
            await show_faucets(update, uid)
        elif action in ("u", "d") and key in gr.FAUCETS:
            if lvl < LVL_TUNE:
                await show_home(update, uid, "🚫 Réservé aux Game Leaders et au-dessus.")
                return
            cur = await gr.faucet_pct(key)
            steps = list(gr.STEPS)
            idx = min(range(len(steps)), key=lambda i: abs(steps[i] - cur))
            idx = min(len(steps) - 1, idx + 1) if action == "u" else max(0, idx - 1)
            await gr.set_rule(f"faucet:{key}", str(steps[idx]), uid)
            await show_faucets(update, uid, f"✅ {gr.FAUCETS[key][0]} → <b>{steps[idx]} %</b>")
        elif action == "r":
            await show_roles(update, uid)
        elif action in ("ru", "rd") and key in gr.BOT_ROLES:
            if lvl < LVL_TUNE:
                await show_home(update, uid, "🚫 Réservé aux Game Leaders et au-dessus.")
                return
            cur = await gr.bot_pct(key)
            steps = [x for x in gr.STEPS if x <= 200]
            idx = min(range(len(steps)), key=lambda i: abs(steps[i] - cur))
            idx = min(len(steps) - 1, idx + 1) if action == "ru" else max(0, idx - 1)
            await gr.set_rule(f"bot:{key}", str(steps[idx]), uid)
            await show_roles(update, uid, f"✅ {gr.BOT_ROLES[key][0]} → <b>{steps[idx]} %</b>")
        elif action == "e":
            await show_economy(update, uid)
        elif action == "s":
            await show_switches(update, uid)
        elif action == "t" and key in gr.SWITCHES:
            _label, _d, lead_only = gr.SWITCHES[key]
            if lead_only and role != "LEAD_PRINCIPAL":
                await show_switches(update, uid, "🔒 Seul le Lead Principal contrôle les paiements réels.")
                return
            if lvl < LVL_TUNE:
                await show_switches(update, uid, "🚫 Réservé aux Game Leaders et au-dessus.")
                return
            new = await gr.toggle_switch(key, uid)
            await show_switches(update, uid, f"✅ {gr.SWITCHES[key][0]} : <b>{'ACTIF' if new else 'COUPÉ'}</b>")
        elif action == "l":
            await show_log(update, uid)
        elif action == "p":
            await show_players(update, uid)
        elif action == "pa":
            if role_level(role) < role_level("ADMIN_N2"):
                await show_home(update, uid, "🚫 Réservé aux Admins N2 et au-dessus.")
                return
            if key and key in _PLAYER_ACTIONS:
                cmd, usage, desc = _PLAYER_ACTIONS[key]
                await _send(update,
                    f"👤 <b>/{cmd}</b>\n{SEP}\n<i>{esc(desc)}</i>\n\n"
                    f"📋 Syntaxe :\n<code>/{cmd} {usage}</code>\n\n"
                    f"Envoie cette commande dans le chat du bot.",
                    M([[B("⬅️ Retour", callback_data=f"{CB}p")]]))
            else:
                await show_players(update, uid)
        else:
            await show_home(update, uid)
    except Exception:
        logger.exception("Console staff : erreur")
        try:
            await q.answer("Erreur, réessaie.", show_alert=True)
        except Exception:
            swallowed('handlers/controle.py')
