# handlers/notifications.py
from utils.swallow import swallowed
import asyncio
import html
import logging
import re
import time
import aiosqlite
from telegram import Update
from telegram.error import BadRequest, Forbidden, NetworkError, RetryAfter
from telegram.ext import ContextTypes
from database import DB_PATH, get_user, now, db_connection
from utils.decorators import require_registered, admin_only
from utils.helpers import fmt_time
from utils.helpers import escape_html

logger = logging.getLogger(__name__)

# Réglages de montée en charge
BROADCAST_CHUNK = 5000        # joueurs par tranche lors d'une diffusion
NOTIF_SEND_PER_SEC = 12       # volontairement bas : les ~30 msg/s de Telegram sont partagés avec les réponses aux joueurs
NOTIF_USERS_PER_PASS = 200    # joueurs chargés à la fois
NOTIF_TIME_BUDGET = 90        # secondes max par passage (le job a 120 s)

# Signal de réveil : dès qu'une notification est mise en file, l'envoi part immédiatement
# au lieu d'attendre le prochain passage périodique (avant : jusqu'à 60 s de retard).
_wakeup: asyncio.Event | None = None


def _signal_wakeup() -> None:
    global _wakeup
    if _wakeup is None:
        _wakeup = asyncio.Event()
    _wakeup.set()


async def wait_for_notifications(timeout: float = 3.0) -> None:
    """Attend qu'une notification arrive (ou `timeout` s), puis réarme le signal.

    Le signal est remis à zéro AVANT l'envoi : une notification qui arrive pendant l'envoi
    redéclenche aussitôt un nouveau passage, rien n'est perdu.
    """
    global _wakeup
    if _wakeup is None:
        _wakeup = asyncio.Event()
    try:
        await asyncio.wait_for(_wakeup.wait(), timeout)
    except asyncio.TimeoutError:
        swallowed('handlers/notifications.py')
    _wakeup.clear()


# ─────────────────────────────────────────────────────────────────────────────
# Types de notifications
# ─────────────────────────────────────────────────────────────────────────────
NOTIF_TYPES = {
    "info": "ℹ️",
    "success": "✅",
    "warning": "⚠️",
    "error": "❌",
    "event": "🌍",
    "reward": "🎁",
    "achievement": "🏆",
    "crime": "🔫",
    "economy": "💰",
    "social": "📱"
}

# ─────────────────────────────────────────────────────────────────────────────
# Helpers (file d'attente)
# ─────────────────────────────────────────────────────────────────────────────
async def queue_notification(user_id: int, title: str, message: str, notif_type: str = "info", delay: int = 0):
    """Ajoute une notification à la file d'attente (différée)."""
    async with db_connection() as db:
        await db.execute("""
            INSERT INTO notifications (user_id, title, message, type, delay, created_at, sent)
            VALUES (?, ?, ?, ?, ?, ?, 0)
        """, (user_id, title, message, notif_type, delay, now()))
        await db.commit()
    if not delay:
        _signal_wakeup()

async def queue_broadcast_notification(title: str, message: str, notif_type: str = "info", delay: int = 0):
    """Ajoute une notification pour TOUS les utilisateurs (file d'attente).

    Une seule requête INSERT ... SELECT, par tranches d'identifiants, au lieu
    d'une boucle joueur par joueur : reste rapide même avec beaucoup de joueurs
    et ne garde jamais la base bloquée longtemps.
    """
    created = now()
    last_id = 0
    while True:
        async with db_connection() as db:
            async with db.execute(
                "SELECT MAX(user_id) FROM (SELECT user_id FROM users "
                "WHERE registered = 1 AND banned = 0 AND user_id > ? "
                "ORDER BY user_id LIMIT ?)",
                (last_id, BROADCAST_CHUNK),
            ) as cur:
                row = await cur.fetchone()
            upper = row[0] if row else None
            if upper is None:
                break
            await db.execute(
                "INSERT INTO notifications (user_id, title, message, type, delay, created_at, sent) "
                "SELECT user_id, ?, ?, ?, ?, ?, 0 FROM users "
                "WHERE registered = 1 AND banned = 0 AND user_id > ? AND user_id <= ?",
                (title, message, notif_type, delay, created, last_id, upper),
            )
            await db.commit()
        last_id = upper
        await asyncio.sleep(0)
    if not delay:
        _signal_wakeup()

async def get_pending_notifications(user_id: int, limit: int = 50) -> list:
    """Récupère les notifications non envoyées d'un utilisateur."""
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT * FROM notifications
            WHERE user_id = ? AND sent = 0 AND (delay = 0 OR created_at + delay < ?)
            ORDER BY created_at ASC
            LIMIT ?
        """, (user_id, now(), limit)) as cur:
            return [dict(r) for r in await cur.fetchall()]

async def mark_notification_sent(notif_id: int):
    """Marque une notification comme envoyée."""
    async with db_connection() as db:
        await db.execute("UPDATE notifications SET sent = 1, sent_at = ? WHERE id = ?", (now(), notif_id))
        await db.commit()

async def get_notification_history(user_id: int, limit: int = 20) -> list:
    """Récupère l'historique des notifications envoyées."""
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT * FROM notifications
            WHERE user_id = ? AND sent = 1
            ORDER BY sent_at DESC
            LIMIT ?
        """, (user_id, limit)) as cur:
            return [dict(r) for r in await cur.fetchall()]

async def clear_old_notifications(days: int = 30):
    """Supprime les notifications de plus de X jours."""
    cutoff = now() - (days * 86400)
    async with db_connection() as db:
        await db.execute("DELETE FROM notifications WHERE sent = 1 AND sent_at < ?", (cutoff,))
        await db.commit()

# ─────────────────────────────────────────────────────────────────────────────
# Envoi périodique des notifications (à appeler dans le scheduler)
# ─────────────────────────────────────────────────────────────────────────────
async def _claim_pending(user_id: int, limit: int) -> list[dict]:
    """Récupère ET marque comme envoyées les notifications d'un joueur, en une transaction."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("""
            SELECT * FROM notifications
            WHERE user_id = ? AND sent = 0 AND (delay = 0 OR created_at + delay < ?)
            ORDER BY created_at ASC
            LIMIT ?
        """, (user_id, now(), limit)) as cur:
            pending = [dict(r) for r in await cur.fetchall()]
        if pending:
            t = now()
            await db.executemany(
                "UPDATE notifications SET sent = 1, sent_at = ? WHERE id = ?",
                [(t, n["id"]) for n in pending],
            )
            await db.commit()
        return pending


_BOLD_RE = re.compile(r"\*\*(.+?)\*\*", re.S)
# Balises de mise en forme que les modules ont le droit d'écrire dans un message (<b>…</b>, etc.)
_SAFE_TAG_RE = re.compile(r"&lt;(/?)(b|i|u|s|code)&gt;")


def _strip_tags(text: str) -> str:
    """Titre : on enlève les balises éventuelles (le titre est déjà mis en gras par l'affichage)."""
    return re.sub(r"</?(b|i|u|s|code)>", "", text or "")


def _to_html(text: str) -> str:
    """Texte brut (avec éventuels **gras** posés par les appelants) -> HTML Telegram sûr.

    Échappe d'abord (noms de joueurs contenant _ * < > &), puis convertit **x** en <b>x</b>.
    Plus aucun « can't parse entities » : le HTML échappé ne peut pas être invalide.
    """
    escaped = html.escape(text or "")
    escaped = _SAFE_TAG_RE.sub(r"<\1\2>", escaped)      # <b>…</b> écrits par les modules : on les rend, on ne les affiche pas
    return _BOLD_RE.sub(r"<b>\1</b>", escaped)


async def _release_claim(ids: list[int]) -> None:
    """Remet des notifications en attente (échec d'envoi temporaire) pour le prochain passage."""
    if not ids:
        return
    async with db_connection() as db:
        await db.executemany(
            "UPDATE notifications SET sent = 0, sent_at = 0 WHERE id = ?",
            [(i,) for i in ids],
        )
        await db.commit()


async def _send_with_retry(bot, user_id: int, text: str) -> bool:
    """Envoie un message HTML. Retourne True si livré ou inutile de réessayer.

    • RetryAfter  : attend puis réessaie une fois ; sinon False (à remettre en file).
    • Forbidden   : le joueur a bloqué le bot → on abandonne (True, pas de réessai).
    • BadRequest  : un repli en texte brut est tenté ; si ça échoue encore → abandon (True).
    • NetworkError/autre : False (à remettre en file), avec log.
    """
    async def _once(**kw):
        await bot.send_message(user_id, text, **kw)

    try:
        try:
            await _once(parse_mode="HTML")
        except RetryAfter as e:
            await asyncio.sleep(float(e.retry_after) + 1)
            await _once(parse_mode="HTML")
        return True
    except Forbidden:
        logger.info("Notification abandonnée : l'utilisateur %s a bloqué le bot.", user_id)
        return True
    except BadRequest as e:
        logger.warning("Notification HTML refusée pour %s (%s) → repli texte brut.", user_id, e)
        try:
            await bot.send_message(user_id, re.sub(r"<[^>]+>", "", html.unescape(text)))
        except Exception as e2:
            logger.warning("Notification abandonnée pour %s : %s", user_id, e2)
        return True
    except (RetryAfter, NetworkError) as e:
        logger.warning("Notification à %s : échec temporaire (%s), remise en file.", user_id, e)
        return False
    except Exception:
        logger.exception("Notification à %s : erreur inattendue, remise en file.", user_id)
        return False


async def process_notifications(bot):
    """Envoie les notifications en attente (appelé régulièrement).

    Débit limité à ~NOTIF_SEND_PER_SEC messages/seconde (limite Telegram ≈ 30/s)
    et borné dans le temps : ce qui reste est repris au passage suivant.
    """
    deadline = time.monotonic() + NOTIF_TIME_BUDGET
    interval = 1.0 / NOTIF_SEND_PER_SEC
    failed: set[int] = set()   # échecs temporaires : on ne les réessaie qu'au prochain passage
    while time.monotonic() < deadline:
        async with db_connection() as db:
            async with db.execute("""
                SELECT DISTINCT user_id FROM notifications
                WHERE sent = 0 AND (delay = 0 OR created_at + delay < ?)
                LIMIT ?
            """, (now(), NOTIF_USERS_PER_PASS)) as cur:
                users = [r[0] for r in await cur.fetchall() if r[0] not in failed]
        if not users:
            return

        for user_id in users:
            if time.monotonic() >= deadline:
                return
            pending = await _claim_pending(user_id, 5)  # Max 5 par envoi
            if not pending:
                continue

            text = "📬 <b>Tes notifications</b>\n\n"
            for notif in pending:
                emoji = NOTIF_TYPES.get(notif["type"], "📌")
                text += f"{emoji} <b>{html.escape(_strip_tags(notif['title'] or ''))}</b>\n{_to_html(notif['message'])}\n\n"

            if not await _send_with_retry(bot, user_id, text):
                await _release_claim([n["id"] for n in pending])
                failed.add(user_id)
            await asyncio.sleep(interval)

# ─────────────────────────────────────────────────────────────────────────────
# Commandes utilisateur
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_notifications(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT title, message, created_at FROM notifications WHERE user_id=? AND sent=1 ORDER BY created_at DESC LIMIT 20",
            (user.id,)
        ) as cur:
            notifs = await cur.fetchall()
    if not notifs:
        await update.message.reply_text("📭 Aucune notification.")
        return
    text = "📬 <b>Notifications</b>\n\n"
    for n in notifs:
        title = html.escape(_strip_tags(n["title"]))
        msg = _to_html(n["message"])
        line = f"• <b>{title}</b> : {msg}\n"
        if len(text) + len(line) > 4000:   # on s'arrête AVANT de dépasser : jamais de balise coupée
            break
        text += line
    await update.message.reply_text(text, parse_mode="HTML")

@require_registered
async def cmd_notifications_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche l'historique des notifications."""
    user = update.effective_user
    history = await get_notification_history(user.id, 20)
    
    if not history:
        await update.message.reply_text("📜 Aucun historique de notifications.")
        return
    
    text = "📜 <b>Historique des notifications</b>\n\n"
    for notif in history:
        emoji = NOTIF_TYPES.get(notif["type"], "📌")
        title = html.escape(_strip_tags(notif["title"]))
        message = _to_html(notif["message"])
        sent_at = fmt_time(max(0, now() - notif["sent_at"])) if notif["sent_at"] else "?"
        block = f"{emoji} <b>{title}</b>\n{message}\n<i>[il y a {sent_at}]</i>\n\n"
        if len(text) + len(block) > 4000:   # jamais de balise coupée en deux
            break
        text += block

    await update.message.reply_text(text, parse_mode="HTML")

@require_registered
async def cmd_notifications_clear(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Supprime toutes les notifications en attente."""
    user = update.effective_user
    async with db_connection() as db:
        await db.execute("DELETE FROM notifications WHERE user_id = ? AND sent = 0", (user.id,))
        await db.commit()
    await update.message.reply_text("🗑️ Toutes tes notifications en attente ont été supprimées.")

# ─────────────────────────────────────────────────────────────────────────────
# Commandes admin
# ─────────────────────────────────────────────────────────────────────────────
@admin_only
async def cmd_broadcast_notify(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Envoie une notification à tous les utilisateurs (file d'attente)."""
    if not context.args:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 📜 Profil & infos → Notifications."
            "Ouvre l'action depuis le 🎮 Menu principal."
        )
        return
    
    args = " ".join(context.args)
    if " | " not in args:
        await update.message.reply_text("❌ Format invalide. Utilise `titre | message`")
        return
    
    title, message = args.split(" | ", 1)
    await queue_broadcast_notification(title[:50], message[:500], "info")
    await update.message.reply_text(f"✅ Notification mise en file d'attente pour tous les utilisateurs :\n<b>{escape_html(title)}</b>\n{escape_html(message)}", parse_mode="HTML")

@admin_only
async def cmd_notify_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Envoie une notification à un utilisateur spécifique (file d'attente)."""
    if not update.message.reply_to_message or len(context.args) < 2:
        await update.message.reply_text(
            "Usage : Répondre au message de l'utilisateur depuis le 🎮 Menu principal"
        )
        return
    
    target = update.message.reply_to_message.from_user
    args = " ".join(context.args)
    if " | " not in args:
        await update.message.reply_text("❌ Format invalide. Utilise `titre | message`")
        return
    
    title, message = args.split(" | ", 1)
    await queue_notification(target.id, title[:50], message[:500], "info")
    await update.message.reply_text(f"✅ Notification mise en file d'attente pour {escape_html(target.full_name)} :\n<b>{escape_html(title)}</b>\n{escape_html(message)}", parse_mode="HTML")

@admin_only
async def cmd_notifications_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les statistiques des notifications."""
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM notifications WHERE sent = 0") as cur:
            pending = (await cur.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM notifications WHERE sent = 1") as cur:
            sent = (await cur.fetchone())[0]
        async with db.execute("SELECT COUNT(DISTINCT user_id) FROM notifications WHERE sent = 0") as cur:
            users_pending = (await cur.fetchone())[0]
    
    await update.message.reply_text(
        f"📊 <b>Statistiques des notifications</b>\n\n"
        f"⏳ En attente : {escape_html(pending)}\n"
        f"✅ Envoyées : {escape_html(sent)}\n"
        f"👥 Utilisateurs avec notifications : {escape_html(users_pending)}",
        parse_mode="HTML"
    )

# ─────────────────────────────────────────────────────────────────────────────
# Hooks pratiques pour les autres modules (utilisent la file d'attente)
# ─────────────────────────────────────────────────────────────────────────────
async def notify_achievement(user_id: int, achievement_name: str):
    await queue_notification(user_id, "Nouveau succès !", f"Tu as débloqué le succès **{achievement_name}** !", "achievement")


async def notify_economy(user_id: int, title: str, message: str):
    await queue_notification(user_id, title, message, "economy")

async def notify_crime(user_id: int, success: bool, reward: int = 0, jail_time: int = 0):
    if success:
        await queue_notification(user_id, "🔫 Crime réussi", f"Tu as gagné {reward} €A !", "crime")
    else:
        await queue_notification(user_id, "🔫 Crime échoué", f"Tu as été arrêté pour {fmt_time(jail_time)}.", "crime")
        
        

# ═══════════════════════════════════════════════════════════════════
#              📩 MENU INTERACTIF NOTIFICATIONS
# ═══════════════════════════════════════════════════════════════════
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from utils.helpers import safe_edit


async def show_notifications_menu(query, user_id: int):
    """Menu interactif Notifications."""
    async with db_connection() as db:
        async with db.execute(
            "SELECT COUNT(*) FROM notifications WHERE user_id=? AND sent=0",
            (user_id,)
        ) as cur:
            pending = (await cur.fetchone())[0] or 0
        async with db.execute(
            "SELECT COUNT(*) FROM notifications WHERE user_id=? AND sent=1",
            (user_id,)
        ) as cur:
            sent = (await cur.fetchone())[0] or 0

    body = [
        f"⏳ En attente : <b>{pending}</b>",
        f"✅ Reçues : <b>{sent}</b>",
        "",
        "<i>Les notifications apparaissent dans ton chat.</i>",
    ]

    keyboard = [
        [InlineKeyboardButton("📩 Voir mes notifications", callback_data="notif_view")],
        [InlineKeyboardButton("📜 Historique", callback_data="notif_history")],
        [InlineKeyboardButton("🗑️ Tout effacer", callback_data="notif_clear")],
        [InlineKeyboardButton("⬅️ Menu principal", callback_data="menu_main")],
    ]

    await safe_edit(
        query,
        "📩 <b>MES NOTIFICATIONS</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def show_notifications_pending(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT title, message, created_at FROM notifications "
            "WHERE user_id=? AND sent=1 ORDER BY created_at DESC LIMIT 15",
            (user_id,)
        ) as cur:
            rows = await cur.fetchall()

    if not rows:
        await safe_edit(
            query,
            "📭 Tu n'as aucune notification.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="notif_menu")]])
        )
        return

    body = []
    for r in rows:
        body.append(f"🔔 <b>{r['title']}</b>")
        body.append(f"   {r['message']}")
        body.append("")

    await safe_edit(
        query,
        "📩 <b>Mes notifications</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="notif_menu")]])
    )


async def show_notifications_history(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT title, message, sent_at FROM notifications "
            "WHERE user_id=? AND sent=1 ORDER BY sent_at DESC LIMIT 15",
            (user_id,)
        ) as cur:
            rows = await cur.fetchall()

    if not rows:
        await safe_edit(
            query,
            "📜 Aucun historique de notifications.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="notif_menu")]])
        )
        return

    body = []
    for r in rows:
        from utils.helpers import fmt_time as _fmt_time
        ago = _fmt_time(max(0, now() - r["sent_at"])) if r["sent_at"] else "?"
        body.append(f"🔔 <b>{r['title']}</b> — <i>il y a {ago}</i>")
        body.append(f"   {r['message']}")
        body.append("")

    await safe_edit(
        query,
        "📜 <b>Historique</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="notif_menu")]])
    )


async def do_clear_notifications(query, user_id: int):
    async with db_connection() as db:
        await db.execute("DELETE FROM notifications WHERE user_id=? AND sent=0", (user_id,))
        await db.commit()

    await safe_edit(
        query,
        "🗑️ Toutes tes notifications en attente ont été supprimées.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="notif_menu")]])
    )


async def notifications_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routeur des callbacks 'notif_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "notif_menu":
        await show_notifications_menu(query, user_id)
        return
    if data == "notif_view":
        await show_notifications_pending(query, user_id)
        return
    if data == "notif_history":
        await show_notifications_history(query, user_id)
        return
    if data == "notif_clear":
        await do_clear_notifications(query, user_id)
        return