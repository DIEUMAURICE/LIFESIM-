"""Entreprises — catalogue de produits : prix, retrait, don, suppression. Les produits ne se créent que par le travail des
employés avec les matériaux (aucune personnalisation : nom, emoji et description sont fixés).

Le catalogue (liste, prix, suppression, retrait) délègue à `gameplay/companies.py`, le même
service pur que `webapp/routers/companies_router.py` — aucune règle n'est recalculée ici."""
from telegram.ext import ContextTypes
from database import get_user, get_user_company, log_company_action, db_connection
from telegram import Update
import aiosqlite
import gameplay.companies as companies_service
from utils.company_roles import can_manage
from utils.aesthetics import card
from utils.helpers import fmt, escape_html
from utils.decorators import require_registered, require_free


@require_registered
@require_free
async def cmd_produits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche le catalogue entreprise et ses produits."""
    user = update.effective_user
    company = await get_user_company(user.id)

    if not company:
        await update.message.reply_text(
            "❌ Tu n'es dans aucune entreprise.\n"
            "Crée ou rejoins une entreprise pour accéder à ses produits."
        )
        return

    # Vérification directe dans la table companies pour obtenir le owner_id
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT owner_id FROM companies WHERE company_id = ?", (company["company_id"],)) as cur:
            row = await cur.fetchone()
            owner_id = row["owner_id"] if row else None

    # Message de diagnostic si l'utilisateur n'est pas propriétaire
    if owner_id != user.id:
        owner = await get_user(owner_id) if owner_id else None
        owner_name = escape_html(owner["full_name"]) if owner else "Inconnu"
        await update.message.reply_text(
            f"❌ Seul le PDG peut voir les produits de l'entreprise.\n"
            f"PDG actuel : {owner_name} (ID: {owner_id})\n"
            f"Ton ID : {user.id}\n\n"
            "⚠️ Si tu penses être le PDG, Ouvre le 🎮 Menu principal pour récupérer la propriété "
            "ou contacte un administrateur.\n"
            f"Vérifie aussi depuis le 🎮 Menu principal pour voir le propriétaire affiché."
        )
        return

    # ─── Affichage du catalogue (service partagé avec l'API) ───
    products = await companies_service.list_products(user.id, company["company_id"])

    if not products:
        async with db_connection() as db:
            async with db.execute("SELECT COUNT(*) FROM company_products WHERE company_id=?", (company["company_id"],)) as cur2:
                count = (await cur2.fetchone())[0]
        if count == 0:
            await update.message.reply_text(
                card(
                    "📦 Catalogue vide",
                    [
                        "Aucun produit actif.",
                    ],
                    icon="📦", style="round"
                ),
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text(
                card(
                    "📦 Catalogue vide (stock épuisé)",
                    [
                        "Tous les produits sont en rupture de stock.",
                    ],
                    icon="📦", style="round"
                ),
                parse_mode="HTML"
            )
        return

    body = []
    for product in products[:12]:
        effect_info = f" ({product.get('effect_type', 'aucun')} {product.get('effect_value', '')})" if product.get('effect_type') else ""
        emoji = product.get('emoji', '📦')
        desc = product.get('description', '')
        if desc:
            desc = f" — {desc[:30]}{'...' if len(desc) > 30 else ''}"
        body.append(
            f"{emoji} <b>{escape_html(product['name'])}</b> · stock <b>{product['stock']}</b> · "
            f"prix {fmt(product['price'])} · ventes {product['sales']} · CA {fmt(product['revenue'])}{effect_info}{desc}"
        )
    body += [
        "",
        "Commandes utiles :",
        "💲 <code>/setprix [produit] [prix]</code>",
        "🗑️ <code>/retirer_produit [id objet] [quantité]</code> (perte)",
    ]
    await update.message.reply_text(
        card("📦 Produits de l'entreprise", body, icon="📦", style="thick"),
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_supprimer_produit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Supprime définitivement un produit du catalogue (même si stock épuisé)."""
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        await update.message.reply_text("❌ Seul le PDG peut supprimer un produit.")
        return
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    name = " ".join(context.args)
    if not await companies_service.delete_product(company["company_id"], user.id, name):
        await update.message.reply_text(f"❌ Produit '{name}' introuvable dans le catalogue.")
        return
    await log_company_action(company["company_id"], "supprimer_produit", user.id, name)
    await update.message.reply_text(f"🗑️ Produit **{name}** supprimé définitivement du catalogue.")


@require_registered
@require_free
async def cmd_retirer_produit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Retire une certaine quantité d'un produit de l'inventaire du PDG (perte)."""
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        await update.message.reply_text("❌ Seul le PDG peut retirer des produits.")
        return
    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    try:
        item_id = int(context.args[0])
        qty = int(context.args[1])
        if qty <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return
    ok, message, name = await companies_service.withdraw_product(user.id, item_id, qty)
    if not ok:
        await update.message.reply_text(f"❌ {message}")
        return
    await log_company_action(company["company_id"], "retirer_produit", user.id, f"{name} x{qty}")
    await update.message.reply_text(f"🗑️ Retiré {qty} exemplaire(s) de **{name}** de ton inventaire (perte).")


@require_registered
@require_free
async def cmd_setprix(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Modifie le prix de vente conseillé d'un produit (affiché dans le menu)."""
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        await update.message.reply_text("❌ Seul le PDG peut modifier le prix d'un produit.")
        return
    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    name = " ".join(context.args[:-1])
    try:
        new_price = int(context.args[-1])
        if new_price < 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Prix invalide.")
        return
    if not await companies_service.set_product_price(company["company_id"], name, new_price):
        await update.message.reply_text(f"❌ Produit '{name}' introuvable.")
        return
    await update.message.reply_text(f"💰 Prix conseillé du produit **{name}** mis à jour : {fmt(new_price)}.")


@require_registered
@require_free
async def cmd_donner_produit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Donne un produit (item) à un autre joueur depuis l'inventaire."""
    if not update.message.reply_to_message:
        await update.message.reply_text("Répondez au message du joueur à qui vous voulez donner un produit.")
        return
    target = update.message.reply_to_message.from_user
    if target.id == update.effective_user.id:
        await update.message.reply_text("Vous ne pouvez pas vous donner un produit à vous-même.")
        return
    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    try:
        item_id = int(context.args[0])
        quantity = int(context.args[1])
        if quantity <= 0:
            raise ValueError
    except Exception:
        await update.message.reply_text("Arguments invalides.")
        return
    from database import get_inventory
    inv = await get_inventory(update.effective_user.id)
    item_quantity = next((i["quantity"] for i in inv if i["item_id"] == item_id), 0)
    if item_quantity < quantity:
        await update.message.reply_text(f"Vous n'avez que {item_quantity} exemplaire(s) de cet item.")
        return
    from handlers.market import remove_item, add_item
    await remove_item(update.effective_user.id, item_id, quantity)
    await add_item(target.id, item_id, quantity, "don")
    await update.message.reply_text(f"✅ {quantity}x item #{item_id} donné à {target.full_name}.")
