"""
handlers/forms_crime.py — Gangs : toutes les commandes en formulaires à boutons
(remplace /creergand, /rejoindregang, /ganginfo, /gangcaisse, /quittergang, …)
"""
from __future__ import annotations

from database import db_connection
from utils.forms import Form, P, provider, register

BACK = "crime_menu"
M = "handlers.crime:"
ACTION = (("💰 Déposer", "depot"), ("💸 Retirer", "retrait"))
NONE, IN = "gang_none", "gang_in"


@provider("gangs")
async def _gangs(uid):
    async with db_connection() as db:
        async with db.execute(
            "SELECT name, reputation FROM gangs ORDER BY reputation DESC LIMIT 20"
        ) as cur:
            return [(f"🏴 {n} (⭐ {r})", n) for n, r in await cur.fetchall()]


@provider("gang_mates")
async def _mates(uid):
    """Membres de mon gang (sauf moi) : (libellé, id)."""
    async with db_connection() as db:
        async with db.execute(
                "SELECT u.full_name, gm.role, gm.user_id FROM gang_members gm "
                "JOIN users u ON u.user_id=gm.user_id WHERE gm.gang_id="
                "(SELECT gang_id FROM gang_members WHERE user_id=?) AND gm.user_id!=? LIMIT 20", (uid, uid)) as cur:
            return [(f"👤 {n or 'Joueur'} — {r}", str(i)) for n, r, i in await cur.fetchall()]


ROLES = tuple((r, r) for r in ("Bras droit", "Lieutenant", "Soldat", "Recrue"))


def F(key, label, fn, params=(), groups=(), **kw):
    return Form(f"g_{key}", label, fn if ":" in fn else M + fn, tuple(params), tuple(groups), back=BACK, **kw)


register(
    F("creer", "➕ Créer un gang", "cmd_creergand",
      [P("name", "text", "Nom de ton gang ? (50 000 €A de frais)")], [NONE]),
    F("rejoindre", "🤝 Rejoindre", "handlers.gangs:cmd_rejoindregang",
      [P("name", "choice", "Quel gang veux-tu rejoindre ?", choices="gangs")], [NONE]),
    F("voir", "🔍 Voir un gang", "cmd_ganginfo",
      [P("name", "choice", "Quel gang ?", choices="gangs")], [NONE, IN]),
    F("classement", "🏆 Classement", "cmd_gangclassement", [], [NONE, IN]),
    F("actions", "⚡ Actions", "cmd_gangactions", [], [IN]),
    F("caisse", "💰 Caisse", "cmd_gangcaisse",
      [P("action", "choice", "Que veux-tu faire ?", choices=ACTION),
       P("amount", "int", "Quel montant (€A) ?", min=1)], [IN]),
    F("hold", "🔫 Hold-up", "cmd_ganghold", [], [IN]),
    F("upgrade", "📈 Améliorer", "cmd_gangupgrade", [], [IN]),
    F("transfert", "👑 Passer chef", "cmd_transfertchef",
      [P("target", "user", "Envoie le <b>@pseudo</b> ou l'<b>ID</b> du nouveau chef.", reply=True)],
      [IN], confirm="Tu perdras le rôle de chef."),
    F("quitter", "🚪 Quitter", "cmd_quittergang", [], [IN],
      confirm="Tu quittes ton gang."),
    F("dissoudre", "💥 Dissoudre", "cmd_dissoudregang", [], [IN],
      confirm="⚠️ Le gang sera dissous définitivement (chef uniquement)."),
    F("candidatures", "📨 Candidatures", "handlers.gangs:cmd_gang_candidatures", [], [IN]),
    F("role", "🎖️ Changer un poste", "handlers.gangs:cmd_gang_role",
      [P("member", "choice", "Quel membre ?", choices="gang_mates"),
       P("role", "choice", "Quel nouveau poste ?", choices=ROLES)], [IN]),
    F("exclure", "🚪 Exclure un membre", "handlers.gangs:cmd_gang_exclure",
      [P("member", "choice", "Quel membre exclure ?", choices="gang_mates")], [IN],
      confirm="Le membre sera exclu du gang."),
)
