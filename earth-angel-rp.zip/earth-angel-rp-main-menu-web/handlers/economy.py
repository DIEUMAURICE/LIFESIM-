# handlers/economy.py
from utils.swallow import swallowed
from utils.gamerules import faucet
import asyncio
import random
import aiosqlite
import logging
import html
from types import SimpleNamespace
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from utils.gametime import fmt_game_datetime
from database import (
    DB_PATH, get_user, update_balance, update_field, increment_field,
    get_top_rich, add_life_journal, get_user_company,
    transfer_money, debit_balance, db_connection
)
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, fmt_time, now, parse_amount, get_karma_multiplier
from utils.simulation import compute_condition_penalties
from utils.vip import (
    income_multiplier, coins_boost_multiplier, xp_boost_multiplier,
    tax_reduction, add_xp, add_coins,
)
from config import (
    DAILY_MIN, DAILY_MAX, WORK_COOLDOWN, DAILY_COOLDOWN, JOBS, SMALL_JOBS, DIPLOME_SALARY_BONUS,
    LOTTERY_TICKET_COST, LOTTERY_JACKPOT_BASE, CITIES, EVOLUTIVE_JOBS, SEASON_EFFECTS,
    WEALTH_TAX_BRACKETS, BANKS
)
from handlers.multiplayer import _bump_relation
from handlers.general import process_referral_progress
from handlers.missions import update_mission_progress
from handlers.bank import (
    cmd_banques, cmd_ouvrir, get_all_bank_accounts,
    cmd_depot, cmd_retrait, cmd_pret, cmd_rembourser, cmd_mescomptes
)

from config import WEALTH_TAX_MONTHLY_BRACKETS
from utils.helpers import escape_html

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Helper : multiplicateurs de ville
# ─────────────────────────────────────────────────────────────────────────────
async def get_city_multipliers(user_id: int) -> dict:
    u = await get_user(user_id)
    city = u.get("location", "Paris")
    return CITIES.get(city, {"realestate_mult": 1.0, "vehicle_mult": 1.0,
                             "salary_mult": 1.0, "market_mult": 1.0, "crime_mult": 1.0})

# Saisons : source unique -> utils.simulation (current_season, get_season_effect)

# ─────────────────────────────────────────────────────────────────────────────
# Bonus quotidien
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@cooldown("daily_last", DAILY_COOLDOWN,
          "⏳ Bonus quotidien déjà récupéré ! Prochain bonus dans <b>{remaining}</b> (temps réel : 24 h entre deux bonus).",
          real_time=True)
async def cmd_quotidien(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    penalties = compute_condition_penalties(u)

    karma_mult = get_karma_multiplier(u.get("karma", 0))
    level_bonus = 1 + (u.get("level", 1) - 1) * 0.01
    base = random.randint(DAILY_MIN, DAILY_MAX)
    vip_mult = income_multiplier(u)
    amount = int(base * karma_mult * level_bonus * penalties["passive_income_mult"] * vip_mult)
    lifestyle = penalties["score"]
    amount = await faucet("daily", amount)      # ⚙️ réglage du staff (0 % = coupé)

    await update_balance(user.id, amount)
    await update_field(user.id, "daily_last", now())
    # ⭐ Utilisation de add_xp (boost XP appliqué automatiquement)
    await add_xp(user.id, 30)

    await update_field(user.id, "hunger", min(100, u.get("hunger", 100) + 15))
    await update_field(user.id, "happiness", min(100, u.get("happiness", 100) + 3))
    if lifestyle < 35:
        await update_field(user.id, "stress", min(100, u.get("stress", 0) + 4))
    await add_life_journal(user.id, "revenu", f"Bonus quotidien encaissé : {fmt(amount)}.", severity="success")
    await process_referral_progress(user.id, context.bot)

    msg = f"🎁 <b>Bonus quotidien !</b>\n\n💰 Montant : <b>{escape_html(fmt(amount))}</b>\n"
    if vip_mult > 1:
        msg += f"⭐ Bonus abonnement : x{escape_html(vip_mult)}\n"
    if karma_mult > 1:
        bonus_pct = int((karma_mult - 1) * 100)
        msg += f"😇 Bonus karma (+{escape_html(bonus_pct)}%) : +{escape_html(fmt(amount - base))}\n"
    elif karma_mult < 1:
        malus_pct = int((1 - karma_mult) * 100)
        msg += f"😈 Malus karma (-{escape_html(malus_pct)}%) : {escape_html(fmt(base - amount))}\n"
    if penalties["passive_income_mult"] < 1:
        malus = int((1 - penalties["passive_income_mult"]) * 100)
        msg += f"🧬 Cohérence de vie : -{escape_html(malus)}% (état actuel)\n"
    if lifestyle < 35:
        msg += "⚠️ Ton mauvais état général te tend davantage.\n"
    msg += f"💵 Nouveau solde : {escape_html(fmt(u['balance'] + amount))}"
    await update.message.reply_text(msg, parse_mode="HTML")

# /travailler, /promotion, /metier : voir handlers/work.py (ré-exportés ici pour bot.py)
from handlers.work import cmd_travailler, cmd_promotion, cmd_metier  # noqa: E402

# ─────────────────────────────────────────────────────────────────────────────
# Payer un autre joueur
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_payer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not update.message.reply_to_message:
        await update.message.reply_text("❌ Réponds au message du joueur à payer.\nOuvre cette action depuis 🎮 Menu → 💼 Économie.")
        return

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 💼 Économie.")
        return

    amount = parse_amount(context.args[0], u["balance"])
    if not amount or amount <= 0:
        await update.message.reply_text("❌ Montant invalide.")
        return

    if amount > u["balance"]:
        await update.message.reply_text(f"❌ Fonds insuffisants ! Solde : {fmt(u['balance'])}")
        return

    target = update.message.reply_to_message.from_user
    if target.id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas te payer toi-même !")
        return

    tu = await get_user(target.id, target.username or "", target.full_name or "")
    if not tu.get("registered"):
        await update.message.reply_text("❌ Ce joueur n'a pas encore commencé sa partie.")
        return

    tax = int(amount * 0.01) if amount > 100_000 else 0

    ok = await transfer_money(user.id, target.id, amount, tax=tax)
    if not ok:
        await update.message.reply_text(f"❌ Fonds insuffisants ! Solde : {fmt(u['balance'])}")
        return

    await update_mission_progress(user.id, "pay", 1)
    if amount >= 100_000:
        await increment_field(user.id, "karma", 1)
    if tax > 0:
        await add_life_journal(user.id, "taxe", f"Taxe de 1% sur transfert de {fmt(amount)} : {fmt(tax)} prélevé.", severity="warning")

    msg = f"💸 <b>Transfert réussi !</b>\n\n"
    msg += f"👤 De : {escape_html(user.full_name)}\n"
    msg += f"👤 Vers : {escape_html(target.full_name)}\n"
    msg += f"💰 Montant : <b>{escape_html(fmt(amount))}</b>\n"
    if tax > 0:
        msg += f"💸 Taxe : -{escape_html(fmt(tax))}\n"
    msg += f"💵 Ton solde : {escape_html(fmt(u['balance'] - amount))}"
    await update.message.reply_text(msg, parse_mode="HTML")

# ─────────────────────────────────────────────────────────────────────────────
# Don
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@cooldown("don_cooldown", 60, "⏳ Tu donnes trop vite ! Patiente 1 minute.")
async def cmd_don(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Donner de l'argent à un autre joueur (don charitable entre joueurs)."""
    sender = update.effective_user
    u = await get_user(sender.id)

    target = None
    if update.message.reply_to_message:
        target = update.message.reply_to_message.from_user
        args = context.args
    elif context.args:
        mention = context.args[0]
        from utils.user_lookup import find_user       # ID d'abord, puis @pseudo
        row = await find_user(mention, registered_only=True)
        if row:
            class FakeUser:
                def __init__(self, uid, name):
                    self.id = uid
                    self.full_name = name
            target = FakeUser(row["user_id"], row["full_name"] or "Joueur")
        args = context.args[1:]
    else:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 💼 Économie."
            "_Faire un don à un autre joueur augmente ton karma et votre relation._"
        )
        return

    if not target or target.id == sender.id or getattr(target, "is_bot", False):
        await update.message.reply_text("❌ Destinataire invalide ou toi-même.")
        return

    target_row = await get_user(target.id)
    if not target_row or not target_row.get("registered"):
        await update.message.reply_text("❌ Ce joueur n'est pas inscrit au jeu.")
        return

    if not args:
        await update.message.reply_text("❌ Montant manquant.")
        return

    amount = parse_amount(args[0], u["balance"])
    if not amount or amount <= 0:
        await update.message.reply_text("❌ Montant invalide.")
        return
    if amount > u["balance"]:
        await update.message.reply_text(f"❌ Fonds insuffisants. Solde : {fmt(u['balance'])}")
        return

    tax = 0
    if amount > 50_000:
        tax = int(amount * 0.01)
        amount_after_tax = amount - tax
        ok = await transfer_money(sender.id, target.id, amount, tax=tax)
        if not ok:
            await update.message.reply_text(f"❌ Erreur de transfert, vérifie ton solde.")
            return
    else:
        ok = await transfer_money(sender.id, target.id, amount, tax=0)
        if not ok:
            await update.message.reply_text(f"❌ Erreur de transfert, vérifie ton solde.")
            return
        amount_after_tax = amount


    karma_gain = max(1, amount_after_tax // 5_000)
    karma_gain = min(50, karma_gain)
    await increment_field(sender.id, "karma", karma_gain)
    await increment_field(sender.id, "charity_given", amount)

    await _bump_relation(sender.id, target.id, 5, "bienfaiteur")

    msg = (
        f"🎁 <b>Don effectué !</b>\n\n"
        f"👤 De : {escape_html(sender.full_name)}\n"
        f"👤 À : {escape_html(target.full_name)}\n"
        f"💰 Montant : {escape_html(fmt(amount))}\n"
    )
    if tax:
        msg += f"💸 Taxe (1%) : -{escape_html(fmt(tax))}\n"
    msg += (
        f"🌟 Karma gagné : +{escape_html(karma_gain)}\n"
        f"💞 Relation avec {escape_html(target.full_name)} : +5\n\n"
        f"<i>La générosité renforce les liens.</i>"
    )
    await update.message.reply_text(msg, parse_mode="HTML")

    try:
        await context.bot.send_message(
            target.id,
            f"🎁 **Tu as reçu un don !**\n\n"
            f"De : {sender.full_name}\n"
            f"💰 Montant : {fmt(amount_after_tax)}"
        )
    except Exception:
        swallowed('handlers/economy.py')

# ─────────────────────────────────────────────────────────────────────────────
# Impôts
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_impots(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    async with db_connection() as db:
        async with db.execute("SELECT COALESCE(SUM(balance),0) FROM bank_accounts WHERE user_id=?", (user.id,)) as cur:
            bank_total = (await cur.fetchone())[0] or 0
    wealth = u["balance"] + bank_total
    rate = _get_impots_rate(wealth)
    daily = _daily_tax_for(wealth, u.get("vip_until"), u.get("premium_until"))

    lines = []
    prev = 0
    for limit, r in WEALTH_TAX_MONTHLY_BRACKETS:
        if limit == float("inf"):
            lines.append(f"• Au-delà de {fmt(prev)} → {r}%/mois")
        elif r == 0:
            lines.append(f"• Moins de {fmt(limit)} → exonéré")
        else:
            lines.append(f"• {fmt(prev)} à {fmt(limit)} → {r}%/mois")
        prev = limit

    await update.message.reply_text(
        f"🏛️ <b>Impôt sur la fortune</b>\n\n"
        f"💰 Fortune imposable (espèces + banque) : {fmt(wealth)}\n"
        f"📊 Ton taux : <b>{rate}%/mois</b>, prélevé chaque jour (1/30e)\n"
        f"🗓️ Soit environ <b>{fmt(daily)}/jour</b> pour ta fortune actuelle\n\n"
        f"📋 <b>Barème :</b>\n" + "\n".join(lines) + "\n\n"
        f"💡 <i>L'argent en banque est imposé comme les espèces.</i>\n"
        f"<i>Un abonnement VIP/Premium réduit ton taux.</i>",
        parse_mode="HTML"
    )

# ─────────────────────────────────────────────────────────────────────────────
# IMPÔTS QUOTIDIENS RENFORCÉS (appelé par le scheduler)
# ─────────────────────────────────────────────────────────────────────────────
TAX_BATCH_SIZE = 100
TAX_MIN_BALANCE = 100_000   # en dessous : taux 0 %, joueur ignoré


def _monthly_tax_rate(wealth: int):
    """Taux mensuel (%) du barème de l'impôt sur la fortune pour une richesse donnée,
    multiplié par le coefficient fixé par le gouvernement (Ministre de l'Économie / Président)."""
    from utils.state_settings import tax_factor
    base = WEALTH_TAX_MONTHLY_BRACKETS[-1][1]
    for limit, rate in WEALTH_TAX_MONTHLY_BRACKETS:
        if wealth < limit:
            base = rate
            break
    rate = base * tax_factor()
    return int(rate) if rate == int(rate) else round(rate, 2)


def _daily_tax_for(balance: int, vip_until, premium_until) -> int:
    """Montant d'impôt quotidien (0 si aucun) pour une fortune totale (wallet + banque)."""
    rate = _monthly_tax_rate(balance)
    if rate <= 0:
        return 0
    reduction = tax_reduction({"vip_until": vip_until, "premium_until": premium_until})
    rate = rate * (1 - reduction)
    return int(balance * rate / 100 / 30)


async def process_daily_tax():
    """
    Prélève l'impôt progressif quotidien sur la FORTUNE TOTALE (wallet + dépôts bancaires).

    Avant, seul le wallet était taxé : il suffisait de tout déposer en banque pour y échapper.
    L'impôt est prélevé sur le wallet d'abord, puis sur les comptes bancaires (le plus gros d'abord).

    Traité PAR LOTS de TAX_BATCH_SIZE joueurs (pagination par user_id) :
    chaque lot est une courte transaction, puis le verrou de la base est
    relâché pour que les joueurs actifs ne soient jamais bloqués longtemps.
    """
    from utils import state_settings
    await state_settings.refresh()          # coefficient réglé par le gouvernement
    last_id = 0
    taxed = 0
    while True:
        state_total = 0   # impôt collecté dans ce lot → budget de l'État (finance les factions)
        async with db_connection() as db:
            async with db.execute(
                "SELECT u.user_id, u.balance, u.vip_until, u.premium_until, "
                "       COALESCE((SELECT SUM(b.balance) FROM bank_accounts b WHERE b.user_id = u.user_id), 0) "
                "FROM users u "
                "WHERE u.registered=1 AND u.banned=0 AND u.user_id>? "
                "  AND u.balance + COALESCE((SELECT SUM(b.balance) FROM bank_accounts b "
                "                            WHERE b.user_id = u.user_id), 0) >= ? "
                "ORDER BY u.user_id LIMIT ?",
                (last_id, TAX_MIN_BALANCE, TAX_BATCH_SIZE),
            ) as cur:
                rows = await cur.fetchall()
            if not rows:
                break
            for uid, balance, vip_until, premium_until, bank_total in rows:
                tax = _daily_tax_for(balance + bank_total, vip_until, premium_until)
                if tax <= 0:
                    continue
                collected = 0   # montant RÉELLEMENT prélevé (et non le montant calculé) → c'est lui qui alimente l'État
                from_wallet = min(tax, balance)
                if from_wallet > 0:
                    cur_w = await db.execute(
                        "UPDATE users SET balance = balance - ? WHERE user_id = ? AND balance >= ?",
                        (from_wallet, uid, from_wallet),
                    )
                    if cur_w.rowcount == 1:
                        collected += from_wallet
                remaining = tax - collected
                if remaining > 0:
                    async with db.execute(
                        "SELECT id, balance FROM bank_accounts WHERE user_id=? AND balance>0 "
                        "ORDER BY balance DESC", (uid,),
                    ) as cur2:
                        accounts = await cur2.fetchall()
                    for acc_id, acc_balance in accounts:
                        if remaining <= 0:
                            break
                        take = min(remaining, acc_balance)
                        cur_b = await db.execute(
                            "UPDATE bank_accounts SET balance = balance - ? WHERE id = ? AND balance >= ?",
                            (take, acc_id, take),
                        )
                        if cur_b.rowcount == 1:
                            collected += take
                            remaining -= take
                if collected <= 0:
                    continue
                taxed += 1
                state_total += collected
                if collected > 1000:
                    await add_life_journal(
                        uid, "impots",
                        f"Impôt sur la fortune : {fmt(collected)} prélevé.",
                        severity="warning", db=db,
                    )
            if state_total:
                await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES ('_state', 0)")
                await db.execute("UPDATE faction_state SET budget=budget+? WHERE faction='_state'", (state_total,))
                from utils.treasury import _flow
                await _flow(db, "impot", "in", state_total)      # comptabilité du Trésor public
            await db.commit()
        last_id = rows[-1][0]
        await asyncio.sleep(0)   # laisse passer les autres tâches entre deux lots
    logger.info("💰 Impôts quotidiens prélevés sur %s joueurs (par lots).", taxed)

# ─────────────────────────────────────────────────────────────────────────────
# Classement des riches
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_richesse(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_for_update
    await show_for_update(update, 'richesse')


# ─────────────────────────────────────────────────────────────────────────────
# Dormir
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@cooldown("sleep_last", 43200, "😴 Tu as déjà dormi récemment. Attends un peu avant de te rendormir.")
async def cmd_dormir(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    penalties = compute_condition_penalties(u)

    hours = 8
    energy_gain = min(100 - u.get("energy", 100), int(hours * 10 * penalties["recovery_mult"]))
    stress_loss = min(u.get("stress", 0), int(hours * 5 * penalties["recovery_mult"]))
    hunger_cost = 6 if u.get("hunger", 100) < 25 else 0
    new_hunger = max(0, u.get("hunger", 100) - hunger_cost)
    rest_warning = "⚠️ Le repos est moins efficace quand ton état général est dégradé.\n\n" if penalties["recovery_mult"] < 1 else ""

    # Logement : sans domicile on dort dehors (repos réduit, santé et stress en pâtissent)
    from handlers.realestate import get_residence
    from config import HOMELESS_SLEEP_MULT
    residence = await get_residence(user.id)
    if residence is not None:                       # on dort chez soi (les sans-abri dorment où ils sont)
        from utils.location import is_exempt, presence_error
        if not await is_exempt(user.id):
            err = await presence_error(user.id, ("maison",))
            if err:
                await update.effective_message.reply_text(err, parse_mode="HTML")
                return
    if residence is None:
        energy_gain = int(energy_gain * HOMELESS_SLEEP_MULT)
        stress_loss = 0
        new_health = max(0, u.get("health", 100) - 3)
        await update_field(user.id, "health", new_health)
        await update_field(user.id, "stress", min(100, u.get("stress", 0) + 5))
        rest_warning += "🏚️ Tu as dormi dehors : repos réduit, -3% santé, +5% stress. 👉 Menu Investissements → Immobilier → Mon logement\n\n"
        stress_loss_shown = -5
    else:
        energy_gain = int(energy_gain * residence["sleep"])
        stress_loss = int(stress_loss * residence["sleep"])
        stress_loss_shown = stress_loss

    await update_field(user.id, "energy", u.get("energy", 100) + energy_gain)
    if residence is not None:
        await update_field(user.id, "stress", u.get("stress", 0) - stress_loss)
    await update_field(user.id, "hunger", new_hunger)
    await update_field(user.id, "sleep_last", now())
    await add_life_journal(user.id, "repos", f"Sommeil réparateur : énergie +{energy_gain}%, stress -{stress_loss}%.", severity="success")

    text_content = (
        f"😴 <b>Bonne nuit !</b>\n\n"
        f"⚡ Énergie : {escape_html(u.get('energy', 100))}% → {escape_html(u.get('energy', 100) + energy_gain)}%\n"
        f"😰 Stress : {escape_html(u.get('stress', 0))}% → {escape_html(max(0, min(100, u.get('stress', 0) - stress_loss_shown)))}%\n\n"
        f"🍽️ Faim : {escape_html(u.get('hunger', 100))}% → {escape_html(new_hunger)}%\n"
        f"{escape_html(rest_warning)}"
        f"<i>Reposé(e) et prêt(e) à conquérir le monde !</i>"
    )

    chat_id = update.effective_chat.id if update.effective_chat else user.id
    try:
        await context.bot.send_message(chat_id, text_content, parse_mode="HTML")
    except Exception:
        swallowed('handlers/economy.py')

# ─────────────────────────────────────────────────────────────────────────────
# Manger
# ─────────────────────────────────────────────────────────────────────────────
from handlers.life import cmd_manger  # noqa: E402,F401  (repas par catégorie et étoiles)

# ─────────────────────────────────────────────────────────────────────────────
# Loterie
# ─────────────────────────────────────────────────────────────────────────────
async def _loterie_view() -> tuple[str, InlineKeyboardMarkup]:
    """Écran de la loterie (jackpot, prix, prochain tirage) + boutons : un seul ticket à la fois."""
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM lottery_draws WHERE drawn_at != 0 ORDER BY draw_id DESC LIMIT 1") as cur:
            last_completed = await cur.fetchone()
        async with db.execute("SELECT * FROM lottery_draws WHERE drawn_at = 0 ORDER BY draw_id DESC LIMIT 1") as cur2:
            current_draw = await cur2.fetchone()
    if not current_draw:
        await _create_initial_lottery_draw()
        async with db_connection() as db:
            async with db.execute("SELECT * FROM lottery_draws WHERE drawn_at = 0 ORDER BY draw_id DESC LIMIT 1") as cur:
                current_draw = await cur.fetchone()
    current_draw = dict(current_draw) if current_draw else {"jackpot": LOTTERY_JACKPOT_BASE}
    if last_completed and last_completed["drawn_at"]:
        last_time = last_completed["drawn_at"]
        next_time = max(now(), last_time + 86400)
    else:
        next_time = now() + 3600
    remaining = max(0, next_time - now())
    if remaining < 60:
        remaining_str = f"{remaining} secondes"
    elif remaining < 3600:
        remaining_str = f"{remaining // 60} minutes"
    elif remaining < 86400:
        remaining_str = f"{remaining // 3600} heures"
    else:
        remaining_str = f"{remaining // 86400} jours"
    next_date = fmt_game_datetime(next_time)
    text = (
        f"🎫 **Loterie Nationale**\n\n"
        f"💰 Jackpot actuel : **{fmt(current_draw['jackpot'])}**\n"
        f"🎟️ Prix d'un ticket : {fmt(LOTTERY_TICKET_COST)}\n"
        f"⏳ Prochain tirage dans : **{remaining_str}**\n"
        f"📅 ({next_date})\n\n"
        f"🎫 Max {LOTTERY_MAX_TICKETS} tickets par tirage · le gagnant est tiré au sort et tout le monde est notifié."
    )
    return text, _loterie_kb()


def _loterie_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🎫 Acheter un ticket", callback_data="lot_buy")],
        [InlineKeyboardButton("🎟️ Mes tickets", callback_data="lot_mine"),
         InlineKeyboardButton("🎰 Dernier tirage", callback_data="lot_last")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="hub:eco:0")],
    ])


@require_registered
async def cmd_loterie(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text, kb = await _loterie_view()
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=kb)


@require_registered
async def cmd_acheterticket(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ok, text = await buy_ticket(update.effective_user.id)
    await update.message.reply_text(text, parse_mode="HTML")

async def _create_initial_lottery_draw():
    async with db_connection() as db:
        await db.execute("INSERT INTO lottery_draws (draw_id, jackpot, drawn_at) VALUES (1, ?, 0)", (LOTTERY_JACKPOT_BASE,))
        await db.commit()

# ─────────────────────────────────────────────────────────────────────────────
# Commandes supplémentaires pour la loterie
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_mestickets(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        async with db.execute(
            "SELECT numbers, purchased_at FROM lottery_tickets WHERE user_id=? ORDER BY purchased_at DESC",
            (user.id,)
        ) as cur:
            tickets = await cur.fetchall()
    if not tickets:
        await update.message.reply_text("📭 Tu n'as aucun ticket en attente.")
        return
    text = "🎫 <b>Tes tickets en attente</b>\n\n"
    for t in tickets[:10]:
        ts = fmt_time(now() - t[1]) if t[1] else "récent"
        text += f"🔢 {escape_html(t[0])} — acheté il y a {escape_html(ts)}\n"
    if len(tickets) > 10:
        text += f"<i>... et {escape_html(len(tickets)-10)} autres</i>"
    await update.message.reply_text(text, parse_mode="HTML")

@require_registered
async def cmd_tirage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM lottery_draws WHERE drawn_at != 0 ORDER BY draw_id DESC LIMIT 1") as cur:
            last = await cur.fetchone()
    if not last:
        await update.message.reply_text("📭 Aucun tirage n'a encore eu lieu.")
        return
    nums = last["winning_numbers"] or "?"
    last_ts = last["drawn_at"]
    if last_ts > now() or last_ts < now() - 86400 * 7:
        last_date = "date inconnue (correction automatique)"
        next_time = now() + 86400
    else:
        last_date = fmt_game_datetime(last_ts)
        next_time = max(now(), last_ts + 86400)
    next_date = fmt_game_datetime(next_time)
    text = (
        f"🎰 <b>Dernier tirage</b>\n\n"
        f"🔢 Numéros gagnants : <b>{escape_html(nums)}</b>\n"
        f"💰 Jackpot : {escape_html(fmt(last['jackpot']))}\n"
        f"📅 Tirage effectué le {escape_html(last_date)}\n\n"
        f"⏳ Prochain tirage : <b>{escape_html(next_date)}</b>"
    )
    await update.message.reply_text(text, parse_mode="HTML")

# ─────────────────────────────────────────────────────────────────────────────
# Maintenance (appelée par le scheduler)
# ─────────────────────────────────────────────────────────────────────────────


def _get_impots_rate(balance: int) -> int:
    """Taux mensuel (%) affiché aux joueurs — même barème que le prélèvement réel."""
    return _monthly_tax_rate(balance)


# ═══════════════════════════════════════════════════════════════════
#                 /compte — MENU PRINCIPAL
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_compte(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche le menu économie avec des boutons pour chaque action."""
    user = update.effective_user
    u = await get_user(user.id)

    async with db_connection() as db:
        async with db.execute("SELECT SUM(balance), SUM(loan) FROM bank_accounts WHERE user_id=?", (user.id,)) as cur:
            row = await cur.fetchone()
    bank_total = row[0] or 0
    loan_total = row[1] or 0

    text = (
        f"💰 **Économie**\n\n"
        f"💵 Espèces : <b>{fmt(u['balance'])}</b>\n"
        f"🏦 Banque : {fmt(bank_total)}\n"
        f"💳 Prêts actifs : -{fmt(loan_total)}\n"
        f"📊 Total net : <b>{fmt(u['balance'] + bank_total - loan_total)}</b>\n\n"
        f"<i>Choisis une action :</i>"
    )

    keyboard = [
        [InlineKeyboardButton("💰 Travailler", callback_data="eco_travailler")],
        [InlineKeyboardButton("🎰 Quotidien", callback_data="eco_quotidien")],
        [InlineKeyboardButton("💼 Métier", callback_data="eco_metier")],
        [InlineKeyboardButton("📈 Promotion", callback_data="eco_promotion")],
        [InlineKeyboardButton("🏦 Banques", callback_data="eco_banques")],
        [InlineKeyboardButton("💰 Dépôt", callback_data="eco_depot")],
        [InlineKeyboardButton("💳 Retrait", callback_data="eco_retrait")],
        [InlineKeyboardButton("💳 Prêt", callback_data="eco_pret")],
        [InlineKeyboardButton("💳 Rembourser", callback_data="eco_rembourser")],
        [InlineKeyboardButton("🏦 Mes comptes", callback_data="eco_mescomptes")],
        [InlineKeyboardButton("💸 Payer", callback_data="eco_payer")],
        [InlineKeyboardButton("🎁 Don", callback_data="eco_don")],
        [InlineKeyboardButton("📊 Impôts", callback_data="eco_impots")],
        [InlineKeyboardButton("🏆 Richesse", callback_data="eco_richesse")],
        [InlineKeyboardButton("🎟️ Loterie", callback_data="eco_loterie")],
        [InlineKeyboardButton("⬅️ Menu principal", callback_data="menu_main")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)


# ═══════════════════════════════════════════════════════════════════
#                    SOUS-MENUS
# ═══════════════════════════════════════════════════════════════════

async def show_metier_menu(query, user_id: int, page: int = 1):
    """Affiche les métiers disponibles sous forme de boutons paginés."""
    u = await get_user(user_id)
    current_dip = u.get("diplome", "")
    dip_order = ["", "Brevet", "Bac", "BTS", "Licence", "Master", "MBA", "Doctorat", "Habilitation"]
    dip_rank = dip_order.index(current_dip) if current_dip in dip_order else 0

    # Seuls les PETITS MÉTIERS freelance se choisissent ici. Les métiers qualifiés
    # (médecin, avocat, ingénieur, PDG…) s'exercent désormais en entreprise ou en faction.
    all_jobs = []
    for job, data in SMALL_JOBS.items():
        need = data.get("need") or ""
        need_rank = dip_order.index(need) if need in dip_order else 0
        unlocked = dip_rank >= need_rank
        all_jobs.append((job, data, unlocked))

    all_jobs.sort(key=lambda x: (not x[2], x[0]))

    per_page = 8
    total_pages = (len(all_jobs) + per_page - 1) // per_page
    page = max(1, min(page, total_pages))
    start = (page - 1) * per_page
    end = start + per_page
    page_jobs = all_jobs[start:end]

    text = (f"🛠️ <b>Petits métiers</b> (page {page}/{total_pages})\n\n"
            f"Actuel : {u.get('job') or 'Aucun'}\n"
            f"<i>Métier autonome, payé tout de suite via un mini-jeu. "
            f"Les métiers qualifiés se trouvent en entreprise (menu Entreprises) ou en faction (menu Carrière).</i>\n\n")
    keyboard = []
    for job, data, unlocked in page_jobs:
        status = "✅" if unlocked else "🔒"
        dip = f" · 🎓 {data['need']}" if data.get("need") else ""
        text += f"{status} {data.get('emoji', '🛠️')} {job} — {fmt(data['min'])}-{fmt(data['max'])}{dip}\n"
        if unlocked:
            keyboard.append([InlineKeyboardButton(f"💼 {job}", callback_data=f"metier_select_{job}")])

    nav = []
    if page > 1:
        nav.append(InlineKeyboardButton("◀️", callback_data=f"metier_page_{page-1}"))
    nav.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav.append(InlineKeyboardButton("▶️", callback_data=f"metier_page_{page+1}"))
    if nav:
        keyboard.append(nav)
    if u.get("job"):
        keyboard.append([InlineKeyboardButton("🛑 Arrêter mon métier", callback_data="metier_quit")])
    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="metier_home")])
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_banques_menu(query, user_id: int):
    """Affiche les banques avec boutons pour ouvrir un compte."""
    from handlers.bank import get_all_bank_accounts, fmt_rate
    accounts = await get_all_bank_accounts(user_id)
    text = "🏦 **Banques**\n\n"
    keyboard = []
    for bank in BANKS:
        existing = any(acc["bank_name"] == bank["name"] for acc in accounts)
        status = "✅" if existing else "🔓"
        text += f"{status} {bank['name']} — intérêts {fmt_rate(bank['interest'])}\n"
        if not existing:
            keyboard.append([InlineKeyboardButton(f"🏦 Ouvrir {bank['name']}", callback_data=f"banque_ouvrir_{bank['name']}")])
    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="eco_retour")])
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_payer_menu(query, user_id: int):
    """Affiche les montants pour payer."""
    text = "💸 <b>Payer</b>\n\nChoisis un montant :"
    keyboard = [
        [InlineKeyboardButton("💰 1 000 €A", callback_data="payer_montant_1000")],
        [InlineKeyboardButton("💰 5 000 €A", callback_data="payer_montant_5000")],
        [InlineKeyboardButton("💰 10 000 €A", callback_data="payer_montant_10000")],
        [InlineKeyboardButton("💰 50 000 €A", callback_data="payer_montant_50000")],
        [InlineKeyboardButton("💰 100 000 €A", callback_data="payer_montant_100000")],
        [InlineKeyboardButton("💰 Autre montant", callback_data="payer_autre")],
        [InlineKeyboardButton("❌ Annuler", callback_data="payer_cancel")],
    ]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_don_menu(query, user_id: int):
    """Affiche les montants pour un don."""
    text = "🎁 <b>Don</b>\n\nChoisis un montant :"
    keyboard = [
        [InlineKeyboardButton("💰 500 €A", callback_data="don_montant_500")],
        [InlineKeyboardButton("💰 1 000 €A", callback_data="don_montant_1000")],
        [InlineKeyboardButton("💰 5 000 €A", callback_data="don_montant_5000")],
        [InlineKeyboardButton("💰 10 000 €A", callback_data="don_montant_10000")],
        [InlineKeyboardButton("🎁 Autre montant", callback_data="don_autre")],
        [InlineKeyboardButton("❌ Annuler", callback_data="don_cancel")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="eco_retour")],
    ]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_loterie_menu(query, user_id: int):
    """Affiche l'écran de la loterie (achat d'un ticket à la fois, comme depuis le menu Économie)."""
    text, kb = await _loterie_view()
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=kb)


# ═══════════════════════════════════════════════════════════════════
#              SOUS-MENUS : DÉPÔT, RETRAIT, PRÊT, REMBOURSEMENT
# ═══════════════════════════════════════════════════════════════════

_NO_ACCOUNT_KB = InlineKeyboardMarkup([
    [InlineKeyboardButton("🏦 Ouvrir un compte", callback_data="eco_banques")],
    [InlineKeyboardButton("⬅️ Retour", callback_data="eco_retour")],
])
_BACK_KB = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="eco_retour")]])


async def show_depot_menu(query, user_id: int):
    """Affiche les montants pour un dépôt."""
    accounts = await get_all_bank_accounts(user_id)
    if not accounts:
        await query.edit_message_text(
            "❌ Tu n'as aucun compte bancaire.\n"
            "Ouvre-en un pour pouvoir déposer, retirer ou emprunter.",
            parse_mode="HTML", reply_markup=_NO_ACCOUNT_KB
        )
        return

    text = "💰 <b>Dépôt</b>\n\nChoisis un montant :"
    keyboard = [
        [InlineKeyboardButton("💰 1 000 €A", callback_data="depot_montant_1000")],
        [InlineKeyboardButton("💰 5 000 €A", callback_data="depot_montant_5000")],
        [InlineKeyboardButton("💰 10 000 €A", callback_data="depot_montant_10000")],
        [InlineKeyboardButton("💰 50 000 €A", callback_data="depot_montant_50000")],
        [InlineKeyboardButton("💰 100 000 €A", callback_data="depot_montant_100000")],
        [InlineKeyboardButton("💰 Autre montant", callback_data="depot_autre")],
        [InlineKeyboardButton("❌ Annuler", callback_data="depot_cancel")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="eco_retour")],
    ]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_retrait_menu(query, user_id: int):
    """Affiche les montants pour un retrait."""
    accounts = await get_all_bank_accounts(user_id)
    if not accounts:
        await query.edit_message_text(
            "❌ Tu n'as aucun compte bancaire.\n"
            "Ouvre-en un pour pouvoir déposer, retirer ou emprunter.",
            parse_mode="HTML", reply_markup=_NO_ACCOUNT_KB
        )
        return

    text = "💳 <b>Retrait</b>\n\nChoisis un montant :"
    keyboard = [
        [InlineKeyboardButton("💰 1 000 €A", callback_data="retrait_montant_1000")],
        [InlineKeyboardButton("💰 5 000 €A", callback_data="retrait_montant_5000")],
        [InlineKeyboardButton("💰 10 000 €A", callback_data="retrait_montant_10000")],
        [InlineKeyboardButton("💰 50 000 €A", callback_data="retrait_montant_50000")],
        [InlineKeyboardButton("💰 100 000 €A", callback_data="retrait_montant_100000")],
        [InlineKeyboardButton("💰 Autre montant", callback_data="retrait_autre")],
        [InlineKeyboardButton("❌ Annuler", callback_data="retrait_cancel")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="eco_retour")],
    ]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_pret_menu(query, user_id: int):
    """Affiche les montants pour un prêt."""
    accounts = await get_all_bank_accounts(user_id)
    if not accounts:
        await query.edit_message_text(
            "❌ Tu n'as aucun compte bancaire.\n"
            "Ouvre-en un pour pouvoir déposer, retirer ou emprunter.",
            parse_mode="HTML", reply_markup=_NO_ACCOUNT_KB
        )
        return

    for acc in accounts:
        if acc.get("loan", 0) > 0:
            await query.edit_message_text(
                f"❌ Tu as déjà un prêt actif à la {escape_html(acc['bank_name'])}.\n"
                f"💰 Reste dû : {escape_html(fmt(acc['loan']))}\n"
                f"Ouvre le 🎮 Menu principal pour le rembourser.",
                parse_mode="HTML", reply_markup=_BACK_KB
            )
            return

    text = "💳 <b>Prêt</b>\n\nChoisis un montant :"
    keyboard = [
        [InlineKeyboardButton("💰 5 000 €A", callback_data="pret_montant_5000")],
        [InlineKeyboardButton("💰 10 000 €A", callback_data="pret_montant_10000")],
        [InlineKeyboardButton("💰 50 000 €A", callback_data="pret_montant_50000")],
        [InlineKeyboardButton("💰 100 000 €A", callback_data="pret_montant_100000")],
        [InlineKeyboardButton("💰 Autre montant", callback_data="pret_autre")],
        [InlineKeyboardButton("❌ Annuler", callback_data="pret_cancel")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="eco_retour")],
    ]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_rembourser_menu(query, user_id: int):
    """Affiche le menu de remboursement."""
    accounts = await get_all_bank_accounts(user_id)
    active_loans = [a for a in accounts if a.get("loan", 0) > 0]

    if not active_loans:
        await query.edit_message_text(
            "✅ Tu n'as aucun prêt actif.",
            parse_mode="HTML", reply_markup=_BACK_KB
        )
        return

    text = "💳 <b>Remboursement</b>\n\n"
    text += "Choisis une banque :\n\n"
    keyboard = []
    for acc in active_loans:
        text += f"🏛️ {escape_html(acc['bank_name'])} : {escape_html(fmt(acc['loan']))} restant\n"
        keyboard.append([InlineKeyboardButton(
            f"Rembourser {acc['bank_name']}",
            callback_data=f"rembourser_banque_{acc['bank_name']}"
        )])

    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="eco_retour")])
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_mescomptes_menu(query, user_id: int):
    """Affiche tous les comptes bancaires."""
    accounts = await get_all_bank_accounts(user_id)

    if not accounts:
        await query.edit_message_text(
            "🏦 Tu n'as aucun compte bancaire.\n"
            "Ouvre-en un depuis le 🎮 Menu principal.",
            parse_mode="HTML", reply_markup=_NO_ACCOUNT_KB
        )
        return

    text = "🏦 <b>Tes comptes bancaires</b>\n\n"
    total_balance = 0
    total_loan = 0

    for acc in accounts:
        text += f"🏛️ <b>{escape_html(acc['bank_name'])}</b>\n"
        text += f"  💰 Solde : {escape_html(fmt(acc['balance']))}\n"
        if acc.get("loan", 0) > 0:
            text += f"  💳 Prêt : {escape_html(fmt(acc['loan']))}\n"
        text += "\n"
        total_balance += acc['balance']
        total_loan += acc.get("loan", 0)

    text += f"━━━━━━━━━━━━\n"
    text += f"💰 Total banque : {escape_html(fmt(total_balance))}\n"
    text += f"💳 Total prêts : {escape_html(fmt(total_loan))}\n"

    keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="eco_retour")]]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ═══════════════════════════════════════════════════════════════════
#                    CALLBACK PRINCIPAL
# ═══════════════════════════════════════════════════════════════════
async def economy_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    action = query.data
    user_id = query.from_user.id

    # Navigation sous-menus
    if action == "eco_metier":
        await show_metier_menu(query, user_id, 1)
        return
    if action == "eco_banques":
        await show_banques_menu(query, user_id)
        return
    if action == "eco_payer":
        await show_payer_menu(query, user_id)
        return
    if action == "eco_don":
        await show_don_menu(query, user_id)
        return
    if action == "eco_loterie":
        await show_loterie_menu(query, user_id)
        return
    if action == "eco_depot":
        await show_depot_menu(query, user_id)
        return
    if action == "eco_retrait":
        await show_retrait_menu(query, user_id)
        return
    if action == "eco_pret":
        await show_pret_menu(query, user_id)
        return
    if action == "eco_rembourser":
        await show_rembourser_menu(query, user_id)
        return
    if action == "eco_mescomptes":
        await show_mescomptes_menu(query, user_id)
        return
    if action == "eco_retour":
        from handlers.hub import open_zone
        await open_zone(query, "economy")
        return
    # ── Mon métier : retour, travailler, arrêter, quitter l'employeur ──
    if action in ("metier_duty_on", "metier_duty_off"):
        from handlers.work import toggle_duty
        msg = await toggle_duty(user_id, action == "metier_duty_on")
        await query.edit_message_text(msg, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("⬅️ Mon métier", callback_data="metier_home")]]))
        return
    if action in ("metier_home", "metier_work", "metier_big", "metier_quit", "metier_quit_ok", "metier_leave", "metier_leave_ok"):
        from handlers.work import build_metier_view, quit_small_job, get_workplace, cmd_travailler, cmd_grande_commande
        back_home = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Mon métier", callback_data="metier_home")]])
        if action == "metier_home":
            text, markup = await build_metier_view(user_id)
            await query.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
        elif action == "metier_work":
            from utils.input_flow import call_cmd
            await call_cmd(query, context, cmd_travailler, [])
        elif action == "metier_big":
            from utils.input_flow import call_cmd
            await call_cmd(query, context, cmd_grande_commande, [])
        elif action == "metier_quit":
            u = await get_user(user_id)
            if not u.get("job"):
                await query.edit_message_text("🛠️ Tu n'as pas de métier à arrêter.", reply_markup=back_home)
                return
            await query.edit_message_text(
                f"🛑 <b>Arrêter ton métier ({u['job']}) ?</b>\n\nTu pourras en choisir un autre quand tu veux.",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("✅ Oui, arrêter", callback_data="metier_quit_ok"),
                    InlineKeyboardButton("⬅️ Non", callback_data="metier_home")]]))
        elif action == "metier_quit_ok":
            old = await quit_small_job(user_id)
            msg = f"✅ Tu as arrêté ton métier ({old})." if old else "🛠️ Tu n'avais pas de métier."
            await query.edit_message_text(msg, reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🛠️ Choisir un autre métier", callback_data="eco_metier")],
                [InlineKeyboardButton("🎮 Menu principal", callback_data="hub:home")]]))
        elif action == "metier_leave":
            wp = await get_workplace(user_id)
            if not wp:
                await query.edit_message_text("🏢 Tu n'as ni entreprise ni faction.", reply_markup=back_home)
                return
            await query.edit_message_text(
                f"🚪 <b>Quitter {wp['label']} ?</b>\n\nTu perds ton poste et ton salaire là-bas.",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("✅ Oui, quitter", callback_data="metier_leave_ok"),
                    InlineKeyboardButton("⬅️ Non", callback_data="metier_home")]]))
        else:   # metier_leave_ok
            from utils.input_flow import call_cmd
            wp = await get_workplace(user_id)
            if not wp:
                await query.edit_message_text("🏢 Tu n'as ni entreprise ni faction.", reply_markup=back_home)
                return
            if wp["kind"] == "faction":
                from handlers.factions import cmd_faction_quitter as leave_cmd
            else:
                from handlers.companies import cmd_demissionner as leave_cmd
            await call_cmd(query, context, leave_cmd, [])
        return

    # Pagination métiers
    if action.startswith("metier_page_"):
        page = int(action.split("_")[-1])
        await show_metier_menu(query, user_id, page)
        return

    # Changement de métier
    if action.startswith("metier_select_"):
        job_name = action.replace("metier_select_", "")
        u = await get_user(user_id)
        if u.get("job") == job_name:
            await query.edit_message_text(f"❌ Tu es déjà {job_name}.")
            return
        job_data = SMALL_JOBS.get(job_name)
        if not job_data:
            await query.edit_message_text("❌ Ce n'est pas un petit métier : les métiers qualifiés "
                                          "s'exercent en entreprise (menu Entreprises) ou en faction (menu Carrière).")
            return
        need = job_data.get("need") or ""
        if need:
            dip_order = ["", "Brevet", "Bac", "BTS", "Licence", "Master", "MBA", "Doctorat", "Habilitation"]
            current_dip = u.get("diplome", "")
            current_rank = dip_order.index(current_dip) if current_dip in dip_order else 0
            need_rank = dip_order.index(need) if need in dip_order else 0
            if current_rank < need_rank:
                await query.edit_message_text(f"🔒 Ce métier nécessite : <b>{need}</b>", parse_mode="HTML")
                return
        await update_field(user_id, "job", job_name)
        await query.edit_message_text(
            f"✅ Petit métier : <b>{job_name}</b> !\n👉 Menu Économie → Travailler pour lancer ta première mission.",
            parse_mode="HTML")
        return

    # Ouverture de compte bancaire
    if action.startswith("banque_ouvrir_"):
        bank_name = action.replace("banque_ouvrir_", "")
        fake_user = SimpleNamespace(
            id=user_id,
            username=(await get_user(user_id)).get('username', ''),
            full_name=(await get_user(user_id)).get('full_name', 'Joueur'),
            first_name=(await get_user(user_id)).get('full_name', 'Joueur'),
            last_name='',
            name=(await get_user(user_id)).get('full_name', 'Joueur'),
        )
        fake_update = SimpleNamespace(
            effective_user=fake_user,
            message=query.message,
            callback_query=None,
            effective_message=query.message,
        )
        fake_context = SimpleNamespace(args=[bank_name])
        await cmd_ouvrir(fake_update, fake_context)
        return

    # ── Saisies guidées : dépôt, retrait, paiement, don ─────────────
    #    (remplace /depot /retrait /payer /don — voir economy_flows.py)
    for _pfx in ("depot", "retrait", "payer", "don"):
        if action.startswith(f"{_pfx}_montant_"):
            from handlers.economy_flows import start_target
            await start_target(query, context, _pfx, int(action.rsplit("_", 1)[1]))
            return
        if action == f"{_pfx}_autre":
            from handlers.economy_flows import start_amount
            wallet = (await get_user(user_id) or {}).get("balance") if _pfx != "retrait" else None
            await start_amount(query, context, _pfx, wallet)
            return
        if action == f"{_pfx}_cancel":
            from utils.input_flow import clear
            clear(context)
            await query.edit_message_text(
                "❌ Action annulée.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("⬅️ Retour", callback_data="eco_retour")]]),
            )
            return

    # Prêt
    if action.startswith("pret_montant_"):
        amount = int(action.replace("pret_montant_", ""))
        context.user_data['pending_loan'] = amount
        context.user_data['awaiting_loan_bank'] = True
        await query.edit_message_text(
            f"💳 <b>Prêt de {escape_html(fmt(amount))}</b>\n\n"
            f"Réponds avec le nom de la banque où emprunter.\n"
            f"<i>(ou appuie sur Annuler)</i>",
            parse_mode="HTML"
        )
        return

    if action == "pret_autre":
        await query.edit_message_text(
            "💳 <b>Prêt</b>\n\n"
            "Envoie le montant sous forme de message (ex: 5000).\n"
            "Puis je te demanderai la banque.",
            parse_mode="HTML"
        )
        context.user_data['awaiting_loan_amount'] = True
        return

    if action == "pret_cancel":
        context.user_data.pop('pending_loan', None)
        context.user_data.pop('awaiting_loan_bank', None)
        context.user_data.pop('awaiting_loan_amount', None)
        await query.edit_message_text("❌ Prêt annulé.")
        return

    # Remboursement
    if action.startswith("rembourser_banque_"):
        bank_name = action.replace("rembourser_banque_", "")
        context.user_data['pending_repayment_bank'] = bank_name
        await query.edit_message_text(
            f"💳 <b>Remboursement à la {escape_html(bank_name)}</b>\n\n"
            f"Envoie le montant à rembourser (ex: 5000).\n"
            f"<i>(ou appuie sur Annuler)</i>",
            parse_mode="HTML"
        )
        context.user_data['awaiting_repayment_amount'] = True
        return

    # Créer un faux update pour les commandes qui nécessitent un Update
    fake_user = SimpleNamespace(
        id=user_id,
        username=(await get_user(user_id)).get('username', ''),
        full_name=(await get_user(user_id)).get('full_name', 'Joueur'),
        first_name=(await get_user(user_id)).get('full_name', 'Joueur'),
        last_name='',
        name=(await get_user(user_id)).get('full_name', 'Joueur'),
    )
    fake_update = SimpleNamespace(
        effective_user=fake_user,
        message=query.message,
        callback_query=None,
        effective_message=query.message,
    )

    if action == "eco_travailler":
        await cmd_travailler(fake_update, context)
    elif action == "eco_quotidien":
        await cmd_quotidien(fake_update, context)
    elif action == "eco_promotion":
        await cmd_promotion(fake_update, context)
    elif action == "eco_impots":
        await cmd_impots(fake_update, context)
    elif action == "eco_richesse":
        await cmd_richesse(fake_update, context)
    else:
        await query.edit_message_text("❌ Action inconnue.")


# ─── Gestion des saisies pour paiements/dons ───
async def resolve_target(target: str) -> int | None:
    """Résout un ID ou un @username en ID utilisateur (ID d'abord)."""
    from utils.user_lookup import resolve_id
    return await resolve_id(target)


# ══════════════════════════════════════════════════════════════════════
#  LOTERIE — achat et tirage au sort (ex handlers/lottery.py)
# ══════════════════════════════════════════════════════════════════════
from config import LOTTERY_MAX_TICKETS, LOTTERY_MIN_PLAYERS
from utils.notify import notify


async def _open_draw(db) -> dict:
    async with db.execute(
            "SELECT draw_id, jackpot FROM lottery_draws WHERE drawn_at=0 ORDER BY draw_id DESC LIMIT 1") as cur:
        row = await cur.fetchone()
    if row:
        return {"draw_id": row[0], "jackpot": row[1]}
    cur = await db.execute("INSERT INTO lottery_draws (jackpot, drawn_at) VALUES (?,0)", (LOTTERY_JACKPOT_BASE,))
    return {"draw_id": cur.lastrowid, "jackpot": LOTTERY_JACKPOT_BASE}


async def buy_ticket(user_id: int) -> tuple[bool, str]:
    """Achète un ticket du tirage en cours. Retourne (succès, message)."""
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            draw = await _open_draw(db)
            async with db.execute("SELECT COUNT(*) FROM lottery_tickets WHERE draw_id=? AND user_id=?",
                                  (draw["draw_id"], user_id)) as cur:
                mine = (await cur.fetchone())[0]
            if mine >= LOTTERY_MAX_TICKETS:
                await db.rollback()
                return False, f"❌ Maximum {LOTTERY_MAX_TICKETS} tickets par tirage."
            debit = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
                (LOTTERY_TICKET_COST, LOTTERY_TICKET_COST, user_id, LOTTERY_TICKET_COST))
            if debit.rowcount != 1:
                await db.rollback()
                return False, f"❌ Ticket : {fmt(LOTTERY_TICKET_COST)}. Fonds insuffisants."
            nums = "-".join(map(str, sorted(random.sample(range(1, 50), 5))))
            cur = await db.execute(
                "INSERT INTO lottery_tickets (user_id, draw_id, numbers, purchased_at) VALUES (?,?,?,?)",
                (user_id, draw["draw_id"], nums, now()))
            await db.execute("UPDATE lottery_draws SET jackpot=jackpot+? WHERE draw_id=?",
                             (LOTTERY_TICKET_COST // 2, draw["draw_id"]))
            await db.commit()
            ticket_id = cur.lastrowid
        except Exception:
            await db.rollback()
            raise
    return True, (f"🎫 <b>Ticket n°{ticket_id}</b> acheté ({mine + 1}/{LOTTERY_MAX_TICKETS})\n"
                  f"🔢 {nums}\n💰 {fmt(LOTTERY_TICKET_COST)}\n"
                  f"<i>Le gagnant est tiré au sort : tu seras notifié(e) du résultat.</i>")


async def process_lottery_draw() -> dict:
    """Tirage planifié (1×/jour de jeu). Retourne un résumé (utile aux tests)."""
    result = {"status": "none", "winner": None, "prize": 0, "participants": 0}
    notes: list[tuple[int, str, str, str]] = []
    winner_id = prize = 0
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            draw = await _open_draw(db)
            async with db.execute("SELECT ticket_id, user_id, numbers FROM lottery_tickets WHERE draw_id=?",
                                  (draw["draw_id"],)) as cur:
                tickets = [dict(r) for r in await cur.fetchall()]
            players = sorted({t["user_id"] for t in tickets})
            result["participants"] = len(players)
            if len(players) < LOTTERY_MIN_PLAYERS:
                for uid in players:
                    notes.append((uid, "🎰 Tirage reporté",
                                  "Pas assez de participants pour tirer le gagnant : ton ticket reste valable "
                                  "pour le prochain tirage.", "info"))
                await db.commit()
                result["status"] = "postponed" if players else "none"
            else:
                win = random.choice(tickets)
                winner_id, prize = win["user_id"], draw["jackpot"]
                async with db.execute("SELECT full_name FROM users WHERE user_id=?", (winner_id,)) as cur:
                    row = await cur.fetchone()
                name = (row["full_name"] if row else None) or "Un joueur"
                await db.execute(
                    "UPDATE users SET balance=balance+?, total_earned=total_earned+?, lottery_wins=lottery_wins+1 "
                    "WHERE user_id=?", (prize, prize, winner_id))
                await db.execute(
                    "UPDATE lottery_draws SET winning_numbers=?, winner_id=?, drawn_at=? WHERE draw_id=?",
                    (win["numbers"], winner_id, now(), draw["draw_id"]))
                await db.execute("DELETE FROM lottery_tickets WHERE draw_id=?", (draw["draw_id"],))
                await db.execute("INSERT INTO lottery_draws (jackpot, drawn_at) VALUES (?,0)",
                                 (LOTTERY_JACKPOT_BASE,))
                for uid in players:
                    if uid == winner_id:
                        notes.append((uid, "🎰 JACKPOT !",
                                      f"Ton ticket n°{win['ticket_id']} est tiré au sort : tu gagnes "
                                      f"<b>{fmt(prize)}</b> !", "achievement"))
                    else:
                        notes.append((uid, "🎰 Résultat de la loterie",
                                      f"Le gagnant est <b>{name}</b> (ticket n°{win['ticket_id']}) : "
                                      f"{fmt(prize)}. Pas de chance cette fois ! Tes tickets de ce tirage "
                                      f"sont supprimés.", "info"))
                await db.commit()
                result.update(status="drawn", winner=winner_id, prize=prize)
        except Exception:
            await db.rollback()
            raise
    if winner_id:
        try:
            from utils.vip import add_xp
            await add_xp(winner_id, 500)
        except Exception:
            logger.exception("XP loterie échouée pour %s", winner_id)
    for uid, title, body, kind in notes:
        await notify(uid, title, body, kind)
    return result


async def lottery_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Boutons de la loterie : lot_buy · lot_mine · lot_last."""
    q = update.callback_query
    await q.answer()
    if q.data == "lot_buy":
        ok, text = await buy_ticket(q.from_user.id)
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🎫 Un autre ticket", callback_data="lot_buy")],
                                   [InlineKeyboardButton("⬅️ Loterie", callback_data="eco_loterie")]])
        await q.edit_message_text(text, parse_mode="HTML", reply_markup=kb)
        return
    from utils.input_flow import call_cmd
    await call_cmd(q, context, cmd_mestickets if q.data == "lot_mine" else cmd_tirage, [])
