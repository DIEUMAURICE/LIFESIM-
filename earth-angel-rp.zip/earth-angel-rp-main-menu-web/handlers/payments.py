# handlers/payments.py
"""
═══════════════════════════════════════════════════════════════════════════
   GAME FRENCH — Module de gestion des paiements et transactions
═══════════════════════════════════════════════════════════════════════════
Système complet de traçabilité :
  • Références uniques par transaction
  • Notifications aux admins
  • Consultation par période (jour/semaine/mois/année)
  • Filtres par rôle (paiement visible par tous, solde € réservé aux Leads)
  • Historique des actions administratives (LEAD_PRINCIPAL uniquement)
"""
from utils.swallow import swallowed
import aiosqlite
import time
from datetime import datetime, timezone
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from database import db_connection, DB_PATH, get_user, now
from utils.gametime import real_now
from config import (
    LEAD_PRINCIPAL_IDS, LEAD_STAFF_GLOBAL_IDS, ADMIN_IDS,
    ROLE_LABELS, role_level,
    STARS_SUBSCRIPTIONS, STARS_SHOP,
)
from utils.decorators import (
    get_user_role_async, require_registered, admin_n1_only,
    lead_principal_only, lead_staff_only,
)
from utils.helpers import fmt, fmt_time, escape_html
from utils.aesthetics import card, alert, SEP_HEAVY, SEP_LIGHT


# ═══════════════════════════════════════════════════════════════════════════
#                    GÉNÉRATION DE RÉFÉRENCES
# ═══════════════════════════════════════════════════════════════════════════

def generate_reference(user_id: int, prefix: str = "TRX") -> str:
    """Génère une référence unique lisible.
    Format : PREFIX-TIMESTAMP-USERID
    Exemple : TRX-1735689600-1687928453
    """
    ts = int(time.time())
    return f"{prefix}-{ts}-{user_id}"


async def log_transaction(
    user_id: int,
    amount: int,
    description: str,
    transaction_type: str = "purchase",
    reference_id: str = None,
    metadata: str = None,
    notify: bool = True,
) -> str:
    """
    Enregistre une transaction dans la base de données.
    
    Args:
        user_id: ID du joueur
        amount: montant (négatif = achat, positif = gain)
        description: description lisible
        transaction_type: 'purchase', 'subscription', 'refund',
                          'donation', 'reward', 'admin_gift', 'boost', etc.
        reference_id: référence personnalisée (sinon générée)
        metadata: infos supplémentaires
        notify: notifier les admins
    """
    if not reference_id:
        reference_id = generate_reference(user_id)

    async with db_connection() as db:
        try:
            await db.execute("""
                INSERT INTO transaction_log 
                (reference_id, user_id, timestamp, amount, description,
                 transaction_type, metadata, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'completed')
            """, (
                reference_id, user_id, real_now(), amount,
                description[:200], transaction_type,
                (metadata or "")[:500],
            ))
            await db.commit()
        except aiosqlite.IntegrityError:
            # Référence déjà existante (idempotence)
            return reference_id

    if notify:
        await notify_admins_of_transaction(
            user_id, amount, description, reference_id, transaction_type
        )
    return reference_id


# ═══════════════════════════════════════════════════════════════════════════
#                    NOTIFICATION DES ADMINS
# ═══════════════════════════════════════════════════════════════════════════

async def notify_admins_of_transaction(
    user_id: int,
    amount: int,
    description: str,
    reference_id: str,
    transaction_type: str,
):
    """Notifie tous les admins de la hiérarchie d'une transaction."""
    # ⭐ FIX : utiliser le registre global au lieu d'importer `app` depuis bot
    from utils.bot_registry import get_bot

    bot = get_bot()
    if bot is None:
        # Le bot n'est pas encore démarré → on skip silencieusement
        return

    user = await get_user(user_id)
    user_name = escape_html(user.get("full_name", f"Joueur {user_id}"))

    type_icons = {
        "purchase": "🛒",
        "subscription": "👑",
        "refund": "↩️",
        "donation": "🎁",
        "reward": "🏆",
        "admin_gift": "🎁",
        "boost": "⚡",
        "consumable": "🍬",
    }
    icon = type_icons.get(transaction_type, "💳")

    amount_sign = "+" if amount >= 0 else ""
    body = [
        f"👤 <b>{user_name}</b>  <code>{user_id}</code>",
        f"📝 {escape_html(description)}",
        f"💰 Montant : <b>{amount_sign}{fmt(abs(amount))}</b>",
        f"📊 Type : <b>{transaction_type}</b>",
        f"📅 {datetime.now(timezone.utc).strftime('%d/%m/%Y %H:%M:%S')} UTC",
        "",
        f"🆔 <b>Référence :</b> <code>{reference_id}</code>",
    ]
    message = card(
        f"{icon} NOUVELLE TRANSACTION",
        body,
        icon=icon,
        style="thick",
        footer="Ouvre le menu pour les détails",
    )

    # Notifier tous les admins
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, message, parse_mode="HTML")
        except Exception:
            swallowed('handlers/payments.py')

# ═══════════════════════════════════════════════════════════════════════════
#                    FILTRES PAR PÉRIODE
# ═══════════════════════════════════════════════════════════════════════════

def _get_period_range(period: str) -> tuple[int, int]:
    """Retourne (start_ts, end_ts) pour une période donnée.
    period ∈ {jour, semaine, mois, annee, all}
    """
    end_ts = real_now()          # transaction_log est horodaté en temps RÉEL (comptabilité Stars)
    p = (period or "all").lower().strip()
    if p in ("jour", "day", "today", "1j"):
        return end_ts - 86400, end_ts
    if p in ("semaine", "week", "7j", "7days"):
        return end_ts - 7 * 86400, end_ts
    if p in ("mois", "month", "30j", "30days"):
        return end_ts - 30 * 86400, end_ts
    if p in ("annee", "année", "year", "365j", "365days"):
        return end_ts - 365 * 86400, end_ts
    return 0, end_ts


def _period_label(period: str) -> str:
    p = (period or "all").lower().strip()
    return {
        "jour": "Aujourd'hui (24h)",
        "semaine": "7 derniers jours",
        "mois": "30 derniers jours",
        "annee": "Dernière année",
        "année": "Dernière année",
    }.get(p, "Tout l'historique")


# ═══════════════════════════════════════════════════════════════════════════
#              COMMANDE : /transactions (consultation)
# ═══════════════════════════════════════════════════════════════════════════

@require_registered
async def cmd_transactions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les transactions avec filtres et statistiques."""
    user_id = update.effective_user.id
    role = await get_user_role_async(user_id)

    period = "all"
    if context.args:
        period = context.args[0].lower()

    start_ts, end_ts = _get_period_range(period)
    is_hierarchy = role != "PLAYER"

    # ─── Construction de la requête ───
    if is_hierarchy:
        # Le staff voit toutes les transactions
        query = "SELECT * FROM transaction_log WHERE timestamp BETWEEN ? AND ?"
        params = [start_ts, end_ts]
    else:
        # Un joueur ne voit que les siennes
        query = "SELECT * FROM transaction_log WHERE user_id = ? AND timestamp BETWEEN ? AND ?"
        params = [user_id, start_ts, end_ts]

    query += " ORDER BY timestamp DESC LIMIT 100"

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(query, params) as cur:
            transactions = await cur.fetchall()

        # ─── Statistiques globales ───
        if is_hierarchy:
            stat_query = """
                SELECT 
                    COUNT(*) AS total_count,
                    SUM(CASE WHEN amount < 0 THEN amount ELSE 0 END) AS total_spent,
                    SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) AS total_gained
                FROM transaction_log
                WHERE timestamp BETWEEN ? AND ?
            """
            async with db.execute(stat_query, (start_ts, end_ts)) as cur2:
                stats = await cur2.fetchone()
        else:
            stat_query = """
                SELECT 
                    COUNT(*) AS total_count,
                    SUM(CASE WHEN amount < 0 THEN amount ELSE 0 END) AS total_spent,
                    SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) AS total_gained
                FROM transaction_log
                WHERE user_id = ? AND timestamp BETWEEN ? AND ?
            """
            async with db.execute(stat_query, (user_id, start_ts, end_ts)) as cur2:
                stats = await cur2.fetchone()

    # ─── Construction du message ───
    body = [
        f"📅 Période : <b>{_period_label(period)}</b>",
        f"📊 Total transactions : <b>{stats['total_count'] or 0}</b>",
    ]

    if is_hierarchy:
        body += [
            f"💸 Total dépensé : <b>{fmt(abs(stats['total_spent'] or 0))}</b>",
            f"💰 Total gagné : <b>{fmt(stats['total_gained'] or 0)}</b>",
        ]
    else:
        body += [
            f"💸 Total dépensé : <b>{fmt(abs(stats['total_spent'] or 0))}</b>",
            f"💰 Total gagné : <b>{fmt(stats['total_gained'] or 0)}</b>",
        ]

    body += ["", SEP_HEAVY, ""]

    if not transactions:
        body.append("<i>Aucune transaction sur cette période.</i>")
    else:
        for t in transactions[:30]:
            if is_hierarchy:
                t_user = await get_user(t["user_id"])
                t_user_name = escape_html(t_user.get("full_name", f"ID:{t['user_id']}"))
                date_str = datetime.fromtimestamp(t["timestamp"]).strftime("%d/%m %H:%M")
                sign = "+" if t["amount"] >= 0 else ""
                body.append(
                    f"🆔 <code>{t['reference_id']}</code>\n"
                    f"   👤 {t_user_name} · 💰 {sign}{fmt(abs(t['amount']))}\n"
                    f"   📝 {escape_html(t['description'][:60])}\n"
                    f"   📅 {date_str} · <i>{t['transaction_type']}</i>"
                )
            else:
                date_str = datetime.fromtimestamp(t["timestamp"]).strftime("%d/%m %H:%M")
                sign = "+" if t["amount"] >= 0 else ""
                body.append(
                    f"🆔 <code>{t['reference_id']}</code>\n"
                    f"   💰 {sign}{fmt(abs(t['amount']))} · 📅 {date_str}\n"
                    f"   📝 {escape_html(t['description'][:60])}"
                )

        if len(transactions) > 30:
            body.append(f"\n<i>... et {len(transactions) - 30} autres transactions</i>")

    # ─── Clavier de filtres ───
    keyboard = [
        [
            InlineKeyboardButton("📅 Jour", callback_data="tx_filter_jour"),
            InlineKeyboardButton("📅 Semaine", callback_data="tx_filter_semaine"),
        ],
        [
            InlineKeyboardButton("📅 Mois", callback_data="tx_filter_mois"),
            InlineKeyboardButton("📅 Année", callback_data="tx_filter_annee"),
        ],
        [
            InlineKeyboardButton("📅 Tout", callback_data="tx_filter_all"),
        ],
    ]

    title = "💳 TOUTES LES TRANSACTIONS" if is_hierarchy else "💳 MES TRANSACTIONS"
    await update.message.reply_text(
        card(title, body, icon="💳", style="thick",
             footer=f"Rôle : {ROLE_LABELS.get(role, role)}"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


# ═══════════════════════════════════════════════════════════════════════════
#              COMMANDE : /transaction_info <REF>
# ═══════════════════════════════════════════════════════════════════════════

@require_registered
async def cmd_transaction_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les détails complets d'une transaction via sa référence."""
    if not context.args:
        await update.message.reply_text(
            alert("info",
                  "Ouvre cette action depuis 🎮 Menu → 💼 Économie."
                  "Ouvre l'action depuis le 🎮 Menu principal."),
            parse_mode="HTML"
        )
        return

    reference_id = context.args[0].strip()
    user_id = update.effective_user.id
    role = await get_user_role_async(user_id)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM transaction_log WHERE reference_id = ?",
            (reference_id,)
        ) as cur:
            row = await cur.fetchone()

    if not row:
        await update.message.reply_text(
            alert("error", f"❌ Référence inconnue : <code>{escape_html(reference_id)}</code>"),
            parse_mode="HTML"
        )
        return

    # ⭐ FIX : convertir le Row en dict pour supporter .get()
    t = dict(row)

    # Un joueur ne peut voir que ses propres transactions
    if role == "PLAYER" and t["user_id"] != user_id:
        await update.message.reply_text(
            alert("error", "❌ Tu ne peux pas consulter cette transaction."),
            parse_mode="HTML"
        )
        return

    t_user = await get_user(t["user_id"])
    user_name = escape_html(t_user.get("full_name", f"ID:{t['user_id']}"))
    date_str = datetime.fromtimestamp(t["timestamp"]).strftime('%d/%m/%Y à %H:%M:%S')

    amount_sign = "+" if t["amount"] >= 0 else ""
    amount_color = "🟢" if t["amount"] >= 0 else "🔴"

    body = [
        f"🆔 <b>Référence :</b> <code>{t['reference_id']}</code>",
        "",
        f"👤 <b>Joueur :</b> {user_name}",
        f"🆔 <b>ID joueur :</b> <code>{t['user_id']}</code>",
        "",
        f"{amount_color} <b>Montant :</b> {amount_sign}{fmt(abs(t['amount']))}",
        f"📝 <b>Description :</b> {escape_html(t['description'])}",
        f"📊 <b>Type :</b> {t['transaction_type']}",
        f"📅 <b>Date et heure :</b> {date_str}",
        f"📌 <b>Statut :</b> {t.get('status', 'completed')}",
    ]
    if t.get("metadata"):
        body.append("")
        body.append(f"📦 <b>Détails :</b> {escape_html(t['metadata'][:300])}")

    await update.message.reply_text(
        card("🔍 DÉTAILS DE LA TRANSACTION", body, icon="🔍", style="thick"),
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════════════
#              CALLBACK : Filtres de période
# ═══════════════════════════════════════════════════════════════════════════

async def transactions_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gère les callbacks des filtres de période."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if data.startswith("tx_filter_"):
        period = data.replace("tx_filter_", "")
        context.args = [period]
        # Créer un faux update pour réutiliser cmd_transactions
        from types import SimpleNamespace
        fake_message = SimpleNamespace(
            reply_text=query.edit_message_text,
        )
        fake_update = SimpleNamespace(
            effective_user=query.from_user,
            message=fake_message,
            effective_message=fake_message,
        )
        # On ne rappelle pas cmd_transactions directement car elle
        # utilise update.message.reply_text, on reconstruit le contenu manuellement.
        # Solution plus simple : ré-afficher via le même code.
        await _show_transactions_edit(query, query.from_user.id, period)
        return


async def _show_transactions_edit(query, user_id: int, period: str):
    """Affiche les transactions en mode édition (pour callbacks)."""
    role = await get_user_role_async(user_id)
    start_ts, end_ts = _get_period_range(period)
    is_hierarchy = role != "PLAYER"

    if is_hierarchy:
        query_str = "SELECT * FROM transaction_log WHERE timestamp BETWEEN ? AND ?"
        params = [start_ts, end_ts]
    else:
        query_str = "SELECT * FROM transaction_log WHERE user_id = ? AND timestamp BETWEEN ? AND ?"
        params = [user_id, start_ts, end_ts]

    query_str += " ORDER BY timestamp DESC LIMIT 100"

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(query_str, params) as cur:
            transactions = await cur.fetchall()

        if is_hierarchy:
            async with db.execute("""
                SELECT COUNT(*) AS total_count,
                    SUM(CASE WHEN amount < 0 THEN amount ELSE 0 END) AS total_spent,
                    SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) AS total_gained
                FROM transaction_log WHERE timestamp BETWEEN ? AND ?
            """, (start_ts, end_ts)) as cur2:
                stats = await cur2.fetchone()
        else:
            async with db.execute("""
                SELECT COUNT(*) AS total_count,
                    SUM(CASE WHEN amount < 0 THEN amount ELSE 0 END) AS total_spent,
                    SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) AS total_gained
                FROM transaction_log WHERE user_id = ? AND timestamp BETWEEN ? AND ?
            """, (user_id, start_ts, end_ts)) as cur2:
                stats = await cur2.fetchone()

    body = [
        f"📅 Période : <b>{_period_label(period)}</b>",
        f"📊 Total : <b>{stats['total_count'] or 0}</b> transactions",
        f"💸 Dépensé : <b>{fmt(abs(stats['total_spent'] or 0))}</b>",
        f"💰 Gagné : <b>{fmt(stats['total_gained'] or 0)}</b>",
        "",
        SEP_HEAVY,
        "",
    ]

    if not transactions:
        body.append("<i>Aucune transaction sur cette période.</i>")
    else:
        for t in transactions[:25]:
            date_str = datetime.fromtimestamp(t["timestamp"]).strftime("%d/%m %H:%M")
            sign = "+" if t["amount"] >= 0 else ""
            if is_hierarchy:
                t_user = await get_user(t["user_id"])
                t_user_name = escape_html(t_user.get("full_name", f"ID:{t['user_id']}"))
                body.append(
                    f"🆔 <code>{t['reference_id']}</code>\n"
                    f"   👤 {t_user_name} · {sign}{fmt(abs(t['amount']))} · {date_str}"
                )
            else:
                body.append(
                    f"🆔 <code>{t['reference_id']}</code>\n"
                    f"   {sign}{fmt(abs(t['amount']))} · {date_str}\n"
                    f"   📝 {escape_html(t['description'][:50])}"
                )

    keyboard = [
        [
            InlineKeyboardButton("📅 Jour", callback_data="tx_filter_jour"),
            InlineKeyboardButton("📅 Semaine", callback_data="tx_filter_semaine"),
        ],
        [
            InlineKeyboardButton("📅 Mois", callback_data="tx_filter_mois"),
            InlineKeyboardButton("📅 Année", callback_data="tx_filter_annee"),
        ],
        [InlineKeyboardButton("📅 Tout", callback_data="tx_filter_all")],
    ]

    title = "💳 TOUTES LES TRANSACTIONS" if is_hierarchy else "💳 MES TRANSACTIONS"
    try:
        await query.edit_message_text(
            card(title, body, icon="💳", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard),
        )
    except Exception:
        swallowed('handlers/payments.py')


# ═══════════════════════════════════════════════════════════════════════════
#         COMMANDE : /balance_stats (solde € — réservé aux Leads)
# ═══════════════════════════════════════════════════════════════════════════

@lead_staff_only
async def cmd_balance_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les statistiques de solde global (réservé Lead Staff + Lead Principal)."""
    period = context.args[0].lower() if context.args else "all"
    start_ts, end_ts = _get_period_range(period)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row

        # Masse monétaire totale
        async with db.execute(
            "SELECT SUM(balance) AS total, COUNT(*) AS count FROM users WHERE registered=1"
        ) as cur:
            money = await cur.fetchone()

        # Masse en banque
        async with db.execute(
            "SELECT SUM(balance) AS total FROM bank_accounts"
        ) as cur:
            bank = await cur.fetchone()

        # Transactions sur la période
        async with db.execute("""
            SELECT 
                COUNT(*) AS nb,
                SUM(CASE WHEN amount < 0 THEN amount ELSE 0 END) AS spent,
                SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) AS gained
            FROM transaction_log WHERE timestamp BETWEEN ? AND ?
        """, (start_ts, end_ts)) as cur:
            tx_stats = await cur.fetchone()

        # Top 5 des plus grosses transactions
        async with db.execute("""
            SELECT user_id, amount, description, reference_id, timestamp
            FROM transaction_log
            WHERE timestamp BETWEEN ? AND ? AND amount < 0
            ORDER BY ABS(amount) DESC LIMIT 5
        """, (start_ts, end_ts)) as cur:
            top_tx = await cur.fetchall()

    body = [
        f"📅 Période : <b>{_period_label(period)}</b>",
        "",
        "━━━ 💰 MASSE MONÉTAIRE ━━━",
        f"💵 Espèces : <b>{fmt(money['total'] or 0)}</b>",
        f"🏦 Banque : <b>{fmt(bank['total'] or 0)}</b>",
        f"📊 Total : <b>{fmt((money['total'] or 0) + (bank['total'] or 0))}</b>",
        f"👥 Joueurs : <b>{money['count'] or 0}</b>",
        "",
        "━━━ 💳 TRANSACTIONS ━━━",
        f"🔢 Nombre : <b>{tx_stats['nb'] or 0}</b>",
        f"💸 Dépensé : <b>{fmt(abs(tx_stats['spent'] or 0))}</b>",
        f"💰 Gagné : <b>{fmt(tx_stats['gained'] or 0)}</b>",
    ]

    if top_tx:
        body += ["", "━━━ 🏆 TOP DÉPENSES ━━━"]
        for tx in top_tx:
            t_user = await get_user(tx["user_id"])
            name = escape_html(t_user.get("full_name", "?"))
            body.append(
                f"• {name} : <b>{fmt(abs(tx['amount']))}</b>\n"
                f"  <code>{tx['reference_id']}</code>"
            )

    keyboard = [
        [
            InlineKeyboardButton("📅 Jour", callback_data="bal_filter_jour"),
            InlineKeyboardButton("📅 Semaine", callback_data="bal_filter_semaine"),
        ],
        [
            InlineKeyboardButton("📅 Mois", callback_data="bal_filter_mois"),
            InlineKeyboardButton("📅 Année", callback_data="bal_filter_annee"),
        ],
        [InlineKeyboardButton("📅 Tout", callback_data="bal_filter_all")],
    ]

    await update.message.reply_text(
        card("💰 STATISTIQUES DE SOLDE", body, icon="💰", style="thick",
             footer="⚠️ Réservé aux Lead Staff Global & Lead Principal"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def balance_stats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Callback pour le menu."""
    query = update.callback_query
    await query.answer()
    data = query.data
    if not data.startswith("bal_filter_"):
        return
    period = data.replace("bal_filter_", "")
    # Rediriger vers la fonction principale via faux update
    from types import SimpleNamespace
    fake_msg = SimpleNamespace(reply_text=query.edit_message_text)
    fake_update = SimpleNamespace(
        effective_user=query.from_user,
        message=fake_msg,
        effective_message=fake_msg,
    )
    context.args = [period]
    # On rappelle manuellement le code pour éviter les problèmes de reply_text
    await _show_balance_stats_edit(query, period)


async def _show_balance_stats_edit(query, period: str):
    """Réaffiche balance_stats en mode édition."""
    start_ts, end_ts = _get_period_range(period)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT SUM(balance) AS total, COUNT(*) AS count FROM users WHERE registered=1"
        ) as cur:
            money = await cur.fetchone()
        async with db.execute("SELECT SUM(balance) AS total FROM bank_accounts") as cur:
            bank = await cur.fetchone()
        async with db.execute("""
            SELECT COUNT(*) AS nb,
                SUM(CASE WHEN amount < 0 THEN amount ELSE 0 END) AS spent,
                SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) AS gained
            FROM transaction_log WHERE timestamp BETWEEN ? AND ?
        """, (start_ts, end_ts)) as cur:
            tx_stats = await cur.fetchone()
        async with db.execute("""
            SELECT user_id, amount, reference_id FROM transaction_log
            WHERE timestamp BETWEEN ? AND ? AND amount < 0
            ORDER BY ABS(amount) DESC LIMIT 5
        """, (start_ts, end_ts)) as cur:
            top_tx = await cur.fetchall()

    body = [
        f"📅 Période : <b>{_period_label(period)}</b>",
        "",
        "━━━ 💰 MASSE MONÉTAIRE ━━━",
        f"💵 Espèces : <b>{fmt(money['total'] or 0)}</b>",
        f"🏦 Banque : <b>{fmt(bank['total'] or 0)}</b>",
        f"📊 Total : <b>{fmt((money['total'] or 0) + (bank['total'] or 0))}</b>",
        f"👥 Joueurs : <b>{money['count'] or 0}</b>",
        "",
        "━━━ 💳 TRANSACTIONS ━━━",
        f"🔢 Nombre : <b>{tx_stats['nb'] or 0}</b>",
        f"💸 Dépensé : <b>{fmt(abs(tx_stats['spent'] or 0))}</b>",
        f"💰 Gagné : <b>{fmt(tx_stats['gained'] or 0)}</b>",
    ]
    if top_tx:
        body += ["", "━━━ 🏆 TOP DÉPENSES ━━━"]
        for tx in top_tx:
            t_user = await get_user(tx["user_id"])
            name = escape_html(t_user.get("full_name", "?"))
            body.append(f"• {name} : <b>{fmt(abs(tx['amount']))}</b>\n  <code>{tx['reference_id']}</code>")

    keyboard = [
        [InlineKeyboardButton("📅 Jour", callback_data="bal_filter_jour"),
         InlineKeyboardButton("📅 Semaine", callback_data="bal_filter_semaine")],
        [InlineKeyboardButton("📅 Mois", callback_data="bal_filter_mois"),
         InlineKeyboardButton("📅 Année", callback_data="bal_filter_annee")],
        [InlineKeyboardButton("📅 Tout", callback_data="bal_filter_all")],
    ]

    try:
        await query.edit_message_text(
            card("💰 STATISTIQUES DE SOLDE", body, icon="💰", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard),
        )
    except Exception:
        swallowed('handlers/payments.py')


# ═══════════════════════════════════════════════════════════════════════════
#              COMMANDE : /admin_action_log (LEAD_PRINCIPAL only)
# ═══════════════════════════════════════════════════════════════════════════

@lead_principal_only
async def cmd_admin_action_log(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Historique complet des actions administratives.
    ⚠️ Visible uniquement par le LEAD_PRINCIPAL.
    """
    period = context.args[0].lower() if context.args else "all"
    start_ts, end_ts = _get_period_range(period)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT al.*, u.full_name AS admin_name
            FROM admin_logs al
            LEFT JOIN users u ON u.user_id = al.admin_id
            WHERE al.timestamp BETWEEN ? AND ?
            ORDER BY al.timestamp DESC
            LIMIT 50
        """, (start_ts, end_ts)) as cur:
            logs = await cur.fetchall()

        async with db.execute("""
            SELECT action, COUNT(*) AS nb FROM admin_logs
            WHERE timestamp BETWEEN ? AND ?
            GROUP BY action ORDER BY nb DESC LIMIT 10
        """, (start_ts, end_ts)) as cur:
            action_stats = await cur.fetchall()

    body = [
        f"📅 Période : <b>{_period_label(period)}</b>",
        f"📊 Total actions : <b>{len(logs)}</b>",
        "",
        "━━━ 📊 TOP ACTIONS ━━━",
    ]
    for a in action_stats:
        body.append(f"• <b>{escape_html(a['action'])}</b> : {a['nb']} fois")

    body += ["", "━━━ 📜 DERNIÈRES ACTIONS ━━━"]

    if not logs:
        body.append("<i>Aucune action enregistrée.</i>")
    else:
        for log in logs[:30]:
            date_str = datetime.fromtimestamp(log["timestamp"]).strftime("%d/%m %H:%M")
            admin_name = escape_html(log["admin_name"] or f"ID:{log['admin_id']}")
            body.append(
                f"📅 <b>{date_str}</b>\n"
                f"👤 Admin : {admin_name}  <code>{log['admin_id']}</code>\n"
                f"➡️ Action : <code>{escape_html(log['action'])}</code>\n"
                f"🎯 Cible : <code>{log['target_id']}</code>\n"
                f"📝 {escape_html((log['details'] or '')[:80])}"
            )

    # Découpage en chunks
    chunk_size = 8
    for i in range(0, len(body), chunk_size):
        chunk = body[i:i+chunk_size]
        footer = (
            f"⚠️ Réservé au LEAD_PRINCIPAL" if i == 0 else None
        )
        await update.message.reply_text(
            card(f"📜 ADMIN ACTION LOG ({i//chunk_size + 1})", chunk,
                 icon="📜", style="thick", footer=footer),
            parse_mode="HTML",
        )


# ═══════════════════════════════════════════════════════════════════════════
#              COMMANDE : /game_logs (tous les admins)
# ═══════════════════════════════════════════════════════════════════════════

@admin_n1_only
async def cmd_game_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les logs des actions de jeu (crimes, missions, voyages, etc.)
    Visible par tout le staff.
    """
    period = context.args[0].lower() if context.args else "jour"
    start_ts, end_ts = _get_period_range(period)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row

        # Crimes
        async with db.execute("""
            SELECT COUNT(*) AS nb, SUM(success) AS success
            FROM crime_log WHERE timestamp BETWEEN ? AND ?
        """, (start_ts, end_ts)) as cur:
            crimes = await cur.fetchone()

        # Voyages
        async with db.execute("""
            SELECT COUNT(*) AS nb FROM travel_log
            WHERE timestamp BETWEEN ? AND ?
        """, (start_ts, end_ts)) as cur:
            travels = await cur.fetchone()

        # Missions complétées
        async with db.execute("""
            SELECT COUNT(*) AS nb FROM mission_log
            WHERE completed_at BETWEEN ? AND ?
        """, (start_ts, end_ts)) as cur:
            missions = await cur.fetchone()

        # Inscriptions / connexions
        async with db.execute("""
            SELECT COUNT(*) AS nb FROM users
            WHERE last_seen BETWEEN ? AND ?
        """, (start_ts, end_ts)) as cur:
            active = await cur.fetchone()

    body = [
        f"📅 Période : <b>{_period_label(period)}</b>",
        "",
        "━━━ 🎮 ACTIVITÉ DE JEU ━━━",
        f"💀 Crimes : <b>{crimes['nb'] or 0}</b> (réussis : {crimes['success'] or 0})",
        f"✈️ Voyages : <b>{travels['nb'] or 0}</b>",
        f"🎯 Missions complétées : <b>{missions['nb'] or 0}</b>",
        f"👥 Joueurs actifs : <b>{active['nb'] or 0}</b>",
    ]

    await update.message.reply_text(
        card("📊 LOGS DE JEU", body, icon="📊", style="thick",
             footer="Visible par tout le staff"),
        parse_mode="HTML",
    )

# ═══════════════════════════════════════════════════════════════════════════
#         💰 REVENUS TELEGRAM STARS (réservé aux Leads)
# ═══════════════════════════════════════════════════════════════════════════

# Taux de conversion (à ajuster selon l'évolution du marché)
STAR_TO_USD = 0.013     # 1 ⭐ ≈ 0.013 USD (prix client)
TON_TO_USD = 5.5        # 1 TON ≈ 5.5 USD
USD_TO_EUR = 0.92       # 1 USD ≈ 0.92 EUR
TELEGRAM_FEE = 0.30     # Telegram retient ~30%


def _estimate_revenue(total_stars: int) -> dict:
    """Calcule les estimations de revenus en USD, TON et €."""
    gross_usd = total_stars * STAR_TO_USD
    net_usd = gross_usd * (1 - TELEGRAM_FEE)  # après commission Telegram
    ton = net_usd / TON_TO_USD if TON_TO_USD > 0 else 0
    eur = net_usd * USD_TO_EUR
    return {
        "gross_usd": round(gross_usd, 2),
        "net_usd": round(net_usd, 2),
        "ton": round(ton, 4),
        "eur": round(eur, 2),
    }


@lead_staff_only
async def cmd_stars_revenue(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les revenus Telegram Stars du bot. Réservé aux Leads."""
    period = context.args[0].lower() if context.args else "all"

    # ═══════════════════════════════════════════════════════════════
    #   Récupération des stats sur plusieurs périodes
    # ═══════════════════════════════════════════════════════════════
    end_ts = real_now()          # transaction_log = temps RÉEL
    periods = {
        "jour": (end_ts - 86400, end_ts, "Aujourd'hui (24h)"),
        "semaine": (end_ts - 7 * 86400, end_ts, "7 derniers jours"),
        "mois": (end_ts - 30 * 86400, end_ts, "30 derniers jours"),
        "annee": (end_ts - 365 * 86400, end_ts, "Dernière année"),
        "all": (0, end_ts, "Depuis le début"),
    }

    stats_by_period = {}

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row

        for key, (start, end, _label) in periods.items():
            # Compte + somme des Stars sur la période (hors remboursements)
            async with db.execute("""
                SELECT 
                    COUNT(*) AS nb,
                    COALESCE(SUM(stars_amount), 0) AS total_stars,
                    COUNT(DISTINCT user_id) AS unique_users
                FROM star_purchases
                WHERE refunded = 0 AND created_at BETWEEN ? AND ?
            """, (start, end)) as cur:
                row = await cur.fetchone()
                stats_by_period[key] = {
                    "nb": row["nb"] or 0,
                    "stars": row["total_stars"] or 0,
                    "users": row["unique_users"] or 0,
                }

        # Top 5 des articles vendus (toutes périodes)
        async with db.execute("""
            SELECT item_id, COUNT(*) AS nb, SUM(stars_amount) AS total
            FROM star_purchases
            WHERE refunded = 0
            GROUP BY item_id
            ORDER BY total DESC
            LIMIT 5
        """) as cur:
            top_items = [dict(r) for r in await cur.fetchall()]

        # Top 5 des acheteurs
        async with db.execute("""
            SELECT sp.user_id, u.full_name, COUNT(*) AS nb, SUM(sp.stars_amount) AS total
            FROM star_purchases sp
            LEFT JOIN users u ON u.user_id = sp.user_id
            WHERE sp.refunded = 0
            GROUP BY sp.user_id
            ORDER BY total DESC
            LIMIT 5
        """) as cur:
            top_buyers = [dict(r) for r in await cur.fetchall()]

    # ═══════════════════════════════════════════════════════════════
    #   Construction du message
    # ═══════════════════════════════════════════════════════════════
    all_stats = stats_by_period["all"]
    period_stats = stats_by_period.get(period, all_stats)
    estimate = _estimate_revenue(period_stats["stars"])

    # Période active
    period_label = periods.get(period, periods["all"])[2]

    body = [
        f"📅 <b>Période analysée :</b> {period_label}",
        "",
        "<b>━━━ 📊 VENTES ━━━</b>",
        f"🛒 Nombre de ventes : <b>{period_stats['nb']}</b>",
        f"⭐ Total Stars : <b>{period_stats['stars']:,}</b>".replace(",", " "),
        f"👥 Acheteurs uniques : <b>{period_stats['users']}</b>",
        "",
        "<b>━━━ 💵 ESTIMATION REVENUS ━━━</b>",
        f"💵 Brut : <b>~ {estimate['gross_usd']}$</b>",
        f"🏦 Après commission Telegram (-30%) : <b>~ {estimate['net_usd']}$</b>",
        f"💎 Estimation TON : <b>~ {estimate['ton']} TON</b>",
        f"💶 Estimation € : <b>~ {estimate['eur']}€</b>",
    ]

    # ─── Récap global ───
    if period != "all":
        global_estimate = _estimate_revenue(all_stats["stars"])
        body += [
            "",
            "<b>━━━ 📈 TOTAL GLOBAL ━━━</b>",
            f"🛒 {all_stats['nb']} ventes · ⭐ {all_stats['stars']:,}".replace(",", " "),
            f"💶 <b>~ {global_estimate['eur']}€</b> au total",
        ]

    # ─── Top articles ───
    if top_items:
        body += ["", "<b>━━━ 🏆 TOP ARTICLES ━━━</b>"]
        for i, item in enumerate(top_items, 1):
            # Retrouver le label depuis la config
            item_id = item["item_id"]
            item_label = item_id
            if item_id in STARS_SUBSCRIPTIONS:
                item_label = STARS_SUBSCRIPTIONS[item_id]["label"]
            elif item_id in STARS_SHOP:
                item_label = STARS_SHOP[item_id]["label"]

            body.append(
                f"{i}. <b>{escape_html(item_label)}</b> — "
                f"{item['nb']}× · ⭐ {item['total']:,}".replace(",", " ")
            )

    # ─── Top acheteurs ───
    if top_buyers:
        body += ["", "<b>━━━ 👑 TOP ACHETEURS ━━━</b>"]
        for i, buyer in enumerate(top_buyers, 1):
            name = escape_html(buyer.get("full_name") or f"ID:{buyer['user_id']}")
            body.append(
                f"{i}. <b>{name}</b> — "
                f"{buyer['nb']}× · ⭐ {buyer['total']:,}".replace(",", " ")
            )

    # ─── Note d'aide ───
    body += [
        "",
        "<i>💡 Estimations basées sur :</i>",
        f"<i>  • 1 ⭐ ≈ {STAR_TO_USD}$ (client)</i>",
        f"<i>  • Commission Telegram : -{int(TELEGRAM_FEE*100)}%</i>",
        f"<i>  • 1 TON ≈ {TON_TO_USD}$ · 1$ ≈ {USD_TO_EUR}€</i>",
    ]

    # ─── Clavier de filtres ───
    keyboard = [
        [
            InlineKeyboardButton("📅 Jour", callback_data="rev_filter_jour"),
            InlineKeyboardButton("📅 Semaine", callback_data="rev_filter_semaine"),
        ],
        [
            InlineKeyboardButton("📅 Mois", callback_data="rev_filter_mois"),
            InlineKeyboardButton("📅 Année", callback_data="rev_filter_annee"),
        ],
        [InlineKeyboardButton("📅 Tout", callback_data="rev_filter_all")],
    ]

    # Découpage si trop long
    chunk_size = 22
    for i in range(0, len(body), chunk_size):
        chunk = body[i:i+chunk_size]
        is_last = (i + chunk_size) >= len(body)
        title = "💰 REVENUS TELEGRAM STARS" if i == 0 else "💰 REVENUS (suite)"
        await update.message.reply_text(
            card(
                title, chunk,
                icon="💰", style="thick",
                footer="⚠️ Réservé aux Leads" if i == 0 else None,
            ),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard) if is_last else None,
        )


async def stars_revenue_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gère les boutons de filtre pour le menu."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if not data.startswith("rev_filter_"):
        return

    period = data.replace("rev_filter_", "")

    # Réaffiche en mode édition
    await _show_stars_revenue_edit(query, period)


async def _show_stars_revenue_edit(query, period: str):
    """Réaffiche le menu en mode édition (pour callbacks)."""
    end_ts = real_now()          # transaction_log = temps RÉEL
    periods = {
        "jour": (end_ts - 86400, end_ts, "Aujourd'hui (24h)"),
        "semaine": (end_ts - 7 * 86400, end_ts, "7 derniers jours"),
        "mois": (end_ts - 30 * 86400, end_ts, "30 derniers jours"),
        "annee": (end_ts - 365 * 86400, end_ts, "Dernière année"),
        "all": (0, end_ts, "Depuis le début"),
    }

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row

        async with db.execute("""
            SELECT COUNT(*) AS nb, COALESCE(SUM(stars_amount), 0) AS total_stars,
                   COUNT(DISTINCT user_id) AS unique_users
            FROM star_purchases
            WHERE refunded = 0 AND created_at BETWEEN ? AND ?
        """, periods.get(period, periods["all"])[:2]) as cur:
            row = await cur.fetchone()
            period_stats = {
                "nb": row["nb"] or 0,
                "stars": row["total_stars"] or 0,
                "users": row["unique_users"] or 0,
            }

        # Total global
        async with db.execute("""
            SELECT COALESCE(SUM(stars_amount), 0) AS total_stars, COUNT(*) AS nb
            FROM star_purchases WHERE refunded = 0
        """) as cur:
            row = await cur.fetchone()
            all_stats = {"nb": row["nb"] or 0, "stars": row["total_stars"] or 0}

    estimate = _estimate_revenue(period_stats["stars"])
    global_estimate = _estimate_revenue(all_stats["stars"])
    period_label = periods.get(period, periods["all"])[2]

    body = [
        f"📅 <b>Période :</b> {period_label}",
        "",
        "<b>━━━ 📊 VENTES ━━━</b>",
        f"🛒 Ventes : <b>{period_stats['nb']}</b>",
        f"⭐ Stars : <b>{period_stats['stars']:,}</b>".replace(",", " "),
        f"👥 Acheteurs : <b>{period_stats['users']}</b>",
        "",
        "<b>━━━ 💵 ESTIMATION ━━━</b>",
        f"💵 Brut : <b>~ {estimate['gross_usd']}$</b>",
        f"🏦 Net (-30%) : <b>~ {estimate['net_usd']}$</b>",
        f"💎 TON : <b>~ {estimate['ton']} TON</b>",
        f"💶 € : <b>~ {estimate['eur']}€</b>",
        "",
        f"<b>━━━ 📈 GLOBAL ━━━</b>",
        f"🛒 {all_stats['nb']} ventes · ⭐ {all_stats['stars']:,}".replace(",", " "),
        f"💶 Total : <b>~ {global_estimate['eur']}€</b>",
    ]

    keyboard = [
        [
            InlineKeyboardButton("📅 Jour", callback_data="rev_filter_jour"),
            InlineKeyboardButton("📅 Semaine", callback_data="rev_filter_semaine"),
        ],
        [
            InlineKeyboardButton("📅 Mois", callback_data="rev_filter_mois"),
            InlineKeyboardButton("📅 Année", callback_data="rev_filter_annee"),
        ],
        [InlineKeyboardButton("📅 Tout", callback_data="rev_filter_all")],
    ]

    try:
        await query.edit_message_text(
            card("💰 REVENUS TELEGRAM STARS", body, icon="💰", style="thick",
                 footer="⚠️ Réservé aux Leads"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard),
        )
    except Exception:
        swallowed('handlers/payments.py')

# ═══════════════════════════════════════════════════════════════════════════
#              EXPORTS
# ═══════════════════════════════════════════════════════════════════════════

__all__ = [
    "generate_reference",
    "log_transaction",
    "notify_admins_of_transaction",
    "cmd_transactions",
    "cmd_transaction_info",
    "cmd_balance_stats",
    "cmd_admin_action_log",
    "cmd_game_logs",
    "cmd_stars_revenue",            # ⭐ NOUVEAU
    "transactions_callback",
    "balance_stats_callback",
    "stars_revenue_callback",       # ⭐ NOUVEAU
]