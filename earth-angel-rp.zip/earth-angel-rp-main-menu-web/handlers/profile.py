"""
handlers/profile.py — LIFESIM ULTRA V2
═══════════════════════════════════════════════════════════════════════
Affichages de profil enrichis & immersifs + menu interactif.
Ajout : affichage des cosmétiques achetés en boutique Étoiles
        (profile_title, profile_badge, signature_emoji).
"""
import unicodedata
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from database import (
    db_connection,
    DB_PATH, get_user, update_field, get_all_skills,
    get_properties, get_vehicles, get_portfolio, get_inventory, get_marriage,
)
from utils.decorators import require_registered
from utils.helpers import (
    fmt, get_title, get_level, xp_for_level, xp_progress,
    karma_label, wealth_class, now, escape_html, fmt_time,
)
from utils.aesthetics import (
    card, stat_card, mini_stat, alert, section, age_stage,
    bullet_list, keyed_list, stars, SEP_LIGHT,
)
from utils.input_flow import ask, flow
from utils.helpers import safe_edit

BIO_MAX = 200
CITY_MAX = 50


# ═══════════════════════════════════════════════════════════════════
#              📊 STATISTIQUES
# ═══════════════════════════════════════════════════════════════════
async def show_stats_view(query, user_id: int):
    u = await get_user(user_id)
    body = [
        "<b>💰 ARGENT</b>",
        f"  💵 Solde actuel : <b>{fmt(u['balance'])}</b>",
        f"  📈 Total gagné : <b>{fmt(u.get('total_earned', 0))}</b>",
        f"  📉 Total dépensé : <b>{fmt(u.get('total_spent', 0))}</b>",
        f"  🤲 Charité : <b>{fmt(u.get('charity_given', 0))}</b>",
        "",
        "<b>⚔️ PVP & CRIME</b>",
        f"  🥊 Combats : <b>{u.get('arena_wins', 0)}W</b> / <b>{u.get('arena_losses', 0)}L</b>",
        f"  💼 Crimes tentés : <b>{u.get('crimes_done', 0)}</b>",
        f"  ✅ Crimes réussis : <b>{u.get('crimes_success', 0)}</b>",
        f"  💻 Hacks : <b>{u.get('hack_attempts', 0)}</b>",
        "",
        "<b>🎯 PROGRESSION</b>",
        f"  ✅ Missions : <b>{u.get('missions_done', 0)}</b>",
        f"  ⭐ XP cumulée : <b>{u['xp']}</b>",
        f"  👑 Prestige : <b>{u.get('prestige', 0)}</b>",
        "",
        "<b>🎲 LOISIRS</b>",
        f"  🎰 Loteries gagnées : <b>{u.get('lottery_wins', 0)}</b>",
        f"  🎲 Casino misé : <b>{fmt(u.get('casino_total_bet', 0))}</b>",
        f"  💰 Casino gagné : <b>{fmt(u.get('casino_total_win', 0))}</b>",
        f"  🌱 Plantes : <b>{u.get('plants_grown', 0)}</b>",
        f"  ✈️ Voyages : <b>{u.get('travel_count', 0)}</b>",
        "",
        "<b>📱 SOCIAL</b>",
        f"  📱 Followers : <b>{u.get('social_followers', 0)}</b>",
    ]
    await safe_edit(
        query,
        card("📊 STATISTIQUES DÉTAILLÉES", body, icon="📊", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="prof_menu")]]),
    )


# ═══════════════════════════════════════════════════════════════════
#              ⭐ NIVEAU
# ═══════════════════════════════════════════════════════════════════
async def show_niveau_view(query, user_id: int):
    u = await get_user(user_id)
    lvl, xp_in, xp_next = xp_progress(u["xp"])
    pct = int(xp_in / max(1, xp_next) * 100)
    bar = "█" * (pct // 10) + "░" * (10 - pct // 10)
    body = [
        f"⭐ Niveau actuel : <b>{lvl}</b>",
        f"📊 XP totale : <b>{u['xp']}</b>",
        "",
        f"Progression vers niveau {lvl+1} :",
        f"<code>{bar}</code> <b>{pct}%</b>",
        f"<b>{xp_in}</b> / <b>{xp_next}</b> XP",
    ]
    await safe_edit(
        query,
        card("⭐ NIVEAU", body, icon="⭐", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="prof_menu")]]),
    )


# ═══════════════════════════════════════════════════════════════════
#              🏅 BADGES
# ═══════════════════════════════════════════════════════════════════
async def show_badges_view(query, user_id: int):
    async with db_connection() as db:
        try:
            async with db.execute("SELECT badge, earned_at FROM user_badges WHERE user_id=?", (user_id,)) as cur:
                rows = await cur.fetchall()
        except aiosqlite.OperationalError:
            rows = []

    if not rows:
        body = ["<i>Tu n'as encore aucun badge.</i>", "", "Enchaîne missions et succès pour en gagner !"]
        await safe_edit(
            query,
            card("🏅 TES BADGES", body, icon="🏅", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="prof_menu")]]),
        )
        return

    body = [f"  🏅 <b>{escape_html(b)}</b>" for b, _ in rows]

    # Badge personnalisé acheté en boutique
    u = await get_user(user_id)
    if u.get("profile_badge"):
        body.append(f"  {u['profile_badge']} <b>Badge personnalisé</b>")

    await safe_edit(
        query,
        card(f"🏅 BADGES ({len(rows)})", body, icon="🏅", style="stars"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="prof_menu")]]),
    )


# ═══════════════════════════════════════════════════════════════════
#              👑 TITRES
# ═══════════════════════════════════════════════════════════════════
async def show_titres_view(query, user_id: int):
    from config import TITLES
    u = await get_user(user_id)
    current = get_title(u["balance"])
    body = []
    for t in TITLES:
        if u["balance"] >= t["min"]:
            body.append(f"  ✅ <b>{t['title']}</b> ─ {fmt(t['min'])}")
        else:
            body.append(f"  🔒 {t['title']} ─ {fmt(t['min'])}")

    # Titre personnalisé acheté
    if u.get("profile_title"):
        body.insert(0, f"  🏷️ <b>Titre personnalisé :</b> {escape_html(u['profile_title'])}")
        body.insert(1, "")

    await safe_edit(
        query,
        card(f"👑 TITRES (actuel : {current})", body, icon="👑", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📜 Historique des titres", callback_data="prof_titres_hist")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="prof_menu")],
        ]),
    )


async def show_historique_titres_view(query, user_id: int):
    from config import TITLES
    u = await get_user(user_id)
    body = ["<b>Hiérarchie des titres :</b>", ""]
    for t in TITLES:
        unlocked = "✅" if u["balance"] >= t["min"] else "🔒"
        body.append(f"  {unlocked} <b>{t['title']}</b> ─ requiert {fmt(t['min'])}")

    if u.get("profile_title"):
        body += ["", f"🏷️ <b>Titre personnalisé :</b> {escape_html(u['profile_title'])}"]

    await safe_edit(
        query,
        card("📜 HISTORIQUE DES TITRES", body, icon="👑", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="prof_titres")]]),
    )


# ═══════════════════════════════════════════════════════════════════
#              🌟 KARMA
# ═══════════════════════════════════════════════════════════════════
async def show_karma_view(query, user_id: int):
    u = await get_user(user_id)
    k = u.get("karma", 0)
    body = [
        f"🌟 Karma : <b>{k:+d}</b>",
        f"📛 Statut : <b>{karma_label(k)}</b>",
        "",
        "<b>Effets actuels :</b>",
        "  • Bonnes actions / charité ↑ Karma",
        "  • Crimes / hacks ↓ Karma",
        "  • Karma haut : +25% revenus, succès",
        "  • Karma bas : −25% chance, pénalités",
    ]
    await safe_edit(
        query,
        card("🌟 KARMA", body, icon="🌟", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="prof_menu")]]),
    )


# ═══════════════════════════════════════════════════════════════════
#              📦 INVENTAIRE
# ═══════════════════════════════════════════════════════════════════
async def show_inventaire_view(query, user_id: int):
    items = await get_inventory(user_id)
    if not items:
        await safe_edit(
            query,
            card("📦 INVENTAIRE", ["<i>Ton inventaire est vide.</i>"], icon="📦", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="prof_menu")]]),
        )
        return

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        body = []
        for i in items[:20]:
            item_id = i.get("item_id")
            if item_id:
                async with db.execute("SELECT emoji, name, rarity FROM items WHERE item_id = ?", (item_id,)) as cur:
                    item_def = await cur.fetchone()
                if item_def:
                    body.append(f"  <code>#{item_id}</code> {item_def['emoji']} <b>{escape_html(item_def['name'])}</b> ({item_def['rarity']}) ×{i['quantity']}")
                else:
                    body.append(f"  <code>#{item_id}</code> {escape_html(i.get('item_name', 'Inconnu'))} ×{i['quantity']}")
            else:
                body.append(f"  📦 <b>{escape_html(i.get('item_name', 'Objet'))}</b> ×{i['quantity']}")
        if len(items) > 20:
            body.append(f"")
            body.append(f"<i>... et {len(items) - 20} autres</i>")

    body.append("")
    body.append("<i>Consomme ou vends tes objets depuis le menu Inventaire.</i>")

    await safe_edit(
        query,
        card(f"📦 INVENTAIRE ({len(items)})", body, icon="📦", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="prof_menu")]]),
    )


# ═══════════════════════════════════════════════════════════════════
#              ✍️ BIO
# ═══════════════════════════════════════════════════════════════════
def _bio_view(u: dict):
    """(texte, boutons) de l'écran « Ma biographie » : le joueur la saisit lui-même."""
    bio = u.get("bio", "")
    body = [
        f"<i>« {escape_html(bio)} »</i>" if bio else "<i>(vide)</i>",
        "",
        f"Appuie sur « ✏️ Écrire ma bio » : le bot te la demande, tu l'écris en un message ({BIO_MAX} caractères max).",
    ]
    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("✏️ Écrire ma bio", callback_data="prof_bio_edit")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="hub:profil:0")],
    ])
    return card("✍️ MA BIOGRAPHIE", body, icon="📝", style="round"), markup


async def show_bio_view(query, user_id: int):
    text, markup = _bio_view(await get_user(user_id))
    await safe_edit(query, text, parse_mode="HTML", reply_markup=markup)


@flow("prof_bio_text")
async def _flow_bio(update, context, value, data):
    bio = value.strip()
    if len(bio) > BIO_MAX:
        await ask(update, context, "prof_bio_text",
                  f"❌ Trop long : {len(bio)} caractères (maximum {BIO_MAX}). Raccourcis ta bio et renvoie-la.",
                  kind="text", back="prof_bio")
        return
    await update_field(update.effective_user.id, "bio", bio)
    await update.effective_message.reply_text(
        card("📝 Bio mise à jour", [f"<i>« {escape_html(bio)} »</i>"], icon="✍️", style="round"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Profil", callback_data="hub:profil:0")]]))


# ═══════════════════════════════════════════════════════════════════
#              📍 LIEU
# ═══════════════════════════════════════════════════════════════════
def _canonical_city(text: str) -> str:
    """Si la ville saisie est une ville connue du jeu (Paris, New York…), on garde son écriture officielle
    (elle donne ses bonus) ; sinon on garde exactement ce que le joueur a écrit."""
    from config import CITIES
    import unicodedata

    def norm(t: str) -> str:
        t = unicodedata.normalize("NFD", t.lower())
        return "".join(c for c in t if unicodedata.category(c) != "Mn").replace("-", " ").strip()

    wanted = norm(text)
    for name in CITIES:
        if norm(name) == wanted:
            return name
    return text.strip()


def _lieu_view(u: dict):
    lieu = (u.get("location") or "").strip()
    body = [
        f"📍 Ville actuelle : <b>{escape_html(lieu)}</b>" if lieu else "📍 Ville actuelle : <i>non définie</i>",
        "",
        "Appuie sur « ✏️ Saisir ma ville » : le bot te la demande, tu écris la ville où tu te trouves.",
    ]
    markup = InlineKeyboardMarkup([
        [InlineKeyboardButton("✏️ Saisir ma ville", callback_data="prof_lieu_edit")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="hub:profil:0")],
    ])
    return card("📍 MA VILLE", body, icon="📍", style="round"), markup


async def show_lieu_view(query, user_id: int):
    text, markup = _lieu_view(await get_user(user_id))
    await safe_edit(query, text, parse_mode="HTML", reply_markup=markup)


@flow("prof_lieu_text")
async def _flow_lieu(update, context, value, data):
    city = _canonical_city(value.strip())
    if len(city) > CITY_MAX:
        await ask(update, context, "prof_lieu_text",
                  f"❌ Trop long ({len(city)} caractères, maximum {CITY_MAX}). Écris juste le nom de ta ville.",
                  kind="text", back="prof_lieu")
        return
    await update_field(update.effective_user.id, "location", city)
    await update.effective_message.reply_text(
        card("📍 Ville changée", [f"Tu te trouves désormais à <b>{escape_html(city)}</b>."], icon="📍", style="round"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Profil", callback_data="hub:profil:0")]]))


# ═══════════════════════════════════════════════════════════════════
#              🏆 TOP XP
# ═══════════════════════════════════════════════════════════════════
async def show_topxp_view(query, user_id: int):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_in_query
    await show_in_query(query, user_id, 'xp')


# ═══════════════════════════════════════════════════════════════════
#              🎯 CALLBACK ROUTEUR PROFIL
# ═══════════════════════════════════════════════════════════════════
async def profile_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gère tous les callbacks commençant par 'prof_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "prof_menu":
        from handlers.hub import open_zone; await open_zone(query, "profile")
        return
    if data == "prof_stats":
        await show_stats_view(query, user_id)
        return
    if data == "prof_niveau":
        await show_niveau_view(query, user_id)
        return
    if data == "prof_badges":
        await show_badges_view(query, user_id)
        return
    if data == "prof_titres":
        await show_titres_view(query, user_id)
        return
    if data == "prof_titres_hist":
        await show_historique_titres_view(query, user_id)
        return
    if data == "prof_karma":
        await show_karma_view(query, user_id)
        return
    if data == "prof_inventaire":
        await show_inventaire_view(query, user_id)
        return
    if data == "prof_bio":
        await show_bio_view(query, user_id)
        return
    if data == "prof_bio_edit":
        await ask(query, context, "prof_bio_text",
                  f"✍️ <b>Ta biographie</b>\n\nÉcris-la en un seul message ({BIO_MAX} caractères maximum).",
                  kind="text", back="prof_bio")
        return
    if data == "prof_lieu":
        await show_lieu_view(query, user_id)
        return
    if data == "prof_lieu_edit":
        await ask(query, context, "prof_lieu_text",
                  f"📍 <b>Ta ville</b>\n\nDans quelle ville te trouves-tu ? Écris son nom ({CITY_MAX} caractères maximum).",
                  kind="text", back="prof_lieu")
        return
    if data == "prof_topxp":
        await show_topxp_view(query, user_id)
        return


# ═══════════════════════════════════════════════════════════════════
#              COMMANDES TEXTE EXISTANTES (compatibilité)
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_profil(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.reply_to_message:
        user = update.message.reply_to_message.from_user
    else:
        user = update.effective_user

    u = await get_user(user.id, user.username or "", user.full_name or "")
    if not u.get("registered"):
        await update.message.reply_text(alert("error", "Ce joueur n'est pas enregistré."), parse_mode="HTML")
        return

    lvl, xp_in, xp_for_next = xp_progress(u["xp"])
    title = get_title(u["balance"])
    age = u.get("age", 20)
    age_label, age_icon = age_stage(age)

    marriage = await get_marriage(user.id)
    partner = "💔 Célibataire"
    if marriage:
        p = await get_user(marriage["partner_id"])
        partner = f"💍 Marié(e) à <b>{p['full_name']}</b>"

    async with db_connection() as db:
        async with db.execute(
            "SELECT f.name FROM family_members fm JOIN family f ON f.family_id=fm.family_id WHERE fm.user_id=?",
            (user.id,)
        ) as cur:
            fam = await cur.fetchone()
    fam_text = f"🏠 Famille <b>{fam[0]}</b>" if fam else "🏠 Sans famille"

    from database import get_user_company
    company = await get_user_company(user.id)
    job_text = (
        f"{u.get('job', '—')} chez <b>{company['name']}</b>"
        if company else u.get('job', 'Sans emploi')
    )

    props = await get_properties(user.id)
    vehs = await get_vehicles(user.id)
    portfolio = await get_portfolio(user.id)

    bio = u.get("bio", "")
    location = u.get("location", "")

    # ⭐ Ligne de nom enrichie avec cosmétiques
    name_line = f"{u.get('profile_color', '🔵')} <b>{u['full_name']}</b>"
    if u.get('username'):
        name_line += f"  @{u['username']}"
    if u.get('profile_title'):
        name_line += f"  🏷️ {escape_html(u['profile_title'])}"
    if u.get('profile_badge'):
        name_line += f"  {u['profile_badge']}"
    if u.get('signature_emoji'):
        name_line += f"  {u['signature_emoji']}"

    body = [
        name_line,
        f"{age_icon} <b>{age} ans</b> · {age_label} · 📍 {location or '<i>lieu inconnu</i>'}",
        f"👑 <b>{title}</b>",
        f"⭐ Niveau <b>{lvl}</b> · XP <b>{xp_in}/{xp_for_next}</b> · 👑 Prestige <b>{u.get('prestige', 0)}</b>",
        f"🌟 Karma : <b>{karma_label(u.get('karma', 0))}</b> ({u.get('karma', 0):+d})",
        "",
        "<b>💗 ÉTAT</b>",
        mini_stat("Santé", u.get("health", 100), emoji="❤️"),
        mini_stat("Énergie", u.get("energy", 100), emoji="⚡"),
        mini_stat("Faim", u.get("hunger", 100), emoji="🍽️"),
        mini_stat("Bonheur", u.get("happiness", 100), emoji="😊"),
        mini_stat("Stress", u.get("stress", 0), emoji="😰", inverted=True),
        "",
        "<b>💼 PROFIL</b>",
        f"💵 Solde : <b>{fmt(u['balance'])}</b> · 🏷️ <b>{wealth_class(u['balance'])}</b>",
        f"💼 {job_text}",
        f"🎓 Diplôme : <b>{u.get('diplome', '—') or 'aucun'}</b>",
        f"{partner}",
        f"{fam_text}",
        "",
        "<b>🏠 PATRIMOINE</b>",
        f"🏘️ {len(props)} · 🚗 {len(vehs)} · 📈 {len(portfolio)}",
    ]

    # ⭐ Signature emoji
    if u.get("signature_emoji"):
        body += ["", f"<i>{u['signature_emoji']} Signature personnalisée {u['signature_emoji']}</i>"]

    if bio:
        body += ["", f"<i>📝 « {bio} »</i>"]
    from handlers.phone import get_status
    status = await get_status(user.id)
    if status:
        body += ["", f"💬 <i>{escape_html(status)}</i>"]

    texte = card(f"PROFIL DE {user.full_name.upper()}", body,
                 icon="👤", style="thick",
                 footer="Ouvre le menu → 📜 Profil pour le menu interactif.")

    try:
        photos = await context.bot.get_user_profile_photos(user.id, limit=1)
        if photos.total_count > 0:
            file_id = photos.photos[0][-1].file_id
            await update.message.reply_photo(
                photo=file_id,
                caption=texte,
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text(texte, parse_mode="HTML")
    except Exception:
        await update.message.reply_text(texte, parse_mode="HTML")


@require_registered
async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    body = [
        "<b>💰 ARGENT</b>",
        f"  💵 Solde actuel : <b>{fmt(u['balance'])}</b>",
        f"  📈 Total gagné : <b>{fmt(u.get('total_earned', 0))}</b>",
        f"  📉 Total dépensé : <b>{fmt(u.get('total_spent', 0))}</b>",
        f"  🤲 Don à la charité : <b>{fmt(u.get('charity_given', 0))}</b>",
        "",
        "<b>⚔️ PVP & CRIME</b>",
        f"  🥊 Combats : <b>{u.get('arena_wins', 0)}W</b> / <b>{u.get('arena_losses', 0)}L</b>",
        f"  💼 Crimes tentés : <b>{u.get('crimes_done', 0)}</b>",
        f"  ✅ Crimes réussis : <b>{u.get('crimes_success', 0)}</b>",
        f"  💻 Hacks : <b>{u.get('hack_attempts', 0)}</b>",
        "",
        "<b>🎯 PROGRESSION</b>",
        f"  ✅ Missions accomplies : <b>{u.get('missions_done', 0)}</b>",
        f"  ⭐ XP cumulée : <b>{u['xp']}</b>",
        f"  👑 Prestige : <b>{u.get('prestige', 0)}</b>",
        "",
        "<b>🎲 LOISIRS</b>",
        f"  🎰 Loteries gagnées : <b>{u.get('lottery_wins', 0)}</b>",
        f"  🎲 Total casino misé : <b>{fmt(u.get('casino_total_bet', 0))}</b>",
        f"  💰 Total casino gagné : <b>{fmt(u.get('casino_total_win', 0))}</b>",
        f"  🌱 Plantes cultivées : <b>{u.get('plants_grown', 0)}</b>",
        f"  ✈️ Voyages : <b>{u.get('travel_count', 0)}</b>",
        "",
        "<b>📱 SOCIAL</b>",
        f"  📱 Followers : <b>{u.get('social_followers', 0)}</b>",
        f"  📊 Influence : <b>{u.get('influence_score', 0)}</b>",
    ]
    await update.message.reply_text(
        card("STATISTIQUES DÉTAILLÉES", body, icon="📊", style="thick"),
        parse_mode="HTML",
    )


@require_registered
async def cmd_badges(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        try:
            async with db.execute("SELECT badge, earned_at FROM user_badges WHERE user_id=?", (user.id,)) as cur:
                rows = await cur.fetchall()
        except aiosqlite.OperationalError:
            rows = []
    if not rows:
        await update.message.reply_text(
            alert("info", "Tu n'as encore aucun badge.\nEnchaîne missions et succès pour en gagner !"),
            parse_mode="HTML")
        return
    body = [f"  🏅 <b>{b}</b>" for b, _ in rows]

    # Badge personnalisé
    u = await get_user(user.id)
    if u.get("profile_badge"):
        body.append(f"  {u['profile_badge']} <b>Badge personnalisé</b>")

    await update.message.reply_text(
        card(f"BADGES de {user.full_name}", body, icon="🏅", style="stars",
             footer=f"Total : {len(rows)} badges"),
        parse_mode="HTML")


@require_registered
async def cmd_bio(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Écran « Ma bio » : bouton ✏️ → le bot demande le texte, le joueur l'écrit."""
    user = update.effective_user
    if context.args:                                   # appel direct avec un texte (staff / compatibilité)
        new_bio = " ".join(context.args)[:BIO_MAX]
        await update_field(user.id, "bio", new_bio)
        await update.effective_message.reply_text(
            card("📝 Bio mise à jour", [f"<i>« {escape_html(new_bio)} »</i>"], icon="✍️", style="round"),
            parse_mode="HTML")
        return
    text, markup = _bio_view(await get_user(user.id))
    await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


@require_registered
async def cmd_setlocation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Écran « Ma ville » : bouton ✏️ → le bot demande la ville, le joueur l'écrit."""
    user = update.effective_user
    if context.args:
        loc = _canonical_city(" ".join(context.args)[:CITY_MAX])
        await update_field(user.id, "location", loc)
        await update.effective_message.reply_text(
            card("📍 Ville changée", [f"Tu te trouves désormais à <b>{escape_html(loc)}</b>."],
                 icon="📍", style="round"),
            parse_mode="HTML")
        return
    text, markup = _lieu_view(await get_user(user.id))
    await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


@require_registered
async def cmd_niveau(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    lvl, xp_in, xp_for_next = xp_progress(u["xp"])
    pct = int(xp_in / max(1, xp_for_next) * 100)
    bar = "█" * (pct // 10) + "░" * (10 - pct // 10)
    body = [
        f"⭐ Niveau actuel : <b>{lvl}</b>",
        f"📊 XP totale : <b>{u['xp']}</b>",
        "",
        f"Progression vers niveau {lvl+1} :",
        f"<code>{bar}</code> <b>{pct}%</b>",
        f"<b>{xp_in}</b> / <b>{xp_for_next}</b> XP",
    ]
    await update.message.reply_text(card("NIVEAU", body, icon="⭐", style="thick"), parse_mode="HTML")


@require_registered
async def cmd_inventaire(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    items = await get_inventory(user.id)
    if not items:
        await update.message.reply_text(
            alert("info", "Ton inventaire est vide."), parse_mode="HTML")
        return
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        body = []
        for i in items:
            item_id = i.get("item_id")
            if item_id:
                async with db.execute("SELECT emoji, name, rarity FROM items WHERE item_id = ?", (item_id,)) as cur:
                    item_def = await cur.fetchone()
                if item_def:
                    body.append(f"  <code>#{item_id}</code> {item_def['emoji']} <b>{item_def['name']}</b> ({item_def['rarity']}) ×{i['quantity']}")
                else:
                    body.append(f"  <code>#{item_id}</code> {i.get('item_name', 'Inconnu')} ×{i['quantity']}")
            else:
                body.append(f"  📦 <b>{i.get('item_name', 'Objet')}</b> ×{i['quantity']}")
    await update.message.reply_text(
        card("📦 INVENTAIRE", body, icon="📦", style="thick",
             footer=f"Total : {len(items)} items"),
        parse_mode="HTML")


@require_registered
async def cmd_titres(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from config import TITLES
    user = update.effective_user
    u = await get_user(user.id)
    current = get_title(u["balance"])
    body = []
    for t in TITLES:
        if u["balance"] >= t["min"]:
            body.append(f"  ✅ <b>{t['title']}</b> ─ {fmt(t['min'])}")
        else:
            body.append(f"  🔒 {t['title']} ─ {fmt(t['min'])}")

    # Titre personnalisé
    if u.get("profile_title"):
        body.insert(0, "")
        body.insert(0, f"  🏷️ <b>Titre personnalisé :</b> {escape_html(u['profile_title'])}")

    await update.message.reply_text(
        card(f"TITRES (actuel : {current})", body, icon="👑", style="thick"),
        parse_mode="HTML")


@require_registered
async def cmd_karma_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    k = u.get("karma", 0)
    body = [
        f"🌟 Karma : <b>{k:+d}</b>",
        f"📛 Statut : <b>{karma_label(k)}</b>",
        "",
        "<b>Effets actuels :</b>",
        "  • Bonnes actions / charité ↑ Karma",
        "  • Crimes / hacks ↓ Karma",
        "  • Karma haut : +25% revenus, succès",
        "  • Karma bas : −25% chance, pénalités",
    ]
    await update.message.reply_text(card("KARMA", body, icon="🌟", style="thick"), parse_mode="HTML")


@require_registered
async def cmd_topxp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_for_update
    await show_for_update(update, 'xp')


@require_registered
async def cmd_historiquetitres(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from config import TITLES
    user = update.effective_user
    u = await get_user(user.id)
    body = ["<b>Hiérarchie des titres :</b>", ""]
    for t in TITLES:
        unlocked = "✅" if u["balance"] >= t["min"] else "🔒"
        body.append(f"  {unlocked} <b>{t['title']}</b> ─ requiert {fmt(t['min'])}")

    if u.get("profile_title"):
        body += ["", f"🏷️ <b>Titre personnalisé :</b> {escape_html(u['profile_title'])}"]

    await update.message.reply_text(
        card("HISTORIQUE DES TITRES", body, icon="👑", style="thick"),
        parse_mode="HTML")