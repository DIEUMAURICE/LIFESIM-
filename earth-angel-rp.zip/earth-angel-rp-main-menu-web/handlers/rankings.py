# handlers/rankings.py — TOUS les classements, jusqu'au dernier joueur, au même endroit
"""
Un seul écran pour tous les classements (voir utils/rankings.py) :
  • menu des classements regroupés par rubrique, avec ta place affichée sur chacun
  • pages de 15 avec ◀️ ▶️, sauts ⏪ ⏩ (5 pages), début ⏮️ et fin ⏭️
  • « 📍 Ma position » : ouvre directement la page où tu te trouves (joueur, entreprise ou gang)
Les anciennes commandes (richesse, XP, prestige, arène, social, entreprises, gangs…) ouvrent cet écran.
"""
import logging

from telegram import Update, InlineKeyboardButton as B, InlineKeyboardMarkup as M
from telegram.ext import ContextTypes

from utils import rankings as rk
from utils.decorators import require_registered

logger = logging.getLogger(__name__)
BACK_HUB = B("🎮 Menu principal", callback_data="hub:home")


async def menu_view(user_id: int) -> tuple[str, M]:
    lines = ["🏆 <b>CLASSEMENTS</b>", "",
             "Tous les classements vont jusqu'au dernier. Si tu n'es pas dans le haut, "
             "« 📍 Ma position » t'y emmène directement.", ""]
    rows: list[list[B]] = []
    for title, keys in rk.GROUPS:
        lines.append(f"<b>{title}</b>")
        row: list[B] = []
        for k in keys:
            r = rk.RANKINGS[k]
            pos = await rk.my_position(k, user_id)
            tag = f" #{pos['rank']}" if pos else ""
            lines.append(f"  {r.emoji} {r.title}" + (f" — ton rang : <b>#{pos['rank']}</b>/{pos['total']}" if pos else ""))
            row.append(B(f"{r.emoji} {r.title[:16]}{tag}", callback_data=f"rk:v:{k}:1"))
            if len(row) == 2:
                rows.append(row)
                row = []
        if row:
            rows.append(row)
        lines.append("")
    rows.append([BACK_HUB])
    return "\n".join(lines), M(rows)


def _nav(key: str, p: dict) -> list[list[B]]:
    page, pages = p["page"], p["pages"]
    nav: list[list[B]] = []
    if pages > 1:
        nav.append([B("⏮️", callback_data=f"rk:v:{key}:1"),
                    B("⏪", callback_data=f"rk:v:{key}:{max(1, page - 5)}"),
                    B("◀️", callback_data=f"rk:v:{key}:{max(1, page - 1)}"),
                    B(f"{page}/{pages}", callback_data="rk:noop"),
                    B("▶️", callback_data=f"rk:v:{key}:{min(pages, page + 1)}"),
                    B("⏩", callback_data=f"rk:v:{key}:{min(pages, page + 5)}"),
                    B("⏭️", callback_data=f"rk:v:{key}:{pages}")])
    nav.append([B("📍 Ma position", callback_data=f"rk:me:{key}"),
                B("🏆 Tous les classements", callback_data="rk:menu")])
    return nav


async def view(user_id: int, key: str, page: int = 1) -> tuple[str, M]:
    key = rk.ALIASES.get(key, key)
    if key not in rk.RANKINGS:
        return await menu_view(user_id)
    p = await rk.get_page(key, page, user_id)
    return rk.render_page(p), M(_nav(key, p) + [[BACK_HUB]])


async def me_view(user_id: int, key: str) -> tuple[str, M]:
    pos = await rk.my_position(key, user_id)
    page = pos["page"] if pos else 1
    return await view(user_id, key, page)


async def show_in_query(query, user_id: int, key: str | None = None, page: int = 1) -> None:
    """Affiche un classement (ou le menu) en éditant le message du bouton."""
    text, markup = await (view(user_id, key, page) if key else menu_view(user_id))
    try:
        await query.edit_message_text(text[:4000], parse_mode="HTML", reply_markup=markup)
    except Exception as e:
        if "not modified" not in str(e).lower():
            logger.warning("rankings edit: %s", e)


async def show_for_update(update: Update, key: str | None = None) -> None:
    uid = update.effective_user.id
    text, markup = await (view(uid, key, 1) if key else menu_view(uid))
    await update.effective_message.reply_text(text[:4000], parse_mode="HTML", reply_markup=markup)


@require_registered
async def cmd_classements_tous(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_for_update(update)


async def rk_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    p = (q.data or "").split(":")[1:]
    await q.answer()
    uid = q.from_user.id
    act = p[0] if p else "menu"
    if act == "noop":
        return
    if act == "v" and len(p) >= 3 and p[2].lstrip("-").isdigit():
        await show_in_query(q, uid, p[1], int(p[2]))
    elif act == "me" and len(p) >= 2 and p[1] in rk.RANKINGS:
        text, markup = await me_view(uid, p[1])
        try:
            await q.edit_message_text(text[:4000], parse_mode="HTML", reply_markup=markup)
        except Exception as e:
            if "not modified" not in str(e).lower():
                logger.warning("rankings edit: %s", e)
    else:
        await show_in_query(q, uid)
