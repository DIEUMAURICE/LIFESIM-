# handlers/education.py
from utils.swallow import swallowed
import random
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import db_connection, DB_PATH, get_user, update_field, update_balance, increment_field, upgrade_skill, get_all_skills
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, fmt_time, now, escape_html
from utils.vip import add_xp
from utils import courses
import gameplay.education as edu_service
from config import (
    DIPLOMES, DIPLOME_COSTS, DIPLOME_STUDY_TIME, DIPLOME_PASS_RATE, DIPLOME_SALARY_BONUS,
    SKILLS, SKILL_LEVEL_COST,
    DIPLOMES_EXTENDED, DIPLOME_COSTS_EXTENDED, DIPLOME_STUDY_TIME_EXTENDED,
    DIPLOME_PASS_RATE_EXTENDED, DIPLOME_SALARY_BONUS_EXTENDED
)
from utils.gametime import add_game_months
from utils.helpers import safe_edit

# Fusion des listes et dictionnaires
# DIPLOMES_EXTENDED reprend déjà tous les diplômes de base : on fusionne sans doublon (ordre de la liste étendue)
ALL_DIPLOMES = list(dict.fromkeys(DIPLOMES_EXTENDED + DIPLOMES))
ALL_COSTS = {**DIPLOME_COSTS, **DIPLOME_COSTS_EXTENDED}
ALL_STUDY_TIME = {**DIPLOME_STUDY_TIME, **DIPLOME_STUDY_TIME_EXTENDED}
ALL_PASS_RATE = {**DIPLOME_PASS_RATE, **DIPLOME_PASS_RATE_EXTENDED}
ALL_SALARY_BONUS = {**DIPLOME_SALARY_BONUS, **DIPLOME_SALARY_BONUS_EXTENDED}

DIPLOME_ORDER = ALL_DIPLOMES


def next_diplome(current: str) -> str | None:
    if not current:
        return DIPLOME_ORDER[0]
    if current in DIPLOME_ORDER:
        idx = DIPLOME_ORDER.index(current)
        if idx + 1 < len(DIPLOME_ORDER):
            return DIPLOME_ORDER[idx + 1]
    return None


# ═══════════════════════════════════════════════════════════════════
#              📚 SOUS-MENU : FORMATIONS (boutons)
# ═══════════════════════════════════════════════════════════════════
async def show_formations_menu(query, user_id: int):
    u = await get_user(user_id)
    current = u.get("diplome", "")
    next_d = next_diplome(current)

    body = [
        f"🎓 Diplôme actuel : <b>{escape_html(current) or 'Aucun'}</b>",
        "",
        "<i>Tape sur un diplôme pour voir les détails et t'inscrire.</i>",
    ]

    keyboard = []
    for i, dip in enumerate(DIPLOME_ORDER):
        cost = ALL_COSTS[dip]
        # Marquer l'état
        if current and dip in DIPLOME_ORDER and DIPLOME_ORDER.index(dip) <= DIPLOME_ORDER.index(current):
            marker = "✅"
            locked = True
        elif dip == next_d:
            marker = "▶️"
            locked = False
        else:
            marker = "🔒"
            locked = True

        keyboard.append([
            InlineKeyboardButton(
                f"{marker} {dip} — {fmt(cost)}",
                callback_data=f"edu_view_{i}"
            )
        ])

    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="edu_menu")])

    await safe_edit(
        query,
        "📚 <b>FORMATIONS DISPONIBLES</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def show_diplome_details(query, user_id: int, dip_index: int):
    if dip_index < 0 or dip_index >= len(DIPLOME_ORDER):
        await safe_edit(query, "❌ Diplôme invalide.", reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("⬅️ Retour", callback_data="edu_formations")
        ]]))
        return

    dip = DIPLOME_ORDER[dip_index]
    cost = ALL_COSTS[dip]
    duration = ALL_STUDY_TIME[dip]
    pass_rate = ALL_PASS_RATE[dip]
    bonus = ALL_SALARY_BONUS[dip]

    u = await get_user(user_id)
    current = u.get("diplome", "")
    next_d = next_diplome(current)

    body = [
        f"🎓 <b>{escape_html(dip)}</b>",
        "",
        f"💰 Coût d'inscription : <b>{fmt(cost)}</b>",
        f"⏱️ Durée d'étude : <b>{fmt_time(duration)}</b>",
        f"🎲 Taux de réussite de base : <b>{int(pass_rate * 100)}%</b>",
        f"💼 Bonus salaire : <b>×{bonus}</b>",
        "",
    ]

    if current and dip in DIPLOME_ORDER and DIPLOME_ORDER.index(dip) <= DIPLOME_ORDER.index(current):
        body.append("✅ <b>Diplôme déjà obtenu</b>")
        keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="edu_formations")]]
    elif dip == next_d:
        body.append("▶️ <b>Prochain diplôme à obtenir</b>")
        keyboard = [
            [InlineKeyboardButton(f"📝 S'inscrire ({fmt(cost)})", callback_data=f"edu_inscrire_{dip_index}")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="edu_formations")],
        ]
    else:
        body.append(f"🔒 <b>Bloqué</b> — Obtiens d'abord <b>{escape_html(next_d or '?')}</b>")
        keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="edu_formations")]]

    await safe_edit(
        query,
        "📚 <b>DÉTAIL DE LA FORMATION</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_inscription(query, user_id: int, dip_index: int):
    try:
        r = await edu_service.enroll(user_id, dip_index)
    except edu_service.EducationError as e:
        await safe_edit(query, f"❌ {escape_html(str(e))}", parse_mode="HTML",
                         reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="edu_formations")]]))
        return
    dip = r["diploma"]
    await safe_edit(
        query,
        f"✅ <b>Inscription réussie !</b>\n\n"
        f"🎓 Formation : <b>{escape_html(dip)}</b>\n"
        f"💰 Payé : <b>{fmt(r['cost'])}</b>\n"
        f"⏱️ Durée : <b>{fmt_time(r['duration'])}</b>\n\n"
        f"📖 Utilise <b>Réviser</b> : chaque révision te donne un <b>cours</b> à apprendre (max {courses.MAX_REVISIONS}).\n"
        f"📝 Quand le temps est écoulé, l'<b>examen</b> te pose des questions sur les cours que tu as révisés.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📖 Réviser", callback_data="edu_reviser")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="edu_menu")],
        ])
    )



# ═══════════════════════════════════════════════════════════════════
#              🎯 SOUS-MENU : COMPÉTENCES
# ═══════════════════════════════════════════════════════════════════
async def show_competences_menu(query, user_id: int):
    skills = await get_all_skills(user_id)

    body = [
        "<i>Tape sur une compétence pour l'améliorer.</i>",
        "",
    ]

    if skills:
        body.append("<b>Tes compétences actuelles :</b>")
        for name, lvl in sorted(skills.items(), key=lambda x: -x[1]):
            stars = "⭐" * min(10, lvl // 10)
            body.append(f"  🧠 <b>{escape_html(name)}</b> — Niv.<b>{lvl}</b> {stars}")
    else:
        body.append("<i>Tu n'as encore aucune compétence améliorée.</i>")

    keyboard = []
    for i, skill in enumerate(SKILLS):
        current_lvl = skills.get(skill, 0)
        cost = SKILL_LEVEL_COST * (current_lvl + 1)
        keyboard.append([
            InlineKeyboardButton(
                f"🧠 {skill} (Niv.{current_lvl} → {current_lvl+1}) · {fmt(cost)}",
                callback_data=f"edu_skill_{i}"
            )
        ])

    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="edu_menu")])

    await safe_edit(
        query,
        "🎯 <b>COMPÉTENCES</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_ameliorer_skill(query, user_id: int, skill_index: int):
    try:
        r = await edu_service.upgrade_skill_level(user_id, skill_index)
    except edu_service.EducationError as e:
        await safe_edit(query, f"❌ {escape_html(str(e))}", parse_mode="HTML",
                         reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="edu_competences")]]))
        return
    await safe_edit(
        query,
        f"🧠 <b>Formation réussie !</b>\n\n"
        f"🎯 Compétence : <b>{escape_html(r['skill'])}</b>\n"
        f"📈 Niveau : <b>{r['level'] - 1} → {r['level']}</b>\n"
        f"💰 Coût : <b>{fmt(r['cost'])}</b>\n"
        f"✨ +{r['xp_gain']} XP\n\n"
        f"➡️ Prochain niveau : <b>{fmt(r['next_cost'])}</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🧠 Améliorer encore", callback_data="edu_competences")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="edu_menu")],
        ])
    )



# ═══════════════════════════════════════════════════════════════════
#              📖 RÉVISER (bouton)
# ═══════════════════════════════════════════════════════════════════
def _back_kb(extra=None):
    rows = list(extra or [])
    rows.append([InlineKeyboardButton("⬅️ Retour", callback_data="edu_menu")])
    return InlineKeyboardMarkup(rows)


async def do_reviser_btn(query, user_id: int):
    """Réviser = recevoir un COURS à apprendre (l'examen portera sur les cours révisés)."""
    try:
        r = await edu_service.revise(user_id)
    except edu_service.EducationError as e:
        extra = [[InlineKeyboardButton("📚 Mes cours", callback_data="edu_cours")]] if e.code == "max_revisions" else None
        await safe_edit(query, f"❌ {escape_html(str(e))}", reply_markup=_back_kb(extra))
        return
    les = r["lesson"]
    footer = f"⏳ Examen dans <b>{fmt_time(r['remaining_seconds'])}</b>" if not r["exam_ready"] else "✅ Tu peux passer l'examen !"
    kb = []
    if r["revisions"] < r["max_revisions"]:
        kb.append([InlineKeyboardButton("📖 Réviser un autre cours", callback_data="edu_reviser")])
    kb.append([InlineKeyboardButton("📚 Mes cours", callback_data="edu_cours"),
               InlineKeyboardButton("📝 Examen", callback_data="edu_examen")])
    await safe_edit(
        query,
        f"📖 <b>COURS {r['revisions']}/{r['max_revisions']} — {escape_html(les['title'])}</b>\n"
        f"<i>{les['theme']}</i>\n━━━━━━━━━━━━━━━━━━━━━━\n"
        f"{les['text']}\n\n"
        f"💡 <i>Retiens bien : l'examen te posera des questions sur ce cours.</i>\n\n"
        f"⚡ Énergie : <b>{r['energy']}%</b> · 😰 Stress : <b>{r['stress']}%</b>\n{footer}",
        parse_mode="HTML", reply_markup=_back_kb(kb))


async def show_cours_menu(query, user_id: int):
    """Bibliothèque : tous les cours déjà révisés, relisibles à volonté."""
    lib = await courses.library(user_id)
    if not lib:
        await safe_edit(query, "📚 <b>Mes cours</b>\n\nTu n'as encore révisé aucun cours. Inscris-toi puis "
                               "utilise <b>📖 Réviser</b>.", reply_markup=_back_kb())
        return
    rows = []
    lines = ["📚 <b>Mes cours</b>", "<i>Relis-les avant l'examen !</i>", ""]
    for i, (lid, dip) in enumerate(lib):
        les = courses.lesson(lid)
        if not les:
            continue
        lines.append(f"{i + 1}. {les['theme']} — {escape_html(les['title'])}")
        rows.append([InlineKeyboardButton(f"{i + 1}. {les['title'][:40]}", callback_data=f"edu_lecon_{i}")])
    await safe_edit(query, "\n".join(lines), reply_markup=_back_kb(rows))


async def show_lecon(query, user_id: int, index: int):
    lib = await courses.library(user_id)
    if index < 0 or index >= len(lib):
        await show_cours_menu(query, user_id)
        return
    les = courses.lesson(lib[index][0])
    if not les:
        await show_cours_menu(query, user_id)
        return
    await safe_edit(
        query, f"📖 <b>{escape_html(les['title'])}</b>\n<i>{les['theme']}</i>\n━━━━━━━━━━━━━━━━━━━━━━\n{les['text']}",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📚 Mes cours", callback_data="edu_cours")],
                                           [InlineKeyboardButton("⬅️ Retour", callback_data="edu_menu")]]))


# ═══════════════════════════════════════════════════════════════════
#              📝 EXAMEN PAR QUESTIONS (sur les cours révisés)
# ═══════════════════════════════════════════════════════════════════
def _question_view(ex: dict) -> tuple[str, InlineKeyboardMarkup]:
    q = ex["questions"][ex["pos"]]
    letters = "ABCD"
    lines = [f"📝 <b>EXAMEN — Question {ex['pos'] + 1}/{ex['total']}</b>", "━━━━━━━━━━━━━━━━━━━━━━",
             f"<b>{escape_html(q['q'])}</b>", ""]
    rows = []
    for i, c in enumerate(q["choices"]):
        lines.append(f"{letters[i]}. {escape_html(c)}")
        rows.append([InlineKeyboardButton(f"{letters[i]}. {c[:50]}", callback_data=f"edu_rep_{i}")])
    return "\n".join(lines), InlineKeyboardMarkup(rows)


async def do_examen_btn(query, user_id: int):
    try:
        ex = await edu_service.start_or_continue_exam(user_id)
    except edu_service.EducationError as e:
        extra = [[InlineKeyboardButton("📖 Réviser", callback_data="edu_reviser")]] if e.code in ("too_early", "no_lessons") else None
        await safe_edit(query, f"❌ {escape_html(str(e))}", reply_markup=_back_kb(extra))
        return
    if ex.get("finished"):
        await _show_exam_result(query, ex)
        return
    letters = "ABCD"
    lines = [f"📝 <b>EXAMEN — Question {ex['pos'] + 1}/{ex['total']}</b>", "━━━━━━━━━━━━━━━━━━━━━━",
             f"<b>{escape_html(ex['question'])}</b>", ""]
    rows = []
    for i, c in enumerate(ex["choices"]):
        lines.append(f"{letters[i]}. {escape_html(c)}")
        rows.append([InlineKeyboardButton(f"{letters[i]}. {c[:50]}", callback_data=f"edu_rep_{i}")])
    text = "\n".join(lines)
    if ex["pos"] == 0:
        text = (f"🎓 <b>{escape_html(ex['diploma'])}</b> — il faut <b>{ex['needed']}/{ex['total']}</b> bonnes réponses.\n"
                f"<i>Les questions portent sur les cours que tu as révisés.</i>\n\n") + text
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(rows))


async def do_reponse(query, user_id: int, choice: int):
    try:
        res = await edu_service.answer_exam(user_id, choice)
    except edu_service.EducationError:
        await do_examen_btn(query, user_id)
        return
    verdict = "✅ <b>Bonne réponse !</b>" if res["correct"] else f"❌ <b>Faux.</b> Bonne réponse : <b>{escape_html(res['right_answer'])}</b>"
    if res["why"]:
        verdict += f"\n<i>{escape_html(res['why'])}</i>"
    label = "➡️ Question suivante" if not res["finished"] else "🏁 Voir mon résultat"
    await safe_edit(query, f"{verdict}\n\n📊 Score : <b>{res['score']}/{res['total']}</b>", parse_mode="HTML",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(label, callback_data="edu_suite")]]))


async def finalize_exam(query, user_id: int):
    """Corrige l'examen (callback edu_suite quand la dernière réponse a atteint pos>=total)."""
    try:
        result = await edu_service.finalize_exam(user_id)
    except edu_service.EducationError as e:
        await safe_edit(query, f"❌ {escape_html(str(e))}", reply_markup=_back_kb())
        return
    await _show_exam_result(query, result)


async def _show_exam_result(query, r: dict):
    """Affiche le même texte de réussite/échec que le bot d'origine, à partir du résultat du service."""
    dip = r["diploma"]
    if r["success"]:
        from config import JOBS as _JOBS  # noqa: F401 (jobs déjà résolus par le service)
        body = [
            "🎉 <b>FÉLICITATIONS !</b>",
            f"Tu as obtenu ton <b>{escape_html(dip)}</b> !",
            "",
            f"✅ Note : <b>{r['score']}/{r['total']}</b> — mention <b>{escape_html(r['mention'])}</b>",
            "",
            "🎁 <b>Ce que ton diplôme t'apporte :</b>",
            f"  • +{r['xp_gain']:,} XP · +{r['prestige_gain']} Prestige",
            f"  • Bonus de salaire : <b>×{r['salary_bonus']}</b>",
            ("  • Métiers débloqués : <b>" + ", ".join(r['jobs_unlocked']) + "</b>") if r['jobs_unlocked'] else "  • Un salaire plus élevé dans tous tes métiers",
        ]
    else:
        body = [
            "😢 <b>ÉCHEC...</b>",
            f"Tu n'as pas obtenu ton <b>{escape_html(dip)}</b>.",
            "",
            f"📊 Note : <b>{r['score']}/{r['total']}</b> — il fallait <b>{r['needed']}/{r['total']}</b>.",
            f"😰 Stress : +{r['stress_gain']}%",
            "",
            "💡 <b>Conseils :</b>",
            "  • Révise plus de cours (jusqu'à 5) : plus tu en connais, mieux tu réponds",
            "  • Relis tes cours dans « Mes cours » avant de te réinscrire",
            "",
            f"💰 Pour repasser : <b>{fmt(r['retry_cost'])}</b>",
        ]
    await safe_edit(
        query, "\n".join(body), parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📚 Voir les formations", callback_data="edu_formations")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="edu_menu")],
        ]))


class _MsgQuery:
    """Fait passer un message (commande /reviser, /examen) pour un callback : les écrans s'affichent en nouveau message."""
    def __init__(self, message):
        self.message = message
        self.from_user = message.from_user if hasattr(message, "from_user") else None

    async def edit_message_text(self, text, parse_mode=None, reply_markup=None, **k):
        await self.message.reply_text(text, parse_mode=parse_mode, reply_markup=reply_markup)

    async def answer(self, *a, **k):
        return None


# ═══════════════════════════════════════════════════════════════════
#              🎯 CALLBACK ROUTEUR ÉDUCATION
# ═══════════════════════════════════════════════════════════════════
async def education_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gère tous les callbacks commençant par 'edu_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "edu_menu":
        from handlers.hub import open_zone; await open_zone(query, "career")
        return

    if data == "edu_formations":
        await show_formations_menu(query, user_id)
        return

    if data.startswith("edu_view_"):
        try:
            idx = int(data.replace("edu_view_", ""))
        except ValueError:
            return
        await show_diplome_details(query, user_id, idx)
        return

    if data.startswith("edu_inscrire_"):
        try:
            idx = int(data.replace("edu_inscrire_", ""))
        except ValueError:
            return
        await do_inscription(query, user_id, idx)
        return

    if data == "edu_competences":
        await show_competences_menu(query, user_id)
        return

    if data == "edu_ameliorer_menu":
        await show_competences_menu(query, user_id)
        return

    if data.startswith("edu_skill_"):
        try:
            idx = int(data.replace("edu_skill_", ""))
        except ValueError:
            return
        await do_ameliorer_skill(query, user_id, idx)
        return

    if data == "edu_reviser":
        await do_reviser_btn(query, user_id)
        return

    if data == "edu_examen":
        await do_examen_btn(query, user_id)
        return

    if data == "edu_suite":
        await do_examen_btn(query, user_id)
        return

    if data.startswith("edu_rep_"):
        try:
            await do_reponse(query, user_id, int(data.replace("edu_rep_", "")))
        except ValueError:
            swallowed('handlers/education.py')
        return

    if data == "edu_cours":
        await show_cours_menu(query, user_id)
        return

    if data.startswith("edu_lecon_"):
        try:
            await show_lecon(query, user_id, int(data.replace("edu_lecon_", "")))
        except ValueError:
            swallowed('handlers/education.py')
        return

    if data == "edu_metier":
        # Vue interactive « Mon métier » (changer / arrêter), partagée avec le menu Carrière
        from handlers.work import build_metier_view
        text, markup = await build_metier_view(user_id)
        await safe_edit(query, text, reply_markup=markup)
        return

    if data == "edu_promotion":
        # Même logique que /promotion (compétences + activité), déclenchée par bouton
        from handlers.work import cmd_promotion
        await cmd_promotion(update, context)
        return


# ═══════════════════════════════════════════════════════════════════
#              COMMANDES TEXTE EXISTANTES (compatibilité)
# ═══════════════════════════════════════════════════════════════════
@require_registered
@require_free
async def cmd_etudes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    current = u.get("diplome", "")

    text = "🎓 <b>Formations disponibles</b>\n\n"
    for dip in DIPLOME_ORDER:
        cost = ALL_COSTS[dip]
        time_req = ALL_STUDY_TIME[dip]
        chance = int(ALL_PASS_RATE[dip] * 100)
        bonus = ALL_SALARY_BONUS[dip]
        status = ""
        if current == dip:
            status = " ✅ OBTENU"
        elif current and DIPLOME_ORDER.index(dip) < DIPLOME_ORDER.index(current):
            status = " ✅ OBTENU"
        next_d = next_diplome(current)
        if dip == next_d:
            status += " 👈 SUIVANT"
        text += (
            f"📚 <b>{escape_html(dip)}</b>{escape_html(status)}\n"
            f"  💰 Coût : {escape_html(fmt(cost))} | ⏱️ Étude : {escape_html(fmt_time(time_req))}\n"
            f"  🎲 Chance de réussite : {escape_html(chance)}% | 💼 Bonus salaire : x{escape_html(bonus)}\n\n"
        )
    text += "<i>Utilise le menu pour commencer.</i>\n"
    text += "<i>Ou Ouvre le menu → 🎓 Carrière pour le menu interactif.</i>"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
@cooldown("study_cooldown", 10, "⏳ Attends un instant avant de t'inscrire à une nouvelle formation.")
async def cmd_etudier(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🎓 Carrière → Études & diplômes.")
        return

    dip = " ".join(context.args).capitalize()
    matched = None
    for d in DIPLOME_ORDER:
        if d.lower() == dip.lower():
            matched = d
            break
    if not matched:
        await update.message.reply_text(f"❌ Diplôme inconnu. Choix : {', '.join(DIPLOME_ORDER)}")
        return

    try:
        r = await edu_service.enroll(user.id, DIPLOME_ORDER.index(matched))
    except edu_service.EducationError as e:
        await update.message.reply_text(f"❌ {e}")
        return

    await update.message.reply_text(
        f"📚 <b>Inscription à la formation : {escape_html(r['diploma'])}</b>\n\n"
        f"💰 Frais payés : {escape_html(fmt(r['cost']))}\n"
        f"⏱️ Durée d'étude : {escape_html(fmt_time(r['duration']))}\n"
        f"🎲 Taux de réussite de base : {escape_html(int(r['pass_rate'] * 100))}%\n\n"
        f"⏰ Reviens dans {escape_html(fmt_time(r['duration']))} pour passer l'examen depuis le menu\n"
        f"👉 Ou utilise le menu → 🎓 Carrière pour le menu interactif.",
        parse_mode="HTML"
    )


@require_registered
@require_free
@cooldown("revision_cooldown", 300, "⏳ Tu es fatigué(e) intellectuellement. Révise dans quelques minutes.")
async def cmd_reviser(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/reviser — reçoit un cours à apprendre (mêmes écrans que le bouton)."""
    await do_reviser_btn(_MsgQuery(update.message), update.effective_user.id)


@require_registered
async def cmd_cours(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/cours — relire les cours déjà révisés."""
    await show_cours_menu(_MsgQuery(update.message), update.effective_user.id)


@require_registered
@require_free
async def cmd_examen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/examen — passe l'examen par questions (mêmes écrans que le bouton)."""
    await do_examen_btn(_MsgQuery(update.message), update.effective_user.id)


@require_registered
@require_free
@cooldown("formation_cooldown", 300, "⏳ Tu viens de suivre une formation. Attends un peu.")
async def cmd_formation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not context.args:
        skills_text = "\n".join(f"• {s}" for s in SKILLS)
        await update.message.reply_text(
            f"🧠 <b>Compétences disponibles</b>\n\n{escape_html(skills_text)}\n\n"
            f"Ouvre cette action depuis 🎮 Menu → 🎓 Carrière → Études &amp; diplômes."
            f"💰 Coût : {escape_html(fmt(SKILL_LEVEL_COST))} par niveau\n"
            f"👉 Ou utilise le menu → 🎓 Carrière",
            parse_mode="HTML"
        )
        return

    skill = " ".join(context.args).capitalize()
    matched = None
    for s in SKILLS:
        if s.lower() == skill.lower():
            matched = s
            break
    if not matched:
        await update.message.reply_text(f"❌ Compétence inconnue. Choix : {', '.join(SKILLS)}")
        return

    try:
        r = await edu_service.upgrade_skill_level(user.id, SKILLS.index(matched))
    except edu_service.EducationError as e:
        await update.message.reply_text(f"❌ {e}")
        return

    await update.message.reply_text(
        f"🧠 <b>Formation : {escape_html(r['skill'])}</b>\n\n"
        f"📈 Niveau : {escape_html(r['level'] - 1)} → <b>{escape_html(r['level'])}</b>\n"
        f"💰 Coût : {escape_html(fmt(r['cost']))}\n"
        f"✨ +{r['xp_gain']} XP\n\n"
        f"<i>Prochain niveau : {escape_html(fmt(r['next_cost']))}</i>",
        parse_mode="HTML"
    )


@require_registered
async def cmd_competences(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    skills = await get_all_skills(user.id)

    if not skills:
        await update.message.reply_text(
            "🧠 Tu n'as aucune compétence améliorée.\n"
            "👉 Utilise le menu pour commencer."
        )
        return

    import html as _html
    text = f"🧠 <b>Compétences de {_html.escape(user.full_name)}</b>\n\n"
    for skill, level in sorted(skills.items(), key=lambda x: -x[1]):
        stars = "⭐" * min(10, level // 10) + "☆" * max(0, 10 - level // 10)
        desc = _skill_desc(skill, level)
        text += f"<b>{_html.escape(str(skill))}</b> Niv.{level}\n{stars}\n<i>{_html.escape(str(desc))}</i>\n\n"
        if len(text) > 3800:
            text += "<i>...</i>"
            break
    await update.message.reply_text(text, parse_mode="HTML")


def _skill_desc(skill: str, level: int) -> str:
    descs = {
        "Charisme":      f"+{level * 5}% succès social",
        "Intelligence":  f"+{level * 3}% succès examen",
        "Force":         f"+{level * 5}% puissance combat",
        "Agilité":       f"+{level * 4}% esquive",
        "Négociation":   f"-{level * 2}% prix achat",
        "Leadership":    f"+{level * 3}% moral employés",
        "Créativité":    f"+{level * 5}% revenus artistiques",
        "Technique":     f"+{level * 4}% succès hack",
        "Endurance":     f"+{level * 10} énergie max",
        "Discrétion":    f"+{level * 5}% succès crime",
    }
    return descs.get(skill, f"Niv.{level}")


async def get_skill_level(user_id: int, skill_name: str) -> int:
    from database import get_skill
    return await get_skill(user_id, skill_name)


async def process_education_maintenance():
    async with db_connection() as db:
        await db.execute(
            "UPDATE users SET study_start=0, study_diplome='', study_effort=1.0, study_revisions=0 "
            "WHERE study_start > 0 AND study_start < ?",
            (add_game_months(now(), -1),)
        )
        await db.commit()