# handlers/reglement.py — 📜 Règlement RP, 🎙️ Dossier d'entretien (staff) — préfixe `rg:`
from utils.ui import esc
import html
import logging

from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M, Update
from telegram.ext import ContextTypes

from config import GOV_FACTIONS, role_level
from database import db_connection, get_user
from utils.decorators import get_user_role_async, require_registered
from utils.input_flow import ask, flow

logger = logging.getLogger(__name__)
CB = "rg:"
SEP = "━━━━━━━━━━━━━━━━━━"

PAGES = [
    ("🎭 L'esprit du jeu",
     "Ici, on ne « joue » pas seulement : on <b>vit</b>. Chaque joueur est un personnage dans un monde partagé.\n\n"
     "• Reste dans ton rôle : parle et agis comme ton personnage\n"
     "• Respecte les autres joueurs : le plaisir de l'un fait celui de tous\n"
     "• Une belle histoire vaut mieux qu'une victoire facile\n"
     "• Solo ou à plusieurs : chacun a sa place"),
    ("⚖️ Règles générales",
     "<b>Interdit</b>\n"
     "• <b>Métagaming</b> : utiliser une information apprise hors du jeu\n"
     "• <b>Powergaming</b> : imposer une action à un autre joueur sans lui laisser de choix\n"
     "• <b>Abus</b> de bug ou de faille : on le signale au staff (🚨 Signalements)\n"
     "• Multi-comptes, spam, harcèlement, propos haineux ou contenu inapproprié\n\n"
     "<b>Attendu</b>\n"
     "• Fair-play dans les duels, crimes et enquêtes\n"
     "• Actions cohérentes avec ton métier, ton rang et ton histoire"),
    ("🏛️ Autorité & argent public",
     "Police, armée, justice, santé et Administration ont des pouvoirs : <b>ils servent le jeu, pas l'intérêt personnel</b>.\n\n"
     "• Un abus d'autorité (arrestation sans raison RP, favoritisme, détournement) est sanctionné\n"
     "• L'argent du <b>Trésor public</b> est celui de tous : toute dotation est journalisée et visible\n"
     "• Respecte la hiérarchie de ta faction, discute en RP avant de contester\n"
     "• Un conflit d'intérêts (juger un proche, se verser des fonds) se déclare ou se récuse"),
    ("🎙️ Les chefs nommés par le staff",
     "Dans certaines factions, <b>le staff nomme le chef</b> (DG police, armée, justice, santé). "
     "Cela garantit une direction sérieuse.\n\n"
     "<b>Le chemin</b>\n"
     "1. Candidature : tu montres ta motivation\n"
     "2. <b>Entretien RP</b> avec le staff (discussion via le bot)\n"
     "3. Le staff consulte ton <b>parcours</b> : faction, diplôme, compétences, entreprise\n"
     "4. Décision : nomination, refus ou conseil de progression\n"
     "5. Période d'essai : un chef qui abuse ou disparaît peut être remplacé\n\n"
     "<i>Le président élu, lui, nomme les ministres : chacun dirige une faction d'État (Police, Armée, Justice, Santé) ou l'Économie.</i>"),
    ("🚨 Sanctions",
     "Le staff applique une échelle graduée, toujours expliquée :\n\n"
     "1. ⚠️ Avertissement\n"
     "2. 🔇 Sourdine (réseau) ou limitation temporaire\n"
     "3. ⛔ Suspension\n"
     "4. 🔨 Bannissement (cas graves ou répétés)\n\n"
     "Une décision se conteste calmement auprès d'un admin supérieur. "
     "Les décisions du staff sont journalisées."),
]


async def _send(update: Update, text: str, markup: M) -> None:
    q = update.callback_query
    if q:
        try:
            await q.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
            return
        except Exception:
            await q.message.reply_text(text, parse_mode="HTML", reply_markup=markup)
            return
    await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


def _nav(rows=None) -> M:
    rows = list(rows or [])
    rows.append([B("📜 Règlement", callback_data=CB + "p:0"), B("🎮 Menu", callback_data="menu_main")])
    return M(rows)


async def show_page(update: Update, n: int) -> None:
    n = max(0, min(n, len(PAGES) - 1))
    title, body = PAGES[n]
    pager = []
    if n > 0:
        pager.append(B("◀️", callback_data=f"{CB}p:{n - 1}"))
    pager.append(B(f"{n + 1}/{len(PAGES)}", callback_data=f"{CB}p:{n}"))
    if n < len(PAGES) - 1:
        pager.append(B("▶️", callback_data=f"{CB}p:{n + 1}"))
    rows = [pager]
    await _send(update, f"📜 <b>RÈGLEMENT RP</b> — {title}\n{SEP}\n{body}", _nav(rows))


@flow("rg_interview")
async def _flow_interview(update, context, value, data):
    cand, _name = value
    await show_interview(update, update.effective_user.id, cand)


async def show_interview(update: Update, staff_id: int, cand: int) -> None:
    role = await get_user_role_async(staff_id)
    if role_level(role) < role_level("GAME_LEADER"):
        await _send(update, "🎙️ Réservé à la direction du jeu (Game Leader et au-dessus).", _nav())
        return
    u = await get_user(cand)
    if not u.get("registered"):
        await _send(update, "❌ Joueur introuvable.", _nav())
        return
    from utils.factions import get_membership
    m = await get_membership(cand)
    fac = f"{GOV_FACTIONS[m['faction']]['emoji']} {GOV_FACTIONS[m['faction']]['name']} — {esc(str(m['rank_name']))}" if m else "aucune faction"
    name = u.get("full_name") or u.get("username") or str(cand)
    async with db_connection() as db:
        async with db.execute("SELECT skill_name, level FROM skills WHERE user_id=? AND skill_name IN "
                              "('Leadership','Négociation','Intelligence','Charisme')", (cand,)) as cur:
            skills = {r[0]: r[1] for r in await cur.fetchall()}
        async with db.execute("SELECT name, poste FROM companies c JOIN company_members m ON m.company_id=c.company_id "
                              "WHERE m.user_id=? AND c.dissolved=0", (cand,)) as cur:
            jobs = [f"{esc(str(r[0]))} ({esc(str(r[1]))})" for r in await cur.fetchall()]
    lines = [f"🎙️ <b>DOSSIER D'ENTRETIEN</b>\n{SEP}", f"👤 <b>{esc(str(name))}</b> (<code>{cand}</code>)",
             f"🎖️ Faction : {fac}", f"🎓 Diplôme : {esc(str(u.get('diplome') or 'aucun'))}",
             "🧠 Compétences : " + (", ".join(f"{k} {v}" for k, v in skills.items()) or "aucune"),
             "🏢 Entreprise : " + (", ".join(jobs) or "aucune"), "",
             "<i>Mène l'entretien en RP (chat du bot), puis nomme depuis « Direction de faction ».</i>"]
    await _send(update, "\n".join(lines), _nav([[B("🎙️ Autre candidat", callback_data=CB + "int")]]))


@require_registered
async def cmd_reglement(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_page(update, 0)


@require_registered
async def cmd_entretien_chef(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if role_level(await get_user_role_async(uid)) < role_level("GAME_LEADER"):
        await _send(update, "🎙️ Réservé à la direction du jeu (Game Leader et au-dessus).", _nav())
        return
    await ask(update, context, "rg_interview", "🎙️ Quel candidat ? Envoie son <b>@pseudo</b> ou son <b>ID</b>.",
              kind="user", back=CB + "p:3")


async def rg_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    p = (q.data or "").split(":")
    action = p[1] if len(p) > 1 else "p"
    try:
        await q.answer()
        if action == "int":
            if role_level(await get_user_role_async(uid)) < role_level("GAME_LEADER"):
                await show_page(update, 3)
                return
            await ask(q, context, "rg_interview", "🎙️ Quel candidat ? Envoie son <b>@pseudo</b> ou son <b>ID</b>.",
                      kind="user", back=CB + "p:3")
        else:
            await show_page(update, int(p[2]) if len(p) > 2 and p[2].isdigit() else 0)
    except Exception:
        logger.exception("Règlement RP : erreur sur %s", q.data)
