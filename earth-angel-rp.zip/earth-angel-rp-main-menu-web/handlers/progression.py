from utils.gamerules import faucet
import asyncio
import io
import math
from datetime import datetime

import aiosqlite
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from config import STARTING_BALANCE
from database import (
    db_connection,
    DeferredReply,
    DB_PATH,
    add_life_journal,
    get_inventory,
    get_user,
    increment_field,
    now,
    snapshot_user_core_stats,
    update_balance,
)
from utils.aesthetics import alert, card
from utils.decorators import cooldown, require_free, require_registered
from utils.helpers import escape_html, fmt, fmt_time

_SPARK = "▁▂▃▄▅▆▇█"


def _sparkline(values: list[float], width: int = 24) -> str:
    """Courbe en texte (sans dépendance) : sous-échantillonne puis mappe sur 8 niveaux."""
    if not values:
        return ""
    if len(values) > width:
        step = len(values) / width
        values = [values[min(len(values) - 1, int(i * step))] for i in range(width)]
    lo, hi = min(values), max(values)
    if hi == lo:
        return _SPARK[3] * len(values)
    return "".join(_SPARK[int((v - lo) / (hi - lo) * (len(_SPARK) - 1))] for v in values)


from config import GAME_NAME

TUTORIAL_STEPS = [
    {
        "title": f"Bienvenue dans {GAME_NAME}",
        "description": "Apprends à te repérer dans ton monde : le menu est rangé par zones et par rubriques.",
        "objective": "Lis les conseils ci-dessous, puis valide cette étape pour recevoir ton pack de départ.",
        "tips": [
            "🎮 Menu principal : toutes les zones du jeu. Chaque zone se découpe en rubriques, avec un retour à chaque étape.",
            "Menu → 🧬 Vie : l'état de ton personnage. Menu → 📜 Profil & infos : ta carte de joueur.",
            "Chaque action est décrite avant que tu la lances : lis la description, puis choisis.",
        ],
        "reward": {"balance": 5000},
        "validator": "always",
    },
    {
        "title": "Gagner tes premiers revenus",
        "description": "Fais tourner ton économie : un salaire et un bonus du jour.",
        "objective": "Travaille au moins une fois (Menu → 💼 Économie → Travailler).",
        "tips": [
            "Dans le même menu, récupère aussi ton bonus quotidien.",
            "Tu peux travailler toutes les heures de jeu : reviens régulièrement.",
        ],
        "reward": {"items": [("Potion de soin", 1)]},
        "validator": "economy",
    },
    {
        "title": "Monter en progression",
        "description": "Fais une action qui fait avancer ton personnage.",
        "objective": "Gagne de l'XP, monte d'un niveau ou commence des études.",
        "tips": [
            "Menu → 🎓 Carrière : commence des études pour viser de meilleurs métiers.",
            "Menu → 🎯 Missions : les missions du jour donnent de l'XP.",
            "Menu → 🎲 Loisirs → Arène : un duel fait aussi progresser.",
        ],
        "reward": {"items": [("Potion d'énergie", 1), ("Parchemin d'XP", 1)]},
        "validator": "progression",
    },
    {
        "title": "Obtenir un objet",
        "description": "Découvre l'inventaire, le butin et le marché.",
        "objective": "Possède au moins un objet dans ton inventaire, puis valide l'étape.",
        "tips": [
            "Les objets viennent de l'arène, des missions, du casino ou des récompenses du tutoriel.",
            "Menu → 📜 Profil → Inventaire pour voir tes objets.",
            "Menu → 🏪 Marché pour les vendre ou les utiliser.",
        ],
        "reward": {"items": [("Petit coffre", 1)]},
        "validator": "inventory",
    },
    {
        "title": "Découvrir le multijoueur",
        "description": "Teste un mode compétitif ou coopératif.",
        "objective": "Fais un duel d'arène, rejoins une compétition ou lance la saison classée.",
        "tips": [
            "Menu → 🎲 Loisirs → Arène pour défier un joueur.",
            "Menu → 🎮 Progression pour la compétition et le classé.",
            "Le classé utilise les duels PvP pour faire évoluer ta cote.",
        ],
        "reward": {"balance": 15000, "items": [("Potion de soin", 1), ("Potion d'énergie", 1)]},
        "validator": "multiplayer",
    },
    {
        "title": "Entrer sur le Réseau RP",
        "description": "Le réseau est lu par les autres joueurs : fais-toi remarquer.",
        "objective": "Publie ton premier post ou suis un joueur (Menu → 🌐 Réseaux sociaux → Réseau RP).",
        "tips": [
            "✍️ Publier : choisis une plateforme et écris ton message, avec des #hashtags (+40 XP).",
            "🔥 Explorer montre les posts les plus aimés ; ➕ Suivre ajoute un joueur à ton fil.",
            "Les likes et abonnements viennent des autres joueurs : sois créatif.",
        ],
        "reward": {"balance": 8000, "items": [("Potion d'énergie", 1)]},
        "validator": "reseau",
    },
    {
        "title": "Créer des liens",
        "description": "Un personnage seul va moins loin : entoure-toi.",
        "objective": "Ajoute un ami, entre dans un clan ou marie-toi (Menu → 👥 Multijoueur & famille).",
        "tips": [
            "🤗 Amis : ajoute un joueur depuis son profil ou via Multijoueur.",
            "🛡️ Clan : fonde le tien ou rejoins-en un sur invitation.",
            "💌 Les messages privés du Réseau RP servent à organiser tout ça.",
        ],
        "reward": {"balance": 8000, "items": [("Potion de soin", 1)]},
        "validator": "liens",
    },
    {
        "title": "Apprendre le jeu",
        "description": "Les cours expliquent les règles du monde : économie, justice, factions, réseau, famille…",
        "objective": "Révise un cours (Menu → 🎓 Carrière → Étudier, puis Réviser).",
        "tips": [
            "Choisis un diplôme à préparer : il te donne accès à des cours.",
            "Chaque cours coûte 15 d'énergie ; l'examen porte sur ce que tu as révisé.",
            "Un meilleur diplôme débloque de meilleurs métiers et un meilleur salaire.",
        ],
        "reward": {"balance": 12000, "items": [("Parchemin d'XP", 1)]},
        "validator": "cours",
    },
]


async def _fetch_item_by_name(db, item_name: str):
    db.row_factory = aiosqlite.Row
    async with db.execute(
        "SELECT item_id, name, emoji, rarity, type, effect_type, effect_value, description, value FROM items WHERE name = ?",
        (item_name,),
    ) as cur:
        return await cur.fetchone()


async def _get_inventory_quantity(db, user_id: int, item_id: int) -> int:
    async with db.execute(
        "SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?",
        (user_id, item_id),
    ) as cur:
        row = await cur.fetchone()
    return row[0] if row else 0


async def _add_item_to_inventory(db, user_id: int, item_id: int, item_name: str, quantity: int, item_type: str = ""):
    current_qty = await _get_inventory_quantity(db, user_id, item_id)
    if current_qty > 0:
        await db.execute(
            "UPDATE inventory SET quantity = quantity + ? WHERE user_id = ? AND item_id = ?",
            (quantity, user_id, item_id),
        )
    else:
        await db.execute(
            "INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at) VALUES (?,?,?,?,?,?)",
            (user_id, item_id, item_type, item_name, quantity, now()),
        )


async def _get_or_create_tutorial_progress(user_id: int) -> dict:
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM tutorial_progress WHERE user_id = ?",
            (user_id,),
        ) as cur:
            row = await cur.fetchone()
        if row:
            return dict(row)

        await db.execute(
            """
            INSERT INTO tutorial_progress(user_id, step_index, completed, claimed_step, updated_at)
            VALUES (?, 0, 0, -1, ?)
            """,
            (user_id, now()),
        )
        await db.commit()

    return {"user_id": user_id, "step_index": 0, "completed": 0, "claimed_step": -1, "updated_at": now()}


async def _set_tutorial_progress(user_id: int, *, step_index: int, completed: int, claimed_step: int):
    async with db_connection() as db:
        await db.execute(
            """
            UPDATE tutorial_progress
            SET step_index = ?, completed = ?, claimed_step = ?, updated_at = ?
            WHERE user_id = ?
            """,
            (step_index, completed, claimed_step, now(), user_id),
        )
        await db.commit()


async def _reset_tutorial_progress(user_id: int):
    progress = await _get_or_create_tutorial_progress(user_id)
    await _set_tutorial_progress(
        user_id,
        step_index=0,
        completed=0,
        claimed_step=max(progress.get("claimed_step", -1), len(TUTORIAL_STEPS) - 1 if progress.get("completed") else progress.get("claimed_step", -1)),
    )




async def _validate_tutorial_step(user_id: int, validator: str) -> tuple[bool, str]:
    if validator == "always":
        return True, "Étape d'introduction prête."

    u = await get_user(user_id)

    if validator == "economy":
        earned = u.get("total_earned", 0)
        if earned > 0 or u.get("balance", STARTING_BALANCE) > STARTING_BALANCE:
            return True, "Tu as déjà commencé à gagner de l'argent."
        return False, "Travaille une fois (Menu → 💼 Économie → Travailler) ou récupère ton bonus quotidien."

    if validator == "progression":
        if u.get("xp", 0) >= 50 or u.get("level", 1) >= 2 or bool(u.get("diplome")):
            return True, "Ta progression a bien été détectée."
        return False, "Gagne de l'XP ou commence tes études pour valider cette étape."

    if validator == "inventory":
        inventory = await get_inventory(user_id)
        if inventory:
            return True, "Ton inventaire contient déjà au moins un objet."
        return False, "Obtiens un objet (arène, missions, casino…), puis valide à nouveau l'étape."

    if validator == "multiplayer":
        total_pvp = (u.get("arena_wins", 0) or 0) + (u.get("arena_losses", 0) or 0)
        if total_pvp > 0:
            return True, "Ton activité multijoueur a bien été repérée."
        return False, "Fais un duel (Menu → 🎲 Loisirs → Arène)."

    if validator == "reseau":
        async with db_connection() as db:
            async with db.execute("SELECT (SELECT COUNT(*) FROM rp_posts WHERE author_id=? AND deleted=0 AND kind='post') "
                                  "+ (SELECT COUNT(*) FROM rp_follows WHERE follower_id=?)", (user_id, user_id)) as cur:
                n = (await cur.fetchone())[0]
        if n > 0:
            return True, "Tu fais maintenant partie du Réseau RP."
        return False, "Publie un post ou suis un joueur dans 🌐 Réseau RP, puis valide l'étape."

    if validator == "liens":
        async with db_connection() as db:
            async with db.execute(
                    "SELECT (SELECT COUNT(*) FROM friendships WHERE user_id=?) "
                    "+ (SELECT COUNT(*) FROM family_members WHERE user_id=?) "
                    "+ (SELECT COUNT(*) FROM marriages WHERE user_id=? AND status='active')",
                    (user_id, user_id, user_id)) as cur:
                n = (await cur.fetchone())[0]
        if n > 0:
            return True, "Tu n'es plus seul : tes liens sont bien repérés."
        return False, "Ajoute un ami, rejoins un clan ou marie-toi (Menu → 👥 Multijoueur & famille)."

    if validator == "cours":
        async with db_connection() as db:
            async with db.execute("SELECT COUNT(*) FROM study_lessons WHERE user_id=?", (user_id,)) as cur:
                n = (await cur.fetchone())[0]
        if n > 0:
            return True, "Tu as déjà révisé un cours."
        return False, "Inscris-toi à un diplôme (🎓 Carrière → Étudier) puis révise un cours."

    return False, "Validateur inconnu."


async def _grant_tutorial_reward(user_id: int, reward: dict) -> list[str]:
    granted = []

    if reward.get("balance"):
        _bonus = await faucet("tutorial", reward["balance"])      # ⚙️ réglage du staff
        if _bonus > 0:
            await update_balance(user_id, _bonus)
            granted.append(f"💰 {fmt(_bonus)}")

    items = reward.get("items", [])
    if items:
        async with db_connection() as db:
            for item_name, quantity in items:
                item = await _fetch_item_by_name(db, item_name)
                if not item:
                    continue
                await _add_item_to_inventory(db, user_id, item["item_id"], item["name"], quantity, item["type"])
                granted.append(f"{item['emoji']} {item['name']} ×{quantity}")
            await db.commit()

    return granted


def _tutorial_keyboard(completed: bool = False):
    if completed:
        return InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔄 Recommencer le tutoriel", callback_data="tutorial_reset")]]
        )
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("✅ Valider cette étape", callback_data="tutorial_validate")],
            [InlineKeyboardButton("🔄 Réinitialiser", callback_data="tutorial_reset")],
        ]
    )


async def _render_tutorial(update_or_query, user_id: int, edit: bool = False):
    progress = await _get_or_create_tutorial_progress(user_id)
    completed = bool(progress.get("completed"))

    if completed:
        body = [
            f"Tu as terminé le parcours guidé de {GAME_NAME}.",
            "",
            "Pour continuer :",
            "  • 🎮 Progression : artisanat, saison classée, graphique de progression",
            "  • 🎮 Menu principal : toutes les actions du jeu par zone",
            "  • 📖 Aide : pages courtes pour chaque sujet",
        ]
        text = card("TUTORIEL TERMINÉ", body, icon="🎓", style="thick", footer="Tu peux le relancer si tu veux refaire le parcours.")
        reply_markup = _tutorial_keyboard(completed=True)
    else:
        step_index = min(progress["step_index"], len(TUTORIAL_STEPS) - 1)
        step = TUTORIAL_STEPS[step_index]
        body = [
            f"Étape <b>{step_index + 1}</b> / <b>{len(TUTORIAL_STEPS)}</b>",
            f"<b>{escape_html(step['title'])}</b>",
            "",
            escape_html(step["description"]),
            "",
            f"🎯 Objectif : {escape_html(step['objective'])}",
            "",
            "<b>Conseils</b>",
            *[f"  • {escape_html(tip)}" for tip in step.get("tips", [])],
        ]

        reward_preview = []
        if step["reward"].get("balance"):
            reward_preview.append(f"💰 {fmt(step['reward']['balance'])}")
        for item_name, quantity in step["reward"].get("items", []):
            reward_preview.append(f"📦 {item_name} ×{quantity}")
        if reward_preview:
            body.extend(["", "<b>Récompense</b>", f"  • {' · '.join(reward_preview)}"])

        text = card("TUTORIEL INTERACTIF", body, icon="🎓", style="thick", footer="Valide l'étape quand les conditions sont remplies.")
        reply_markup = _tutorial_keyboard(completed=False)

    if edit and hasattr(update_or_query, "edit_message_text"):
        await update_or_query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)
    elif hasattr(update_or_query, "reply_text"):
        await update_or_query.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update_or_query.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)


@require_registered
async def cmd_tutorial(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if context.args and context.args[0].lower() == "reset":
        await _reset_tutorial_progress(user.id)
    await _render_tutorial(update.message, user.id)


async def tutorial_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    action = query.data.replace("tutorial_", "", 1)

    if action == "reset":
        await _reset_tutorial_progress(user_id)
        await _render_tutorial(query, user_id, edit=True)
        return

    if action != "validate":
        await query.answer("Action inconnue.", show_alert=True)
        return

    progress = await _get_or_create_tutorial_progress(user_id)
    if progress.get("completed"):
        await _render_tutorial(query, user_id, edit=True)
        return

    step_index = min(progress["step_index"], len(TUTORIAL_STEPS) - 1)
    step = TUTORIAL_STEPS[step_index]
    ok, detail = await _validate_tutorial_step(user_id, step["validator"])

    if not ok:
        await query.answer(detail, show_alert=True)
        return

    rewards = []
    already_claimed = progress.get("claimed_step", -1) >= step_index
    if not already_claimed:
        rewards = await _grant_tutorial_reward(user_id, step["reward"])
    next_index = step_index + 1
    completed = 1 if next_index >= len(TUTORIAL_STEPS) else 0
    await _set_tutorial_progress(
        user_id,
        step_index=min(next_index, len(TUTORIAL_STEPS) - 1),
        completed=completed,
        claimed_step=step_index,
    )
    await add_life_journal(
        user_id,
        "tutorial",
        f"Étape tutoriel validée : {step['title']}. Récompenses : {', '.join(rewards) if rewards else 'aucune'}.",
        severity="success",
    )

    await query.answer("Étape validée avec succès.", show_alert=False)
    await _render_tutorial(query, user_id, edit=True)
    if rewards:
        await query.message.reply_text(
            card(
                "RÉCOMPENSES DU TUTORIEL",
                [f"  • {escape_html(reward)}" for reward in rewards],
                icon="🎁",
                style="thick",
                footer=detail,
            ),
            parse_mode="HTML",
        )


@require_registered
async def cmd_graphstats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Évolution des stats en courbes texte (aucune image, aucune dépendance graphique)."""
    user = update.effective_user
    await snapshot_user_core_stats(user.id)

    stat_filter = "all"
    period_days = 30
    for arg in context.args:
        lower = arg.lower()
        if lower in {"all", "balance", "xp", "prestige"}:
            stat_filter = lower
        elif lower.isdigit():
            period_days = max(1, min(180, int(lower)))

    names = ["balance", "xp", "prestige"] if stat_filter == "all" else [stat_filter]
    from_ts = now() - period_days * 86400
    titles = {"balance": ("💰", "Richesse"), "xp": ("⭐", "XP"), "prestige": ("👑", "Prestige")}

    lines: list[str] = []
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        for stat_name in names:
            async with db.execute(
                "SELECT recorded_at, stat_value FROM user_stat_history "
                "WHERE user_id = ? AND stat_name = ? AND recorded_at >= ? ORDER BY recorded_at ASC",
                (user.id, stat_name, from_ts),
            ) as cur:
                rows = await cur.fetchall()
            if not rows:
                continue
            values = [r["stat_value"] for r in rows]
            emoji, label = titles.get(stat_name, ("📊", stat_name.capitalize()))
            delta = values[-1] - values[0]
            sign = "+" if delta >= 0 else "−"
            lines += [
                f"{emoji} <b>{label}</b>",
                f"<code>{_sparkline(values)}</code>",
                f"  {fmt(values[0])} → <b>{fmt(values[-1])}</b> ({sign}{fmt(abs(delta))})  "
                f"· min {fmt(min(values))} · max {fmt(max(values))}",
                "",
            ]

    if not lines:
        await update.message.reply_text(
            alert("info", "Pas assez d'historique pour afficher une évolution sur cette période."),
            parse_mode="HTML",
        )
        return

    await update.message.reply_text(
        card(
            "ÉVOLUTION DE TES STATS",
            lines + [f"Période : <b>{period_days} jour(s)</b>", "Utilisation : le 🎮 Menu principal"],
            icon="📈",
            style="thick",
        ),
        parse_mode="HTML",
    )


# ═══════════════════════════════════════════════════════════════════
#              🎮 MENU INTERACTIF PROGRESSION
# ═══════════════════════════════════════════════════════════════════
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from utils.helpers import escape_html as _escape
from utils.helpers import safe_edit


# ─── Tutoriel ─────────────────────────────────────────────────────
async def show_prog_tutorial(query, user_id: int):
    progress = await _get_or_create_tutorial_progress(user_id)
    if progress.get("completed"):
        body = [
            "✅ <b>Tutoriel terminé</b>",
            "",
            "<i>Tu peux le refaire pour rafraîchir les bases.</i>",
        ]
        keyboard = [
            [InlineKeyboardButton("🔄 Recommencer le tutoriel", callback_data="tutorial_reset")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="prog_menu")],
        ]
    else:
        step = min(progress.get("step_index", 0), len(TUTORIAL_STEPS) - 1)
        data = TUTORIAL_STEPS[step]
        body = [
            f"📖 Étape <b>{step + 1}/{len(TUTORIAL_STEPS)}</b>",
            f"<b>{_escape(data['title'])}</b>",
            "",
            _escape(data["description"]),
            "",
            f"🎯 <i>{_escape(data['objective'])}</i>",
        ]
        keyboard = [
            [InlineKeyboardButton("✅ Valider l'étape", callback_data="tutorial_validate")],
            [InlineKeyboardButton("🔄 Réinitialiser", callback_data="tutorial_reset")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="prog_menu")],
        ]

    await safe_edit(
        query,
        card("🎓 TUTORIEL", body, icon="🎓", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


# ─── Graphiques ───────────────────────────────────────────────────
async def show_prog_graph(query, user_id: int):
    body = [
        "📈 <b>Graphiques de progression</b>",
        "",
        "le 🎮 Menu principal → génère un graphique de tes 3 stats principales",
        "",
        "<b>Options :</b>",
        "  • le 🎮 Menu principal — Richesse sur 30 jours",
        "  • le 🎮 Menu principal — XP sur 7 jours",
        "  • le 🎮 Menu principal — Prestige sur 90 jours",
        "  • le 🎮 Menu principal — Toutes les stats",
    ]
    await safe_edit(
        query,
        card("📈 GRAPHIQUES", body, icon="📈", style="round"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="prog_menu")]])
    )


# ─── Routeur ──────────────────────────────────────────────────────
async def progression_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routeur des callbacks 'prog_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "prog_menu":
        from handlers.hub import open_zone; await open_zone(query, "progression")
        return
    if data == "prog_tutorial":
        await show_prog_tutorial(query, user_id)
        return
    if data == "prog_graph":
        await show_prog_graph(query, user_id)
        return


# ─────────────────────────────────────────────────────────────────────────────
#  🧭 Mon parcours : tout ce qui fait avancer le joueur, sur un seul écran
# ─────────────────────────────────────────────────────────────────────────────
def _bar(done: int, total: int, width: int = 10) -> str:
    full = round(done / total * width) if total else 0
    return "█" * full + "░" * (width - full)


@require_registered
async def cmd_parcours(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Tableau de bord de la progression : niveau, tutoriel, missions, succès, compétition — avec accès direct."""
    from handlers.phone import _hub_cb
    from utils.helpers import xp_progress
    uid = update.effective_user.id
    u = await get_user(uid)
    lines = []
    lvl, xp_in, xp_need = xp_progress(int(u.get("xp", 0) or 0))
    lines.append(f"⭐ <b>Niveau {lvl}</b>  {_bar(xp_in, xp_need)}  {xp_in}/{xp_need} XP")

    tp = await _get_or_create_tutorial_progress(uid)
    total = len(TUTORIAL_STEPS)
    if tp["completed"]:
        lines.append(f"🌱 Tutoriel : <b>terminé</b> ({total}/{total})")
    else:
        step = TUTORIAL_STEPS[min(tp["step_index"], total - 1)]
        lines.append(f"🌱 Tutoriel : étape <b>{tp['step_index'] + 1}/{total}</b> — {escape_html(step['title'])}")
        lines.append(f"   <i>{escape_html(step['objective'])}</i>")

    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*), SUM(completed) FROM missions WHERE user_id=?", (uid,)) as cur:
            m_total, m_done = await cur.fetchone()
        async with db.execute("SELECT COUNT(*) FROM user_achievements WHERE user_id=?", (uid,)) as cur:
            ach = (await cur.fetchone())[0]
    from handlers.achievements import ACHIEVEMENTS
    lines.append(f"🎯 Missions : <b>{int(m_done or 0)}/{int(m_total or 0)}</b> accomplies")
    lines.append(f"🏅 Succès : <b>{ach}/{len(ACHIEVEMENTS)}</b>  {_bar(ach, len(ACHIEVEMENTS))}")


    rows = [[InlineKeyboardButton("🌱 Tutoriel", callback_data=_hub_cb("tutorial", "progression")),
             InlineKeyboardButton("🎯 Missions", callback_data=_hub_cb("missions", "progression"))],
            [InlineKeyboardButton("🏅 Succès", callback_data=_hub_cb("achievements", "progression"))],
            [InlineKeyboardButton("⬅️ Progression", callback_data="hub:progression"),
             InlineKeyboardButton("🎮 Menu principal", callback_data="hub:home")]]
    await update.effective_message.reply_text(card("MON PARCOURS", lines, icon="🧭", style="round"),
                                              parse_mode="HTML", reply_markup=InlineKeyboardMarkup(rows))
