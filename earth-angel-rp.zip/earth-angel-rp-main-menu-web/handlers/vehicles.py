# handlers/vehicles.py
# Système de véhicules complet — Fusion de vehicle.py + vehicles.py (2.0)
# Ce fichier regroupe TOUTES les opérations liées aux véhicules.

from utils.swallow import swallowed
import asyncio
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import (
    DB_PATH, get_user, update_balance, get_vehicles, now, add_notification,
    increment_field, db_connection, snapshot_user_core_stats
)
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, escape_html, fmt_time, parse_amount, get_level
from utils.aesthetics import card, alert, rich_bar
from utils.pagination import paginate_lines
from utils.vip import max_vehicles as vip_max_vehicles
from config import VEHICLES
from utils.helpers import safe_edit

MAX_VEHICLES = 10


# ═══════════════════════════════════════════════════════════════════════════
#                       HELPERS DE BASE
# ═══════════════════════════════════════════════════════════════════════════

async def get_active_vehicle(user_id: int):
    """Retourne le véhicule actif (dict) ou None."""
    u = await get_user(user_id)
    active_id = u.get("active_vehicle_id", 0)
    if not active_id:
        return None
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM vehicles WHERE veh_id = ? AND user_id = ?",
            (active_id, user_id)
        ) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def set_active_vehicle(user_id: int, veh_id: int):
    async with db_connection() as db:
        await db.execute(
            "UPDATE users SET active_vehicle_id = ? WHERE user_id = ?",
            (veh_id, user_id)
        )
        await db.commit()


async def get_vehicle_stats(veh_type: str) -> dict:
    return VEHICLES.get(veh_type, {})


async def get_max_vehicles(user_id: int) -> int:
    u = await get_user(user_id)
    return vip_max_vehicles(u, MAX_VEHICLES)


async def get_garage_text_and_markup(user_id: int):
    """Génère le texte et le clavier du garage interactif."""
    vehicles = await get_vehicles(user_id)
    active = await get_active_vehicle(user_id)
    max_veh = await get_max_vehicles(user_id)

    if not vehicles:
        return "🏎️ <b>VOTRE GARAGE</b>\n\nVotre garage est vide. Achète un véhicule : menu Véhicules &amp; luxe → Acheter un véhicule.", None

    text = f"🏎️ <b>VOTRE GARAGE</b> ({len(vehicles)}/{max_veh})\n\n"
    for v in vehicles:
        veh_data = await get_vehicle_stats(v["veh_type"])
        is_active = active and v["veh_id"] == active["veh_id"]
        marker = " ✅ ACTIF" if is_active else ""

        speed = v.get("speed", 0) or veh_data.get("speed", 0)
        cargo = v.get("cargo", 0) or veh_data.get("cargo", 0)
        luxury = v.get("luxury", 0) or veh_data.get("luxury", 0)
        condition = v.get("condition", 100)
        fuel = v.get("fuel", 0) or 0
        capacity = veh_data.get("fuel_capacity", 0)

        # Auto-sync des stats si elles sont à 0 en base
        if v.get("speed", 0) == 0 and veh_data.get("speed", 0) > 0:
            async with db_connection() as db:
                await db.execute("UPDATE vehicles SET speed = ? WHERE veh_id = ?",
                                 (veh_data.get("speed", 0), v["veh_id"]))
                await db.commit()
        if v.get("cargo", 0) == 0 and veh_data.get("cargo", 0) > 0:
            async with db_connection() as db:
                await db.execute("UPDATE vehicles SET cargo = ? WHERE veh_id = ?",
                                 (veh_data.get("cargo", 0), v["veh_id"]))
                await db.commit()
        if v.get("luxury", 0) == 0 and veh_data.get("luxury", 0) > 0:
            async with db_connection() as db:
                await db.execute("UPDATE vehicles SET luxury = ? WHERE veh_id = ?",
                                 (veh_data.get("luxury", 0), v["veh_id"]))
                await db.commit()

        condition_bar = rich_bar(condition, 100, 10)
        if capacity > 0:
            fuel_bar = rich_bar(fuel, capacity, 10)
            fuel_display = f"<code>{fuel_bar}</code> {fuel}/{capacity}"
        else:
            fuel_display = "N/A (électrique/manuel)"

        text += (
            f"{veh_data.get('emoji', '🚗')} <b>{escape_html(v['veh_type'])}</b>{marker}\n"
            f"⚡ Vitesse: {speed}/100  |  📦 Cargo: {cargo}/100  |  ✨ Luxe: {luxury}/100\n"
            f"🛠 État: <code>{condition_bar}</code> {condition}%\n"
            f"⛽ Essence: {fuel_display}\n\n"
        )

    keyboard = []
    for v in vehicles:
        if active and v["veh_id"] == active["veh_id"]:
            continue
        veh_data = await get_vehicle_stats(v["veh_type"])
        keyboard.append([
            InlineKeyboardButton(
                f"✅ Sélectionner {veh_data.get('emoji', '')} {v['veh_type']}",
                callback_data=f"garage_select_{v['veh_id']}"
            )
        ])

    if active:
        keyboard.append([
            InlineKeyboardButton("🔧 Réparer", callback_data=f"garage_repair_{active['veh_id']}"),
            InlineKeyboardButton("⛽ Faire le plein", callback_data=f"garage_refuel_{active['veh_id']}"),
        ])

    reply_markup = InlineKeyboardMarkup(keyboard) if keyboard else None
    return text, reply_markup


# ═══════════════════════════════════════════════════════════════════════════
#                       CATALOGUE & ACHAT
# ═══════════════════════════════════════════════════════════════════════════

@require_registered
@require_free
async def cmd_vehicules_liste(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche le catalogue complet des véhicules disponibles."""
    text = "🚗 <b>Showroom de véhicules</b>\n\n"
    for vtype, data in VEHICLES.items():
        text += (
            f"{data['emoji']} <b>{vtype}</b>\n"
            f"  💰 Prix : {fmt(data['price'])}\n"
            f"  🔧 Entretien : {fmt(data['maint'])}/mois\n"
            f"  ✨ Prestige : +{data['status']} pts\n"
            f"  ⚡ Vitesse : {data.get('speed', 0)}/100\n"
            f"  📦 Cargo : {data.get('cargo', 0)}/100\n"
            f"  ✨ Luxe : {data.get('luxury', 0)}/100\n\n"
        )
    text += "<i>Utilise le bouton « Acheter un véhicule ».</i>"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
@cooldown("buy_vehicle", 10, "⏳ Attends un instant avant d'acheter un autre véhicule.")
async def cmd_acheter_vehicule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏎️ Véhicules & luxe.")
        return

    vtype = " ".join(context.args).title()
    matched = None
    for v in VEHICLES:
        if v.lower() == vtype.lower():
            matched = v
            break
    if not matched:
        await update.message.reply_text("❌ Véhicule inconnu : choisis-le dans la liste du menu.")
        return

    data = VEHICLES[matched]
    if u["balance"] < data["price"]:
        await update.message.reply_text(
            f"❌ Fonds insuffisants !\n"
            f"💰 Prix : {fmt(data['price'])}\n"
            f"💵 Ton solde : {fmt(u['balance'])}",
            parse_mode="HTML"
        )
        return

    vehs = await get_vehicles(user.id)
    max_veh = await get_max_vehicles(user.id)
    if len(vehs) >= max_veh:
        await update.message.reply_text(
            f"❌ Tu as déjà {max_veh} véhicules, vends-en un avant d'en acheter un autre.\n"
            f"💡 <i>Astuce : achète <code>+3 véhicules max</code> dans la boutique Étoiles.</i>",
            parse_mode="HTML"
        )
        return

    try:
        async with db_connection() as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                async with db.execute("SELECT COUNT(*) FROM vehicles WHERE user_id=?", (user.id,)) as cur:
                    owned = (await cur.fetchone())[0]
                if owned >= max_veh:
                    await db.rollback()
                    await update.message.reply_text(f"❌ Tu as déjà {max_veh} véhicules.")
                    return
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+?, prestige=prestige+? "
                    "WHERE user_id=? AND balance>=?",
                    (data["price"], data["price"], data["status"], user.id, data["price"]),
                )
                if debit.rowcount != 1:
                    await db.rollback()
                    await update.message.reply_text("❌ Fonds insuffisants.")
                    return
                await db.execute(
                    "INSERT INTO vehicles (user_id, veh_type, condition, insured, purchased_at, "
                    "last_maintenance, speed, cargo, luxury, fuel) VALUES (?,?,100,0,?,?,?,?,?,?)",
                    (user.id, matched, now(), now(), data.get("speed", 0), data.get("cargo", 0),
                     data.get("luxury", 0), data.get("fuel_capacity", 0)),
                )
                await snapshot_user_core_stats(user.id, db)
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except Exception:
        raise

    await update.message.reply_text(
        f"✅ <b>{matched} acheté !</b>\n\n"
        f"{data['emoji']} Bienvenue dans ta nouvelle monture !\n"
        f"💰 Prix : {fmt(data['price'])}\n"
        f"🔧 Entretien mensuel : {fmt(data['maint'])}\n"
        f"✨ +{data['status']} prestige\n"
        f"⚡ Vitesse : {data.get('speed', 0)}/100\n"
        f"📦 Cargo : {data.get('cargo', 0)}/100\n"
        f"✨ Luxe : {data.get('luxury', 0)}/100\n\n",
        parse_mode="HTML"
    )
    await add_notification(user.id, f"🚗 Tu as acheté un {matched} !")


@require_registered
@require_free
async def cmd_mes_vehicules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Liste des véhicules du joueur (bouton « Mes véhicules » du menu)."""
    user = update.effective_user
    vehs = await get_vehicles(user.id)
    max_veh = await get_max_vehicles(user.id)

    if not vehs:
        await update.message.reply_text(
            "🚗 Tu ne possèdes aucun véhicule.\nOuvre le catalogue : menu Véhicules & luxe → Catalogue véhicules."
        )
        return

    lines = []
    for i, v in enumerate(vehs, 1):
        data = VEHICLES.get(v["veh_type"], {})
        cond_bar = "🟢" if v["condition"] >= 70 else "🟡" if v["condition"] >= 40 else "🔴"
        ins_text = "✅ Assuré" if v["insured"] else "❌ Non assuré"
        last_maint = v.get("last_maintenance", 0)
        maint_ago = fmt_time(now() - last_maint) if last_maint else "jamais"
        speed = v.get("speed", 0) or data.get("speed", 0)
        cargo = v.get("cargo", 0) or data.get("cargo", 0)
        luxury = v.get("luxury", 0) or data.get("luxury", 0)
        lines.append(
            f"#{i} {data.get('emoji', '🚗')} <b>{escape_html(v['veh_type'])}</b>\n"
            f"  ⚡ {speed}/100 📦 {cargo}/100 ✨ {luxury}/100\n"
            f"  {cond_bar} État : {v['condition']}%\n"
            f"  🏥 {ins_text}\n"
            f"  🔧 Dernier entretien : il y a {maint_ago}"
        )

    header = f"🚗 <b>Tes véhicules</b> ({len(vehs)}/{max_veh})\n\n"
    footer = "\n<i>Réparer, faire le plein, assurer ou vendre : menu Véhicules &amp; luxe.</i>"

    text, _markup = await paginate_lines(lines, 1, per_page=12, header=header, footer=footer)
    if len(lines) > 12:
        text += f"\n<i>… et {len(lines) - 12} autre(s) véhicule(s) : voir ton Garage.</i>"
    await update.message.reply_text(text, parse_mode="HTML")


# ═══════════════════════════════════════════════════════════════════════════
#                       ENTRETIEN (Réparation / Plein)
# ═══════════════════════════════════════════════════════════════════════════

@require_registered
@require_free
@cooldown("repair_vehicle", 10)
async def cmd_repair_vehicle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Répare un véhicule (actif par défaut, ou un index précis)."""
    user = update.effective_user
    u = await get_user(user.id)
    vehicles = await get_vehicles(user.id)
    if not vehicles:
        await update.message.reply_text(alert("info", "Vous n'avez aucun véhicule."), parse_mode="HTML")
        return

    if context.args and context.args[0].isdigit():
        idx = int(context.args[0]) - 1
        if idx < 0 or idx >= len(vehicles):
            await update.message.reply_text("❌ Numéro invalide.")
            return
        veh = vehicles[idx]
    else:
        active = await get_active_vehicle(user.id)
        if not active:
            await update.message.reply_text(
                alert("info", "Aucun véhicule actif. Utilisez le menu pour en sélectionner un."),
                parse_mode="HTML"
            )
            return
        veh = active

    if veh["condition"] >= 100:
        await update.message.reply_text("✅ Ce véhicule est déjà en parfait état.")
        return

    # Formule unique (celle de la v2.0 — tient compte du luxe)
    lux = veh.get("luxury", 0) or (await get_vehicle_stats(veh["veh_type"])).get("luxury", 0)
    repair_cost = int((100 - veh["condition"]) * (lux * 2 + 50) / 100)
    if repair_cost < 100:
        repair_cost = 100
    if veh.get("insured"):
        repair_cost = max(50, repair_cost // 2)    # assuré : réparations à moitié prix

    if u["balance"] < repair_cost:
        await update.message.reply_text(
            f"❌ Réparation : {fmt(repair_cost)}{' (tarif assuré)' if veh.get('insured') else ''}.\nSolde : {fmt(u['balance'])}",
            parse_mode="HTML"
        )
        return

    await update_balance(user.id, -repair_cost, sink="vehicules")
    async with db_connection() as db:
        await db.execute(
            "UPDATE vehicles SET condition = 100, last_maintenance = ? WHERE veh_id = ?",
            (now(), veh["veh_id"])
        )
        await db.commit()

    await update.message.reply_text(
        f"🔧 <b>Réparation terminée !</b>\n\n"
        f"{VEHICLES.get(veh['veh_type'], {}).get('emoji', '🚗')} {escape_html(veh['veh_type'])}\n"
        f"État : {veh['condition']}% → 100%\n"
        f"💰 Coût : {fmt(repair_cost)}",
        parse_mode="HTML"
    )
    await add_notification(user.id, f"🔧 Véhicule {veh['veh_type']} réparé pour {fmt(repair_cost)}.")


# Alias rétrocompatibilité — /reparer pointe sur /repair
cmd_reparer_vehicule = cmd_repair_vehicle


@require_registered
@require_free
@cooldown("refuel", 60)
async def cmd_refuel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    active = await get_active_vehicle(user.id)
    if not active:
        await update.message.reply_text(
            alert("info", "Aucun véhicule actif. Utilisez le menu pour en sélectionner un."),
            parse_mode="HTML"
        )
        return

    veh_data = await get_vehicle_stats(active["veh_type"])
    capacity = veh_data.get("fuel_capacity", 0)
    if capacity == 0:
        await update.message.reply_text("❌ Ce véhicule n'utilise pas de carburant.")
        return

    current_fuel = active.get("fuel", 0)
    if current_fuel >= capacity:
        await update.message.reply_text("✅ Le réservoir est déjà plein.")
        return

    needed = capacity - current_fuel
    total_cost = needed * 10

    if u["balance"] < total_cost:
        await update.message.reply_text(
            f"❌ Solde insuffisant. Coût : {fmt(total_cost)}", parse_mode="HTML"
        )
        return

    await update_balance(user.id, -total_cost, sink="vehicules")
    async with db_connection() as db:
        await db.execute("UPDATE vehicles SET fuel = ? WHERE veh_id = ?", (capacity, active["veh_id"]))
        await db.commit()

    await update.message.reply_text(
        f"⛽ <b>Plein effectué !</b>\n\n"
        f"{veh_data.get('emoji', '🚗')} {escape_html(active['veh_type'])}\n"
        f"⛽ Essence : {current_fuel} → {capacity}\n"
        f"💰 Coût : {fmt(total_cost)}",
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════════════
#                       ASSURANCE / VENTE / INFO
# ═══════════════════════════════════════════════════════════════════════════

@require_registered
@require_free
@cooldown("insure_vehicle", 10)
async def cmd_assurer_vehicule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    vehs = await get_vehicles(user.id)

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏎️ Véhicules & luxe.")
        return

    try:
        idx = int(context.args[0]) - 1
        if idx < 0:
            raise IndexError  # évite l'indexation négative (props[-1])
        veh = vehs[idx]
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Véhicule introuvable : choisis-le dans la liste du menu.")
        return

    if veh["insured"]:
        await update.message.reply_text("✅ Ce véhicule est déjà assuré !")
        return

    veh_data = VEHICLES.get(veh["veh_type"], {})
    insurance_cost = int(veh_data.get("price", 10000) * 0.05)
    if insurance_cost < 100:
        insurance_cost = 100

    if u["balance"] < insurance_cost:
        await update.message.reply_text(f"❌ Assurance : {fmt(insurance_cost)} (prime unique).\nSolde : {fmt(u['balance'])}", parse_mode="HTML")
        return

    await update_balance(user.id, -insurance_cost, sink="vehicules")
    async with db_connection() as db:
        await db.execute("UPDATE vehicles SET insured=1 WHERE veh_id=?", (veh["veh_id"],))
        await db.commit()

    await update.message.reply_text(
        f"✅ <b>Véhicule assuré !</b>\n\n"
        f"{veh_data.get('emoji','🚗')} {escape_html(veh['veh_type'])}\n"
        f"💰 Prime unique : {fmt(insurance_cost)}\n"
        f"<i>Tes réparations coûtent désormais 50 % de moins.</i>",
        parse_mode="HTML"
    )
    await add_notification(user.id, f"🏥 Tu as assuré ton {veh['veh_type']} (prime unique : {fmt(insurance_cost)}).")


@require_registered
@require_free
@cooldown("sell_vehicle", 10)
async def cmd_vendre_vehicule(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    vehs = await get_vehicles(user.id)

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏎️ Véhicules & luxe.")
        return

    try:
        idx = int(context.args[0]) - 1
        if idx < 0:
            raise IndexError  # évite l'indexation négative (props[-1])
        veh = vehs[idx]
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Numéro invalide.")
        return

    veh_data = VEHICLES.get(veh["veh_type"], {})
    condition = veh["condition"]
    base_price = veh_data.get("price", 0)
    sell_price = int(base_price * 0.6 * (condition / 100))
    if sell_price <= 0:
        await update.message.reply_text("❌ Ce véhicule ne vaut plus rien.")
        return

    async with db_connection() as db:
        await db.execute("DELETE FROM vehicles WHERE veh_id=?", (veh["veh_id"],))
        await db.commit()

    await update_balance(user.id, sell_price)
    await increment_field(user.id, "prestige", -veh_data.get("status", 0))

    await update.message.reply_text(
        f"💰 <b>Vente de véhicule</b>\n\n"
        f"{veh_data.get('emoji', '🚗')} {escape_html(veh['veh_type'])}\n"
        f"État : {condition}%\n"
        f"💰 Prix de reprise : {fmt(sell_price)}\n\n"
        f"<i>Tu regrettes peut-être…</i>",
        parse_mode="HTML"
    )
    await add_notification(user.id, f"💰 Tu as vendu ton {veh['veh_type']} pour {fmt(sell_price)}.")


@require_registered
async def cmd_vehicule_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    vehs = await get_vehicles(user.id)
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏎️ Véhicules & luxe.")
        return
    try:
        idx = int(context.args[0]) - 1
        if idx < 0 or idx >= len(vehs):
            await update.message.reply_text("❌ Numéro invalide.")
            return
        veh = vehs[idx]
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Numéro invalide.")
        return

    data = VEHICLES.get(veh["veh_type"], {})
    cond_bar = rich_bar(veh["condition"], 100, 10)
    last_maint = veh.get("last_maintenance", 0)
    maint_ago = fmt_time(now() - last_maint) if last_maint else "jamais"
    purchased_ago = fmt_time(now() - veh.get("purchased_at", now()))

    speed = veh.get("speed", 0) or data.get("speed", 0)
    cargo = veh.get("cargo", 0) or data.get("cargo", 0)
    luxury = veh.get("luxury", 0) or data.get("luxury", 0)
    fuel = veh.get("fuel", 0) or 0
    capacity = data.get("fuel_capacity", 0)

    text = (
        f"🚗 <b>Informations sur le véhicule</b>\n\n"
        f"{data.get('emoji', '🚗')} <b>{escape_html(veh['veh_type'])}</b>\n"
        f"💰 Valeur neuve : {fmt(data.get('price', 0))}\n"
        f"🔧 Entretien mensuel : {fmt(data.get('maint', 0))}\n"
        f"✨ Prestige : +{data.get('status', 0)}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"⚡ Vitesse : {speed}/100\n"
        f"📦 Cargo : {cargo}/100\n"
        f"✨ Luxe : {luxury}/100\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🏚️ État : <code>{cond_bar}</code> {veh['condition']}%\n"
        f"🏥 Assurance : {'✅ Oui' if veh['insured'] else '❌ Non'}\n"
        f"🔧 Dernier entretien : il y a {maint_ago}\n"
        f"📅 Acheté il y a : {purchased_ago}\n"
        f"⛽ Carburant : {fuel}/{capacity}"
    )
    await update.message.reply_text(text, parse_mode="HTML")


# ═══════════════════════════════════════════════════════════════════════════
#                       COMMANDES INTERACTIVES (Garage)
# ═══════════════════════════════════════════════════════════════════════════

@require_registered
@require_free
async def cmd_garage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text, reply_markup = await get_garage_text_and_markup(user_id)
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)


@require_registered
@require_free
async def cmd_garage_select(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    try:
        await query.answer()
    except Exception:
        swallowed('handlers/vehicles.py')

    data = query.data
    if not data.startswith("garage_select_"):
        return
    veh_id = int(data.split("_")[2])
    user_id = query.from_user.id

    vehicles = await get_vehicles(user_id)
    if not any(v["veh_id"] == veh_id for v in vehicles):
        await query.edit_message_text("❌ Véhicule introuvable.")
        return

    await set_active_vehicle(user_id, veh_id)
    text, reply_markup = await get_garage_text_and_markup(user_id)
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)


@require_registered
@require_free
async def cmd_garage_repair(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    try:
        await query.answer()
    except Exception:
        swallowed('handlers/vehicles.py')

    data = query.data
    if not data.startswith("garage_repair_"):
        return
    veh_id = int(data.split("_")[2])
    user_id = query.from_user.id

    vehicles = await get_vehicles(user_id)
    veh = next((v for v in vehicles if v["veh_id"] == veh_id), None)
    if not veh:
        await query.edit_message_text("❌ Véhicule introuvable.")
        return

    active = await get_active_vehicle(user_id)
    if not active or active["veh_id"] != veh_id:
        await query.edit_message_text("❌ Ce véhicule n'est pas actif. Sélectionnez-le d'abord.")
        return

    if veh["condition"] >= 100:
        await query.edit_message_text("✅ Ce véhicule est déjà en parfait état.")
        return

    u = await get_user(user_id)
    lux = veh.get("luxury", 0) or (await get_vehicle_stats(veh["veh_type"])).get("luxury", 0)
    repair_cost = int((100 - veh["condition"]) * (lux * 2 + 50) / 100)
    if repair_cost < 100:
        repair_cost = 100
    if veh.get("insured"):
        repair_cost = max(50, repair_cost // 2)    # assuré : réparations à moitié prix

    if u["balance"] < repair_cost:
        await query.edit_message_text(
            f"❌ Réparation : {fmt(repair_cost)}{' (tarif assuré)' if veh.get('insured') else ''}.\nSolde : {fmt(u['balance'])}",
            parse_mode="HTML"
        )
        return

    await update_balance(user_id, -repair_cost, sink="vehicules")
    async with db_connection() as db:
        await db.execute(
            "UPDATE vehicles SET condition = 100, last_maintenance = ? WHERE veh_id = ?",
            (now(), veh_id)
        )
        await db.commit()

    await add_notification(user_id, f"🔧 Véhicule {veh['veh_type']} réparé pour {fmt(repair_cost)}.")
    text, reply_markup = await get_garage_text_and_markup(user_id)
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)


@require_registered
@require_free
async def cmd_garage_refuel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    try:
        await query.answer()
    except Exception:
        swallowed('handlers/vehicles.py')

    data = query.data
    if not data.startswith("garage_refuel_"):
        return
    veh_id = int(data.split("_")[2])
    user_id = query.from_user.id

    vehicles = await get_vehicles(user_id)
    veh = next((v for v in vehicles if v["veh_id"] == veh_id), None)
    if not veh:
        await query.edit_message_text("❌ Véhicule introuvable.")
        return

    active = await get_active_vehicle(user_id)
    if not active or active["veh_id"] != veh_id:
        await query.edit_message_text("❌ Ce véhicule n'est pas actif. Sélectionnez-le d'abord.")
        return

    veh_data = await get_vehicle_stats(veh["veh_type"])
    capacity = veh_data.get("fuel_capacity", 0)
    if capacity == 0:
        await query.edit_message_text("❌ Ce véhicule n'utilise pas de carburant.")
        return

    current_fuel = veh.get("fuel", 0)
    if current_fuel >= capacity:
        await query.edit_message_text("✅ Le réservoir est déjà plein.")
        return

    needed = capacity - current_fuel
    total_cost = needed * 10

    u = await get_user(user_id)
    if u["balance"] < total_cost:
        await query.edit_message_text(f"❌ Solde insuffisant. Coût : {fmt(total_cost)}", parse_mode="HTML")
        return

    await update_balance(user_id, -total_cost, sink="vehicules")
    async with db_connection() as db:
        await db.execute("UPDATE vehicles SET fuel = ? WHERE veh_id = ?", (capacity, veh_id))
        await db.commit()

    text, reply_markup = await get_garage_text_and_markup(user_id)
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)


# ═══════════════════════════════════════════════════════════════════════════
#                       MAINTENANCE QUOTIDIENNE
# ═══════════════════════════════════════════════════════════════════════════

VEHICLE_BATCH = 100


async def process_vehicles_maintenance():
    """
    Usure, carburant et entretien des véhicules.

    Corrige un blocage « database is locked » : l'ancienne version gardait une
    écriture non validée sur une connexion tout en débitant les joueurs via une
    autre connexion. Ici chaque étape est une transaction courte et validée,
    et les notifications sont écrites dans la même transaction (aucun appel externe).
    """
    # 1) Usure de tous les véhicules : une seule requête
    async with db_connection() as db:
        await db.execute("UPDATE vehicles SET condition = MAX(0, condition - 2)")
        await db.commit()

    # 2) Carburant du véhicule actif, par lots
    last_id = 0
    while True:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            async with db.execute("""
                SELECT v.* FROM vehicles v
                JOIN users u ON u.active_vehicle_id = v.veh_id
                WHERE v.user_id = u.user_id AND v.veh_id > ?
                ORDER BY v.veh_id LIMIT ?
            """, (last_id, VEHICLE_BATCH)) as cur:
                active_vehicles = [dict(r) for r in await cur.fetchall()]
            if not active_vehicles:
                break
            fuel_updates, notifs = [], []
            ts = now()
            for v in active_vehicles:
                veh_data = await get_vehicle_stats(v["veh_type"])
                capacity = veh_data.get("fuel_capacity", 0)
                if capacity > 0:
                    consumption = max(1, int(capacity * 0.05))
                    new_fuel = max(0, v["fuel"] - consumption)
                    fuel_updates.append((new_fuel, v["veh_id"]))
                    if new_fuel == 0 and v["fuel"] > 0:
                        notifs.append((v["user_id"], f"⛽ Le réservoir de votre {v['veh_type']} est vide !", ts))
            if fuel_updates:
                await db.executemany("UPDATE vehicles SET fuel = ? WHERE veh_id = ?", fuel_updates)
            if notifs:
                await db.executemany(
                    "INSERT INTO notifications (user_id, title, message, created_at) VALUES (?, 'Notification', ?, ?)",
                    notifs,
                )
            await db.commit()
        last_id = active_vehicles[-1]["veh_id"]
        await asyncio.sleep(0)

    # 3) Frais d'entretien, par lots. Débit gardé : jamais de solde négatif.
    last_id = 0
    while True:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            async with db.execute(
                "SELECT veh_id, user_id, luxury, veh_type FROM vehicles "
                "WHERE veh_id > ? ORDER BY veh_id LIMIT ?",
                (last_id, VEHICLE_BATCH),
            ) as cur:
                batch = [dict(r) for r in await cur.fetchall()]
            if not batch:
                break
            ts = now()
            for v in batch:
                lux = v["luxury"] or (await get_vehicle_stats(v["veh_type"])).get("luxury", 0)
                cost = lux * 2
                if cost <= 0:
                    continue
                res = await db.execute(
                    "UPDATE users SET balance = balance - ?, total_spent = total_spent + ? "
                    "WHERE user_id = ? AND balance >= ?",
                    (cost, cost, v["user_id"], cost),
                )
                if res.rowcount > 0:
                    await snapshot_user_core_stats(v["user_id"], db)
                else:
                    await db.execute(
                        "UPDATE vehicles SET condition = MAX(0, condition - 5) WHERE veh_id = ?",
                        (v["veh_id"],),
                    )
                    await db.execute(
                        "INSERT INTO notifications (user_id, title, message, created_at) VALUES (?, 'Notification', ?, ?)",
                        (v["user_id"], f"⚠️ Entretien impayé pour votre {v['veh_type']} (état -5%).", ts),
                    )
            await db.commit()
        last_id = batch[-1]["veh_id"]
        await asyncio.sleep(0)


# ═══════════════════════════════════════════════════════════════════════════
#                       MENU INTERACTIF DU MODULE VÉHICULES
# ═══════════════════════════════════════════════════════════════════════════



async def show_vehicles_catalog(query, user_id: int):
    body = ["<i>Pour acheter : menu Véhicules &amp; luxe → Acheter un véhicule.</i>", ""]
    for vtype, data in VEHICLES.items():
        body.append(
            f"{data['emoji']} <b>{vtype}</b>\n"
            f"   💰 {fmt(data['price'])} · 🔧 {fmt(data['maint'])}/mois\n"
            f"   ⚡ {data.get('speed', 0)} · 📦 {data.get('cargo', 0)} · ✨ {data.get('luxury', 0)}"
        )
    await safe_edit(
        query,
        card("📋 CATALOGUE DES VÉHICULES", body, icon="📋", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="veh_menu")]])
    )


async def show_veh_buy_info(query, user_id: int):
    body = [
        "Touche <b>« Acheter un véhicule »</b>, choisis-le dans la liste : c'est tout.",
        "",
        "💡 Consulte le <b>Catalogue</b> pour comparer prix, vitesse, cargo et luxe.",
        "✨ Chaque véhicule te rapporte du <b>prestige</b>.",
    ]
    await safe_edit(
        query,
        card("💰 ACHETER UN VÉHICULE", body, icon="💰", style="round"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🛒 Acheter un véhicule", callback_data="fm:a_acheter_vehicule")],
            [InlineKeyboardButton("📋 Voir le catalogue", callback_data="veh_catalog")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="veh_menu")],
        ])
    )


async def show_veh_sell_info(query, user_id: int):
    body = [
        "Touche <b>« Vendre un véhicule »</b> et choisis-le dans la liste.",
        "",
        "💡 <b>Prix de reprise :</b> 60 % de la valeur neuve,",
        "   ajusté selon l'état du véhicule.",
        "⚠️ Tu perds aussi le prestige gagné à l'achat.",
    ]
    await safe_edit(
        query,
        card("💸 VENDRE UN VÉHICULE", body, icon="💸", style="round"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💸 Vendre un véhicule", callback_data="fm:a_vendre_vehicule")],
            [InlineKeyboardButton("📋 Mon garage", callback_data="veh_garage")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="veh_menu")],
        ])
    )


async def show_veh_vip_info(query, user_id: int):
    from config import VIP_LUXE_REQUIRED
    body = [
        "✨ <b>Accès VIP</b>",
        "",
        "Pour entrer dans les lieux prestigieux, il te faut :",
        "  • Un <b>véhicule actif</b>",
        f"  • Un niveau de luxe ≥ <b>{VIP_LUXE_REQUIRED}/100</b>",
    ]
    await safe_edit(
        query,
        card("✨ ACCÈS VIP", body, icon="✨", style="stars"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✨ Vérifier mon accès", callback_data="veh_vip_check"),
             InlineKeyboardButton("🏛️ Voir les lieux", callback_data="veh_vip_places")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="veh_menu")],
        ])
    )


async def show_veh_vip_places(query, user_id: int):
    from config import VIP_LIEUX
    body = ["<i>Lieux réservés aux véhicules de luxe :</i>", ""]
    for lieu in VIP_LIEUX:
        body.append(f"  • {lieu}")
    await safe_edit(
        query,
        card("🏛️ LIEUX VIP", body, icon="🏛️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✨ Vérifier mon accès", callback_data="veh_vip_check")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="veh_menu")],
        ])
    )


async def show_veh_cargo_info(query, user_id: int):
    active = await get_active_vehicle(user_id)
    if not active:
        await safe_edit(
            query,
            "🚫 Aucun véhicule actif.\n\nSélectionne-en un dans ton Garage.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="veh_menu")]])
        )
        return

    veh_data = await get_vehicle_stats(active["veh_type"])
    cargo = active.get("cargo", 0) or veh_data.get("cargo", 0)
    bonus = min(20, int(cargo / 5))

    body = [
        f"🚗 Véhicule : <b>{active['veh_type']}</b>",
        f"📦 Cargo : <b>{cargo}/100</b>",
        f"💰 Bonus sur les ventes : <b>+{bonus}%</b>",
        "",
        "<i>Ce bonus s'applique automatiquement lors des ventes au marché.</i>",
    ]
    await safe_edit(
        query,
        card("📦 BONUS CARGO", body, icon="📦", style="round"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="veh_menu")]])
    )


async def vehicles_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "veh_menu":
        from handlers.hub import open_zone; await open_zone(query, "vehicles")
        return
    if data == "veh_garage":
        text, reply_markup = await get_garage_text_and_markup(user_id)
        await safe_edit(query, text, parse_mode="HTML", reply_markup=reply_markup)
        return
    if data == "veh_catalog":
        await show_vehicles_catalog(query, user_id)
        return
    if data == "veh_buy_info":
        await show_veh_buy_info(query, user_id)
        return
    if data == "veh_sell_info":
        await show_veh_sell_info(query, user_id)
        return
    if data == "veh_vip_info":
        await show_veh_vip_info(query, user_id)
        return
    if data == "veh_vip_places":
        await show_veh_vip_places(query, user_id)
        return
    if data == "veh_vip_check":
        active = await get_active_vehicle(user_id)
        if not active:
            await safe_edit(
                query,
                "🚫 Pas de véhicule actif.",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="veh_menu")]])
            )
            return
        veh_data = await get_vehicle_stats(active["veh_type"])
        luxe = active.get("luxury", 0) or veh_data.get("luxury", 0)
        from config import VIP_LUXE_REQUIRED
        if luxe >= VIP_LUXE_REQUIRED:
            msg = f"✅ <b>Accès VIP accordé !</b>\n\n✨ Luxe : <b>{luxe}/100</b>"
        else:
            missing = VIP_LUXE_REQUIRED - luxe
            msg = f"🔒 <b>Accès refusé</b>\n\n✨ Luxe : <b>{luxe}/100</b>\n⚠️ Il te manque <b>{missing}</b> points."
        await safe_edit(
            query, msg, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="veh_menu")]])
        )
        return
    if data == "veh_cargo_info":
        await show_veh_cargo_info(query, user_id)
        return