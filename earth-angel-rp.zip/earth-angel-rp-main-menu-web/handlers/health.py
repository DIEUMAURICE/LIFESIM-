# handlers/health.py
import random
import aiosqlite
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import db_connection, DB_PATH, get_user, update_balance, update_field, increment_field
from utils.gametime import fmt_game_datetime
from utils.decorators import require_registered, cooldown, require_free
from utils.location import require_location
from utils.helpers import fmt, fmt_time, now
from utils.aesthetics import rich_bar as health_bar
from config import GYM_COST, GYM_ENERGY_BONUS
from utils.vip import add_xp
from utils.gametime import add_game_months


# ─────────────────────────────────────────────────────────────────────────────
# Helper : vérifier si hospitalisé
# ─────────────────────────────────────────────────────────────────────────────
async def _check_hospitalized(u: dict) -> tuple[bool, str]:
    """Vérifie si le joueur est hospitalisé et renvoie (True, message)."""
    if u.get("hospital_until", 0) > now():
        remaining = u["hospital_until"] - now()
        return True, f"🏥 Tu es hospitalisé pour encore {fmt_time(remaining)}. Repose-toi !"
    return False, None


# ─────────────────────────────────────────────────────────────────────────────
# Fonctions d'action (sans envoi de message direct)
# ─────────────────────────────────────────────────────────────────────────────

async def action_sante(user_id: int) -> str:
    """Retourne l'état de santé formaté."""
    u = await get_user(user_id)

    def status(val):
        if val >= 80: return "🟢 Excellent"
        if val >= 60: return "🟡 Bon"
        if val >= 40: return "🟠 Moyen"
        if val >= 20: return "🔴 Mauvais"
        return "⚫ Critique"

    async with db_connection() as db:
        async with db.execute("SELECT * FROM insurance WHERE user_id=?", (user_id,)) as cur:
            ins = await cur.fetchone()
    ins_text = f"✅ Assuré(e) ({ins[1]})" if ins else "❌ Non assuré(e)"

    hospital_until = u.get("hospital_until", 0)
    if hospital_until > now():
        remaining = hospital_until - now()
        hospital_status = f"\n🏥 <b>Hospitalisé</b> : {fmt_time(remaining)} restant"
    else:
        hospital_status = ""

    text = (
        f"❤️ <b>Santé</b>\n\n"
        f"❤️ Santé : [{health_bar(u['health'])}] {u['health']}% — {status(u['health'])}\n"
        f"⚡ Énergie : [{health_bar(u['energy'])}] {u['energy']}% — {status(u['energy'])}\n"
        f"😊 Bonheur : [{health_bar(u['happiness'])}] {u['happiness']}% — {status(u['happiness'])}\n"
        f"🍽️ Faim : [{health_bar(u['hunger'])}] {u['hunger']}% — {status(u['hunger'])}\n"
        f"😰 Stress : [{health_bar(u['stress'])}] {u['stress']}% — {status(100 - u['stress'])}\n\n"
        f"🏥 Assurance : {ins_text}{hospital_status}"
    )

    warnings = []
    if u["health"] < 30:   warnings.append("⚠️ Ta santé est critique ! Va voir un médecin !")
    if u["energy"] < 20:   warnings.append("⚠️ Tu es épuisé(e) ! Dors avant de travailler.")
    if u["hunger"] < 20:   warnings.append("⚠️ Tu as très faim ! Mange quelque chose.")
    if u["stress"] > 80:   warnings.append("⚠️ Ton stress est dangereux ! Prends des vacances.")

    if warnings:
        text += "\n\n" + "\n".join(warnings)

    return text

async def action_gym(user_id: int) -> str:
    """Action gym - retourne le résultat formaté."""
    u = await get_user(user_id)

    hospitalized, msg = await _check_hospitalized(u)
    if hospitalized:
        return msg

    if u["balance"] < GYM_COST:
        return f"❌ La salle de sport coûte {fmt(GYM_COST)}."

    if u["energy"] < 20:
        return "😴 Tu es trop fatigué(e) pour faire du sport !"

    if u["hunger"] < 10:
        return "🍽️ Tu as trop faim pour faire du sport ! Mange d'abord."

    await update_balance(user_id, -GYM_COST, sink="loisirs")

    energy_cost = random.randint(25, 35)
    health_gain = random.randint(5, 15)
    happiness_gain = random.randint(5, 15)
    stress_loss = random.randint(10, 20)
    hunger_loss = random.randint(10, 20)

    from database import upgrade_skill
    force_boost = random.random() < 0.3
    if force_boost:
        await upgrade_skill(user_id, "Force")
        force_text = "\n💪 +1 niveau en Force !"
    else:
        force_text = ""

    new_energy = max(0, u["energy"] - energy_cost)
    new_health = min(100, u["health"] + health_gain)
    new_happiness = min(100, u["happiness"] + happiness_gain)
    new_stress = max(0, u["stress"] - stress_loss)
    new_hunger = max(0, u["hunger"] - hunger_loss)

    await update_field(user_id, "energy", new_energy)
    await update_field(user_id, "health", new_health)
    await update_field(user_id, "happiness", new_happiness)
    await update_field(user_id, "stress", new_stress)
    await update_field(user_id, "hunger", new_hunger)
    xp_gain = 80
    await add_xp(user_id, xp_gain)   # ✅ Fix #11 : boost + hook compétition
    await update_field(user_id, "gym_last", now())

    workouts = [
        "🏋️ Musculation intensive",
        "🏃 Cardio 5km",
        "🤸 Yoga & stretching",
        "🥊 Boxe",
        "🏊 Natation",
        "🚴 Vélo d'appartement",
    ]

    return (
        f"💪 **Séance de sport !**\n\n"
        f"🏋️ Entraînement : {random.choice(workouts)}\n\n"
        f"❤️ Santé : +{health_gain}% → {new_health}%\n"
        f"😊 Bonheur : +{happiness_gain}% → {new_happiness}%\n"
        f"😰 Stress : -{stress_loss}% → {new_stress}%\n"
        f"⚡ Énergie : -{energy_cost}% → {new_energy}%\n"
        f"🍽️ Faim : -{hunger_loss}% → {new_hunger}%\n"
        f"✨ +{xp_gain} XP{force_text}\n"
        f"💰 Coût : {fmt(GYM_COST)}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Commandes existantes (wrappers)
# ─────────────────────────────────────────────────────────────────────────────

@require_registered
async def cmd_sante(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """État de santé (commande textuelle)."""
    text = await action_sante(update.effective_user.id)
    await update.message.reply_text(text, parse_mode="HTML")

@require_registered
@require_free
@cooldown("gym_last", 43200, "⏳ Tu es fatigué de la salle. Reviens dans 12h.")
async def cmd_gym(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gym (commande textuelle)."""
    text = await action_gym(update.effective_user.id)
    await update.message.reply_text(text, parse_mode="HTML")


# Médicaments, hôpital, consultation (/medecin) et assurance : voir handlers/sante.py
# (faction Santé publique, coffre général, ambulances, lits).


# ─────────────────────────────────────────────────────────────────────────────
# Maintenance : dégradation quotidienne
# ─────────────────────────────────────────────────────────────────────────────
async def process_health_maintenance():
    """Détériore légèrement la santé de tous les joueurs chaque jour."""
    async with db_connection() as db:
        await db.execute("UPDATE users SET hospital_until=0 WHERE hospital_until > 0 AND hospital_until < ?", (now(),))
        await db.execute(
            "UPDATE users SET health = MAX(0, health - ABS(RANDOM() % 5) - 1), "
            "energy = MAX(0, energy - ABS(RANDOM() % 7) - 2), "
            "stress = MIN(100, stress + ABS(RANDOM() % 5) + 1), "
            "hunger = MAX(0, hunger - ABS(RANDOM() % 11) - 5) "
            "WHERE registered = 1 AND hospital_until <= ?",
            (now(),)
        )
        await db.execute("DELETE FROM insurance WHERE since < ?", (add_game_months(now(), -1),))
        await db.commit()