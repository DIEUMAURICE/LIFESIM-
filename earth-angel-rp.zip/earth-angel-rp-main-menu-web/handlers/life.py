import html as _html
# handlers/life.py — Menu de vie interactif complet avec sous-menus
import random
import aiosqlite
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import db_connection, DB_PATH, get_user, update_balance, update_field, now, increment_field
from utils.gametime import fmt_game_datetime
from utils.decorators import require_registered
from utils.helpers import fmt, fmt_time, fmt_duration, escape_html
from utils.aesthetics import card, alert, age_stage, mini_stat
from utils.simulation import current_season
from config import SEASON_EFFECTS, SANTE_HEAD_LEVEL, DAILY_COOLDOWN, WORK_COOLDOWN
from utils.cooldowns import cooldown_left
from utils.gametime import add_game_months


# ═══════════════════════════════════════════════════════════════════
#                    HELPERS SAISON (robustes)
# ═══════════════════════════════════════════════════════════════════
def _season_info(season: str):
    """Retourne (label_capitalisé, icône) pour une saison, en tolérant la casse."""
    season_key = season.capitalize() if season else ""
    icons = {"Hiver": "❄️", "Printemps": "🌸", "Été": "☀️", "Automne": "🍂"}
    return season_key, icons.get(season_key, "🌍")


# ═══════════════════════════════════════════════════════════════════
#                        /vie ─ MENU INTERACTIF
# ═══════════════════════════════════════════════════════════════════
VIE_HOLD = "vie_hold"      # bouton « titre de catégorie » : ne fait rien


def _header(label: str) -> list:
    """Ligne-titre d'une catégorie du menu (bouton inerte)."""
    return [InlineKeyboardButton(f"━━ {label} ━━", callback_data=VIE_HOLD)]


async def _vie_view(user_id: int) -> tuple[str, InlineKeyboardMarkup]:
    """Texte + clavier du menu Vie : TOUT le gameplay « vie » rangé par catégorie.

    Santé = faction gouvernementale « Santé publique » (handlers/sante.py, boutons hop:…) :
    hôpitaux, ambulance, médicaments, assurance et poste sont gérés là-bas, plus ici.
    """
    from utils import sante
    u = await get_user(user_id)
    age = u.get("age", 20)
    age_label, age_icon = age_stage(age)
    season_label, season_icon = _season_info(current_season())

    try:
        ins = await sante.get_insurance(user_id)
        staff = await sante.get_staff(user_id)
    except Exception:           # la santé ne doit jamais empêcher d'ouvrir le menu
        ins, staff = None, None

    lines = [
        f"{age_icon} <b>{age} ans</b> · {age_label} · {season_icon} <b>{season_label}</b>",
        "",
        f"❤️ <b>{u.get('health', 100)}%</b> · ⚡ <b>{u.get('energy', 100)}%</b>",
        f"🍽️ <b>{u.get('hunger', 100)}%</b> · 😊 <b>{u.get('happiness', 100)}%</b>",
        f"😰 Stress : <b>{u.get('stress', 0)}%</b>",
        f"💰 Solde : <b>{fmt(u['balance'])}</b>",
        "🛡️ Assurance : " + (f"<b>{ins['type'].capitalize()}</b> ({ins['left']} remb.)" if ins else "aucune"),
    ]
    if staff:
        duty = ""
        if staff["role"] in sante.CARE_ROLES:
            duty = " · 🟢 en service" if staff["on_duty"] else " · ⚪ hors service"
        lines.append(f"{staff['post_emoji']} Santé publique : <b>{staff['post_name']}</b>{duty}")
    if u.get("hospital_until", 0) > now():
        lines.append(f"🏥 Hospitalisé(e) encore <b>{fmt_time(u['hospital_until'] - now())}</b>")
    lines += ["", "<i>Choisis une action ci-dessous :</i>"]

    B = InlineKeyboardButton
    kb = [
        _header("🧍 BESOINS & FORME"),
        [B("📊 État de santé", callback_data="vie_sante"), B("🍽️ Manger", callback_data="vie_manger")],
        [B("🛌 Dormir", callback_data="vie_dormir"), B("🏋️ Gym", callback_data="vie_gym")],

        _header("🏥 SANTÉ PUBLIQUE"),
        [B("🏥 Hôpital", callback_data="hop:home"), B("🚑 Ambulance (gratuit)", callback_data="hop:amb")],
        [B("💊 Médicaments", callback_data="hop:pharma"), B("🛡️ Assurance", callback_data="hop:ins")],
        [B("🏥 Hôpitaux & trajet", callback_data="hop:list"), B("👔 Mon poste santé", callback_data="hop:job")],
    ]
    if staff and staff["level"] >= SANTE_HEAD_LEVEL:
        kb.append([B("👥 Équipe & direction", callback_data="hop:team"),
                   B("📦 Stocks", callback_data="hop:stock")])
    elif staff and staff["role"] in sante.CARE_ROLES:
        kb.append([B("📟 Appels en attente", callback_data="hop:calls")])
    kb += [
        _header("🏠 LOGEMENT & DÉPLACEMENTS"),
        [B("🏠 Logement", callback_data="logement_home"), B("🧭 Me déplacer", callback_data="loc_map")],

        _header("📔 SUIVI"),
        [B("📔 Journal", callback_data="vie_journal"), B("⚡ Routine", callback_data="vie_routine")],

        [B("⬅️ Menu principal", callback_data="hub:home")],
    ]
    return "\n".join(lines), InlineKeyboardMarkup(kb)


@require_registered
async def cmd_vie(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menu Vie : besoins, santé publique, logement, suivi."""
    text, markup = await _vie_view(update.effective_user.id)
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=markup)


# ─── Santé : redirection vers la faction « Santé publique » ────────────
async def _to_sante(update: Update, screen: str):
    """Ouvre un écran de handlers/sante.py (anciens boutons vie_/medicaments_/hopital_ compris)."""
    from handlers import sante
    uid = update.callback_query.from_user.id
    if screen == "pharma":
        await sante.show_pharmacy(update, uid)
    elif screen == "ins":
        await sante.show_insurance(update, uid)
    else:
        await sante.show_home(update, uid)


# ─── Callback principal pour le menu vie ──────────────────────────────
async def vie_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gère les clics sur le menu vie."""
    query = update.callback_query
    await query.answer()

    action = query.data
    user_id = query.from_user.id

    if action == VIE_HOLD:          # titre de catégorie
        return

    # ─── Navigation vers les sous-menus ──────────────────────────────
    if action == "vie_manger":
        await show_manger_menu(query)
        return

    # ─── Santé : tout passe par la Santé publique ─────────────────────
    # (anciens boutons de messages déjà envoyés : on les redirige au lieu de les ignorer)
    if action in ("vie_medicaments",) or action.startswith("medicaments_"):
        await _to_sante(update, "pharma")
        return

    if action in ("vie_assurance",) or action.startswith("vie_assurance_sub_"):
        await _to_sante(update, "ins")
        return

    if action == "hopital_check":
        await show_sante(query, user_id)
        return

    if action == "vie_hopital" or action.startswith("hopital_"):
        await _to_sante(update, "home")
        return

    # ─── Actions simples (sans sous-menu) ─────────────────────────────
    if action == "vie_sante":
        await show_sante(query, user_id)
        return

    if action == "vie_dormir":
        await do_dormir(query, user_id)
        return

    if action == "vie_gym":
        await do_gym(query, user_id)
        return

    if action == "vie_journal":
        await show_journal(query, user_id)
        return

    if action == "vie_routine":
        await show_routine(query, user_id)
        return

    # ─── Retour au menu Vie ────────────────────────────────────────────
    if action == "vie_retour":
        from handlers.hub import open_zone
        await open_zone(query, "life")
        return

    if action.startswith("manger_"):
        await do_manger_option(query, user_id, action)
        return

    # Fallback
    await query.edit_message_text("❌ Action inconnue.")


# ═══════════════════════════════════════════════════════════════════
#                    SOUS-MENU : MANGER
# ═══════════════════════════════════════════════════════════════════
async def show_manger_menu(query):
    """Menu des repas (catégories → étoiles) : logique dans handlers/meals.py."""
    await meals_callback(query, query.from_user.id, "manger_menu")


async def do_manger_option(query, user_id: int, action: str):
    """Navigation et achat des repas (manger_menu / manger_cat_* / manger_eat_* / anciennes clés)."""
    await meals_callback(query, user_id, action)


# ═══════════════════════════════════════════════════════════════════
#                    ACTIONS SIMPLES
# ═══════════════════════════════════════════════════════════════════

async def show_sante(query, user_id: int):
    """Affiche l'état de santé."""
    u = await get_user(user_id)

    def status(val):
        if val >= 80: return "🟢 Excellent"
        if val >= 60: return "🟡 Bon"
        if val >= 40: return "🟠 Moyen"
        if val >= 20: return "🔴 Mauvais"
        return "⚫ Critique"

    text = (
        f"❤️ <b>Santé</b>\n\n"
        f"❤️ Santé : {escape_html(u['health'])}% — {escape_html(status(u['health']))}\n"
        f"⚡ Énergie : {escape_html(u['energy'])}% — {escape_html(status(u['energy']))}\n"
        f"😊 Bonheur : {escape_html(u['happiness'])}% — {escape_html(status(u['happiness']))}\n"
        f"🍽️ Faim : {escape_html(u['hunger'])}% — {escape_html(status(u['hunger']))}\n"
        f"😰 Stress : {escape_html(u['stress'])}% — {escape_html(status(100 - u['stress']))}\n"
    )

    keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="vie_retour")]]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def do_dormir(query, user_id: int):
    """Action dormir."""
    u = await get_user(user_id)

    if u.get("hospital_until", 0) > now():
        remaining = u["hospital_until"] - now()
        await query.edit_message_text(f"🏥 Tu es hospitalisé pour encore {fmt_time(remaining)}.")
        return

    if u["energy"] >= 100:
        await query.edit_message_text("🛌 Tu n'as pas besoin de dormir, tu es en pleine forme !")
        return

    gain = random.randint(20, 45)
    new_energy = min(100, u["energy"] + gain)
    await update_field(user_id, "energy", new_energy)

    keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="vie_retour")]]
    await query.edit_message_text(
        f"🛌 **Dormir**\n\n"
        f"Tu as bien dormi.\n"
        f"⚡ Énergie : {u['energy']}% → **{new_energy}%**",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def do_gym(query, user_id: int):
    """Action gym."""
    u = await get_user(user_id)

    if u.get("hospital_until", 0) > now():
        remaining = u["hospital_until"] - now()
        await query.edit_message_text(f"🏥 Tu es hospitalisé pour encore {fmt_time(remaining)}.")
        return

    from config import GYM_COST

    if u["balance"] < GYM_COST:
        await query.edit_message_text(f"❌ La salle de sport coûte {fmt(GYM_COST)}.")
        return

    if u["energy"] < 20:
        await query.edit_message_text("😴 Tu es trop fatigué(e) pour faire du sport !")
        return

    if u["hunger"] < 10:
        await query.edit_message_text("🍽️ Tu as trop faim pour faire du sport ! Mange d'abord.")
        return

    await update_balance(user_id, -GYM_COST, sink="loisirs")

    energy_cost = random.randint(25, 35)
    health_gain = random.randint(5, 15)
    happiness_gain = random.randint(5, 15)
    stress_loss = random.randint(10, 20)
    hunger_loss = random.randint(10, 20)

    from database import upgrade_skill
    force_boost = random.random() < 0.3
    if force_boost:
        await upgrade_skill(user_id, "Force")
        force_text = "\n💪 +1 niveau en Force !"
    else:
        force_text = ""

    new_energy = max(0, u["energy"] - energy_cost)
    new_health = min(100, u["health"] + health_gain)
    new_happiness = min(100, u["happiness"] + happiness_gain)
    new_stress = max(0, u["stress"] - stress_loss)
    new_hunger = max(0, u["hunger"] - hunger_loss)

    await update_field(user_id, "energy", new_energy)
    await update_field(user_id, "health", new_health)
    await update_field(user_id, "happiness", new_happiness)
    await update_field(user_id, "stress", new_stress)
    await update_field(user_id, "hunger", new_hunger)

    xp_gain = 80
    from utils.vip import add_xp
    await add_xp(user_id, xp_gain)   # ✅ Fix #11 : boost + hook compétition
    await update_field(user_id, "gym_last", now())

    workouts = [
        "🏋️ Musculation intensive",
        "🏃 Cardio 5km",
        "🤸 Yoga & stretching",
        "🥊 Boxe",
        "🏊 Natation",
        "🚴 Vélo d'appartement",
    ]

    keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="vie_retour")]]
    await query.edit_message_text(
        f"💪 **Séance de sport !**\n\n"
        f"🏋️ Entraînement : {random.choice(workouts)}\n\n"
        f"❤️ Santé : +{health_gain}% → {new_health}%\n"
        f"😊 Bonheur : +{happiness_gain}% → {new_happiness}%\n"
        f"😰 Stress : -{stress_loss}% → {new_stress}%\n"
        f"⚡ Énergie : -{energy_cost}% → {new_energy}%\n"
        f"🍽️ Faim : -{hunger_loss}% → {new_hunger}%\n"
        f"✨ +{xp_gain} XP{force_text}\n"
        f"💰 Coût : {fmt(GYM_COST)}",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def show_journal(query, user_id: int):
    """Affiche le journal de vie."""
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT category, summary, severity, created_at FROM life_journal "
            "WHERE user_id=? ORDER BY created_at DESC LIMIT 15",
            (user_id,)
        ) as cur:
            rows = await cur.fetchall()

    if not rows:
        text = "📔 Ton journal de vie est encore vierge.\nDes événements s'y inscriront à mesure que tu joues."
        keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="vie_retour")]]
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
        return

    icons = {"success": "✅", "info": "💡", "warning": "⚠️", "danger": "🚨", "error": "❌"}
    lines = []
    current = now()
    for r in rows:
        elapsed = current - r["created_at"]
        ago = fmt_duration(elapsed)
        ic = icons.get(r["severity"], "•")
        cat = r["category"].upper()
        lines.append(f"{ic} <b>[{_html.escape(str(cat))}]</b>  <i>il y a {ago}</i>")
        lines.append(f"   {_html.escape(str(r['summary']))}")
        lines.append("")

    text = "📔 <b>Journal de vie</b>\n\n" + "\n".join(lines[:10])
    keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="vie_retour")]]
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_routine(query, user_id: int):
    """Affiche la routine quotidienne."""
    u = await get_user(user_id)

    actions = []

    if u.get("hunger", 100) < 40:
        actions.append("🍽️ <b>Manger</b> — URGENCE : ta faim est critique")
    elif u.get("hunger", 100) < 60:
        actions.append("🍽️ <b>Manger</b> — restaure ta faim")

    if u.get("energy", 100) < 30:
        actions.append("🛌 <b>Dormir</b> — URGENCE : tu es épuisé(e)")
    elif u.get("energy", 100) < 50:
        actions.append("🛌 <b>Dormir</b> — regagne de l'énergie")

    if u.get("health", 100) < 50:
        actions.append("🏥 <b>Hôpital</b> — consulte vite")
    if u.get("stress", 0) > 60:
        actions.append("🧘 <b>Gym</b> — baisse ton stress")

    if await cooldown_left(user_id, "daily_last", DAILY_COOLDOWN) == 0:
        actions.append("💰 <b>Quotidien</b> — ton bonus journalier est dispo !")
    if await cooldown_left(user_id, "freelance_last", WORK_COOLDOWN) == 0:
        actions.append("💼 <b>Travailler</b> — ton job peut te payer")

    if not actions:
        text = "🏆 <b>Tu es au top !</b>\nTes besoins sont satisfaits, ton économie tourne."
    else:
        text = "🧭 <b>Routine recommandée</b>\n\n" + "\n".join(f"• {a}" for a in actions[:5])

    keyboard = [
        [InlineKeyboardButton("🔄 Actualiser", callback_data="vie_routine")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="vie_retour")],
    ]

    # Éviter l'erreur "Message is not modified"
    try:
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
    except Exception as e:
        if "Message is not modified" in str(e):
            await query.answer("Rien n'a changé !")
        else:
            raise


# ══════════════════════════════════════════════════════════════════════
#  REPAS — catégories et étoiles (ex handlers/meals.py)
# ══════════════════════════════════════════════════════════════════════
from config import (MEALS, MEAL_CATEGORIES, MEAL_LEGACY, NOT_HUNGRY_AT, MEAL_PLACE, MEAL_SCORE_MULT,
                    MEAL_SCORE_LABEL, MEAL_BITES_BASE, MEAL_FINISH_SCORE)
from database import add_life_journal
from utils.decorators import require_free


def _stars(n: int) -> str:
    return "⭐" * n


def _clamp(v: int) -> int:
    return max(0, min(100, v))


def _effects_line(m: dict) -> str:
    parts = [f"🍽️ +{m['hunger']}%"]
    if m["energy"]:
        parts.append(f"⚡ +{m['energy']}%")
    if m["health"]:
        parts.append(f"❤️ {m['health']:+d}%")
    if m["stress"]:
        parts.append(f"😰 {m['stress']:+d}%")
    if m["happiness"]:
        parts.append(f"😊 +{m['happiness']}%")
    return " · ".join(parts)


def categories_view() -> tuple[str, InlineKeyboardMarkup]:
    kb = [[InlineKeyboardButton(f"{c['emoji']} {c['name']}", callback_data=f"manger_cat_{k}")]
          for k, c in MEAL_CATEGORIES.items()]
    kb.append([InlineKeyboardButton("⬅️ Retour", callback_data="vie_retour")])
    return "🍽️ <b>Où veux-tu manger ?</b>\nChoisis un type de repas.", InlineKeyboardMarkup(kb)


def meals_view(cat: str) -> tuple[str, InlineKeyboardMarkup]:
    c = MEAL_CATEGORIES[cat]
    lines = [f"{c['emoji']} <b>{c['name']}</b>\n<i>{c['desc']}</i>\n"]
    kb = []
    for key, m in MEALS.items():
        if m["cat"] != cat:
            continue
        lines.append(f"{m['emoji']} <b>{m['name']}</b> {_stars(m['stars'])} — {fmt(m['cost'])}\n   {_effects_line(m)}")
        kb.append([InlineKeyboardButton(f"{m['emoji']} {m['name']} {_stars(m['stars'])} · {fmt(m['cost'])}",
                                        callback_data=f"manger_eat_{key}")])
    kb.append([InlineKeyboardButton("⬅️ Catégories", callback_data="manger_menu")])
    return "\n".join(lines), InlineKeyboardMarkup(kb)


def _eat_blocker(u: dict, m: dict) -> str | None:
    t = now()
    if u.get("prison_until", 0) > t:
        return f"⛓️ En prison, tu manges la gamelle. Libération dans {fmt_time(u['prison_until'] - t)}."
    if u.get("hospital_until", 0) > t:
        return f"🏥 Tu es hospitalisé(e) pour encore {fmt_time(u['hospital_until'] - t)}."
    if u.get("hunger", 100) >= NOT_HUNGRY_AT:
        return "🍽️ Tu n'as pas faim pour le moment."
    if u["balance"] < m["cost"]:
        return f"❌ Fonds insuffisants. Coût : {fmt(m['cost'])}"
    return None


async def pay_meal(user_id: int, meal_key: str) -> tuple[bool, str]:
    """Paiement automatique du repas choisi. Retourne (succès, message d'erreur éventuel)."""
    m = MEALS.get(MEAL_LEGACY.get(meal_key, meal_key))
    if not m:
        return False, "❌ Repas inconnu."
    blocked = _eat_blocker(await get_user(user_id), m)
    if blocked:
        return False, blocked
    await update_balance(user_id, -m["cost"], sink="vie_courante")
    return True, ""


async def apply_meal(user_id: int, meal_key: str, score: int = 2) -> str:
    """Effets du repas (déjà payé) selon le score du mini-jeu : un bon repas profite plus."""
    meal_key = MEAL_LEGACY.get(meal_key, meal_key)
    m = MEALS[meal_key]
    mult = MEAL_SCORE_MULT[score]
    u = await get_user(user_id)

    def scaled(v: int) -> int:
        return int(round(v * mult)) if v > 0 else v

    gains = {"hunger": scaled(m["hunger"]), "energy": scaled(m["energy"]), "health": scaled(m["health"]),
             "happiness": scaled(m["happiness"]), "stress": m["stress"] if m["stress"] > 0 else int(round(m["stress"] * mult))}
    default = {"hunger": 100, "energy": 100, "health": 100, "stress": 0, "happiness": 100}
    new = {f: _clamp(u.get(f, default[f]) + d) for f, d in gains.items()}
    for field, value in new.items():
        if value != u.get(field):
            await update_field(user_id, field, value)
    await add_life_journal(user_id, "nutrition",
                           f"Repas : {m['name']} ({_stars(m['stars'])}) pour {fmt(m['cost'])} — {MEAL_SCORE_LABEL[score]}.",
                           severity="info")
    eff = dict(m, hunger=gains["hunger"], energy=gains["energy"], health=gains["health"],
               stress=gains["stress"], happiness=gains["happiness"])
    return (f"{m['emoji']} <b>{m['name']}</b> {_stars(m['stars'])} — {MEAL_SCORE_LABEL[score]}\n\n"
            f"💰 Payé automatiquement : {fmt(m['cost'])}\n"
            f"🍽️ Faim : {u.get('hunger', 100)}% → <b>{new['hunger']}%</b>\n"
            f"{_effects_line(eff)}")


async def eat_meal(user_id: int, meal_key: str, score: int = 2) -> tuple[bool, str]:
    """Paiement + effets d'un coup (sans mini-jeu). Retourne (succès, texte HTML)."""
    ok, err = await pay_meal(user_id, meal_key)
    if not ok:
        return False, err
    return True, await apply_meal(user_id, meal_key, score)


@require_registered
@require_free
async def cmd_manger(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menu des repas en boutons (catégorie → repas → trajet jusqu'au restaurant)."""
    text, kb = categories_view()
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=kb)


def _after_meal_kb(back: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🍽️ Encore", callback_data=back)],
        [InlineKeyboardButton("🧭 Me déplacer", callback_data="loc_map"),
         InlineKeyboardButton("⬅️ Retour", callback_data="vie_retour")],
    ])


async def _show_transport(query, user_id: int, meal_key: str, here: str):
    """Comment aller au restaurant : à pied, en vélo/véhicule ou en taxi. Pas de mini-jeu : seul le temps compte."""
    from utils.location import plan_options, location_label
    m = MEALS[meal_key]
    opts = await plan_options(user_id, here, MEAL_PLACE)
    lines = [f"🍽️ Pour manger <b>{m['name']}</b>, il faut aller au <b>{location_label(MEAL_PLACE)}</b> "
             f"({opts[0]['km']:g} km).\n<i>Choisis ton moyen de transport : plus il est rapide, plus tu arrives tôt.</i>\n"]
    kb = []
    balance = (await get_user(user_id))["balance"]
    for o in opts:
        if o["mode"] == "taxi" and o["ok"] and balance < o["money"] + m["cost"]:
            o["ok"], o["why"] = False, "course + repas trop chers pour ton solde"
        if o["mode"] == "walk":
            detail = f"⚡ -{o['energy']}%"
        elif o["mode"] == "taxi":
            detail = f"💶 -{fmt(o['money'])}"
        elif o["fuel"]:
            detail = f"⛽ -{o['fuel']} · 🔧 usure"
        else:
            detail = "sans carburant"
        if o["ok"]:
            kb.append([InlineKeyboardButton(f"{o['label']} · ⏱️ {fmt_time(o['duration'])} · {detail}",
                                            callback_data=f"manger_go_{meal_key}_{o['mode']}")])
        else:
            lines.append(f"🚫 {o['label']} : {o['why']}")
    kb.append([InlineKeyboardButton("⬅️ Retour", callback_data=f"manger_cat_{m['cat']}")])
    await query.edit_message_text("\n".join(lines), parse_mode="HTML", reply_markup=InlineKeyboardMarkup(kb))


# ── Mini-jeu « manger » : on appuie sur le plat, une bouchée à la fois, jusqu'à le finir ──
_EATING: dict[int, dict] = {}      # user_id → {"key": repas, "left": bouchées restantes, "total": bouchées}


def _eating_view(st: dict, prefix: str = "") -> tuple[str, InlineKeyboardMarkup]:
    m = MEALS[st["key"]]
    done = st["total"] - st["left"]
    bar = "🟩" * done + "⬜" * st["left"]
    text = (f"{prefix}{m['emoji']} <b>{m['name']}</b> {_stars(m['stars'])}\n\n"
            f"{bar}  {done}/{st['total']} bouchées\n\n"
            f"<i>Appuie sur ton plat pour le manger jusqu'au bout !</i>")
    kb = InlineKeyboardMarkup([[InlineKeyboardButton(f"{m['emoji']} {m['name']} · croquer", callback_data=f"manger_bite_{st['key']}")]])
    return text, kb


async def _serve(query, user_id: int, meal_key: str, prefix: str = ""):
    """Au restaurant : paiement automatique, puis le plat s'affiche en bouton : on appuie dessus pour le consommer."""
    meal_key = MEAL_LEGACY.get(meal_key, meal_key)
    m = MEALS[meal_key]
    back = f"manger_cat_{m['cat']}"
    st = _EATING.get(user_id)
    if st is None:                                  # nouveau repas → on le paie une seule fois
        ok, err = await pay_meal(user_id, meal_key)
        if not ok:
            await query.edit_message_text(prefix + err, parse_mode="HTML", reply_markup=_after_meal_kb(back))
            return
        st = _EATING[user_id] = {"key": meal_key, "left": MEAL_BITES_BASE + m["stars"], "total": MEAL_BITES_BASE + m["stars"]}
        prefix += f"💰 Payé automatiquement : {fmt(m['cost'])}\n\n"
    text, kb = _eating_view(st, prefix)
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=kb)


async def _bite(query, user_id: int, meal_key: str):
    """Une pression sur le plat = une bouchée ; à la dernière, le repas est fini et ses effets s'appliquent."""
    st = _EATING.get(user_id)
    meal_key = MEAL_LEGACY.get(meal_key, meal_key)
    if not st or st["key"] != meal_key:
        text, kb = categories_view()
        await query.edit_message_text("🍽️ Ce repas est déjà terminé.\n\n" + text, parse_mode="HTML", reply_markup=kb)
        return
    st["left"] -= 1                                 # pas d'await entre lecture et écriture : un double clic ne passe qu'une fois
    if st["left"] > 0:
        text, kb = _eating_view(st)
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=kb)
        return
    _EATING.pop(user_id, None)
    m = MEALS[meal_key]
    text = await apply_meal(user_id, meal_key, MEAL_FINISH_SCORE)
    await query.edit_message_text("🍽️ <b>Assiette terminée !</b>\n\n" + text, parse_mode="HTML",
                                  reply_markup=_after_meal_kb(f"manger_cat_{m['cat']}"))


async def _go_and_eat(query, user_id: int, meal_key: str, mode: str):
    """Lance le trajet chronométré vers le restaurant (aucun mini-jeu) ; à l'arrivée, le joueur appuie sur son plat."""
    from utils.location import get_position, plan_options, start_travel
    m = MEALS[meal_key]
    back = _after_meal_kb(f"manger_cat_{m['cat']}")
    u = await get_user(user_id)
    blocked = _eat_blocker(u, m)
    pos = await get_position(user_id)
    if blocked or pos["in_transit"]:
        await query.edit_message_text(blocked or "🚶 Tu es déjà en déplacement.", reply_markup=back)
        return
    opt = next((o for o in await plan_options(user_id, pos["location"], MEAL_PLACE) if o["mode"] == mode), None)
    if not opt or not opt["ok"]:
        await query.edit_message_text(f"❌ Trajet impossible : {opt['why'] if opt else 'moyen indisponible'}.", reply_markup=back)
        return
    if mode == "taxi" and u["balance"] < opt["money"] + m["cost"]:
        await query.edit_message_text("❌ Fonds insuffisants : course + repas.", reply_markup=back)
        return
    ok, msg = await start_travel(user_id, MEAL_PLACE, mode)
    if not ok:
        await query.edit_message_text(f"❌ {msg}", reply_markup=back)
        return
    await query.edit_message_text(
        f"🧭 <b>En route vers le restaurant</b>\n{msg}\n\n"
        f"<i>À ton arrivée (tu seras notifié(e)), reviens appuyer sur ton plat.</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(f"{m['emoji']} {m['name']} (une fois arrivé)", callback_data=f"manger_eat_{meal_key}")],
            [InlineKeyboardButton("⬅️ Retour", callback_data=f"manger_cat_{m['cat']}")],
        ]))


async def meals_callback(query, user_id: int, action: str):
    """Appelé par vie_callback pour toute action « manger_* »."""
    from utils.location import get_position
    if action in ("manger_menu", "vie_manger"):
        text, kb = categories_view()
    elif action.startswith("manger_cat_") and action[len("manger_cat_"):] in MEAL_CATEGORIES:
        text, kb = meals_view(action[len("manger_cat_"):])
    elif action.startswith("manger_bite_"):
        await _bite(query, user_id, action[len("manger_bite_"):])
        return
    elif action.startswith("manger_go_"):
        key, mode = action[len("manger_go_"):].rsplit("_", 1)
        if MEALS.get(key):
            await _go_and_eat(query, user_id, key, mode)
            return
        text, kb = categories_view()
    else:
        key = action.replace("manger_eat_", "").replace("manger_", "")
        key = MEAL_LEGACY.get(key, key)
        m = MEALS.get(key)
        if not m:
            text, kb = categories_view()
        else:
            back = f"manger_cat_{m['cat']}"
            if user_id in _EATING:                  # un repas est déjà servi : on reprend l'assiette
                await _serve(query, user_id, _EATING[user_id]["key"])
                return
            blocked = _eat_blocker(await get_user(user_id), m)
            pos = await get_position(user_id)
            if blocked:
                text, kb = blocked, _after_meal_kb(back)
            elif pos["in_transit"]:
                text, kb = "🚶 Tu es en déplacement : attends d'être arrivé(e).", _after_meal_kb(back)
            elif pos["location"] == MEAL_PLACE:
                await _serve(query, user_id, key)
                return
            else:
                await _show_transport(query, user_id, key, pos["location"])
                return
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=kb)
