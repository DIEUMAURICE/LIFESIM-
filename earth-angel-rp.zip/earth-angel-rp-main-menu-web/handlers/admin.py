# handlers/admin.py — GAME FRENCH — Version hiérarchique refactorisée
"""
Console d'administration avec permissions par niveau.

Hiérarchie :
  🟢 Admin N1       → userinfo, userstats, topstats, game_logs (ne sanctionne pas)
  🔴 Admin N2       → + warn, clearwarn, ban, freeze, prison, stats vitales, reset
  🎮 Game Leader    → + événements, broadcast, récompenses
  🎖️ Lead Staff     → + économie lourde, marché, entreprises, balance_stats
  👑 Lead Principal → + godmode, killuser, resetworld, admin_action_log
  👨‍💻 Lead Studio    → + reloadconfig, fix_inventory

📌 NOTE : Les commandes de paiement/transaction (/transactions,
   /transaction_info, /balance_stats, /admin_action_log, /game_logs)
   sont DÉFINIES dans handlers/payments.py et enregistrées dans bot.py.
   Ce fichier liste leur existence dans /admin (aide).
"""
from utils.swallow import swallowed
import aiosqlite
import contextvars
import functools
import time
import random
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from config import DB_PATH, ADMIN_IDS
from database import (
    db_connection,
    DeferredReply,
    get_user, update_field, increment_field, update_balance,
    now, get_all_skills, add_notification,
)
from utils.decorators import (
    admin_n1_only,
    admin_n2_only,
    game_leader_only,
    lead_staff_only,
    lead_principal_only,
    lead_studio_only,
)
from utils.helpers import fmt, parse_amount, fmt_time, escape_html
from utils.aesthetics import card, alert, section, SEP_LIGHT
from handlers.events import EVENT_EFFECTS_DESCRIPTIONS
from utils.gametime import fmt_game_datetime, fmt_game_date, real_now

# ═══════════════════════════════════════════════════════════════════════════
#                       Helpers internes
# ═══════════════════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#   📝 MOTIF OBLIGATOIRE (charte GAME FRENCH) — tout acte du staff sur un joueur est motivé, et le motif est
#   envoyé TEL QUEL au joueur concerné (et inscrit dans le journal).
# ═══════════════════════════════════════════════════════════════
MOTIF_MIN = 3
MOTIF_MAX = 300
_MOTIF: contextvars.ContextVar = contextvars.ContextVar("staff_motif", default=None)
_MOTIF_STATE: contextvars.ContextVar = contextvars.ContextVar("staff_motif_state", default=None)


class _ArgsContext:
    """Contexte PTB dont `args` ne contient plus le motif (les commandes lisent leurs arguments comme avant)."""
    def __init__(self, ctx, args):
        object.__setattr__(self, "_ctx", ctx)
        object.__setattr__(self, "args", args)

    def __getattr__(self, name):
        return getattr(self._ctx, name)


def _split_motif(args: list[str], fixed: int | None, replied: bool) -> tuple[list[str], str]:
    """Sépare (arguments, motif). Un « | » isole toujours le motif ; sinon le motif suit les `fixed` arguments
    (la cible compte pour un argument, sauf si on répond au message du joueur)."""
    raw = " ".join(args)
    if "|" in raw:
        before, _, after = raw.partition("|")
        return before.split(), after.strip()
    if fixed is None:
        return args, ""
    need = fixed + (0 if replied else 1)
    return args[:need], " ".join(args[need:]).strip()


def motif_required(fixed: int | None = 0, example: str = ""):
    """Décorateur : refuse la commande sans motif, nettoie `context.args`, expose le motif (_MOTIF) et, si la
    commande n'a prévenu personne elle-même, envoie au joueur une notification contenant le motif."""
    def deco(fn):
        cmd = fn.__name__.removeprefix("cmd_")

        @functools.wraps(fn)
        async def wrapper(update, context, *a, **k):
            replied = bool(update.message and update.message.reply_to_message)
            args, motif = _split_motif(list(context.args or []), fixed, replied)
            if len(motif) < MOTIF_MIN:
                ex = example or f"/{cmd} @joueur" + (" …" if fixed else "") + " motif"
                await update.message.reply_text(
                    f"❌ <b>Motif obligatoire.</b>\nExemple : <code>{escape_html(ex)}</code>\n"
                    f"<i>Il est envoyé tel quel au joueur concerné. Astuce : tu peux aussi l'écrire après un « | ».</i>",
                    parse_mode="HTML")
                return
            motif = motif[:MOTIF_MAX]
            ctx = _ArgsContext(context, args)
            state = {"notified": False, "logged": False}
            t1, t2 = _MOTIF.set(motif), _MOTIF_STATE.set(state)
            try:
                result = await fn(update, ctx, *a, **k)
                if state["logged"] and not state["notified"]:      # action réussie mais joueur non prévenu
                    target = await _resolve(update, ctx)
                    if target:
                        await _notify_target(ctx, target.id, "⚖️ ACTION DU STAFF",
                                             [f"Par : <b>{escape_html(update.effective_user.full_name)}</b>",
                                              f"Action : <code>/{escape_html(cmd)}</code>"],
                                             icon="⚖️", style="thick", bdd_msg=f"⚖️ Action du staff (/{cmd})")
                return result
            finally:
                _MOTIF.reset(t1)
                _MOTIF_STATE.reset(t2)
        return wrapper
    return deco


async def _notify_target(context, target_id: int, title: str, body: list, icon: str = "🔔",
                          style: str = "thick", bdd_msg: str | None = None):
    """Envoie un message direct à la cible + une notification BDD (silencieux en cas d'échec).
    Si un motif est en cours (décorateur motif_required), il est ajouté TEL QUEL dans les deux."""
    motif = _MOTIF.get()
    if motif:
        body = list(body) + ["", f"📝 <b>Motif :</b> {escape_html(motif)}"]
        bdd_msg = (bdd_msg or f"{icon} {title}") + f" — Motif : {escape_html(motif)}"
        st = _MOTIF_STATE.get()
        if st is not None:
            st["notified"] = True
    try:
        await context.bot.send_message(
            target_id,
            card(title, body, icon=icon, style=style),
            parse_mode="HTML"
        )
    except Exception:
        swallowed('handlers/admin.py')
    try:
        await add_notification(target_id, bdd_msg or f"{icon} {title}")
    except Exception:
        swallowed('handlers/admin.py')


async def _resolve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.reply_to_message:
        return update.message.reply_to_message.from_user
    if not context.args:
        return None
    from utils.user_lookup import find_user       # ID d'abord, puis @pseudo
    found = await find_user(context.args[0])
    if not found:
        return None
    row = (found["user_id"], found["username"], found["full_name"])

    class Fake:
        def __init__(s, uid, un, fn):
            s.id, s.username, s.full_name = uid, un, fn

    return Fake(row[0], row[1] or "", row[2] or "Joueur")


async def _log_admin(admin_id: int, action: str, target_id: int = 0, detail: str = ""):
    """Enregistre une action admin dans les logs (table admin_logs)."""
    motif = _MOTIF.get()
    if motif:
        detail = f"{detail} | motif: {motif}" if detail else f"motif: {motif}"
        st = _MOTIF_STATE.get()
        if st is not None:
            st["logged"] = True
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO admin_logs(admin_id, target_id, action, details, timestamp, real_ts) VALUES(?,?,?,?,?,?)",
            (admin_id, target_id, action, detail[:500], now(), int(__import__("time").time()))
        )
        await db.commit()


async def _add_item_to_inventory(user_id: int, item_id: int, quantity: int = 1, item_type: str = "admin"):
    async with db_connection() as db:
        async with db.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?",
            (user_id, item_id)
        ) as cur:
            existing = await cur.fetchone()
        if existing:
            await db.execute(
                "UPDATE inventory SET quantity = quantity + ? WHERE user_id = ? AND item_id = ?",
                (quantity, user_id, item_id)
            )
        else:
            async with db.execute("SELECT name FROM items WHERE item_id = ?", (item_id,)) as cur2:
                name_row = await cur2.fetchone()
            item_name = name_row[0] if name_row else "Item"
            await db.execute("""
                INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, item_id, item_type, item_name, quantity, now()))
        await db.commit()


async def _remove_item_from_inventory(user_id: int, item_id: int, quantity: int = 1) -> bool:
    async with db_connection() as db:
        async with db.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?",
            (user_id, item_id)
        ) as cur:
            row = await cur.fetchone()
        if not row or row[0] < quantity:
            return False
        new_qty = row[0] - quantity
        if new_qty <= 0:
            await db.execute("DELETE FROM inventory WHERE user_id = ? AND item_id = ?", (user_id, item_id))
        else:
            await db.execute(
                "UPDATE inventory SET quantity = quantity - ? WHERE user_id = ? AND item_id = ?",
                (quantity, user_id, item_id)
            )
        await db.commit()
    return True


async def _set_field(update, context, field, label, parser=int):
    """Helper générique pour les commandes set_*."""
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        val = parser(context.args[-1])
    except Exception:
        await update.message.reply_text(alert("error", "Valeur invalide"), parse_mode="HTML")
        return
    await update_field(t.id, field, val)
    await _log_admin(update.effective_user.id, f"set_{field}", t.id, str(val))
    await update.message.reply_text(
        alert("success", f"{label} de {t.full_name} → {val}"),
        parse_mode="HTML"
    )


# (L'aide /admin et le panneau sont dans handlers/staff.py — panneau staff unique.)

# ═══════════════════════════════════════════════════════════════════════════
#                    🟢 ADMIN N1 — Modération légère
# ═══════════════════════════════════════════════════════════════════════════

@admin_n2_only
@motif_required(0, '/warn @joueur spam dans le chat')
async def cmd_warn(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    u = await get_user(t.id)
    new_count = u.get("warnings", 0) + 1
    await update_field(t.id, "warnings", new_count)
    msg = _MOTIF.get() or "(aucune raison)"
    await _log_admin(update.effective_user.id, "warn", t.id, msg)

    await _notify_target(
        context, t.id,
        "⚠️ AVERTISSEMENT REÇU",
        [
            f"De : <b>{update.effective_user.full_name}</b>",
            f"Total : <b>{new_count}/3</b>",
            "",
            "<i>À 3 avertissements, tu risques des sanctions lourdes.</i>",
        ],
        icon="⚠️", style="thick",
        bdd_msg=f"⚠️ Avertissement reçu ({new_count}/3)",
    )

    await update.message.reply_text(
        card(
            "⚠️ Avertissement",
            [
                f"À : {t.full_name}",
                f"Raison : {msg}",
                f"Total : {new_count}/3",
            ],
            icon="⚠️", style="thick",
        ),
        parse_mode="HTML"
    )


@admin_n2_only
@motif_required(0, '/clearwarn @joueur erreur de modération')
async def cmd_clearwarn(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    await update_field(t.id, "warnings", 0)

    await _notify_target(
        context, t.id,
        "✅ AVERTISSEMENTS EFFACÉS",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            "Tes avertissements ont été remis à zéro.",
            "",
            "<i>Redresse la barre et continue ton aventure !</i>",
        ],
        icon="✅", style="round",
        bdd_msg="✅ Tes avertissements ont été effacés.",
    )

    await update.message.reply_text(
        alert("success", f"Avertissements de {t.full_name} effacés."),
        parse_mode="HTML"
    )


@admin_n1_only
async def cmd_userinfo(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    u = await get_user(t.id)
    body = [
        f"<b>{t.full_name}</b> (ID : <code>{t.id}</code>)",
        f"@{t.username}" if t.username else "—",
        "",
        f"💰 Solde : {fmt(u['balance'])}",
        f"⭐ XP : {u['xp']}  ·  Niveau {u['level']}",
        f"🌟 Karma : {u['karma']}",
        f"👑 Prestige : {u['prestige']}",
        f"💼 Job : {u['job']}",
        f"🎓 Diplôme : {u.get('diplome', '—')}",
        f"🎂 Âge : {u['age']}",
        "",
        f"❤️ {u['health']}% ⚡ {u['energy']}% 🍽️ {u['hunger']}% 😊 {u['happiness']}% 😰 {u['stress']}%",
        "",
        f"📅 Créé : {fmt_game_date(u['created_at'])}",
        f"👀 Dernière connexion : il y a {fmt_time(now() - u['last_seen'])}",
        f"⚠️ Warnings : {u['warnings']}/3",
        f"🚫 Banni : {'OUI' if u['banned'] else 'non'}",
        f"⛓️ Prison : {fmt_time(max(0, u['prison_until'] - now())) if u['prison_until'] > now() else 'libre'}",
        f"⚡ God Mode : {'OUI' if u.get('god_mode') else 'non'}",
    ]
    await update.message.reply_text(
        card("INFO JOUEUR", body, icon="🔍", style="thick"),
        parse_mode="HTML",
    )


@admin_n1_only
async def cmd_userstats(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    u = await get_user(t.id)
    body = [
        f"<b>{t.full_name}</b>",
        "",
        f"💰 Total gagné : {fmt(u.get('total_earned', 0))}",
        f"💸 Total dépensé : {fmt(u.get('total_spent', 0))}",
        f"🥊 Arène : {u.get('arena_wins', 0)}W / {u.get('arena_losses', 0)}L",
        f"💼 Crimes : {u.get('crimes_done', 0)} (✓{u.get('crimes_success', 0)})",
        f"🎯 Missions : {u.get('missions_done', 0)}",
        f"✈️ Voyages : {u.get('travel_count', 0)}",
        f"🎰 Loteries gagnées : {u.get('lottery_wins', 0)}",
        f"🌱 Plantes : {u.get('plants_grown', 0)}",
        f"💻 Hacks : {u.get('hack_attempts', 0)}",
        f"📱 Followers : {u.get('social_followers', 0)}",
        f"🤲 Charité totale : {fmt(u.get('charity_given', 0))}",
    ]
    await update.message.reply_text(
        card("STATS JOUEUR", body, icon="📊", style="thick"),
        parse_mode="HTML",
    )


@admin_n1_only
async def cmd_topstats(update, context):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT full_name, balance, xp, karma FROM users "
            "WHERE registered=1 ORDER BY balance DESC LIMIT 10"
        ) as cur:
            rows = await cur.fetchall()
    body = [f"  {i+1}. <b>{r['full_name']}</b> ─ {fmt(r['balance'])}" for i, r in enumerate(rows)]
    await update.message.reply_text(
        card("Top 10 mondial", body, icon="🏆", style="thick"),
        parse_mode="HTML",
    )


# ═══════════════════════════════════════════════════════════════════════════
#                    🔴 ADMIN N2 — Sanctions & Gestion
# ═══════════════════════════════════════════════════════════════════════════

@admin_n2_only
@motif_required(0, '/banuser @joueur triche avérée')
async def cmd_banuser(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    await update_field(t.id, "banned", 1)
    await _log_admin(update.effective_user.id, "ban", t.id)

    await _notify_target(
        context, t.id,
        "🔨 BANNISSEMENT",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            "Ton compte a été <b>banni</b> du jeu.",
            "",
            "<i>Si tu penses qu'il s'agit d'une erreur, contacte le support.</i>",
        ],
        icon="🔨", style="thick",
        bdd_msg="🔨 Tu as été banni du jeu.",
    )

    await update.message.reply_text(
        alert("danger", f"🔨 {t.full_name} a été banni du jeu."),
        parse_mode="HTML"
    )


@admin_n2_only
@motif_required(0, '/unbanuser @joueur recours accepté')
async def cmd_unbanuser(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    await update_field(t.id, "banned", 0)

    await _notify_target(
        context, t.id,
        "✅ DÉBANNISSEMENT",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            "Ton compte a été <b>débanni</b>.",
            "",
            "<i>Bon retour parmi nous !</i>",
        ],
        icon="✅", style="round",
        bdd_msg="✅ Tu as été débanni du jeu.",
    )

    await update.message.reply_text(
        alert("success", f"✅ {t.full_name} a été débanni."),
        parse_mode="HTML"
    )


@admin_n2_only
@motif_required(1, '/freezeuser @joueur 3600 enquête en cours')
async def cmd_freezeuser(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        secs = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Durée invalide.")
        return
    await update_field(t.id, "frozen_until", now() + secs)

    await _notify_target(
        context, t.id,
        "❄️ COMPTE GELÉ",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"Durée : <b>{fmt_time(secs)}</b>",
            "",
            "<i>Ton compte est gelé. Tu ne peux plus agir pendant ce temps.</i>",
        ],
        icon="❄️", style="thick",
        bdd_msg=f"❄️ Ton compte est gelé pour {fmt_time(secs)}.",
    )

    await update.message.reply_text(
        alert("warning", f"❄️ {t.full_name} gelé pour {fmt_time(secs)}"),
        parse_mode="HTML"
    )


@admin_n2_only
@motif_required(0, '/unfreezeuser @joueur enquête terminée')
async def cmd_unfreezeuser(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    await update_field(t.id, "frozen_until", 0)

    await _notify_target(
        context, t.id,
        "✅ COMPTE DÉGELÉ",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            "Ton compte a été <b>dégelé</b>.",
            "",
            "<i>Tu peux de nouveau agir librement.</i>",
        ],
        icon="✅", style="round",
        bdd_msg="✅ Ton compte a été dégelé.",
    )

    await update.message.reply_text(
        alert("success", f"{t.full_name} dégelé."),
        parse_mode="HTML"
    )


@admin_n2_only
@motif_required(1, '/forceprison @joueur 3600 insultes répétées')
async def cmd_forceprison(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        secs = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Durée invalide.")
        return
    await update_field(t.id, "prison_until", now() + secs)

    await _notify_target(
        context, t.id,
        "⛓️ EMPRISONNEMENT",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"Durée : <b>{fmt_time(secs)}</b>",
            "",
            "<i>Tu es enfermé. Utilise /caution pour sortir plus tôt.</i>",
        ],
        icon="⛓️", style="thick",
        bdd_msg=f"⛓️ Tu as été emprisonné pour {fmt_time(secs)}.",
    )

    await update.message.reply_text(
        alert("danger", f"⛓️ {t.full_name} en prison pour {fmt_time(secs)}"),
        parse_mode="HTML"
    )


@admin_n2_only
@motif_required(0, '/freeprison @joueur peine purgée')
async def cmd_freeprison(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    await update_field(t.id, "prison_until", 0)

    await _notify_target(
        context, t.id,
        "🔓 LIBÉRATION",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            "Tu as été <b>libéré</b> de prison.",
            "",
            "<i>Profite de ta liberté retrouvée !</i>",
        ],
        icon="🔓", style="round",
        bdd_msg="🔓 Tu as été libéré de prison.",
    )

    await update.message.reply_text(
        alert("success", f"🔓 {t.full_name} libéré."),
        parse_mode="HTML"
    )


@admin_n2_only
@motif_required(1, '/sethospital @joueur 1800 bug corrigé')
async def cmd_sethospital(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        secs = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Durée invalide.")
        return
    await update_field(t.id, "hospital_until", now() + secs)

    await _notify_target(
        context, t.id,
        "🏥 HOSPITALISATION",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"Durée : <b>{fmt_time(secs)}</b>",
            "",
            "<i>Tu es hospitalisé. Repose-toi jusqu'à la fin du séjour.</i>",
        ],
        icon="🏥", style="thick",
        bdd_msg=f"🏥 Tu as été hospitalisé pour {fmt_time(secs)}.",
    )

    await update.message.reply_text(
        alert("warning", f"🏥 {t.full_name} hospitalisé pour {fmt_time(secs)}"),
        parse_mode="HTML"
    )


@admin_n2_only
@motif_required(1, '/settravel @joueur 600 bug de déplacement')
async def cmd_settravel(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        secs = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Durée invalide.")
        return
    await update_field(t.id, "travel_until", now() + secs)

    await _notify_target(
        context, t.id,
        "✈️ BLOCAGE VOYAGE",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"Durée : <b>{fmt_time(secs)}</b>",
            "",
            "<i>Tu ne peux pas voyager pendant ce temps.</i>",
        ],
        icon="✈️", style="thick",
        bdd_msg=f"✈️ Tu es bloqué (voyage) pour {fmt_time(secs)}.",
    )

    await update.message.reply_text(
        alert("warning", f"✈️ {t.full_name} bloqué (voyage) pour {fmt_time(secs)}"),
        parse_mode="HTML"
    )


@admin_n2_only
@motif_required(0, '/resetuser @joueur compte corrompu')
async def cmd_resetuser(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    async with db_connection() as db:
        await db.execute("""UPDATE users SET balance=10000, xp=0, level=1, karma=0, prestige=0,
                            health=100, energy=100, happiness=100, hunger=100, stress=0,
                            job='Livreur', diplome='', prison_until=0, hospital_until=0,
                            warnings=0, banned=0 WHERE user_id=?""", (t.id,))
        await db.commit()
    await _log_admin(update.effective_user.id, "RESET_FULL", t.id)

    await _notify_target(
        context, t.id,
        "🔄 RESET COMPLET",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            "Ton compte a été <b>réinitialisé</b> :",
            "  • Solde : 10 000 €A",
            "  • Niveau 1 · Sans diplôme",
            "  • Stats vitales au maximum",
            "  • Avertissements et ban effacés",
            "",
            "<i>Un nouveau départ commence pour toi.</i>",
        ],
        icon="🔄", style="thick",
        bdd_msg="🔄 Ton compte a été réinitialisé (reset complet).",
    )

    await update.message.reply_text(
        card(
            "🔄 RESET COMPLET",
            [
                f"<b>{t.full_name}</b>",
                "Tout a été remis à zéro.",
                "Solde : 10K · Niveau 1 · Sans diplôme · Stats max",
            ],
            icon="🔄", style="thick",
        ),
        parse_mode="HTML",
    )


# ─── Stats vitales (Admin N2) ───

@admin_n2_only
@motif_required(1, '/sethp @joueur 100 bug de santé')
async def cmd_sethp(update, context):
    await _set_field(update, context, "health", "Santé")


@admin_n2_only
@motif_required(1, '/setenergy @joueur 100 bug')
async def cmd_setenergy(update, context):
    await _set_field(update, context, "energy", "Énergie")


@admin_n2_only
@motif_required(1, '/sethappiness @joueur 100 bug')
async def cmd_sethappiness(update, context):
    await _set_field(update, context, "happiness", "Bonheur")


@admin_n2_only
@motif_required(1, '/sethunger @joueur 100 bug')
async def cmd_sethunger(update, context):
    await _set_field(update, context, "hunger", "Faim")


@admin_n2_only
@motif_required(1, '/setstress @joueur 0 bug')
async def cmd_setstress(update, context):
    await _set_field(update, context, "stress", "Stress")


@admin_n2_only
@motif_required(1, '/setage @joueur 25 correction')
async def cmd_setage(update, context):
    await _set_field(update, context, "age", "Âge")


@admin_n2_only
@motif_required(None, '/setjob @joueur Livreur | correction après bug')
async def cmd_setjob(update, context):
    await _set_field(update, context, "job", "Métier", parser=str)


@admin_n2_only
@motif_required(None, '/setdiplome @joueur Master | correction')
async def cmd_setdiplome(update, context):
    await _set_field(update, context, "diplome", "Diplôme", parser=str)


@admin_n2_only
@motif_required(None, '/setbio @joueur texte | contenu inapproprié')
async def cmd_setbio(update, context):
    await _set_field(update, context, "bio", "Bio", parser=str)


@admin_n2_only
@motif_required(None, '/setcolor @joueur rouge | correction')
async def cmd_setcolor(update, context):
    await _set_field(update, context, "profile_color", "Couleur de profil", parser=str)


@admin_n2_only
@motif_required(None, '/setlocation @joueur Paris | bug de position')
async def cmd_setlocation(update, context):
    await _set_field(update, context, "location", "Ville", parser=str)


@admin_n2_only
@motif_required(2, '/setskill @joueur cuisine 10 compensation bug')
async def cmd_setskill(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 3:
        return
    try:
        skill = context.args[1]
        lvl = int(context.args[2])
    except ValueError:
        await update.message.reply_text("❌ Niveau invalide.")
        return
    async with db_connection() as db:
        await db.execute(
            "INSERT OR REPLACE INTO skills(user_id, skill_name, level) VALUES(?,?,?)",
            (t.id, skill, lvl)
        )
        await db.commit()
    await _log_admin(update.effective_user.id, "setskill", t.id, f"{skill} → {lvl}")
    await update.message.reply_text(
        alert("success", f"Skill {skill} de {t.full_name} → niv. {lvl}"),
        parse_mode="HTML"
    )


# ─── Consultation avancée (Admin N2) ───

@admin_n2_only
async def cmd_listusers(update: Update, context: ContextTypes.DEFAULT_TYPE):
    page = 1
    if context.args and context.args[0].isdigit():
        page = int(context.args[0])
    per_page = 20
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT COUNT(*) as total FROM users WHERE registered=1") as cur:
            total = (await cur.fetchone())["total"]
        total_pages = (total + per_page - 1) // per_page
        if page < 1:
            page = 1
        if page > total_pages and total_pages > 0:
            page = total_pages
        offset = (page - 1) * per_page
        async with db.execute(
            "SELECT user_id, username, full_name FROM users WHERE registered=1 ORDER BY user_id LIMIT ? OFFSET ?",
            (per_page, offset)
        ) as cur:
            users = await cur.fetchall()
    if not users:
        await update.message.reply_text("📭 Aucun joueur enregistré.")
        return
    lines = []
    for u in users:
        username = f"@{escape_html(u['username'])}" if u['username'] else "pas de pseudo"
        name = escape_html(u['full_name'])
        lines.append(f"<code>{u['user_id']}</code> — {name} ({username})")
    text = f"👥 <b>Liste des joueurs</b> (page {page}/{total_pages})\n\n" + "\n".join(lines)
    if total_pages > 1:
        nav = []
        if page > 1:
            nav.append(f"<code>/listusers {page-1}</code> ◀️")
        if page < total_pages:
            nav.append(f"<code>/listusers {page+1}</code> ▶️")
        text += "\n\n" + "  ".join(nav)
    await update.message.reply_text(text, parse_mode="HTML")


@admin_n2_only
async def cmd_playerhistory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target = await _resolve(update, context)
    if not target:
        await update.message.reply_text("Usage : /playerhistory @user (ou en répondant à un message)")
        return

    page = 1
    if context.args and len(context.args) > 1 and context.args[1].isdigit():
        page = int(context.args[1])

    per_page = 10
    events = []

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row

        async with db.execute(
            "SELECT crime_type, success, reward, jail_time, timestamp FROM crime_log WHERE user_id=? ORDER BY timestamp DESC",
            (target.id,)
        ) as cur:
            for row in await cur.fetchall():
                ts = fmt_game_datetime(row["timestamp"], sep=" ")
                if row["success"]:
                    events.append(("💀 Crime", f"{ts} | {row['crime_type']} → +{fmt(row['reward'])}", row["timestamp"]))
                else:
                    events.append(("⛓️ Crime échoué", f"{ts} | {row['crime_type']} → prison {fmt_time(row['jail_time'])}", row["timestamp"]))

        async with db.execute(
            "SELECT destination, cost, timestamp FROM travel_log WHERE user_id=? ORDER BY timestamp DESC LIMIT 50",
            (target.id,)
        ) as cur:
            for row in await cur.fetchall():
                ts = fmt_game_datetime(row["timestamp"], sep=" ")
                events.append(("✈️ Voyage", f"{ts} | {row['destination']} → -{fmt(row['cost'])}", row["timestamp"]))

        async with db.execute(
            "SELECT category, summary, severity, created_at FROM life_journal WHERE user_id=? ORDER BY created_at DESC LIMIT 30",
            (target.id,)
        ) as cur:
            for row in await cur.fetchall():
                ts = fmt_game_datetime(row["created_at"], sep=" ")
                summary = row["summary"].replace("\n", " ").strip()[:80]
                events.append(("📔 Vie", f"{ts} | {row['category']} : {summary}", row["created_at"]))

        events.sort(key=lambda x: x[2], reverse=True)

    total = len(events)
    total_pages = (total + per_page - 1) // per_page if total > 0 else 1
    if page < 1:
        page = 1
    if page > total_pages:
        page = total_pages
    start = (page - 1) * per_page
    end = start + per_page
    page_events = events[start:end]

    if not page_events:
        await update.message.reply_text(f"📭 Aucun historique trouvé pour {escape_html(target.full_name)}.")
        return

    lines = []
    for icon, desc, _ in page_events:
        lines.append(f"{icon} {escape_html(desc)}")
    text = f"📜 <b>Historique de {escape_html(target.full_name)}</b> (page {page}/{total_pages})\n\n" + "\n".join(lines)
    if total_pages > 1:
        nav = []
        if page > 1:
            nav.append(f"<code>/playerhistory {target.id} {page-1}</code> ◀️")
        if page < total_pages:
            nav.append(f"<code>/playerhistory {target.id} {page+1}</code> ▶️")
        text += "\n\n" + "  ".join(nav)
    await update.message.reply_text(text, parse_mode="HTML")


@admin_n2_only
@motif_required(None, '/givebadge @joueur badge | récompense événement')
async def cmd_givebadge(update: Update, context: ContextTypes.DEFAULT_TYPE):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        await update.message.reply_text("Usage : /givebadge @user [nom_du_badge]")
        return
    badge = " ".join(context.args[1:])[:50]
    async with db_connection() as db:
        await db.execute(
            "INSERT OR IGNORE INTO user_badges(user_id, badge, earned_at) VALUES(?,?,?)",
            (t.id, badge, now())
        )
        await db.commit()
    await _log_admin(update.effective_user.id, "givebadge", t.id, badge)

    await _notify_target(
        context, t.id,
        "🏅 NOUVEAU BADGE",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"Badge : <b>{badge}</b>",
            "",
            "<i>Félicitations, ce badge t'est décerné !</i>",
        ],
        icon="🏅", style="stars",
        bdd_msg=f"🏅 Tu as reçu le badge : {badge}",
    )

    await update.message.reply_text(
        alert("success", f"Badge <b>{badge}</b> donné à {t.full_name}"),
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════════════
#                    🎮 GAME LEADER — Événements & Animation
# ═══════════════════════════════════════════════════════════════════════════

@game_leader_only
async def cmd_createevent(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Format : /createevent \"nom\" durée_secondes effet"""
    args = context.args

    if len(args) < 3:
        body = [
            "📋 <b>EFFETS DISPONIBLES</b>",
            "",
        ]
        for key, data in EVENT_EFFECTS_DESCRIPTIONS.items():
            body.append(f"{data['emoji']} <code>{key}</code>")
            body.append(f"   <b>{data['label']}</b>")
            body.append(f"   <i>{data['desc']}</i>")
            body.append("")

        body += [
            "━━━━━━━━━━━━━━━━━━━━━━",
            "<b>📌 Syntaxe :</b>",
            "<code>/createevent \"nom\" durée effet</code>",
            "",
            "<b>Exemple :</b>",
            "<code>/createevent \"Krach de 2026\" 86400 market_crash</code>",
            "",
            "<i>Durée en secondes : 3600 = 1h · 86400 = 1j · 604800 = 1 semaine</i>",
        ]
        await update.message.reply_text(
            card("⚡ CRÉER UN ÉVÉNEMENT MONDIAL", body, icon="⚡", style="thick"),
            parse_mode="HTML",
        )
        return

    try:
        duration = int(args[-2])
        effect = args[-1].lower()
        name = " ".join(args[:-2]).strip('"').strip("'")
    except ValueError:
        await update.message.reply_text(
            alert("error", "❌ Durée invalide. Doit être un nombre de secondes."),
            parse_mode="HTML"
        )
        return

    if effect not in EVENT_EFFECTS_DESCRIPTIONS:
        await update.message.reply_text(
            alert("error", f"❌ Effet inconnu : <code>{effect}</code>\nUtilise <code>/createevent</code> seul pour voir la liste."),
            parse_mode="HTML"
        )
        return

    if duration <= 0:
        await update.message.reply_text(
            alert("error", "❌ La durée doit être positive."),
            parse_mode="HTML"
        )
        return

    now_ts = now()                      # temps de JEU (durée en secondes de jeu)
    ends_at = now_ts + duration

    async with db_connection() as db:
        await db.execute(
            "INSERT INTO world_events (name, effect, severity, started_at, ends_at, active) "
            "VALUES (?, ?, ?, ?, ?, 1)",
            (name, effect, 0.5, now_ts, ends_at)
        )
        await db.commit()

    await _log_admin(update.effective_user.id, "createevent", 0, f"{name} ({effect}) {duration}s")

    effect_data = EVENT_EFFECTS_DESCRIPTIONS[effect]
    await update.message.reply_text(
        card(
            "⚡ ÉVÉNEMENT MONDIAL CRÉÉ",
            [
                f"📛 Nom : <b>{escape_html(name)}</b>",
                f"{effect_data['emoji']} Effet : <b>{effect_data['label']}</b>",
                f"📝 <i>{effect_data['desc']}</i>",
                "",
                f"⏱️ Durée : <b>{fmt_time(duration)}</b>",
                f"📅 Fin : {fmt_game_datetime(ends_at, sep=' ')}",
            ],
            icon="⚡", style="stars",
        ),
        parse_mode="HTML",
    )


@game_leader_only
async def cmd_endevent(update, context):
    async with db_connection() as db:
        await db.execute("UPDATE world_events SET active=0 WHERE ends_at > ?", (now(),))
        await db.commit()
    await _log_admin(update.effective_user.id, "endevent", 0, "Tous événements terminés")
    await update.message.reply_text(
        alert("success", "Tous les événements actifs ont été terminés."),
        parse_mode="HTML"
    )


@game_leader_only
async def cmd_broadcast(update, context):
    msg = " ".join(context.args)
    if not msg:
        await update.message.reply_text(
            alert("info", "Usage : /broadcast message"),
            parse_mode="HTML"
        )
        return
    async with db_connection() as db:
        async with db.execute("SELECT user_id FROM users WHERE registered=1 AND banned=0") as cur:
            ids = [r[0] for r in await cur.fetchall()]
    sent = 0
    for uid in ids:
        try:
            await context.bot.send_message(
                uid,
                card("📢 ANNONCE OFFICIELLE", [msg], icon="📢", style="thick"),
                parse_mode="HTML",
            )
            sent += 1
        except Exception:
            swallowed('handlers/admin.py')
    await _log_admin(update.effective_user.id, "broadcast", 0, msg[:100])
    await update.message.reply_text(
        alert("success", f"📡 Broadcast envoyé à {sent} joueurs."),
        parse_mode="HTML"
    )


@game_leader_only
async def cmd_announce(update, context):
    await cmd_broadcast(update, context)


@game_leader_only
@motif_required(1, '/lotowin @joueur montant motif')
async def cmd_lotowin(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    u = await get_user(t.id)
    win = 5_000_000
    await update_field(t.id, "balance", u["balance"] + win)
    await update_field(t.id, "lottery_wins", u.get("lottery_wins", 0) + 1)
    await _log_admin(update.effective_user.id, "lotowin", t.id, str(win))

    await _notify_target(
        context, t.id,
        "🎰 JACKPOT !",
        ["Tu remportes la loterie nationale !", "💰 +5 000 000 €A"],
        icon="🎰", style="stars",
        bdd_msg="🎰 Tu as remporté 5M €A à la loterie !",
    )

    await update.message.reply_text(
        alert("success", f"🎰 {t.full_name} gagne 5M €A à la loterie !"),
        parse_mode="HTML"
    )


# ─── Items (Game Leader) ───

@game_leader_only
@motif_required(2, '/giveitem @joueur 12 1 compensation bug')
async def cmd_giveitem(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 3:
        await update.message.reply_text("Usage : /giveitem @user item_id quantité")
        return
    try:
        item_id = int(context.args[1])
        qty = int(context.args[2])
    except ValueError:
        await update.message.reply_text("❌ item_id et quantité doivent être des nombres.")
        return
    async with db_connection() as db:
        async with db.execute("SELECT name FROM items WHERE item_id = ?", (item_id,)) as cur:
            row = await cur.fetchone()
    if not row:
        await update.message.reply_text(f"❌ Item avec ID {item_id} inexistant. Utilisez /listitems.")
        return
    await _add_item_to_inventory(t.id, item_id, qty, "admin")
    await _log_admin(update.effective_user.id, "giveitem", t.id, f"item_id:{item_id} qty:{qty}")

    await _notify_target(
        context, t.id,
        "🎁 OBJET REÇU",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"Objet : <b>{row[0]}</b> ×{qty}",
        ],
        icon="🎁", style="stars",
        bdd_msg=f"🎁 Tu as reçu {qty}× {row[0]} (ID {item_id})",
    )

    await update.message.reply_text(
        alert("success", f"Donné {qty}× {row[0]} (ID {item_id}) à {t.full_name}"),
        parse_mode="HTML"
    )


@game_leader_only
@motif_required(2, '/takeitem @joueur 12 1 objet obtenu par bug')
async def cmd_takeitem(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 3:
        await update.message.reply_text("Usage : /takeitem @user item_id quantité")
        return
    try:
        item_id = int(context.args[1])
        qty = int(context.args[2])
    except ValueError:
        await update.message.reply_text("❌ item_id et quantité doivent être des nombres.")
        return
    if await _remove_item_from_inventory(t.id, item_id, qty):
        await _log_admin(update.effective_user.id, "takeitem", t.id, f"item_id:{item_id} qty:{qty}")

        await _notify_target(
            context, t.id,
            "⚠️ OBJET RETIRÉ",
            [
                f"Par : <b>{update.effective_user.full_name}</b>",
                f"Objet retiré : ID <b>{item_id}</b> ×{qty}",
            ],
            icon="⚠️", style="round",
            bdd_msg=f"⚠️ {qty}× objet (ID {item_id}) t'ont été retirés.",
        )

        await update.message.reply_text(
            alert("success", f"Retiré {qty} exemplaire(s) de l'item {item_id} à {t.full_name}"),
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            alert("error", "Quantité insuffisante ou item non possédé."),
            parse_mode="HTML"
        )


@game_leader_only
@motif_required(2, "/setitem @joueur 12 3 correction d'inventaire")
async def cmd_setitem(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 3:
        await update.message.reply_text("Usage : /setitem @user item_id quantité")
        return
    try:
        item_id = int(context.args[1])
        qty = int(context.args[2])
    except ValueError:
        await update.message.reply_text("❌ item_id et quantité doivent être des nombres.")
        return
    async with db_connection() as db:
        async with db.execute("SELECT name FROM items WHERE item_id = ?", (item_id,)) as cur:
            row = await cur.fetchone()
    if not row:
        await update.message.reply_text(f"❌ Item avec ID {item_id} inexistant.")
        return
    if qty <= 0:
        async with db_connection() as db2:
            await db2.execute("DELETE FROM inventory WHERE user_id = ? AND item_id = ?", (t.id, item_id))
            await db2.commit()
    else:
        async with db_connection() as db2:
            await db2.execute("DELETE FROM inventory WHERE user_id = ? AND item_id = ?", (t.id, item_id))
            await db2.execute("""
                INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at)
                VALUES (?, ?, 'admin', ?, ?, ?)
            """, (t.id, item_id, row[0], qty, now()))
            await db2.commit()
    await _log_admin(update.effective_user.id, "setitem", t.id, f"item_id:{item_id} qty:{qty}")
    await update.message.reply_text(
        alert("success", f"Inventaire de {t.full_name} pour l'item {row[0]} (ID {item_id}) fixé à {qty}"),
        parse_mode="HTML"
    )


@game_leader_only
@motif_required(0, '/clearinventory @joueur inventaire corrompu')
async def cmd_clearinventory(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    async with db_connection() as db:
        await db.execute("DELETE FROM inventory WHERE user_id=?", (t.id,))
        await db.commit()
    await _log_admin(update.effective_user.id, "clearinventory", t.id)

    await _notify_target(
        context, t.id,
        "🗑️ INVENTAIRE VIDÉ",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            "Ton inventaire a été <b>vidé</b>.",
        ],
        icon="🗑️", style="round",
        bdd_msg="🗑️ Ton inventaire a été vidé par un admin.",
    )

    await update.message.reply_text(
        alert("success", f"Inventaire de {t.full_name} vidé."),
        parse_mode="HTML"
    )


@game_leader_only
@motif_required(0, '/giveallitems @joueur motif')
async def cmd_giveallitems(update, context):
    if len(context.args) < 2:
        await update.message.reply_text("Usage : /giveallitems item_id quantité")
        return
    try:
        item_id = int(context.args[0])
        qty = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ item_id et quantité doivent être des nombres.")
        return
    async with db_connection() as db:
        async with db.execute("SELECT name FROM items WHERE item_id = ?", (item_id,)) as cur:
            row = await cur.fetchone()
    if not row:
        await update.message.reply_text(f"❌ Item avec ID {item_id} inexistant.")
        return
    async with db_connection() as db:
        async with db.execute("SELECT user_id FROM users WHERE registered=1") as cur:
            users = await cur.fetchall()
        for (uid,) in users:
            await _add_item_to_inventory(uid, item_id, qty, "admin_gift")
        await db.commit()
    await _log_admin(update.effective_user.id, "giveallitems", 0, f"item_id:{item_id} qty:{qty}")
    await update.message.reply_text(
        alert("success", f"Donné {qty}× {row[0]} (ID {item_id}) à tous les joueurs."),
        parse_mode="HTML"
    )


@game_leader_only
async def cmd_listitems(update, context):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT item_id, name, type, rarity FROM items ORDER BY item_id") as cur:
            items = await cur.fetchall()
    if not items:
        await update.message.reply_text("📦 Aucun item trouvé.")
        return
    text = "📦 <b>Catalogue des items</b>\n\n"
    for i in items:
        text += f"<code>#{escape_html(i['item_id'])}</code> <b>{escape_html(i['name'])}</b> ({escape_html(i['type'])}, {escape_html(i['rarity'])})\n"
    await update.message.reply_text(text, parse_mode="HTML")


# ─── Missions (Game Leader) ───







@game_leader_only
@motif_required(2, '/mission_force @joueur mission progression motif')
async def cmd_mission_force(update, context):
    if len(context.args) < 3:
        await update.message.reply_text("Usage : /mission_force @user [nom_mission] [progression]")
        return
    t = await _resolve(update, context)
    if not t:
        return
    mission_name = context.args[1]
    try:
        progress = int(context.args[2])
    except ValueError:
        await update.message.reply_text("❌ Progression invalide.")
        return
    async with db_connection() as db:
        await db.execute(
            "UPDATE missions SET progress=? WHERE user_id=? AND mission_name=?",
            (progress, t.id, mission_name)
        )
        await db.commit()
    await update.message.reply_text(
        alert("success", f"Mission {mission_name} de {t.full_name} forcée à {progress}"),
        parse_mode="HTML"
    )


@game_leader_only
@motif_required(0, '/resetmissions @joueur motif')
async def cmd_resetmissions(update, context):
    async with db_connection() as db:
        await db.execute("DELETE FROM missions")
        await db.commit()
    await _log_admin(update.effective_user.id, "resetmissions", 0, "")
    await update.message.reply_text(
        alert("success", "Toutes les missions ont été réinitialisées."),
        parse_mode="HTML"
    )


# ─── Gangs (Game Leader) ───

@game_leader_only
async def cmd_gang_create_admin(update, context):
    if not context.args:
        await update.message.reply_text("Usage : /gang_create_admin [nom]")
        return
    name = " ".join(context.args)
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO gangs (name, founder_id, treasury, reputation, created_at) VALUES (?,?,0,0,?)",
            (name, 0, now())
        )
        async with db.execute("SELECT last_insert_rowid()") as cur:
            gang_id = (await cur.fetchone())[0]
        await db.commit()
    await update.message.reply_text(
        alert("success", f"Gang <b>{name}</b> créé (ID {gang_id})"),
        parse_mode="HTML"
    )


@game_leader_only
async def cmd_gang_delete(update, context):
    if not context.args:
        await update.message.reply_text("Usage : /gang_delete [gang_id]")
        return
    try:
        gang_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID invalide.")
        return
    async with db_connection() as db:
        await db.execute("DELETE FROM gangs WHERE gang_id=?", (gang_id,))
        await db.execute("DELETE FROM gang_members WHERE gang_id=?", (gang_id,))
        await db.commit()
    await update.message.reply_text(
        alert("success", f"Gang {gang_id} supprimé."),
        parse_mode="HTML"
    )


@game_leader_only
@motif_required(1, '/gang_add @joueur nom_du_gang motif')
async def cmd_gang_add(update, context):
    if len(context.args) < 2:
        await update.message.reply_text("Usage : /gang_add @user [gang_id]")
        return
    t = await _resolve(update, context)
    if not t:
        return
    try:
        gang_id = int(context.args[1])
    except (ValueError, IndexError):
        await update.message.reply_text("❌ ID gang invalide.")
        return
    try:
        async with db_connection() as db:
            async with db.execute("SELECT 1 FROM gang_members WHERE user_id=?", (t.id,)) as cur:
                if await cur.fetchone():
                    raise DeferredReply(update.message.reply_text, "❌ Ce joueur est déjà dans un gang.")
            await db.execute(
                "INSERT INTO gang_members (gang_id, user_id, role, joined_at) VALUES (?,?, 'Membre', ?)",
                (gang_id, t.id, now())
            )
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()
    await update.message.reply_text(
        alert("success", f"{t.full_name} ajouté au gang {gang_id}"),
        parse_mode="HTML"
    )


@game_leader_only
@motif_required(0, '/gang_remove @joueur motif')
async def cmd_gang_remove(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    async with db_connection() as db:
        await db.execute("DELETE FROM gang_members WHERE user_id=?", (t.id,))
        await db.commit()
    await update.message.reply_text(
        alert("success", f"{t.full_name} retiré de son gang."),
        parse_mode="HTML"
    )


@game_leader_only
async def cmd_gang_set_treasury(update, context):
    if len(context.args) < 2:
        await update.message.reply_text("Usage : /gang_set_treasury [gang_id] [montant]")
        return
    try:
        gang_id = int(context.args[0])
        amount = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return
    async with db_connection() as db:
        await db.execute("UPDATE gangs SET treasury=? WHERE gang_id=?", (amount, gang_id))
        await db.commit()
    await update.message.reply_text(
        alert("success", f"Trésorerie du gang {gang_id} fixée à {fmt(amount)}"),
        parse_mode="HTML"
    )


@game_leader_only
async def cmd_gang_set_reputation(update, context):
    if len(context.args) < 2:
        await update.message.reply_text("Usage : /gang_set_reputation [gang_id] [valeur]")
        return
    try:
        gang_id = int(context.args[0])
        rep = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return
    async with db_connection() as db:
        await db.execute("UPDATE gangs SET reputation=? WHERE gang_id=?", (rep, gang_id))
        await db.commit()
    await update.message.reply_text(
        alert("success", f"Réputation du gang {gang_id} fixée à {rep}"),
        parse_mode="HTML"
    )


# ─── Relations & Famille (Game Leader) ───

@game_leader_only
@motif_required(2, '/setrelation @joueur1 @joueur2 valeur motif')
async def cmd_setrelation(update, context):
    if len(context.args) < 3:
        await update.message.reply_text("Usage : /setrelation @user1 @user2 score")
        return
    target1 = await _resolve(update, context)
    if not target1:
        await update.message.reply_text("❌ Premier utilisateur invalide.")
        return
    from utils.user_lookup import find_user
    found2 = await find_user(context.args[1])
    row2 = (found2["user_id"], found2["full_name"]) if found2 else None
    if not row2:
        await update.message.reply_text("❌ Second utilisateur invalide.")
        return
    try:
        score = int(context.args[2])
    except ValueError:
        await update.message.reply_text("❌ Score doit être un nombre.")
        return
    async with db_connection() as db:
        await db.execute("""
            INSERT INTO mp_relations(user_id, other_id, score, last_interaction, relation_type)
            VALUES(?,?,?,?,'admin') ON CONFLICT(user_id, other_id) DO UPDATE SET score=?, last_interaction=?
        """, (target1.id, row2[0], score, now(), score, now()))
        await db.execute("""
            INSERT INTO mp_relations(user_id, other_id, score, last_interaction, relation_type)
            VALUES(?,?,?,?,'admin') ON CONFLICT(user_id, other_id) DO UPDATE SET score=?, last_interaction=?
        """, (row2[0], target1.id, score, now(), score, now()))
        await db.commit()
    await _log_admin(update.effective_user.id, "setrelation", target1.id, f"avec {row2[0]} score={score}")
    await update.message.reply_text(
        alert("success", f"Relation entre {target1.full_name} et {row2[1]} fixée à {score}"),
        parse_mode="HTML"
    )


@game_leader_only
@motif_required(1, '/setmarriage @joueur @conjoint motif')
async def cmd_setmarriage(update, context):
    if len(context.args) < 2:
        await update.message.reply_text("Usage : /setmarriage @user1 @user2")
        return
    target1 = await _resolve(update, context)
    if not target1:
        await update.message.reply_text("❌ Premier utilisateur invalide.")
        return
    from utils.user_lookup import find_user
    found2 = await find_user(context.args[1])
    row2 = (found2["user_id"], found2["full_name"]) if found2 else None
    if not row2:
        await update.message.reply_text("❌ Second utilisateur invalide.")
        return
    async with db_connection() as db:
        await db.execute("DELETE FROM marriages WHERE user_id IN (?,?)", (target1.id, row2[0]))
        await db.execute(
            "INSERT INTO marriages(user_id, partner_id, married_at, status) VALUES(?,?,?,'active')",
            (target1.id, row2[0], now())
        )
        await db.execute(
            "INSERT INTO marriages(user_id, partner_id, married_at, status) VALUES(?,?,?,'active')",
            (row2[0], target1.id, now())
        )
        await db.commit()
    await _log_admin(update.effective_user.id, "setmarriage", target1.id, f"avec {row2[0]}")
    await update.message.reply_text(
        alert("success", f"Mariage forcé entre {target1.full_name} et {row2[1]}"),
        parse_mode="HTML"
    )


@game_leader_only
@motif_required(0, '/admin_divorce @joueur motif')
async def cmd_admin_divorce(update, context):
    t = await _resolve(update, context)
    if not t:
        await update.message.reply_text("Usage : /divorce @user")
        return
    async with db_connection() as db:
        await db.execute(
            "UPDATE marriages SET status='divorced', divorced_at=? "
            "WHERE user_id=? AND status='active'",
            (now(), t.id)
        )
        await db.execute(
            "UPDATE marriages SET status='divorced', divorced_at=? "
            "WHERE partner_id=? AND status='active'",
            (now(), t.id)
        )
        await db.commit()
    await _log_admin(update.effective_user.id, "divorce", t.id)
    await update.message.reply_text(
        alert("success", f"{t.full_name} a été divorcé d'office."),
        parse_mode="HTML"
    )


@game_leader_only
@motif_required(1, '/setfamily @joueur @parent motif')
async def cmd_setfamily(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        await update.message.reply_text("Usage : /setfamily @user famille_id")
        return
    try:
        fam_id = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ famille_id doit être un nombre.")
        return
    try:
        async with db_connection() as db:
            async with db.execute("SELECT 1 FROM family WHERE family_id = ?", (fam_id,)) as cur:
                if not await cur.fetchone():
                    raise DeferredReply(update.message.reply_text, f"❌ Famille {fam_id} inexistante.")
            await db.execute(
                "INSERT OR REPLACE INTO family_members(user_id, family_id, role, joined_at) "
                "VALUES(?,?,?,?)",
                (t.id, fam_id, "Membre", now())
            )
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()
    await _log_admin(update.effective_user.id, "setfamily", t.id, str(fam_id))
    await update.message.reply_text(
        alert("success", f"{t.full_name} ajouté à la famille {fam_id}"),
        parse_mode="HTML"
    )


@game_leader_only
@motif_required(0, '/removefamily @joueur motif')
async def cmd_removefamily(update, context):
    t = await _resolve(update, context)
    if not t:
        await update.message.reply_text("Usage : /removefamily @user")
        return
    async with db_connection() as db:
        await db.execute("DELETE FROM family_members WHERE user_id = ?", (t.id,))
        await db.commit()
    await _log_admin(update.effective_user.id, "removefamily", t.id)
    await update.message.reply_text(
        alert("success", f"{t.full_name} retiré de toute famille."),
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════════════
#              🎖️ LEAD STAFF GLOBAL — Économie lourde
# ═══════════════════════════════════════════════════════════════════════════

@lead_staff_only
@motif_required(1, '/addmoney @joueur 5000 compensation bug')
async def cmd_addmoney(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        await update.message.reply_text(
            alert("info", "Usage : /addmoney @user montant"),
            parse_mode="HTML"
        )
        return
    amount = parse_amount(context.args[-1])
    if not amount:
        await update.message.reply_text(
            alert("error", "Montant invalide"),
            parse_mode="HTML"
        )
        return
    u = await get_user(t.id)
    await update_field(t.id, "balance", u["balance"] + amount)
    await _log_admin(update.effective_user.id, "addmoney", t.id, str(amount))

    await _notify_target(
        context, t.id,
        "💰 ARGENT REÇU",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"💵 +{fmt(amount)}",
            f"Nouveau solde : {fmt(u['balance'] + amount)}",
        ],
        icon="💰", style="stars",
        bdd_msg=f"💰 Un admin t'a donné {fmt(amount)}.",
    )

    await update.message.reply_text(
        card(
            "💰 Argent ajouté",
            [
                f"À : <b>{t.full_name}</b>",
                f"💵 +{fmt(amount)}",
                f"Nouveau solde : {fmt(u['balance'] + amount)}",
            ],
            icon="💰", style="stars",
        ),
        parse_mode="HTML",
    )


@lead_staff_only
@motif_required(1, '/removemoney @joueur 5000 gain frauduleux')
async def cmd_removemoney(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        await update.message.reply_text(
            alert("info", "Usage : /removemoney @user montant"),
            parse_mode="HTML"
        )
        return
    amount = parse_amount(context.args[-1])
    u = await get_user(t.id)
    new_bal = max(0, u["balance"] - amount)
    await update_field(t.id, "balance", new_bal)
    await _log_admin(update.effective_user.id, "removemoney", t.id, str(amount))

    await _notify_target(
        context, t.id,
        "💸 ARGENT RETIRÉ",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"💵 -{fmt(amount)}",
            f"Nouveau solde : {fmt(new_bal)}",
        ],
        icon="💸", style="round",
        bdd_msg=f"💸 Un admin t'a retiré {fmt(amount)}.",
    )

    await update.message.reply_text(
        alert("success", f"Retiré {fmt(amount)} à {t.full_name}. Nouveau solde : {fmt(new_bal)}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/setmoney @joueur 10000 correction')
async def cmd_setmoney(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    amount = parse_amount(context.args[-1])
    await update_field(t.id, "balance", amount)
    await _log_admin(update.effective_user.id, "setmoney", t.id, str(amount))

    await _notify_target(
        context, t.id,
        "💰 SOLDE MODIFIÉ",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"Nouveau solde : <b>{fmt(amount)}</b>",
        ],
        icon="💰", style="stars",
        bdd_msg=f"💰 Ton solde a été fixé à {fmt(amount)}.",
    )

    await update.message.reply_text(
        alert("success", f"Solde de {t.full_name} fixé à {fmt(amount)}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(None, '/addbank @joueur 5000 | compensation bug')
async def cmd_addbank(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    amount = parse_amount(context.args[-1])
    bank_name = " ".join(context.args[1:-1]) if len(context.args) > 2 else None
    async with db_connection() as db:
        if bank_name:
            await db.execute(
                "UPDATE bank_accounts SET balance = balance + ? "
                "WHERE user_id = ? AND bank_name = ?",
                (amount, t.id, bank_name)
            )
        else:
            await db.execute(
                "UPDATE bank_accounts SET balance = balance + ? "
                "WHERE user_id = ? ORDER BY balance DESC LIMIT 1",
                (amount, t.id)
            )
        await db.commit()
    await _log_admin(update.effective_user.id, "addbank", t.id, f"{amount} ({bank_name or 'principal'})")

    await _notify_target(
        context, t.id,
        "🏦 DÉPÔT BANCAIRE",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"💵 +{fmt(amount)} ({bank_name or 'compte principal'})",
        ],
        icon="🏦", style="round",
        bdd_msg=f"🏦 +{fmt(amount)} ajoutés à ton compte bancaire.",
    )

    await update.message.reply_text(
        alert("success", f"Ajouté {fmt(amount)} au compte bancaire de {t.full_name}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(None, '/rembank @joueur 5000 | gain frauduleux')
async def cmd_rembank(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    amount = parse_amount(context.args[-1])
    bank_name = " ".join(context.args[1:-1]) if len(context.args) > 2 else None
    async with db_connection() as db:
        if bank_name:
            await db.execute(
                "UPDATE bank_accounts SET balance = balance - ? "
                "WHERE user_id = ? AND bank_name = ? AND balance >= ?",
                (amount, t.id, bank_name, amount)
            )
        else:
            await db.execute(
                "UPDATE bank_accounts SET balance = balance - ? "
                "WHERE user_id = ? AND balance >= ? ORDER BY balance DESC LIMIT 1",
                (amount, t.id, amount)
            )
        await db.commit()
    await _log_admin(update.effective_user.id, "rembank", t.id, f"{amount} ({bank_name or 'principal'})")

    await _notify_target(
        context, t.id,
        "🏦 RETRAIT BANCAIRE",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"💸 -{fmt(amount)} ({bank_name or 'compte principal'})",
        ],
        icon="🏦", style="round",
        bdd_msg=f"🏦 -{fmt(amount)} retirés de ton compte bancaire.",
    )

    await update.message.reply_text(
        alert("success", f"Retiré {fmt(amount)} du compte bancaire de {t.full_name}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(None, '/setbank @joueur 5000 | correction')
async def cmd_setbank(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    amount = parse_amount(context.args[-1])
    bank_name = " ".join(context.args[1:-1]) if len(context.args) > 2 else None
    async with db_connection() as db:
        if bank_name:
            await db.execute(
                "UPDATE bank_accounts SET balance = ? "
                "WHERE user_id = ? AND bank_name = ?",
                (amount, t.id, bank_name)
            )
        else:
            await db.execute(
                "UPDATE bank_accounts SET balance = ? WHERE user_id = ?",
                (amount, t.id)
            )
        await db.commit()
    await _log_admin(update.effective_user.id, "setbank", t.id, f"{amount} ({bank_name or 'principal'})")
    await update.message.reply_text(
        alert("success", f"Compte bancaire de {t.full_name} fixé à {fmt(amount)}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(0, '/cleardebt @joueur erreur de prêt')
async def cmd_cleardebt(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    async with db_connection() as db:
        await db.execute("UPDATE bank_accounts SET loan=0, loan_due=0 WHERE user_id=?", (t.id,))
        await db.commit()
    await _log_admin(update.effective_user.id, "cleardebt", t.id)

    await _notify_target(
        context, t.id,
        "💳 DETTES EFFACÉES",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            "Toutes tes dettes bancaires ont été <b>effacées</b>.",
        ],
        icon="💳", style="round",
        bdd_msg="💳 Tes dettes ont été effacées.",
    )

    await update.message.reply_text(
        alert("success", f"Dettes effacées pour {t.full_name}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/addprestige @joueur 10 récompense')
async def cmd_addprestige(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        amount = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Valeur invalide.")
        return
    await increment_field(t.id, "prestige", amount)
    await _log_admin(update.effective_user.id, "addprestige", t.id, str(amount))
    await update.message.reply_text(
        alert("success", f"+{amount} prestige pour {t.full_name}"),
        parse_mode="HTML"
    )


# ─── SocialCoins (Lead Staff) ───

@lead_staff_only
@motif_required(1, '/addsocialcoins @joueur 100 récompense')
async def cmd_addsocialcoins(update, context):
    """Donne des SocialCoins à un joueur."""
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        await update.message.reply_text(
            alert("info", "Usage : /addsocialcoins @user montant"),
            parse_mode="HTML"
        )
        return
    try:
        amount = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Montant invalide.")
        return
    await increment_field(t.id, "social_coins", amount)
    await _log_admin(update.effective_user.id, "addsocialcoins", t.id, str(amount))

    await _notify_target(
        context, t.id,
        "💎 SOCIALCOINS REÇUS",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"💎 +{amount} SocialCoins",
        ],
        icon="💎", style="stars",
        bdd_msg=f"💎 Un admin t'a donné {amount} SocialCoins.",
    )

    await update.message.reply_text(
        alert("success", f"✅ +{amount} 💎 SocialCoins pour {t.full_name}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/remsocialcoins @joueur 100 triche')
async def cmd_remsocialcoins(update, context):
    """Retire des SocialCoins à un joueur."""
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        await update.message.reply_text(
            alert("info", "Usage : /remsocialcoins @user montant"),
            parse_mode="HTML"
        )
        return
    try:
        amount = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Montant invalide.")
        return
    u = await get_user(t.id)
    current = u.get("social_coins", 0)
    new_val = max(0, current - amount)
    await update_field(t.id, "social_coins", new_val)
    await _log_admin(update.effective_user.id, "remsocialcoins", t.id, str(amount))

    await update.message.reply_text(
        alert("success", f"✅ -{amount} 💎 SocialCoins pour {t.full_name} (maintenant {new_val})"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/setsocialcoins @joueur 0 correction')
async def cmd_setsocialcoins(update, context):
    """Fixe le solde de SocialCoins d'un joueur."""
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        await update.message.reply_text(
            alert("info", "Usage : /setsocialcoins @user montant"),
            parse_mode="HTML"
        )
        return
    try:
        amount = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Montant invalide.")
        return
    await update_field(t.id, "social_coins", amount)
    await _log_admin(update.effective_user.id, "setsocialcoins", t.id, str(amount))

    await update.message.reply_text(
        alert("success", f"✅ SocialCoins de {t.full_name} fixés à {amount}"),
        parse_mode="HTML"
    )


# ─── Prestige / XP / Karma (suite) ───

@lead_staff_only
@motif_required(1, '/remprestige @joueur 10 triche')
async def cmd_remprestige(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        amount = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Valeur invalide.")
        return
    u = await get_user(t.id)
    new_val = max(0, u.get("prestige", 0) - amount)
    await update_field(t.id, "prestige", new_val)
    await _log_admin(update.effective_user.id, "remprestige", t.id, str(amount))
    await update.message.reply_text(
        alert("success", f"-{amount} prestige pour {t.full_name} (maintenant {new_val})"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/setprestige @joueur 50 correction')
async def cmd_setprestige(update, context):
    await _set_field(update, context, "prestige", "Prestige")


@lead_staff_only
@motif_required(1, '/addxp @joueur 500 compensation')
async def cmd_addxp(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        amount = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Valeur invalide.")
        return
    await increment_field(t.id, "xp", amount)
    await _log_admin(update.effective_user.id, "addxp", t.id, str(amount))
    await update.message.reply_text(
        alert("success", f"+{amount} XP pour {t.full_name}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/remxp @joueur 500 triche')
async def cmd_remxp(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        amount = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Valeur invalide.")
        return
    u = await get_user(t.id)
    new_val = max(0, u.get("xp", 0) - amount)
    await update_field(t.id, "xp", new_val)
    await _log_admin(update.effective_user.id, "remxp", t.id, str(amount))
    await update.message.reply_text(
        alert("success", f"-{amount} XP pour {t.full_name} (maintenant {new_val})"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/setxp @joueur 1000 correction')
async def cmd_setxp(update, context):
    await _set_field(update, context, "xp", "XP")


@lead_staff_only
@motif_required(1, '/setlevel @joueur 5 correction')
async def cmd_setlevel(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        level = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Niveau invalide.")
        return
    xp_needed = max(0, (level - 1) ** 2 * 500)
    await update_field(t.id, "xp", xp_needed)
    await _log_admin(update.effective_user.id, "setlevel", t.id, str(level))
    await update.message.reply_text(
        alert("success", f"Niveau de {t.full_name} forcé à {level} (XP = {xp_needed})"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/addkarma @joueur 10 geste récompensé')
async def cmd_addkarma(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        amount = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Valeur invalide.")
        return
    await increment_field(t.id, "karma", amount)
    await _log_admin(update.effective_user.id, "addkarma", t.id, str(amount))
    await update.message.reply_text(
        alert("success", f"+{amount} karma pour {t.full_name}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/remkarma @joueur 10 comportement toxique')
async def cmd_remkarma(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        amount = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Valeur invalide.")
        return
    u = await get_user(t.id)
    new_val = u.get("karma", 0) - amount
    await update_field(t.id, "karma", new_val)
    await _log_admin(update.effective_user.id, "remkarma", t.id, str(amount))
    await update.message.reply_text(
        alert("success", f"-{amount} karma pour {t.full_name} (maintenant {new_val})"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/setkarma @joueur 0 correction')
async def cmd_setkarma(update, context):
    await _set_field(update, context, "karma", "Karma")


# ─── Marché (Lead Staff) ───

@lead_staff_only
async def cmd_crashmarket(update, context):
    async with db_connection() as db:
        await db.execute("UPDATE market_prices SET price = price * 0.3")
        await db.commit()
    await _log_admin(update.effective_user.id, "crashmarket", 0, "")
    await update.message.reply_text(
        card(
            "💥 KRACH BOURSIER",
            ["Tous les prix divisés par ~3", "Les investisseurs paniquent !"],
            icon="💥", style="thick",
        ),
        parse_mode="HTML",
    )


@lead_staff_only
async def cmd_boommarket(update, context):
    async with db_connection() as db:
        await db.execute("UPDATE market_prices SET price = price * 2.5")
        await db.commit()
    await _log_admin(update.effective_user.id, "boommarket", 0, "")
    await update.message.reply_text(
        card(
            "🚀 BOOM DU MARCHÉ",
            ["Tous les prix ×2.5", "Les actionnaires font la fête !"],
            icon="🚀", style="stars",
        ),
        parse_mode="HTML",
    )


@lead_staff_only
async def cmd_resetmarket(update, context):
    async with db_connection() as db:
        await db.execute("UPDATE market_prices SET price = 100")
        await db.commit()
    await _log_admin(update.effective_user.id, "resetmarket", 0, "")
    await update.message.reply_text(
        alert("success", "Marché remis à 100 partout."),
        parse_mode="HTML"
    )


@lead_staff_only
async def cmd_setprice(update, context):
    if len(context.args) < 2:
        return
    asset = context.args[0]
    try:
        price = float(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Prix invalide.")
        return
    async with db_connection() as db:
        await db.execute("UPDATE market_prices SET price=? WHERE asset_name=?", (price, asset))
        await db.commit()
    await _log_admin(update.effective_user.id, "setprice", 0, f"{asset} → {price}")
    await update.message.reply_text(
        alert("success", f"Prix de {asset} fixé à {price}"),
        parse_mode="HTML"
    )


@lead_staff_only
async def cmd_setstock(update, context):
    await cmd_setprice(update, context)


@lead_staff_only
async def cmd_maintenance(update, context):
    mode = context.args[0].lower() if context.args else "on"
    import os
    flag = "maintenance.flag"
    if mode == "on":
        open(flag, "w").close()
        await update.message.reply_text(
            alert("warning", "🔧 Mode maintenance ACTIVÉ"),
            parse_mode="HTML"
        )
    else:
        if os.path.exists(flag):
            os.remove(flag)
        await update.message.reply_text(
            alert("success", "✅ Maintenance désactivée"),
            parse_mode="HTML"
        )


# ─── Entreprises (Lead Staff) ───

@lead_staff_only
async def cmd_setcompanytreasury(update, context):
    if len(context.args) < 3:
        await update.message.reply_text("Usage : /setcompanytreasury @user entreprise montant")
        return
    t = await _resolve(update, context)
    if not t:
        await update.message.reply_text("❌ Utilisateur invalide.")
        return
    company_name = context.args[1]
    try:
        amount = int(context.args[2])
    except ValueError:
        await update.message.reply_text("❌ Montant invalide.")
        return
    try:
        async with db_connection() as db:
            async with db.execute(
                "SELECT company_id FROM companies WHERE name = ? AND dissolved = 0",
                (company_name,)
            ) as cur:
                row = await cur.fetchone()
            if not row:
                raise DeferredReply(update.message.reply_text, f"❌ Entreprise '{company_name}' introuvable.")
            await db.execute("UPDATE companies SET treasury = ? WHERE company_id = ?", (amount, row[0]))
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()
    await _log_admin(update.effective_user.id, "setcompanytreasury", t.id, f"{company_name} -> {amount}")
    await update.message.reply_text(
        alert("success", f"Trésorerie de {company_name} fixée à {fmt(amount)}"),
        parse_mode="HTML"
    )


@lead_staff_only
async def cmd_setcompanyreputation(update, context):
    if len(context.args) < 3:
        await update.message.reply_text("Usage : /setcompanyreputation @user entreprise valeur")
        return
    t = await _resolve(update, context)
    if not t:
        await update.message.reply_text("❌ Utilisateur invalide.")
        return
    company_name = context.args[1]
    try:
        rep = int(context.args[2])
        if rep < 0 or rep > 100:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Valeur de réputation invalide (0-100).")
        return
    try:
        async with db_connection() as db:
            async with db.execute(
                "SELECT company_id FROM companies WHERE name = ? AND dissolved = 0",
                (company_name,)
            ) as cur:
                row = await cur.fetchone()
            if not row:
                raise DeferredReply(update.message.reply_text, f"❌ Entreprise '{company_name}' introuvable.")
            await db.execute("UPDATE companies SET reputation = ? WHERE company_id = ?", (rep, row[0]))
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()
    await _log_admin(update.effective_user.id, "setcompanyreputation", t.id, f"{company_name} -> {rep}")
    await update.message.reply_text(
        alert("success", f"Réputation de {company_name} fixée à {rep}"),
        parse_mode="HTML"
    )


@lead_staff_only
async def cmd_setcompanylevel(update, context):
    if len(context.args) < 3:
        await update.message.reply_text("Usage : /setcompanylevel @user entreprise niveau")
        return
    t = await _resolve(update, context)
    if not t:
        await update.message.reply_text("❌ Utilisateur invalide.")
        return
    company_name = context.args[1]
    try:
        level = int(context.args[2])
    except ValueError:
        await update.message.reply_text("❌ Niveau invalide.")
        return
    try:
        async with db_connection() as db:
            async with db.execute(
                "SELECT company_id FROM companies WHERE name = ? AND dissolved = 0",
                (company_name,)
            ) as cur:
                row = await cur.fetchone()
            if not row:
                raise DeferredReply(update.message.reply_text, f"❌ Entreprise '{company_name}' introuvable.")
            await db.execute("UPDATE companies SET level = ? WHERE company_id = ?", (level, row[0]))
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()
    await _log_admin(update.effective_user.id, "setcompanylevel", t.id, f"{company_name} -> {level}")
    await update.message.reply_text(
        alert("success", f"Niveau de {company_name} fixé à {level}"),
        parse_mode="HTML"
    )


@lead_staff_only
async def cmd_addcompanytreasury(update, context):
    if len(context.args) < 2:
        await update.message.reply_text("Usage : /addcompanytreasury entreprise montant")
        return
    company_name = context.args[0]
    amount = parse_amount(context.args[1])
    if not amount:
        await update.message.reply_text("❌ Montant invalide.")
        return
    async with db_connection() as db:
        await db.execute(
            "UPDATE companies SET treasury = treasury + ? WHERE name = ? AND dissolved = 0",
            (amount, company_name)
        )
        await db.commit()
    await _log_admin(update.effective_user.id, "addcompanytreasury", 0, f"{company_name} +{amount}")
    await update.message.reply_text(
        alert("success", f"Ajouté {fmt(amount)} à la trésorerie de {company_name}"),
        parse_mode="HTML"
    )


@lead_staff_only
async def cmd_removetreasury(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("Usage : /removetreasury [nom_entreprise] [montant]")
        return
    company_name = " ".join(context.args[:-1])
    amount = parse_amount(context.args[-1])
    if not amount or amount <= 0:
        await update.message.reply_text("❌ Montant invalide.")
        return
    try:
        async with db_connection() as db:
            async with db.execute(
                "SELECT company_id, treasury FROM companies WHERE name = ? AND dissolved = 0",
                (company_name,)
            ) as cur:
                row = await cur.fetchone()
            if not row:
                raise DeferredReply(update.message.reply_text, f"❌ Entreprise '{company_name}' introuvable.")
            company_id, treasury = row
            if amount > treasury:
                raise DeferredReply(update.message.reply_text, f"❌ Trésorerie insuffisante. Disponible : {fmt(treasury)}")
            await db.execute(
                "UPDATE companies SET treasury = treasury - ? WHERE company_id = ?",
                (amount, company_id)
            )
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()
    from database import log_company_action
    await log_company_action(
        company_id, "retrait_admin",
        update.effective_user.id, f"{fmt(amount)}"
    )
    await _log_admin(update.effective_user.id, "removetreasury", 0, f"{company_name} -{amount}")
    await update.message.reply_text(
        f"✅ Retrait de {escape_html(fmt(amount))} de la trésorerie de <b>{escape_html(company_name)}</b>. "
        f"Nouvelle trésorerie : {escape_html(fmt(treasury - amount))}",
        parse_mode="HTML"
    )


@lead_staff_only
async def cmd_deletecompany(update, context):
    if not context.args:
        return
    name = context.args[0]
    async with db_connection() as db:
        await db.execute("UPDATE companies SET dissolved=1 WHERE name=?", (name,))
        await db.commit()
    await _log_admin(update.effective_user.id, "deletecompany", 0, name)
    await update.message.reply_text(
        alert("success", f"Entreprise {name} dissoute."),
        parse_mode="HTML"
    )


@lead_staff_only
async def cmd_listcompanies(update, context):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM companies WHERE dissolved=0 LIMIT 20") as cur:
            rows = await cur.fetchall()
    body = [f"  {r['name']} ({r['sector']}) ─ {fmt(r['treasury'])}" for r in rows]
    await update.message.reply_text(
        card("Entreprises actives", body or ["(aucune)"], icon="🏢", style="thick"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(2, '/forcehire @joueur entreprise poste motif')
async def cmd_forcehire(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 3:
        return
    company = context.args[1]
    poste = context.args[2]
    async with db_connection() as db:
        async with db.execute(
            "SELECT company_id FROM companies WHERE name=?", (company,)
        ) as cur:
            cid_row = await cur.fetchone()
        if not cid_row:
            return
        await db.execute(
            "INSERT OR REPLACE INTO company_members(user_id, company_id, poste, salary, joined_at) "
            "VALUES(?,?,?,?,?)",
            (t.id, cid_row[0], poste, 1500, now())
        )
        await db.commit()
    await update.message.reply_text(
        alert("success", f"{t.full_name} engagé chez {company} en {poste}"),
        parse_mode="HTML"
    )


# ─── Patrimoine (Lead Staff) ───

@lead_staff_only
@motif_required(1, '/setproperty @joueur id motif')
async def cmd_setproperty(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    ptype = context.args[1]
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO properties(user_id, prop_type, purchased_at, condition) VALUES(?,?,?,100)",
            (t.id, ptype, now())
        )
        await db.commit()
    await _log_admin(update.effective_user.id, "setproperty", t.id, ptype)
    await update.message.reply_text(
        alert("success", f"Propriété {ptype} ajoutée à {t.full_name}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(2, '/setpropertycond @joueur id état motif')
async def cmd_setpropertycond(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 3:
        return
    try:
        prop_id = int(context.args[1])
        condition = int(context.args[2])
    except ValueError:
        await update.message.reply_text("❌ ID et condition doivent être des nombres.")
        return
    async with db_connection() as db:
        await db.execute(
            "UPDATE properties SET condition = ? WHERE prop_id = ? AND user_id = ?",
            (condition, prop_id, t.id)
        )
        await db.commit()
    await _log_admin(update.effective_user.id, "setpropertycond", t.id, f"prop_id:{prop_id} cond:{condition}")
    await update.message.reply_text(
        alert("success", f"État de la propriété #{prop_id} de {t.full_name} fixé à {condition}%"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(1, '/setvehicle @joueur id motif')
async def cmd_setvehicle(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    veh_type = context.args[1]
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO vehicles(user_id, veh_type, condition, insured, purchased_at) "
            "VALUES(?,?,100,0,?)",
            (t.id, veh_type, now())
        )
        await db.commit()
    await _log_admin(update.effective_user.id, "setvehicle", t.id, veh_type)
    await update.message.reply_text(
        alert("success", f"Véhicule {veh_type} ajouté à {t.full_name}"),
        parse_mode="HTML"
    )


@lead_staff_only
@motif_required(2, '/setvehiclecond @joueur id état motif')
async def cmd_setvehiclecond(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 3:
        return
    try:
        veh_id = int(context.args[1])
        condition = int(context.args[2])
    except ValueError:
        await update.message.reply_text("❌ ID et condition doivent être des nombres.")
        return
    async with db_connection() as db:
        await db.execute(
            "UPDATE vehicles SET condition = ? WHERE veh_id = ? AND user_id = ?",
            (condition, veh_id, t.id)
        )
        await db.commit()
    await _log_admin(update.effective_user.id, "setvehiclecond", t.id, f"veh_id:{veh_id} cond:{condition}")
    await update.message.reply_text(
        alert("success", f"État du véhicule #{veh_id} de {t.full_name} fixé à {condition}%"),
        parse_mode="HTML"
    )


@lead_staff_only
async def cmd_setluxury(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    article = " ".join(context.args[1:])
    from config import LUXURY_ITEMS
    if article not in LUXURY_ITEMS:
        await update.message.reply_text("❌ Article de luxe inconnu.")
        return
    data = LUXURY_ITEMS[article]
    async with db_connection() as db:
        async with db.execute("SELECT item_id FROM items WHERE name = ?", (article,)) as cur:
            row = await cur.fetchone()
        if row:
            item_id = row[0]
        else:
            await db.execute("""
                INSERT INTO items (name, type, rarity, value, effect_type, effect_value, emoji, description)
                VALUES (?, 'luxury', 'epic', ?, NULL, 0, ?, ?)
            """, (article, data["price"], data["emoji"], f"Article de luxe : {article}"))
            async with db.execute("SELECT last_insert_rowid()") as cur2:
                item_id = (await cur2.fetchone())[0]
        await _add_item_to_inventory(t.id, item_id, 1, "luxury")
        await db.commit()
    await _log_admin(update.effective_user.id, "setluxury", t.id, article)
    await update.message.reply_text(
        alert("success", f"Article de luxe {article} ajouté à {t.full_name}"),
        parse_mode="HTML"
    )


@lead_staff_only
async def cmd_setblackmarket(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    article = " ".join(context.args[1:])
    from config import BLACK_MARKET_ITEMS
    if article not in BLACK_MARKET_ITEMS:
        await update.message.reply_text("❌ Article du marché noir inconnu.")
        return
    data = BLACK_MARKET_ITEMS[article]
    async with db_connection() as db:
        async with db.execute("SELECT item_id FROM items WHERE name = ?", (article,)) as cur:
            row = await cur.fetchone()
        if row:
            item_id = row[0]
        else:
            await db.execute("""
                INSERT INTO items (name, type, rarity, value, effect_type, effect_value, emoji, description)
                VALUES (?, 'blackmarket', 'rare', ?, NULL, 0, ?, ?)
            """, (article, data["price"], data["emoji"], f"Article du marché noir : {article}"))
            async with db.execute("SELECT last_insert_rowid()") as cur2:
                item_id = (await cur2.fetchone())[0]
        await _add_item_to_inventory(t.id, item_id, 1, "blackmarket")
        await db.commit()
    await _log_admin(update.effective_user.id, "setblackmarket", t.id, article)
    await update.message.reply_text(
        alert("success", f"Article {article} du marché noir ajouté à {t.full_name}"),
        parse_mode="HTML"
    )


# ─── Stats serveur (Lead Staff) ───

@lead_staff_only
async def cmd_botstats(update, context):
    async with db_connection() as db:
        async with db.execute(
            "SELECT COUNT(*), SUM(balance), AVG(level), MAX(balance) "
            "FROM users WHERE registered=1"
        ) as cur:
            count, total_bal, avg_lvl, max_bal = await cur.fetchone()
    body = [
        f"👥 Joueurs : <b>{count or 0}</b>",
        f"💰 Argent total en circulation : <b>{fmt(total_bal or 0)}</b>",
        f"📊 Niveau moyen : <b>{avg_lvl or 0:.1f}</b>",
        f"💎 Plus riche : <b>{fmt(max_bal or 0)}</b>",
    ]
    await update.message.reply_text(
        card("STATS SERVEUR", body, icon="🌐", style="thick"),
        parse_mode="HTML",
    )


@lead_staff_only
async def cmd_serverstats(update, context):
    await cmd_botstats(update, context)


@lead_staff_only
@motif_required(1, '/resetcooldown @joueur champ motif')
async def cmd_resetcooldown(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    field = context.args[1]
    await update_field(t.id, field, 0)
    await _log_admin(update.effective_user.id, "resetcooldown", t.id, field)
    await update.message.reply_text(
        alert("success", f"Cooldown {field} de {t.full_name} reset."),
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════════════
#                    👑 LEAD PRINCIPAL — Commandes Dieu
# ═══════════════════════════════════════════════════════════════════════════

@lead_principal_only
@motif_required(1, '/godmode @joueur on motif')
async def cmd_godmode(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    mode = "on"
    if len(context.args) > 1:
        mode = context.args[1].lower()
    elif context.args and context.args[0].lower() in ("on", "off"):
        mode = context.args[0].lower()
    new_val = 1 if mode == "on" else 0
    await update_field(t.id, "god_mode", new_val)
    await _log_admin(update.effective_user.id, "godmode", t.id, mode)
    if new_val:
        await update.message.reply_text(
            card(
                "⚡ MODE DIEU ACTIVÉ",
                [
                    f"<b>{t.full_name}</b> est <b>invincible</b>.",
                    "❤️ Santé, faim, énergie, bonheur toujours au maximum · jamais à terre.",
                    "🔓 Ignore prison, hôpital et menottes · aucun cooldown · pas de lieu imposé.",
                    "🛡️ Ne peut être ni volé ni neutralisé · accès aux commandes admin.",
                ],
                icon="⚡", style="stars",
            ),
            parse_mode="HTML",
        )
    else:
        await update.message.reply_text(
            alert("warning", f"Mode Dieu désactivé pour {t.full_name}"),
            parse_mode="HTML"
        )


@lead_principal_only
@motif_required(0, '/killuser @joueur décision du Lead Principal')
async def cmd_killuser(update, context):
    t = await _resolve(update, context)
    if not t:
        return
    async with db_connection() as db:
        await db.execute(
            "UPDATE users SET health=0, hospital_until=? WHERE user_id=?",
            (now() + 3600, t.id)
        )
        await db.execute(
            "INSERT INTO life_journal(user_id, category, summary, severity, created_at) "
            "VALUES(?,?,?,?,?)",
            (t.id, "death", "💀 Ton personnage est à terre (santé à zéro). Va à l'hôpital pour te soigner.",
             "danger", now())
        )
        await db.commit()
    await _log_admin(update.effective_user.id, "killuser", t.id)

    await _notify_target(
        context, t.id,
        "💀 MORT INFLIGÉE",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            "Ton personnage est <b>à terre</b> (santé à zéro).",
            "Va à l'hôpital (menu Vie → Hôpital) pour te soigner.",
        ],
        icon="💀", style="thick",
        bdd_msg="💀 Ton personnage a été mis à terre. Va à l'hôpital pour te soigner.",
    )

    await update.message.reply_text(
        card(
            "💀 MORT INFLIGÉE",
            [
                f"<b>{t.full_name}</b> est à terre (santé à zéro).",
                "Il doit aller à l'hôpital pour se soigner.",
            ],
            icon="💀", style="thick",
        ),
        parse_mode="HTML",
    )


@lead_principal_only
@motif_required(1, '/timetravel @joueur heures motif')
async def cmd_timetravel(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 2:
        return
    try:
        hours = int(context.args[-1])
    except ValueError:
        await update.message.reply_text("❌ Nombre d'heures invalide.")
        return
    if not 1 <= hours <= 168:
        await update.message.reply_text("❌ Entre 1 et 168 heures de jeu (7 jours max).")
        return
    async with db_connection() as db:
        await db.execute(
            "UPDATE users SET last_life_tick = last_life_tick - ? WHERE user_id=?",
            (hours * 3600, t.id)
        )
        await db.commit()
    from utils.simulation import apply_passive_simulation
    await apply_passive_simulation(t.id)
    await _log_admin(update.effective_user.id, "timetravel", t.id, str(hours))
    await update.message.reply_text(
        alert("success", f"⏳ {fmt_time(hours * 3600)} DE JEU simulées pour {t.full_name}"),
        parse_mode="HTML"
    )


@lead_principal_only
@motif_required(3, '/spawn @joueur argent xp prestige motif')
async def cmd_spawn(update, context):
    t = await _resolve(update, context)
    if not t or len(context.args) < 4:
        return
    money = parse_amount(context.args[1])
    try:
        xp = int(context.args[2])
        prestige = int(context.args[3])
    except ValueError:
        await update.message.reply_text("❌ Valeurs invalides.")
        return
    u = await get_user(t.id)
    await update_field(t.id, "balance", u["balance"] + money)
    await update_field(t.id, "xp", u["xp"] + xp)
    await update_field(t.id, "prestige", u["prestige"] + prestige)
    await _log_admin(update.effective_user.id, "spawn", t.id, f"{money}/{xp}/{prestige}")

    await _notify_target(
        context, t.id,
        "⚡ SPAWN BOOST",
        [
            f"Par : <b>{update.effective_user.full_name}</b>",
            f"💰 +{fmt(money)}",
            f"⭐ +{xp} XP",
            f"👑 +{prestige} prestige",
        ],
        icon="⚡", style="stars",
        bdd_msg=f"⚡ Spawn boost : +{fmt(money)} · +{xp} XP · +{prestige} prestige.",
    )

    await update.message.reply_text(
        card(
            "⚡ SPAWN BOOST",
            [
                f"<b>{t.full_name}</b>",
                f"💰 +{fmt(money)}",
                f"⭐ +{xp} XP",
                f"👑 +{prestige} prestige",
            ],
            icon="⚡", style="stars",
        ),
        parse_mode="HTML",
    )


@lead_principal_only
async def cmd_resetworld(update, context):
    if not context.args or context.args[0].lower() != "confirm":
        await update.message.reply_text(
            card(
                "💀 RESET MONDE",
                [
                    "⚠️ **CETTE ACTION EST IRRÉVERSIBLE**",
                    "Tous les joueurs seront réinitialisés.",
                    "Les entreprises, gangs, etc. seront supprimés.",
                    "Pour confirmer : `/resetworld confirm`",
                ],
                icon="💀", style="thick",
            ),
            parse_mode="HTML",
        )
        return
    async with db_connection() as db:
        for table in [
            "users", "bank_accounts", "properties", "vehicles", "skills",
            "garden", "investments", "companies", "company_members",
            "company_applications", "company_logs", "company_shares",
            "company_products", "company_ads", "company_invitations",
            "family", "family_members", "marriages", "marriage_requests",
            "friendships", "inventory", "auction_listings", "crime_log",
            "travel_log", "missions", "politics", "social_media",
            "blackmarket_log", "world_events", "lottery_tickets",
            "lottery_draws", "hack_log", "pvp_challenges", "insurance",
            "admin_logs", "price_history", "gangs", "gang_members",
            "adoptions", "casino_log", "bank_loans", "user_badges",
            "title_history", "mission_log", "social_log",
            "user_achievements", "notifications", "life_journal",
            "reports", "mp_trades", "mp_relations", "mp_gifts",
            "transaction_log",
        ]:
            try:
                await db.execute(f"DELETE FROM {table}")
            except aiosqlite.OperationalError:
                swallowed('handlers/admin.py')
        try:
            await db.execute("DELETE FROM sqlite_sequence")
        except aiosqlite.OperationalError:
            swallowed('handlers/admin.py')
        await db.commit()
    await _log_admin(update.effective_user.id, "RESETWORLD", 0, "Monde réinitialisé")
    await update.message.reply_text(
        alert("danger", "🌍 LE MONDE A ÉTÉ RÉINITIALISÉ COMPLÈTEMENT."),
        parse_mode="HTML"
    )


@lead_principal_only
@motif_required(1, '/deleteuser @joueur confirm compte frauduleux')
async def cmd_deleteuser(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target = await _resolve(update, context)
    if not target:
        await update.message.reply_text("Usage : /deleteuser @utilisateur (ou en répondant) confirm")
        return

    if not context.args or context.args[-1].lower() != "confirm":
        await update.message.reply_text(
            f"⚠️ **SUPPRESSION DÉFINITIVE DE {target.full_name}**\n\n"
            f"Pour confirmer : `/deleteuser {target.id} confirm`"
        )
        return

    async with db_connection() as db:
        for query in [
            "DELETE FROM user_achievements WHERE user_id = ?",
            "DELETE FROM user_badges WHERE user_id = ?",
            "DELETE FROM notifications WHERE user_id = ?",
            "DELETE FROM life_journal WHERE user_id = ?",
            "DELETE FROM reports WHERE user_id = ? OR target_id = ?",
            "DELETE FROM mp_trades WHERE from_id = ? OR to_id = ?",
            "DELETE FROM mp_relations WHERE user_id = ? OR other_id = ?",
            "DELETE FROM inventory WHERE user_id = ?",
            "DELETE FROM missions WHERE user_id = ?",
            "DELETE FROM crime_log WHERE user_id = ?",
            "DELETE FROM travel_log WHERE user_id = ?",
            "DELETE FROM marriages WHERE user_id = ? OR partner_id = ?",
            "DELETE FROM family_members WHERE user_id = ?",
            "DELETE FROM bank_accounts WHERE user_id = ?",
            "DELETE FROM investments WHERE user_id = ?",
            "DELETE FROM garden WHERE user_id = ?",
            "DELETE FROM properties WHERE user_id = ?",
            "DELETE FROM vehicles WHERE user_id = ?",
            "DELETE FROM skills WHERE user_id = ?",
            "DELETE FROM company_members WHERE user_id = ?",
            "DELETE FROM gang_members WHERE user_id = ?",
            "DELETE FROM admin_roles WHERE user_id = ?",
            "DELETE FROM transaction_log WHERE user_id = ?",
            "DELETE FROM users WHERE user_id = ?",
        ]:
            try:
                if query.count("?") == 2:
                    await db.execute(query, (target.id, target.id))
                else:
                    await db.execute(query, (target.id,))
            except aiosqlite.OperationalError:
                swallowed('handlers/admin.py')
        await db.commit()

    await _log_admin(update.effective_user.id, "DELETE_USER", target.id, target.full_name)
    await update.message.reply_text(
        f"🗑️ **Joueur {target.full_name} (ID {target.id}) supprimé définitivement.**"
    )


@lead_principal_only
async def cmd_adminlogs(update, context):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        try:
            async with db.execute(
                "SELECT * FROM admin_logs ORDER BY timestamp DESC LIMIT 15"
            ) as cur:
                rows = await cur.fetchall()
        except aiosqlite.OperationalError:
            rows = []
    if not rows:
        await update.message.reply_text(
            alert("info", "Aucun log admin."),
            parse_mode="HTML"
        )
        return
    body = []
    for r in rows:
        body.append(
            f"<code>{fmt_game_datetime(r['timestamp'], sep=' ')}</code> "
            f"<b>{r['action']}</b> on {r['target_id']} ({r['details'][:30]})"
        )
    await update.message.reply_text(
        card("📜 LOGS ADMIN", body, icon="📜", style="thick"),
        parse_mode="HTML",
    )


# ═══════════════════════════════════════════════════════════════════════════
#                    👨‍💻 LEAD STUDIO — Accès technique
# ═══════════════════════════════════════════════════════════════════════════

@lead_studio_only
async def cmd_reloadconfig(update, context):
    import importlib
    import config
    importlib.reload(config)
    await _log_admin(update.effective_user.id, "reloadconfig", 0)
    await update.message.reply_text(
        alert("success", "♻️ Config rechargée."),
        parse_mode="HTML"
    )


@lead_studio_only
async def cmd_fix_inventory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        async with db_connection() as db:
            await db.execute("CREATE TABLE inventory_backup AS SELECT * FROM inventory")
            await db.execute("DROP TABLE inventory")
            await db.execute("""
                CREATE TABLE inventory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    item_id INTEGER,
                    item_type TEXT,
                    item_name TEXT,
                    quantity INTEGER DEFAULT 1,
                    acquired_at INTEGER,
                    UNIQUE(user_id, item_id)
                )
            """)
            await db.execute("""
                INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at)
                SELECT user_id, item_id, item_type, item_name, SUM(quantity), MIN(acquired_at)
                FROM inventory_backup
                GROUP BY user_id, item_id
            """)
            await db.execute("DROP TABLE inventory_backup")
            await db.commit()
        await _log_admin(update.effective_user.id, "fix_inventory", 0)
        await update.message.reply_text(
            "✅ Table inventory corrigée avec succès (données conservées)."
        )
    except Exception as e:
        await update.message.reply_text(f"❌ Erreur : {e}")


# ═══════════════════════════════════════════════════════════════════════════
#                    EXPORTS
# ═══════════════════════════════════════════════════════════════════════════

__all__ = [
    # Admin N1
    "cmd_warn", "cmd_clearwarn",
    "cmd_userinfo", "cmd_userstats", "cmd_topstats",
    # Admin N2
    "cmd_banuser", "cmd_unbanuser", "cmd_freezeuser", "cmd_unfreezeuser",
    "cmd_forceprison", "cmd_freeprison", "cmd_sethospital", "cmd_settravel",
    "cmd_resetuser", "cmd_sethp", "cmd_setenergy", "cmd_sethappiness",
    "cmd_sethunger", "cmd_setstress", "cmd_setage", "cmd_setjob",
    "cmd_setdiplome", "cmd_setbio", "cmd_setcolor", "cmd_setlocation",
    "cmd_setskill", "cmd_listusers", "cmd_playerhistory", "cmd_givebadge",
    # Game Leader
    "cmd_createevent", "cmd_endevent", "cmd_broadcast", "cmd_announce",
    "cmd_lotowin", "cmd_giveitem", "cmd_takeitem", "cmd_setitem",
    "cmd_clearinventory", "cmd_giveallitems", "cmd_listitems",
    "cmd_mission_force", "cmd_resetmissions",
    "cmd_gang_create_admin", "cmd_gang_delete",
    "cmd_gang_add", "cmd_gang_remove", "cmd_gang_set_treasury",
    "cmd_gang_set_reputation", "cmd_setrelation", "cmd_setmarriage",
    "cmd_admin_divorce", "cmd_setfamily", "cmd_removefamily",
    # Lead Staff
    "cmd_addmoney", "cmd_removemoney", "cmd_setmoney",
    "cmd_addbank", "cmd_rembank", "cmd_setbank", "cmd_cleardebt",
    "cmd_addprestige", "cmd_remprestige", "cmd_setprestige",
    "cmd_addxp", "cmd_remxp", "cmd_setxp", "cmd_setlevel",
    "cmd_addkarma", "cmd_remkarma", "cmd_setkarma",
    "cmd_addsocialcoins", "cmd_remsocialcoins", "cmd_setsocialcoins",
    "cmd_crashmarket", "cmd_boommarket", "cmd_resetmarket",
    "cmd_setprice", "cmd_setstock", "cmd_maintenance",
    "cmd_setcompanytreasury", "cmd_setcompanyreputation",
    "cmd_setcompanylevel", "cmd_addcompanytreasury", "cmd_removetreasury",
    "cmd_deletecompany", "cmd_listcompanies", "cmd_forcehire",
    "cmd_setproperty", "cmd_setpropertycond", "cmd_setvehicle",
    "cmd_setvehiclecond", "cmd_setluxury", "cmd_setblackmarket",
    "cmd_botstats", "cmd_serverstats", "cmd_resetcooldown",
    # Lead Principal
    "cmd_godmode", "cmd_killuser", "cmd_timetravel", "cmd_spawn",
    "cmd_resetworld", "cmd_deleteuser", "cmd_adminlogs",
    # Lead Studio
    "cmd_reloadconfig", "cmd_fix_inventory",
]