# handlers/shop_stars.py
"""
Boutique Telegram Stars : abonnements VIP/Premium + boutique.

CORRECTIONS :
  • Fix exploit lottery_ticket (donne 1 ticket au lieu du jackpot)
  • Anti-spam Lead (cooldown 5s entre chaque achat gratuit)
  • Log transaction systématique
  • Retrait des items non implémentés (slots5, casino_spin)
  • ⭐ Refus des achats si plafond stack atteint (AVANT facture)
  • ⭐ Remboursement automatique si un paiement passe au plafond
  • ⭐ Affichage "MAX ATTEINT" + progression dans la boutique
  • ⭐ NOUVEAU : Affichage short_desc dans les boutons de catégorie
  • ⭐ NOUVEAU : Affichage desc complète dans la facture Telegram
"""
from utils.gamerules import switch_on
import html
import logging
import random

from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup, LabeledPrice,
)
from telegram.ext import ContextTypes

from database import (
    get_user, update_field, increment_field, update_balance,
    log_star_purchase, grant_subscription, extend_boost, add_stack,
    db_connection,
)
from utils.decorators import require_registered
from utils.helpers import fmt, now
from utils.aesthetics import card, alert, rich_bar
from utils.vip import get_tier, status_label
from config import (
    STARS_SUBSCRIPTIONS, STARS_SHOP, STARS_SHOP_CATEGORIES, STARS_FEATURED_OFFERS, STARS_RETIRED_ITEMS,
    VIP_TIER_BONUSES, LEAD_PRINCIPAL_IDS, LEAD_STAFF_GLOBAL_IDS,
)
from handlers.payments import log_transaction, generate_reference

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════
#                    Cooldown anti-spam Lead
# ═══════════════════════════════════════════════════════════════════
_LEAD_PURCHASE_COOLDOWN: dict[int, float] = {}
_LEAD_COOLDOWN_SECONDS = 5


def _is_lead(user_id: int) -> bool:
    return user_id in LEAD_PRINCIPAL_IDS or user_id in LEAD_STAFF_GLOBAL_IDS


def _check_lead_cooldown(user_id: int) -> tuple[bool, int]:
    import time
    last = _LEAD_PURCHASE_COOLDOWN.get(user_id, 0)
    elapsed = time.time() - last
    if elapsed < _LEAD_COOLDOWN_SECONDS:
        return False, int(_LEAD_COOLDOWN_SECONDS - elapsed) + 1
    return True, 0


def _mark_lead_purchase(user_id: int):
    import time
    _LEAD_PURCHASE_COOLDOWN[user_id] = time.time()


# ═══════════════════════════════════════════════════════════════════
#          ⭐ Vérification du plafond pour les items "stack"
# ═══════════════════════════════════════════════════════════════════
async def _check_stack_available(user_id: int, item_id: str) -> tuple[bool, str]:
    """
    Vérifie si un item peut être acheté en l'état actuel du joueur :
      • pour un "stack" : refuse si le plafond est déjà atteint.
      • pour un consommable à précondition (prison_clear, diplome_skip) :
        refuse si la précondition n'est pas remplie, pour éviter de facturer
        un achat inutile (ex. acheter une carte de sortie de prison en étant libre).
    Retourne (True, "") si possible, ou (False, raison) sinon.
    """
    item = STARS_SHOP.get(item_id)
    if not item:
        return True, ""

    if item.get("type") == "stack":
        field = item["field"]
        amount = item["amount"]
        max_total = amount * item["max_stack"]

        u = await get_user(user_id)
        current = u.get(field, 0) or 0

        if current >= max_total:
            return False, f"Déjà au maximum ({current}/{max_total})"
        return True, ""

    if item.get("type") == "consumable" and item.get("effect") == "prison_clear":
        u = await get_user(user_id)
        if u.get("prison_until", 0) <= now():
            return False, "Tu n'es pas en prison, rien à débloquer."
        return True, ""

    if item.get("type") == "consumable" and item.get("effect") == "diplome_skip":
        from config import DIPLOME_STUDY_TIME, DIPLOME_STUDY_TIME_EXTENDED
        all_times = {**DIPLOME_STUDY_TIME, **DIPLOME_STUDY_TIME_EXTENDED}
        u = await get_user(user_id)
        dip = u.get("study_diplome")
        start = u.get("study_start", 0)
        if not dip or start <= 0:
            return False, "Aucune formation en cours."
        remaining = (start + all_times.get(dip, 0)) - now()
        if remaining <= 0:
            return False, "Ta formation est déjà terminée, passe l'examen."
        return True, ""

    return True, ""


async def _get_stack_progress(user_id: int, item_id: str) -> tuple[int, int]:
    """Retourne (current, max) pour un item stack."""
    item = STARS_SHOP.get(item_id)
    if not item or item.get("type") != "stack":
        return 0, 0
    field = item["field"]
    max_total = item["amount"] * item["max_stack"]
    u = await get_user(user_id)
    current = u.get(field, 0) or 0
    return current, max_total


# ═══════════════════════════════════════════════════════════════════
#                    /vip — Statut & abonnements
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = await get_user(update.effective_user.id)
    tier = get_tier(u)

    body = [f"📌 Statut actuel : <b>{status_label(u)}</b>"]
    if tier == "vip" and u.get("vip_until"):
        body.append(f"⏳ Expire le : {_fmt_date(u['vip_until'])}")
    elif tier == "premium" and u.get("premium_until"):
        body.append(f"⏳ Expire le : {_fmt_date(u['premium_until'])}")

    if _is_lead(update.effective_user.id):
        body += [
            "",
            "👑 <b>Privilège Lead détecté</b>",
            "<i>Tous les achats sont GRATUITS pour toi.</i>",
        ]

    v, p = VIP_TIER_BONUSES["vip"], VIP_TIER_BONUSES["premium"]
    body += [
        "",
        "<b>📊 Ce que ça change concrètement :</b>",
        f"  ┃ Revenus        ┃ VIP +{int(v['income_mult']*100-100)}%   ┃ PREMIUM +{int(p['income_mult']*100-100)}%",
        f"  ┃ Cooldowns      ┃ VIP -{int((1-v['cooldown_mult'])*100)}%   ┃ PREMIUM -{int((1-p['cooldown_mult'])*100)}%",
        f"  ┃ Gains casino   ┃ VIP +{int(v['casino_bonus']*100)}%   ┃ PREMIUM +{int(p['casino_bonus']*100)}%",
        f"  ┃ Followers      ┃ VIP +{int(v['social_bonus']*100)}%   ┃ PREMIUM +{int(p['social_bonus']*100)}%",
        f"  ┃ Impôts         ┃ VIP -{int(v['tax_reduction']*100)}%   ┃ PREMIUM -{int(p['tax_reduction']*100)}%",
        "",
        "<i>💡 PREMIUM double quasiment tous les avantages du VIP — idéal si tu joues régulièrement.</i>",
        "",
        "<b>Choisis un abonnement ci-dessous</b> (paiement en ⭐ Étoiles Telegram) :",
    ]

    kb = []
    for key, sub in STARS_SUBSCRIPTIONS.items():
        tag = sub.get("tag", "")
        label = f"{sub['label']} — {sub['stars']} ⭐"
        if tag:
            label += f"  {tag}"
        kb.append([InlineKeyboardButton(label, callback_data=f"starbuy:sub:{key}")])
    kb.append([InlineKeyboardButton("🛒 Voir la boutique en Étoiles", callback_data="star_menu")])

    await update.message.reply_text(
        card("ABONNEMENTS VIP & PREMIUM", body, icon="👑", style="double"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(kb),
    )


def _fmt_date(ts: int) -> str:
    from datetime import datetime
    return datetime.fromtimestamp(ts).strftime("%d/%m/%Y %H:%M")


# ═══════════════════════════════════════════════════════════════════
#                    Menu boutique
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_boutique_etoiles(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from handlers.boutique import cmd_boutique          # la boutique v2 remplace cette vitrine
    return await cmd_boutique(update, context)


async def _legacy_cmd_boutique_etoiles(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _send_star_menu(update.message.reply_text, user_id=update.effective_user.id)


def _cat_price_range(cat_id: int) -> tuple[int, int, int]:
    """Retourne (nb_items, prix_min, prix_max) pour une catégorie."""
    prices = [it["stars"] for k, it in STARS_SHOP.items() if it["cat"] == cat_id and k not in STARS_RETIRED_ITEMS]
    if not prices:
        return 0, 0, 0
    return len(prices), min(prices), max(prices)


async def _send_star_menu(send_func, edit=False, query=None, user_id: int | None = None):
    if user_id is None and query:
        user_id = query.from_user.id

    body = [
        "🛍️ <i>Des avantages concrets, immédiats, pour avancer plus vite.</i>",
        "",
        "🔥 <b>En vedette cette semaine</b>",
    ]

    kb = []
    for iid in STARS_FEATURED_OFFERS:
        it = STARS_SHOP.get(iid)
        if not it or iid in STARS_RETIRED_ITEMS:
            continue
        tag = it.get("tag", "")
        tag_suffix = f" {tag}" if tag else ""
        body.append(f"  ▸ <b>{it['label']}</b> — {it['stars']} ⭐{tag_suffix}")
        if it.get("short_desc"):
            body.append(f"    <i>{it['short_desc']}</i>")
        kb.append([InlineKeyboardButton(
            f"{it['label']} — {it['stars']} ⭐",
            callback_data=f"starbuy:shop:{iid}"
        )])

    body.append("")
    body.append("📂 <b>Ou parcours tout le catalogue :</b>")

    for cat_id, label in STARS_SHOP_CATEGORIES.items():
        count, pmin, pmax = _cat_price_range(cat_id)
        kb.append([InlineKeyboardButton(
            f"{label}  ·  {count} art.  ·  dès {pmin} ⭐",
            callback_data=f"star_cat:{cat_id}"
        )])

    kb.append([InlineKeyboardButton("👑 VIP / Premium", callback_data="star_vip")])
    kb.append([InlineKeyboardButton("❌ Fermer", callback_data="star_close")])

    text = card("BOUTIQUE EN ÉTOILES", body, icon="⭐", style="double",
                footer="Achat 100% sécurisé via Telegram Stars · Effet immédiat")
    markup = InlineKeyboardMarkup(kb)
    if edit and query:
        await query.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
    else:
        await send_func(text, parse_mode="HTML", reply_markup=markup)


async def star_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data

    if data == "star_menu":
        await _send_star_menu(None, edit=True, query=q)
        return

    if data == "star_close":
        await q.message.delete()
        return

    # ⭐ Bouton inactif (item au plafond)
    if data == "star_noop":
        await q.answer("⛔ Déjà au maximum", show_alert=True)
        return

    if data == "star_vip":
        u = await get_user(q.from_user.id)
        v, p = VIP_TIER_BONUSES["vip"], VIP_TIER_BONUSES["premium"]
        body = [
            f"📌 Statut actuel : <b>{status_label(u)}</b>",
            "",
            f"  ┃ Revenus        ┃ VIP +{int(v['income_mult']*100-100)}%   ┃ PREMIUM +{int(p['income_mult']*100-100)}%",
            f"  ┃ Cooldowns      ┃ VIP -{int((1-v['cooldown_mult'])*100)}%   ┃ PREMIUM -{int((1-p['cooldown_mult'])*100)}%",
            f"  ┃ Gains casino   ┃ VIP +{int(v['casino_bonus']*100)}%   ┃ PREMIUM +{int(p['casino_bonus']*100)}%",
            f"  ┃ Followers      ┃ VIP +{int(v['social_bonus']*100)}%   ┃ PREMIUM +{int(p['social_bonus']*100)}%",
            f"  ┃ Impôts         ┃ VIP -{int(v['tax_reduction']*100)}%   ┃ PREMIUM -{int(p['tax_reduction']*100)}%",
        ]
        kb = []
        for key, sub in STARS_SUBSCRIPTIONS.items():
            tag = sub.get("tag", "")
            label = f"{sub['label']} — {sub['stars']} ⭐" + (f"  {tag}" if tag else "")
            kb.append([InlineKeyboardButton(label, callback_data=f"starbuy:sub:{key}")])
        kb.append([InlineKeyboardButton("⬅️ Retour", callback_data="star_menu")])
        await q.edit_message_text(
            card("ABONNEMENTS", body, icon="👑"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(kb),
        )
        return

    if data.startswith("star_cat:"):
        cat_id = int(data.split(":", 1)[1])
        items = [(iid, it) for iid, it in STARS_SHOP.items() if it["cat"] == cat_id and iid not in STARS_RETIRED_ITEMS]
        items.sort(key=lambda pair: pair[1]["stars"])

        body = [
            f"📦 <b>{len(items)} article(s) disponible(s)</b>",
            "<i>Tape sur un article pour l'acheter — effet immédiat après paiement.</i>",
            "",
        ]

        kb = []

        for iid, it in items:
            short = it.get("short_desc", "")
            tag = it.get("tag", "")
            tag_suffix = f"  {tag}" if tag else ""

            # ⭐ Vérifier plafond pour les stacks
            if it.get("type") == "stack":
                current, max_total = await _get_stack_progress(q.from_user.id, iid)
                bar = rich_bar(current, max_total, 8)

                if current >= max_total:
                    kb.append([InlineKeyboardButton(
                        f"✅ {it['label']} — MAX ATTEINT",
                        callback_data="star_noop"
                    )])
                    body.append(f"• <b>{it['label']}</b> ✅ <i>maximum atteint</i>")
                else:
                    kb.append([InlineKeyboardButton(
                        f"{it['label']} — {it['stars']} ⭐ ({current}/{max_total})",
                        callback_data=f"starbuy:shop:{iid}"
                    )])
                    body.append(f"• <b>{it['label']}</b> — {it['stars']} ⭐{tag_suffix}")
                    body.append(f"  <code>{bar}</code> {current}/{max_total}")
                if short:
                    body.append(f"  <i>{short}</i>")
                body.append("")
                continue

            # Item normal
            kb.append([InlineKeyboardButton(
                f"{it['label']} — {it['stars']} ⭐" + (f" {tag}" if tag else ""),
                callback_data=f"starbuy:shop:{iid}"
            )])
            body.append(f"• <b>{it['label']}</b> — {it['stars']} ⭐{tag_suffix}")
            if short:
                body.append(f"  <i>{short}</i>")
            body.append("")

        kb.append([InlineKeyboardButton("⬅️ Retour", callback_data="star_menu")])

        await q.edit_message_text(
            card(STARS_SHOP_CATEGORIES[cat_id], body, icon="⭐"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(kb),
        )
        return


# ═══════════════════════════════════════════════════════════════════
#          Envoi facture / Achat gratuit Lead
#          ⭐ MODIFIÉ : Refus si plafond atteint + descriptions
# ═══════════════════════════════════════════════════════════════════
async def buy_star_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()

    try:
        _, kind, item_id = q.data.split(":", 2)
    except ValueError:
        await q.message.reply_text("❌ Article invalide.")
        return

    if kind == "sub":
        item = STARS_SUBSCRIPTIONS.get(item_id)
    else:
        item = STARS_SHOP.get(item_id)

    if item_id in STARS_RETIRED_ITEMS:
        await q.message.reply_text("❌ Cet article n'est plus en vente.")
        return
    if not item:
        await q.message.reply_text("❌ Article introuvable.")
        return

    # ═══════════════════════════════════════════════════════════════
    #   ⭐ Vérification du plafond AVANT tout traitement
    # ═══════════════════════════════════════════════════════════════
    if kind == "shop":
        can_buy, reason = await _check_stack_available(q.from_user.id, item_id)
        if not can_buy:
            current, max_total = await _get_stack_progress(q.from_user.id, item_id)
            await q.answer(f"⛔ {reason}", show_alert=True)
            await q.message.reply_text(
                alert("warning",
                      f"⛔ <b>Achat refusé</b>\n\n"
                      f"📦 Article : <b>{item['label']}</b>\n"
                      f"📊 Progression : <b>{current}/{max_total}</b>\n\n"
                      f"<i>Tu as déjà atteint le maximum pour cet item.</i>\n"
                      f"<i>Aucun débit effectué.</i>"),
                parse_mode="HTML"
            )

            # Log l'audit du refus
            await log_transaction(
                user_id=q.from_user.id,
                amount=0,
                description=f"[REFUSÉ] {item['label']} - plafond atteint ({current}/{max_total})",
                transaction_type="refused",
                metadata=f"Kind: {kind}, ItemID: {item_id}, Reason: {reason}",
                notify=False,
            )
            return

    # ═══════════════════════════════════════════════════════════════
    #   ACHAT GRATUIT LEADS
    # ═══════════════════════════════════════════════════════════════
    if _is_lead(q.from_user.id):
        ok, remaining = _check_lead_cooldown(q.from_user.id)
        if not ok:
            await q.answer(f"⏳ Attends {remaining}s entre chaque achat.", show_alert=True)
            return

        _mark_lead_purchase(q.from_user.id)
        reference_id = generate_reference(q.from_user.id, prefix="FREE")

        try:
            if kind == "sub":
                result_text = await _apply_subscription(q.from_user.id, item_id)
            else:
                result_text = await _apply_shop_item(q.from_user.id, item_id)
        except ValueError as e:
            await q.message.reply_text(alert("error", f"❌ {e}"), parse_mode="HTML")
            return
        except Exception as e:
            logger.exception("Erreur Lead")
            await q.message.reply_text(alert("error", f"❌ Erreur : {e}"), parse_mode="HTML")
            return

        await log_transaction(
            user_id=q.from_user.id,
            amount=0,
            description=f"[GRATUIT] {item['label']}",
            transaction_type="admin_gift",
            reference_id=reference_id,
            metadata=f"Kind: {kind}, ItemID: {item_id}, Valeur: {item['stars']} ⭐",
            notify=True,
        )

        await q.message.reply_text(
            alert("success",
                  f"🎁 <b>Achat gratuit activé !</b>\n\n"
                  f"📦 {html.escape(result_text)}\n"
                  f"⭐ Valeur : {item['stars']} Étoiles offertes\n"
                  f"🆔 Référence : <code>{reference_id}</code>"),
            parse_mode="HTML",
        )
        return

    # ═══════════════════════════════════════════════════════════════
    #   PAIEMENT NORMAL
    # ═══════════════════════════════════════════════════════════════
    if not await switch_on("real_payments"):       # 💳 coupé par le Lead Principal
        await q.message.reply_text("💳 Les paiements sont momentanément suspendus par la direction. Réessaie plus tard.")
        return
    payload = f"{q.from_user.id}:{kind}:{item_id}"

    await context.bot.send_invoice(
        chat_id=q.message.chat_id,
        title=item["label"],
        description=_describe(kind, item),
        payload=payload,
        provider_token="",
        currency="XTR",
        prices=[LabeledPrice(item["label"], item["stars"])],
    )


def _describe(kind: str, item: dict) -> str:
    """
    ⭐ Retourne la description pour la facture Telegram.
    Priorité : champ 'desc' (détaillé) → fallback générique.
    """
    # ⭐ Utilise la description détaillée de la config si présente
    if item.get("desc"):
        return item["desc"]

    if kind == "sub":
        tier = item["tier"]
        if tier == "premium":
            return f"Abonnement PREMIUM {item['days']} jours : +25% revenus, -30% cooldowns, et bien plus."
        return f"Abonnement VIP {item['days']} jours : +10% revenus, -15% cooldowns, et bien plus."

    t = item["type"]
    if t == "boost":
        return f"Boost actif pendant {item['days']} jours."
    if t == "stack":
        return f"Amélioration permanente (cumulable, max {item['max_stack']}×)."
    if t == "consumable":
        return "Effet appliqué instantanément à ton profil."
    if t == "cosmetic":
        return "Personnalisation cosmétique de ton profil."
    if t == "pack":
        return "Pack combinant plusieurs avantages."
    return item["label"]


async def precheckout_star_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.pre_checkout_query
    if not await switch_on("real_payments"):
        await query.answer(ok=False, error_message="Paiements suspendus par la direction.")
        return
    try:
        user_id_str, kind, item_id = query.invoice_payload.split(":", 2)
        user_id = int(user_id_str)
    except ValueError:
        await query.answer(ok=False, error_message="Facture invalide.")
        return

    catalog = STARS_SUBSCRIPTIONS if kind == "sub" else STARS_SHOP
    item = catalog.get(item_id)
    if item_id in STARS_RETIRED_ITEMS:
        await query.answer(ok=False, error_message="Cet article n'est plus en vente.")
        return
    if not item:
        await query.answer(ok=False, error_message="Article introuvable.")
        return
    if item["stars"] != query.total_amount:
        await query.answer(ok=False, error_message="Montant incorrect.")
        return

    # ⭐ Dernier check : refuser au pre-checkout si plafond atteint
    if kind == "shop":
        can_buy, reason = await _check_stack_available(user_id, item_id)
        if not can_buy:
            await query.answer(
                ok=False,
                error_message=f"⛔ {reason}\nAucun débit effectué."
            )
            return

    await query.answer(ok=True)


# ═══════════════════════════════════════════════════════════════════
#      Paiement confirmé
#      ⭐ MODIFIÉ : rembourse si plafond atteint entre-temps
# ═══════════════════════════════════════════════════════════════════
async def successful_payment_star_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    payment = update.message.successful_payment
    payload = payment.invoice_payload

    try:
        user_id_str, kind, item_id = payload.split(":", 2)
        user_id = int(user_id_str)
    except ValueError:
        logger.error("Payload Stars invalide : %s", payload)
        return

    is_new = await log_star_purchase(
        user_id=user_id, item_id=item_id, stars_amount=payment.total_amount,
        charge_id=payment.telegram_payment_charge_id, payload=payload,
    )
    if not is_new:
        # ✅ Fix #15 : confirmer explicitement au lieu d'ignorer silencieusement
        try:
            await update.message.reply_text(
                alert(
                    "info",
                    "ℹ️ <b>Paiement déjà traité</b>\n\n"
                    "Ce paiement a déjà été appliqué à ton compte.\n"
                    f"🆔 Charge ID : <code>{html.escape(str(payment.telegram_payment_charge_id))}</code>\n\n"
                    "<i>Aucune action supplémentaire n'est nécessaire.</i>"
                ),
                parse_mode="HTML",
            )
        except Exception:
            logger.exception("Impossible de notifier le doublon de paiement")
        return

    catalog = STARS_SUBSCRIPTIONS if kind == "sub" else STARS_SHOP
    item = catalog.get(item_id)
    label = item["label"] if item else item_id

    # ═══════════════════════════════════════════════════════════════
    #   ⭐ Vérifier plafond au moment du paiement
    #   (course possible entre pre-checkout et paiement confirmé)
    # ═══════════════════════════════════════════════════════════════
    if kind == "shop":
        can_buy, reason = await _check_stack_available(user_id, item_id)
        if not can_buy:
            # ⚠️ Le joueur a payé mais le plafond est atteint → REMBOURSER
            refund_success = False
            refund_msg = ""
            try:
                await context.bot.refund_star_payment(
                    user_id=user_id,
                    telegram_payment_charge_id=payment.telegram_payment_charge_id,
                )
                refund_success = True
                refund_msg = "💸 <b>Remboursement automatique effectué.</b>"
            except Exception as e:
                logger.exception("Échec remboursement Stars")
                refund_msg = (
                    f"⚠️ <b>Remboursement manuel requis</b>\n"
                    f"Charge ID : <code>{payment.telegram_payment_charge_id}</code>\n"
                    f"Contacte un admin avec cette référence."
                )

            current, max_total = await _get_stack_progress(user_id, item_id)

            # Log l'audit du remboursement
            await log_transaction(
                user_id=user_id,
                amount=0,
                description=f"[REMBOURSÉ] {label} - plafond atteint ({current}/{max_total})",
                transaction_type="refund",
                metadata=(
                    f"Kind: {kind}, ItemID: {item_id}, "
                    f"Charge: {payment.telegram_payment_charge_id}, "
                    f"Refund: {refund_success}"
                ),
                notify=True,
            )

            await update.message.reply_text(
                alert("warning",
                      f"⚠️ <b>Achat annulé</b>\n\n"
                      f"📦 Article : <b>{label}</b>\n"
                      f"📊 Progression : <b>{current}/{max_total}</b>\n\n"
                      f"<i>Tu avais déjà atteint le maximum pour cet item.</i>\n\n"
                      f"{refund_msg}"),
                parse_mode="HTML"
            )
            return

    # ═══════════════════════════════════════════════════════════════
    #   Application de l'effet
    # ═══════════════════════════════════════════════════════════════
    try:
        if kind == "sub":
            result_text = await _apply_subscription(user_id, item_id)
        else:
            result_text = await _apply_shop_item(user_id, item_id)
    except ValueError as e:
        await update.message.reply_text(alert("error", f"❌ {e}"), parse_mode="HTML")
        return
    except Exception as e:
        logger.exception("Erreur paiement Stars")
        await update.message.reply_text(
            alert("error", f"❌ Erreur : {e}\nContacte un admin avec ta référence."),
            parse_mode="HTML"
        )
        return

    stars_amount = item.get("stars", 0) if item else payment.total_amount

    reference_id = await log_transaction(
        user_id=user_id,
        amount=-stars_amount,
        description=f"Achat : {label}",
        transaction_type="purchase",
        metadata=f"Kind: {kind}, ItemID: {item_id}, Charge: {payment.telegram_payment_charge_id}",
        notify=True,
    )

    await update.message.reply_text(
        alert("success",
              f"Achat confirmé : <b>{html.escape(result_text)}</b>\n"
              f"🧾 Transaction Telegram : <code>{payment.telegram_payment_charge_id}</code>\n"
              f"🆔 Référence : <code>{reference_id}</code>\n\n"
              f"<i>Conserve ta référence pour tout remboursement éventuel.</i>"),
        parse_mode="HTML",
    )


# ═══════════════════════════════════════════════════════════════════
#      Application des effets
# ═══════════════════════════════════════════════════════════════════
async def _apply_subscription(user_id: int, item_id: str) -> str:
    sub = STARS_SUBSCRIPTIONS[item_id]
    new_until = await grant_subscription(user_id, sub["tier"], sub["days"])
    return f"{sub['label']} activé jusqu'au {_fmt_date(new_until)}"


async def _apply_shop_item(user_id: int, item_id: str) -> str:
    item = STARS_SHOP[item_id]
    t = item["type"]

    if t == "boost":
        await extend_boost(user_id, item["field"], item["days"])
        return f"{item['label']} activé pour {item['days']} jours"

    if t == "stack":
        max_total = item["amount"] * item["max_stack"]
        total = await add_stack(user_id, item["field"], item["amount"], max_total)
        return f"{item['label']} (total cumulé : {total}/{max_total})"

    if t == "consumable":
        await _apply_consumable(user_id, item)
        return item["label"]

    if t == "cosmetic":
        await update_field(user_id, item["field"], item["value"])
        return item["label"]

    if t == "pack":
        await _apply_pack(user_id, item["effect"])
        return item["label"]

    return item["label"]


async def _apply_consumable(user_id: int, item: dict):
    effect = item["effect"]

    if effect == "heal_full":
        await update_field(user_id, "health", 100)
    elif effect == "energy_full":
        await update_field(user_id, "energy", 100)
    elif effect == "happiness_full":
        await update_field(user_id, "happiness", 100)
    elif effect == "stress_zero":
        await update_field(user_id, "stress", 0)
    elif effect == "xp":
        await increment_field(user_id, "xp", item["amount"])
    elif effect == "coins":
        await update_balance(user_id, item["amount"])
    elif effect == "prestige":
        await increment_field(user_id, "prestige", item["amount"])
    elif effect == "lottery_ticket":
        await _give_lottery_ticket(user_id)
    elif effect == "prison_clear":
        await _clear_prison(user_id)
    elif effect == "diplome_skip":
        await _skip_study_time(user_id)
    else:
        raise ValueError(f"Effet inconnu : {effect}")


async def _clear_prison(user_id: int):
    """🔓 Libère immédiatement le joueur s'il est en prison."""
    u = await get_user(user_id)
    if u.get("prison_until", 0) <= now():
        raise ValueError("Tu n'es pas en prison, rien à débloquer.")
    await update_field(user_id, "prison_until", 0)


async def _skip_study_time(user_id: int):
    """⏩ Fait passer le temps d'étude restant à zéro (si une formation est en cours)."""
    from config import DIPLOME_STUDY_TIME, DIPLOME_STUDY_TIME_EXTENDED
    all_times = {**DIPLOME_STUDY_TIME, **DIPLOME_STUDY_TIME_EXTENDED}

    u = await get_user(user_id)
    dip = u.get("study_diplome")
    start = u.get("study_start", 0)
    if not dip or start <= 0:
        raise ValueError("Aucune formation en cours : inscris-toi d'abord avec /etudier.")

    duration = all_times.get(dip, 0)
    remaining = (start + duration) - now()
    if remaining <= 0:
        raise ValueError("Ta formation est déjà terminée : tape sur Passer l'examen.")

    await update_field(user_id, "study_start", now() - duration)


async def _give_lottery_ticket(user_id: int):
    """⭐ Crée 1 ticket de loterie (fix exploit : ne donne plus le jackpot)."""
    async with db_connection() as db:
        async with db.execute(
            "SELECT draw_id, jackpot FROM lottery_draws WHERE drawn_at=0 "
            "ORDER BY draw_id DESC LIMIT 1"
        ) as cur:
            row = await cur.fetchone()

        if not row:
            from config import LOTTERY_JACKPOT_BASE
            cur = await db.execute(
                "INSERT INTO lottery_draws (jackpot, drawn_at) VALUES (?, 0)",
                (LOTTERY_JACKPOT_BASE,)
            )
            draw_id = cur.lastrowid
        else:
            draw_id = row[0]

        nums = "-".join(map(str, sorted(random.sample(range(1, 50), 5))))
        await db.execute(
            "INSERT INTO lottery_tickets (user_id, draw_id, numbers, purchased_at) "
            "VALUES (?,?,?,?)",
            (user_id, draw_id, nums, now())
        )

        # ⭐ Bonus jackpot : +5 000 (contribution, pas le jackpot entier)
        await db.execute(
            "UPDATE lottery_draws SET jackpot = jackpot + ? WHERE draw_id=?",
            (5_000, draw_id)
        )
        await db.commit()


async def _apply_pack(user_id: int, pack: str):
    """⭐ Applique un pack combiné (boosts + coins + abonnement + prestige)."""
    if pack == "pack_starter":
        # 100K coins + soin complet + 500 XP
        await update_balance(user_id, 100_000)
        await update_field(user_id, "health", 100)
        await update_field(user_id, "energy", 100)
        await update_field(user_id, "happiness", 100)
        await increment_field(user_id, "xp", 500)

    elif pack == "pack_decouverte":
        # 3 boosts 7j + 50K coins
        for field in ("boost_xp2_until", "boost_coins2_until", "boost_chance_until"):
            await extend_boost(user_id, field, 7)
        await update_balance(user_id, 50_000)

    elif pack == "pack_entrepreneur":
        # Boost Coins x2 (7j) + 600K coins
        await extend_boost(user_id, "boost_coins2_until", 7)
        await update_balance(user_id, 600_000)

    elif pack == "pack_prestige":
        # Premium 30j + 5 000 Prestige + titre exclusif
        await grant_subscription(user_id, "premium", 30)
        await increment_field(user_id, "prestige", 5_000)
        await update_field(user_id, "profile_title", "👑 Prestige")

    elif pack == "pack_ultime":
        # Premium 90j + boosts de confort 90j (les x2 XP / €A ne sont plus vendus)
        await grant_subscription(user_id, "premium", 90)
        for field in ("boost_chance_until", "boost_jardin_until", "boost_vitesse_until"):
            await extend_boost(user_id, field, 90)

    else:
        raise ValueError(f"Pack inconnu : {pack}")