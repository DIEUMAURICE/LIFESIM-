# handlers/work.py — le travail en RP : le MÉTIER (petit métier freelance) + promotions.
"""
• Travailler : ne concerne QUE le métier choisi (menu Carrière → Mon métier).
   Mission = un mini-jeu, rémunération immédiate (score 0–3), UN SEUL essai, repos de 1 h DE JEU avant de reprendre.
   Les salariés d'entreprise et de faction n'ont plus rien à lancer : leur salaire est versé
   automatiquement et leurs points d'activité (promotions, production) s'ajoutent tout seuls
   chaque jour de jeu (voir utils/payroll.py).
• Mon métier : métier actuel + boutons « Changer de métier » et « Arrêter mon métier ».
• Promotion : promotion par compétences.
"""
from utils.swallow import swallowed
from utils.gamerules import faucet
import logging
import random

import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from config import (
    GOV_FACTIONS, WORK_COOLDOWN, SHIFT_ENERGY, SHIFT_BASE_XP,
    COMPANY_RANKS, COMPANY_SALARY_MAP, SMALL_JOBS, ACTIVITY_MINUTES_PER_POINT, DUTY_MAX_SECONDS,
)
from database import (
    get_user, update_field, update_balance, get_user_company,
    db_connection, now,
)
from handlers.missions import update_mission_progress
from utils.company_roles import can_manage, get_role
from utils.cooldowns import claim_cooldown, release_cooldown
from utils.decorators import require_registered, require_free, _reply, get_user_role_async
from utils.factions import (
    get_membership, try_auto_promotion, company_promotion_check, rank_name,
)
from utils.helpers import fmt, fmt_time
from utils.location import is_exempt, presence_error, location_label
from utils.notify import notify
from utils.simulation import compute_condition_penalties
from utils.vip import add_xp, xp_boost_multiplier, effective_cooldown
from utils import minigames

logger = logging.getLogger(__name__)


# ═════════════════════════════════════════════════════════════════════════
#  Lecture de l'employeur / du petit métier
# ═════════════════════════════════════════════════════════════════════════
async def get_workplace(user_id: int) -> dict | None:
    """{'kind': 'faction'|'company', 'place': lieu RP, 'label', 'rank_idx', 'poste', 'salary', ...}"""
    fm = await get_membership(user_id)
    if fm:
        f = GOV_FACTIONS[fm["faction"]]
        place = f["location"]
        if fm["faction"] == "sante":
            from utils.sante import workplace_location
            place = await workplace_location(user_id)      # l'hôpital auquel l'employé est affecté
        elif fm["faction"] in ("police", "armee", "justice"):
            from utils.ordre import workplace_location
            place = await workplace_location(user_id)      # le poste / la caserne d'affectation
        return {
            "kind": "faction", "place": place, "label": f"{f['emoji']} {f['name']}",
            "rank_idx": fm["rank"], "poste": fm["rank_name"], "salary": fm["salary"],
            "activity": fm["activity_score"], "faction": fm["faction"],
        }
    c = await get_user_company(user_id)
    if c:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            async with db.execute(
                "SELECT poste, base_salary, activity_score FROM company_members "
                "WHERE user_id=? AND company_id=?", (user_id, c["company_id"])) as cur:
                row = await cur.fetchone()
        role = await get_role(user_id, c)
        return {
            "kind": "company", "place": "travail",
            "label": f"🏢 {c['name']}",
            "rank_idx": COMPANY_RANKS.index(row["poste"]) if row and row["poste"] in COMPANY_RANKS else 2,
            "poste": row["poste"] if row else "Employé",
            "salary": (row["base_salary"] if row else 0) or 0,
            "activity": (row["activity_score"] if row else 0) or 0,
            "company": c, "role": role,
        }
    return None


async def get_small_job(user_id: int) -> dict | None:
    """Retourne {'name', 'category', 'emoji', 'min', 'max', 'xp', 'need'} ou None."""
    u = await get_user(user_id)
    name = u.get("job", "") or ""
    if name in SMALL_JOBS:
        return {"name": name, **SMALL_JOBS[name]}
    return None


NO_JOB_TEXT = (
    "💼 Tu n'as pas de métier.\n"
    "🛠️ Choisis-en un : menu Carrière → Mon métier → « Choisir un métier »."
)

DIP_ORDER = ["", "Brevet", "Bac", "BTS", "Licence", "Master", "MBA", "Doctorat", "Habilitation"]


def _dip_rank(dip: str) -> int:
    return DIP_ORDER.index(dip) if dip in DIP_ORDER else 0


# ═════════════════════════════════════════════════════════════════════════
#  /travailler — point d'entrée
# ═════════════════════════════════════════════════════════════════════════
KEY_SHIFT = "work_last"        # service au poste (entreprise / faction)
KEY_SMALL = "freelance_last"   # petit métier freelance
_TIRED = {
    KEY_SHIFT: "⏳ Tu es fatigué(e) ! Repos nécessaire avant ton prochain service au poste.",
    KEY_SMALL: "⏳ Tu es fatigué(e) ! Repos nécessaire avant ta prochaine mission freelance.",
}


async def _claim_work(user_id: int, u: dict, key: str, mult: float = 1.0) -> tuple[bool, str]:
    """Réserve le cooldown de la voie choisie (admins et god mode exemptés). `mult` : grande commande = repos plus long."""
    if await get_user_role_async(user_id) != "PLAYER" or u.get("god_mode"):
        return True, ""
    ok, remaining = await claim_cooldown(user_id, key, int(effective_cooldown(u, WORK_COOLDOWN, work=True) * mult))
    if ok:
        return True, ""
    return False, f"{_TIRED[key]}\n🕐 Encore <b>{fmt_time(remaining)}</b>."


def _vital_problem(u: dict) -> str | None:
    if u.get("energy", 100) < 20:
        return "😴 Tu es épuisé(e) ! Dors un peu avant de retravailler (menu Vie → Dormir)."
    if u.get("hunger", 100) < 12:
        return "🍽️ Tu es trop affamé(e) pour travailler. Mange d'abord (menu Vie → Manger)."
    if u.get("health", 100) < 15:
        return "🏥 Ton état est trop critique pour travailler. Va te soigner (menu Vie → Hôpital)."
    return None


@require_registered
@require_free
async def cmd_travailler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _start_work(update, context, update.effective_user, choice="small")


@require_registered
async def cmd_grande_commande(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _start_work(update, context, update.effective_user, choice="small", big=True)


async def _start_work(update, context, user, choice: str | None = "small", big: bool = False):
    """Travailler = une mission de ton MÉTIER. (Entreprise et faction : salaire et activité automatiques.)"""
    u = await get_user(user.id)

    problem = _vital_problem(u)
    if problem:
        await _reply(update, problem)
        return

    small = await get_small_job(user.id)
    if not small:
        await _reply(update, NO_JOB_TEXT)
        return
    await _do_freelance(update, context, user, u, small, big=big)


async def work_pick_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Anciens boutons « service au poste / petit métier » encore présents dans d'anciens messages :
    ils lancent désormais simplement la mission du métier."""
    q = update.callback_query
    data = q.data or ""
    parts = data.split("_")          # work_pick_<shift|small>_<user_id>
    try:
        owner = int(parts[3])
    except (IndexError, ValueError):
        await q.answer()
        return
    if q.from_user.id != owner:
        await q.answer("Ce menu n'est pas le tien.", show_alert=True)
        return
    await q.answer()
    try:
        await q.edit_message_reply_markup(reply_markup=None)
    except Exception:
        swallowed('handlers/work.py')
    await _guarded_start(update, context, q.from_user, "small")


@require_registered
@require_free
async def _guarded_start(update, context, user, choice):
    await _start_work(update, context, user, choice)


# ═════════════════════════════════════════════════════════════════════════
#  Freelance — lance un mini-jeu
# ═════════════════════════════════════════════════════════════════════════
_WORK_PREPARATIONS = {}               # contexte métier partagé jusqu'à la fin du mini-jeu


async def _do_freelance(update, context, user, u, small: dict, big: bool = False):
    from gameplay import work as work_gameplay

    starter = minigames.STARTERS.get(small["category"])
    if not starter:
        await _reply(update, f"⏳ Mini-jeu <b>{small['category']}</b> pas encore disponible.", parse_mode="HTML")
        return
    try:
        preparation = await work_gameplay.prepare(user.id, big=big)
    except work_gameplay.WorkError as exc:
        await _reply(update, exc.message, parse_mode="HTML")
        return

    try:
        _WORK_PREPARATIONS[user.id] = preparation
        tag = " — 📦 GRANDE COMMANDE" if big else ""
        sent = await update.effective_message.reply_text(
            f"💼 <b>{small.get('emoji','🛠️')} {small['name']}</b>{tag}\n\n"
            f"⏳ Préparation de ta journée…", parse_mode="HTML")
        await starter(minigames._make_query(sent), user.id, preparation.base_gain, attempt=1)
    except Exception:
        _WORK_PREPARATIONS.pop(user.id, None)
        await release_cooldown(user.id, KEY_SMALL)
        raise


# ═════════════════════════════════════════════════════════════════════════
#  Callback appelé par minigames._finalize
# ═════════════════════════════════════════════════════════════════════════
async def on_minigame_done(query, user_id: int, score: int, gain: int,
                           game_title: str, attempt: int, bonus_note: str = ""):
    """Applique le gain + XP + énergie. Un seul essai : le résultat est définitif."""
    from gameplay import work as work_gameplay

    preparation = _WORK_PREPARATIONS.pop(user_id, None)
    if preparation is None:
        # Compatibilité avec les anciens messages/callbacks déjà envoyés avant la
        # centralisation : on reconstruit uniquement le contexte, puis on délègue
        # toujours toute la mutation au service commun.
        u = await get_user(user_id)
        job = u.get("job", "") or ""
        if job not in SMALL_JOBS:
            await query.edit_message_text("⌛ Session de travail expirée.")
            return
        prog = await work_gameplay.get_job_progress(user_id, job)
        divisor = work_gameplay.SCORE_MULT.get(max(0, min(3, score)), 1.0) or 1.0
        preparation = work_gameplay.WorkPreparation(
            user_id=user_id,
            job_name=job,
            rank=prog["rank"],
            big=False,
            base_gain=int(gain / divisor),
            cooldown_seconds=int(effective_cooldown(u, WORK_COOLDOWN, work=True)),
        )
    result = await work_gameplay.resolve(preparation, score)
    chain_note = ""
    if result["goods"]:
        chain_note = f"\n📦 Livré à ton stock : <b>{result['goods']['units']}</b> × {result['goods']['label']}"
    if result["promotion_available"]:
        chain_note += "\n🎖️ <b>Promotion disponible !</b> (Carrière → Promotion)"
    label = minigames.SCORE_LABEL[score]
    minigames.clear(user_id)
    try:
        await query.edit_message_text(
            f"{game_title}\n\n{label}{bonus_note}\n\n"
            f"💰 Gain : <b>+{result['gain']:,} €A</b>{chain_note}\n"
            f"✨ +{result['xp']} XP · ⚡ -{result['energy_cost']}% énergie",
            parse_mode="HTML",
        )
    except Exception:
        swallowed('handlers/work.py')


# ═════════════════════════════════════════════════════════════════════════
#  Mon métier — voir, changer, arrêter (tout en boutons)
# ═════════════════════════════════════════════════════════════════════════
async def build_metier_view(user_id: int) -> tuple[str, InlineKeyboardMarkup]:
    """Texte + boutons de l'écran « Mon métier » (utilisé par le menu ET par les boutons de retour)."""
    wp = await get_workplace(user_id)
    small = await get_small_job(user_id)

    lines = ["💼 <b>MON MÉTIER</b>", ""]
    rows: list[list[InlineKeyboardButton]] = []

    if small:
        from utils import chain as _chain
        from config_chain import job_rank_name, job_rank_mult, GRANDE_COMMANDE_RANK, INTRANTS, JOB_GOOD
        prog = await _chain.get_job_progress(user_id, small["name"])
        rm = job_rank_mult(prog["rank"])
        lines += [
            f"{small.get('emoji', '🛠️')} Métier actuel : <b>{small['name']}</b> — 🎖️ <b>{job_rank_name(prog['rank'])}</b> "
            f"({prog['missions']} missions)",
            f"📈 Rang : gains ×{rm['pay']} · biens ×{rm['goods']} · effort ×{rm['energy']}",
            f"💰 Gains par mission : <b>{fmt(small['min'])}</b> – <b>{fmt(small['max'])}</b> (mini-jeu)",
            f"✨ {small['xp']} XP par mission · catégorie <b>{small['category']}</b>",
        ]
        if small.get("need"):
            lines.append(f"🎓 Diplôme requis : <b>{small['need']}</b>")
        gk = JOB_GOOD.get(small["name"])
        if gk:
            lines.append(f"📦 Tu fournis : {INTRANTS[gk]['emoji']} <b>{INTRANTS[gk]['name']}</b> (vendu aux entreprises)")
        rows.append([InlineKeyboardButton("💼 Travailler maintenant", callback_data="metier_work")])
        if prog["rank"] >= GRANDE_COMMANDE_RANK:
            rows.append([InlineKeyboardButton("📦 Grande commande (gros gains, repos ×3)", callback_data="metier_big")])
        rows.append([InlineKeyboardButton("🎖️ Promotion du métier", callback_data="ch:promo"),
                     InlineKeyboardButton("📦 Mes biens", callback_data="ch:goods")])
        rows.append([InlineKeyboardButton("🔄 Changer de métier", callback_data="eco_metier"),
                     InlineKeyboardButton("🛑 Arrêter mon métier", callback_data="metier_quit")])
    else:
        lines += ["🛠️ Tu n'as pas de métier pour le moment.",
                  "Choisis-en un pour pouvoir travailler."]
        rows.append([InlineKeyboardButton("🛠️ Choisir un métier", callback_data="eco_metier")])

    if wp:
        from utils.duty import get_duty_since, points_for
        since = await get_duty_since(user_id)
        lines += [
            "",
            f"🏢 <b>Employeur</b> : {wp['label']}",
            f"👔 Poste : <b>{wp['poste']}</b>",
            f"💰 Salaire : <b>{fmt(wp['salary'])}</b> (versé automatiquement)",
            f"📈 Activité : <b>{wp['activity']}</b> (gagnée en restant en service)",
            f"📍 Lieu de travail : <b>{location_label(wp['place'])}</b>",
        ]
        if since is not None:
            mins = int((now() - since) // 60)
            lines.append(f"🟢 <b>EN SERVICE</b> depuis {mins} min · +{points_for(now() - since)} activité en cours")
            rows.append([InlineKeyboardButton("⚪ Quitter mon service", callback_data="metier_duty_off")])
        else:
            lines.append(f"⚪ Hors service · 1 activité toutes les {ACTIVITY_MINUTES_PER_POINT} min en service")
            rows.append([InlineKeyboardButton("🟢 Prendre mon service", callback_data="metier_duty_on")])
        quit_label = "🚪 Quitter ma faction" if wp["kind"] == "faction" else "🚪 Démissionner de l'entreprise"
        rows.append([InlineKeyboardButton(quit_label, callback_data="metier_leave")])

    rows.append([InlineKeyboardButton("⬅️ Retour", callback_data="hub:carriere:0"),
                 InlineKeyboardButton("🎮 Menu principal", callback_data="hub:home")])
    return "\n".join(lines), InlineKeyboardMarkup(rows)


@require_registered
async def cmd_metier(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text, markup = await build_metier_view(update.effective_user.id)
    await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


async def toggle_duty(user_id: int, on: bool) -> str:
    """Prend / quitte le service. Le temps de jeu passé en service devient de l'activité (promotions, production)."""
    from utils.duty import start_duty, stop_duty, credit_activity
    wp = await get_workplace(user_id)
    if not wp:
        return "🏢 Tu n'as ni entreprise ni faction : il n'y a pas de service à prendre."
    if on:
        from utils.location import is_exempt, get_position
        if not await is_exempt(user_id):
            pos = await get_position(user_id)
            if pos["in_transit"] or pos["location"] != wp["place"]:
                return f"📍 Pour prendre ton service, rends-toi à <b>{location_label(wp['place'])}</b>."
        if wp.get("faction") == "sante":                 # les soignants reçoivent aussi les appels
            from utils.sante import set_duty
            await set_duty(user_id, True)
        if wp.get("faction") in ("police", "armee", "justice"):      # les agents reçoivent aussi les alertes
            from utils.ordre import set_duty as ordre_duty
            await ordre_duty(user_id, True)
        if not await start_duty(user_id):
            return "🟢 Tu es déjà en service."
        return (f"🟢 <b>Tu es en service !</b>\nChaque tranche de {ACTIVITY_MINUTES_PER_POINT} min de jeu "
                f"te rapporte 1 point d'activité (max {DUTY_MAX_SECONDS // 3600} h par service).")
    if wp.get("faction") == "sante":
        from utils.sante import set_duty
        await set_duty(user_id, False)
    if wp.get("faction") in ("police", "armee", "justice"):
        from utils.ordre import set_duty as ordre_duty
        await ordre_duty(user_id, False)
    was_on, elapsed, pts = await stop_duty(user_id)
    if not was_on:
        return "⚪ Tu n'étais pas en service."
    company_id = wp["company"]["company_id"] if wp["kind"] == "company" else None
    await credit_activity(user_id, wp["kind"], company_id, pts)
    return (f"⚪ <b>Service terminé</b> · {int(elapsed // 60)} min de jeu\n"
            f"📈 Activité gagnée : <b>+{pts}</b>")


async def quit_small_job(user_id: int) -> str | None:
    """Arrête le métier du joueur. Retourne le nom du métier quitté (None s'il n'en avait pas)."""
    small = await get_small_job(user_id)
    if not small:
        return None
    await update_field(user_id, "job", "")
    return small["name"]


# ═════════════════════════════════════════════════════════════════════════
#  /promotion — inchangé (compétences + activité)
# ═════════════════════════════════════════════════════════════════════════
@require_registered
@require_free
async def cmd_promotion(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Promotion : celle de ton MÉTIER (rangs), avec accès à la promotion de ton poste en entreprise/faction."""
    user = update.effective_user
    if await get_small_job(user.id):
        from handlers.chain import promo_view
        text, markup = await promo_view(user.id)
        await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)
        return
    await cmd_promotion_poste(update, context)


async def cmd_promotion_poste(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    wp = await get_workplace(user.id)
    if not wp:
        await _reply(update, "💼 Tu n'es dans aucune entreprise ni faction : pas de promotion possible.\n"
                             "🏢 Rejoins une entreprise (menu Entreprises) ou une faction (menu État & factions → Rejoindre une faction).")
        return

    if wp["kind"] == "faction":
        ok, info = await try_auto_promotion(user.id)
        await _reply(update, (f"🎉 Promu(e) <b>{info}</b> !" if ok else f"🔒 {info}"),
                     parse_mode="HTML")
        return

    company = wp["company"]
    target, req, missing, poste = await company_promotion_check(user.id, company["company_id"])
    if missing:
        await _reply(
            update,
            f"🔒 Prochain poste : <b>{COMPANY_RANKS[min(target, len(COMPANY_RANKS)-1)]}</b>\n"
            f"Il te manque : {', '.join(missing)}\n💡 Progresse via le menu Carrière (compétences, études).",
            parse_mode="HTML",
        )
        return

    async with db_connection() as db:
        cur = await db.execute(
            "INSERT OR IGNORE INTO promotion_requests(user_id, company_id, status, created_at) "
            "VALUES (?,?, 'pending', ?)", (user.id, company["company_id"], now()))
        await db.commit()
        async with db.execute(
            "SELECT user_id FROM company_members WHERE company_id=? AND role IN ('owner','manager')",
            (company["company_id"],)) as c:
            bosses = {r[0] for r in await c.fetchall()} | {company["owner_id"]}

    if not cur.rowcount:
        await _reply(update, "⏳ Ta demande de promotion est déjà en attente.")
        return

    nxt = COMPANY_RANKS[target]
    for b in bosses:
        await notify(
            b, "📈 Demande de promotion",
            f"{user.full_name} remplit les conditions pour devenir <b>{nxt}</b>. "
            f"Tu peux le promouvoir depuis le menu Entreprises → Équipe & recrutement → Promouvoir un employé.", "info",
        )
    await _reply(
        update,
        f"📨 Compétences validées ! Demande envoyée à la direction (poste visé : <b>{nxt}</b>).",
        parse_mode="HTML",
    )


# ═════════════════════════════════════════════════════════════════════════
#  /promouvoir — validation par la direction (inchangé)
# ═════════════════════════════════════════════════════════════════════════
@require_registered
@require_free
async def cmd_promouvoir(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        # Direction de la Santé publique (DG / PDG) : la promotion passe par « Poste santé », pas par une entreprise
        from utils import sante as _sante
        from config import SANTE_HEAD_LEVEL
        st = await _sante.get_staff(user.id)
        if st and st["level"] >= SANTE_HEAD_LEVEL and update.message:
            await update.message.reply_text(
                "🏥 Tu diriges la Santé publique : tes employés se promeuvent avec « Poste santé ».",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🩺 Promouvoir un employé de la santé", callback_data="fm:a_sante_poste")]]))
            return
        await _reply(update, "❌ Réservé à la direction de l'entreprise.")
        return
    if not update.message or not update.message.reply_to_message:
        await _reply(update, "❌ Choisis l'employé à promouvoir depuis le menu Entreprises → Équipe & recrutement → Promouvoir un employé.")
        return
    target = update.message.reply_to_message.from_user
    if target.id == user.id:
        await _reply(update, "❌ Tu ne peux pas te promouvoir toi-même.")
        return
    tm = await get_user_company(target.id)
    if not tm or tm["company_id"] != company["company_id"]:
        await _reply(update, "❌ Cette personne ne travaille pas chez toi.")
        return

    rank_idx, req, missing, poste = await company_promotion_check(target.id, company["company_id"])
    if missing:
        await _reply(update, f"🔒 Conditions non remplies : {', '.join(missing)}")
        return

    new_poste = COMPANY_RANKS[rank_idx]
    floor = COMPANY_SALARY_MAP.get(new_poste, 0)

    async with db_connection() as db:
        async with db.execute(
            "SELECT base_salary FROM company_members WHERE user_id=? AND company_id=?",
            (target.id, company["company_id"])) as c:
            cur_salary = (await c.fetchone())[0] or 0
        new_salary = max(cur_salary, floor)
        await db.execute(
            "UPDATE company_members SET poste=?, base_salary=? WHERE user_id=? AND company_id=?",
            (new_poste, new_salary, target.id, company["company_id"]))
        await db.execute(
            "UPDATE promotion_requests SET status='accepted' "
            "WHERE user_id=? AND company_id=? AND status='pending'",
            (target.id, company["company_id"]))
        await db.commit()

    await notify(
        target.id, "🎉 Promotion",
        f"<b>{company['name']}</b> te promeut <b>{new_poste}</b> ! "
        f"Salaire : <b>{fmt(new_salary)}</b>/jour.", "achievement")
    await _reply(
        update,
        f"✅ {target.full_name} est promu(e) <b>{new_poste}</b> ({fmt(new_salary)}/jour).",
        parse_mode="HTML",
    )


async def run_duty_tick() -> None:
    """Tâche planifiée (toutes les 10 min de jeu) : crédite l'activité des joueurs en service au fil de l'eau,
    pour que leur entreprise produise à chaque heure de jeu sans attendre la fin du service.
    Un service qui atteint la durée maximale se termine tout seul (le joueur est prévenu)."""
    from config import DUTY_MAX_SECONDS
    from utils import duty
    from utils.notify import notify
    for uid, since, credited in await duty.running():
        try:
            elapsed = max(0.0, now() - since)
            total = duty.points_for(elapsed)
            wp = await get_workplace(uid)
            if not wp:
                await duty.stop_duty(uid)
                continue
            if total > credited:
                await duty.mark_credited(uid, total)
                company_id = wp["company"]["company_id"] if wp["kind"] == "company" else None
                await duty.credit_activity(uid, wp["kind"], company_id, total - credited)
            if elapsed >= DUTY_MAX_SECONDS:
                await toggle_duty(uid, False)
                await notify(uid, "🟡 Service terminé",
                             f"Tes {DUTY_MAX_SECONDS // 3600} h de service sont écoulées : l'activité est bien enregistrée. "
                             "Reprends ton service (🎮 Menu → 🎓 Carrière → Mon métier) pour continuer à produire.", "info")
        except Exception:
            logger.exception("Tick de service : erreur pour %s", uid)
