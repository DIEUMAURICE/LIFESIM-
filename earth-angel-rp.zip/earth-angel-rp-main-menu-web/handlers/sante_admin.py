# handlers/sante_admin.py — contrôle de la Santé publique par le staff (Game Leader, admins)
"""
/nommer_pdg      (Game Leader et plus) : nomme le PDG du grand hôpital
/revoquer_pdg    (Game Leader et plus) : révoque le PDG actuel (poste vacant)
/sante_audit     (Admin N2+)           : journal des actions (enquêtes anti-triche)
/sante_lits      (Admin N2+)           : occupation des lits, libération forcée
Les admins agissent aussi via /nommer_dg, /sante_poste et /sante_renvoyer (handlers/sante.py) sans
condition de poste, pour retirer quelqu'un ou résoudre une situation.
"""
import html

import aiosqlite
from telegram import Update
from telegram.ext import ContextTypes

from handlers.sante import _target, _find_user, _norm, _parse_hospital
from database import db_connection
from utils import sante
from utils.decorators import admin_n2_only, game_leader_only


async def _can_direct_sante(update: Update) -> bool:
    """Game Leader et plus, ou Ministre de la Santé."""
    from utils.decorators import get_user_role_async
    from utils.roles import can_direct_faction
    uid = update.effective_user.id
    if await can_direct_faction(uid, "sante", await get_user_role_async(uid)):
        return True
    await update.effective_message.reply_text("❌ Réservé au Ministre de la Santé et au Game Leader (ou plus).")
    return False


async def cmd_nommer_pdg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/nommer_pdg [@joueur] — le Ministre de la Santé (ou le Game Leader) nomme le PDG du grand hôpital."""
    if not await _can_direct_sante(update):
        return
    tgt = await _target(update, context, 0)
    if not tgt:
        await update.message.reply_text("Usage : /nommer_pdg @pseudo (mentionne le joueur) ou réponds à son message avec /nommer_pdg")
        return
    ok, msg = await sante.appoint_pdg(update.effective_user.id, tgt[0])
    await update.message.reply_text(("✅ " if ok else "❌ ") + f"{html.escape(tgt[1])} : {msg}", parse_mode="HTML")


async def cmd_revoquer_pdg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/revoquer_pdg [motif] — le Ministre de la Santé (ou le Game Leader) révoque le PDG actuel du grand hôpital."""
    if not await _can_direct_sante(update):
        return
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT user_id FROM sante_staff WHERE post='pdg'") as cur:
            row = await cur.fetchone()
    if not row:
        await update.message.reply_text("❌ Il n'y a pas de PDG en poste.")
        return
    reason = " ".join(context.args or []) or "révocation par la direction du jeu"
    ok, msg = await sante.dismiss(update.effective_user.id, row["user_id"], is_admin=True, reason=reason)
    if ok:
        msg += " Le poste de PDG est vacant : /nommer_pdg @joueur pour en nommer un nouveau."
    await update.message.reply_text(("✅ " if ok else "❌ ") + msg)


@admin_n2_only
async def cmd_sante_audit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/sante_audit [@joueur|id] [nombre] — journal des actions de la santé (enquête anti-triche)."""
    args = list(context.args or [])
    limit, target = 25, 0
    for a in args:
        if a.isdigit() and int(a) <= 60:
            limit = int(a)
        else:
            row = await _find_user(a)
            if row:
                target = row["user_id"]
    rows = await sante.audit(limit, target)
    if not rows:
        await update.message.reply_text("Journal vide.")
        return
    from utils.gametime import fmt_game_datetime as fgd
    lines = ["🧾 <b>Audit Santé publique</b>"]
    for r in rows:
        lines.append(f"{fgd(r['ts'])} · <code>{r['actor_id']}</code> {r['action']}"
                     + (f" → <code>{r['target_id']}</code>" if r["target_id"] else "")
                     + (f" · {html.escape(r['details'])}" if r["details"] else ""))
    await update.message.reply_text("\n".join(lines)[:4000], parse_mode="HTML")


@admin_n2_only
async def cmd_sante_lits(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/sante_lits — occupation des lits · /sante_lits liberer <hôpital|@joueur|id> — libère de force."""
    args = list(context.args or [])
    if args and _norm(args[0]) in ("liberer", "libere", "free") and len(args) > 1:
        hid = _parse_hospital(args[1])
        row = None if hid else await _find_user(args[1])
        if not hid and not row:
            await update.message.reply_text("❌ Hôpital ou joueur introuvable.")
            return
        n = await sante.free_beds(user_id=row["user_id"] if row else None, hospital_id=hid)
        await sante.log_event(update.effective_user.id, "admin_liberer_lits", row["user_id"] if row else 0, args[1])
        await update.message.reply_text(f"🛏️ {n} lit(s) libéré(s).")
        return
    lines = ["🛏️ <b>Lits</b>"]
    for h in await sante.hospital_overview():
        lines.append(f"{h['name']} : {h['beds_used']}/{h['beds_cap']}")
    lines.append("\n<code>/sante_lits liberer &lt;hôpital|@joueur&gt;</code>")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


# ─────────────────────────────────────────────────────────────────────────────
#  Aide staff « Santé publique » (partagée par /admin_help et /admin)
# ─────────────────────────────────────────────────────────────────────────────
SANTE_HELP_N2 = [
    "<b>🏥 SANTÉ PUBLIQUE (Admin N2+)</b>",
    "  <i>Hôpitaux : 1=Résidences · 2=Affaires · 3=Sud · 4=Aéroport (ou leur nom). Joueur = @pseudo ou id.</i>",
    "  /sante_audit [@joueur|id] [nombre] — journal anti-triche (25 actions par défaut, 60 max)",
    "  /sante_lits — occupation des lits",
    "  /sante_lits liberer &lt;hôpital|@joueur|id&gt; — libère les lits de force",
    "  /nommer_dg &lt;hôpital&gt; @joueur — nomme le DG d'un petit hôpital (l'ancien DG redevient récolteur)",
    "  /sante_poste &lt;poste&gt; @joueur [hôpital] — change le poste / l'affectation d'un employé",
    "  <i>Postes : recolteur, ambulancier, technicien, operateur, infirmier, medecin, chirurgien</i>",
    "  /sante_renvoyer @joueur [motif] — renvoie un employé de la Santé publique (un PDG : voir Game Leader)",
    "  <i>Le joueur doit être inscrit, non banni, et ne travailler dans aucune autre faction ni entreprise.</i>",
]
SANTE_HELP_GL = [
    "<b>🏥 SANTÉ PUBLIQUE — PDG (Game Leader+)</b>",
    "  /nommer_pdg @joueur — nomme le PDG du grand hôpital (ou réponds à son message) ; l'ancien PDG redevient récolteur",
    "  /revoquer_pdg [motif] — révoque le PDG actuel : il est renvoyé de la Santé publique, poste vacant",
    "  <i>Un Admin N2 ne peut pas renvoyer un PDG (/sante_renvoyer refusé) : utilise /revoquer_pdg.</i>",
    "  /coffre [faction] — solde du coffre général (défaut : santé)",
    "  /coffre_ajouter &lt;faction&gt; &lt;montant&gt; [motif] — ajoute de l'argent au coffre de la faction",
    "  /coffre_retirer &lt;faction&gt; &lt;montant&gt; [motif] — retire de l'argent du coffre, à tout moment",
    "  <i>Factions : sante, police, justice, mairie, armee. Les soins, médicaments et primes d'assurance remplissent déjà le coffre santé.</i>",
]
