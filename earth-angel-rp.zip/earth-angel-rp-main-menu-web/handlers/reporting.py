# handlers/reporting.py — Version corrigée complète
# ✅ Fix #1 : ajout de reporting_menu_callback
# ✅ Fix #5 : fusion avec utils/reporting.py (code mort supprimé)
# ✅ Ajout : has_recent_target_report (anti-spam)
# ✅ Ajout : menu interactif complet

from utils.swallow import swallowed
import html
import logging

import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from database import db_connection, DB_PATH, get_user, now, add_notification
from utils.decorators import require_registered, admin_only, get_user_role_async
from utils.cooldowns import claim_cooldown
from utils.helpers import fmt_time
from utils.aesthetics import card
from utils.input_flow import ask, flow
from utils.helpers import safe_edit
from utils.helpers import escape_html


# Règles, types, statuts et accès base : `gameplay/reports.py` (partagé avec l'API web).
from gameplay.reports import (  # noqa: F401  (noms ré-exportés pour bot.py et les tests)
    REPORT_TYPES, REPORT_COOLDOWN_KEY, REPORT_COOLDOWN, MIN_LEN,
    STATUS_EMOJI, STATUS_LABEL, STATUS_CODE,
    add_report, get_reports, get_user_reports, has_recent_target_report,
    update_report_status, get_report_stats,
)
from gameplay import reports as reports_service

logger = logging.getLogger(__name__)

BACK_HUB = "hub:profil:0"        # retour vers la zone « Profil & infos » du menu principal


async def _is_staff(user_id: int) -> bool:
    return await reports_service.is_staff(user_id)


def _after_markup(extra_first: list | None = None) -> InlineKeyboardMarkup:
    rows = list(extra_first or [])
    rows.append([InlineKeyboardButton("📋 Mes signalements", callback_data="report_my_list")])
    rows.append([InlineKeyboardButton("🚨 Signalements", callback_data="report_menu"),
                 InlineKeyboardButton("🎮 Menu principal", callback_data="hub:home")])
    return InlineKeyboardMarkup(rows)


async def _menu_view(user_id: int) -> tuple[str, InlineKeyboardMarkup]:
    """Écran principal des signalements (texte + boutons)."""
    reports = await get_user_reports(user_id, 20)
    pending = sum(1 for r in reports if r["status"] in ("pending", "in_progress"))
    body = [
        "🎯 <b>Signale un problème ou propose une idée</b>",
        "",
        f"📊 Tes signalements : <b>{len(reports)}</b>",
        f"⏳ En cours de traitement : <b>{pending}</b>",
        "",
        "<i>Choisis un type, puis écris ton message. Chaque signalement est examiné par l'équipe.</i>",
    ]
    keyboard = [
        [InlineKeyboardButton("🐛 Signaler un bug", callback_data="report_type_bug"),
         InlineKeyboardButton("💡 Suggestion", callback_data="report_type_suggestion")],
        [InlineKeyboardButton("⚠️ Exploit / Triche", callback_data="report_type_exploit"),
         InlineKeyboardButton("🚫 Harcèlement", callback_data="report_type_harassment")],
        [InlineKeyboardButton("🎯 Signaler un joueur", callback_data="report_user"),
         InlineKeyboardButton("📝 Autre", callback_data="report_type_other")],
        [InlineKeyboardButton("📋 Mes signalements", callback_data="report_my_list")],
    ]
    if await _is_staff(user_id):
        keyboard.append([InlineKeyboardButton("🛡️ Signalements à traiter (staff)", callback_data="admin_reports")])
    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data=BACK_HUB),
                     InlineKeyboardButton("🎮 Menu principal", callback_data="hub:home")])
    text = card("🚨 SIGNALEMENTS & SUPPORT", body, icon="🚨", style="thick",
                footer="Chaque retour compte pour améliorer le jeu.")
    return text, InlineKeyboardMarkup(keyboard)


# ─────────────────────────────────────────────────────────────────────────────
# Entrée depuis le menu principal (bouton « Signalements »)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ouvre l'écran des signalements (tout se fait ensuite par boutons et messages guidés)."""
    text, markup = await _menu_view(update.effective_user.id)
    await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


# anciens noms conservés (ils ouvrent simplement le même écran)
cmd_report_user = cmd_report
cmd_myreports = cmd_report


# ─────────────────────────────────────────────────────────────────────────────
# Saisies guidées : texte du signalement · joueur signalé · raison
# ─────────────────────────────────────────────────────────────────────────────
async def _claim(user_id: int) -> tuple[bool, int]:
    return await reports_service.claim(user_id)


@flow("report_text")
async def _flow_report_text(update, context, value, data):
    msg = update.effective_message
    rtype = data.get("type", "other")
    result = await reports_service.submit(update.effective_user.id, rtype, value)
    if not result["ok"]:
        if result["reason"] == "too_short":
            await ask(update, context, "report_text",
                      f"❌ Trop court (minimum {MIN_LEN} caractères). Décris un peu plus ton signalement.",
                      kind="text", data=data, back="report_menu")
        else:
            await msg.reply_text(
                f"⏳ Tu as déjà envoyé un signalement récemment. Attends encore {fmt_time(result['remaining'])}.",
                reply_markup=_after_markup())
        return
    d = REPORT_TYPES[result["report_type"]]
    await msg.reply_text(
        f"{d['emoji']} <b>Signalement envoyé !</b>\n\n{html.escape(d['auto_response'])}\n\n"
        "Tu peux suivre son état dans « 📋 Mes signalements ».",
        parse_mode="HTML", reply_markup=_after_markup())


@flow("report_target")
async def _flow_report_target(update, context, value, data):
    target_id, target_name = value
    me = update.effective_user.id
    msg = update.effective_message
    if target_id == me:
        await msg.reply_text("❌ Tu ne peux pas te signaler toi-même.", reply_markup=_after_markup())
        return
    if await has_recent_target_report(me, target_id):
        await msg.reply_text("⏳ Tu as déjà signalé ce joueur récemment. "
                             "Attends 1 heure avant un nouveau signalement contre la même cible.",
                             reply_markup=_after_markup())
        return
    await ask(update, context, "report_reason",
              f"🎯 Joueur signalé : <b>{html.escape(str(target_name))}</b>\n\n"
              "Écris maintenant la <b>raison</b> (harcèlement, triche, insultes…).",
              kind="text", data={"target_id": target_id, "target_name": str(target_name)}, back="report_menu")


@flow("report_reason")
async def _flow_report_reason(update, context, value, data):
    msg = update.effective_message
    result = await reports_service.submit(update.effective_user.id, None, value, data["target_id"])
    if not result["ok"]:
        if result["reason"] == "too_short":
            await ask(update, context, "report_reason",
                      f"❌ Trop court (minimum {MIN_LEN} caractères). Explique la raison un peu plus.",
                      kind="text", data=data, back="report_menu")
        else:
            await msg.reply_text(
                f"⏳ Tu as déjà envoyé un signalement récemment. Attends encore {fmt_time(result.get('remaining', 0))}.",
                reply_markup=_after_markup())
        return
    await msg.reply_text(
        f"⚠️ <b>Signalement envoyé contre {html.escape(data.get('target_name', ''))}</b>\n\n"
        f"Raison : {html.escape(value)}\n\n"
        "L'équipe de modération va examiner la situation.",
        parse_mode="HTML", reply_markup=_after_markup())


# ─────────────────────────────────────────────────────────────────────────────
# Commandes admin
# ─────────────────────────────────────────────────────────────────────────────
@admin_only
async def cmd_reports_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche la liste des signalements en attente."""
    reports = await get_reports("pending", 20)

    if not reports:
        await update.message.reply_text("📋 Aucun signalement en attente.")
        return

    import html as _html
    text = "📋 <b>Signalements en attente</b>\n\n"
    for r in reports:
        data = REPORT_TYPES.get(r["report_type"], {"name": r["report_type"], "emoji": "📝"})
        date = fmt_time(now() - r["created_at"])
        text += f"<b>ID #{r['id']}</b> | {data['emoji']} {_html.escape(str(data['name']))}\n"
        text += f"👤 Par : {_html.escape(str(r['reporter_name']))}\n"
        text += f"📅 il y a {date}\n"
        text += f"📝 {_html.escape(str(r['message'])[:150])}\n"
        if r["target_id"]:
            text += f"🎯 Cible : ID {r['target_id']}\n"
        text += "\n"

    keyboard = []
    for r in reports[:5]:
        keyboard.append([
            InlineKeyboardButton(
                f"📌 #{r['id']} - {r['report_type']}",
                callback_data=f"admin_report_{r['id']}"
            )
        ])
    keyboard.append([InlineKeyboardButton("📊 Statistiques", callback_data="admin_report_stats")])

    await update.message.reply_text(
        text[:3500],
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard) if keyboard else None
    )



# ─────────────────────────────────────────────────────────────────────────────
# Traitement d'un signalement (commande staff ET boutons staff)
# ─────────────────────────────────────────────────────────────────────────────
async def apply_report_status(bot, report_id: int, status: str, response: str | None = None) -> bool:
    """Change le statut, prévient le joueur (notification + message). False si le signalement n'existe pas."""
    reporter_id = await reports_service.set_status(report_id, status, response)
    if reporter_id is None:
        return False
    label = STATUS_LABEL.get(status, status)
    try:
        await bot.send_message(
            reporter_id,
            f"📢 <b>Mise à jour de ton signalement #{report_id}</b>\n\n"
            f"Statut : <b>{label}</b>\n"
            + (f"💬 Réponse : {html.escape(response)}\n" if response else ""),
            parse_mode="HTML")
    except Exception:
        swallowed('handlers/reporting.py')
    return True


@admin_only
async def cmd_report_handle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Staff : /report_handle <id> <statut> [réponse] (les boutons « Signalements » font la même chose)."""
    if not context.args or len(context.args) < 2:
        await update.message.reply_text(
            "Staff : ouvre Profil → Signalements → « Signalements à traiter », "
            "ou /report_handle id statut [réponse] (pending, in_progress, resolved, rejected).")
        return
    try:
        report_id = int(context.args[0])
        status = context.args[1].lower()
        response = " ".join(context.args[2:]) if len(context.args) > 2 else None
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Format invalide.")
        return
    if status not in STATUS_LABEL:
        await update.message.reply_text("❌ Statut invalide.")
        return
    if not await apply_report_status(context.bot, report_id, status, response):
        await update.message.reply_text(f"❌ Signalement #{report_id} introuvable.")
        return
    await update.message.reply_text(f"✅ Signalement #{report_id} mis à jour : {status}")


@admin_only
async def cmd_reports_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les statistiques des signalements."""
    stats = await get_report_stats()

    async with db_connection() as db:
        async with db.execute("""
            SELECT report_type, COUNT(*) as count
            FROM reports
            GROUP BY report_type
            ORDER BY count DESC
        """) as cur:
            by_type = await cur.fetchall()

    text = "📊 <b>Statistiques des signalements</b>\n\n"
    text += f"⏳ En attente : {escape_html(stats['pending'])}\n"
    text += f"🔨 En cours : {escape_html(stats['in_progress'])}\n"
    text += f"✅ Résolus : {escape_html(stats['resolved'])}\n"
    text += f"❌ Rejetés : {escape_html(stats['rejected'])}\n"
    text += f"📅 7 derniers jours : {escape_html(stats['last_7_days'])}\n\n"
    text += "<b>Par type :</b>\n"
    for rt, count in by_type:
        data = REPORT_TYPES.get(rt, {"name": rt, "emoji": "📝"})
        text += f"{escape_html(data['emoji'])} {escape_html(data['name'])} : {escape_html(count)}\n"

    await update.message.reply_text(text, parse_mode="HTML")



# ─────────────────────────────────────────────────────────────────────────────
# Callbacks (boutons)
# ─────────────────────────────────────────────────────────────────────────────
async def _staff_list_view() -> tuple[str, InlineKeyboardMarkup]:
    reports = await get_reports("pending", 20) + await get_reports("in_progress", 20)
    back = [InlineKeyboardButton("⬅️ Retour", callback_data="report_menu")]
    if not reports:
        return ("📋 Aucun signalement à traiter.",
                InlineKeyboardMarkup([[InlineKeyboardButton("📊 Statistiques", callback_data="admin_report_stats")], back]))
    body = [f"📋 <b>{len(reports)} signalement(s) à traiter</b>", ""]
    rows = []
    for r in reports[:15]:
        d = REPORT_TYPES.get(r["report_type"], {"name": r["report_type"], "emoji": "📝"})
        st = STATUS_EMOJI.get(r["status"], "❓")
        body.append(f"{st} <b>#{r['id']}</b> {d['emoji']} {d['name']} — {html.escape(str(r['reporter_name']))}\n"
                    f"   {html.escape(r['message'][:70])}")
        rows.append([InlineKeyboardButton(f"{st} #{r['id']} · {d['name']}"[:40], callback_data=f"admin_report_{r['id']}")])
    rows.append([InlineKeyboardButton("📊 Statistiques", callback_data="admin_report_stats")])
    rows.append(back)
    return card("🛡️ SIGNALEMENTS À TRAITER", body, icon="🛡️", style="thick"), InlineKeyboardMarkup(rows)


async def _staff_detail_view(report_id: int) -> tuple[str, InlineKeyboardMarkup] | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT r.*, u.full_name AS reporter_name FROM reports r "
            "LEFT JOIN users u ON u.user_id = r.user_id WHERE r.id = ?", (report_id,)) as cur:
            r = await cur.fetchone()
    if not r:
        return None
    r = dict(r)
    d = REPORT_TYPES.get(r["report_type"], {"name": r["report_type"], "emoji": "📝"})
    body = [
        f"{d['emoji']} <b>{d['name']}</b> — {STATUS_EMOJI.get(r['status'], '❓')} {r['status']}",
        f"👤 Par : {html.escape(str(r.get('reporter_name') or r['user_id']))}",
        f"📅 il y a {fmt_time(now() - r['created_at'])}",
    ]
    if r.get("target_id"):
        body.append(f"🎯 Joueur visé : ID <code>{r['target_id']}</code>")
    body += ["", html.escape(r["message"][:1500])]
    if r.get("admin_response"):
        body += ["", f"💬 <b>Réponse :</b> {html.escape(r['admin_response'][:300])}"]
    rid = r["id"]
    rows = [
        [InlineKeyboardButton("🔨 En cours", callback_data=f"admin_report_set_{rid}_ip"),
         InlineKeyboardButton("✅ Résolu", callback_data=f"admin_report_set_{rid}_ok")],
        [InlineKeyboardButton("❌ Rejeté", callback_data=f"admin_report_set_{rid}_no"),
         InlineKeyboardButton("💬 Répondre", callback_data=f"admin_report_reply_{rid}")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="admin_reports")],
    ]
    return card(f"📌 SIGNALEMENT #{rid}", body, icon="📌", style="thick"), InlineKeyboardMarkup(rows)


@flow("report_admin_reply")
async def _flow_admin_reply(update, context, value, data):
    msg = update.effective_message
    if not await _is_staff(update.effective_user.id):
        return
    rid = data["id"]
    if not await apply_report_status(context.bot, rid, "resolved", value):
        await msg.reply_text(f"❌ Signalement #{rid} introuvable.")
        return
    await msg.reply_text(f"✅ Réponse envoyée, signalement #{rid} marqué résolu.",
                         reply_markup=InlineKeyboardMarkup(
                             [[InlineKeyboardButton("🛡️ Signalements à traiter", callback_data="admin_reports")]]))


async def report_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Boutons des signalements : choix du type, signaler un joueur, et côté staff le traitement."""
    query = update.callback_query
    await query.answer()
    data = query.data or ""
    uid = query.from_user.id

    if data.startswith("report_type_"):
        report_type = data.replace("report_type_", "")
        if report_type not in REPORT_TYPES:
            await safe_edit(query, "❌ Type invalide.")
            return
        d = REPORT_TYPES[report_type]
        await ask(query, context, "report_text",
                  f"{d['emoji']} <b>{d['name']}</b>\n\nÉcris le détail de ton signalement en un seul message.",
                  kind="text", data={"type": report_type}, back="report_menu")
        return

    if data == "report_user":
        await ask(query, context, "report_target",
                  "🎯 <b>Signaler un joueur</b>\n\nEnvoie son <b>@pseudo</b> (ou son ID).",
                  kind="user", back="report_menu")
        return

    if data == "report_cancel":
        await safe_edit(query, "❌ Signalement annulé.", reply_markup=_after_markup())
        return

    # ── côté staff ──
    if data.startswith("admin_report"):
        if not await _is_staff(uid):
            await query.answer("🚫 Réservé au staff.", show_alert=True)
            return
        if data == "admin_reports":
            text, markup = await _staff_list_view()
            await safe_edit(query, text, reply_markup=markup)
            return
        if data == "admin_report_stats":
            stats = await get_report_stats()
            await safe_edit(
                query,
                "📊 <b>Statistiques</b>\n\n"
                f"⏳ En attente : {stats['pending']}\n🔨 En cours : {stats['in_progress']}\n"
                f"✅ Résolus : {stats['resolved']}\n❌ Rejetés : {stats['rejected']}\n"
                f"📅 7 derniers jours : {stats['last_7_days']}",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="admin_reports")]]))
            return
        if data.startswith("admin_report_set_"):
            try:
                rid_s, code = data[len("admin_report_set_"):].rsplit("_", 1)
                rid, status = int(rid_s), STATUS_CODE[code]
            except (ValueError, KeyError):
                await query.answer("Action invalide.", show_alert=True)
                return
            if not await apply_report_status(context.bot, rid, status):
                await query.answer("Signalement introuvable.", show_alert=True)
                return
            view = await _staff_detail_view(rid)
            if view:
                await safe_edit(query, view[0], reply_markup=view[1])
            return
        if data.startswith("admin_report_reply_"):
            try:
                rid = int(data[len("admin_report_reply_"):])
            except ValueError:
                await query.answer("ID invalide.", show_alert=True)
                return
            await ask(query, context, "report_admin_reply",
                      f"💬 <b>Réponse au signalement #{rid}</b>\n\nÉcris ta réponse : elle sera envoyée au joueur "
                      "et le signalement passera en « résolu ».",
                      kind="text", data={"id": rid}, back=f"admin_report_{rid}")
            return
        try:
            rid = int(data[len("admin_report_"):])
        except ValueError:
            await query.answer("ID invalide.", show_alert=True)
            return
        view = await _staff_detail_view(rid)
        if not view:
            await query.answer("Signalement introuvable.", show_alert=True)
            return
        await safe_edit(query, view[0], reply_markup=view[1])



# ═══════════════════════════════════════════════════════════════════
#              🚨 MENU INTERACTIF REPORTING
# ═══════════════════════════════════════════════════════════════════



async def show_report_menu(query, user_id: int):
    """Menu principal du module Reporting."""
    text, markup = await _menu_view(user_id)
    await safe_edit(query, text, parse_mode="HTML", reply_markup=markup)


async def show_report_my_list(query, user_id: int):
    reports = await get_user_reports(user_id, 20)
    back = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="report_menu")]])
    if not reports:
        await safe_edit(query, "📋 Tu n'as envoyé aucun signalement.", reply_markup=back)
        return

    body = [f"📋 <b>{len(reports)} signalement(s)</b>", ""]
    for r in reports[:10]:
        d = REPORT_TYPES.get(r["report_type"], {"name": r["report_type"], "emoji": "📝"})
        st = STATUS_EMOJI.get(r["status"], "❓")
        date = fmt_time(now() - r["created_at"])
        body.append(
            f"{d['emoji']} <b>{d['name']}</b> {st}\n"
            f"   <i>il y a {date}</i>\n"
            f"   {html.escape(r['message'][:80])}{'…' if len(r['message']) > 80 else ''}"
        )
        if r.get("admin_response"):
            body.append(f"   💬 <b>Réponse :</b> {html.escape(r['admin_response'][:80])}")

    await safe_edit(query, card("📋 MES SIGNALEMENTS", body, icon="📋", style="thick"),
                    parse_mode="HTML", reply_markup=back)


async def reporting_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routeur des écrans « Signalements » et « Mes signalements »."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "report_menu":
        await show_report_menu(query, user_id)
        return
    if data == "report_my_list":
        await show_report_my_list(query, user_id)
        return


__all__ = [
    "REPORT_TYPES",
    "add_report",
    "get_reports",
    "get_user_reports",
    "has_recent_target_report",
    "update_report_status",
    "get_report_stats",
    "apply_report_status",
    "cmd_report",
    "cmd_report_user",
    "cmd_myreports",
    "cmd_reports_list",
    "cmd_report_handle",
    "cmd_reports_stats",
    "report_callback",
    "reporting_menu_callback",
    "show_report_menu",
    "show_report_my_list",
]
