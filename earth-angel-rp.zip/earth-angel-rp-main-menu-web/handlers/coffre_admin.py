# handlers/coffre_admin.py — coffre général des factions (Game Leader et plus)
"""
/coffre [faction]                              — solde du coffre (défaut : Santé publique)
/coffre_ajouter <faction> <montant> [motif]    — ajoute de l'argent au coffre (Game Leader+)
/coffre_retirer <faction> <montant> [motif]    — retire de l'argent du coffre, à tout moment (Game Leader+)
Factions : sante, police, justice, mairie, armee (clé ou nom). Les soins, médicaments et primes
d'assurance de la Santé publique alimentent déjà ce coffre automatiquement (utils/sante.py).
"""
import html

from config import GOV_FACTIONS
from database import db_connection
from telegram import Update
from telegram.ext import ContextTypes

from handlers.sante import _norm
from utils.decorators import game_leader_only
from utils.factions import coffre_add, coffre_balance
from utils.helpers import parse_amount


def _faction_key(token: str) -> str | None:
    t = _norm(token)
    for key, f in GOV_FACTIONS.items():
        if t in (key, _norm(f["name"])):
            return key
    return None


def _usage(cmd: str) -> str:
    keys = " · ".join(GOV_FACTIONS)
    return f"Usage : /{cmd} &lt;faction&gt; &lt;montant&gt; [motif]\nFactions : {keys}"


async def _move(update: Update, context: ContextTypes.DEFAULT_TYPE, sign: int, cmd: str):
    args = list(context.args or [])
    key = _faction_key(args[0]) if args else None
    amount = parse_amount(args[1]) if len(args) > 1 else None
    if not key or not amount or amount <= 0:
        await update.message.reply_text(_usage(cmd), parse_mode="HTML")
        return
    reason = " ".join(args[2:]) or ("ajout par la direction du jeu" if sign > 0 else "retrait par la direction du jeu")
    async with db_connection() as db:
        await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES (?,0)", (key,))
        async with db.execute("SELECT budget FROM faction_state WHERE faction=?", (key,)) as cur:
            have = int((await cur.fetchone())[0])
        if sign < 0 and amount > have:
            await update.message.reply_text(f"❌ Le coffre ne contient que <b>{have:,}</b>.", parse_mode="HTML")
            return
        await coffre_add(db, key, sign * amount)
        await db.commit()
    if key == "sante":
        from utils import sante
        await sante.log_event(update.effective_user.id, "coffre_ajout" if sign > 0 else "coffre_retrait", 0,
                              f"{amount} — {reason}")
    f = GOV_FACTIONS[key]
    await update.message.reply_text(
        f"{'💰➕' if sign > 0 else '💸➖'} Coffre {f['emoji']} <b>{f['name']}</b> : "
        f"{'+' if sign > 0 else '-'}{amount:,}\n🏦 Nouveau solde : <b>{await coffre_balance(key):,}</b>\n"
        f"<i>{html.escape(reason)}</i>", parse_mode="HTML")


@game_leader_only
async def cmd_coffre_ajouter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _move(update, context, +1, "coffre_ajouter")


@game_leader_only
async def cmd_coffre_retirer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _move(update, context, -1, "coffre_retirer")


@game_leader_only
async def cmd_coffre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    key = _faction_key(context.args[0]) if context.args else "sante"
    if not key:
        await update.message.reply_text(_usage("coffre"), parse_mode="HTML")
        return
    f = GOV_FACTIONS[key]
    await update.message.reply_text(f"🏦 Coffre {f['emoji']} <b>{f['name']}</b> : <b>{await coffre_balance(key):,}</b>",
                                    parse_mode="HTML")
