"""
handlers/forms_companies.py — Entreprises : toutes les commandes en formulaires à boutons
(remplace /creerboite, /postuler, /accepter, /prime, /rd, /depotboite, …)
"""
from __future__ import annotations

from config import PRODUCT_EFFECTS, SECTORS
from database import db_connection
from utils.forms import Form, P, provider, register

BACK = "comp_menu"
M = "handlers.companies:"
EFFECTS = tuple(PRODUCT_EFFECTS) if isinstance(PRODUCT_EFFECTS, dict) else ("heal", "energy", "xp", "money", "buff")
SECT = tuple((s, s) for s in SECTORS)
EFF = tuple((e, e) for e in EFFECTS)


# ── Listes dynamiques proposées en boutons ──────────────────────────
@provider("companies")
async def _companies(uid):
    async with db_connection() as db:
        async with db.execute(
            "SELECT name, sector FROM companies WHERE dissolved=0 ORDER BY reputation DESC LIMIT 20"
        ) as cur:
            return [(f"🏢 {n} ({s})", n) for n, s in await cur.fetchall()]


@provider("my_apps")
async def _apps(uid):
    async with db_connection() as db:
        async with db.execute(
            "SELECT ca.app_id, u.full_name, ca.desired_salary FROM company_applications ca "
            "JOIN users u ON u.user_id=ca.user_id "
            "JOIN companies c ON c.company_id=ca.company_id "
            "WHERE c.owner_id=? AND ca.status='pending' ORDER BY ca.applied_at LIMIT 20", (uid,)
        ) as cur:
            return [(f"👤 {n} — {s}/j", str(a)) for a, n, s in await cur.fetchall()]


@provider("my_products")
async def _products(uid):
    async with db_connection() as db:
        async with db.execute(
            "SELECT p.name FROM company_products p JOIN companies c ON c.company_id=p.company_id "
            "WHERE c.owner_id=? ORDER BY p.name LIMIT 30", (uid,)
        ) as cur:
            return [(f"📦 {n}", n) for (n,) in await cur.fetchall()]


def F(key, label, fn, params=(), groups=(), **kw):
    return Form(f"c_{key}", label, M + fn, tuple(params), tuple(groups), back=BACK, **kw)


TARGET = P("target", "user", "Envoie le <b>@pseudo</b> ou l'<b>ID</b> du joueur.", reply=True)
AMOUNT = P("amount", "int", "Envoie le <b>montant</b> (€A).", min=1)

register(
    # ── Création / candidature ──
    F("creer", "🏭 Créer", "cmd_creerboite",
      [P("name", "text", "Nom de ton entreprise ?"), P("sector", "choice", "Quel secteur ?", choices=SECT)],
      ["comp_create_info"]),
    F("postuler", "📝 Postuler", "cmd_postuler",
      [P("company", "choice", "Quelle entreprise ?", choices="companies"),
       P("salary", "int", "Salaire souhaité (€A/jour) ?", min=0)],
      ["comp_postuler_info"]),
    F("liste", "🏢 Entreprises", "cmd_boites", [], ["comp_postuler_info"]),
    F("info", "ℹ️ Détails", "cmd_infoboite",
      [P("name", "choice", "Quelle entreprise ?", choices="companies")], ["comp_postuler_info"]),
    # ── Produits ──
    F("produits", "📦 Catalogue", "cmd_produits", [], ["comp_products_info"]),
    F("setprix", "💲 Prix", "cmd_setprix",
      [P("product", "choice", "Quel produit ?", choices="my_products"),
       P("price", "int", "Nouveau prix (€A) ?", min=1)], ["comp_products_info"]),
    # ── Équipe ──
    F("employes", "👥 Employés", "cmd_employes", [], ["comp_team_info"]),
    F("candidatures", "📋 Candidatures", "cmd_candidatures", [], ["comp_team_info", "comp_candidatures_info"]),
    F("accepter", "✅ Accepter", "cmd_accepter",
      [P("app", "choice", "Quelle candidature ?", choices="my_apps"),
       P("salary", "int", "Salaire proposé (€A/jour) ?", min=0)],
      ["comp_team_info", "comp_candidatures_info"]),
    F("refuser", "❌ Refuser", "cmd_refuser",
      [P("app", "choice", "Quelle candidature ?", choices="my_apps")],
      ["comp_team_info", "comp_candidatures_info"]),
    F("inviter", "📨 Inviter", "cmd_inviter",
      [TARGET, P("salary", "int", "Salaire proposé (€A/jour) ?", min=0),
       P("poste", "text", "Intitulé du poste ?")], ["comp_team_info"]),
    F("setsalaire", "💼 Salaire", "cmd_setsalaire",
      [TARGET, P("salary", "int", "Nouveau salaire (€A/jour) ?", min=0)], ["comp_team_info"]),
    F("prime", "🎁 Prime", "cmd_prime", [TARGET, AMOUNT], ["comp_team_info"]),
    F("former", "🎓 Former", "cmd_former", [TARGET, AMOUNT], ["comp_team_info"]),
    F("licencier", "🚪 Licencier", "cmd_licencier", [TARGET], ["comp_team_info"],
      confirm="Le joueur sera licencié immédiatement."),
    F("demission", "🏃 Démissionner", "cmd_demissionner", [], ["comp_team_info", "comp_paie_info"],
      confirm="Tu quittes ton entreprise."),
    # ── Finances ──
    F("depot", "💰 Déposer", "cmd_depotboite", [AMOUNT], ["comp_finance_info"]),
    F("retrait", "💸 Retirer", "cmd_retirerboite", [AMOUNT], ["comp_finance_info"]),
    F("salaires", "💵 Payer salaires", "cmd_versersalaires", [], ["comp_finance_info"]),
    F("parts", "📊 Parts", "cmd_parts", [], ["comp_finance_info"]),
    F("buyparts", "🛒 Acheter parts", "cmd_acheterparts",
      [P("company", "choice", "Dans quelle entreprise ?", choices="companies"),
       P("shares", "int", "Combien de parts ?", min=1)], ["comp_finance_info"]),
    F("sellparts", "💹 Vendre parts", "cmd_vendreparts",
      [P("company", "choice", "De quelle entreprise ?", choices="companies"),
       P("shares", "int", "Combien de parts ?", min=1)], ["comp_finance_info"]),
    F("dividendes", "🏦 Dividendes", "cmd_dividendes",
      [P("percent", "int", "Quel pourcentage verser (1 à 100) ?", min=1, max=100)], ["comp_finance_info"]),
    # ── R&D ──
    F("rd", "🔬 Investir R&D", "cmd_rd", [AMOUNT], ["comp_rd_info"]),
    # ── Annonces ──
    F("annonce", "📢 Publier", "cmd_annonce",
      [P("poste", "text", "Intitulé du poste (un mot) ?", one_word=True),
       P("salary", "int", "Salaire (€A/jour) ?", min=0)], ["comp_annonce_info"]),
    F("emplois", "🔎 Offres", "cmd_emplois", [], ["comp_annonce_info"]),
    # ── Gestion générale ──
    F("rename", "✏️ Renommer", "cmd_renommer_entreprise",
      [P("name", "text", "Nouveau nom de l'entreprise ?")], ["comp_menu_admin"]),
    F("sector", "🏭 Secteur", "cmd_changer_secteur",
      [P("sector", "choice", "Nouveau secteur ?", choices=SECT)], ["comp_menu_admin"]),
    F("overhead", "🧾 Frais fixes", "cmd_setoverhead",
      [P("v", "int", "Montant des frais fixes ?", min=0)], ["comp_menu_admin"]),
    F("dissoudre", "💥 Dissoudre", "cmd_dissoudreboite", [], ["comp_menu_admin"],
      confirm="⚠️ Ton entreprise sera dissoute définitivement.", fixed_args=("confirmer",)),
    Form("c_prod_fiche", "🏭 Production & stock", M + "cmd_production", (), ("comp_products_info",), back=BACK),
    Form("c_prod_niveau", "⚙️ Niveau de production", M + "cmd_production",
         (P("level", "choice", "Quel niveau de production ?\n1 = prudente · 2 = normale · 3 = agressive "
            "(produit plus mais coûte plus cher)", choices=(("1 · Prudente", "1"), ("2 · Normale", "2"),
                                                              ("3 · Agressive", "3"))),),
         ("comp_products_info",), back=BACK),
)
