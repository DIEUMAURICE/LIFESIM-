# handlers/companies.py — Module Entreprises refondu
from gameplay import hiring as hiring_service
from utils.company_roles import can_manage, get_role
import asyncio
import aiosqlite
import random
import re
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import (
    Outbox,
    DeferredReply,
    DB_PATH, get_user, update_balance, get_company_by_name, get_company_by_id,
    get_user_company, get_all_companies, log_company_action, increment_field,
    now, add_notification, DB_TIMEOUT, db_connection,  # Ajout de db_connection
)
from utils.decorators import require_registered, require_free
from utils.helpers import fmt, parse_amount, escape_md, escape_html
from utils.aesthetics import card, alert, section, rich_bar
from config import SECTORS, COMPANY_CREATION_COST, PRODUCT_EFFECTS
from utils.gametime import fmt_game_datetime
from utils.company_ops import (  # noqa: F401
    CONTRACT_TYPES,  # noqa: F401 — ré-export : les formulaires/bot importent depuis handlers.companies
    _add_item_to_inventory, _remove_item_from_inventory, company_deposit_atomic, company_spend_atomic, company_withdraw_atomic, get_user_shares, paginate_items, pay_company_salaries_atomic, strip_quotes, update_company_field,
)
from handlers.company_products import (  # noqa: F401 — ré-export : les formulaires/bot importent depuis handlers.companies
    cmd_donner_produit, cmd_produits, cmd_retirer_produit, cmd_setprix, cmd_supprimer_produit,
)
from handlers.company_shares import (  # noqa: F401 — ré-export : les formulaires/bot importent depuis handlers.companies
    cmd_acheterparts, cmd_dividendes, cmd_parts, cmd_transfert_entreprise, cmd_vendreparts,
)
from handlers.company_deals import (  # noqa: F401 — ré-export : les formulaires/bot importent depuis handlers.companies
    cmd_negocier_contrat, cmd_proposer_contrat, cmd_proposer_fusion, cmd_repondre_contrat, cmd_repondre_fusion,
)

# ─────────────────────────────────────────────────────────────────────────────
# Helper : enlever les guillemets
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# Helper : ajouter/retirer item de l'inventaire
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# Helper : pagination corrigée (Lot 5)
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# Fonctions utilitaires pour les parts
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# Helpers financiers atomiques (Lot 5)
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# Fonctions d'affichage (company view)
# ─────────────────────────────────────────────────────────────────────────────
def _company_stage(level: int) -> str:
    """Stade de l'entreprise (Atelier → Multinationale, voir config_chain.STAGES)."""
    from config_chain import stage_name
    return stage_name(level)

def _company_targets(level: int) -> dict:
    """Conditions du stade `level` (1 = Atelier … 7 = Multinationale)."""
    from config_chain import STAGES, clamp_stage
    st = STAGES[clamp_stage(level) - 1]
    return {
        "treasury": st["treasury"],
        "reputation": st["rep"],
        "rd_level": max(1, level // 2),
        "employees": st["staff"],
        "products": min(6, 1 + level // 2),
    }

def _progress_mark(current: int, target: int) -> str:
    return "✅" if current >= target else "⬜"

async def _company_metrics(company: dict) -> dict:
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT COUNT(*) AS n, COALESCE(AVG(activity_score),0) AS avg_activity "
            "FROM company_members WHERE company_id=?",
            (company["company_id"],)
        ) as cur:
            team = await cur.fetchone()
        async with db.execute("SELECT COUNT(*) FROM company_products WHERE company_id=?", (company["company_id"],)) as cur:
            product_count = (await cur.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM company_ads WHERE company_id=?", (company["company_id"],)) as cur:
            ad_count = (await cur.fetchone())[0]
        async with db.execute(
            "SELECT COUNT(*) FROM company_applications WHERE company_id=? AND status='pending'",
            (company["company_id"],)
        ) as cur:
            pending_apps = (await cur.fetchone())[0]
        # Contrats actifs (type accepted)
        async with db.execute(
            "SELECT COUNT(*) FROM contracts WHERE (from_company=? OR to_company=?) AND status='accepted' AND end_date > ?",
            (company["company_id"], company["company_id"], now())
        ) as cur:
            contract_count = (await cur.fetchone())[0]
        # Contrats en négociation
        async with db.execute(
            "SELECT COUNT(*) FROM contracts WHERE (from_company=? OR to_company=?) AND status='negotiating'",
            (company["company_id"], company["company_id"])
        ) as cur:
            negotiating_contracts = (await cur.fetchone())[0]
        async with db.execute(
            "SELECT COUNT(*), COALESCE(SUM(shares), 0) FROM company_shares WHERE company_id=?",
            (company["company_id"],)
        ) as cur:
            shareholders_count, total_shares = await cur.fetchone()
        async with db.execute("""
            SELECT name, price, sales, revenue
            FROM company_products
            WHERE company_id=?
            ORDER BY revenue DESC, sales DESC, price DESC
            LIMIT 5
        """, (company["company_id"],)) as cur:
            top_products = [dict(r) for r in await cur.fetchall()]
        async with db.execute("""
            SELECT u.full_name, cm.poste, cm.activity_score, cm.base_salary
            FROM company_members cm
            JOIN users u ON u.user_id=cm.user_id
            WHERE cm.company_id=?
            ORDER BY cm.activity_score DESC, cm.base_salary DESC
            LIMIT 5
        """, (company["company_id"],)) as cur:
            top_members = [dict(r) for r in await cur.fetchall()]
        async with db.execute("""
            SELECT action, details, timestamp
            FROM company_logs
            WHERE company_id=?
            ORDER BY timestamp DESC
            LIMIT 4
        """, (company["company_id"],)) as cur:
            logs = [dict(r) for r in await cur.fetchall()]

    revenue_total = sum(p["revenue"] for p in top_products)
    growth_score = min(
        100,
        company["level"] * 6
        + company["reputation"] // 2
        + company.get("rd_level", 0) * 7
        + int((team["avg_activity"] or 0) * 1.5)
        + product_count * 6
        + contract_count * 8
    )
    health_score = min(
        100,
        max(
            5,
            int(
                min(35, company["treasury"] / 25_000)
                + min(30, company["reputation"] * 0.3)
                + min(20, team["n"] * 2.5)
                + min(15, company.get("rd_level", 0) * 3)
            )
        ),
    )

    return {
        "employees": team["n"],
        "avg_activity": int(team["avg_activity"] or 0),
        "products": product_count,
        "ads": ad_count,
        "pending_apps": pending_apps,
        "contracts": contract_count,
        "negotiating_contracts": negotiating_contracts,
        "shareholders": shareholders_count,
        "total_shares": total_shares or 100,
        "top_products": top_products,
        "top_members": top_members,
        "logs": logs,
        "revenue_total": revenue_total,
        "growth_score": growth_score,
        "health_score": health_score,
    }

def _company_buttons(company_id: int, is_manager: bool = False):
    rows = [[
        InlineKeyboardButton("🏢 Vue", callback_data=f"company_page_overview_{company_id}"),
        InlineKeyboardButton("🧠 Audit", callback_data=f"company_page_audit_{company_id}"),
    ], [
        InlineKeyboardButton("📦 Produits", callback_data=f"company_page_products_{company_id}"),
        InlineKeyboardButton("👥 Équipe", callback_data=f"company_page_team_{company_id}"),
    ]]
    if is_manager:
        rows.append([
            InlineKeyboardButton("💼 Gestion", callback_data=f"company_page_manage_{company_id}"),
            InlineKeyboardButton("💰 Finance", callback_data=f"company_page_finance_{company_id}"),
        ])
    return InlineKeyboardMarkup(rows)

def _company_recommendations(company: dict, metrics: dict) -> list[str]:
    recommendations = []
    runway_needed = max(50_000, metrics["employees"] * max(1, company.get("overhead", 1000)) * 3)
    if company["treasury"] < runway_needed:
        recommendations.append(f"Renforcer la trésorerie jusqu'à <b>{fmt(runway_needed)}</b> minimum.")
    if metrics["products"] == 0:
        recommendations.append("Créer un produit pour générer des revenus via le marché.")
    if metrics["employees"] < max(2, company["level"]):
        recommendations.append("Recruter pour soutenir la croissance et augmenter l'activité.")
    if company.get("rd_level", 0) < max(1, company["level"] // 2):
        recommendations.append("Investir en R&D pour améliorer la qualité des produits.")
    if company["reputation"] < 60:
        recommendations.append("Remonter la réputation avec une équipe active et une offre plus crédible.")
    if metrics["pending_apps"] > 0:
        recommendations.append("Traiter les candidatures en attente pour ne pas rater des talents.")
    if metrics["contracts"] == 0 and company["level"] >= 4:
        recommendations.append("Signer un contrat B2B pour stabiliser les revenus.")
    return recommendations[:4] or ["Entreprise équilibrée. Continue à élargir le catalogue et la structure."]

async def _render_company_view(company: dict, viewer_company: dict | None, view: str = "overview"):
    metrics = await _company_metrics(company)
    is_manager = (
        viewer_company is not None
        and viewer_company.get("company_id") == company["company_id"]
        and viewer_company.get("poste") in ("PDG", "Directeur")
    )
    targets = _company_targets(company["level"] + 1)
    buttons = _company_buttons(company["company_id"], is_manager)
    owner = await get_user(company["owner_id"])

    if view == "products":
        body = [
            f"Catalogue : <b>{metrics['products']}</b> produit(s)",
            f"Revenu cumulé suivi : <b>{fmt(metrics['revenue_total'])}</b>",
            "",
        ]
        if metrics["top_products"]:
            for product in metrics["top_products"]:
                async with db_connection() as db:
                    async with db.execute("SELECT effect_type, effect_value FROM items WHERE name=?", (product["name"],)) as cur:
                        item_row = await cur.fetchone()
                effect_str = f" (effet: {item_row[0] if item_row else 'Aucun'})" if item_row else ""
                body.append(
                    f"📦 <b>{escape_html(product['name'])}</b> · prix {fmt(product['price'])} · "
                    f"ventes {product['sales']} · CA {fmt(product['revenue'])}{effect_str}"
                )
        else:
            body.append("Aucun produit enregistré. Ouvre le 🎮 Menu principal pour lancer le catalogue.")
        body += ["", "Les produits ne sont plus vendus automatiquement. Vous devez les vendre via le marché."]
        return card("📦 Catalogue entreprise", body, icon="📦", style="thick"), buttons

    if view == "team":
        body = [
            f"👥 Effectif : <b>{metrics['employees']}</b>",
            f"⚡ Activité moyenne : <b>{metrics['avg_activity']}</b>",
            f"📨 Candidatures en attente : <b>{metrics['pending_apps']}</b>",
            "",
        ]
        if metrics["top_members"]:
            for member in metrics["top_members"]:
                body.append(
                    f"👤 <b>{escape_html(member['full_name'])}</b> · {escape_html(member['poste'])} · "
                    f"activité {member['activity_score']} · salaire {fmt(member['base_salary'])}"
                )
        else:
            body.append("Aucun employé actif.")
        return card("👥 Équipe", body, icon="👥", style="thick"), buttons

    if view == "finance":
        share_value = max(
            10,
            (company["treasury"] // 1000) * (50 + company["reputation"]) // 50 + company.get("rd_level", 0) * 100,
        )
        market_cap = share_value * max(1, metrics["total_shares"])
        body = [
            f"💰 Trésorerie : <b>{fmt(company['treasury'])}</b>",
            f"💸 Frais généraux : <b>{fmt(company.get('overhead', 1000))}</b> / employé",
            f"📈 Valeur par part : <b>{fmt(share_value)}</b>",
            f"🏦 Valorisation interne : <b>{fmt(market_cap)}</b>",
            f"🤝 Contrats actifs : <b>{metrics['contracts']}</b>",
            f"📝 Contrats en négociation : <b>{metrics['negotiating_contracts']}</b>",
            f"👤 Actionnaires : <b>{metrics['shareholders']}</b>",
            "",
            f"Momentum : <code>{rich_bar(metrics['growth_score'], 100, 12)}</code> <b>{metrics['growth_score']}%</b>",
        ]
        return card("💰 Finance", body, icon="💰", style="thick"), buttons

    if view == "manage":
        body = [
            f"PDG : <b>{escape_html(owner['full_name'])}</b>",
            f"Réputation : <b>{company['reputation']}/100</b>",
            f"Niveau : <b>{company['level']}</b> · phase <b>{_company_stage(company['level'])}</b>",
            "",
            "<b>Raccourcis utiles</b>",
            "• bouton du menu Entreprises",
            "<code>/rd montant</code>",
        ]
        return card("💼 Gestion", body, icon="💼", style="thick"), buttons

    if view == "audit":
        body = [
            f"Phase actuelle : <b>{_company_stage(company['level'])}</b>",
            f"Santé : <code>{rich_bar(metrics['health_score'], 100, 10)}</code> <b>{metrics['health_score']}%</b>",
            f"Croissance : <code>{rich_bar(metrics['growth_score'], 100, 10)}</code> <b>{metrics['growth_score']}%</b>",
            "",
            "<b>Prochain cap</b>",
            f"{_progress_mark(company['treasury'], targets['treasury'])} Trésorerie {fmt(company['treasury'])} / {fmt(targets['treasury'])}",
            f"{_progress_mark(company['reputation'], targets['reputation'])} Réputation {company['reputation']} / {targets['reputation']}",
            f"{_progress_mark(company.get('rd_level', 0), targets['rd_level'])} R&D {company.get('rd_level', 0)} / {targets['rd_level']}",
            f"{_progress_mark(metrics['employees'], targets['employees'])} Employés {metrics['employees']} / {targets['employees']}",
            f"{_progress_mark(metrics['products'], targets['products'])} Produits {metrics['products']} / {targets['products']}",
            "",
            "<b>Priorités</b>",
        ]
        body.extend(f"• {tip}" for tip in _company_recommendations(company, metrics))
        return card("🧠 Audit entreprise", body, icon="🧠", style="thick"), buttons

    # Overview
    body = [
        f"🏭 Secteur : <b>{escape_html(company['sector'])}</b>",
        f"👑 PDG : <b>{escape_html(owner['full_name'])}</b>",
        f"🏆 Niveau : <b>{company['level']}</b> · <b>{_company_stage(company['level'])}</b>",
        f"⭐ Réputation : <b>{company['reputation']}/100</b>",
        f"💰 Trésorerie : <b>{fmt(company['treasury'])}</b>",
        f"🔬 R&D : <b>{company.get('rd_level', 0)}</b>",
        "",
        f"👥 Effectif : <b>{metrics['employees']}</b> · activité moyenne <b>{metrics['avg_activity']}</b>",
        f"📦 Produits : <b>{metrics['products']}</b> · 🤝 contrats actifs : <b>{metrics['contracts']}</b>",
        f"📨 Candidatures : <b>{metrics['pending_apps']}</b> · 📣 annonces : <b>{metrics['ads']}</b>",
        "",
        f"Santé : <code>{rich_bar(metrics['health_score'], 100, 12)}</code> <b>{metrics['health_score']}%</b>",
        f"Croissance : <code>{rich_bar(metrics['growth_score'], 100, 12)}</code> <b>{metrics['growth_score']}%</b>",
    ]
    if metrics["logs"]:
        body += ["", "<b>Derniers mouvements</b>"]
        for log in metrics["logs"][:3]:
            body.append(f"• <b>{escape_html(log['action'])}</b> · {escape_html(log['details'])}")
    return card(f"🏢 {escape_html(company['name'])}", body, icon="🏢", style="thick"), buttons

# ─────────────────────────────────────────────────────────────────────────────
# Commandes principales (conservées ou légèrement adaptées)
# ─────────────────────────────────────────────────────────────────────────────

@require_registered
@require_free
async def cmd_boites(update: Update, context: ContextTypes.DEFAULT_TYPE):
    sector = " ".join(context.args) if context.args else None
    companies = await get_all_companies(sector)
    if not companies:
        s_text = f" dans le secteur {sector}" if sector else ""
        await update.message.reply_text(alert("info", f"Aucune entreprise trouvée{s_text}."), parse_mode="HTML")
        return
    by_sector = {}
    for c in companies:
        by_sector.setdefault(c["sector"], []).append(c)
    lines = []
    for sec, comps in by_sector.items():
        lines.append(f"<b>{escape_html(sec)}</b>")
        for c in comps[:5]:
            lines.append(
                f"• <b>{escape_html(c['name'])}</b> · {fmt(c['treasury'])} · niv.{c['level']} · rep {c['reputation']}/100"
            )
        if len(comps) > 5:
            lines.append(f"<i>(+{len(comps) - 5} autres)</i>")
        lines.append("")
    sectors_text = " | ".join(SECTORS)
    lines.append(f"Secteurs : <i>{escape_html(sectors_text)}</i>")
    lines.append("Commande : le 🎮 Menu principal pour filtrer")
    await update.message.reply_text(
        card("🏢 Marché des entreprises", lines, icon="🏢", style="thick"),
        parse_mode="HTML"
    )

@require_registered
@require_free
async def cmd_infoboite(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(alert("info", "Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises."), parse_mode="HTML")
        return
    name = " ".join(context.args)
    c = await get_company_by_name(name)
    if not c:
        await update.message.reply_text(alert("error", "Entreprise introuvable."), parse_mode="HTML")
        return
    viewer_company = await get_user_company(update.effective_user.id)
    text, reply_markup = await _render_company_view(c, viewer_company, "overview")
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)

@require_registered
@require_free
async def cmd_employes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if context.args:
        c = await get_company_by_name(" ".join(context.args))
    else:
        c = await get_user_company(user.id)
    if not c:
        await update.message.reply_text("❌ Entreprise introuvable ou tu n'es pas employé.")
        return
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT u.full_name, cm.poste, cm.base_salary, cm.activity_score, cm.joined_at
            FROM company_members cm JOIN users u ON u.user_id=cm.user_id
            WHERE cm.company_id=? ORDER BY cm.activity_score DESC
        """, (c["company_id"],)) as cur:
            members = [dict(m) for m in await cur.fetchall()]
    if not members:
        await update.message.reply_text("👥 Aucun employé.")
        return
    page = 1
    if context.args and context.args[-1].isdigit():
        page = int(context.args[-1])
    lines = []
    for m in members:
        import html as _html
        lines.append(
            f"👤 <b>{escape_html(str(m['full_name']))}</b> — {escape_html(str(m['poste']))}\n"
            f"  💰 {fmt(m['base_salary'])}/paie | ⚡ {m['activity_score']} pts"
        )
    title = f"👥 <b>{escape_html(str(c['name']))} — Équipe</b>"
    text, reply_markup = await paginate_items(lines, page, 5, title)
    if reply_markup:
        await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(text, parse_mode="HTML")

@require_registered
@require_free
async def cmd_postuler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if len(context.args) < 1:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    name = " ".join(context.args[:-1]) if len(context.args) > 1 else context.args[0]
    desired_salary = 0
    if len(context.args) > 1 and context.args[-1].isdigit():
        desired_salary = int(context.args[-1])
    # Contrôles dans l'ordre historique : État → entreprise inconnue → déjà employé → doublon
    from utils.factions import get_membership as _fm
    if await _fm(user.id):
        await update.message.reply_text("❌ Tu travailles déjà pour l'État.")
        return
    c = await get_company_by_name(name)
    if not c:
        await update.message.reply_text("❌ Entreprise introuvable.")
        return
    result = await hiring_service.apply(user.id, c["company_id"], desired_salary)
    if not result["ok"]:
        text = {
            "already_employed": "❌ Tu travailles déjà dans une entreprise.",
            "already_pending": "❌ Candidature déjà en attente.",
        }.get(result["reason"], "❌ Candidature impossible.")
        await update.message.reply_text(text)
        return
    salary_text = f" avec prétention salariale de {fmt(desired_salary)}" if desired_salary else ""
    await update.message.reply_text(
        f"✅ Candidature envoyée à <b>{escape_html(escape_md(c['name']))}</b>{escape_html(salary_text)} !\n"
        f"<i>Le PDG va examiner ta candidature.</i>",
        parse_mode="HTML"
    )

@require_registered
@require_free
async def cmd_demissionner(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    result = await hiring_service.resign(user.id, user.full_name)
    if not result["ok"]:
        text = ("❌ Tu es PDG ! Utilise le menu pour fermer." if result["reason"] == "is_owner"
                else "❌ Tu ne travailles dans aucune entreprise.")
        await update.message.reply_text(text)
        return
    await update.message.reply_text(f"👋 Tu as démissionné de <b>{escape_html(escape_md(result['company_name']))}</b>.", parse_mode="HTML")

@require_registered
@require_free
async def cmd_monentreprise(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company:
        await update.message.reply_text(
            alert("error", "Tu ne travailles dans aucune entreprise. Postule à une entreprise existante, ou crée la tienne, depuis le 🎮 Menu → 🏢 Entreprises."),
            parse_mode="HTML"
        )
        return
    extra = section(
        "Mon poste",
        [
            f"👔 Poste : <b>{escape_html(company['poste'])}</b>",
            f"💰 Salaire : <b>{fmt(company.get('base_salary', 0))}</b> / paie (versé automatiquement)",
            f"⚡ Activité : <b>{company.get('activity_score', 0)} pts</b> "
            f"(gagnée en étant en service ; elle sert aux promotions et à la production)",
        ],
        icon="👔"
    )
    await update.message.reply_text(f"{text}\n{extra}", parse_mode="HTML", reply_markup=reply_markup)

@require_registered
@require_free
async def cmd_auditboite(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.args:
        company = await get_company_by_name(" ".join(context.args))
    else:
        company = await get_user_company(update.effective_user.id)
    if not company:
        await update.message.reply_text(
            alert("error", "Entreprise introuvable. Ouvre le 🎮 Menu principal ou rejoins une entreprise."),
            parse_mode="HTML"
        )
        return
    viewer_company = await get_user_company(update.effective_user.id)
    text, reply_markup = await _render_company_view(company, viewer_company, "audit")
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)

@require_registered
@require_free
async def cmd_candidatures(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        await update.message.reply_text("❌ Réservé au créateur et aux gérants.")
        return
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ca.app_id, u.full_name, u.user_id, u.diplome, u.karma, ca.desired_salary, ca.applied_at
            FROM company_applications ca JOIN users u ON u.user_id=ca.user_id
            WHERE ca.company_id=? AND ca.status='pending'
        """, (company["company_id"],)) as cur:
            apps = [dict(a) for a in await cur.fetchall()]
    if not apps:
        await update.message.reply_text("📋 Aucune candidature en attente.")
        return
    page = 1
    if context.args and context.args[-1].isdigit():
        page = int(context.args[-1])
    lines = []
    for a in apps:
        import html as _html
        lines.append(
            f"#<b>{a['app_id']}</b> {escape_html(str(a['full_name']))}\n"
            f"  🎓 {escape_html(str(a['diplome'] or 'Sans diplôme'))} | 🌟 Karma: {a['karma']} | 💰 Prétention: {fmt(a['desired_salary'])}"
        )
    title = f"📋 <b>Candidatures — {escape_html(str(company['name']))}</b>"
    text, reply_markup = await paginate_items(lines, page, 5, title)
    if reply_markup:
        await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)
    else:
        await update.message.reply_text(text, parse_mode="HTML")
    await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises Entreprises pour gérer les candidatures.")

@require_registered
@require_free
async def cmd_accepter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        await update.message.reply_text("❌ Réservé au créateur et aux gérants.")
        return
    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    try:
        app_id = int(context.args[0])
        salary = int(context.args[1])
        if salary < 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ ID ou salaire invalide.")
        return
    result = await hiring_service.accept_application(user.id, app_id, salary)
    if not result["ok"]:
        text = {
            "unknown_application": "❌ Candidature introuvable.",
            "state_employee": "❌ Ce candidat travaille désormais pour l'État.",
            "already_employed": "❌ Ce candidat travaille déjà dans une autre entreprise.",
        }.get(result["reason"], "❌ Recrutement impossible.")
        await update.message.reply_text(text)
        return
    await update.message.reply_text(f"✅ Candidature #{app_id} acceptée ! Nouvel employé au salaire de {fmt(salary)}.")

@require_registered
@require_free
async def cmd_negocier(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        await update.message.reply_text("❌ Réservé au créateur et aux gérants.")
        return
    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    try:
        app_id = int(context.args[0])
        proposed_salary = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ ID ou salaire invalide.")
        return
    result = await hiring_service.counter_offer(user.id, app_id, proposed_salary)
    if not result["ok"]:
        text = ("❌ Candidature introuvable." if result["reason"] == "unknown_application"
                else "❌ ID ou salaire invalide.")
        await update.message.reply_text(text)
        return
    await update.message.reply_text(f"📨 Contre-offre envoyée. En attente de réponse.")

@require_registered
@require_free
async def cmd_repondre_offre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    try:
        app_id = int(context.args[0])
        decision = context.args[1].lower()
    except ValueError:
        await update.message.reply_text("❌ ID invalide.")
        return
    result = await hiring_service.respond_offer(user.id, user.full_name, app_id, decision == "accepter")
    if not result["ok"]:
        text = {
            "state_employee": "❌ Tu travailles déjà pour l'État.",
            "already_employed": "❌ Tu travailles déjà dans une autre entreprise.",
        }.get(result["reason"], "❌ Aucune offre en négociation trouvée.")
        await update.message.reply_text(text)
        return
    if result["accepted"]:
        await update.message.reply_text(f"✅ Offre acceptée ! Tu rejoins l'entreprise avec un salaire de {fmt(result['salary'])}.")
    else:
        await update.message.reply_text("❌ Offre refusée.")

@require_registered
@require_free
async def cmd_refuser(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        await update.message.reply_text("❌ Réservé au créateur et aux gérants.")
        return
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    try:
        app_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID invalide.")
        return
    result = await hiring_service.refuse_application(user.id, app_id)
    if not result["ok"]:
        await update.message.reply_text("❌ Candidature introuvable.")
        return
    await update.message.reply_text(f"❌ Candidature #{app_id} refusée.")

@require_registered
@require_free
async def cmd_nommer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Réservé au PDG.")
        return
    if not update.message.reply_to_message or len(context.args) < 2:
        await update.message.reply_text(
            f"Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises."
        )
        return
    target = update.message.reply_to_message.from_user
    try:
        salary = int(context.args[0])
        if salary < 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Salaire invalide.")
        return
    poste = " ".join(context.args[1:]) or "Employé"
    result = await hiring_service.set_pay(user.id, target.id, salary, poste)
    if not result["ok"]:
        await update.message.reply_text("❌ Cet employé ne travaille pas dans ton entreprise.")
        return
    await update.message.reply_text(
        f"👔 <b>{escape_html(escape_md(target.full_name))}</b> promu(e) au poste de <b>{escape_html(escape_md(poste))}</b> !\n"
        f"💰 Nouveau salaire : {escape_html(fmt(salary))}/paie",
        parse_mode="HTML"
    )

@require_registered
@require_free
async def cmd_setsalaire(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Réservé au PDG.")
        return
    if not update.message.reply_to_message or len(context.args) != 1:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    target = update.message.reply_to_message.from_user
    try:
        new_salary = int(context.args[0])
        if new_salary < 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Montant invalide.")
        return
    result = await hiring_service.set_pay(user.id, target.id, new_salary)
    if not result["ok"]:
        await update.message.reply_text("❌ Cet employé ne travaille pas dans ton entreprise.")
        return
    await update.message.reply_text(f"💰 Salaire de {escape_md(target.full_name)} modifié à {fmt(new_salary)}/paie.")

@require_registered
@require_free
async def cmd_licencier(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        await update.message.reply_text("❌ Réservé au créateur et aux gérants.")
        return
    if not update.message.reply_to_message:
        await update.message.reply_text("❌ Réponds au message de l'employé à licencier.")
        return
    target = update.message.reply_to_message.from_user
    result = await hiring_service.fire(user.id, target.id)
    if not result["ok"]:
        text = {
            "self": "❌ Tu ne peux pas te licencier toi-même !",
            "owner_only": "❌ Seul le créateur peut licencier un gérant ou le créateur.",
            "target_not_member": "❌ Cet employé ne travaille pas dans ton entreprise.",
        }.get(result["reason"], "❌ Licenciement impossible.")
        await update.message.reply_text(text)
        return
    await update.message.reply_text(
        f"🔨 <b>{escape_html(escape_md(target.full_name))}</b> licencié(e).\n"
        f"{escape_html('💰 Indemnité versée : ' + fmt(result['severance']) if result['severance_paid'] else '⚠️ Trésorerie insuffisante pour les indemnités.')}",
        parse_mode="HTML"
    )

# ─────────────────────────────────────────────────────────────────────────────
# CRÉATION D'ENTREPRISE ATOMIQUE (Lot 5)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_creerboite(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    from utils.factions import get_membership as _fm
    if await _fm(user.id):
        await update.message.reply_text("❌ Tu travailles déjà pour l'État.")
        return
    u = await get_user(user.id)
    if not context.args or len(context.args) < 2:
        sectors_text = ", ".join(SECTORS)
        await update.message.reply_text(
            f"🏢 **Créer une entreprise**\n\n"
            f"💰 Coût de création : {fmt(COMPANY_CREATION_COST)}\n\n"
            f"Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises."
            f"Secteurs : {sectors_text}"
        )
        return
    sector = context.args[-1].capitalize()
    name = " ".join(context.args[:-1])
    matched_sector = None
    for s in SECTORS:
        if s.lower() == sector.lower():
            matched_sector = s
            break
    if not matched_sector:
        await update.message.reply_text(f"❌ Secteur inconnu. Choix : {', '.join(SECTORS)}")
        return
    if u["balance"] < COMPANY_CREATION_COST:
        await update.message.reply_text(
            f"❌ Fonds insuffisants !\n"
            f"💰 Coût : {fmt(COMPANY_CREATION_COST)}\n"
            f"💵 Ton solde : {fmt(u['balance'])}"
        )
        return

    # Vérifier si une entreprise (même dissoute) porte déjà ce nom
    try:
        async with db_connection() as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT company_id, dissolved FROM companies WHERE name = ?", (name,)) as cur:
                existing = await cur.fetchone()
            if existing:
                if existing["dissolved"] == 0:
                    raise DeferredReply(update.message.reply_text, f"❌ Une entreprise nommée '{escape_md(name)}' existe déjà et n'est pas dissoute !")
                else:
                    # Supprimer l'ancienne dissoute pour éviter conflit
                    await db.execute("DELETE FROM companies WHERE company_id = ?", (existing["company_id"],))
                    await db.execute("DELETE FROM company_members WHERE company_id = ?", (existing["company_id"],))
                    await db.execute("DELETE FROM company_shares WHERE company_id = ?", (existing["company_id"],))
                    await db.execute("DELETE FROM company_applications WHERE company_id = ?", (existing["company_id"],))
                    await db.execute("DELETE FROM company_logs WHERE company_id = ?", (existing["company_id"],))
                    await db.execute("DELETE FROM company_products WHERE company_id = ?", (existing["company_id"],))
                    await db.execute("DELETE FROM company_ads WHERE company_id = ?", (existing["company_id"],))
                    await db.execute("DELETE FROM company_invitations WHERE company_id = ?", (existing["company_id"],))
                    await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()

    # Vérifier si l'utilisateur est déjà dans une entreprise (non dissoute)
    existing_company = await get_user_company(user.id)
    if existing_company and existing_company["owner_id"] == user.id:
        await update.message.reply_text("❌ Tu diriges déjà une entreprise !")
        return

    # Transaction atomique avec BEGIN IMMEDIATE
    try:
        async with db_connection() as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                    "WHERE user_id=? AND balance>=?",
                    (
                        COMPANY_CREATION_COST,
                        COMPANY_CREATION_COST,
                        user.id,
                        COMPANY_CREATION_COST,
                    ),
                )
                if debit.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Fonds insuffisants.")

                cursor = await db.execute(
                    "INSERT INTO companies "
                    "(name,owner_id,sector,treasury,reputation,level,dissolved,created_at) "
                    "VALUES (?,?,?,0,50,1,0,?)",
                    (name, user.id, matched_sector, now()),
                )
                company_id = cursor.lastrowid
                await db.execute(
                    "INSERT INTO company_members "
                    "(user_id,company_id,poste,salary,base_salary,activity_score,joined_at) "
                    "VALUES (?,?,'PDG',0,0,0,?)",
                    (user.id, company_id, now()),
                )
                await db.execute(
                    "INSERT INTO company_shares (user_id,company_id,shares) "
                    "VALUES (?,?,100)",
                    (user.id, company_id),
                )
                await db.commit()
            except aiosqlite.IntegrityError:
                await db.rollback()
                raise DeferredReply(update.message.reply_text, "❌ Nom déjà pris ou tu appartiens déjà à une entreprise.")
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    await update.message.reply_text(
        f"🏢 <b>{escape_html(escape_md(name))} fondée !</b>\n\n"
        f"🏭 Secteur : {escape_html(matched_sector)}\n"
        f"💰 Fonds utilisés : {escape_html(fmt(COMPANY_CREATION_COST))}\n"
        f"👑 Tu es PDG !\n"
        f"⭐ Réputation initiale : 50/100\n\n"
        f"📋 <b>Prochaine étape :</b> investis dans ton entreprise depuis le menu Entreprises.",
        parse_mode="HTML"
    )

# ─────────────────────────────────────────────────────────────────────────────
# DISSOLUTION
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_dissoudreboite(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Réservé au PDG.")
        return
    if not context.args or context.args[0].lower() != "confirmer":
        await update.message.reply_text(
            f"⚠️ **DANGER : Dissolution de {escape_md(company['name'])}**\n\n"
            f"Cette action est IRRÉVERSIBLE !\n"
            f"💰 Trésorerie récupérée : {fmt(company['treasury'] // 2)} (50%)\n\n"
            f""
        )
        return
    async with db_connection() as db:
        async with db.execute("SELECT user_id FROM company_members WHERE company_id=?", (company["company_id"],)) as cur:
            members = await cur.fetchall()
    treasury_return = company["treasury"] // 2
    async with db_connection() as db:
        await db.execute("UPDATE companies SET dissolved=1 WHERE company_id=?", (company["company_id"],))
        await db.execute("DELETE FROM company_members WHERE company_id=?", (company["company_id"],))
        await db.execute("DELETE FROM company_shares WHERE company_id=?", (company["company_id"],))
        await db.commit()
    if treasury_return > 0:
        await update_balance(user.id, treasury_return)
    for (uid,) in members:
        if uid != user.id:
            await add_notification(uid, f"💀 L'entreprise <b>{escape_html(str(company['name']))}</b> a été dissoute par le PDG.")
    await update.message.reply_text(
        f"💀 **{escape_md(company['name'])} a été dissoute.**\n\n"
        f"💰 Récupéré : {fmt(treasury_return)}\n"
        f"_Une fin d'ère..._"
    )

# ─────────────────────────────────────────────────────────────────────────────
# DÉPÔT (atomique) – Lot 5
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_depotboite(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company:
        await update.message.reply_text("❌ Tu n'appartiens à aucune entreprise.")
        return
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return

    user_data = await get_user(user.id)
    amount = parse_amount(context.args[0], user_data["balance"])
    if not amount or amount <= 0:
        await update.message.reply_text("❌ Montant invalide.")
        return

    success = await company_deposit_atomic(
        user.id,
        company["company_id"],
        amount,
    )
    if not success:
        await update.message.reply_text("❌ Fonds insuffisants ou entreprise inactive.")
        return

    await update.message.reply_text(
        f"✅ {fmt(amount)} déposés dans la trésorerie de {company['name']}."
    )

# ─────────────────────────────────────────────────────────────────────────────
# RETRAIT (atomique) – Lot 5
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_retirerboite(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company:
        await update.message.reply_text("❌ Tu n'appartiens à aucune entreprise.")
        return
    if company.get("poste") not in ("PDG", "Directeur"):
        await update.message.reply_text("❌ Réservé au PDG et aux Directeurs.")
        return
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return

    amount = parse_amount(context.args[0])
    if not amount or amount <= 0:
        await update.message.reply_text("❌ Montant invalide.")
        return

    success = await company_withdraw_atomic(
        user.id,
        company["company_id"],
        amount,
    )
    if not success:
        await update.message.reply_text("❌ Trésorerie insuffisante ou accès refusé.")
        return

    await update.message.reply_text(
        f"✅ {fmt(amount)} retirés de la trésorerie."
    )

# ─────────────────────────────────────────────────────────────────────────────
# VERSER SALAIRES (atomique) – Lot 5
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_versersalaires(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "ℹ️ Les salaires sont désormais versés AUTOMATIQUEMENT chaque fin de jour de jeu, "
        "sans validation. Veille simplement à ce que la trésorerie soit suffisante "
        "(menu Entreprises → Investir). Si elle ne l'est pas, personne n'est payé et la réputation baisse."
    )

# ─────────────────────────────────────────────────────────────────────────────
# RENOMMER / CHANGER SECTEUR
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_renommer_entreprise(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Seul le PDG peut renommer l'entreprise.")
        return
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.\nCoût : 20 000 €A")
        return
    new_name = " ".join(context.args)
    cost = 20000
    if company["treasury"] < cost:
        await update.message.reply_text(f"❌ Trésorerie insuffisante. Coût : {fmt(cost)}")
        return
    existing = await get_company_by_name(new_name)
    if existing and existing["company_id"] != company["company_id"]:
        await update.message.reply_text(f"❌ Une entreprise nommée '{escape_md(new_name)}' existe déjà.")
        return
    async with db_connection() as db:
        await db.execute("UPDATE companies SET treasury = treasury - ?, name = ? WHERE company_id = ?",
                         (cost, new_name, company["company_id"]))
        await db.commit()
    await log_company_action(company["company_id"], "renommer", user.id, f"{company['name']} → {new_name}")
    await update.message.reply_text(f"✅ Entreprise renommée **{escape_md(new_name)}** (coût : {fmt(cost)}).")

@require_registered
@require_free
async def cmd_changer_secteur(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Seul le PDG peut changer le secteur.")
        return
    if not context.args:
        await update.message.reply_text(f"Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.\nSecteurs : {', '.join(SECTORS)}\nCoût : 50 000 €A")
        return
    new_sector = context.args[0].capitalize()
    if new_sector not in SECTORS:
        await update.message.reply_text(f"❌ Secteur invalide. Choix : {', '.join(SECTORS)}")
        return
    cost = 50000
    if company["treasury"] < cost:
        await update.message.reply_text(f"❌ Trésorerie insuffisante. Coût : {fmt(cost)}")
        return
    async with db_connection() as db:
        await db.execute("UPDATE companies SET treasury = treasury - ?, sector = ? WHERE company_id = ?",
                         (cost, new_sector, company["company_id"]))
        # nouvelle chaîne : lignes et équipes de l'ancien secteur n'ont plus de sens
        await db.execute("DELETE FROM company_lines WHERE company_id = ?", (company["company_id"],))
        await db.execute("UPDATE company_members SET dept = '' WHERE company_id = ?", (company["company_id"],))
        await db.commit()
    await log_company_action(company["company_id"], "changer_secteur", user.id, f"{company['sector']} → {new_sector}")
    await update.message.reply_text(f"✅ Secteur changé à **{new_sector}** (coût : {fmt(cost)}).")

# ─────────────────────────────────────────────────────────────────────────────
# LOGS, CLASSEMENT, PARTS
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_logsboite(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company:
        await update.message.reply_text("❌ Tu n'as pas d'entreprise.")
        return
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT cl.action, COALESCE(u.full_name, 'Système') as full_name, cl.details, cl.timestamp
            FROM company_logs cl LEFT JOIN users u ON u.user_id=cl.actor_id
            WHERE cl.company_id=? ORDER BY cl.timestamp DESC LIMIT 20
        """, (company["company_id"],)) as cur:
            logs = await cur.fetchall()
    if not logs:
        await update.message.reply_text("📋 Aucun log disponible.")
        return
    text = f"📋 <b>Logs — {escape_html(escape_md(company['name']))}</b>\n\n"
    from datetime import datetime
    for l in logs:
        ts = fmt_game_datetime(l["timestamp"], sep=" ")[:-3] if False else fmt_game_datetime(l["timestamp"], sep=" ")
        text += f"[{escape_html(ts)}] <b>{escape_html(escape_md(l['action']))}</b> par {escape_html(escape_md(l['full_name']))}: {escape_html(escape_md(l['details']))}\n"
    await update.message.reply_text(text, parse_mode="HTML")

@require_registered
@require_free
async def cmd_classement_boites(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_for_update
    await show_for_update(update, 'entreprises')


# ─────────────────────────────────────────────────────────────────────────────
# PRODUITS AVEC EFFETS (conservé)
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# COMMANDES POUR LES PRODUITS (donner, emoji, renommer, desc) – conservées
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# FUSIONS (avec consentement)
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# CONTRATS B2B enrichis (avec type, durée, bénéfices)
# ─────────────────────────────────────────────────────────────────────────────


# ─────────────────────────────────────────────────────────────────────────────
# MAINTENANCE (sans ventes automatiques)
# ─────────────────────────────────────────────────────────────────────────────
COMPANY_BATCH = 100


async def process_company_maintenance():
    """Maintenance quotidienne : frais généraux, réputation, nettoyage, pas de ventes auto.

    Par lots de COMPANY_BATCH entreprises ; le nombre d'employés est obtenu en UNE
    requête groupée par lot (et non une requête par entreprise).
    """
    last_id = 0
    while True:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            async with db.execute(
                "SELECT * FROM companies WHERE dissolved=0 AND company_id>? "
                "ORDER BY company_id LIMIT ?",
                (last_id, COMPANY_BATCH),
            ) as cur:
                companies = [dict(row) for row in await cur.fetchall()]
            if not companies:
                break

            ids = [c["company_id"] for c in companies]
            marks = ",".join("?" * len(ids))
            async with db.execute(
                f"SELECT company_id, COUNT(*) FROM company_members "
                f"WHERE company_id IN ({marks}) GROUP BY company_id",
                ids,
            ) as cur2:
                emp_counts = {r[0]: r[1] for r in await cur2.fetchall()}

            logs, updates = [], []
            _owner_notifs: list[tuple[int, str]] = []
            ts = now()
            for c in companies:
                emp_count = emp_counts.get(c["company_id"], 0)
                overhead = c.get("overhead", 1000)
                maintenance_cost = emp_count * overhead
                new_treasury = c["treasury"] - maintenance_cost if c["treasury"] >= maintenance_cost else 0
                new_reputation = c["reputation"]
                if c["treasury"] < maintenance_cost:
                    new_reputation = max(0, c["reputation"] - 10)
                    if new_treasury == 0:
                        logs.append((
                            c["company_id"], "maintenance_neg", c["owner_id"],
                            "Trésorerie insuffisante, perte de réputation", ts,
                        ))
                        _owner_notifs.append((
                            c["owner_id"],
                            f"⚠️ Trésorerie insuffisante — <b>{escape_html(str(c['name']))}</b>\n"
                            f"Frais généraux non prélevés ({maintenance_cost:,} €A). "
                            f"Réputation −10. Alimentez la trésorerie pour éviter la dissolution."
                        ))
                updates.append((new_treasury, new_reputation, c["company_id"]))

            if logs:
                await db.executemany(
                    "INSERT INTO company_logs (company_id, action, actor_id, details, timestamp) VALUES (?,?,?,?,?)",
                    logs,
                )
            await db.executemany(
                "UPDATE companies SET treasury=?, reputation=? WHERE company_id=?",
                updates,
            )
            await db.commit()
        for _oid, _msg in _owner_notifs:
            from database import add_notification as _an
            await _an(_oid, _msg)
        last_id = companies[-1]["company_id"]
        await asyncio.sleep(0)

    # Nettoyages globaux : une seule fois (et non une fois par entreprise)
    async with db_connection() as db:
        await db.execute(
            "UPDATE contracts SET status='expired' WHERE status='accepted' AND end_date < ?",
            (now(),),
        )
        # Annonces périmées (7 jours)
        await db.execute("DELETE FROM company_ads WHERE created_at < ?", (now() - 7 * 86400,))
        # Candidatures en négociation trop vieilles (48h)
        await db.execute(
            "UPDATE company_applications SET status='refused' WHERE status='negotiating' AND applied_at < ?",
            (now() - 48 * 3600,),
        )
        await db.commit()

# ─────────────────────────────────────────────────────────────────────────────
# CALLBACK pour la pagination des pages entreprise
# ─────────────────────────────────────────────────────────────────────────────
async def company_page_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    parts = query.data.split("_")
    if len(parts) < 4:
        return
    view = parts[2]
    try:
        company_id = int(parts[3])
    except ValueError:
        return
    company = await get_company_by_id(company_id)
    if not company:
        await query.edit_message_text("❌ Entreprise introuvable.")
        return
    viewer_company = await get_user_company(query.from_user.id)
    text, reply_markup = await _render_company_view(company, viewer_company, view)
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=reply_markup)

# ─────────────────────────────────────────────────────────────────────────────
# TRANSFERT DE PROPRIÉTÉ
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# COMMANDES FINANCIÈRES (parts)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_rd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Seul le PDG peut investir en R&D.")
        return
    if not context.args:
        await update.message.reply_text("Usage : /rd [montant]\nLe coût augmente avec le niveau actuel.")
        return
    amount = parse_amount(context.args[0], company["treasury"])
    if not amount or amount <= 0:
        await update.message.reply_text("❌ Montant invalide.")
        return
    current_level = company.get("rd_level", 0)
    spent = 0
    gained = 0
    next_cost = 50_000 * (current_level + 1)
    while spent + next_cost <= amount and spent + next_cost <= company["treasury"]:
        spent += next_cost
        gained += 1
        current_level += 1
        next_cost = 50_000 * (current_level + 1)
    if gained == 0:
        await update.message.reply_text(f"❌ Il faut au moins {fmt(next_cost)} pour atteindre le prochain niveau de R&D.")
        return
    new_level = company.get("rd_level", 0) + gained
    async with db_connection() as db:
        await db.execute(
            "UPDATE companies SET treasury=treasury-?, rd_level=rd_level+? WHERE company_id=?",
            (spent, gained, company["company_id"])
        )
        await db.commit()
    await log_company_action(company["company_id"], "rd_invest", user.id, f"+{gained} niveaux -> {new_level}")
    await update.message.reply_text(
        card(
            "🔬 R&D améliorée",
            [
                f"Niveaux gagnés : <b>+{gained}</b>",
                f"Niveau actuel : <b>{new_level}</b>",
                f"Investissement : <b>{fmt(spent)}</b>",
                f"Prochain coût : <b>{fmt(next_cost)}</b>",
            ],
            icon="🔬", style="thick"
        ),
        parse_mode="HTML"
    )

@require_registered
@require_free
async def cmd_setoverhead(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Seul le PDG peut modifier les frais généraux.")
        return
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.\nMontant par employé (ex: 1000)")
        return
    try:
        overhead = int(context.args[0])
        if overhead < 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Montant invalide.")
        return
    await update_company_field(company["company_id"], "overhead", overhead)
    await update.message.reply_text(f"🏢 Frais généraux fixés à {fmt(overhead)} par employé (déduits quotidiennement).")

@require_registered
@require_free
async def cmd_annonce(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        await update.message.reply_text("❌ Réservé au créateur et aux gérants.")
        return
    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    poste = context.args[0]
    try:
        salary = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Salaire invalide.")
        return
    async with db_connection() as db:
        await db.execute(
            "INSERT OR REPLACE INTO company_ads (company_id, poste, salary, created_at) VALUES (?,?,?,?)",
            (company["company_id"], poste, salary, now())
        )
        await db.commit()
    await update.message.reply_text(
        f"📢 <b>Annonce publiée</b>\n"
        f"Entreprise : {escape_html(escape_md(company['name']))}\n"
        f"Poste : {escape_html(escape_md(poste))}\n"
        f"Salaire : {escape_html(fmt(salary))}\n\n"
        f"Les joueurs peuvent postuler depuis 🎮 Menu → 🏢 Entreprises.",
        parse_mode="HTML"
    )

@require_registered
@require_free
async def cmd_emplois(update: Update, context: ContextTypes.DEFAULT_TYPE):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT a.*, c.name as company_name
            FROM company_ads a JOIN companies c ON c.company_id=a.company_id
            WHERE a.created_at > ?
            ORDER BY a.created_at DESC LIMIT 20
        """, (now() - 7*86400,)) as cur:
            ads = await cur.fetchall()
    if not ads:
        await update.message.reply_text("📢 Aucune annonce récente.")
        return
    text = "📢 <b>Offres d'emploi</b>\n\n"
    for a in ads:
        text += f"🏢 <b>{escape_html(escape_md(a['company_name']))}</b> – Poste: {escape_html(escape_md(a['poste']))} – Salaire: {escape_html(fmt(a['salary']))}\n"
        text += f"   Postulez depuis 🎮 Menu → 🏢 Entreprises\n\n"
    await update.message.reply_text(text, parse_mode="HTML")

@require_registered
@require_free
async def cmd_inviter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or not await can_manage(user.id, company):
        await update.message.reply_text("❌ Seul le PDG peut inviter.")
        return
    if not update.message.reply_to_message or len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    target = update.message.reply_to_message.from_user
    if target.id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas t'inviter toi-même.")
        return
    try:
        salary = int(context.args[0])
        poste = " ".join(context.args[1:])
        if salary < 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Salaire invalide.")
        return
    if await get_user_company(target.id):
        await update.message.reply_text("❌ Cette personne travaille déjà dans une entreprise.")
        return
    async with db_connection() as db:
        await db.execute(
            "DELETE FROM company_invitations WHERE user_id=? AND company_id=? AND status='pending'",
            (target.id, company["company_id"])
        )
        await db.execute(
            "INSERT INTO company_invitations (user_id, company_id, poste, salary, invited_by, invited_at, status) VALUES (?,?,?,?,?,?,'pending')",
            (target.id, company["company_id"], poste, salary, user.id, now())
        )
        await db.commit()
    await add_notification(target.id, f"📩 Vous avez reçu une invitation de <b>{escape_html(str(company['name']))}</b> pour le poste de {escape_html(str(poste))} avec un salaire de {fmt(salary)}. Ouvrez cette action depuis 🎮 Menu → 🏢 Entreprises.")
    await update.message.reply_text(f"✅ Invitation envoyée à {escape_md(target.full_name)}.")

@require_registered
@require_free
async def cmd_repondre_invitation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    from utils.factions import get_membership as _fm
    if await _fm(user.id):
        await update.message.reply_text("❌ Tu travailles déjà pour l'État.")
        return
    if len(context.args) != 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    try:
        company_id = int(context.args[0])
        decision = context.args[1].lower()
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return
    async with Outbox() as _out:
        async with db_connection() as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM company_invitations WHERE user_id=? AND company_id=? AND status='pending'",
                (user.id, company_id)
            ) as cur:
                inv = await cur.fetchone()
            if not inv:
                _out.add(update.message.reply_text, "❌ Aucune invitation en attente pour cette entreprise.")
                return
            if decision == "accepter":
                if await get_user_company(user.id):
                    _out.add(update.message.reply_text, "❌ Tu as déjà une entreprise, tu ne peux pas accepter.")
                    return
                await db.execute("UPDATE company_invitations SET status='accepted' WHERE user_id=? AND company_id=?", (user.id, company_id))
                await db.execute("""
                INSERT INTO company_members (user_id, company_id, poste, base_salary, joined_at, activity_score)
                VALUES (?,?,?,?,?,0)
            """, (user.id, company_id, inv["poste"], inv["salary"], now()))
                await db.commit()
                await add_notification(inv["invited_by"], f"{user.full_name} a accepté l'invitation pour rejoindre **{inv['poste']}** dans votre entreprise.")
                _out.add(update.message.reply_text, f"✅ Vous avez rejoint l'entreprise en tant que {escape_md(inv['poste'])} avec un salaire de {fmt(inv['salary'])}.")
            else:
                await db.execute("UPDATE company_invitations SET status='refused' WHERE user_id=? AND company_id=?", (user.id, company_id))
                await db.commit()
                await add_notification(inv["invited_by"], f"{user.full_name} a refusé votre invitation.")
                _out.add(update.message.reply_text, "❌ Invitation refusée.")

# ─────────────────────────────────────────────────────────────────────────────
# FORMER (financer une formation pour un employé)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_former(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Seul le PDG peut financer une formation.")
        return
    if not update.message.reply_to_message or len(context.args) < 1:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    target = update.message.reply_to_message.from_user
    try:
        amount = int(context.args[0])
        if amount <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Montant invalide.")
        return
    if company["treasury"] < amount:
        await update.message.reply_text("❌ Trésorerie insuffisante.")
        return
    async with db_connection() as db:
        await db.execute("UPDATE companies SET treasury=treasury-? WHERE company_id=?", (amount, company["company_id"]))
        await db.execute("UPDATE company_members SET activity_score = activity_score + ? WHERE user_id=? AND company_id=?", (amount // 1000, target.id, company["company_id"]))
        await db.commit()
    await log_company_action(company["company_id"], "formation", user.id, f"{target.full_name} pour {fmt(amount)}")
    await update.message.reply_text(f"🎓 Formation financée pour {escape_md(target.full_name)} (+{amount//1000} pts d'activité).")

# ─────────────────────────────────────────────────────────────────────────────
# PRIME (donner une prime à un employé)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_prime(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Seul le PDG peut donner une prime.")
        return
    if not update.message.reply_to_message or len(context.args) < 1:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
        return
    target = update.message.reply_to_message.from_user
    try:
        amount = int(context.args[0])
        if amount <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Montant invalide.")
        return
    if company["treasury"] < amount:
        await update.message.reply_text("❌ Trésorerie insuffisante.")
        return
    async with db_connection() as db:
        await db.execute("UPDATE companies SET treasury=treasury-? WHERE company_id=?", (amount, company["company_id"]))
        await db.commit()
    await update_balance(target.id, amount)
    await log_company_action(company["company_id"], "prime", user.id, f"{target.full_name} ({fmt(amount)})")
    await update.message.reply_text(f"🎁 Prime de {fmt(amount)} versée à {escape_md(target.full_name)}.")
    


# ═══════════════════════════════════════════════════════════════════
#              🏢 MENU INTERACTIF ENTREPRISES
# ═══════════════════════════════════════════════════════════════════
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


async def show_comp_list(query, user_id: int):
    companies = await get_all_companies()
    if not companies:
        await safe_edit(
            query,
            card("🏢 ENTREPRISES", ["<i>Aucune entreprise active.</i>"], icon="🏢", style="thick"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="comp_menu")]])
        )
        return

    by_sector = {}
    for c in companies:
        by_sector.setdefault(c["sector"], []).append(c)

    body = []
    for sec, comps in by_sector.items():
        body.append(f"<b>{escape_html(sec)}</b>")
        for c in comps[:5]:
            body.append(
                f"  • <b>{escape_html(c['name'])}</b> · {fmt(c['treasury'])} · niv.{c['level']} · rep {c['reputation']}/100"
            )
        if len(comps) > 5:
            body.append(f"  <i>(+{len(comps) - 5} autres)</i>")
        body.append("")

    body.append(f"💡 Ouvre le 🎮 Menu principal pour plus de détails.")

    await safe_edit(
        query,
        card("🏢 ENTREPRISES ACTIVES", body, icon="🏢", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📝 Postuler", callback_data="comp_postuler_info")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="comp_menu")],
        ])
    )


async def show_comp_view_mine(query, user_id: int):
    company = await get_user_company(user_id)
    if not company:
        await safe_edit(query, "❌ Tu n'es dans aucune entreprise.")
        return

    # Rendu standard via _render_company_view
    text, reply_markup = await _render_company_view(company, company, "overview")
    await safe_edit(query, text, parse_mode="HTML", reply_markup=reply_markup)


async def show_comp_rank_view(query, user_id: int):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_in_query
    await show_in_query(query, user_id, 'entreprises')


# ─── Infos génériques (info-bulles) ───────────────────────────────
INFO_PAGES = {
    "comp_menu_admin": (
        "⚙️ GESTION",
        ["Renommer, changer de secteur, régler les frais fixes ou dissoudre l'entreprise."],
        "⚙️", "thick",
    ),
    "comp_create_info": (
        "🏭 CRÉER UNE ENTREPRISE",
        [
            f"💰 Coût de création : <b>{fmt(COMPANY_CREATION_COST)}</b>",
            "",
            "<b>Commande :</b>",
            "  • bouton du menu Entreprises",
            "",
            "<b>Secteurs disponibles :</b>",
            ", ".join(SECTORS),
        ],
        "🏭", "thick",
    ),
    "comp_postuler_info": (
        "📝 POSTULER À UNE ENTREPRISE",
        [
            "<b>Commande :</b>",
            "  • bouton du menu Entreprises",
            "",
            "Le PDG recevra ta candidature et pourra l'accepter ou la refuser.",
        ],
        "📝", "round",
    ),
    "comp_products_info": (
        "📦 PRODUITS",
        [
            "<b>Voir le catalogue :</b>",
            "  • bouton du menu Entreprises",
            "",
            "<b>Gérer un produit (prix, nom, description, emoji, retrait) :</b>",
            "  • bouton du menu Entreprises",
            "  Effets : heal, energy, xp, money, buff",
        ],
        "📦", "thick",
    ),
    "comp_team_info": (
        "👥 ÉQUIPE",
        [
            "<b>Voir les employés :</b>",
            "  • bouton du menu Entreprises",
            "",
            "<b>Candidatures, inviter, salaire, prime, formation, licencier :</b>",
            "  • bouton du menu Entreprises",
            "  (inviter/licencier : en répondant au message du joueur)",
        ],
        "👥", "thick",
    ),
    "comp_finance_info": (
        "💰 FINANCES",
        [
            "<b>Trésorerie — déposer, retirer, payer les salaires :</b>",
            "  • bouton du menu Entreprises",
            "",
            "<b>Parts & dividendes — répartition, acheter, vendre, verser :</b>",
            "  • bouton du menu Entreprises",
        ],
        "💰", "thick",
    ),
    "comp_rd_info": (
        "🔬 R&D",
        [
            "<b>Investir en R&D :</b>",
            "  <code>/rd [montant]</code>",
            "",
            "Chaque niveau de R&D améliore la qualité de tes produits et augmente leur valeur.",
            "",
            "<b>Coût du niveau suivant :</b>",
            "  50 000 × (niveau actuel + 1)",
        ],
        "🔬", "thick",
    ),
    "comp_annonce_info": (
        "📢 ANNONCE D'EMPLOI",
        [
            "<b>Publier une annonce :</b>",
            "  • bouton du menu Entreprises",
            "",
            "<b>Voir les annonces :</b>",
            "  • bouton du menu Entreprises",
            "",
            "Durée : 7 jours",
        ],
        "📢", "round",
    ),
    "comp_candidatures_info": (
        "📋 CANDIDATURES",
        [
            "<b>Voir, accepter, refuser ou négocier une candidature :</b>",
            "  • bouton du menu Entreprises",
        ],
        "📋", "round",
    ),
    "comp_b2b_info": (
        "🤝 B2B & FUSIONS",
        [
            "<b>Proposer, répondre ou négocier un contrat :</b>",
            "  • bouton du menu Entreprises",
            "  Types : service, fourniture, partenariat, licence",
            "",
            "<b>Fusions :</b>",
            "  • bouton du menu Entreprises",
        ],
        "🤝", "thick",
    ),
    "comp_paie_info": (
        "💼 MA PAIE",
        [
            "Tes salaires sont versés automatiquement par le PDG.",
            "",
            "<b>Voir ton poste :</b>",
            "  • bouton du menu Entreprises",
            "",
            "<b>Démissionner :</b>",
            "  • bouton du menu Entreprises",
        ],
        "💼", "round",
    ),
}


async def show_comp_info_page(query, user_id: int, key: str):
    page = INFO_PAGES.get(key)
    if not page:
        await safe_edit(query, "❌ Page inconnue.")
        return
    title, body_lines, icon, style = page
    from utils.forms import form_rows
    rows = form_rows(key)
    if rows:
        # Les actions sont des boutons : on retire les lignes « tape /commande »
        import re as _re
        body_lines = [l for l in body_lines
                      if "<code>/" not in l and not _re.match(r"^\s*<b>.*:</b>\s*$", l)]
        body_lines = [*body_lines, "", "<i>Choisis une action ci-dessous.</i>"]
    rows = [*rows, [InlineKeyboardButton("⬅️ Retour", callback_data="comp_menu")]]
    await safe_edit(
        query,
        card(title, body_lines, icon=icon, style=style),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(rows)
    )


async def companies_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routeur des callbacks 'comp_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "comp_menu":
        from handlers.hub import open_zone; await open_zone(query, "companies")
        return
    if data == "comp_list":
        await show_comp_list(query, user_id)
        return
    if data == "comp_view_mine":
        await show_comp_view_mine(query, user_id)
        return
    if data == "comp_rank_view":
        await show_comp_rank_view(query, user_id)
        return
    if data in INFO_PAGES:
        await show_comp_info_page(query, user_id, data)
        return


# ══════════════════════════════════════════════════════════════════════
#  PRODUCTION — fiche et niveau (ex handlers/production.py)
# ══════════════════════════════════════════════════════════════════════
from config import SECTOR_PRODUCTION, PRODUCTION_LEVELS
from utils.payroll import get_level, set_level, get_stock
from utils.company_roles import can_manage
from utils.notify import notify as _notify_prod
from utils.helpers import safe_edit


@require_registered
@require_free
async def cmd_production(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company:
        await update.message.reply_text("❌ Tu ne travailles dans aucune entreprise. 🏢 Rejoins-en une depuis le menu Entreprises.")
        return
    cid = company["company_id"]
    if context.args:                                   # formulaire « Niveau de production »
        if not await can_manage(user.id, company):
            await update.message.reply_text("❌ Réservé au créateur et aux gérants.")
            return
        try:
            new_level = int(context.args[0])
        except ValueError:
            new_level = 0
        if new_level not in PRODUCTION_LEVELS:
            await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises.")
            return
        await set_level(cid, new_level)
        lv = PRODUCTION_LEVELS[new_level]
        await update.message.reply_text(
            f"✅ Production <b>{lv['name'].lower()}</b> : unités ×{lv['units']}, coût ×{lv['cost']}.",
            parse_mode="HTML")
        return
    from handlers.chain import co_view
    text, markup = await co_view(user.id)
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=markup)