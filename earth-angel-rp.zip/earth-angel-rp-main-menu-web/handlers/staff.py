# handlers/staff.py — 🛡️ PANNEAU STAFF UNIQUE (remplace /admin, /admin_help, /adminpanel et les nominations en triple)
"""
Point d'entrée unique du staff :
  /admin (alias : /admin_help, /adminpanel, /monrole)  → panneau à boutons (préfixe `stf:`)
  /staff_nommer <rôle> @u · /revoquer @u <motif> · /staff_promouvoir @u   (/nommer et /promouvoir restent ceux des entreprises)
  /recours <message>                                    → recours d'un ancien staff auprès du Lead Principal
  /presence · /passation pb | à surveiller | suggestions → Admin N1/N2 : arrivée au créneau, formulaire de fin
  /creneau @u A|B|C|D|aucun · /creneaux · /presences · /passations → Lead Staff Global / Game Leader
  /audit @u                                              → qui a fait quoi, à qui (Admin N2+)
  /staff_liste · /staff_history @u
Les anciennes commandes (/nommer_admin_n1, /lsg_revoquer, /gl_promouvoir_admin…) restent comme alias.
La logique (droits, nominations, recours) vit dans utils/staff.py.
"""
from __future__ import annotations

import logging

import aiosqlite
from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M, Update
from telegram.ext import ContextTypes

from config import (STAFF_SLOTS, GAME_LEADER_IDS, ADMIN_N1_IDS, ADMIN_N2_IDS, LEAD_PRINCIPAL_IDS, LEAD_STAFF_GLOBAL_IDS,
                    LEAD_STUDIO_IDS, ROLE_HIERARCHY, role_level)
from database import db_connection, get_admin_role_history, get_user, list_admin_roles, now
from utils import staff as st
from utils.aesthetics import card
from utils.decorators import admin_n1_only, admin_n2_only, game_leader_only, get_user_role_async
from utils.gametime import game_seconds_to_real
from utils.helpers import escape_html, fmt, safe_edit

logger = logging.getLogger(__name__)
CB = "stf:"


# ─────────────────────────────────────────────────────────────────────────────
#  Outils
# ─────────────────────────────────────────────────────────────────────────────
async def _target(update: Update, args: list[str]):
    """(id, nom) depuis une réponse, un @pseudo ou un id numérique (premier argument). None si introuvable."""
    msg = update.effective_message
    if msg and msg.reply_to_message and msg.reply_to_message.from_user:
        u = msg.reply_to_message.from_user
        return u.id, u.full_name, args
    if not args:
        return None
    from utils.user_lookup import find_user       # ID d'abord, puis @pseudo
    row = await find_user(args[0])
    return (row["user_id"], row["full_name"] or "Joueur", args[1:]) if row else None


async def _reply(update: Update, text: str, markup: M | None = None) -> None:
    q = update.callback_query
    if q:
        await safe_edit(q, text, reply_markup=markup)
    else:
        await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


def _nav(role: str, extra: list[list[B]] | None = None) -> M:
    rows = list(extra or [])
    rows.append([B("🛡️ Panneau", callback_data=CB + "home"), B("🎮 Menu", callback_data="menu_main")])
    return M(rows)


# ─────────────────────────────────────────────────────────────────────────────
#  Écrans
# ─────────────────────────────────────────────────────────────────────────────
async def _stats_lines() -> list[str]:
    qs = {"👥 Joueurs": "SELECT COUNT(*) FROM users WHERE registered=1", "🚫 Bannis": "SELECT COUNT(*) FROM users WHERE banned=1",
          "📩 Signalements en attente": "SELECT COUNT(*) FROM reports WHERE status='pending'",
          "🏢 Entreprises": "SELECT COUNT(*) FROM companies WHERE dissolved=0",
          "💰 Masse monétaire": "SELECT COALESCE(SUM(balance),0) FROM users WHERE registered=1"}
    out = []
    async with db_connection() as db:
        for name, q in qs.items():
            try:
                async with db.execute(q) as cur:
                    n = (await cur.fetchone())[0]
                out.append(f"{name} : <b>{fmt(n)}</b>")
            except Exception:
                logger.debug("stat %s indisponible", name, exc_info=True)
    return out


async def show_home(update: Update, note: str = "") -> None:
    uid = update.effective_user.id
    role = await get_user_role_async(uid)
    if role == "PLAYER":
        await _reply(update, "🚫 Panneau réservé au staff.", None)
        return
    lvl, top = role_level(role), len(ROLE_HIERARCHY) - 1
    body = [f"{st.badge(role)} <b>{st.label(role)}</b>", f"<code>{'█' * lvl}{'░' * (top - lvl)}</code> niveau {lvl}/{top}",
            "<i>Chaque niveau hérite des permissions du niveau inférieur.</i>",
            "📝 <i>Toute sanction ou correction exige un motif, envoyé tel quel au joueur.</i>"]
    if note:
        body.insert(0, note)
    if lvl >= role_level("GAME_LEADER"):
        body += ["", *await _stats_lines()]
    rows = []
    sh = await st.current_shift(uid) if role in ("ADMIN_N1", "ADMIN_N2") else None
    if sh:
        body.insert(2, f"🕘 {st.slot_label(sh['slot'])} — " + (f"arrivée confirmée à {st.fmt_hm(sh['confirmed_at'])}"
                                                               if sh["confirmed_at"] else "<b>arrivée à confirmer</b>"))
        if not sh["confirmed_at"]:
            rows.append([B("✅ Confirmer mon arrivée", callback_data=CB + "presence")])
    cats = st.visible_catalog(role)
    for i in range(0, len(cats), 2):
        rows.append([B(f"{c[1]} {c[2]}", callback_data=f"{CB}cat:{c[0]}") for c in cats[i:i + 2]])
    rows.append([B("👥 Équipe", callback_data=CB + "team"), B("📜 Journal", callback_data=CB + "logs")])
    if lvl >= role_level("GAME_LEADER"):
        rows.append([B("🕘 Créneaux", callback_data=CB + "slots"), B("📊 Présences", callback_data=CB + "att")])
    if lvl >= role_level("GAME_LEADER"):
        rows.append([B("⚙️ Réglages du jeu & économie", callback_data="gc:home")])
    rows.append([B("🎮 Menu", callback_data="menu_main")])
    await _reply(update, card("PANNEAU STAFF", body, icon="🛡️", style="thick"), M(rows))


async def _show_cat(update: Update, key: str) -> None:
    role = await get_user_role_async(update.effective_user.id)
    sec = next((c for c in st.visible_catalog(role) if c[0] == key), None)
    if not sec:
        await _reply(update, "🚫 Section non accessible à ton rang.", _nav(role))
        return
    body = [f"<i>Niveau requis : {st.label(sec[3])}</i>", ""] + [f"  {escape_html(l)}" for l in sec[4]]
    body.append("\n<i>@u = @pseudo, id numérique, ou réponse à son message.</i>")
    await _reply(update, card(f"{sec[1]} {sec[2].upper()}", body, icon=sec[1], style="thick"), _nav(role))


async def _show_team(update: Update) -> None:
    role = await get_user_role_async(update.effective_user.id)
    static = {"LEAD_PRINCIPAL": LEAD_PRINCIPAL_IDS, "LEAD_STUDIO": LEAD_STUDIO_IDS, "LEAD_STAFF_GLOBAL": LEAD_STAFF_GLOBAL_IDS,
              "GAME_LEADER": GAME_LEADER_IDS, "ADMIN_N2": ADMIN_N2_IDS, "ADMIN_N1": ADMIN_N1_IDS}
    members: dict[str, dict[int, str]] = {r: {} for r in st.STAFF_ROLES_DESC}
    for r, ids in static.items():
        for uid in ids:
            members[r][uid] = (await get_user(uid) or {}).get("full_name") or f"#{uid}"
    for row in await list_admin_roles(include_revoked=False):
        if row["role"] in members:
            members[row["role"]].setdefault(row["user_id"], row.get("full_name") or f"#{row['user_id']}")
    body = []
    for r in st.STAFF_ROLES_DESC:
        if not members[r]:
            continue
        body.append(f"<b>{st.badge(r)} {st.label(r)}</b>")
        for uid, name in members[r].items():
            body.append(f"  • {escape_html(name)} <code>{uid}</code>")
        body.append("")
    await _reply(update, card("ÉQUIPE DU STAFF", body or ["<i>Aucun staff enregistré.</i>"], icon="👥", style="thick"), _nav(role))


async def _show_slots(update: Update) -> None:
    role = await get_user_role_async(update.effective_user.id)
    cov = await st.coverage()
    body = []
    for k, (a, b, lab) in STAFF_SLOTS.items():
        n1, n2 = cov[k]["ADMIN_N1"], cov[k]["ADMIN_N2"]
        body.append(f"<b>{st.slot_label(k)}</b> — 🟢 N1 : {len(n1)} · 🔴 N2 : {len(n2)}" + ("" if n1 and n2 else "  ⚠️ <i>couverture incomplète</i>"))
        for uid in n1 + n2:
            body.append(f"   • {escape_html(await st._name(uid))} <code>{uid}</code>")
    body.append("\n<i>Règle : au moins 1 Admin N1 en service et 1 Admin N2 joignable par créneau.</i>")
    await _reply(update, card("COUVERTURE DES CRÉNEAUX", body, icon="🕘", style="thick"), _nav(role))


async def _show_attendance(update: Update) -> None:
    role = await get_user_role_async(update.effective_user.id)
    rows = await st.attendance(7)
    body = []
    for r in rows:
        late = int((r["late"] or 0) // 60)
        body.append(f"• {escape_html(await st._name(r['user_id']))} : {r['p'] or 0}/{r['n']} présent · "
                    f"{r['a'] or 0} absence(s) · retard moyen {late} min")
    await _reply(update, card("PRÉSENCES — 7 JOURS", body or ["<i>Aucun créneau terminé sur la période.</i>"],
                              icon="📊", style="thick"), _nav(role))


async def _show_logs(update: Update) -> None:
    uid = update.effective_user.id
    role = await get_user_role_async(uid)
    sees_all = role == "LEAD_PRINCIPAL"
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        q = "SELECT admin_id, action, target_id, details, timestamp FROM admin_logs " + \
            ("" if sees_all else "WHERE admin_id=? ") + "ORDER BY log_id DESC LIMIT 12"
        async with db.execute(q, () if sees_all else (uid,)) as cur:
            rows = await cur.fetchall()
    body = []
    for r in rows:
        who = f"<code>{r['admin_id']}</code> " if sees_all else ""
        tgt = f" → <code>{r['target_id']}</code>" if r["target_id"] else ""
        body.append(f"• {who}<b>{escape_html(str(r['action']))}</b>{tgt} {escape_html(str(r['details'] or ''))[:60]}")
    await _reply(update, card("JOURNAL" + (" (tout le staff)" if sees_all else " (tes actions)"),
                              body or ["<i>Rien à afficher.</i>"], icon="📜", style="thick"), _nav(role))


# ─────────────────────────────────────────────────────────────────────────────
#  Commandes
# ─────────────────────────────────────────────────────────────────────────────
async def cmd_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update)


def _usage(text: str) -> str:
    return f"❌ {text}"


@game_leader_only
async def cmd_nommer(update: Update, context: ContextTypes.DEFAULT_TYPE, role: str | None = None):
    args = list(context.args or [])
    if role is None:
        role = st.ROLE_ALIASES.get(args.pop(0).lower()) if args else None
    if not role:
        await update.message.reply_text(_usage("Usage : <code>/staff_nommer rôle @pseudo</code> — rôles : "
                                               "lead_staff · game_leader · n2 · n1."), parse_mode="HTML")
        return
    t = await _target(update, args)
    if not t:
        await update.message.reply_text(_usage("Indique un @pseudo, un id, ou réponds à son message."))
        return
    ok, msg = await st.nominate(update.effective_user.id, t[0], role)
    await update.message.reply_text(
        card("NOMINATION", [f"Joueur : <b>{escape_html(t[1])}</b>", msg], icon="🎖️", style="stars") if ok else f"❌ {msg}",
        parse_mode="HTML")


@game_leader_only
async def cmd_revoquer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    t = await _target(update, list(context.args or []))
    if not t:
        await update.message.reply_text(_usage("Usage : <code>/revoquer @pseudo motif</code> (le motif est obligatoire)"), parse_mode="HTML")
        return
    ok, msg = await st.revoke(update.effective_user.id, t[0], " ".join(t[2]))
    await update.message.reply_text(
        card("RÉVOCATION", [f"Joueur : <b>{escape_html(t[1])}</b>", f"Ancien rôle : {msg}"], icon="❌", style="thick")
        if ok else f"❌ {msg}", parse_mode="HTML")


@game_leader_only
async def cmd_promouvoir(update: Update, context: ContextTypes.DEFAULT_TYPE):
    t = await _target(update, list(context.args or []))
    if not t:
        await update.message.reply_text(_usage("Usage : <code>/staff_promouvoir @pseudo</code>"), parse_mode="HTML")
        return
    ok, msg = await st.promote(update.effective_user.id, t[0])
    await update.message.reply_text(
        card("PROMOTION", [f"Joueur : <b>{escape_html(t[1])}</b>", f"Nouveau rang : {msg}"], icon="⬆️", style="stars")
        if ok else f"❌ {msg}", parse_mode="HTML")


async def cmd_recours(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ok, msg = await st.appeal(update.effective_user.id, " ".join(context.args or []))
    await update.effective_message.reply_text(("✅ " if ok else "❌ ") + msg)


@admin_n1_only
async def cmd_presence(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ok, msg = await st.confirm_presence(update.effective_user.id)
    await update.effective_message.reply_text(msg if ok else f"❌ {msg}")


@admin_n1_only
async def cmd_passation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Formulaire de fin de créneau : la capture est automatique, l'Admin ajoute 3 champs libres."""
    uid = update.effective_user.id
    sh = await st.last_reportable(uid)
    if not sh:
        await update.effective_message.reply_text("❌ Aucun créneau terminé à rapporter.")
        return
    parts = [p.strip() for p in " ".join(context.args or []).split("|")]
    if len(parts) < 3:
        cap = await st.capture(uid, sh["confirmed_at"], sh["ends_at"])
        await update.effective_message.reply_text(card(
            "FORMULAIRE DE PASSATION", [f"{st.slot_label(sh['slot'])} · {st.fmt_hm(sh['starts_at'])}–{st.fmt_hm(sh['ends_at'])}",
                                        "<i>Capturé automatiquement :</i>", *st.capture_lines(cap), "",
                                        "Complète puis envoie :", "<code>/passation problèmes | joueurs à surveiller | suggestions</code>",
                                        "<i>Mets « - » pour un champ vide.</i>"], icon="📋", style="thick"), parse_mode="HTML")
        return
    clean = [("" if p in ("-", "—") else p[:400]) for p in parts[:3]]
    ok, msg = await st.submit_report(uid, *clean)
    await update.effective_message.reply_text(("✅ " if ok else "❌ ") + msg)


@game_leader_only
async def cmd_creneau(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = list(context.args or [])
    if not args:
        await update.effective_message.reply_text(_usage("Usage : <code>/creneau @pseudo A|B|C|D|aucun</code>"), parse_mode="HTML")
        return
    t = await _target(update, args)
    if not t or not t[2]:
        await update.effective_message.reply_text(_usage("Usage : <code>/creneau @pseudo A|B|C|D|aucun</code>"), parse_mode="HTML")
        return
    val = t[2][0].upper()
    ok, msg = await st.set_slot(update.effective_user.id, t[0], None if val in ("AUCUN", "0", "-") else val)
    await update.effective_message.reply_text(f"✅ {escape_html(t[1])} : {msg}" if ok else f"❌ {msg}", parse_mode="HTML")


@game_leader_only
async def cmd_creneaux(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _show_slots(update)


@game_leader_only
async def cmd_presences(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _show_attendance(update)


@game_leader_only
async def cmd_passations(update: Update, context: ContextTypes.DEFAULT_TYPE):
    n = min(10, int(context.args[0])) if context.args and context.args[0].isdigit() else 5
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT shift_id FROM staff_shifts WHERE status='reported' ORDER BY report_at DESC LIMIT ?", (n,)) as cur:
            ids = [r[0] for r in await cur.fetchall()]
    if not ids:
        await update.effective_message.reply_text("📋 Aucune passation reçue.")
        return
    for sid in ids:
        await update.effective_message.reply_text(await st.render_report(sid))


@admin_n2_only
async def cmd_audit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Qui a fait quoi, à qui : actions subies par un joueur, et (Game Leader+) actions menées par lui."""
    t = await _target(update, list(context.args or []))
    if not t:
        await update.effective_message.reply_text(_usage("Usage : <code>/audit @pseudo</code>"), parse_mode="HTML")
        return
    role = await get_user_role_async(update.effective_user.id)

    def line(r):
        ts = r["real_ts"]
        when = (st.datetime.fromtimestamp(ts, st._tz()).strftime("%d/%m %H:%M") if ts else "—")
        return f"{when} · <code>{r['admin_id']}</code> <b>{escape_html(str(r['action']))}</b> {escape_html(str(r['details'] or ''))[:70]}"

    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT admin_id, action, details, real_ts FROM admin_logs WHERE target_id=? "
                              "ORDER BY log_id DESC LIMIT 15", (t[0],)) as cur:
            on = await cur.fetchall()
        by = []
        if role_level(role) >= role_level("GAME_LEADER"):
            async with db.execute("SELECT admin_id, action, details, real_ts FROM admin_logs WHERE admin_id=? "
                                  "ORDER BY log_id DESC LIMIT 15", (t[0],)) as cur:
                by = await cur.fetchall()
    body = ["<b>Actions subies (par qui ?)</b>"] + ([line(r) for r in on] or ["<i>Aucune.</i>"])
    if role_level(role) >= role_level("GAME_LEADER"):
        body += ["", "<b>Actions menées par lui/elle</b>"] + ([line(r) for r in by] or ["<i>Aucune.</i>"])
    await update.effective_message.reply_text(card(f"HISTORIQUE — {escape_html(t[1])}", body, icon="🔎", style="thick"),
                                              parse_mode="HTML")


@admin_n1_only
async def cmd_staff_liste(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _show_team(update)


@admin_n1_only
async def cmd_staff_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    t = await _target(update, list(context.args or []))
    if not t:
        await update.message.reply_text(_usage("Usage : <code>/staff_history @pseudo</code>"), parse_mode="HTML")
        return
    hist = await get_admin_role_history(t[0])
    if not hist:
        await update.message.reply_text(f"📜 <b>{escape_html(t[1])}</b> n'a jamais eu de rôle staff.", parse_mode="HTML")
        return
    body = []
    for r in hist[:15]:
        start = game_seconds_to_real(max(0, now() - r["assigned_at"])) // 86400
        if r["revoked_at"]:
            end = game_seconds_to_real(max(0, now() - r["revoked_at"])) // 86400
            body.append(f"<s>{st.label(r['role'])}</s> · nommé il y a {start} j · terminé il y a {end} j")
        else:
            body.append(f"✅ <b>{st.label(r['role'])}</b> · depuis {start} j")
    await update.message.reply_text(card(f"HISTORIQUE — {escape_html(t[1])}", body, icon="📜", style="thick"),
                                    parse_mode="HTML")


# ─────────────────────────────────────────────────────────────────────────────
#  Alias des anciennes commandes (nommer_admin_n1, lsg_revoquer, gl_promouvoir_admin…)
# ─────────────────────────────────────────────────────────────────────────────
def _alias_nommer(role: str):
    async def _h(update: Update, context: ContextTypes.DEFAULT_TYPE):
        return await cmd_nommer(update, context, role=role)
    return _h


LEGACY_ALIASES = {
    "nommer_lead_staff": _alias_nommer("LEAD_STAFF_GLOBAL"), "nommer_game_leader": _alias_nommer("GAME_LEADER"),
    "nommer_admin_n1": _alias_nommer("ADMIN_N1"), "nommer_admin_n2": _alias_nommer("ADMIN_N2"),
    "lsg_nommer_game_leader": _alias_nommer("GAME_LEADER"), "lsg_nommer_admin_n1": _alias_nommer("ADMIN_N1"),
    "lsg_nommer_admin_n2": _alias_nommer("ADMIN_N2"), "gl_nommer_admin_n1": _alias_nommer("ADMIN_N1"),
    "gl_nommer_admin_n2": _alias_nommer("ADMIN_N2"),
    "lsg_revoquer": cmd_revoquer, "gl_revoquer_admin": cmd_revoquer, "gl_promouvoir_admin": cmd_promouvoir,
}
PANEL_ALIASES = ("admin", "admin_help", "adminpanel", "monrole")


# ─────────────────────────────────────────────────────────────────────────────
#  Callbacks `stf:`
# ─────────────────────────────────────────────────────────────────────────────
async def stf_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    role = await get_user_role_async(q.from_user.id)
    if role == "PLAYER":
        await q.answer("🚫 Réservé au staff.", show_alert=True)
        return
    await q.answer()
    action, _, arg = (q.data or "")[len(CB):].partition(":")
    if action == "cat":
        await _show_cat(update, arg)
    elif action == "team":
        await _show_team(update)
    elif action == "logs":
        await _show_logs(update)
    elif action == "presence":
        ok, msg = await st.confirm_presence(q.from_user.id)
        await show_home(update, msg)
    elif action in ("slots", "att") and role_level(role) >= role_level("GAME_LEADER"):
        await (_show_slots if action == "slots" else _show_attendance)(update)
    else:
        await show_home(update)


def register(app) -> None:
    """Enregistre toutes les commandes et callbacks du panneau staff (appelé depuis bot.py)."""
    from telegram.ext import CallbackQueryHandler, CommandHandler
    for name in PANEL_ALIASES:
        app.add_handler(CommandHandler(name, cmd_panel))
    for name, fn in {"presence": cmd_presence, "passation": cmd_passation, "creneau": cmd_creneau, "creneaux": cmd_creneaux,
                     "presences": cmd_presences, "passations": cmd_passations, "audit": cmd_audit,
                     "recours": cmd_recours, "staff_nommer": cmd_nommer, "revoquer": cmd_revoquer,
                     "staff_promouvoir": cmd_promouvoir, "staff_liste": cmd_staff_liste,
                     "staff_history": cmd_staff_history, **LEGACY_ALIASES}.items():
        app.add_handler(CommandHandler(name, fn))
    app.add_handler(CallbackQueryHandler(stf_callback, pattern=r"^stf:"))
