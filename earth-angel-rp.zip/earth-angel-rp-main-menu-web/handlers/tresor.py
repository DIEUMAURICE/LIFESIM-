# handlers/tresor.py — 🏛️ Trésor public (Administration) — 100 % boutons, préfixe `td:`
"""
Transparence pour tous : combien contient le Trésor, d'où vient l'argent (les pertes des joueurs envers le jeu),
quelles dotations ont été faites. Le Président et les ministres (chacun pour son ministère) et la direction du jeu
peuvent distribuer le Trésor aux coffres des factions gouvernementales ; le Ministre de l'Économie règle l'impôt.
Règles : dotation minimale, jamais plus de la moitié du Trésor d'un coup, tout est journalisé.
"""
from utils.ui import esc
import html
import logging
import time

from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M, Update
from telegram.ext import ContextTypes

from config import GOV_FACTIONS, TAX_FACTOR_MAX, TAX_FACTOR_MIN, TAX_FACTOR_STEP
from database import db_connection
from utils import state_settings, treasury as tr
from utils.decorators import get_user_role_async, require_registered
from utils.factions import coffre_balance
from utils.notify import notify

logger = logging.getLogger(__name__)
CB = "td:"
SEP = "━━━━━━━━━━━━━━━━━━"
AMOUNTS = (5_000, 10_000, 25_000, 50_000, 100_000, 250_000)


def _k(n: int) -> str:
    return f"{n // 1000}k" if n >= 1000 else str(n)


async def _send(update: Update, text: str, markup: M) -> None:
    q = update.callback_query
    if q:
        try:
            await q.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
            return
        except Exception:
            await q.message.reply_text(text, parse_mode="HTML", reply_markup=markup)
            return
    await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


def _nav(rows=None) -> M:
    rows = list(rows or [])
    rows.append([B("🏛️ Trésor", callback_data=CB + "home"), B("🎮 Menu", callback_data="menu_main")])
    return M(rows)


async def show_home(update: Update, uid: int, note: str = "") -> None:
    role = await get_user_role_async(uid)
    can = await tr.can_grant(uid, role)
    rep = await tr.report(1)
    week = await tr.report(7)
    bal = await tr.balance()
    lines = [f"🏛️ <b>TRÉSOR PUBLIC</b>\n{SEP}"]
    if note:
        lines.append(note)
    lines.append(f"💰 Solde : <b>{bal:,}</b>")
    lines.append(f"📥 Reçu aujourd'hui : <b>{rep['total_in']:,}</b> · 7 jours : <b>{week['total_in']:,}</b>")
    lines.append(f"📤 Redistribué (7 jours) : <b>{week['out']:,}</b>")
    if week["in"]:
        lines.append("\n<b>D'où vient l'argent</b> (7 jours)")
        for src, amount in week["in"][:6]:
            lines.append(f"• {tr.label(src)} : {amount:,}")
    else:
        lines.append("\n<i>Aucune perte enregistrée pour l'instant.</i>")
    if week["grants"]:
        lines.append("\n<b>Dernières dotations</b>")
        for g in week["grants"]:
            f = GOV_FACTIONS.get(g["target"], {"emoji": "🏛️", "name": g["target"]})
            when = time.strftime("%d/%m %H:%M", time.gmtime(g["created_at"]))
            lines.append(f"• {when} → {f['emoji']} {esc(f['name'])} : {g['amount']:,}")
    lines.append("\n<i>Toutes les dépenses des joueurs envers le jeu financent l'Administration, qui répartit "
                 "ensuite entre les coffres des factions.</i>")
    factor = state_settings.tax_factor()
    lines.append(f"\n🧾 Impôt sur la fortune : coefficient <b>×{factor:g}</b> sur le barème")
    rows = []
    if can:
        rows.append([B("💸 Distribuer le Trésor", callback_data=CB + "give")])
    else:
        lines.append("🔒 Seuls le Président et les ministres distribuent le Trésor (chacun pour son ministère).")
    if await tr.can_set_tax(uid, role):
        rows.append([B("📈 Régler l'impôt", callback_data=CB + "tax")])
    await _send(update, "\n".join(lines), _nav(rows))


async def show_tax(update: Update, uid: int, note: str = "") -> None:
    if not await tr.can_set_tax(uid, await get_user_role_async(uid)):
        await show_home(update, uid, "🚫 Réservé au Ministre de l'Économie et au Président.")
        return
    factor = state_settings.tax_factor()
    lines = [f"📈 <b>IMPÔT SUR LA FORTUNE</b>\n{SEP}"]
    if note:
        lines.append(note)
    lines.append(f"Coefficient actuel : <b>×{factor:g}</b> (barème normal = ×1)")
    lines.append(f"Fourchette : ×{TAX_FACTOR_MIN:g} à ×{TAX_FACTOR_MAX:g} · un changement par jour de jeu.")
    lines.append("<i>Un impôt plus haut remplit le Trésor, un impôt plus bas allège les joueurs.</i>")
    steps = []
    v = TAX_FACTOR_MIN
    while v <= TAX_FACTOR_MAX + 1e-9:
        steps.append(round(v, 4))
        v += TAX_FACTOR_STEP
    btns = [B(("✅ " if abs(x - factor) < 1e-9 else "") + f"×{x:g}", callback_data=f"{CB}taxset:{int(round(x * 100))}")
            for x in steps]
    rows = [btns[i:i + 3] for i in range(0, len(btns), 3)]
    await _send(update, "\n".join(lines), _nav(rows))


async def do_set_tax(update: Update, uid: int, pct: int) -> None:
    if not await tr.can_set_tax(uid, await get_user_role_async(uid)):
        await show_home(update, uid, "🚫 Réservé au Ministre de l'Économie et au Président.")
        return
    ok, msg = await state_settings.set_tax_factor(pct / 100)
    await show_tax(update, uid, ("✅ " if ok else "❌ ") + html.escape(msg))


async def show_targets(update: Update, uid: int) -> None:
    if not await tr.can_grant(uid, await get_user_role_async(uid)):
        await show_home(update, uid, "🚫 Réservé au Président et aux ministres.")
        return
    bal = await tr.balance()
    allowed = await tr.grant_targets(uid, await get_user_role_async(uid))
    lines = [f"💸 <b>DISTRIBUER</b>\n{SEP}", f"Trésor : <b>{bal:,}</b>", "Choisis le coffre à alimenter :", ""]
    rows = []
    for key, f in GOV_FACTIONS.items():
        if key not in allowed:
            continue
        cb = await coffre_balance(key)
        lines.append(f"{f['emoji']} <b>{esc(f['name'])}</b> — coffre {cb:,}")
        rows.append([B(f"{f['emoji']} {f['name']} ({cb:,})", callback_data=f"{CB}to:{key}")])
    await _send(update, "\n".join(lines), _nav(rows))


async def show_amounts(update: Update, uid: int, key: str) -> None:
    if key not in GOV_FACTIONS:
        await show_targets(update, uid)
        return
    f = GOV_FACTIONS[key]
    bal = await tr.balance()
    lines = [f"💸 <b>Dotation → {f['emoji']} {esc(f['name'])}</b>\n{SEP}",
             f"Trésor : <b>{bal:,}</b> · plafond d'une dotation : <b>{int(bal * tr.GRANT_MAX_SHARE):,}</b>",
             "Choisis le montant :"]
    btns = [B(f"{_k(a)}", callback_data=f"{CB}g:{key}:{a}") for a in AMOUNTS if a <= max(bal, 0)]
    rows = [btns[i:i + 3] for i in range(0, len(btns), 3)]
    if not rows:
        lines.append("\n<i>Le Trésor est trop bas pour une dotation.</i>")
    rows.append([B("⬅️ Autres factions", callback_data=CB + "give")])
    await _send(update, "\n".join(lines), _nav(rows))


async def _heads(key: str) -> list[int]:
    async with db_connection() as db:
        async with db.execute("SELECT user_id FROM faction_members WHERE faction=? AND rank=("
                              "SELECT MAX(rank) FROM faction_members WHERE faction=?)", (key, key)) as cur:
            return [r[0] for r in await cur.fetchall()]


async def do_grant(update: Update, uid: int, key: str, amount: int) -> None:
    role = await get_user_role_async(uid)
    ok, msg = await tr.grant(uid, key, amount, "dotation de l'Administration", role)
    if ok:
        f = GOV_FACTIONS[key]
        for head in await _heads(key):
            if head != uid:
                await notify(head, "🏛️ Dotation reçue",
                             f"L'Administration a versé <b>{amount:,}</b> au coffre {f['emoji']} <b>{esc(f['name'])}</b>.",
                             "economy")
    await show_home(update, uid, ("✅ " if ok else "❌ ") + esc(msg))


@require_registered
async def cmd_tresor(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update, update.effective_user.id)


async def td_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    p = (q.data or "").split(":")
    action = p[1] if len(p) > 1 else "home"
    a = p[2:] + ["", ""]
    try:
        await q.answer()
        if action == "give":
            await show_targets(update, uid)
        elif action == "tax":
            await show_tax(update, uid)
        elif action == "taxset" and a[0].isdigit():
            await do_set_tax(update, uid, int(a[0]))
        elif action == "to":
            await show_amounts(update, uid, a[0])
        elif action == "g" and a[0] in GOV_FACTIONS and a[1].isdigit():
            await do_grant(update, uid, a[0], int(a[1]))
        else:
            await show_home(update, uid)
    except Exception:
        logger.exception("Trésor public : erreur sur %s", q.data)
