# handlers/team.py — 👥 Hiérarchie & 💬 chats d'équipe (100 % boutons, préfixe `tm:`)
from utils.swallow import swallowed
import asyncio
import html
import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ApplicationHandlerStop, ContextTypes

from database import get_user
from utils import team
from utils.decorators import require_registered
from utils.helpers import send_or_edit as _send

logger = logging.getLogger(__name__)
CB = "tm:"
PAGE = 10


def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text, callback_data=data)


def _e(s) -> str:
    return html.escape(str(s))


# ─────────────────────────────────────────────────────────────────────────────
#  Accueil
# ─────────────────────────────────────────────────────────────────────────────
async def show_home(update: Update, uid: int, note: str = "") -> None:
    mem = await team.membership(uid)
    lines = ["👥 <b>Mon équipe</b>", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    if mem["faction"]:
        rows.append([_btn("👥 Hiérarchie de ma faction", CB + "r:faction:0")])
    if mem["company"]:
        rows.append([_btn("👥 Hiérarchie de mon entreprise", CB + "r:company:0")])
    if not mem["faction"] and not mem["company"]:
        lines.append("Tu ne fais partie d'aucune faction ni entreprise. 🎖️ Menu État & factions · 🏢 Entreprises.")
    if mem["faction"] or mem["company"]:
        rows.append([_btn("💬 Chats d'équipe", CB + "chat")])
    rows.append([_btn("🔄 Actualiser", CB + "home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Hiérarchie
# ─────────────────────────────────────────────────────────────────────────────
async def show_roster(update: Update, uid: int, kind: str, page: int = 0) -> None:
    r = await team.roster(uid, kind)
    if r.get("error"):
        await show_home(update, uid, f"❌ {r['error']}")
        return
    members = r["members"]
    total = len(members)
    start = max(0, page) * PAGE
    chunk = members[start:start + PAGE]
    lines = [f"👥 <b>Hiérarchie — {r['title']}</b> ({total})", ""]
    for m in chunk:
        pseudo = f"@{_e(m['username'])}" if m["username"] else "—"
        lines.append(f"{'👑' if m['head'] else '▫️'} <b>{_e(m['name'])}</b> · {pseudo} · 🆔 <code>{m['user_id']}</code>")
        extra = f"   {_e(m['title'])}" + (f" · {_e(m['place'])}" if m["place"] else "") + (" · 🟢" if m["duty"] else "")
        if r["can_see_activity"]:
            extra += f" · ⚡ activité <b>{m['activity']}</b>"
        lines.append(extra)
    if not chunk:
        lines.append("Aucun membre.")
    if r["can_see_activity"]:
        lines += ["", "<i>🔎 En tant que direction, tu vois aussi l'activité de chaque employé.</i>"]
    rows = []
    nav = []
    if page > 0:
        nav.append(_btn("⬅️", CB + f"r:{kind}:{page - 1}"))
    if start + PAGE < total:
        nav.append(_btn("➡️", CB + f"r:{kind}:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([_btn("⬅️ Mon équipe", CB + "home")])
    await _send(update, "\n".join(lines)[:3900], InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Chats
# ─────────────────────────────────────────────────────────────────────────────
async def show_chat(update: Update, uid: int, note: str = "") -> None:
    chans = await team.my_channels(uid)
    active = await team.get_channel(uid)
    lines = ["💬 <b>Chats d'équipe</b>", "",
             "<i>Entre dans un canal : tout ce que tu écris ensuite est envoyé à ses membres via le bot, "
             "avec ton nom et ton poste.</i>", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    for code, title in chans:
        muted = await team.is_muted(uid, code)
        n = len(await team.channel_member_ids(code))
        mark = "🟢 " if code == active else ""
        lines.append(f"{mark}{title} — {n} membre(s){' · 🔕 sourdine' if muted else ''}")
        rows.append([_btn(f"{mark}💬 {title}", CB + f"in:{code}"), _btn("🔔" if muted else "🔕", CB + f"mute:{code}")])
    if active:
        rows.append([_btn("⏹️ Quitter le chat", CB + "out")])
    if not chans:
        lines.append("Aucun canal disponible.")
    rows.append([_btn("⬅️ Mon équipe", CB + "home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def team_relay(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Diffuse le message d'un joueur qui est dans un canal ; lève ApplicationHandlerStop s'il a été traité."""
    msg = update.effective_message
    user = update.effective_user
    if not msg or not msg.text or not user:
        return
    prep = await team.prepare_message(user.id, msg.text)
    if prep is None:
        return
    if prep.get("error") is not None and "channel" not in prep:
        if prep["error"]:
            await msg.reply_text(prep["error"])
        raise ApplicationHandlerStop
    body = (f"💬 <b>{_e(prep['title'])}</b>\n<b>{_e(prep['name'])}</b> · <i>{_e(prep['post'])}</i>\n"
            f"{_e(prep['text'])}")
    sent = 0

    async def one(rid: int):
        nonlocal sent
        try:
            await context.bot.send_message(rid, body, parse_mode="HTML")
            sent += 1
        except Exception:
            logger.debug("Chat d'équipe : message non remis à %s", rid)

    for i in range(0, len(prep["recipients"]), 20):           # par lots de 20 (limites Telegram)
        await asyncio.gather(*(one(r) for r in prep["recipients"][i:i + 20]))
        if len(prep["recipients"]) > 20:
            await asyncio.sleep(1)
    await msg.reply_text(f"✅ Envoyé à {sent} membre(s).",
                         reply_markup=InlineKeyboardMarkup([[_btn("⏹️ Quitter le chat", CB + "out")]]))
    raise ApplicationHandlerStop


# ─────────────────────────────────────────────────────────────────────────────
#  Commandes & callbacks
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_hierarchie(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update, update.effective_user.id)


@require_registered
async def cmd_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_chat(update, update.effective_user.id)


@require_registered
async def cmd_hierarchie_ent(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Entrée du menu Entreprises : hiérarchie de mon entreprise."""
    await show_roster(update, update.effective_user.id, "company")


@require_registered
async def cmd_chat_ent(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Entrée du menu Entreprises : chats d'équipe."""
    await show_chat(update, update.effective_user.id)


async def tm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    parts = (q.data or "").split(":")
    action = parts[1] if len(parts) > 1 else "home"
    a2 = parts[2] if len(parts) > 2 else ""
    a3 = parts[3] if len(parts) > 3 else ""
    try:
        u = await get_user(uid)
        if not u.get("registered") or u.get("banned"):
            await q.answer("Termine d'abord /start.", show_alert=True)
            return
        await q.answer()
        if action == "home":
            await show_home(update, uid)
        elif action == "r" and a2 in ("faction", "company"):
            await show_roster(update, uid, a2, int(a3) if a3.isdigit() else 0)
        elif action == "chat":
            await show_chat(update, uid)
        elif action == "in":
            code = ":".join(parts[2:])
            ok, msg = await team.enter(uid, code)
            await show_chat(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "out":
            await team.leave(uid)
            await show_chat(update, uid, "⏹️ Tu as quitté le chat : tes messages ne sont plus diffusés.")
        elif action == "mute":
            code = ":".join(parts[2:])
            if await team.has_access(uid, code):
                muted = await team.toggle_mute(uid, code)
                await show_chat(update, uid, "🔕 Canal en sourdine." if muted else "🔔 Canal réactivé.")
            else:
                await show_chat(update, uid, "❌ Canal inaccessible.")
        else:
            await show_home(update, uid)
    except Exception:
        logger.exception("tm_callback : %s", q.data)
        try:
            await q.message.reply_text("⚠️ Une erreur est survenue, réessaie depuis le menu.")
        except Exception:
            swallowed('handlers/team.py')
