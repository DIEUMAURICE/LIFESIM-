# handlers/chain.py — écrans de la chaîne : métiers → entreprises → produits finis
"""
Tout se fait aux boutons (callback `ch:…`). La logique est dans utils/chain.py.

  Joueur       : Mes biens (vendre aux entreprises / comptoir), Promotion du métier
  Entreprise   : Chaîne de production (stade, lignes, équipes, achats d'intrants, prix, part du marché national)
  Commerçant   : Grossiste (achat de produits finis aux entreprises, revente sur le marché)
  Tout le monde: Prestations (services d'entreprises), Catalogue des secteurs (ce que fait chaque produit)
"""
import logging

from telegram import Update, InlineKeyboardButton as B, InlineKeyboardMarkup as M
from telegram.ext import ContextTypes

from config import PRODUCTION_LEVELS, SMALL_JOBS
from config_chain import (
    INTRANTS, RECIPES, RECIPES_BY_SECTOR, STAGES, MAX_STAGE, SECTORS_CHAIN, SECTOR_TEAMS, BID_STEP, BID_MIN, BID_MAX,
    clamp_stage, stage_name, stage_emoji, stage_cap, job_rank_name, job_rank_mult, describe_effects, dept_label,
    good_label, npc_price, recipe_needs, sector_depts, sector_inputs, MAX_JOB_RANK, COUNTER_PRICE_RATIO,
    COUNTER_DAILY_CAP, GRANDE_COMMANDE_RANK,
)
from database import get_user, get_user_company, db_connection
from utils import chain
from utils.company_roles import can_manage
from utils.decorators import require_registered
from utils.helpers import fmt

logger = logging.getLogger(__name__)

HOME = B("🎮 Menu principal", callback_data="hub:home")


def _bar(cur: float, need: float, n: int = 10) -> str:
    r = 1.0 if need <= 0 else max(0.0, min(1.0, cur / need))
    k = int(round(r * n))
    return "▰" * k + "▱" * (n - k)


def _back(cb: str, label: str = "⬅️ Retour") -> list:
    return [B(label, callback_data=cb), HOME]


async def _edit(query, text: str, markup: M) -> None:
    try:
        await query.edit_message_text(text[:4000], parse_mode="HTML", reply_markup=markup)
    except Exception as e:                     # « message is not modified » & co : sans gravité
        if "not modified" not in str(e).lower():
            logger.warning("chain edit: %s", e)


async def _send(update: Update, text: str, markup: M) -> None:
    await update.effective_message.reply_text(text[:4000], parse_mode="HTML", reply_markup=markup)


# ═════════════════════════════════════════════════════════════════════════════
#  MÉTIER : promotion
# ═════════════════════════════════════════════════════════════════════════════
async def promo_view(user_id: int, note: str = "") -> tuple[str, M]:
    u = await get_user(user_id)
    job = u.get("job", "") or ""
    if job not in SMALL_JOBS:
        return "💼 Tu n'as pas de métier.\n🛠️ Choisis-en un : Carrière → Mon métier.", M([_back("hub:carriere:0")])
    st = await chain.promotion_status(user_id, job)
    rank = st["rank"]
    lines = [f"🎖️ <b>PROMOTION — {SMALL_JOBS[job].get('emoji', '🛠️')} {job}</b>", ""]
    if note:
        lines += [note, ""]
    lines.append(f"Rang actuel : <b>{job_rank_name(rank)}</b> ({st['missions']} missions)")
    m = job_rank_mult(rank)
    lines.append(f"Gains ×{m['pay']} · biens fournis ×{m['goods']} · effort ×{m['energy']}")
    rows = []
    if st["next"] is None:
        lines += ["", "🏆 Rang maximal atteint : tu es un <b>Grand maître</b>."]
    else:
        nm = job_rank_mult(st["next"])
        lines += ["", f"Prochain rang : <b>{job_rank_name(st['next'])}</b> "
                      f"(gains ×{nm['pay']} · biens ×{nm['goods']})"]
        for label, have, need, ok in st["reqs"]:
            lines.append(f"{'✅' if ok else '⬜'} {label} : {have}/{need}")
        if st["next"] == GRANDE_COMMANDE_RANK:
            lines.append("📦 Ce rang ouvre les <b>grandes commandes</b> (gros gains, beaucoup de biens, repos ×3).")
        if st["ok"]:
            rows.append([B("⬆️ Être promu", callback_data="ch:promoup")])
    lines += ["", "📈 Monte en rang : plus de gains, plus de biens à fournir aux entreprises."]
    rows.append([B("📦 Mes biens", callback_data="ch:goods"), B("🏢 Promotion à mon poste", callback_data="ch:wpromo")])
    rows.append(_back("metier_home", "⬅️ Mon métier"))
    return "\n".join(lines), M(rows)


@require_registered
async def cmd_chaine_promotion(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text, markup = await promo_view(update.effective_user.id)
    await _send(update, text, markup)


# ═════════════════════════════════════════════════════════════════════════════
#  JOUEUR : mes biens, vente
# ═════════════════════════════════════════════════════════════════════════════
async def goods_view(user_id: int, note: str = "") -> tuple[str, M]:
    goods = await chain.user_goods(user_id)
    raw = {k: q for k, q in goods.items() if k in INTRANTS}
    fin = {k: q for k, q in goods.items() if k in RECIPES}
    lines = ["📦 <b>MES BIENS</b>", ""]
    if note:
        lines += [note, ""]
    rows = []
    if raw:
        lines.append("<b>Biens de base</b> — fournis par les métiers, achetés par les entreprises :")
        for k, q in raw.items():
            g = INTRANTS[k]
            lines.append(f"{g['emoji']} {g['name']} ×<b>{q}</b> · référence {g['ref']:,} €A/u")
            rows.append([B(f"💰 Vendre {g['emoji']} {g['name']} ({q})", callback_data=f"ch:sell:{k}")])
    else:
        lines.append("Aucun bien de base. Chaque mission de ton métier t'en fait gagner, "
                     "et tes récoltes du jardin donnent des 🥕 Récoltes fraîches.")
    if fin:
        lines += ["", "<b>Produits finis</b> (à utiliser ou revendre depuis Marché → Mes objets) :"]
        for k, q in fin.items():
            r = RECIPES[k]
            lines.append(f"{r['emoji']} {r['name']} ×<b>{q}</b> — {describe_effects(r['effects'])}")
    st = await _my_stats(user_id)
    if st:
        lines += ["", f"📊 Fournis : <b>{st['goods_supplied']:,}</b> unités aux entreprises · "
                      f"valeur <b>{st['supply_value']:,}</b> €A · grandes commandes : <b>{st['big_orders']}</b>"]
    rows.append(_back("metier_home", "⬅️ Mon métier"))
    return "\n".join(lines), M(rows)


async def _my_stats(user_id: int) -> dict | None:
    async with db_connection() as db:
        async with db.execute("SELECT goods_made, goods_supplied, supply_value, big_orders "
                              "FROM user_chain_stats WHERE user_id=?", (user_id,)) as cur:
            r = await cur.fetchone()
    if not r:
        return None
    return {"goods_made": r[0], "goods_supplied": r[1], "supply_value": r[2], "big_orders": r[3]}


async def sell_view(user_id: int, good: str, note: str = "") -> tuple[str, M]:
    g = INTRANTS[good]
    have = (await chain.user_goods(user_id)).get(good, 0)
    lines = [f"💰 <b>Vendre {g['emoji']} {g['name']}</b> (tu en as <b>{have}</b>)", ""]
    if note:
        lines += [note, ""]
    rows = []
    buyers = await chain.companies_buying(good, 5)
    if buyers:
        lines.append("<b>Entreprises acheteuses</b> (meilleur prix d'abord) :")
        for c in buyers:
            lines.append(f"{stage_emoji(c['level'])} {c['name']} — <b>{c['price']:,}</b> €A/u "
                         f"(×{c['mult']:.1f}) · place {c['room']} · caisse {fmt(c['treasury'])}")
            rows.append([B(f"{c['name'][:14]} ×1", callback_data=f"ch:s:{good}:{c['company_id']}:1"),
                         B("×5", callback_data=f"ch:s:{good}:{c['company_id']}:5"),
                         B("Tout", callback_data=f"ch:s:{good}:{c['company_id']}:a")])
    else:
        lines.append("Aucune entreprise n'achète ce bien pour le moment.")
    price = max(1, int(g["ref"] * COUNTER_PRICE_RATIO))
    lines += ["", f"🏛️ <b>Comptoir national</b> (filet de sécurité) : {price:,} €A/u, "
                  f"max {COUNTER_DAILY_CAP}/jour."]
    rows.append([B(f"🏛️ Comptoir ×1", callback_data=f"ch:c:{good}:1"), B("×5", callback_data=f"ch:c:{good}:5"),
                 B("Tout", callback_data=f"ch:c:{good}:a")])
    comp = await get_user_company(user_id)
    if comp and good in sector_inputs(comp["sector"]):
        lines.append(f"🏢 Tu travailles chez <b>{comp['name']}</b> : tu peux déposer gratuitement ce bien à son stock.")
        rows.append([B("📥 Déposer à mon entreprise ×5", callback_data=f"ch:d:{good}:5"),
                     B("Tout", callback_data=f"ch:d:{good}:a")])
    rows.append(_back("ch:goods", "⬅️ Mes biens"))
    return "\n".join(lines), M(rows)


async def _qty(user_id: int, good: str, q: str) -> int:
    have = (await chain.user_goods(user_id)).get(good, 0)
    return have if q == "a" else min(have, int(q)) if q.isdigit() else 0


# ═════════════════════════════════════════════════════════════════════════════
#  ENTREPRISE : vue d'ensemble de la chaîne
# ═════════════════════════════════════════════════════════════════════════════
def _stage_lines(comp: dict, state: dict, staff: int) -> list[str]:
    stage = clamp_stage(comp["level"])
    out = [f"{stage_emoji(stage)} Stade : <b>{stage_name(stage)}</b> ({stage}/{MAX_STAGE}) · "
           f"capacité ×{stage_cap(stage)} · {STAGES[stage - 1]['lines']} ligne(s)"]
    if stage < MAX_STAGE:
        nx = STAGES[stage]
        out.append(f"➡️ Prochain stade : <b>{nx['name']}</b>")
        out.append(f"{'✅' if state['xp'] >= nx['xp'] else '⬜'} XP {_bar(state['xp'], nx['xp'])} {state['xp']:,}/{nx['xp']:,}")
        out.append(f"{'✅' if staff >= nx['staff'] else '⬜'} Effectif {staff}/{nx['staff']}")
        out.append(f"{'✅' if comp['reputation'] >= nx['rep'] else '⬜'} Réputation {comp['reputation']}/{nx['rep']}")
        out.append(f"{'✅' if comp['treasury'] >= nx['treasury'] else '⬜'} Trésorerie {comp['treasury']:,}/{nx['treasury']:,}")
    else:
        out.append("🌍 Stade maximal : multinationale.")
    return out


async def co_view(user_id: int, note: str = "") -> tuple[str, M]:
    comp = await get_user_company(user_id)
    if not comp:
        return ("🏢 Tu ne travailles dans aucune entreprise.\nRejoins-en une depuis le menu Entreprises.",
                M([_back("hub:entreprises:0")]))
    cid = comp["company_id"]
    boss = await can_manage(user_id, comp)
    state = await chain.get_chain_state(cid)
    team = await chain.team_overview(cid)
    staff = sum(len(v) for v in team.values())
    lines = [f"🏭 <b>{comp['name']}</b> — {comp['sector']}", ""]
    if note:
        lines += [note, ""]
    lines += _stage_lines(comp, state, staff)
    lines += ["", f"💰 Trésorerie : <b>{fmt(comp['treasury'])}</b> · ⭐ réputation {comp['reputation']}/100"]
    ln = await chain.get_lines(cid)
    lines += ["", "<b>Lignes de production</b> :"]
    for rk in ln or []:
        lines.append(f"▶️ {RECIPES[rk]['emoji']} {RECIPES[rk]['name']} ({'service' if RECIPES[rk]['type'] == 'service' else 'bien'})")
    if not ln:
        lines.append("Aucune : la 1re recette du secteur démarre toute seule.")
    stock = await chain.stock_of(cid)
    if stock:
        lines += ["", "<b>Stock</b> :"]
        for k, q in sorted(stock.items()):
            if k in INTRANTS:
                lines.append(f"  📥 {good_label(k)} ×{q}")
            elif k in RECIPES:
                lines.append(f"  📤 {RECIPES[k]['emoji']} {RECIPES[k]['name']} ×{q}")
            else:
                lines.append(f"  ⚙️ {k} ×{q}")
    from utils import payroll
    lvl = await payroll.get_level(cid)
    lines += ["", f"⚙️ Rythme : <b>{PRODUCTION_LEVELS[lvl]['name']}</b> "
                  f"(unités ×{PRODUCTION_LEVELS[lvl]['units']}, coûts ×{PRODUCTION_LEVELS[lvl]['cost']})",
              f"🛒 Part livrée au marché national : <b>{int(state['npc_share'] * 100)} %</b> "
              f"(le reste va aux grossistes et aux clients)",
              f"📈 Produit en tout : {state['produced_total']:,} · chiffre d'affaires : {fmt(state['revenue_total'])}"]
    async with db_connection() as db:
        async with db.execute("SELECT day, produced, sold, cost, revenue FROM company_production_log "
                              "WHERE company_id=? ORDER BY day DESC LIMIT 1", (cid,)) as cur:
            last = await cur.fetchone()
    if last:
        net = last[4] - last[3]
        lines.append(f"📊 Dernier bilan : {last[1]} produits · {last[2]} vendus · net <b>{'+' if net >= 0 else ''}{net:,}</b>")
    on_duty = sum(1 for v in team.values() for m in v if m[3])
    lines += ["", f"⏱️ <b>La production tourne à chaque heure de jeu.</b> En service : <b>{on_duty}/{staff}</b>.",
              "💡 Pour produire, l'équipe doit être <b>en service</b> (🎓 Carrière → Mon métier → Prendre mon service)."]
    lines += await _bot_notice()
    rows = [[B("📖 Guide pas à pas", callback_data="ch:guide"), B("🔍 Diagnostic", callback_data="ch:diag")],
            [B("📋 Lignes & recettes", callback_data="ch:lines"), B("👥 Équipes", callback_data="ch:team")],
            [B("📥 Achat d'intrants", callback_data="ch:bids"), B("🏷️ Prix de vente", callback_data="ch:prices")]]
    if boss:
        rows.append([B("⚙️ Rythme", callback_data="ch:lvl"), B("🛒 Part nationale", callback_data="ch:share")])
    rows.append(_back("hub:entreprises:0"))
    return "\n".join(lines), M(rows)


@require_registered
async def cmd_chaine_entreprise(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text, markup = await co_view(update.effective_user.id)
    await _send(update, text, markup)


def _recipe_card(rk: str, active: bool, stage: int) -> str:
    r = RECIPES[rk]
    lock = r["min_stage"] > stage
    flag = "🔒" if lock else ("▶️" if active else "⏹️")
    kind = "service" if r["type"] == "service" else "bien"
    txt = [f"{flag} {r['emoji']} <b>{r['name']}</b> ({kind}) — stade {STAGES[r['min_stage'] - 1]['name']} min.",
           f"   {r['desc']}",
           f"   Effet : {describe_effects(r['effects'])}"]
    for i, st in enumerate(r["steps"], 1):
        ins = ", ".join(f"{q}×{good_label(g) if g in INTRANTS else _inter(g)}" for g, q in st["in"].items())
        txt.append(f"   {i}. {dept_label_of(r, st)} : {ins} → {st['out'][1]}×{_inter(st['out'][0])}")
    txt.append(f"   Prix national : {npc_price(rk):,} €A · capacité {r['base_cap']}/jour")
    return "\n".join(txt)


def _inter(key: str) -> str:
    from config_chain import INTERMEDIAIRES
    if key in INTERMEDIAIRES:
        return INTERMEDIAIRES[key]["name"]
    if key in RECIPES:
        return RECIPES[key]["name"]
    return good_label(key) if key in INTRANTS else key


def dept_label_of(r: dict, st: dict) -> str:
    return dept_label(r["sector"], st["dept"])


async def _bot_notice() -> list[str]:
    """Rôles du bot réduits ou fermés par le staff : les joueurs doivent savoir sur qui compter."""
    from utils import gamerules as gr
    out = []
    for key, (label, _d) in gr.BOT_ROLES.items():
        pct = await gr.bot_pct(key)
        if pct == 0:
            out.append(f"⛔ {label} : <b>fermé</b>")
        elif pct < 100:
            out.append(f"🟡 {label} : <b>réduit à {pct} %</b>")
    if out:
        out = ["", "🔁 <b>Le bot se retire :</b>"] + out + ["<i>Achète et vends entre entreprises, joueurs et commerçants.</i>"]
    return out


async def guide_view(user_id: int) -> tuple[str, M]:
    """Guide pas à pas : le cycle complet d'une entreprise, avec ce qui est déjà fait et la prochaine étape."""
    comp = await get_user_company(user_id)
    from utils import gamerules as gr
    steps: list[tuple[bool, str, str]] = []
    if not comp:
        txt = ("📖 <b>GUIDE DE L'ENTREPRISE</b>\n━━━━━━━━━━━━━━━━━━\n"
               "👉 <b>Étape 1 — Avoir une entreprise.</b>\nFonde la tienne ou postule dans une équipe : "
               "🎮 Menu → 🏢 Entreprises → Trouver ou créer.")
        return txt, M([_back("hub:entreprises")])
    from utils import payroll
    d = await payroll.diagnose(comp["company_id"])
    stock = await chain.stock_of(comp["company_id"])
    have_stock = sum(v for k, v in stock.items() if k in RECIPES) > 0
    can_produce = any(ln["ok"] for ln in d["lines"])
    need = max((ln["need_cost"] for ln in d["lines"]), default=0)
    npc_open = await gr.bot_pct("npc_orders") > 0
    steps = [
        (True, "Avoir une entreprise", "C'est fait."),
        (d["members"] >= 2, "Constituer une équipe", "Recrute ou invite un joueur : 🏢 Entreprises → Recrutement. Seul, tu produis lentement."),
        (d["on_duty"] > 0, "Prendre son service", "Chaque membre : 🎓 Carrière → Mon métier → Prendre mon service. Sans service, aucune activité."),
        (bool(d["lines"]), "Choisir une recette", "Ouvre « 📋 Lignes & recettes » dans la chaîne et active la recette voulue."),
        (int(d["treasury"] or 0) >= need > 0 or int(d["treasury"] or 0) > 20_000, "Avoir de la trésorerie",
         "Dépose de l'argent en caisse : 🏢 Entreprises → Caisse & finances → Déposer en caisse. Les intrants et les salaires s'y prélèvent."),
        (can_produce or have_stock, "Produire (automatique)", "L'équipe en service produit à chaque heure de jeu. Surveille « 🔍 Pourquoi ça ne produit pas ? »."),
        (have_stock, "Vendre", ("Fixe tes prix dans « 💰 Prix » ; vends aux commerçants (grossiste)" + (" ou au marché national." if npc_open else ". Le marché national est fermé : les joueurs sont ton marché."))),
        (False, "Payer l'équipe", "Les salaires partent de la trésorerie en fin de journée de jeu : garde de quoi les payer."),
    ]
    lines = ["📖 <b>GUIDE DE L'ENTREPRISE</b>", "━━━━━━━━━━━━━━━━━━", f"🏢 <b>{comp['name']}</b>", ""]
    nxt = None
    for i, (done, title, how) in enumerate(steps, 1):
        if i == len(steps):
            lines.append(f"🔁 {i}. {title}")
            continue
        if done:
            lines.append(f"✅ {i}. {title}")
        else:
            lines.append(f"{'👉' if nxt is None else '⬜'} {i}. {title}")
            nxt = nxt or (i, title, how)
    lines.append("")
    if nxt:
        lines += [f"<b>Prochaine étape — {nxt[1]}</b>", nxt[2]]
    else:
        lines += ["🎉 Ton entreprise tourne : produis, vends, réinvestis.", steps[-1][2]]
    lines += await _bot_notice()
    return "\n".join(lines), M([[B("🔍 Diagnostic", callback_data="ch:diag")], _back("ch:co", "⬅️ Chaîne")])


async def diag_view(user_id: int) -> tuple[str, M]:
    """Explique, en clair, pourquoi l'entreprise produit ou non, et quoi faire."""
    comp = await get_user_company(user_id)
    if not comp:
        return "🏢 Tu ne travailles dans aucune entreprise.", M([_back("hub:entreprises:0")])
    from utils import payroll
    d = await payroll.diagnose(comp["company_id"])
    lines = [f"🔍 <b>DIAGNOSTIC — {comp['name']}</b>", "",
             "⏱️ L'entreprise produit à <b>chaque heure de jeu</b> avec l'activité de l'équipe en service.", "",
             f"👥 En service : <b>{d['on_duty']}/{d['members']}</b>",
             f"⚡ Activité disponible : <b>{sum(d['pools'].values())}</b> point(s)",
             f"💰 Trésorerie : <b>{fmt(d['treasury'])}</b>"]
    lines += await _bot_notice()
    advice = []
    if d["members"] and not d["on_duty"]:
        advice.append("🟢 <b>Personne n'est en service.</b> Chaque membre doit « Prendre son service » "
                      "(🎓 Carrière → Mon métier). 1 point d'activité toutes les 10 min de jeu, par personne.")
    if not d["lines"]:
        lines += ["", "📋 Aucune ligne active : lance une recette dans « Lignes & recettes »."]
    for ln in d["lines"]:
        r = RECIPES[ln["recipe"]]
        head = f"{r['emoji']} <b>{r['name']}</b>"
        need = f"1 lot ≈ {ln['need_points']} pts d'activité + {fmt(ln['need_cost'])}"
        if ln["ok"]:
            lines += ["", f"✅ {head} — peut produire (jusqu'à {ln['lots_now']} lot(s) maintenant)", f"   {need}"]
        else:
            why = {"treasury": "💰 trésorerie insuffisante", "points": "⚡ activité insuffisante",
                   "supply": "📥 fournisseur national à court d'intrants aujourd'hui"}.get(ln["reason"], "⚠️ blocage")
            lines += ["", f"⛔ {head} — {why}", f"   {need}"]
            if ln["reason"] == "treasury":
                advice.append("💰 Dépose de l'argent (🏢 Entreprises → Caisse & finances → Déposer en caisse).")
            elif ln["reason"] == "points" and d["on_duty"]:
                advice.append("⚡ L'équipe est en service : patiente, l'activité s'accumule au fil des heures de jeu.")
            elif ln["reason"] == "supply":
                from utils import gamerules as _gr
                if await _gr.bot_pct("npc_supply") == 0:
                    advice.append("📥 Le fournisseur national est fermé : achète tes intrants aux joueurs et aux autres entreprises.")
                else:
                    advice.append("📥 Achète des intrants aux joueurs (Lignes → Achat d'intrants) ou reviens demain.")
    if advice:
        lines += ["", "<b>Que faire ?</b>"] + [f"• {a}" for a in dict.fromkeys(advice)]
    return "\n".join(lines), M([_back("ch:co", "⬅️ Chaîne")])


async def lines_view(user_id: int, note: str = "") -> tuple[str, M]:
    comp = await get_user_company(user_id)
    if not comp:
        return "🏢 Aucune entreprise.", M([_back("hub:entreprises:0")])
    boss = await can_manage(user_id, comp)
    stage = clamp_stage(comp["level"])
    active = set(await chain.get_lines(comp["company_id"]))
    lines = [f"📋 <b>LIGNES DE PRODUCTION — {comp['name']}</b>",
             f"{stage_name(stage)} : {len(active)}/{STAGES[stage - 1]['lines']} ligne(s) active(s)", ""]
    if note:
        lines += [note, ""]
    rows = []
    for rk in RECIPES_BY_SECTOR[comp["sector"]]:
        lines.append(_recipe_card(rk, rk in active, stage))
        lines.append("")
        if boss and RECIPES[rk]["min_stage"] <= stage:
            rows.append([B(f"{'⏹️ Arrêter' if rk in active else '▶️ Lancer'} {RECIPES[rk]['name']}"[:40],
                           callback_data=f"ch:ln:{rk}")])
    if not boss:
        lines.append("ℹ️ Seuls le créateur et les gérants changent les lignes.")
    rows.append(_back("ch:co", "⬅️ Chaîne"))
    return "\n".join(lines), M(rows)


async def team_view(user_id: int, note: str = "") -> tuple[str, M]:
    comp = await get_user_company(user_id)
    if not comp:
        return "🏢 Aucune entreprise.", M([_back("hub:entreprises:0")])
    boss = await can_manage(user_id, comp)
    team = await chain.team_overview(comp["company_id"])
    depts = sector_depts(comp["sector"])
    lines = [f"👥 <b>ÉQUIPES — {comp['name']}</b> ({comp['sector']})", ""]
    if note:
        lines += [note, ""]
    lines.append("Chaque équipe fait une étape de fabrication avec son activité en service. "
                 "Les polyvalents aident partout, à moitié efficacité.")
    rows = []
    for key in list(depts) + [""]:
        members = team.get(key, [])
        lines += ["", f"<b>{dept_label(comp['sector'], key)}</b> — {len(members)} membre(s)"]
        for uid, name, poste, duty in members:
            lines.append(f"  {'🟢' if duty else '⚪'} {name} ({poste})")
            if boss:
                rows.append([B(f"✏️ {name[:20]} → équipe", callback_data=f"ch:tm:{uid}")])
    rows.append(_back("ch:co", "⬅️ Chaîne"))
    return "\n".join(lines), M(rows)


async def tm_choose_view(user_id: int, target: int) -> tuple[str, M]:
    comp = await get_user_company(user_id)
    if not comp or not await can_manage(user_id, comp):
        return "❌ Réservé à la direction.", M([_back("ch:team")])
    rows = [[B(dept_label(comp["sector"], d), callback_data=f"ch:td:{target}:{d}")] for d in sector_depts(comp["sector"])]
    rows.append([B("👥 Polyvalent", callback_data=f"ch:td:{target}:-")])
    rows.append(_back("ch:team", "⬅️ Équipes"))
    return "Choisis l'équipe de cette personne :", M(rows)


async def bids_view(user_id: int, note: str = "") -> tuple[str, M]:
    comp = await get_user_company(user_id)
    if not comp:
        return "🏢 Aucune entreprise.", M([_back("hub:entreprises:0")])
    boss = await can_manage(user_id, comp)
    stock = await chain.stock_of(comp["company_id"])
    lines = [f"📥 <b>ACHAT D'INTRANTS — {comp['name']}</b>", "",
             "Les joueurs (métiers) te vendent ces biens au prix que tu affiches. "
             "Si tu en manque, le fournisseur national complète (+50 %, plafonné par jour).", ""]
    if note:
        lines += [note, ""]
    rows = []
    for g in sorted(sector_inputs(comp["sector"])):
        mult = await chain.get_bid_mult(comp["company_id"], g)
        gi = INTRANTS[g]
        lines.append(f"{gi['emoji']} {gi['name']} — <b>{chain.bid_price(g, mult):,}</b> €A/u (×{mult:.1f}) · "
                     f"stock {stock.get(g, 0)} · fourni par {gi['job'] or 'jardin'}")
        if boss:
            rows.append([B(f"➖ {gi['name'][:16]}", callback_data=f"ch:bd:{g}:m"),
                         B(f"➕", callback_data=f"ch:bd:{g}:p")])
    rows.append(_back("ch:co", "⬅️ Chaîne"))
    return "\n".join(lines), M(rows)


async def prices_view(user_id: int, note: str = "") -> tuple[str, M]:
    comp = await get_user_company(user_id)
    if not comp:
        return "🏢 Aucune entreprise.", M([_back("hub:entreprises:0")])
    boss = await can_manage(user_id, comp)
    lines = [f"🏷️ <b>PRIX — {comp['name']}</b>", "",
             "Prix de gros (commerçants) ou de prestation (clients). Le marché national paie le prix national.", ""]
    if note:
        lines += [note, ""]
    rows = []
    for rk in RECIPES_BY_SECTOR[comp["sector"]]:
        r = RECIPES[rk]
        p = await chain.get_price(comp["company_id"], rk)
        lines.append(f"{r['emoji']} {r['name']} — <b>{p:,}</b> €A ({'prestation' if r['type'] == 'service' else 'gros'}) "
                     f"· national {npc_price(rk):,}")
        if boss:
            rows.append([B(f"➖10 % {r['name'][:14]}", callback_data=f"ch:pr:{rk}:d"),
                         B("➕10 %", callback_data=f"ch:pr:{rk}:u")])
    rows.append(_back("ch:co", "⬅️ Chaîne"))
    return "\n".join(lines), M(rows)


async def share_view(user_id: int, note: str = "") -> tuple[str, M]:
    comp = await get_user_company(user_id)
    if not comp or not await can_manage(user_id, comp):
        return "❌ Réservé à la direction.", M([_back("ch:co")])
    st = await chain.get_chain_state(comp["company_id"])
    lines = ["🛒 <b>PART LIVRÉE AU MARCHÉ NATIONAL</b>", "",
             f"Actuellement : <b>{int(st['npc_share'] * 100)} %</b> de la capacité du stade.",
             "Le marché national achète au prix national, plafonné par jour. Atteindre l'objectif du jour "
             "rapporte de l'XP et de la réputation. Ce que tu ne lui vends pas reste en stock pour les "
             "commerçants et les clients."]
    if note:
        lines += ["", note]
    rows = [[B(f"{p} %", callback_data=f"ch:sh:{p}") for p in (0, 25, 50, 75, 100)], _back("ch:co", "⬅️ Chaîne")]
    return "\n".join(lines), M(rows)


async def lvl_view(user_id: int, note: str = "") -> tuple[str, M]:
    comp = await get_user_company(user_id)
    if not comp or not await can_manage(user_id, comp):
        return "❌ Réservé à la direction.", M([_back("ch:co")])
    from utils import payroll
    cur = await payroll.get_level(comp["company_id"])
    lines = ["⚙️ <b>RYTHME DE PRODUCTION</b>", ""]
    if note:
        lines += [note, ""]
    rows = []
    for k, v in PRODUCTION_LEVELS.items():
        lines.append(f"{'👉 ' if k == cur else ''}<b>{v['name']}</b> : unités ×{v['units']}, frais ×{v['cost']}")
        rows.append([B(f"{'✅ ' if k == cur else ''}{v['name']}", callback_data=f"ch:lv:{k}")])
    rows.append(_back("ch:co", "⬅️ Chaîne"))
    return "\n".join(lines), M(rows)


# ═════════════════════════════════════════════════════════════════════════════
#  COMMERÇANT : grossiste · PRESTATIONS · CATALOGUE
# ═════════════════════════════════════════════════════════════════════════════
async def ws_view(user_id: int, note: str = "") -> tuple[str, M]:
    u = await get_user(user_id)
    lines = ["🏭 <b>GROSSISTE</b>", ""]
    if note:
        lines += [note, ""]
    if (u.get("job") or "") != chain.MERCHANT_JOB:
        return ("🛍️ Le grossiste est réservé aux <b>Commerçants</b>.\n"
                "Ils achètent les produits finis aux entreprises et les revendent sur le marché."), M([_back("hub:marche:0")])
    offers = await chain.wholesale_offers(12)
    lines.append(f"💰 Ton solde : <b>{fmt(u['balance'])}</b>")
    rows = []
    if not offers:
        lines += ["", "Aucun produit en stock chez les entreprises pour le moment."]
    for o in offers:
        r = RECIPES[o["recipe"]]
        lines.append(f"{r['emoji']} {r['name']} — {o['company']} · <b>{o['price']:,}</b> €A/u · stock {o['stock']} "
                     f"· revente conseillée ≈ {int(o['price'] * 1.25):,}")
        rows.append([B(f"{r['emoji']} {o['company'][:12]} ×1", callback_data=f"ch:wb:{o['company_id']}:{o['recipe']}:1"),
                     B("×5", callback_data=f"ch:wb:{o['company_id']}:{o['recipe']}:5"),
                     B("×10", callback_data=f"ch:wb:{o['company_id']}:{o['recipe']}:10")])
    rows.append(_back("hub:marche:0"))
    return "\n".join(lines), M(rows)


@require_registered
async def cmd_grossiste(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text, markup = await ws_view(update.effective_user.id)
    await _send(update, text, markup)


async def sv_view(user_id: int, note: str = "") -> tuple[str, M]:
    offers = await chain.service_offers(12)
    lines = ["🛎️ <b>PRESTATIONS</b>", "",
             "Services d'entreprises, réalisés par un employé en service : l'effet s'applique à toi."]
    if note:
        lines += ["", note]
    rows = []
    if not offers:
        lines += ["", "Aucune prestation disponible (il faut du stock et un employé en service)."]
    for o in offers:
        r = RECIPES[o["recipe"]]
        lines.append(f"\n{r['emoji']} <b>{r['name']}</b> — {o['company']} · <b>{o['price']:,}</b> €A · "
                     f"{o['stock']} dispo · {o['workers']} employé(s) en service\n   {describe_effects(r['effects'])}")
        rows.append([B(f"{r['emoji']} {r['name'][:18]} ({o['price']:,})", callback_data=f"ch:sb:{o['company_id']}:{o['recipe']}")])
    rows.append(_back("hub:marche:0"))
    return "\n".join(lines), M(rows)


@require_registered
async def cmd_prestations(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text, markup = await sv_view(update.effective_user.id)
    await _send(update, text, markup)


def catalog_view(idx: int) -> tuple[str, M]:
    idx %= len(SECTORS_CHAIN)
    sec = SECTORS_CHAIN[idx]
    t = SECTOR_TEAMS[sec]
    lines = [f"📚 <b>{t.get('emoji', '')} {sec}</b> ({idx + 1}/{len(SECTORS_CHAIN)})", "",
             "<b>Équipes</b> : " + " · ".join(dept_label(sec, d) for d in sector_depts(sec)), "",
             "<b>Intrants achetés</b> (fournis par les métiers) :"]
    for g in sorted(sector_inputs(sec)):
        gi = INTRANTS[g]
        lines.append(f"  {gi['emoji']} {gi['name']} ← {gi['job'] or 'jardin'}")
    lines += ["", "<b>Produits finis</b> :"]
    for rk in RECIPES_BY_SECTOR[sec]:
        r = RECIPES[rk]
        lines.append(f"{r['emoji']} <b>{r['name']}</b> ({'prestation' if r['type'] == 'service' else 'bien'}) · "
                     f"stade {STAGES[r['min_stage'] - 1]['name']} · {npc_price(rk):,} €A")
        lines.append(f"   ➜ {describe_effects(r['effects'])}")
    rows = [[B("◀️", callback_data=f"ch:cat:{(idx - 1) % len(SECTORS_CHAIN)}"),
             B(f"{idx + 1}/{len(SECTORS_CHAIN)}", callback_data="ch:noop"),
             B("▶️", callback_data=f"ch:cat:{(idx + 1) % len(SECTORS_CHAIN)}")],
            _back("hub:entreprises:0")]
    return "\n".join(lines), M(rows)


@require_registered
async def cmd_catalogue_secteurs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text, markup = catalog_view(0)
    await _send(update, text, markup)


@require_registered
async def cmd_biens(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text, markup = await goods_view(update.effective_user.id)
    await _send(update, text, markup)


# ═════════════════════════════════════════════════════════════════════════════
#  Callbacks `ch:…`
# ═════════════════════════════════════════════════════════════════════════════
async def chain_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    p = (q.data or "").split(":")[1:]
    act = p[0] if p else ""
    await q.answer()
    try:
        text, markup = await _dispatch(q, uid, act, p[1:], context)
    except Exception:
        logger.exception("chain callback %s", q.data)
        text, markup = "⚠️ Une erreur est survenue. Réessaie.", M([[HOME]])
    if text is not None:
        await _edit(q, text, markup)


async def _dispatch(q, uid: int, act: str, a: list[str], context):
    if act == "noop":
        return None, None
    if act == "goods":
        return await goods_view(uid)
    if act == "promo":
        return await promo_view(uid)
    if act == "promoup":
        u = await get_user(uid)
        ok, msg = await chain.promote_job(uid, u.get("job", "") or "")
        return await promo_view(uid, msg)
    if act == "wpromo":
        from utils.input_flow import call_cmd
        from handlers.work import cmd_promotion_poste
        await call_cmd(q, context, cmd_promotion_poste, [])
        return None, None
    if act == "sell":
        return await sell_view(uid, a[0])
    if act == "s":                               # vente à une entreprise
        good, cid, qs = a[0], int(a[1]), a[2]
        n = await _qty(uid, good, qs)
        ok, msg = await chain.sell_to_company(uid, cid, good, n) if n else (False, "❌ Tu n'en as pas.")
        return await sell_view(uid, good, msg)
    if act == "c":
        good, qs = a[0], a[1]
        n = await _qty(uid, good, qs)
        ok, msg = await chain.counter_sell(uid, good, n) if n else (False, "❌ Tu n'en as pas.")
        return await sell_view(uid, good, msg)
    if act == "d":
        good, qs = a[0], a[1]
        comp = await get_user_company(uid)
        n = await _qty(uid, good, qs)
        ok, msg = (await chain.deposit_to_company(uid, comp["company_id"], good, n)
                   if comp and n else (False, "❌ Impossible."))
        return await sell_view(uid, good, msg)
    # ── entreprise ──
    if act == "co":
        return await co_view(uid)
    if act == "diag":
        return await diag_view(uid)
    if act == "guide":
        return await guide_view(uid)
    if act == "lines":
        return await lines_view(uid)
    if act == "team":
        return await team_view(uid)
    if act == "bids":
        return await bids_view(uid)
    if act == "prices":
        return await prices_view(uid)
    if act == "share":
        return await share_view(uid)
    if act == "lvl":
        return await lvl_view(uid)
    comp = await get_user_company(uid)
    boss = bool(comp) and await can_manage(uid, comp)
    if act in ("ln", "tm", "td", "bd", "pr", "sh", "lv") and not boss:
        return "❌ Réservé au créateur et aux gérants.", M([_back("ch:co", "⬅️ Chaîne")])
    if act == "ln":
        ok, msg = await chain.toggle_line(comp["company_id"], a[0])
        return await lines_view(uid, msg)
    if act == "tm":
        return await tm_choose_view(uid, int(a[0]))
    if act == "td":
        ok, msg = await chain.set_member_dept(comp["company_id"], int(a[0]), "" if a[1] == "-" else a[1])
        return await team_view(uid, msg)
    if act == "bd":
        new = await chain.step_bid(comp["company_id"], a[0], BID_STEP if a[1] == "p" else -BID_STEP)
        return await bids_view(uid, f"✅ Prix d'achat réglé à ×{new:.1f}.")
    if act == "pr":
        new = await chain.step_price(comp["company_id"], a[0], 1.1 if a[1] == "u" else 0.9)
        return await prices_view(uid, f"✅ Nouveau prix : {new:,} €A.")
    if act == "sh":
        await chain.set_npc_share(comp["company_id"], int(a[0]) / 100)
        return await share_view(uid, f"✅ Part nationale : {a[0]} %.")
    if act == "lv":
        from utils import payroll
        await payroll.set_level(comp["company_id"], int(a[0]))
        return await lvl_view(uid, "✅ Rythme modifié.")
    # ── commerçant / services ──
    if act == "ws":
        return await ws_view(uid)
    if act == "wb":
        ok, msg = await chain.buy_wholesale(uid, int(a[0]), a[1], int(a[2]))
        return await ws_view(uid, msg)
    if act == "sv":
        return await sv_view(uid)
    if act == "sb":
        ok, msg, _w = await chain.perform_service(uid, int(a[0]), a[1])
        return await sv_view(uid, msg)
    if act == "cat":
        return catalog_view(int(a[0]))
    return None, None
