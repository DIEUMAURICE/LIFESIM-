# handlers/social.py — LIFESIM ULTRA V2
# ✅ Fix #6  : social_boost remplacé par happiness_gain_mult
# ✅ Fix #11 : add_xp() centralisé partout (boost ×2)
# ✅ Fix #14 : INSERT OR IGNORE + relecture (anti race-condition)

from utils.swallow import swallowed
import asyncio
import logging
import random
import re
import json
import aiosqlite
from types import SimpleNamespace
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from database import (
    Outbox,
    DeferredReply,
    DB_PATH, get_user, update_balance, increment_field, update_field, now,
    db_connection, add_notification,
)
from utils.decorators import require_registered, require_free, cooldown
from utils.cooldowns import claim_cooldown
from utils.reseau_rules import POST_COOLDOWN_KEY, POST_COOLDOWN_SECONDS
from utils.notify import notify
from utils.helpers import fmt, fmt_duration, escape_html
from utils.aesthetics import card
from utils.vip import social_bonus, add_xp
from config import (
    SOCIAL_PLATFORMS, SOCIAL_COLLAB_COST, SOCIAL_TRANSFER_TAX,
    SOCIAL_TREND_COST, SOCIAL_TREND_DURATION, SOCIAL_TREND_MULTIPLIER,
    SOCIAL_STORY_DURATION, SOCIAL_MIN_FOLLOWERS_FOR_LIVE, SOCIAL_LIVE_COST_PER_HOUR,
    SOCIAL_LIVE_COST_COINS, SOCIAL_LIVE_CHAT_COOLDOWN, SOCIAL_LIVE_CHAT_MAX_LEN,
    SOCIAL_COIN_NAME, SOCIAL_COIN_STARTING_BALANCE, ADMIN_IDS
)

logger = logging.getLogger(__name__)
from handlers.vehicles import get_active_vehicle
from utils.helpers import safe_edit


# ============================================================================
# HELPER : édition sécurisée
# ============================================================================


async def _notify_proposer(bot, target_id: int, title: str, body_lines: list,
                            icon: str = "🔔", style: str = "round",
                            bdd_msg: str | None = None):
    try:
        await bot.send_message(
            target_id,
            card(title, body_lines, icon=icon, style=style),
            parse_mode="HTML"
        )
    except Exception:
        swallowed('handlers/social.py')
    try:
        await add_notification(target_id, bdd_msg or f"{icon} {title}")
    except Exception:
        swallowed('handlers/social.py')


async def show_plateformes_menu(query, user_id: int):
    text = f"📱 <b>PLATEFORMES SOCIALES</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
    for p in SOCIAL_PLATFORMS:
        text += f"• <b>{p}</b>\n"
    text += (
        f"\n<i>Chaque plateforme a ses propres abonnés et revenus.</i>\n"
        f"💡 Plus tu publies, plus tu gagnes."
    )
    keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="social_menu")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ============================================================================
# FLUX INTERACTIFS
# ============================================================================
async def start_post_flow(query, context):
    context.user_data['social_state'] = "post_platform"
    text = (
        f"📤 <b>PUBLIER UN POST</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Étape 1/2</b> : Choisis une plateforme.\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<i>Coût du post = gratuit · Cooldown = 2h</i>"
    )
    keyboard = []
    row = []
    for i, p in enumerate(SOCIAL_PLATFORMS):
        row.append(InlineKeyboardButton(p, callback_data=f"social_post_platform_{p}"))
        if len(row) == 2:
            keyboard.append(row); row = []
    if row: keyboard.append(row)
    keyboard.append([InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")])
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def ask_post_message(query, context, platform):
    context.user_data['social_state'] = "post_message"
    context.user_data['social_platform'] = platform
    text = (
        f"📤 <b>Post sur {platform}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Étape 2/2</b> : Envoie le <b>contenu</b> de ton post.\n\n"
        f"<i>Un bon post rapporte plus d'abonnés.</i>"
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_story_flow(query, context):
    context.user_data['social_state'] = "story_platform"
    text = (
        f"📸 <b>PUBLIER UNE STORY</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Étape 1/2</b> : Choisis une plateforme.\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<i>Une story dure 24h et rapporte moins qu'un post</i>\n"
        f"<i>Cooldown = 30 minutes de jeu</i>"
    )
    keyboard = []
    row = []
    for p in SOCIAL_PLATFORMS:
        row.append(InlineKeyboardButton(p, callback_data=f"social_story_platform_{p}"))
        if len(row) == 2:
            keyboard.append(row); row = []
    if row: keyboard.append(row)
    keyboard.append([InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")])
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def ask_story_message(query, context, platform):
    context.user_data['social_state'] = "story_message"
    context.user_data['social_platform'] = platform
    text = (
        f"📸 <b>Story sur {platform}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Étape 2/2</b> : Envoie le <b>contenu</b> de ta story."
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_live_flow(query, context):
    context.user_data['social_state'] = "live_platform"
    text = (
        f"🎥 <b>LANCER UN LIVE</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Étape 1/2</b> : Choisis une plateforme.\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<i>Tu gagnes des abonnés pendant le live</i>\n"
        f"<i>Seuil : {SOCIAL_MIN_FOLLOWERS_FOR_LIVE:,} abonnés requis</i>"
    )
    keyboard = []
    row = []
    for p in SOCIAL_PLATFORMS:
        row.append(InlineKeyboardButton(p, callback_data=f"social_live_platform_{p}"))
        if len(row) == 2:
            keyboard.append(row); row = []
    if row: keyboard.append(row)
    keyboard.append([InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")])
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def ask_live_duration(query, context, platform):
    context.user_data['social_state'] = "live_duration"
    context.user_data['social_platform'] = platform
    text = (
        f"🎥 <b>Live sur {platform}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Étape 2/2</b> : Choisis la durée du live.\n\n"
        f"💸 <b>Coût</b> : {SOCIAL_LIVE_COST_PER_HOUR:,} €A / heure + {SOCIAL_LIVE_COST_COINS} {SOCIAL_COIN_NAME}s\n"
        f"<i>(déduits au lancement)</i>\n"
        f"👥 Seuls les membres de ta communauté (tes abonnés) pourront suivre ce live."
    )
    keyboard = [
        [InlineKeyboardButton("⏱️ 1 heure", callback_data="social_live_duration_1"),
         InlineKeyboardButton("⏱️ 2 heures", callback_data="social_live_duration_2")],
        [InlineKeyboardButton("⏱️ 3 heures", callback_data="social_live_duration_3"),
         InlineKeyboardButton("⏱️ 4 heures", callback_data="social_live_duration_4")],
        [InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_donner_live_flow(query, context, user_id):
    async with db_connection() as db:
        async with db.execute(
            "SELECT live_id, user_id, platform, ends_at FROM social_lives WHERE active=1 AND ends_at>? ORDER BY ends_at ASC LIMIT 30",
            (now(),)
        ) as cur:
            all_lives = await cur.fetchall()

    # 🔒 Live réservé à la communauté : on ne montre que les lives des joueurs qu'on suit.
    lives = [l for l in all_lives if await is_follower(user_id, l[1])][:10]

    if not lives:
        text = (
            f"💸 <b>DONNER EN LIVE</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📭 Aucun live actif chez les joueurs que tu suis.\n\n"
            f"<i>Un live n'est visible que par la communauté (abonnés) de l'émetteur.</i>"
        )
        keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="social_menu")]]
        await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
        return

    text = f"💸 <b>DONNER EN LIVE</b>\n━━━━━━━━━━━━━━━━━━━━━━\n<i>Lives de ta communauté :</i>\n\n"
    keyboard = []
    for live_id, streamer_id, platform, ends_at in lives:
        streamer = await get_user(streamer_id)
        name = streamer.get("full_name", f"Joueur {streamer_id}")
        remaining = ends_at - now()
        text += f"🎥 <b>{escape_html(name)}</b> — {platform}\n   ⏳ Se termine dans {fmt_duration(remaining)}\n\n"
        keyboard.append([InlineKeyboardButton(f"💸 Donner à {name[:15]}", callback_data=f"social_donner_live_{live_id}")])
    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="social_menu")])
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_live_chat_flow(query, context, user_id, live_id):
    live = await get_live_info(live_id)
    if not live or live["ends_at"] < now():
        await query.answer("❌ Ce live n'est plus actif.", show_alert=True); return
    if live["user_id"] != user_id:
        await query.answer("🔒 Seul l'émetteur du live peut écrire à sa communauté.", show_alert=True); return
    context.user_data['social_state'] = "live_chat_message"
    context.user_data['social_live_id'] = live_id
    text = (
        f"💬 <b>ÉCRIRE À MA COMMUNAUTÉ</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"Envoie le message à diffuser à tous tes abonnés pendant ce live.\n\n"
        f"<i>Max {SOCIAL_LIVE_CHAT_MAX_LEN} caractères · 1 message / {SOCIAL_LIVE_CHAT_COOLDOWN}s</i>"
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def ask_donner_live_amount(query, context, live_id):
    context.user_data['social_state'] = "donner_live_amount"
    context.user_data['social_live_id'] = live_id
    text = f"💸 <b>DONNER EN LIVE</b>\n━━━━━━━━━━━━━━━━━━━━━━\nEnvoie le <b>montant</b> à donner (ex: 10000)."
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_collab_flow(query, context):
    user_id = query.from_user.id
    active = await get_user_active_collab(user_id)
    if active:
        remaining = active["expires_at"] - now()
        other_id = active["to_id"] if active["from_id"] == user_id else active["from_id"]
        other = await get_user(other_id)
        other_name = other.get("full_name", f"Joueur {other_id}") if other else "?"
        await safe_edit(
            query,
            card("⏳ COLLABORATION EN COURS",
                 [f"Tu es déjà en collaboration avec <b>{escape_html(other_name)}</b>.",
                  f"Type : <b>{escape_html(active['collab_type'])}</b>", "",
                  f"⏳ Fin dans : <b>{fmt_duration(remaining)}</b>", "",
                  "<i>Attends la fin de la collaboration pour en lancer une nouvelle.</i>"],
                 icon="⏳", style="round"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="social_menu")]])
        )
        return

    context.user_data['social_state'] = "collab_target"
    text = (
        f"🤝 <b>PROPOSER UNE COLLABORATION</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Étape 1/3</b> : Envoie le <b>@username</b> ou l'ID du joueur.\n\n"
        f"<i>Coût : {fmt(SOCIAL_COLLAB_COST)}</i>\n"
        f"<i>Durée : 24h (aucune autre collab possible pendant)</i>"
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def ask_collab_type(query, context):
    context.user_data['social_state'] = "collab_type"
    text = f"🤝 <b>Type de collaboration</b>\n━━━━━━━━━━━━━━━━━━━━━━\n<b>Étape 2/3</b> : Choisis le type."
    keyboard = [
        [InlineKeyboardButton("🎥 Live commun", callback_data="social_collab_type_live")],
        [InlineKeyboardButton("🎁 Giveaway", callback_data="social_collab_type_giveaway")],
        [InlineKeyboardButton("🔄 Cross-promo", callback_data="social_collab_type_cross")],
        [InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_vendre_followers_flow(query, context):
    context.user_data['social_state'] = "vendre_target"
    text = (
        f"💰 <b>VENDRE DES FOLLOWERS</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Étape 1/3</b> : Envoie le <b>@username</b> de l'acheteur."
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def ask_vendre_quantity(query, context):
    context.user_data['social_state'] = "vendre_quantity"
    text = f"💰 <b>Quantité à vendre</b>\n━━━━━━━━━━━━━━━━━━━━━━\n<b>Étape 2/3</b> : Envoie le <b>nombre d'abonnés</b> à vendre."
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def ask_vendre_price(query, context):
    context.user_data['social_state'] = "vendre_price"
    text = (
        f"💰 <b>Prix total</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Étape 3/3</b> : Envoie le <b>prix total</b> en coins.\n\n"
        f"<i>Taxe : {int(SOCIAL_TRANSFER_TAX*100)}%</i>"
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_noter_flow(query, context):
    context.user_data['social_state'] = "noter_target"
    text = (
        f"⭐ <b>NOTER UN JOUEUR</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>Étape 1/2</b> : Envoie le <b>@username</b> du joueur."
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def ask_noter_value(query, context):
    context.user_data['social_state'] = "noter_value"
    text = f"⭐ <b>Note</b>\n━━━━━━━━━━━━━━━━━━━━━━\n<b>Étape 2/2</b> : Choisis ta note."
    keyboard = [
        [InlineKeyboardButton("👍 +1 (Positif)", callback_data="social_noter_value_1")],
        [InlineKeyboardButton("👎 -1 (Négatif)", callback_data="social_noter_value_-1")],
        [InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_classement_menu(query, user_id: int):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_in_query
    await show_in_query(query, user_id, 'social')


async def start_creer_communaute_flow(query, context):
    context.user_data['social_state'] = "creer_communaute_name"
    text = (
        f"👥 <b>CRÉER UNE COMMUNAUTÉ</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"Envoie le <b>nom</b> de ta communauté.\n\n"
        f"<i>Coût : 1000 {SOCIAL_COIN_NAME}</i>"
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_socialcoins_menu(query, user_id: int):
    coins = await get_social_coins(user_id)
    text = (
        f"💎 <b>{SOCIAL_COIN_NAME.upper()}S</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💰 Ton solde : <b>{coins}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💡 Gagne des SocialCoins en publiant\n"
        f"🎁 Donne-en à un autre joueur\n"
        f"🏛️ Utilise-les pour créer une communauté (1000)"
    )
    keyboard = [
        [InlineKeyboardButton("🎁 Donner des SocialCoins", callback_data="social_donner_socialcoins")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="social_menu")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_donner_socialcoins_flow(query, context):
    context.user_data['social_state'] = "socialcoins_target"
    text = f"🎁 <b>DONNER DES SOCIALCOINS</b>\n━━━━━━━━━━━━━━━━━━━━━━\n<b>Étape 1/2</b> : Envoie le <b>@username</b> du destinataire."
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_tendance_flow(query, context):
    context.user_data['social_state'] = "tendance_hashtag"
    text = (
        f"🏷️ <b>LANCER UNE TENDANCE</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"Envoie le <b>hashtag</b> (ex: #EarthAngel).\n\n"
        f"<i>Coût : {fmt(SOCIAL_TREND_COST)}</i>\n"
        f"<i>Multiplicateur x{SOCIAL_TREND_MULTIPLIER} pendant {fmt_duration(SOCIAL_TREND_DURATION)}</i>"
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def show_analytiques_menu(query, user_id: int):
    async with db_connection() as db:
        cutoff = now() - 7 * 86400
        cursor = await db.execute(
            "SELECT date(timestamp, 'unixepoch') as day, SUM(gain) FROM social_history WHERE user_id=? AND timestamp > ? GROUP BY day ORDER BY day DESC LIMIT 7",
            (user_id, cutoff)
        )
        rows = await cursor.fetchall()

    if not rows:
        text = f"📈 <b>ANALYTIQUES (7 jours)</b>\n━━━━━━━━━━━━━━━━━━━━━━\n📭 Aucune donnée récente."
    else:
        text = f"📈 <b>ANALYTIQUES (7 jours)</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
        total = 0
        for day, gain in rows:
            text += f"📅 {day} : +{gain:,} abonnés\n"
            total += gain or 0
        text += f"━━━━━━━━━━━━━━━━━━━━━━\n💰 Total : +{total:,} abonnés"

    keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="social_menu")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ============================================================================
# CALLBACK PRINCIPAL
# ============================================================================
async def social_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    action = query.data
    user_id = query.from_user.id

    if action == "social_menu":
        from handlers.hub import open_zone; await open_zone(query, "social"); return
    if action == "social_plateformes":
        await show_plateformes_menu(query, user_id); return

    if action == "social_cancel":
        for k in ('social_state', 'social_platform', 'social_live_id', 'social_target_id',
                  'social_collab_type', 'social_vendre_quantity'):
            context.user_data.pop(k, None)
        await safe_edit(
            query,
            "❌ Action annulée.\n\nAppuie sur « 🎮 Menu principal » ou envoie /start.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
        )
        return

    if action == "social_post":
        await start_post_flow(query, context); return
    if action.startswith("social_post_platform_"):
        platform = action.replace("social_post_platform_", "")
        await ask_post_message(query, context, platform); return

    if action == "social_story":
        await start_story_flow(query, context); return
    if action.startswith("social_story_platform_"):
        platform = action.replace("social_story_platform_", "")
        await ask_story_message(query, context, platform); return

    if action == "social_live":
        await start_live_flow(query, context); return
    if action.startswith("social_live_platform_"):
        platform = action.replace("social_live_platform_", "")
        await ask_live_duration(query, context, platform); return
    if action.startswith("social_live_duration_"):
        duration = int(action.replace("social_live_duration_", ""))
        platform = context.user_data.get('social_platform')
        if not platform:
            await query.answer("Session expirée.", show_alert=True)
            return
        context.user_data.pop('social_state', None)
        context.user_data.pop('social_platform', None)
        await _execute_live(query, user_id, platform, duration); return

    if action == "social_donner_live":
        await start_donner_live_flow(query, context, user_id); return
    if action.startswith("social_donner_live_"):
        try:
            live_id = int(action.replace("social_donner_live_", ""))
        except ValueError:
            await query.answer("Live invalide.", show_alert=True)
            return
        await ask_donner_live_amount(query, context, live_id); return

    if action.startswith("social_live_chat_"):
        try:
            live_id = int(action.replace("social_live_chat_", ""))
        except ValueError:
            await query.answer("Live invalide.", show_alert=True)
            return
        await start_live_chat_flow(query, context, user_id, live_id); return

    if action == "social_collab":
        await start_collab_flow(query, context); return
    if action.startswith("social_collab_type_"):
        collab_type = action.replace("social_collab_type_", "")
        target_id = context.user_data.get('social_target_id')
        if not target_id:
            await query.answer("Session expirée.", show_alert=True)
            return
        context.user_data.pop('social_state', None)
        context.user_data.pop('social_target_id', None)
        await _execute_collab(query, user_id, target_id, collab_type, context); return

    if action == "social_vendre_followers":
        await start_vendre_followers_flow(query, context); return

    if action == "social_noter":
        await start_noter_flow(query, context); return
    if action.startswith("social_noter_value_"):
        value = int(action.replace("social_noter_value_", ""))
        target_id = context.user_data.get('social_target_id')
        if not target_id:
            await query.answer("Session expirée.", show_alert=True)
            return
        context.user_data.pop('social_state', None)
        context.user_data.pop('social_target_id', None)
        await _execute_noter(query, user_id, target_id, value); return

    if action == "social_classement":
        await show_classement_menu(query, user_id); return

    if action == "social_creer_communaute":
        await start_creer_communaute_flow(query, context); return

    if action == "social_socialcoins":
        await show_socialcoins_menu(query, user_id); return
    if action == "social_donner_socialcoins":
        await start_donner_socialcoins_flow(query, context); return

    if action == "social_tendance":
        await start_tendance_flow(query, context); return

    if action == "social_mesabonnes":
        await _show_mes_abonnes(query, user_id); return

    if action == "social_analytiques":
        await show_analytiques_menu(query, user_id); return

    if action.startswith("collab_accept_") or action.startswith("collab_refuse_"):
        await collab_callback_handler(update, context); return
    if action.startswith("buy_followers_") or action.startswith("refuse_followers_"):
        await buy_followers_callback(update, context); return


# ============================================================================
# GESTION DES SAISIES
# ============================================================================
async def handle_social_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return
    state = context.user_data.get('social_state')
    if not state:
        return

    text = update.message.text.strip()
    user_id = update.effective_user.id

    if text.lower() in ("/annuler", "/cancel", "annuler", "cancel"):
        for k in ['social_state', 'social_platform', 'social_live_id', 'social_target_id',
                  'social_collab_type', 'social_vendre_quantity']:
            context.user_data.pop(k, None)
        await update.message.reply_text(
            "❌ Action annulée.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
        )
        return

    if state == "post_message":
        platform = context.user_data.get('social_platform')
        if not platform: return
        context.user_data.pop('social_state', None)
        context.user_data.pop('social_platform', None)

        async with db_connection() as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute("SELECT * FROM social_media WHERE user_id=? AND platform=?", (user_id, platform))
            acc = await cursor.fetchone()
            acc = dict(acc) if acc else None

        if acc and (now() - acc.get("last_post", 0)) < 7200:
            rem = 7200 - (now() - acc["last_post"])
            await update.message.reply_text(f"⏳ Déjà posté récemment. Attends {fmt_duration(rem)}.")
            return

        await _execute_post(update, context, platform, text); return

    if state == "story_message":
        platform = context.user_data.get('social_platform')
        if not platform: return
        context.user_data.pop('social_state', None)
        context.user_data.pop('social_platform', None)
        await _execute_story(update, context, platform); return

    if state == "donner_live_amount":
        live_id = context.user_data.get('social_live_id')
        if not live_id: return
        try:
            amount = int(text)
            if amount <= 0: raise ValueError
        except ValueError:
            await update.message.reply_text("❌ Montant invalide."); return
        context.user_data.pop('social_state', None)
        context.user_data.pop('social_live_id', None)
        await _execute_donner_live(update, context, live_id, amount); return

    if state == "live_chat_message":
        live_id = context.user_data.get('social_live_id')
        if not live_id: return
        context.user_data.pop('social_state', None)
        context.user_data.pop('social_live_id', None)
        await _execute_live_chat_message(update, live_id, text); return

    if state == "collab_target":
        target_id, target_name = await resolve_username_to_id(text)
        if not target_id:
            await update.message.reply_text("❌ Joueur introuvable."); return
        if target_id == user_id:
            await update.message.reply_text("❌ Tu ne peux pas collaborer avec toi-même."); return
        context.user_data['social_target_id'] = target_id
        context.user_data['social_state'] = "collab_type"
        await update.message.reply_text(
            f"🤝 <b>Type de collaboration</b>\n━━━━━━━━━━━━━━━━━━━━━━\nCible : <b>{escape_html(target_name)}</b>\n\n<b>Étape 2/3</b> : Choisis le type.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎥 Live commun", callback_data="social_collab_type_live")],
                [InlineKeyboardButton("🎁 Giveaway", callback_data="social_collab_type_giveaway")],
                [InlineKeyboardButton("🔄 Cross-promo", callback_data="social_collab_type_cross")],
                [InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")],
            ])
        ); return

    if state == "vendre_target":
        target_id, target_name = await resolve_username_to_id(text)
        if not target_id:
            await update.message.reply_text("❌ Joueur introuvable."); return
        if target_id == user_id:
            await update.message.reply_text("❌ Tu ne peux pas te vendre à toi-même."); return
        context.user_data['social_target_id'] = target_id
        context.user_data['social_state'] = "vendre_quantity"
        await update.message.reply_text(
            f"💰 <b>Quantité à vendre</b>\n━━━━━━━━━━━━━━━━━━━━━━\nCible : <b>{escape_html(target_name)}</b>\n\nEnvoie le <b>nombre d'abonnés</b> à vendre.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]])
        ); return

    if state == "vendre_quantity":
        try:
            qty = int(text)
            if qty <= 0: raise ValueError
        except ValueError:
            await update.message.reply_text("❌ Quantité invalide."); return
        total_followers = await get_total_followers(user_id)
        if total_followers < qty:
            await update.message.reply_text(f"❌ Tu n'as que {total_followers} abonnés."); return
        context.user_data['social_vendre_quantity'] = qty
        context.user_data['social_state'] = "vendre_price"
        await update.message.reply_text(
            f"💰 <b>Prix total</b>\n━━━━━━━━━━━━━━━━━━━━━━\nQuantité : <b>{qty}</b> abonnés\n\nEnvoie le <b>prix total</b> en coins.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]])
        ); return

    if state == "vendre_price":
        target_id = context.user_data.get('social_target_id')
        qty = context.user_data.get('social_vendre_quantity')
        if not target_id or not qty:
            await update.message.reply_text("❌ Session expirée. Recommence."); return
        try:
            price = int(text)
            if price <= 0: raise ValueError
        except ValueError:
            await update.message.reply_text("❌ Prix invalide."); return
        context.user_data.pop('social_state', None)
        context.user_data.pop('social_target_id', None)
        context.user_data.pop('social_vendre_quantity', None)
        await _execute_vendre_followers(update, context, target_id, qty, price); return

    if state == "noter_target":
        target_id, target_name = await resolve_username_to_id(text)
        if not target_id:
            await update.message.reply_text("❌ Joueur introuvable."); return
        if target_id == user_id:
            await update.message.reply_text("❌ Tu ne peux pas te noter toi-même."); return
        context.user_data['social_target_id'] = target_id
        context.user_data['social_state'] = "noter_value"
        await update.message.reply_text(
            f"⭐ <b>Note pour {escape_html(target_name)}</b>\n\nChoisis ta note :",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("👍 +1 (Positif)", callback_data="social_noter_value_1")],
                [InlineKeyboardButton("👎 -1 (Négatif)", callback_data="social_noter_value_-1")],
                [InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")],
            ])
        ); return

    if state == "creer_communaute_name":
        context.user_data.pop('social_state', None)
        await _execute_creer_communaute(update, context, text); return

    if state == "socialcoins_target":
        target_id, target_name = await resolve_username_to_id(text)
        if not target_id:
            await update.message.reply_text("❌ Joueur introuvable."); return
        if target_id == user_id:
            await update.message.reply_text("❌ Tu ne peux pas te donner à toi-même."); return
        context.user_data['social_target_id'] = target_id
        context.user_data['social_state'] = "socialcoins_amount"
        await update.message.reply_text(
            f"🎁 <b>Don à {escape_html(target_name)}</b>\n\nEnvoie le <b>montant</b> de {SOCIAL_COIN_NAME} à donner.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Annuler", callback_data="social_cancel")]])
        ); return

    if state == "socialcoins_amount":
        target_id = context.user_data.get('social_target_id')
        if not target_id: return
        try:
            amount = int(text)
            if amount <= 0: raise ValueError
        except ValueError:
            await update.message.reply_text("❌ Montant invalide."); return
        coins = await get_social_coins(user_id)
        if coins < amount:
            await update.message.reply_text(f"❌ Solde insuffisant ({coins} {SOCIAL_COIN_NAME})."); return
        context.user_data.pop('social_state', None)
        context.user_data.pop('social_target_id', None)
        await spend_social_coins(user_id, amount)
        await give_social_coins(target_id, amount)
        target = await get_user(target_id)
        await update.message.reply_text(
            f"✅ <b>Don envoyé !</b>\n\n👤 À : {escape_html(target.get('full_name', 'Joueur'))}\n💎 {amount} {SOCIAL_COIN_NAME}",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
        ); return

    if state == "tendance_hashtag":
        hashtag = text.strip()
        if not hashtag.startswith("#"):
            hashtag = "#" + hashtag
        context.user_data.pop('social_state', None)
        await _execute_tendance(update, context, hashtag); return


# ============================================================================
# EXÉCUTIONS
# ✅ Fix #6 : social_boost → happiness_gain_mult
# ✅ Fix #11 : add_xp() partout
# ✅ Fix #14 : INSERT OR IGNORE + relecture
# ============================================================================
async def run_post(user_id: int, platform: str, message: str) -> dict:
    """UN SEUL moteur de publication (bot Telegram ET application web) : audience gagnée, revenus,
    XP, social coins, publication dans le fil des joueurs, historique, badges. Aucun envoi Telegram ici :
    renvoie les chiffres, chaque interface les affiche à sa façon."""
    u = await get_user(user_id)

    async with db_connection(row_factory=aiosqlite.Row) as db:
        cursor = await db.execute("SELECT * FROM social_media WHERE user_id=? AND platform=?", (user_id, platform))
        acc = await cursor.fetchone()
        acc = dict(acc) if acc else None

    # ✅ FIX #14 : UPSERT atomique (évite la race sur 2 posts simultanés)
    if not acc:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            await db.execute(
                "INSERT OR IGNORE INTO social_media "
                "(user_id, platform, followers, posts, revenue_per_day, last_post) "
                "VALUES (?,?,0,0,0,0)",
                (user_id, platform)
            )
            await db.commit()
            async with db.execute(
                "SELECT followers, posts, revenue_per_day, last_post "
                "FROM social_media WHERE user_id=? AND platform=?",
                (user_id, platform)
            ) as cur:
                row = await cur.fetchone()
        acc = dict(row) if row else {"followers": 0, "posts": 0, "revenue_per_day": 0, "last_post": 0}

    current_followers = acc["followers"]
    creativity = await get_skill(user_id, "Créativité")
    charisma = await get_skill(user_id, "Charisme")
    base_gain = random.randint(10, 200)
    skill_mult = 1 + (creativity + charisma) * 0.05
    follower_gain = int(base_gain * skill_mult)
    karma = u.get("karma", 0)
    if karma > 0:
        follower_gain = int(follower_gain * (1 + min(0.5, karma / 1000)))
    trend_mult = await get_pending_trend_multiplier(user_id)
    if trend_mult > 1.0:
        follower_gain = int(follower_gain * trend_mult)
        await clear_pending_trend(user_id)

    # ✅ FIX #6 : utiliser happiness_gain_mult au lieu de social_boost inexistant
    from handlers.events import get_event_effect
    event_effect = await get_event_effect()
    happiness_boost = event_effect.get("happiness_gain_mult", 1.0)
    if happiness_boost > 1.0:
        follower_gain = int(follower_gain * happiness_boost)

    collab_mult, collab_count = await get_active_collab_bonus(user_id)
    community_mult, community_name, community_size = await get_community_bonus(user_id)
    engagement_mult = await get_platform_engagement_multiplier(user_id, platform)
    rating_mult = await get_social_rating_multiplier(user_id)

    vip_mult = 1 + social_bonus(u)

    follower_gain = int(follower_gain * collab_mult * community_mult * engagement_mult * rating_mult * vip_mult)

    active_vehicle = await get_active_vehicle(user_id)
    luxe_bonus_msg = ""
    if active_vehicle:
        vehicle_luxe = active_vehicle.get("luxury", 0)
        if vehicle_luxe > 80:
            luxe_bonus = 1 + (vehicle_luxe - 80) / 100
            follower_gain = int(follower_gain * luxe_bonus)
            luxe_bonus_msg = f"\n🚗 Bonus luxe : x{luxe_bonus:.2f}"

    viral = random.random() < min(0.24, 0.03 + charisma * 0.01 + collab_count * 0.03)
    viral_mult = round(random.uniform(1.8, 3.0), 2) if viral else 1.0
    follower_gain = max(1, int(follower_gain * viral_mult))
    coin_gain = max(1, follower_gain // 250)

    from utils.gamerules import switch_on
    bot_gives = await switch_on("bot_followers")       # ⚙️ le staff peut couper les abonnés offerts par le bot
    if not bot_gives:
        follower_gain = 0
        coin_gain = 0
    new_followers = current_followers + follower_gain
    if new_followers >= 1_000_000:
        daily_rev = int(new_followers * 0.001)
    elif new_followers >= 100_000:
        daily_rev = int(new_followers * 0.0005)
    elif new_followers >= 10_000:
        daily_rev = int(new_followers * 0.0002)
    else:
        daily_rev = 0

    async with db_connection() as db:
        await db.execute(
            "UPDATE social_media SET posts=posts+1, revenue_per_day=?, last_post=? WHERE user_id=? AND platform=?",
            (daily_rev, now(), user_id, platform)
        )
        await db.commit()

    await add_social_followers_atomic(user_id, platform, follower_gain)

    # ✅ FIX #11 : add_xp applique le boost x2 si actif
    await add_xp(user_id, 40)

    if coin_gain > 0:
        await give_social_coins(user_id, coin_gain)
    try:                                                # 🌐 un seul réseau : le post apparaît dans le fil des joueurs
        from handlers.reseau import publish_post
        await publish_post(user_id, platform, message)
    except Exception:
        logger.exception("Publication dans le fil RP impossible")
    await add_social_history(user_id, platform, "post", follower_gain)
    await check_social_badges(user_id)

    return {
        "follower_gain": follower_gain, "new_followers": new_followers, "daily_rev": daily_rev,
        "vip_mult": vip_mult, "collab_count": collab_count, "collab_mult": collab_mult,
        "community_name": community_name, "community_mult": community_mult,
        "viral": viral, "viral_mult": viral_mult, "luxe_bonus_msg": luxe_bonus_msg,
        "bot_gives": bot_gives, "coin_gain": coin_gain,
    }


async def _execute_post(update: Update, context, platform: str, message: str):
    r = await run_post(update.effective_user.id, platform, message)
    follower_gain, new_followers, daily_rev = r["follower_gain"], r["new_followers"], r["daily_rev"]
    vip_mult, collab_count, collab_mult = r["vip_mult"], r["collab_count"], r["collab_mult"]
    community_name, community_mult = r["community_name"], r["community_mult"]
    viral, viral_mult, luxe_bonus_msg = r["viral"], r["viral_mult"], r["luxe_bonus_msg"]
    bot_gives, coin_gain = r["bot_gives"], r["coin_gain"]

    msg = (
        f"📤 <b>Post publié sur {platform} !</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📝 <i>{escape_html(message[:100])}{'...' if len(message) > 100 else ''}</i>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 +{follower_gain:,} abonnés\n"
        f"👥 Total : {new_followers:,}"
    )
    if daily_rev > 0:
        msg += f"\n💰 Revenu quotidien : {fmt(daily_rev)}"
    if vip_mult > 1:
        msg += f"\n⭐ Bonus abonnement : x{vip_mult:.2f}"
    if collab_count:
        msg += f"\n🤝 Bonus collabs : x{collab_mult:.2f}"
    if community_name:
        msg += f"\n👥 Communauté {community_name} : x{community_mult:.2f}"
    if viral:
        msg += f"\n🚀 Post viral : x{viral_mult}"
    if luxe_bonus_msg:
        msg += luxe_bonus_msg
    if bot_gives:
        msg += f"\n💎 +{coin_gain} {SOCIAL_COIN_NAME}"
    else:
        msg += "\nℹ️ Ton audience vient désormais des autres joueurs : likes et abonnements sur le 🌐 Réseau RP."
    msg += "\n🌐 Visible dans le fil des joueurs.\n✨ +40 XP"

    await update.message.reply_text(
        msg, parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
    )


async def _execute_story(update: Update, context, platform: str):
    user = update.effective_user
    allowed, remaining = await claim_cooldown(user.id, "story_cooldown", 1800)
    if not allowed:
        await update.message.reply_text(f"⏳ Attends encore {fmt_duration(remaining)} avant de publier une autre story.")
        return
    gain = await compute_follower_gain_simple(user.id, platform, factor=0.4)
    collab_mult, collab_count = await get_active_collab_bonus(user.id)
    community_mult, community_name, _ = await get_community_bonus(user.id)
    engagement_mult = await get_platform_engagement_multiplier(user.id, platform)
    gain = max(1, int(gain * collab_mult * community_mult * engagement_mult))

    active_vehicle = await get_active_vehicle(user.id)
    if active_vehicle and active_vehicle.get("luxury", 0) > 80:
        luxe_bonus = 1 + (active_vehicle.get("luxury", 0) - 80) / 100
        gain = int(gain * luxe_bonus)

    coin_gain = max(1, gain // 400)
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO rp_posts (author_id, platform, text, created_at, kind, expires_at) VALUES (?,?,?,?,?,?)",
            (user.id, platform, "story", now(), "story", now() + SOCIAL_STORY_DURATION)
        )
        await db.commit()
    await add_social_history(user.id, platform, "story", gain)
    await add_social_followers_atomic(user.id, platform, gain)
    # ✅ FIX #11
    await add_xp(user.id, 15)
    await give_social_coins(user.id, coin_gain)
    await set_engagement_boost(user.id, platform, 1.15, 3600)

    text = (
        f"📸 <b>Story publiée sur {platform} !</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 +{gain} abonnés\n"
        f"💎 +{coin_gain} {SOCIAL_COIN_NAME}\n"
        f"✨ +15 XP"
    )
    await update.message.reply_text(
        text, parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
    )


async def _execute_live(query, user_id: int, platform: str, duration_h: int):
    ok, err = await check_live_launch_requirements(user_id)
    if not ok:
        await safe_edit(
            query, err, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
        )
        return
    total_followers = await get_total_followers(user_id)

    live_cost = SOCIAL_LIVE_COST_PER_HOUR * duration_h
    u = await get_user(user_id)
    if u.get("balance", 0) < live_cost:
        await safe_edit(
            query,
            f"❌ Solde insuffisant.\n"
            f"💸 Coût du live {duration_h}h : <b>{live_cost:,} €A</b>\n"
            f"💰 Ton solde : <b>{u.get('balance', 0):,} €A</b>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
        )
        return
    await update_balance(user_id, -live_cost, sink="live")
    await spend_social_coins(user_id, SOCIAL_LIVE_COST_COINS)
    u = await get_user(user_id)
    collab_mult, _ = await get_active_collab_bonus(user_id)
    community_mult, _, _ = await get_community_bonus(user_id)
    vip_mult = 1 + social_bonus(u)
    gain = int((total_followers * 0.01 * duration_h + random.randint(10, 500)) * collab_mult * community_mult * vip_mult)

    active_vehicle = await get_active_vehicle(user_id)
    if active_vehicle and active_vehicle.get("luxury", 0) > 80:
        luxe_bonus = 1 + (active_vehicle.get("luxury", 0) - 80) / 100
        gain = int(gain * luxe_bonus)

    coin_gain = max(2, gain // 300)
    await add_social_history(user_id, platform, "live", gain)
    await add_social_followers_atomic(user_id, platform, gain)
    await give_social_coins(user_id, coin_gain)
    live_id = await register_live(user_id, platform, duration_h)

    text = (
        f"🎥 <b>Live démarré sur {platform} !</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"⏱️ Durée : {duration_h}h\n"
        f"💸 Coût : <b>{live_cost:,} €A</b> + {SOCIAL_LIVE_COST_COINS} {SOCIAL_COIN_NAME}s déduits\n"
        f"👥 Abonnés gagnés : ~{gain}\n"
        f"💎 +{coin_gain} {SOCIAL_COIN_NAME}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔒 Seuls les membres de ta communauté peuvent suivre ce live et te faire des dons.\n"
        f"💬 Utilise « Écrire à ma communauté » pour leur envoyer un message pendant le live."
    )
    await safe_edit(
        query, text, parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💬 Écrire à ma communauté", callback_data=f"social_live_chat_{live_id}")],
            [InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")],
        ])
    )


async def _execute_live_chat_message(update: Update, live_id: int, text: str) -> None:
    """Diffuse un message de l'émetteur d'un live à tous les membres de sa communauté (abonnés RP).
    Chat à sens unique (côté émetteur) : chaque abonné le reçoit en notification."""
    sender = update.effective_user
    live = await get_live_info(live_id)
    if not live or live["ends_at"] < now():
        await update.message.reply_text("❌ Ce live n'est plus actif."); return
    if live["user_id"] != sender.id:
        await update.message.reply_text("🔒 Seul l'émetteur du live peut écrire à sa communauté."); return
    text = text.strip()
    if not text:
        await update.message.reply_text("❌ Message vide."); return
    if len(text) > SOCIAL_LIVE_CHAT_MAX_LEN:
        await update.message.reply_text(f"❌ Message trop long (max {SOCIAL_LIVE_CHAT_MAX_LEN} caractères)."); return

    allowed, remaining = await claim_cooldown(sender.id, f"live_chat:{live_id}", SOCIAL_LIVE_CHAT_COOLDOWN)
    if not allowed:
        await update.message.reply_text(f"⏳ Attends encore {remaining}s avant le prochain message."); return

    async with db_connection() as db:
        async with db.execute("SELECT follower_id FROM rp_follows WHERE followee_id=?", (sender.id,)) as cur:
            followers = [row[0] for row in await cur.fetchall()]

    title = f"🔴 Live de {escape_html(sender.full_name)}"
    for follower_id in followers:
        await notify(follower_id, title, escape_html(text), "social")

    await update.message.reply_text(
        f"💬 Message envoyé à <b>{len(followers)}</b> membre(s) de ta communauté.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💬 Écrire encore", callback_data=f"social_live_chat_{live_id}")],
            [InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")],
        ])
    )


async def _execute_donner_live(update: Update, context, live_id: int, amount: int):
    donor = update.effective_user
    live = await get_live_info(live_id)
    if not live or live["ends_at"] < now():
        await update.message.reply_text("❌ Ce live n'est plus actif."); return
    if live["user_id"] == donor.id:
        await update.message.reply_text("❌ Tu ne peux pas te donner à toi-même."); return
    if not await is_follower(donor.id, live["user_id"]):
        await update.message.reply_text(
            "🔒 Ce live est réservé à la communauté (abonnés) de l'émetteur. Suis-le pour pouvoir le soutenir."
        ); return

    try:
        async with db_connection() as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
                    (amount, amount, donor.id, amount),
                )
                if debit.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Solde insuffisant.")
                await db.execute(
                    "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                    (amount, amount, live["user_id"]),
                )
                await db.commit()
            except Exception:
                await db.rollback(); raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    bonus_followers = max(1, amount // 1500)
    coin_gain = max(1, amount // 5000)
    await add_social_followers_atomic(live["user_id"], "live_tip", bonus_followers)
    await give_social_coins(live["user_id"], coin_gain)

    try:
        await context.bot.send_message(
            live["user_id"],
            f"💸 <b>{escape_html(donor.full_name)}</b> t'a envoyé {fmt(amount)} en live !\n"
            f"+{bonus_followers} abonnés, +{coin_gain} {SOCIAL_COIN_NAME}",
            parse_mode="HTML"
        )
    except Exception:
        swallowed('handlers/social.py')

    await update.message.reply_text(
        f"✅ <b>Don envoyé !</b>\n\n💰 Montant : {fmt(amount)}\n👥 Le streameur a gagné +{bonus_followers} abonnés",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
    )


async def _execute_collab(query, user_id: int, target_id: int, collab_type: str, context):
    from gameplay.social_collabs import SocialCollabError, create_request
    try:
        request = await create_request(user_id, target_id, collab_type, notify_target=False)
    except SocialCollabError as exc:
        await safe_edit(
            query, f"❌ {escape_html(str(exc))}", parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="social_menu")]]),
        )
        return
    request_id = request["request_id"]

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Accepter", callback_data=f"collab_accept_{request_id}"),
         InlineKeyboardButton("❌ Refuser", callback_data=f"collab_refuse_{request_id}")]
    ])

    try:
        await context.bot.send_message(
            target_id,
            f"🤝 <b>{escape_html(request['requester_name'])}</b> te propose une collaboration.\n"
            f"Type : <b>{escape_html(request['type_label'])}</b>\nDurée : <b>{request['duration_h']}h</b>",
            reply_markup=keyboard,
            parse_mode="HTML"
        )
    except Exception:
        swallowed('handlers/social.py')

    await safe_edit(
        query,
        f"✅ <b>Demande envoyée à {escape_html(request['target_name'])}</b>\n\n"
        f"Type : {escape_html(request['type_label'])}\nEn attente de réponse...",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
    )


async def _execute_vendre_followers(update: Update, context, target_id: int, quantity: int, price: int):
    user = update.effective_user
    offer_id = await create_follower_offer(user.id, target_id, quantity, price)
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("💰 Acheter", callback_data=f"buy_followers_{offer_id}"),
         InlineKeyboardButton("❌ Refuser", callback_data=f"refuse_followers_{offer_id}")]
    ])
    try:
        await context.bot.send_message(
            target_id,
            f"💵 <b>Offre de {escape_html(user.full_name)}</b>\n\n"
            f"📊 Quantité : {quantity} abonnés\n"
            f"💰 Prix : {fmt(price)}\n"
            f"<i>Taxe incluse : {int(SOCIAL_TRANSFER_TAX*100)}%</i>",
            reply_markup=keyboard,
            parse_mode="HTML"
        )
    except Exception:
        swallowed('handlers/social.py')

    await update.message.reply_text(
        f"✅ <b>Offre envoyée !</b>\n\n📊 {quantity} abonnés pour {fmt(price)}\nEn attente de réponse...",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
    )


async def _execute_noter(query, user_id: int, target_id: int, delta: int):
    async with db_connection() as db:
        cursor = await db.execute(
            "SELECT delta FROM social_reputation WHERE user_id=? AND rater_id=?",
            (target_id, user_id)
        )
        previous = await cursor.fetchone()
        diff = delta - (previous[0] if previous else 0)
        await db.execute(
            "INSERT OR REPLACE INTO social_reputation (user_id, rater_id, delta, created_at) VALUES (?,?,?,?)",
            (target_id, user_id, delta, now())
        )
        await db.execute("UPDATE users SET social_rating = social_rating + ? WHERE user_id=?", (diff, target_id))
        await db.commit()

    target = await get_user(target_id)
    emoji = "👍" if delta > 0 else "👎"
    await safe_edit(
        query,
        f"⭐ <b>Note enregistrée !</b>\n\n{emoji} Note : {delta:+d}\n👤 Pour : {escape_html(target.get('full_name', 'Joueur'))}",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
    )


async def _execute_creer_communaute(update: Update, context, name: str):
    user = update.effective_user
    name = name.strip()[:50]
    if len(name) < 3:
        await update.message.reply_text("❌ Le nom doit faire au moins 3 caractères."); return

    coins = await get_social_coins(user.id)
    if coins < 1000:
        await update.message.reply_text(f"❌ Il faut 1000 {SOCIAL_COIN_NAME}."); return
    await spend_social_coins(user.id, 1000)

    async with db_connection() as db:
        await db.execute("INSERT INTO social_communities (name, owner_id, created_at) VALUES (?,?,?)", (name, user.id, now()))
        cursor = await db.execute("SELECT last_insert_rowid()")
        community_id = (await cursor.fetchone())[0]
        await db.execute(
            "INSERT INTO social_community_members (community_id, user_id, role, joined_at) VALUES (?,?,?,?)",
            (community_id, user.id, "owner", now())
        )
        await db.commit()

    await update.message.reply_text(
        f"✅ <b>Communauté créée !</b>\n\n👥 <b>{escape_html(name)}</b>\n🆔 ID : {community_id}\n💰 Coût : 1000 {SOCIAL_COIN_NAME}",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
    )


async def _execute_tendance(update: Update, context, hashtag: str):
    user = update.effective_user
    u = await get_user(user.id)
    if u["balance"] < SOCIAL_TREND_COST:
        await update.message.reply_text(f"❌ Solde insuffisant. Besoin de {fmt(SOCIAL_TREND_COST)}."); return
    await update_balance(user.id, -SOCIAL_TREND_COST, sink="reseaux")
    expires = now() + SOCIAL_TREND_DURATION
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO social_trends (hashtag, creator_id, multiplier, expires_at) VALUES (?,?,?,?)",
            (hashtag, user.id, SOCIAL_TREND_MULTIPLIER, expires)
        )
        await db.commit()

    await update.message.reply_text(
        f"✅ <b>Tendance lancée !</b>\n\n🏷️ {hashtag}\n📈 Multiplicateur x{SOCIAL_TREND_MULTIPLIER}\n⏱️ Durée : {fmt_duration(SOCIAL_TREND_DURATION)}",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🌐 Retour Réseaux", callback_data="social_menu")]])
    )


async def _show_mes_abonnes(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT platform, followers, posts, revenue_per_day FROM social_media WHERE user_id=? ORDER BY followers DESC",
            (user_id,)
        )
        rows = await cursor.fetchall()

    if not rows:
        text = f"📊 <b>MES ABONNÉS</b>\n━━━━━━━━━━━━━━━━━━━━━━\n📭 Aucune activité sociale."
    else:
        text = f"📊 <b>MES ABONNÉS</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
        total_followers = 0
        total_revenue = 0
        for r in rows:
            text += f"📱 <b>{r['platform']}</b>\n   👥 {r['followers']:,} | 📝 {r['posts']} posts\n   💰 {fmt(r['revenue_per_day'])}/jour\n"
            total_followers += r['followers']
            total_revenue += r['revenue_per_day']
        text += f"━━━━━━━━━━━━━━━━━━━━━━\n👥 Total : {total_followers:,}\n💰 Revenus : {fmt(total_revenue)}/jour"

    keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="social_menu")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ============================================================================
# HELPERS INTERNES
# ============================================================================
async def resolve_username_to_id(text: str) -> tuple[int, str] | tuple[None, None]:
    """ID d'abord, puis @pseudo (joueur inscrit)."""
    from utils.user_lookup import find_user
    row = await find_user(text, registered_only=True)
    return (row["user_id"], row["full_name"]) if row else (None, None)


# ============================================================================
# COMMANDES DE BASE
# ============================================================================
@require_registered
@require_free
async def cmd_plateformes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = "📱 <b>Plateformes sociales</b>\n\n" + "\n".join(f"• {p}" for p in SOCIAL_PLATFORMS)
    text += "\n\n💡 <i>Utilise le menu → Réseaux pour un menu interactif</i>"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
@cooldown(POST_COOLDOWN_KEY, POST_COOLDOWN_SECONDS)
async def cmd_poster(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text(
            f"📤 <b>Publier un post</b>\n\nOuvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux."
            f"Plateformes : {', '.join(SOCIAL_PLATFORMS)}\n\n"
            f"💡 <i>Utilise le menu → Réseaux pour un menu interactif</i>",
            parse_mode="HTML"
        )
        return
    platform = context.args[0]
    if platform not in SOCIAL_PLATFORMS:
        await update.message.reply_text("❌ Plateforme inconnue."); return
    message = " ".join(context.args[1:])
    await _execute_post(update, context, platform, message)


@require_registered
@require_free
@cooldown("story_cooldown", 1800)
async def cmd_story(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text(
            f"📸 <b>Publier une story</b>\n\nOuvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.\n"
            f"💡 <i>Utilise le menu → Réseaux pour un menu interactif</i>",
            parse_mode="HTML"
        )
        return
    platform = context.args[0]
    if platform not in SOCIAL_PLATFORMS:
        await update.message.reply_text("❌ Plateforme inconnue."); return
    await _execute_story(update, context, platform)


@require_registered
@require_free
@cooldown("live_cooldown", 43200)
async def cmd_live(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text(
            f"🎥 <b>Lancer un live</b>\n\nOuvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.\n"
            f"💡 <i>Utilise le menu → Réseaux pour un menu interactif</i>",
            parse_mode="HTML"
        )
        return
    platform = context.args[0]
    duration_h = 1
    if len(context.args) > 1:
        try:
            duration_h = max(1, min(4, int(context.args[1])))
        except ValueError:
            swallowed('handlers/social.py')
    if platform not in SOCIAL_PLATFORMS:
        await update.message.reply_text("❌ Plateforme inconnue."); return

    ok, err = await check_live_launch_requirements(update.effective_user.id)
    if not ok:
        await update.message.reply_text(err, parse_mode="HTML"); return
    total_followers = await get_total_followers(update.effective_user.id)
    u = await get_user(update.effective_user.id)
    collab_mult, _ = await get_active_collab_bonus(update.effective_user.id)
    community_mult, _, _ = await get_community_bonus(update.effective_user.id)
    vip_mult = 1 + social_bonus(u)
    gain = int((total_followers * 0.01 * duration_h + random.randint(10, 500)) * collab_mult * community_mult * vip_mult)
    coin_gain = max(2, gain // 300)
    live_cost = SOCIAL_LIVE_COST_PER_HOUR * duration_h
    if u.get("balance", 0) < live_cost:
        await update.message.reply_text(f"❌ Solde insuffisant : {live_cost:,} €A requis."); return
    await update_balance(update.effective_user.id, -live_cost, sink="live")
    await spend_social_coins(update.effective_user.id, SOCIAL_LIVE_COST_COINS)
    await add_social_history(update.effective_user.id, platform, "live", gain)
    await add_social_followers_atomic(update.effective_user.id, platform, gain)
    await give_social_coins(update.effective_user.id, coin_gain)
    live_id = await register_live(update.effective_user.id, platform, duration_h)
    await update.message.reply_text(
        f"🎥 <b>Live démarré sur {platform} pour {duration_h}h</b>\n\n"
        f"💸 Coût : {live_cost:,} €A + {SOCIAL_LIVE_COST_COINS} {SOCIAL_COIN_NAME}s\n"
        f"👥 Abonnés gagnés : ~{gain}\n💎 +{coin_gain} {SOCIAL_COIN_NAME}\n\n"
        f"🔒 Réservé à ta communauté (live n°{live_id}) — ouvre le menu Réseaux pour leur écrire.",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_donner_live(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text(
            f"💸 <b>Donner en live</b>\n\nOuvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.",
            parse_mode="HTML"
        )
        return
    try:
        live_id = int(context.args[0])
        amount = int(context.args[1])
        if live_id <= 0 or amount <= 0: raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides."); return
    await _execute_donner_live(update, context, live_id, amount)


@require_registered
async def cmd_analytiques(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    days = 7
    platform = None
    for arg in context.args:
        if arg.startswith("--periode"):
            try: days = int(arg.split("=")[1])
            except Exception: swallowed('handlers/social.py')
        elif arg in SOCIAL_PLATFORMS:
            platform = arg
    async with db_connection() as db:
        cutoff = now() - days * 86400
        if platform:
            cursor = await db.execute(
                "SELECT date(timestamp, 'unixepoch') as day, SUM(gain) FROM social_history WHERE user_id=? AND platform=? AND timestamp > ? GROUP BY day ORDER BY day DESC LIMIT ?",
                (user.id, platform, cutoff, days)
            )
        else:
            cursor = await db.execute(
                "SELECT date(timestamp, 'unixepoch') as day, SUM(gain) FROM social_history WHERE user_id=? AND timestamp > ? GROUP BY day ORDER BY day DESC LIMIT ?",
                (user.id, cutoff, days)
            )
        rows = await cursor.fetchall()
    if not rows:
        await update.message.reply_text("📭 Aucune donnée."); return
    lines = [f"📈 Évolution (derniers {days} jours)"]
    for row in rows:
        lines.append(f"{row[0]} : +{row[1]} abonnés")
    await update.message.reply_text("\n".join(lines))


# ============================================================================
# COMMANDES MULTIJOUEUR
# ============================================================================
@require_registered
@require_free
async def cmd_collab(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.reply_to_message:
        await update.message.reply_text(
            f"🤝 <b>Collaboration</b>\n\nRéponds au message du joueur avec qui collaborer.\n\n"
            f"💡 <i>Utilise le menu → Réseaux pour un menu interactif</i>",
            parse_mode="HTML"
        )
        return
    target = update.message.reply_to_message.from_user
    if target.id == update.effective_user.id:
        await update.message.reply_text("❌ Impossible de collaborer avec soi-même."); return
    collab_type = "live"
    for i, arg in enumerate(context.args):
        if arg == "--type" and i + 1 < len(context.args):
            if context.args[i + 1] in ("live", "giveaway", "cross"):
                collab_type = context.args[i + 1]
    u = await get_user(update.effective_user.id)
    if u["balance"] < SOCIAL_COLLAB_COST:
        await update.message.reply_text(f"❌ Solde insuffisant. Besoin {fmt(SOCIAL_COLLAB_COST)}."); return

    class FakeQuery:
        async def edit_message_text(self, *a, **k): pass
        async def answer(self, *a, **k): pass
    await _execute_collab(FakeQuery(), update.effective_user.id, target.id, collab_type, context)
    await update.message.reply_text("✅ Demande envoyée.")


@require_registered
@require_free
async def cmd_vendre_followers(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 3:
        await update.message.reply_text("💰 Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.", parse_mode="HTML"); return
    target_id, _ = await resolve_username_to_id(context.args[0])
    if not target_id:
        await update.message.reply_text("❌ Joueur introuvable."); return
    try:
        quantity = int(context.args[1])
        price = int(context.args[2])
        if quantity <= 0 or price <= 0: raise ValueError
    except Exception:
        await update.message.reply_text("❌ Quantité/prix invalides."); return
    await _execute_vendre_followers(update, context, target_id, quantity, price)


@require_registered
@require_free
@cooldown("social_rating_cooldown", 3600)
async def cmd_noter_social(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("⭐ Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.", parse_mode="HTML"); return
    target_id, _ = await resolve_username_to_id(context.args[0])
    if not target_id or target_id == update.effective_user.id:
        await update.message.reply_text("❌ Utilisateur invalide."); return
    try:
        delta = int(context.args[1])
        if delta not in (-1, 1): raise ValueError
    except Exception:
        await update.message.reply_text("❌ Note doit être +1 ou -1."); return

    class FakeQuery:
        async def edit_message_text(self, *a, **k): pass
        async def answer(self, *a, **k): pass
    await _execute_noter(FakeQuery(), update.effective_user.id, target_id, delta)
    await update.message.reply_text(f"⭐ Note {delta:+d} enregistrée.")


@require_registered
async def cmd_classement_social(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_for_update
    await show_for_update(update, 'social')


# ============================================================================
# COMMUNAUTÉS
# ============================================================================
@require_registered
@require_free
@cooldown("create_community_cooldown", 86400)
async def cmd_creer_communaute(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("👥 Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.", parse_mode="HTML"); return
    name = " ".join(context.args)
    await _execute_creer_communaute(update, context, name)


@require_registered
@require_free
async def cmd_inviter_communaute(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("👥 Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.", parse_mode="HTML"); return
    try:
        community_id = int(context.args[0])
    except Exception:
        await update.message.reply_text("❌ ID invalide."); return
    target_id, _ = await resolve_username_to_id(context.args[1])
    if not target_id:
        await update.message.reply_text("❌ Joueur introuvable."); return
    user = update.effective_user
    try:
        async with db_connection() as db:
            cursor = await db.execute(
                "SELECT role FROM social_community_members WHERE community_id=? AND user_id=?",
                (community_id, user.id)
            )
            row = await cursor.fetchone()
            if not row or row[0] not in ('owner', 'admin'):
                raise DeferredReply(update.message.reply_text, "❌ Tu n'es pas autorisé.")
            await db.execute(
                "INSERT INTO social_community_invites (community_id, invited_id, inviter_id, created_at) VALUES (?,?,?,?)",
                (community_id, target_id, user.id, now())
            )
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()
    await update.message.reply_text(f"✅ Invitation envoyée.")
    try:
        await context.bot.send_message(
            target_id,
            f"👥 Invitation à rejoindre la communauté #{community_id}.\nAccepte-la depuis le menu Réseaux."
        )
    except Exception:
        swallowed('handlers/social.py')


@require_registered
async def cmd_communaute(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    community = await get_user_community(user.id)
    if community:
        async with db_connection() as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("""
                SELECT u.full_name, m.role FROM social_community_members m
                JOIN users u ON u.user_id = m.user_id
                WHERE m.community_id=?
                ORDER BY CASE WHEN m.role='owner' THEN 0 WHEN m.role='admin' THEN 1 ELSE 2 END
                LIMIT 12
            """, (community["community_id"],)) as cur:
                members = await cur.fetchall()
        lines = [f"👥 <b>{escape_html(community['name'])}</b>", f"Membres : {community['member_count']}", ""]
        for m in members:
            badge = "👑" if m["role"] == "owner" else ("🛡️" if m["role"] == "admin" else "•")
            lines.append(f"{badge} {escape_html(m['full_name'])} — {m['role']}")
        await update.message.reply_text("\n".join(lines), parse_mode="HTML")
        return
    async with db_connection() as db:
        cursor = await db.execute("""
            SELECT c.community_id, c.name, COUNT(m.user_id) AS members
            FROM social_communities c
            LEFT JOIN social_community_members m ON m.community_id = c.community_id
            WHERE c.disbanded = 0
            GROUP BY c.community_id
            ORDER BY members DESC LIMIT 5
        """)
        rows = await cursor.fetchall()
    if not rows:
        await update.message.reply_text("📭 Aucune communauté."); return
    lines = ["👥 <b>COMMUNAUTÉS POPULAIRES</b>\n"]
    for row in rows:
        lines.append(f"#{row[0]} — {escape_html(row[1])} ({row[2]} membres)")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


@require_registered
@require_free
async def cmd_rejoindre_communaute(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) != 1:
        await update.message.reply_text("👥 Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.", parse_mode="HTML"); return
    try:
        community_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID invalide."); return
    user = update.effective_user
    if await get_user_community(user.id):
        await update.message.reply_text("❌ Déjà dans une communauté."); return
    try:
        async with db_connection() as db:
            db.row_factory = aiosqlite.Row
            cursor = await db.execute(
                "SELECT invite_id FROM social_community_invites WHERE community_id=? AND invited_id=? AND status='pending'",
                (community_id, user.id)
            )
            invite = await cursor.fetchone()
            if not invite:
                raise DeferredReply(update.message.reply_text, "❌ Aucune invitation en attente.")
            cursor = await db.execute("SELECT name FROM social_communities WHERE community_id=? AND disbanded=0", (community_id,))
            community = await cursor.fetchone()
            if not community:
                raise DeferredReply(update.message.reply_text, "❌ Communauté inexistante.")
            await db.execute(
                "INSERT OR IGNORE INTO social_community_members (community_id, user_id, role, joined_at) VALUES (?,?,?,?)",
                (community_id, user.id, "member", now())
            )
            await db.execute("UPDATE social_community_invites SET status='accepted' WHERE invite_id=?", (invite["invite_id"],))
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()
    await update.message.reply_text(f"✅ Rejoint <b>{escape_html(community['name'])}</b>", parse_mode="HTML")


# ============================================================================
# PARTAGES ET TENDANCES
# ============================================================================
@require_registered
@require_free
@cooldown("share_cooldown", 3600)
async def cmd_partager(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.reply_to_message:
        await update.message.reply_text("🔄 Réponds au message d'un joueur pour partager son post."); return
    target = update.message.reply_to_message.from_user
    if target.id == update.effective_user.id:
        await update.message.reply_text("❌ Impossible de se partager soi-même."); return
    try:
        async with db_connection() as db:
            cursor = await db.execute("SELECT 1 FROM social_media WHERE user_id=? AND posts>0", (target.id,))
            if not await cursor.fetchone():
                raise DeferredReply(update.message.reply_text, "❌ Ce joueur n'a jamais posté.")
    except DeferredReply as _deferred:
        return await _deferred.send()
    gain = random.randint(5, 50)
    await add_social_followers_atomic(update.effective_user.id, "share", gain)
    await add_social_followers_atomic(target.id, "share", gain)
    await update.message.reply_text(f"🔄 +{gain} abonnés pour vous et {escape_html(target.full_name)}", parse_mode="HTML")


@require_registered
@require_free
@cooldown("trend_cooldown", 86400)
async def cmd_lancer_tendance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("🏷️ Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.", parse_mode="HTML"); return
    hashtag = context.args[0]
    if not hashtag.startswith("#"):
        hashtag = "#" + hashtag
    await _execute_tendance(update, context, hashtag)


@require_registered
@require_free
async def cmd_utiliser_tendance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 1:
        await update.message.reply_text("🏷️ Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.", parse_mode="HTML"); return
    hashtag = context.args[0]
    if not hashtag.startswith("#"):
        hashtag = "#" + hashtag
    try:
        async with db_connection() as db:
            cursor = await db.execute("SELECT multiplier FROM social_trends WHERE hashtag=? AND expires_at>?", (hashtag, now()))
            trend = await cursor.fetchone()
            if not trend:
                raise DeferredReply(update.message.reply_text, "❌ Tendance inactive.")
            await db.execute(
                "INSERT OR REPLACE INTO social_user_trends (user_id, hashtag, multiplier, used) VALUES (?,?,?,0)",
                (update.effective_user.id, hashtag, trend[0])
            )
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()
    await update.message.reply_text(f"🏷️ Tendance {hashtag} activée (x{trend[0]}).")


# ============================================================================
# SOCIALCOINS
# ============================================================================
@require_registered
async def cmd_socialcoins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    coins = await get_social_coins(update.effective_user.id)
    await update.message.reply_text(f"💎 {SOCIAL_COIN_NAME} : {coins}")


@require_registered
@require_free
async def cmd_donner_socialcoins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("🎁 Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.", parse_mode="HTML"); return
    target_id, _ = await resolve_username_to_id(context.args[0])
    if not target_id or target_id == update.effective_user.id:
        await update.message.reply_text("❌ Utilisateur invalide."); return
    try:
        amount = int(context.args[1])
        if amount <= 0: raise ValueError
    except Exception:
        await update.message.reply_text("❌ Montant invalide."); return
    coins = await get_social_coins(update.effective_user.id)
    if coins < amount:
        await update.message.reply_text(f"❌ Solde insuffisant ({coins})."); return
    await spend_social_coins(update.effective_user.id, amount)
    await give_social_coins(target_id, amount)
    await update.message.reply_text(f"💸 {amount} {SOCIAL_COIN_NAME} donnés.")


# ============================================================================
# COMMANDES UTILITAIRES
# ============================================================================
@require_registered
async def cmd_mesabonnes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT platform, followers, posts, revenue_per_day FROM social_media WHERE user_id=? ORDER BY followers DESC",
            (update.effective_user.id,)
        )
        rows = await cursor.fetchall()
    if not rows:
        await update.message.reply_text("📭 Aucune activité sociale."); return
    lines = ["📊 <b>VOS RÉSEAUX</b>"]
    total_f = 0
    total_r = 0
    for r in rows:
        lines.append(f"{r['platform']} : 👥 {r['followers']:,} | 💰 {fmt(r['revenue_per_day'])}/j")
        total_f += r['followers']
        total_r += r['revenue_per_day']
    lines.append(f"━━━\n👥 Total : {total_f:,} | 💰 {fmt(total_r)}/j")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


# ============================================================================
# CALLBACKS DES ACCORDS
# ============================================================================
async def collab_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user_id = query.from_user.id
    user_name = query.from_user.full_name or "Un joueur"

    if data.startswith("collab_accept_"):
        action = "collab_accept"
        try:
            request_id = int(data.replace("collab_accept_", ""))
        except ValueError:
            await query.edit_message_text("❌ Format invalide."); return
    elif data.startswith("collab_refuse_"):
        action = "collab_refuse"
        try:
            request_id = int(data.replace("collab_refuse_", ""))
        except ValueError:
            await query.edit_message_text("❌ Format invalide."); return
    else:
        await query.edit_message_text("❌ Format invalide."); return
    from gameplay.social_collabs import SocialCollabError, respond_to_request
    decision = "accept" if action == "collab_accept" else "refuse"
    try:
        result = await respond_to_request(request_id, user_id, decision, notify_requester=False)
    except SocialCollabError as exc:
        await query.edit_message_text(f"❌ {escape_html(str(exc))}")
        return
    from_id = result["from_id"]
    collab_type = escape_html(result["type_label"])
    duration_h = result["duration_h"]
    if decision == "accept":
        await query.edit_message_text("✅ Collaboration acceptée !")
        title = "🤝 COLLABORATION ACCEPTÉE"
        lines = [f"Par : <b>{escape_html(user_name)}</b>", f"Type : <b>{collab_type}</b>",
                 f"Durée : <b>{duration_h}h</b>", "", "<i>Votre collaboration est active. Publie et profite du bonus !</i>"]
        icon = "🤝"
    else:
        await query.edit_message_text("❌ Collaboration refusée.")
        title = "❌ COLLABORATION REFUSÉE"
        lines = [f"Par : <b>{escape_html(user_name)}</b>", f"Type : <b>{collab_type}</b>", "",
                 "<i>Dommage, retente ta chance avec un autre joueur !</i>"]
        icon = "❌"
    message = (f"{icon} {user_name} a accepté ta collaboration ({collab_type}, {duration_h} h). "
               f"Vous avez chacun gagné +100 abonnés."
               if decision == "accept" else f"{icon} {user_name} a refusé ta collaboration ({collab_type})")
    await _notify_proposer(
        context.bot, from_id, title, lines, icon=icon,
        style="stars" if decision == "accept" else "round", bdd_msg=message,
    )


async def buy_followers_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user_id = query.from_user.id
    user_name = query.from_user.full_name or "Un joueur"

    if data.startswith("buy_followers_"):
        action = "buy"
        try:
            offer_id = int(data.replace("buy_followers_", ""))
        except ValueError:
            await query.edit_message_text("❌ Format invalide."); return
    elif data.startswith("refuse_followers_"):
        action = "refuse"
        try:
            offer_id = int(data.replace("refuse_followers_", ""))
        except ValueError:
            await query.edit_message_text("❌ Format invalide."); return
    else:
        await query.edit_message_text("❌ Format invalide."); return

    async with db_connection() as db:
        async with db.execute(
            "SELECT seller_id, buyer_id, quantity, price, status FROM social_follower_offers WHERE offer_id=?",
            (offer_id,)
        ) as cur:
            offer = await cur.fetchone()

    if not offer:
        await query.edit_message_text("❌ Offre introuvable."); return

    seller_id, buyer_id, quantity, price, status = offer

    if buyer_id != user_id:
        await query.answer("⛔ Ce n'est pas ton offre.", show_alert=True); return
    if status != "pending":
        await query.edit_message_text(f"⚠️ Déjà traitée ({status})."); return

    if action == "buy":
        success = await execute_follower_transfer(offer_id)
        if success:
            await query.edit_message_text("✅ Achat effectué !")
            await _notify_proposer(
                context.bot, seller_id, "💰 FOLLOWERS VENDUS",
                [f"Acheteur : <b>{escape_html(user_name)}</b>",
                 f"Quantité : <b>{quantity}</b> abonnés",
                 f"Prix reçu : <b>{fmt(price)}</b>",
                 f"<i>(après taxe {int(SOCIAL_TRANSFER_TAX*100)}% : {fmt(int(price * (1 - SOCIAL_TRANSFER_TAX)))})</i>",
                 "", "<i>La transaction est complète.</i>"],
                icon="💰", style="stars",
                bdd_msg=f"💰 {user_name} a acheté {quantity} followers pour {fmt(price)}",
            )
        else:
            await query.edit_message_text("❌ Échec de l'achat (fonds insuffisants ou stock épuisé).")
    elif action == "refuse":
        await refuse_follower_offer(offer_id)
        await query.edit_message_text("❌ Offre refusée.")
        await _notify_proposer(
            context.bot, seller_id, "❌ OFFRE DE FOLLOWERS REFUSÉE",
            [f"Par : <b>{escape_html(user_name)}</b>",
             f"Quantité proposée : <b>{quantity}</b>",
             f"Prix : <b>{fmt(price)}</b>", "",
             "<i>Tu peux retenter avec un autre joueur.</i>"],
            icon="❌", style="round",
            bdd_msg=f"❌ {user_name} a refusé ton offre de {quantity} followers",
        )


# ============================================================================
# SONDAGES
# ============================================================================
@require_registered
async def cmd_sondage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 3:
        await update.message.reply_text('📊 Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.', parse_mode="HTML"); return
    args_str = " ".join(context.args)
    matches = re.findall(r'"([^"]*)"', args_str)
    if len(matches) < 3:
        await update.message.reply_text("❌ Mets chaque élément entre guillemets."); return
    question = matches[0]
    options = matches[1:5]
    from handlers.reseau import _gate
    gate = await _gate(update, update.effective_user.id, writing=True)
    if gate:
        await update.message.reply_text(gate, parse_mode="HTML"); return
    from gameplay.social_polls import PollError
    try:
        poll_id = await create_poll(update.effective_user.id, question, options)
    except PollError as exc:
        await update.message.reply_text(f"❌ {escape_html(str(exc))}", parse_mode="HTML"); return
    lines = [f"📊 <b>Sondage #{poll_id}</b>", f"❓ {escape_html(question)}", ""]
    for i, opt in enumerate(options, 1):
        lines.append(f"{i}. {escape_html(opt)}")
    lines.append(f"\nVote avec le bouton « Voter » (sondage n°{poll_id})")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


@require_registered
async def cmd_vote(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 2:
        await update.message.reply_text("🗳️ Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.", parse_mode="HTML"); return
    try:
        poll_id = int(context.args[0])
        option_idx = int(context.args[1]) - 1
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides."); return
    from handlers.reseau import _gate
    gate = await _gate(update, update.effective_user.id, writing=True)
    if gate:
        await update.message.reply_text(gate, parse_mode="HTML"); return
    from gameplay.social_polls import PollError, vote_poll
    try:
        await vote_poll(poll_id, update.effective_user.id, option_idx)
    except PollError as exc:
        await update.message.reply_text(f"❌ {escape_html(str(exc))}", parse_mode="HTML"); return
    await update.message.reply_text("✅ Vote enregistré (+1 SocialCoin).")


@require_registered
@require_free
async def cmd_resultats_sondage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) != 1:
        await update.message.reply_text("📊 Ouvre cette action depuis 🎮 Menu → 🌐 Réseaux sociaux.", parse_mode="HTML"); return
    try:
        poll_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID invalide."); return
    async with Outbox() as _out:
        async with db_connection() as db:
            cursor = await db.execute("SELECT user_id, question, options, active FROM social_polls WHERE poll_id=?", (poll_id,))
            poll = await cursor.fetchone()
            if not poll or poll[3] == 0:
                _out.add(update.message.reply_text, "❌ Sondage introuvable ou expiré.")
            creator_id, question, options_json, _ = poll
            options = json.loads(options_json)
            user_id = update.effective_user.id
            if user_id != creator_id and user_id not in ADMIN_IDS:
                _out.add(update.message.reply_text, "🔒 Seul le créateur peut voir les résultats.")
            cursor = await db.execute(
                "SELECT option_index, COUNT(*) FROM social_poll_votes WHERE poll_id=? GROUP BY option_index",
                (poll_id,)
            )
            votes = {idx: count for idx, count in await cursor.fetchall()}
            total = sum(votes.values())
            result_text = f"📊 <b>Résultats du sondage #{poll_id}</b>\n❓ {escape_html(question)}\n\n"
            for i, opt in enumerate(options):
                count = votes.get(i, 0)
                percent = (count / total * 100) if total > 0 else 0
                result_text += f"{i+1}. {escape_html(opt)} : {count} ({percent:.1f}%)\n"
            result_text += f"\nTotal : {total} votant(s)"
            _out.add(update.message.reply_text, result_text, parse_mode="HTML")


# ============================================================================
# MAINTENANCE
# ============================================================================
SOCIAL_BATCH = 1000


async def process_social_revenue():
    """Revenus des réseaux sociaux, par lots de SOCIAL_BATCH joueurs."""
    last_id = 0
    while True:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            cursor = await db.execute(
                "SELECT user_id, SUM(revenue_per_day) as total_revenue FROM social_media "
                "WHERE revenue_per_day > 0 AND user_id > ? "
                "GROUP BY user_id ORDER BY user_id LIMIT ?",
                (last_id, SOCIAL_BATCH),
            )
            users = await cursor.fetchall()
            if not users:
                break
            ts = now()
            # ⚖️ Le job tourne toutes les heures : on verse 1/24e du revenu journalier
            # (avant : le revenu d'une journée entière était versé 24 fois par jour).
            paid = [(int(r["total_revenue"] // 24), r["user_id"]) for r in users if r["total_revenue"] >= 24]
            if paid:
                await db.executemany("UPDATE users SET balance = balance + ? WHERE user_id=?", paid)
                await db.executemany(
                    "INSERT INTO social_log (user_id, revenue, timestamp) VALUES (?,?,?)",
                    [(uid, rev, ts) for rev, uid in paid],
                )
            await db.commit()
        last_id = users[-1]["user_id"]
        await asyncio.sleep(0)


async def process_social_maintenance():
    async with db_connection() as db:
        current = now()
        await db.execute("UPDATE social_lives SET active=0 WHERE active=1 AND ends_at<=?", (current,))
        await db.execute("UPDATE social_trends SET active=0 WHERE active=1 AND expires_at<=?", (current,))
        await db.execute("DELETE FROM social_active_collabs WHERE expires_at<=?", (current,))
        await db.execute("UPDATE social_polls SET active=0 WHERE active=1 AND created_at<=?", (current - 172800,))
        await db.execute("DELETE FROM rp_posts WHERE kind='story' AND expires_at<=?", (current,))
        await db.commit()


# ============================================================================
# FONCTIONS UTILITAIRES INTERNES
# ============================================================================
async def get_skill(user_id: int, skill_name: str) -> int:
    async with db_connection() as db:
        cursor = await db.execute("SELECT level FROM skills WHERE user_id=? AND skill_name=?", (user_id, skill_name))
        row = await cursor.fetchone()
        return row[0] if row else 0


async def add_social_history(user_id: int, platform: str, action_type: str, gain: int):
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO social_history (user_id, platform, action_type, gain, timestamp) VALUES (?, ?, ?, ?, ?)",
            (user_id, platform, action_type, gain, now())
        )
        await db.commit()


async def compute_follower_gain_simple(user_id: int, platform: str, factor: float = 1.0) -> int:
    u = await get_user(user_id)
    creativity = await get_skill(user_id, "Créativité")
    charisma = await get_skill(user_id, "Charisme")
    base = random.randint(5, 100)
    mult = 1 + (creativity + charisma) * 0.03
    gain = int(base * mult * factor)
    karma = u.get("karma", 0)
    if karma > 0:
        gain = int(gain * (1 + min(0.3, karma / 1000)))
    active_vehicle = await get_active_vehicle(user_id)
    if active_vehicle:
        vehicle_luxe = active_vehicle.get("luxury", 0)
        if vehicle_luxe > 80:
            bonus = 1 + (vehicle_luxe - 80) / 100
            gain = int(gain * bonus)
    try:
        vip_mult = 1 + social_bonus(u)
        gain = int(gain * vip_mult)
    except Exception:
        swallowed('handlers/social.py')
    return max(1, gain)


async def get_total_followers(user_id: int) -> int:
    """Total d'abonnés : followers virtuels (social_media) + vrais abonnés RP (rp_follows)."""
    async with db_connection() as db:
        cursor = await db.execute("SELECT SUM(followers) FROM social_media WHERE user_id=?", (user_id,))
        row = await cursor.fetchone()
        virtual = int(row[0]) if row[0] else 0
        cursor2 = await db.execute("SELECT COUNT(*) FROM rp_follows WHERE followee_id=?", (user_id,))
        row2 = await cursor2.fetchone()
        real = int(row2[0]) if row2[0] else 0
    return virtual + real


async def is_follower(follower_id: int, followee_id: int) -> bool:
    """Vrai si `follower_id` fait partie de la communauté (abonnés RP réels) de `followee_id`."""
    async with db_connection() as db:
        async with db.execute(
            "SELECT 1 FROM rp_follows WHERE follower_id=? AND followee_id=?", (follower_id, followee_id)
        ) as cur:
            return (await cur.fetchone()) is not None


async def check_live_launch_requirements(user_id: int) -> tuple[bool, str]:
    """Vérifie qu'un joueur peut lancer un live : seuil de communauté (abonnés) + SocialCoins.
    Retourne (ok, message_erreur)."""
    total_followers = await get_total_followers(user_id)
    if total_followers < SOCIAL_MIN_FOLLOWERS_FOR_LIVE:
        return False, (f"❌ Il faut une communauté d'au moins {SOCIAL_MIN_FOLLOWERS_FOR_LIVE:,} abonnés pour lancer "
                        f"un live.\nTa communauté : {total_followers:,} abonnés.")
    coins = await get_social_coins(user_id)
    if coins < SOCIAL_LIVE_COST_COINS:
        return False, (f"❌ Il faut au moins {SOCIAL_LIVE_COST_COINS} {SOCIAL_COIN_NAME}s pour lancer un live.\n"
                        f"💎 Ton solde : {coins} {SOCIAL_COIN_NAME}s.")
    return True, ""


async def get_user_community(user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("""
            SELECT c.community_id, c.name, m.role, COUNT(all_members.user_id) AS member_count
            FROM social_community_members m
            JOIN social_communities c ON c.community_id = m.community_id
            LEFT JOIN social_community_members all_members ON all_members.community_id = c.community_id
            WHERE m.user_id=? AND c.disbanded=0
            GROUP BY c.community_id, c.name, m.role
        """, (user_id,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def get_user_active_collab(user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM social_active_collabs "
            "WHERE expires_at > ? AND (from_id=? OR to_id=?) "
            "ORDER BY expires_at DESC LIMIT 1",
            (now(), user_id, user_id)
        ) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def get_active_collab_bonus(user_id: int):
    async with db_connection() as db:
        cursor = await db.execute(
            "SELECT COUNT(*) FROM social_active_collabs WHERE expires_at>? AND (from_id=? OR to_id=?)",
            (now(), user_id, user_id)
        )
        count = (await cursor.fetchone())[0]
    return 1 + min(0.36, count * 0.12), count


async def get_community_bonus(user_id: int):
    community = await get_user_community(user_id)
    if not community:
        return 1.0, None, 0
    members = int(community.get("member_count", 1) or 1)
    return 1 + min(0.25, members * 0.02), community["name"], members


async def get_platform_engagement_multiplier(user_id: int, platform: str) -> float:
    async with db_connection() as db:
        cursor = await db.execute(
            "SELECT multiplier, expires_at FROM social_engagement_boosts WHERE user_id=? AND platform=?",
            (user_id, platform)
        )
        row = await cursor.fetchone()
        if not row:
            return 1.0
        multiplier, expires_at = row
        if expires_at <= now():
            await db.execute("DELETE FROM social_engagement_boosts WHERE user_id=? AND platform=?", (user_id, platform))
            await db.commit()
            return 1.0
        return max(1.0, float(multiplier))


async def get_social_rating_multiplier(user_id: int) -> float:
    user = await get_user(user_id)
    rating = int(user.get("social_rating", 0) or 0)
    if rating >= 0:
        return 1 + min(0.25, rating * 0.01)
    return max(0.85, 1 + rating * 0.01)


async def add_social_followers_atomic(user_id: int, platform: str, amount: int) -> None:
    if amount <= 0:
        return
    async with db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            await db.execute(
                "INSERT INTO social_media (user_id,platform,followers,posts,revenue_per_day,last_post) VALUES (?,?,?,0,0,0) "
                "ON CONFLICT(user_id,platform) DO UPDATE SET followers=social_media.followers+excluded.followers",
                (user_id, platform, amount),
            )
            await db.execute("UPDATE users SET social_followers=COALESCE(social_followers,0)+? WHERE user_id=?", (amount, user_id))
            await db.commit()
        except Exception:
            await db.rollback(); raise


async def set_engagement_boost(user_id: int, platform: str, mult: float, duration: int):
    async with db_connection() as db:
        await db.execute(
            "INSERT OR REPLACE INTO social_engagement_boosts (user_id, platform, multiplier, expires_at) VALUES (?,?,?,?)",
            (user_id, platform, mult, now() + duration)
        )
        await db.commit()


async def get_pending_trend_multiplier(user_id: int) -> float:
    async with db_connection() as db:
        cursor = await db.execute("SELECT multiplier FROM social_user_trends WHERE user_id=? AND used=0", (user_id,))
        row = await cursor.fetchone()
        return row[0] if row else 1.0


async def clear_pending_trend(user_id: int):
    async with db_connection() as db:
        await db.execute("UPDATE social_user_trends SET used=1 WHERE user_id=?", (user_id,))
        await db.commit()


async def register_live(user_id: int, platform: str, duration_h: int) -> int:
    ends = now() + duration_h * 3600
    async with db_connection() as db:
        cursor = await db.execute(
            "INSERT INTO social_lives (user_id, platform, started_at, ends_at) VALUES (?,?,?,?)",
            (user_id, platform, now(), ends)
        )
        await db.commit()
        return cursor.lastrowid


async def get_live_info(live_id: int):
    async with db_connection() as db:
        cursor = await db.execute("SELECT user_id, ends_at FROM social_lives WHERE live_id=? AND active=1", (live_id,))
        row = await cursor.fetchone()
        if row:
            return {"user_id": row[0], "ends_at": row[1]}
    return None


async def check_social_badges(user_id: int):
    total = await get_total_followers(user_id)
    badges = []
    if total >= 1000: badges.append("débutant_influence")
    if total >= 10000: badges.append("influenceur_local")
    if total >= 100000: badges.append("célébrité")
    if total >= 1000000: badges.append("méga_star")
    if badges:
        async with db_connection() as db:
            for badge in badges:
                await db.execute(
                    "INSERT OR IGNORE INTO user_badges (user_id, badge, earned_at) VALUES (?,?,?)",
                    (user_id, badge, now())
                )
            await db.commit()


async def get_social_coins(user_id: int) -> int:
    async with db_connection() as db:
        cursor = await db.execute("SELECT social_coins FROM users WHERE user_id=?", (user_id,))
        row = await cursor.fetchone()
        return row[0] if row else SOCIAL_COIN_STARTING_BALANCE


async def spend_social_coins(user_id: int, amount: int):
    async with db_connection() as db:
        await db.execute("UPDATE users SET social_coins = social_coins - ? WHERE user_id=?", (amount, user_id))
        await db.commit()


async def give_social_coins(user_id: int, amount: int):
    async with db_connection() as db:
        await db.execute("UPDATE users SET social_coins = social_coins + ? WHERE user_id=?", (amount, user_id))
        await db.commit()


async def create_collab_request(from_id: int, to_id: int, collab_type: str, duration_h: int) -> int:
    from gameplay.social_collabs import create_request
    result = await create_request(from_id, to_id, collab_type, duration_h, notify_target=False)
    return result["request_id"]


async def apply_collaboration(request_id: int, actor_id: int | None = None):
    from gameplay.social_collabs import respond_to_request
    if actor_id is None:
        async with db_connection() as db:
            async with db.execute("SELECT to_id FROM social_collab_requests WHERE request_id=?", (request_id,)) as cur:
                row = await cur.fetchone()
        if not row:
            return None
        actor_id = int(row[0])
    return await respond_to_request(request_id, actor_id, "accept")


async def refuse_collaboration(request_id: int, actor_id: int | None = None):
    from gameplay.social_collabs import respond_to_request
    if actor_id is None:
        async with db_connection() as db:
            async with db.execute("SELECT to_id FROM social_collab_requests WHERE request_id=?", (request_id,)) as cur:
                row = await cur.fetchone()
        if not row:
            return None
        actor_id = int(row[0])
    return await respond_to_request(request_id, actor_id, "refuse")


async def create_follower_offer(seller_id: int, buyer_id: int, quantity: int, price: int) -> int:
    async with db_connection() as db:
        cursor = await db.execute(
            "INSERT INTO social_follower_offers (seller_id, buyer_id, quantity, price, created_at) VALUES (?,?,?,?,?)",
            (seller_id, buyer_id, quantity, price, now())
        )
        await db.commit()
        return cursor.lastrowid


async def execute_follower_transfer(offer_id: int) -> bool:
    async with db_connection() as db:
        cursor = await db.execute(
            "SELECT seller_id, buyer_id, quantity, price, status FROM social_follower_offers WHERE offer_id=?",
            (offer_id,)
        )
        offer = await cursor.fetchone()
        if not offer or offer[4] != 'pending':
            return False
        seller_id, buyer_id, quantity, price = offer[:4]
        cursor2 = await db.execute("SELECT balance FROM users WHERE user_id=?", (buyer_id,))
        buyer_balance = (await cursor2.fetchone())[0]
        if buyer_balance < price:
            return False
        seller_followers = await get_total_followers(seller_id)
        if seller_followers < quantity:
            return False
        tax = int(price * SOCIAL_TRANSFER_TAX)
        net = price - tax
        await db.execute("UPDATE users SET balance = balance - ? WHERE user_id=?", (price, buyer_id))
        await db.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (net, seller_id))
        cursor3 = await db.execute("SELECT platform FROM social_media WHERE user_id=? ORDER BY followers DESC LIMIT 1", (seller_id,))
        seller_platform_row = await cursor3.fetchone()
        if not seller_platform_row:
            return False
        seller_platform = seller_platform_row[0]
        await db.execute(
            "UPDATE social_media SET followers = followers - ? WHERE user_id=? AND platform=?",
            (quantity, seller_id, seller_platform)
        )
        cursor4 = await db.execute("SELECT platform FROM social_media WHERE user_id=? ORDER BY followers DESC LIMIT 1", (buyer_id,))
        buyer_platform_row = await cursor4.fetchone()
        if buyer_platform_row:
            await db.execute(
                "UPDATE social_media SET followers = followers + ? WHERE user_id=? AND platform=?",
                (quantity, buyer_id, buyer_platform_row[0])
            )
        else:
            await db.execute(
                "INSERT INTO social_media (user_id, platform, followers, posts, revenue_per_day, last_post) VALUES (?,?,?,0,0,0)",
                (buyer_id, SOCIAL_PLATFORMS[0], quantity)
            )
        await db.execute("UPDATE users SET social_followers = social_followers - ? WHERE user_id=?", (quantity, seller_id))
        await db.execute("UPDATE users SET social_followers = social_followers + ? WHERE user_id=?", (quantity, buyer_id))
        await db.execute("UPDATE social_follower_offers SET status='completed' WHERE offer_id=?", (offer_id,))
        await db.commit()
        return True


async def refuse_follower_offer(offer_id: int):
    async with db_connection() as db:
        await db.execute("UPDATE social_follower_offers SET status='refused' WHERE offer_id=?", (offer_id,))
        await db.commit()


async def create_poll(user_id: int, question: str, options: list) -> int:
    from gameplay.social_polls import create_poll as create_shared_poll
    result = await create_shared_poll(user_id, question, options)
    return result["poll_id"]


async def register_vote(poll_id: int, user_id: int, option_idx: int) -> bool:
    from gameplay.social_polls import PollError, vote_poll
    try:
        await vote_poll(poll_id, user_id, option_idx)
        return True
    except PollError:
        return False
