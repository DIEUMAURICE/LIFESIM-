# handlers/justice.py — ⚖️ Justice (100 % boutons, préfixe `jus:`) : caution, avocat, procès, mandats
from utils.swallow import swallowed
import html
import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from config import JUSTICE
from database import get_user, now
from utils import justice, ordre
from utils.decorators import require_registered
from utils.input_flow import ask, flow
from utils.helpers import send_or_edit as _send

logger = logging.getLogger(__name__)
CB = "jus:"

BAIL_CHOICES = (10_000, 25_000, 50_000, 100_000, 250_000)
FINE_CHOICES = (10_000, 50_000, 100_000)
PRISON_CHOICES = (1_800, 3_600, 7_200, 10_800)


def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text, callback_data=data)


def _e(s) -> str:
    return html.escape(str(s))


def _plead_text(f: dict) -> str:
    return {1: "✅ plaidoirie réussie (-35 %)", -1: "❌ plaidoirie ratée", 0: "pas encore plaidé"}[f["plead"]]


# ─────────────────────────────────────────────────────────────────────────────
#  Accueil
# ─────────────────────────────────────────────────────────────────────────────
async def show_home(update: Update, uid: int, note: str = "") -> None:
    st = await justice.staff(uid)
    lines = ["⚖️ <b>Justice</b>", "",
             "<i>Police et armée arrêtent, la Justice tranche : caution, avocat, procès et mandats d'arrêt.</i>"]
    if note:
        lines = [note, ""] + lines
    rows = [[_btn("📁 Ma situation judiciaire", CB + "me")]]
    if st:
        lines += ["", f"{st['post_emoji']} <b>{st['post_name']}</b> · {st['code']} · "
                      f"{'🟢 en service' if st['on_duty'] else '⚪ hors service'}"]
        if st["post"] == "juge":
            rows.append([_btn("📁 Dossiers", CB + "files"), _btn("📜 Mandat d'arrêt", CB + "mw")])
            rows.append([_btn("📨 Candidatures (avocats)", "ord:apps"), _btn("👥 Équipe", "ord:team")])
        else:
            rows.append([_btn("🧑‍💼 Mes clients", CB + "cl")])
        rows.append([_btn("👔 Mon poste", "ord:job")])
    else:
        rows.append([_btn("📝 Postuler (avocat)", "ord:ap:justice:central")])
    rows.append([_btn("⬅️ Menu", "hub:etat:0")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Détenu
# ─────────────────────────────────────────────────────────────────────────────
async def show_me(update: Update, uid: int, note: str = "") -> None:
    u = await get_user(uid)
    f = await justice.my_file(uid)
    left = max(0, u.get("prison_until", 0) - now())
    lines = ["📁 <b>Ma situation judiciaire</b>", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    if not f:
        if left > 0 and not await justice.has_judges():
            from utils.helpers import fmt_time
            lines += [f"⛓️ Tu es en prison encore <b>{fmt_time(left)}</b>.", "",
                      "<i>Aucun juge n'exerce : l'ancien système automatique est disponible.</i>"]
            rows += [[_btn("💰 Payer la caution", "crime_caution_info")],
                     [_btn("⚖️ Tribunal", "crime_tribunal_info"), _btn("👨‍⚖️ Avocat", "crime_avocat_info")]]
        elif left > 0:
            lines.append("⛓️ Tu es en prison, mais aucun dossier n'est ouvert (peine automatique).")
        else:
            lines.append("✅ Aucun dossier ouvert à ton nom.")
        rows.append([_btn("⬅️ Justice", CB + "home")])
        await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))
        return
    from utils.helpers import fmt_time
    lines += [f"📂 Dossier <b>#{f['id']}</b> — {_e(f['crime'] or 'arrestation')}",
              f"⛓️ Temps restant : <b>{fmt_time(left)}</b>",
              f"👨‍⚖️ Avocat : <b>{_e(f['lawyer_name'] or 'aucun')}</b> ({_plead_text(f)})"]
    if f["bail"] > 0:
        due = justice.effective_bail(f)
        lines.append(f"💰 Caution fixée : <b>{due:,}</b>" + (f" (au lieu de {f['bail']:,})" if due != f["bail"] else ""))
        rows.append([_btn(f"💰 Payer la caution ({due:,})", CB + "pay")])
    else:
        lines.append("💰 Caution : <i>pas encore fixée par un juge</i>")
    if not f["lawyer_id"]:
        rows.append([_btn(f"👨‍⚖️ Prendre un avocat ({JUSTICE['lawyer_fee']:,})", CB + "law")])
    if f["status"] != "audience":
        rows.append([_btn("⚖️ Demander une audience", CB + "hear")])
    else:
        lines.append("⚖️ Audience demandée : un juge examinera ton dossier.")
    rows.append([_btn("🔄 Actualiser", CB + "me"), _btn("⬅️ Justice", CB + "home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_lawyers(update: Update, uid: int) -> None:
    lawyers = await justice.list_lawyers(True)
    lines = ["👨‍⚖️ <b>Avocats disponibles</b>", "", f"Honoraires : <b>{JUSTICE['lawyer_fee']:,}</b> (versés à l'avocat)."]
    rows = [[_btn(f"👨‍⚖️ {str(l['full_name'] or l['user_id'])[:24]}", CB + f"hire:{l['user_id']}")] for l in lawyers]
    if not lawyers:
        lines.append("\n<i>Aucun avocat en service pour le moment.</i>")
    rows.append([_btn("⬅️ Retour", CB + "me")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Avocat
# ─────────────────────────────────────────────────────────────────────────────
async def show_clients(update: Update, uid: int, note: str = "") -> None:
    lw, err = await justice.lawyer_check(uid, on_duty=False)
    if err:
        await _send(update, f"❌ {err}", InlineKeyboardMarkup([[_btn("⬅️ Justice", CB + "home")]]))
        return
    files = await justice.list_files(10, lawyer_id=uid)
    lines = ["🧑‍💼 <b>Mes clients</b>", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    for f in files:
        lines.append(f"#{f['id']} · {_e(f['suspect_name'])} — {_e(f['crime'])} · {_plead_text(f)}")
        if f["plead"] == 0:
            rows.append([_btn(f"🎤 Plaider #{f['id']}", CB + f"pl:{f['id']}")])
    if not files:
        lines.append("Aucun client pour le moment.")
    rows.append([_btn("⬅️ Justice", CB + "home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Juge
# ─────────────────────────────────────────────────────────────────────────────
async def show_files(update: Update, uid: int, note: str = "") -> None:
    jg, err = await justice.judge_check(uid, on_duty=False)
    if err:
        await _send(update, f"❌ {err}", InlineKeyboardMarkup([[_btn("⬅️ Justice", CB + "home")]]))
        return
    files = await justice.list_files(10)
    lines = ["📁 <b>Dossiers à juger</b>", ""]
    if note:
        lines = [note, ""] + lines
    rows = []
    for f in files:
        lines.append(f"{'⚖️' if f['status'] == 'audience' else '📂'} #{f['id']} · {_e(f['suspect_name'])} — {_e(f['crime'])}")
        rows.append([_btn(f"{'⚖️' if f['status'] == 'audience' else '📂'} #{f['id']} {str(f['suspect_name'])[:18]}", CB + f"f:{f['id']}")])
    if not files:
        lines.append("Aucun dossier ouvert.")
    rows.append([_btn("⬅️ Justice", CB + "home")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def show_file(update: Update, uid: int, file_id: int, note: str = "") -> None:
    jg, err = await justice.judge_check(uid, on_duty=False)
    f = await justice.get_file(file_id)
    if err or not f or f["status"] not in justice.OPEN_STATUS:
        await show_files(update, uid, "ℹ️ Dossier introuvable ou déjà jugé.")
        return
    left = await justice._remaining_prison(f["suspect_id"])
    from utils.helpers import fmt_time
    lines = [f"📂 <b>Dossier #{f['id']}</b> — {_e(f['crime'] or 'arrestation')}",
             f"👤 Prévenu : <b>{_e(f['suspect_name'])}</b> · arrêté par : {_e(f['source'])}",
             f"⛓️ Détention restante : {fmt_time(left)}",
             f"👨‍⚖️ Avocat : {_e(f['lawyer_name'] or 'aucun')} · {_plead_text(f)}",
             f"💰 Caution : {f['bail']:,}" + (f" → {justice.effective_bail(f):,} après plaidoirie" if f['plead'] == 1 and f['bail'] else "")]
    if note:
        lines = [note, ""] + lines
    rows = [[_btn(f"💰 {b // 1000}k", CB + f"bail:{f['id']}:{b}") for b in BAIL_CHOICES[:3]],
            [_btn(f"💰 {b // 1000}k", CB + f"bail:{f['id']}:{b}") for b in BAIL_CHOICES[3:]]
            + [_btn("🚫 Pas de caution", CB + f"bail:{f['id']}:0")],
            [_btn("✅ Acquitter", CB + f"ve:{f['id']}:acquit:0")],
            [_btn(f"💸 Amende {a // 1000}k", CB + f"ve:{f['id']}:amende:{a}") for a in FINE_CHOICES],
            [_btn(f"⛓️ {s // 60} min", CB + f"ve:{f['id']}:prison:{s}") for s in PRISON_CHOICES[:2]],
            [_btn(f"⛓️ {s // 60} min", CB + f"ve:{f['id']}:prison:{s}") for s in PRISON_CHOICES[2:]],
            [_btn("⬅️ Dossiers", CB + "files")]]
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


# ─────────────────────────────────────────────────────────────────────────────
#  Saisies guidées (mandat d'arrêt)
# ─────────────────────────────────────────────────────────────────────────────
@flow("jus_warrant_target")
async def _flow_warrant_target(update, context, value, data):
    target_id, name = value
    await ask(update, context, "jus_warrant_reason", f"📜 Mandat contre <b>{_e(name)}</b> : quel motif ? (une phrase)",
              kind="text", data={"target": target_id}, back=CB + "home")


@flow("jus_warrant_reason")
async def _flow_warrant_reason(update, context, value, data):
    ok, msg = await justice.issue_warrant(update.effective_user.id, data["target"], value[:80])
    await update.effective_message.reply_text(("✅ " if ok else "❌ ") + msg, parse_mode="HTML",
                                              reply_markup=InlineKeyboardMarkup([[_btn("⬅️ Justice", CB + "home")]]))


# ─────────────────────────────────────────────────────────────────────────────
#  Commande & callbacks
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_justice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update, update.effective_user.id)


async def jus_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    parts = (q.data or "").split(":")
    action = parts[1] if len(parts) > 1 else "home"
    a2 = parts[2] if len(parts) > 2 else ""
    a3 = parts[3] if len(parts) > 3 else ""
    a4 = parts[4] if len(parts) > 4 else ""
    try:
        u = await get_user(uid)
        if not u.get("registered") or u.get("banned"):
            await q.answer("Termine d'abord /start.", show_alert=True)
            return
        await q.answer()
        if action == "home":
            await show_home(update, uid)
        elif action == "me":
            await show_me(update, uid)
        elif action == "pay":
            ok, msg = await justice.pay_bail(uid)
            await show_me(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "law":
            await show_lawyers(update, uid)
        elif action == "hire":
            ok, msg = await justice.hire_lawyer(uid, int(a2))
            await show_me(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "hear":
            ok, msg = await justice.request_hearing(uid)
            await show_me(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "cl":
            await show_clients(update, uid)
        elif action == "pl":
            ok, msg = await justice.plead(uid, int(a2))
            await show_clients(update, uid, ("✅ " if ok else "❌ ") + msg)
        elif action == "files":
            await show_files(update, uid)
        elif action == "f":
            await show_file(update, uid, int(a2))
        elif action == "bail":
            ok, msg = await justice.set_bail(uid, int(a2), int(a3))
            await show_file(update, uid, int(a2), ("✅ " if ok else "❌ ") + msg)
        elif action == "ve":
            ok, msg = await justice.judge_file(uid, int(a2), a3, int(a4 or 0))
            if ok:
                await show_files(update, uid, "✅ " + msg)
            else:
                await show_file(update, uid, int(a2), "❌ " + msg)
        elif action == "mw":
            jg, err = await justice.judge_check(uid)
            if err:
                await show_home(update, uid, f"❌ {err}")
                return
            await ask(q, context, "jus_warrant_target", "📜 Contre qui délivrer un mandat d'arrêt ? (@pseudo ou ID)",
                      kind="user", back=CB + "home")
        else:
            await show_home(update, uid)
    except Exception:
        logger.exception("jus_callback : %s", q.data)
        try:
            await q.message.reply_text("⚠️ Une erreur est survenue, réessaie depuis le menu.")
        except Exception:
            swallowed('handlers/justice.py')
