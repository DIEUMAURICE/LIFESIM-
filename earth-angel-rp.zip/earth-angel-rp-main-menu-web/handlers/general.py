"""
handlers/general.py — LIFESIM ULTRA V2
═══════════════════════════════════════════════════════════════════════
Commandes générales : /start, /menu, /aide, /guide, /nouveautes, /about
Menu principal interactif avec redirection vers tous les modules.

✅ Fix #12 : except Exception (au lieu de FileNotFoundError) pour ne plus
             perdre le message en cas d'erreur Telegram (photo, réseau, etc.)
"""
from utils.swallow import swallowed
from datetime import datetime
from types import SimpleNamespace
import logging
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputFile
from telegram.ext import ContextTypes

from database import (
    db_connection,
    DB_PATH, get_user, update_field, increment_field, update_balance,
    get_active_event, add_life_journal
)
from utils.decorators import require_registered
from utils.helpers import (
    fmt, now, get_level, lifestyle_score, life_state_label,
    wealth_class, karma_label, random_quote, xp_progress, escape_html
)
from utils.aesthetics import (
    card, stat_card, alert, age_stage,
)
from utils.simulation import apply_passive_simulation, current_season
from config import (SEASON_EFFECTS, START_PHOTO_PATH, GAME_NAME, GAME_TAGLINE, GAME_LORE,
                    BOT_LINK, GROUP_LINK, UPDATES_LINK, SUPPORT_LINK, DEV_LINK, CREATOR_LINK)
from handlers.missions import update_mission_progress
from utils.helpers import escape_html


BOT_PUBLIC_LINK = BOT_LINK
REFERRAL_JOIN_REFERRER = 15_000
REFERRAL_JOIN_REFERRED = 7_500
REFERRAL_JOIN_COINS = 15
REFERRAL_ACTIVATION_REFERRER = 40_000
REFERRAL_ACTIVATION_REFERRED = 20_000
REFERRAL_ACTIVATION_COINS = 30


# ═══════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════
async def safe_edit(query, text, parse_mode="HTML", reply_markup=None):
    """Édite un message en ignorant les erreurs mineures."""
    try:
        await query.edit_message_text(text, parse_mode=parse_mode, reply_markup=reply_markup)
    except Exception as e:
        err = str(e)
        if "Message is not modified" in err:
            return
        if "no text in the message" in err.lower():
            try:
                await query.message.reply_text(text, parse_mode=parse_mode, reply_markup=reply_markup)
                try:
                    await query.message.delete()
                except Exception:
                    swallowed('handlers/general.py')
            except Exception:
                swallowed('handlers/general.py')
            return
        raise


async def _notify_user(bot, user_id: int, text: str):
    try:
        await bot.send_message(user_id, text, parse_mode="HTML")
    except Exception:
        swallowed('handlers/general.py')


def _get_season_effects(season: str) -> dict:
    """Récupère les effets d'une saison en tolérant casse et absence d'icône."""
    season_key = season.capitalize() if season else ""
    default = {"garden_mult": 1.0, "happiness_gain": 0, "crime_mult": 1.0, "icon": "🌍"}
    s_fx = dict(SEASON_EFFECTS.get(season_key, default))
    if not s_fx.get("icon"):
        icons = {"Hiver": "❄️", "Printemps": "🌸", "Été": "☀️", "Automne": "🍂"}
        s_fx["icon"] = icons.get(season_key, "🌍")
    return s_fx


async def fun_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routeur pour les boutons du sous-menu Loisirs."""
    q = update.callback_query
    await q.answer()
    user_id = q.from_user.id
    data = q.data

    if data == "fun_menu":
        from handlers.hub import open_zone; await open_zone(q, "fun")
        return

    if data == "fun_garden":
        from handlers.garden import show_garden_menu
        await show_garden_menu(q, user_id)
        return

    if data == "fun_travel":
        from handlers.travel import show_travel_menu
        await show_travel_menu(q, user_id)
        return

    if data == "fun_casino":
        from handlers.casino import show_casino_menu
        await show_casino_menu(q, user_id)
        return

    if data == "fun_arena":
        await safe_edit(
            q,
            card(
                "⚔️ ARÈNE",
                [
                    "🥊 <b>Défier un joueur</b> — Réponds à son message depuis le 🎮 Menu principal",
                    "",
                    "📋 <b>Voir les défis en attente</b> — le 🎮 Menu principal",
                    "🏆 <b>Classement de l'arène</b> — le 🎮 Menu principal",
                    "🎰 <b>Parier sur un combat</b> — le 🎮 Menu principal (en répondant)",
                    "",
                    "<b>Jeux disponibles :</b>",
                    "  • ⚔️ Combat",
                    "  • ✊ Pierre-Papier-Ciseaux",
                    "  • 🪙 Pile ou Face",
                    "  • 🎲 Dés",
                    "  • 🏃 Course",
                    "  • ❓ Quiz",
                ],
                icon="⚔️", style="thick",
            ),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="fun_menu")]])
        )
        return


# ═══════════════════════════════════════════════════════════════════
# HELPERS PARRAINAGE
# ═══════════════════════════════════════════════════════════════════
async def process_referral_progress(user_id: int, bot=None):
    from gameplay.referrals import process_activation
    return bool(await process_activation(user_id))

    # Compatibilité avec les anciennes bases et anciens appels : le bloc ci-dessous
    # est conservé pour les migrations historiques, mais le flux actif passe par
    # gameplay.referrals.
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT r.referrer_id, u.level, u.total_earned, u.full_name, u.referral_activated
            FROM referrals r
            JOIN users u ON u.user_id = r.referred_id
            WHERE r.referred_id=? AND r.activated_at=0
        """, (user_id,)) as cur:
            row = await cur.fetchone()
        if not row:
            return False
        if row["referral_activated"]:
            return False
        if row["level"] < 3 or row["total_earned"] < 25_000:
            return False

        current = now()
        await db.execute("UPDATE referrals SET activated_at=? WHERE referred_id=?", (current, user_id))
        await db.execute(
            "UPDATE users SET referral_activated=1, social_coins=COALESCE(social_coins,0)+?, referral_rewards=referral_rewards+? WHERE user_id=?",
            (REFERRAL_ACTIVATION_COINS, REFERRAL_ACTIVATION_REFERRED, user_id)
        )
        await db.execute(
            "UPDATE users SET social_coins=COALESCE(social_coins,0)+?, referral_rewards=referral_rewards+? WHERE user_id=?",
            (REFERRAL_ACTIVATION_COINS, REFERRAL_ACTIVATION_REFERRER, row["referrer_id"])
        )
        await db.commit()

    await update_balance(user_id, REFERRAL_ACTIVATION_REFERRED)
    await update_balance(row["referrer_id"], REFERRAL_ACTIVATION_REFERRER)
    await add_life_journal(
        user_id, "parrainage",
        f"🎁 Récompense d'activation de parrainage reçue : {fmt(REFERRAL_ACTIVATION_REFERRED)} + {REFERRAL_ACTIVATION_COINS} SocialCoins.",
        severity="success"
    )
    await add_life_journal(
        row["referrer_id"], "parrainage",
        f"👥 Ton filleul {escape_html(row['full_name'])} s'est bien lancé : {fmt(REFERRAL_ACTIVATION_REFERRER)} + {REFERRAL_ACTIVATION_COINS} SocialCoins.",
        severity="success"
    )
    if bot:
        await _notify_user(
            bot,
            row["referrer_id"],
            f"🎉 <b>Ton filleul progresse vraiment !</b>\n"
            f"{escape_html(row['full_name'])} a validé son activation.\n"
            f"💰 Récompense : <b>{fmt(REFERRAL_ACTIVATION_REFERRER)}</b>\n"
            f"💎 Bonus : <b>{REFERRAL_ACTIVATION_COINS}</b> SocialCoins"
        )
        await _notify_user(
            bot,
            user_id,
            f"🎁 <b>Parrainage activé</b>\n"
            f"Tu as débloqué la récompense de progression.\n"
            f"💰 Gain : <b>{fmt(REFERRAL_ACTIVATION_REFERRED)}</b>\n"
            f"💎 Bonus : <b>{REFERRAL_ACTIVATION_COINS}</b> SocialCoins"
        )
    return True


async def _handle_referral_start(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> str:
    if not context.args:
        return ""
    token = context.args[0].strip()
    if not token.startswith("ref_"):
        return ""
    code = token[4:]
    if not code.isdigit():
        return ""

    referrer_id = int(code)
    if referrer_id == user_id:
        return ""

    from gameplay.referrals import ReferralError, start_referral
    try:
        result = await start_referral(user_id, referrer_id)
    except ReferralError:
        return ""
    return (
        f"🤝 <b>Parrainage activé</b>\n"
        f"Parrain : <b>{escape_html(result['referrer_name'])}</b>\n"
        f"🎁 Bonus de départ : <b>{fmt(result['cash'])}</b>\n"
        f"💎 Bonus : <b>{result['coins']}</b> SocialCoins\n"
        f"🚀 Une autre récompense se débloquera quand tu auras vraiment lancé ta partie."
    )

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT referred_by FROM users WHERE user_id=?", (user_id,)) as cur:
            current_user = await cur.fetchone()
        if not current_user or (current_user["referred_by"] or 0):
            return ""

        async with db.execute(
            "SELECT user_id, full_name, registered FROM users WHERE user_id=?",
            (referrer_id,)
        ) as cur:
            referrer = await cur.fetchone()
        if not referrer or not referrer["registered"]:
            return ""

        await db.execute("UPDATE users SET referred_by=? WHERE user_id=?", (referrer_id, user_id))
        await db.execute(
            "INSERT OR IGNORE INTO referrals(referrer_id, referred_id, created_at, starter_rewarded, activated_at) VALUES(?,?,?,?,0)",
            (referrer_id, user_id, now(), 1)
        )
        await db.execute(
            "UPDATE users SET referral_count=referral_count+1, social_coins=COALESCE(social_coins,0)+?, referral_rewards=referral_rewards+? WHERE user_id=?",
            (REFERRAL_JOIN_COINS, REFERRAL_JOIN_REFERRER, referrer_id)
        )
        await db.execute(
            "UPDATE users SET social_coins=COALESCE(social_coins,0)+?, referral_rewards=referral_rewards+? WHERE user_id=?",
            (REFERRAL_JOIN_COINS, REFERRAL_JOIN_REFERRED, user_id)
        )
        await db.commit()
        referrer_name = referrer["full_name"] or f"Joueur {referrer_id}"

    await update_balance(referrer_id, REFERRAL_JOIN_REFERRER)
    await update_balance(user_id, REFERRAL_JOIN_REFERRED)
    await add_life_journal(
        user_id, "parrainage",
        f"🤝 Tu as rejoint le jeu via {escape_html(referrer_name)} : {fmt(REFERRAL_JOIN_REFERRED)} + {REFERRAL_JOIN_COINS} SocialCoins.",
        severity="success"
    )
    await add_life_journal(
        referrer_id, "parrainage",
        f"👥 Un nouveau filleul a rejoint le jeu : {fmt(REFERRAL_JOIN_REFERRER)} + {REFERRAL_JOIN_COINS} SocialCoins.",
        severity="success"
    )
    await _notify_user(
        context.bot,
        referrer_id,
        f"🎉 <b>Nouveau filleul !</b>\n"
        f"Un joueur vient de rejoindre grâce à ton lien.\n"
        f"💰 Récompense immédiate : <b>{fmt(REFERRAL_JOIN_REFERRER)}</b>\n"
        f"💎 Bonus : <b>{REFERRAL_JOIN_COINS}</b> SocialCoins"
    )
    return (
        f"🤝 <b>Parrainage activé</b>\n"
        f"Parrain : <b>{escape_html(referrer_name)}</b>\n"
        f"🎁 Bonus de départ : <b>{fmt(REFERRAL_JOIN_REFERRED)}</b>\n"
        f"💎 Bonus : <b>{REFERRAL_JOIN_COINS}</b> SocialCoins\n"
        f"🚀 Une autre récompense se débloquera quand tu auras vraiment lancé ta partie."
    )


# ═══════════════════════════════════════════════════════════════════
#                    🎮 CONSTRUCTION DU MENU PRINCIPAL
# ═══════════════════════════════════════════════════════════════════
async def _build_main_menu_keyboard(user_id: int = 0) -> InlineKeyboardMarkup:
    """Menu principal unique : les zones du hub (source unique, toujours synchronisées).
    Menu simplifié pour les débutants."""
    from handlers.hub import home_markup_for
    return await home_markup_for(user_id)


def _build_main_menu_body(u: dict) -> list:
    """En-tête du menu principal (le texte du hub est ajouté dessous)."""
    return [
        f"💰 Solde : <b>{fmt(u.get('balance', 0))}</b>",
        f"⭐ Niveau : <b>{u.get('level', 1)}</b>   ·   ❤️ Santé : <b>{u.get('health', 100)}%</b>",
    ]


# ═══════════════════════════════════════════════════════════════════
#                              /start
# ═══════════════════════════════════════════════════════════════════
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id, user.username or "", user.full_name or "")

    if u.get("registered"):
        from utils import character as chr_
        if not await chr_.is_complete(user.id):
            # 🪪 Création de personnage obligatoire : les joueurs déjà inscrits avant son
            # introduction la complètent dès leur prochaine ouverture, avant tout le reste.
            from handlers.personnage import show_home as _pc_show_home
            await update.message.reply_text(
                "🪪 <b>UNE DERNIÈRE ÉTAPE</b>\n━━━━━━━━━━━━━━━━━━\n"
                "Avant de continuer l'aventure, termine la création de ton personnage "
                "(identité et apparence).",
                parse_mode="HTML",
            )
            await _pc_show_home(update, user.id)
            return

        sim = await apply_passive_simulation(user.id)
        await process_referral_progress(user.id, context.bot)
        u = await get_user(user.id, user.username or "", user.full_name or "")
        score = lifestyle_score(u)
        lvl, xp_in, xp_for = xp_progress(u.get("xp", 0))
        age = u.get("age", 20)
        age_label, age_icon = age_stage(age)
        season = current_season()
        s_fx = _get_season_effects(season)

        await update_mission_progress(user.id, "login", 1)

        if sim.get("alert"):
            await update.message.reply_text(sim["alert"], parse_mode="HTML")

        body = [
            f"{age_icon} <b>{age} ans</b> · {age_label}",
            f"{s_fx['icon']} Saison : <b>{season.capitalize()}</b>",
            "",
            f"🧬 État global : <b>{life_state_label(score)}</b>  ({score}/100)",
            "",
            stat_card("Santé",   u.get("health", 100),   emoji="❤️"),
            stat_card("Énergie", u.get("energy", 100),   emoji="⚡"),
            stat_card("Faim",    u.get("hunger", 100),   emoji="🍽️"),
            stat_card("Bonheur", u.get("happiness", 100), emoji="😊"),
            stat_card("Stress",  u.get("stress", 0),     emoji="😰", inverted=True),
            "",
            f"💰 Solde : <b>{fmt(u['balance'])}</b>   ·   {wealth_class(u['balance'])}",
            f"⭐ Niveau <b>{lvl}</b>  ·  XP : {xp_in}/{xp_for}",
            f"🌟 Karma : <b>{karma_label(u.get('karma', 0))}</b>",
            f"💼 {escape_html(u.get('job') or 'Sans emploi')}  ·  🎓 {escape_html(u.get('diplome') or 'Aucun diplôme')}",
        ]

        from handlers.hub import home_markup_for
        kb = InlineKeyboardMarkup(list((await home_markup_for(user.id)).inline_keyboard) + [
            [InlineKeyboardButton("👥 Groupe de jeu", url=GROUP_LINK),
             InlineKeyboardButton("📢 Mises à jour", url=UPDATES_LINK)],
            [InlineKeyboardButton("🛠️ Support", url=SUPPORT_LINK),
             InlineKeyboardButton("👨‍💻 STUDIO DEV", callback_data="dev_info"),
             InlineKeyboardButton("👑 Créateur", callback_data="creator_info")],
            [InlineKeyboardButton("🤖 Bot officiel", url=BOT_LINK)],
        ])

        texte = card(
            f"Bon retour, {escape_html(user.full_name)}",
            body,
            footer=random_quote(),
            icon="🌟",
            style="thick",
        )

        # ✅ Fix #12 : attrape TOUTES les erreurs (TelegramError, réseau, photo trop grosse)
        try:
            with open(START_PHOTO_PATH, 'rb') as photo_file:
                await update.message.reply_photo(
                    photo=InputFile(photo_file),
                    caption=f"Bon retour, {escape_html(user.full_name)} 👋",
                    parse_mode="HTML",
                    reply_markup=kb
                )
                await update.message.reply_text(texte, parse_mode="HTML")
        except Exception:
            await update.message.reply_text(texte, parse_mode="HTML", reply_markup=kb)

        await update_field(user.id, "last_seen", now())
        return

    # ─── PREMIÈRE FOIS ──────────────────────────────────────────
    defaults = {
        "registered": 1,
        "created_at": now(),
        "last_seen": now(),
        "last_life_tick": now(),
        "balance": 10_000,
        "health": 100, "energy": 100, "happiness": 100, "hunger": 100,
        "stress": 0, "karma": 0, "age": 18,
        "job": "Livreur", "diplome": "",
        "level": 1, "xp": 0,
    }
    for field, value in defaults.items():
        await update_field(user.id, field, value)

    referral_text = await _handle_referral_start(update, context, user.id)

    await add_life_journal(
        user.id, "naissance",
        f"🎂 Naissance d'un nouveau destin : {escape_html(user.full_name)}, 18 ans, 10 000 €A en poche, Livreur.",
        severity="success",
    )

    intro_body = [
        "<i>Le Blanc et le Noir se disputent le monde… et ton cœur.</i>",
        "",
        "🧍 Tu apparais sur Terre en tant qu'<b>humain</b>, à <b>18 ans</b>, dans une grande métropole.",
        "💼 Premier job : <b>Livreur</b> · 💰 Capital de départ : <b>10 000 €A</b>.",
        "",
        "<b>🌗 Ton destin en 3 phases</b>",
        "  🧍 <b>L'Humain</b> — bâtis ta vie (disponible)",
        "  😇 <b>L'Élu</b> — un ange te donne des pouvoirs (bientôt)",
        "  👼 <b>L'Ange</b> — rejoins la bataille du Ciel des Cieux (bientôt)",
        "",
        "<b>🪪 Avant toute chose</b>",
        "  • Crée ton <b>personnage</b> : identité et apparence (obligatoire, 2 min)",
        "  • Puis un menu unique, rangé par zones et par rubriques",
        "  • <b>📖 Aide & tutoriel</b> te guide pas à pas (l'histoire complète y est aussi)",
    ]
    if referral_text:
        intro_body.extend(["", referral_text])

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("✨ Créer mon personnage", callback_data="pc:go")],
        [InlineKeyboardButton("📖 Aide & tutoriel", callback_data="help:home")],
        [InlineKeyboardButton("👥 Groupe de jeu", url=GROUP_LINK),
         InlineKeyboardButton("📢 Mises à jour", url=UPDATES_LINK)],
        [InlineKeyboardButton("🛠️ Support", url=SUPPORT_LINK),
         InlineKeyboardButton("👨‍💻 STUDIO DEV", callback_data="dev_info"),
         InlineKeyboardButton("👑 Créateur", callback_data="creator_info")],
    ])

    texte = card(
        f"Bienvenue dans {GAME_NAME}, {escape_html(user.full_name)}",
        intro_body,
        footer=GAME_TAGLINE,
        icon="🌟",
        style="thick",
    )

    # ✅ Fix #12 : attrape TOUTES les erreurs
    try:
        with open(START_PHOTO_PATH, 'rb') as photo_file:
            await update.message.reply_photo(
                photo=InputFile(photo_file),
                caption=f"Bienvenue, {escape_html(user.full_name)} 🚀",
                parse_mode="HTML",
                reply_markup=kb
            )
            await update.message.reply_text(texte, parse_mode="HTML")
    except Exception:
        await update.message.reply_text(texte, parse_mode="HTML", reply_markup=kb)

    await update_field(user.id, "last_seen", now())
    return


# ═══════════════════════════════════════════════════════════════════
#                              /parrainage
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_parrainage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    deep_link = f"{BOT_PUBLIC_LINK}?start=ref_{user.id}"
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN activated_at > 0 THEN 1 ELSE 0 END) AS activated
            FROM referrals
            WHERE referrer_id=?
        """, (user.id,)) as cur:
            stats = await cur.fetchone()
        async with db.execute("""
            SELECT u.full_name, u.level, r.created_at, r.activated_at
            FROM referrals r
            JOIN users u ON u.user_id = r.referred_id
            WHERE r.referrer_id=?
            ORDER BY r.created_at DESC
            LIMIT 8
        """, (user.id,)) as cur:
            rows = await cur.fetchall()

    u = await get_user(user.id)
    total = stats["total"] or 0
    activated = stats["activated"] or 0
    pending = total - activated

    body = [
        "Invite tes amis avec ce lien personnel :",
        f"<code>{escape_html(deep_link)}</code>",
        "",
        f"👥 Filleuls inscrits : <b>{total}</b>",
        f"✅ Activés : <b>{activated}</b>",
        f"⏳ En attente : <b>{pending}</b>",
        f"💰 Récompenses gagnées : <b>{fmt(u.get('referral_rewards', 0))}</b>",
        "",
        "<b>Récompenses</b>",
        f"• Arrivée d'un filleul : <b>{fmt(REFERRAL_JOIN_REFERRER)}</b> + {REFERRAL_JOIN_COINS} SocialCoins",
        f"• Activation d'un filleul : <b>{fmt(REFERRAL_ACTIVATION_REFERRER)}</b> + {REFERRAL_ACTIVATION_COINS} SocialCoins",
        "",
        "Un filleul est activé quand il atteint le niveau 3 et a gagné au moins 25 000 €A au total.",
    ]
    if rows:
        body.extend(["", "<b>Derniers filleuls</b>"])
        for row in rows:
            status = "✅ activé" if row["activated_at"] else "⏳ en cours"
            body.append(f"• <b>{escape_html(row['full_name'])}</b> · niv.{row['level']} · {status}")

    await update.message.reply_text(
        card("🤝 PARRAINAGE", body, icon="🤝", style="thick",
             footer="Partage le lien le menu pour faire grandir la communauté."),
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════
#                              /menu
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    event = await get_active_event()
    ev_line = f"⚡ Événement actif : <b>{escape_html(event['name'])}</b>" if event else "🌍 Monde stable"

    body = [
        ev_line,
        "",
        f"💰 Solde : <b>{fmt(u.get('balance', 0))}</b>",
        f"⭐ Niveau : <b>{u.get('level', 1)}</b>   ·   ❤️ Santé : <b>{u.get('health', 100)}%</b>",
        "",
        "<b>🎮 Menu unique</b>",
        "  Toutes les actions du jeu sont dans le menu ci-dessous, rangées par zone.",
        "  Plus besoin de retenir les commandes !",
        "",
        "<b>💡 Astuce</b>",
        "  Ouvre ton <b>téléphone</b> (🎮 Menu → 📱 Téléphone) pour ton hub central :",
        "  Banque · Garage · Réseaux · Marché · Inventaire · Profil",
    ]

    await update.message.reply_text(
        card("MENU PRINCIPAL", body, icon="🎮", style="double",
             footer="Choisis une catégorie ci-dessous."),
        parse_mode="HTML",
        reply_markup=await _build_main_menu_keyboard(user.id),
    )


# ═══════════════════════════════════════════════════════════════════
#                              /aide
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_aide(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Centre d'aide à boutons (remplace l'ancienne longue liste)."""
    from handlers.help_center import send_home
    await send_home(update)


# ═══════════════════════════════════════════════════════════════════
#                              /guide
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_guide(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Le guide complet est désormais le centre d'aide à boutons."""
    from handlers.help_center import send_home
    await send_home(update)


# ═══════════════════════════════════════════════════════════════════
#                          /nouveautes
# ═══════════════════════════════════════════════════════════════════
async def cmd_nouveautes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    line = "━━━━━━━━━━━━━━━━━━━━━━"
    body = [
        "<b>🆕 NOUVEAUTÉS — OCTOBRE 2026</b>",
        "",
        line,
        "<b>🧭 UN MENU REFAIT</b>",
        "  • Trois niveaux : zone → rubrique → action",
        "  • Chaque écran a son « ⬅️ Retour » et son « 🎮 Menu principal »",
        "  • Chaque action est décrite avant d'être lancée",
        "  • Les doublons ont disparu : un seul hub de classements, un seul moteur de publication",
        "",
        line,
        "<b>🌐 UN SEUL RÉSEAU SOCIAL</b>",
        "  • Publie avec des <b>#hashtags</b> ; page <b>Tendances</b>",
        "  • <b>Communauté</b> : hashtag officiel, fil et sondages réservés aux membres",
        "  • <b>Sondages</b> : vote, résultats en direct, clôture, notifications",
        "  • Fil, likes, commentaires, abonnements, messages privés, Voidgram",
        "",
        line,
        "<b>🛍️ BOUTIQUE REFAITE</b>",
        "  • Offre du jour, offre de bienvenue, éditions limitées, cadeaux, fidélité",
        "  • Achat sécurisé : jamais deux livraisons, remboursement automatique en cas de problème",
        "",
        line,
        "<b>🪪 TON PERSONNAGE</b>",
        "  • Nom, sexe, origine, apparence, caractère et histoire",
        "  • Avatar composé automatiquement, carte d'identité sur ton profil",
        "",
        line,
        "<b>🏭 ENTREPRISES</b>",
        "  • « 📖 Guide pas à pas » : où tu en es et la prochaine étape",
        "  • Production à chaque <b>heure de jeu</b>",
        "  • L'activité est créditée <b>pendant</b> le service, plus à la fin",
        "  • « 🔍 Pourquoi ça ne produit pas ? » explique et propose la solution",
        "  • La création de produits personnalisés est retirée",
        "",
        line,
        "<b>🏛️ TRÉSOR PUBLIC</b>",
        "  • Les dépenses envers le jeu financent l'Administration",
        "  • Elle redistribue aux coffres des factions (dotations journalisées)",
        "  • Le staff réduit puis ferme le rôle du bot (fournisseur, marché, comptoir) quand les entreprises prennent le relais",
        "",
        line,
        "<b>🎮 PROGRESSION</b>",
        "  • « 🧭 Mon parcours » : niveau, tutoriel, missions, succès, compétition",
        "  • Notifications : niveau atteint, succès, mission, résultats de compétition",
        "  • Tutoriel en 8 étapes",
        "",
        line,
        "<b>📜 RÈGLEMENT RP</b>",
        "  • Règles du jeu de rôle, chefs nommés par le staff après entretien",
        "",
        line,
        "<b>🎓 ÉTUDES</b>",
        "  • École de commerce, Grande École et Doctorat honoris causa dans la liste",
        "",
        line,
        "<b>🔧 CORRECTIONS</b>",
        "  • Les partis politiques sont retirés : on vote pour des personnes (candidatures, élections, lois)",
        "  • Publier un post ne plante plus ; les abonnés ne sont plus comptés deux fois",
        "  • Boutons plus lisibles : les libellés longs prennent toute la largeur",
    ]

    footer = "💡 Plus besoin de retenir les commandes."

    chunk_size = 15
    for i in range(0, len(body), chunk_size):
        chunk = body[i:i+chunk_size]
        current_footer = footer if i + chunk_size >= len(body) else None
        text = card("QUOI DE NEUF ?", chunk, icon="🆕", style="thick", footer=current_footer)
        if i == 0:
            await update.message.reply_text(
                text, parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🎮 Ouvrir le menu", callback_data="menu_main")
                ]]),
            )
        else:
            await update.message.reply_text(text, parse_mode="HTML")


# ═══════════════════════════════════════════════════════════════════
#                              /about
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_about(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        f"<b>🌗 {escape_html(GAME_NAME)}</b>\n<i>{escape_html(GAME_TAGLINE)}</i>\n\n"
        "Un jeu RP où le Bien et le Mal s'affrontent à travers les hommes et les anges :\n"
        "• Apparais comme humain, bâtis ta vie et ta fortune\n"
        "• Deviens l'élu d'un ange, puis un ange toi-même\n"
        "• Interagis, allie-toi ou trahis les autres joueurs\n\n"
        "<b>Liens utiles :</b>\n"
        f"👥 [Groupe de jeu]({escape_html(GROUP_LINK)})\n"
        f"📢 [Mises à jour]({escape_html(UPDATES_LINK)})\n"
        f"🛠️ [Support]({escape_html(SUPPORT_LINK)})\n"
        f"👨‍💻 STUDIO DEV : [Game French]({escape_html(DEV_LINK)})\n"
        f"👑 Créateur &amp; Propriétaire : [Game French]({escape_html(CREATOR_LINK)})\n"
        f"🤖 [Bot officiel]({escape_html(BOT_LINK)})"
    )
    await update.message.reply_text(text, parse_mode="HTML", disable_web_page_preview=True)


# ═══════════════════════════════════════════════════════════════════
#                          /shop
# ═══════════════════════════════════════════════════════════════════
async def cmd_shop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("👑 Articles de luxe", callback_data="shop_luxe")],
        [InlineKeyboardButton("🕶️ Marché noir", callback_data="shop_noir")],
        [InlineKeyboardButton("⭐ VIP / Premium / Boutique Étoiles", callback_data="star_menu")],
        [InlineKeyboardButton("❌ Fermer", callback_data="shop_close")]
    ])
    await update.message.reply_text(
        "🛒 <b>Boutique</b>\n\nChoisis ta catégorie :",
        reply_markup=keyboard,
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════
#                CALLBACK DU MENU PRINCIPAL
# ═══════════════════════════════════════════════════════════════════
async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Callbacks `menu_*` : il n'existe plus qu'UN menu (handlers/hub.py).

    Les anciens menus thématiques (menu_life, menu_economy, … menu_profile) et
    leurs sous-menus sont fusionnés : chaque ancien bouton ouvre la zone équivalente.
    """
    from handlers import hub
    q = update.callback_query
    await q.answer()
    key = q.data.replace("menu_", "", 1)
    if key == "hold":
        return

    from utils.character import gate as _character_gate
    if key != "help" and await _character_gate(update, q.from_user.id):
        return

    if key == "help":
        from handlers.help_center import show_home as _help_home
        await _help_home(q)
        return

    if key != "main":
        key = key.rsplit("_", 1)[0] if key.rsplit("_", 1)[-1].isdigit() else key   # ancien suffixe de page
        if await hub.open_zone(q, key):
            return

    # menu_main (ou clé inconnue) : le menu principal unique
    u = await get_user(q.from_user.id)
    await hub.show_home(q, _build_main_menu_body(u))

# ═══════════════════════════════════════════════════════════════════
#                CALLBACKS : DEV & CRÉATEUR
# ═══════════════════════════════════════════════════════════════════
async def dev_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    text = (
        "👨‍💻 <b>STUDIO DEV</b>\n\n"
        f"Le cerveau derrière {escape_html(GAME_NAME)} :\n"
        f"<b>[Studio Game French]({escape_html(DEV_LINK)})</b>\n\n"
        "<i>Passionné par la simulation de vie et les RP textuels.</i>"
    )
    await q.message.reply_text(text, parse_mode="HTML", disable_web_page_preview=True)
    try:
        await q.message.delete()
    except Exception:
        swallowed('handlers/general.py')


async def creator_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    text = (
        "👑 <b>Créateur &amp; Propriétaire</b>\n\n"
        f"L'univers de {escape_html(GAME_NAME)} a été imaginé par :\n"
        f"<b>[Game French]({escape_html(CREATOR_LINK)})</b>\n\n"
        "<i>Merci de faire vivre ce monde.</i>"
    )
    await q.message.reply_text(text, parse_mode="HTML", disable_web_page_preview=True)
    try:
        await q.message.delete()
    except Exception:
        swallowed('handlers/general.py')


# ═══════════════════════════════════════════════════════════════════
#                CALLBACK : BOUTIQUE /shop
# ═══════════════════════════════════════════════════════════════════
async def shop_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "shop_luxe":
        await q.edit_message_text(
            "👑 <b>Boutique luxe</b>\n\n"
            "Ouvre le 🎮 Menu principal pour voir les articles premium.",
            parse_mode="HTML"
        )
    elif q.data == "shop_noir":
        await q.edit_message_text(
            "🕶️ <b>Marché noir</b>\n\n"
            "Ouvre le 🎮 Menu principal pour voir les offres illégales.",
            parse_mode="HTML"
        )
    elif q.data == "shop_close":
        await q.message.delete()
    else:
        await q.edit_message_text("❌ Option invalide.")


# ═══════════════════════════════════════════════════════════════════
#                      COMMANDE INCONNUE
# ═══════════════════════════════════════════════════════════════════
async def cmd_unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Commande sans handler dédié : on tente d'ouvrir l'action du menu du même nom
    (formulaire à boutons si besoin) ; sinon on renvoie vers le menu."""
    if not update.message or not update.message.text:
        return
    name = update.message.text.split()[0].lstrip("/").split("@")[0].lower()
    try:
        from handlers.hub import run_typed_command
        if await run_typed_command(update, context, name):
            return
    except Exception:
        logging.getLogger(__name__).exception("Commande /%s : ouverture directe impossible", name)
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("🎮 Ouvrir le menu", callback_data="menu_main")]])
    await update.message.reply_text(
        alert("info",
              "Cette commande n'existe pas.\n"
              "Ouvre le menu et choisis ton action : le bot te demandera ce qu'il faut "
              "(pseudo, montant…) par message."),
        parse_mode="HTML", reply_markup=kb,
    )


# ─────────────────────────────────────────────────────────────────────────────
# /annuler (ex handlers/cancel.py)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_annuler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Annule l'action en cours (paiement, don, etc.)."""
    keys_to_clear = [
        'pending_payment', 'pending_donation',
        'awaiting_payment_amount', 'awaiting_payment_target',
        'awaiting_donation_amount', 'awaiting_donation_target',
        'temp_report_type', 'pending_bet', 'awaiting_roulette_number',
        # Location
        'awaiting_rental_target', 'pending_rental_property_index',
        'awaiting_rental_amount', 'pending_rental_target_id',
    ]
    cleared = False
    for key in keys_to_clear:
        if context.user_data.pop(key, None) is not None:
            cleared = True
    
    if cleared:
        await update.message.reply_text(
            "✅ <b>Action annulée</b>\n\n"
            "Tout est réinitialisé. Tu peux reprendre.",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            "ℹ️ Aucune action en cours à annuler.",
            parse_mode="HTML"
        )
