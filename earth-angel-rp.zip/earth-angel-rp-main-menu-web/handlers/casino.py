# handlers/casino.py — Casino interactif complet (1xBet style)
# ✅ Fix #2 : cas_other_ (double slash)
# ✅ Fix #3 + #26 : ajout created_at + cleanup_casino_games()

from utils.swallow import swallowed
import random
import asyncio
import time
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import db_connection, DB_PATH, get_user, update_balance, update_field, increment_field
from utils.location import require_location
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, fmt_time, now, parse_amount
from utils.vip import casino_bonus, chance_boost_bonus, add_xp
from config import (
    CASINO_MIN_BET, CASINO_MAX_BET, CASINO_VIP_BONUS_CAP, ROULETTE_NUMBERS,
    CASINO_OPEN_HOUR, CASINO_CLOSE_HOUR
)
from utils.gametime import game_datetime
from handlers.missions import update_mission_progress
from utils.helpers import escape_html

# ─────────────────────────────────────────────────────────────────────────────
# Gestion du temps de jeu et horaires du casino
# ─────────────────────────────────────────────────────────────────────────────

def get_game_time() -> tuple[int, int, int]:
    """(secondes écoulées dans la journée de jeu, heure, minute) — heure de jeu partagée."""
    d = game_datetime()
    return d["hour"] * 3600 + d["minute"] * 60 + d["second"], d["hour"], d["minute"]

def is_casino_open() -> bool:
    _, hours, _ = get_game_time()
    if CASINO_OPEN_HOUR <= hours < 24:
        return True
    if 0 <= hours < CASINO_CLOSE_HOUR:
        return True
    return False

def get_casino_status_text() -> str:
    _, hours, minutes = get_game_time()
    game_time_str = f"{hours:02d}:{minutes:02d}"
    open_time = f"{CASINO_OPEN_HOUR:02d}:00"
    close_time = f"{CASINO_CLOSE_HOUR:02d}:00"

    if is_casino_open():
        current_seconds = hours * 3600 + minutes * 60
        close_seconds = CASINO_CLOSE_HOUR * 3600
        if close_seconds <= current_seconds:
            close_seconds += 86400
        remaining_game_seconds = max(60, close_seconds - current_seconds)
        status = f"🟢 <b>OUVERT</b>\nFerme dans environ <b>{fmt_time(remaining_game_seconds)}</b> (heure du jeu)."
    else:
        current_seconds = hours * 3600 + minutes * 60
        open_seconds = CASINO_OPEN_HOUR * 3600
        if open_seconds <= current_seconds:
            open_seconds += 86400
        remaining_game_seconds = max(60, open_seconds - current_seconds)
        status = f"🔴 <b>FERMÉ</b>\nOuvre dans environ <b>{fmt_time(remaining_game_seconds)}</b> (heure du jeu)."

    return (
        f"🎰 <b>Casino</b>\n"
        f"Heure de jeu : <b>{game_time_str}</b>\n"
        f"Horaires : <b>{open_time} → {close_time}</b> (heure du jeu)\n"
        f"{status}"
    )

@require_registered
@require_location("casino")
async def cmd_casino(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(get_casino_status_text(), parse_mode="HTML")

# ─────────────────────────────────────────────────────────────────────────────
# Helpers communs
# ─────────────────────────────────────────────────────────────────────────────

async def add_random_item(user_id: int, min_rarity: str = "common", max_rarity: str = "legendary"):
    rarity_order = ["common", "rare", "epic", "legendary"]
    min_idx = rarity_order.index(min_rarity)
    max_idx = rarity_order.index(max_rarity)
    possible = [r for r in rarity_order if min_idx <= rarity_order.index(r) <= max_idx]
    chosen_rarity = random.choice(possible)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT item_id, name, emoji, rarity FROM items WHERE rarity = ? ORDER BY RANDOM() LIMIT 1",
            (chosen_rarity,)
        ) as cur:
            item = await cur.fetchone()
        if not item:
            return None

        async with db.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?",
            (user_id, item["item_id"])
        ) as cur2:
            existing = await cur2.fetchone()
        if existing:
            await db.execute(
                "UPDATE inventory SET quantity = quantity + 1 WHERE user_id = ? AND item_id = ?",
                (user_id, item["item_id"])
            )
        else:
            await db.execute("""
                INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, item["item_id"], "loot", item["name"], 1, now()))
        await db.commit()
    return f"{item['emoji']} {item['name']} ({item['rarity']})"

def validate_bet(u: dict, args: list) -> tuple[int | None, str | None]:
    if not args:
        return None, f"Usage : commande [mise]\nMise min : {fmt(CASINO_MIN_BET)} | Max : {fmt(CASINO_MAX_BET)}"
    amount = parse_amount(args[0], u["balance"])
    if not amount or amount < CASINO_MIN_BET:
        return None, f"❌ Mise minimum : {fmt(CASINO_MIN_BET)}"
    if amount > CASINO_MAX_BET:
        return None, f"❌ Mise maximum : {fmt(CASINO_MAX_BET)}"
    if amount > u["balance"]:
        return None, f"❌ Fonds insuffisants ! Solde : {fmt(u['balance'])}"
    return amount, None

async def track_casino(user_id: int, bet: int, win: int):
    """Enregistre les stats casino + applique le bonus VIP sur les gains."""
    await increment_field(user_id, "casino_total_bet", bet)
    if win > 0:
        # ⭐ Bonus VIP/Premium sur les gains casino
        try:
            u = await get_user(user_id)
            bonus = casino_bonus(u)
            if bonus > 0:
                # ⚖️ Plafonné à CASINO_VIP_BONUS_CAP × la mise : le bonus ne peut plus rendre un jeu
                # rentable sur la durée (avant : +25 % de TOUS les gains = argent infini).
                bonus_amount = min(int(win * bonus), int(bet * CASINO_VIP_BONUS_CAP))
                await update_balance(user_id, bonus_amount)
                win += bonus_amount
        except Exception:
            swallowed('handlers/casino.py')

        await increment_field(user_id, "casino_total_win", win)
        # ✅ Mise à jour de la mission "Gagner 30K en jeux"
        await update_mission_progress(user_id, "casino_win", win)

# ─────────────────────────────────────────────────────────────────────────────
# Helper Blackjack
# ─────────────────────────────────────────────────────────────────────────────
def card() -> str:
    from gameplay.casino import _blackjack_card
    return _blackjack_card(random)

def hand_value(hand: list) -> int:
    from gameplay.casino import blackjack_hand_value
    return blackjack_hand_value(hand)

# ─────────────────────────────────────────────────────────────────────────────
# Dictionnaire pour stocker les parties en cours (callbacks)
# ─────────────────────────────────────────────────────────────────────────────
active_games = {}  # clé: (user_id, message_id)

# ─────────────────────────────────────────────────────────────────────────────
# 1. SLOTS (interactif)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@require_location("casino")
async def cmd_slots(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_casino_open():
        await update.message.reply_text(get_casino_status_text(), parse_mode="HTML")
        return

    user = update.effective_user
    u = await get_user(user.id)
    amount, err = validate_bet(u, context.args)
    if err:
        await update.message.reply_text(err)
        return

    await update_balance(user.id, -amount, sink="casino")

    keyboard = [[InlineKeyboardButton("🎰 SPIN", callback_data=f"slots_spin:{user.id}:{amount}")]]
    msg = await update.message.reply_text(
        f"🎰 <b>Machine à Sous</b>\n\n"
        f"💰 Mise : {escape_html(fmt(amount))}\n"
        f"Appuie sur SPIN pour lancer les rouleaux.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    active_games[(user.id, msg.message_id)] = {
        "game": "slots",
        "amount": amount,
        "user_id": user.id,
        "message_id": msg.message_id,
        "chat_id": msg.chat_id,
        "created_at": int(time.time()),   # ⭐ FIX #3 : timestamp pour cleanup
    }

async def slots_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data.split(":")
    if data[0] != "slots_spin":
        return
    user_id = int(data[1])
    amount = int(data[2])

    if query.from_user.id != user_id:
        await query.answer("Ce n'est pas ton jeu !", show_alert=True)
        return

    game_key = (user_id, query.message.message_id)
    game = active_games.get(game_key)
    if not game:
        await query.answer("Partie expirée.", show_alert=True)
        return

    SYMBOLS = ["🍒", "🍋", "🍊", "🍇", "🔔", "💎", "7️⃣", "🌟", "🍀", "💰"]
    WEIGHTS = [20, 20, 15, 15, 10, 5, 5, 3, 4, 3]
    reels = [random.choices(SYMBOLS, weights=WEIGHTS)[0] for _ in range(5)]

    win = 0
    unique = set(reels)
    # ⚖️ Table rééquilibrée : retour joueur ≈ 90 % (avant : ≈ 138 %, argent infini).
    if len(unique) == 1:
        mult = 50
    elif reels[0] == reels[1] == reels[2]:
        mult = 7
    elif len(unique) == 2 and max(reels.count(s) for s in unique) >= 4:
        mult = 12
    elif len(unique) <= 2:
        mult = 5
    elif len(unique) == 3:
        mult = 1
    elif "💎" in reels or "7️⃣" in reels:
        mult = 0.5
    else:
        mult = 0

    win = int(amount * mult)
    if win > 0:
        await update_balance(user_id, win)
        # ⭐ XP avec boost appliqué
        await add_xp(user_id, 30)
    await track_casino(user_id, amount, win)

    loot_msg = ""
    if win > 0:
        u = await get_user(user_id)
        loot_chance = 0.2 + chance_boost_bonus(u)
        if random.random() < loot_chance:
            item = await add_random_item(user_id, "common", "epic")
            if item:
                loot_msg = f"\n\n🎁 Tu as gagné un item : {item} !"

    result_text = " | ".join(reels)
    if mult >= 50:
        msg = "🎉 **JACKPOT ABSOLU !!!**"
    elif mult >= 10:
        msg = "🎉 **JACKPOT !!!**"
    elif mult >= 5:
        msg = "🎉 **Gros gain !**"
    elif mult > 1:
        msg = "✅ **Petit gain !**"
    elif mult == 1:
        msg = "💫 **Mise récupérée !**"
    elif mult > 0:
        msg = "😕 **Mise en partie récupérée.**"
    else:
        msg = "❌ **Perdu !**"

    await query.edit_message_text(
        f"🎰 <b>Machine à Sous</b>\n\n"
        f"[ {escape_html(result_text)} ]\n\n"
        f"{escape_html(msg)}\n"
        f"💰 Mise : {escape_html(fmt(amount))} | "
        f"{escape_html('💵 Gain : ' + fmt(win) if win > 0 else '💸 Perdu : ' + fmt(amount))}\n"
        f"💵 Solde : {escape_html(fmt((await get_user(user_id))['balance']))}{escape_html(loot_msg)}",
        parse_mode="HTML",
        reply_markup=None
    )
    active_games.pop(game_key, None)

# ─────────────────────────────────────────────────────────────────────────────
# 2. BLACKJACK (interactif)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@require_location("casino")
async def cmd_blackjack(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_casino_open():
        await update.message.reply_text(get_casino_status_text(), parse_mode="HTML")
        return

    user = update.effective_user
    u = await get_user(user.id)
    amount, err = validate_bet(u, context.args)
    if err:
        await update.message.reply_text(err)
        return

    from gameplay.casino import blackjack_start
    game = await blackjack_start(user.id, amount)
    player, dealer = game["player_hand"], game["dealer_hand"]
    pv = hand_value(player)

    if game["status"] == "blackjack":
        loot_msg = f"\n\n🎁 Tu as gagné un item : {game['loot']} !" if game["loot"] else ""
        await update.message.reply_text(
            f"🃏 <b>BLACKJACK !</b> Naturel !\n\n"
            f"Ton jeu : {escape_html(' '.join(player))} = 21\n"
            f"Croupier : {escape_html(dealer[0])} ?\n\n"
            f"🎉 <b>+{escape_html(fmt(game['gross_payout']))} (x1.5)</b>{escape_html(loot_msg)}",
            parse_mode="HTML"
        )
        return

    keyboard = [
        [InlineKeyboardButton("🃏 Tirer", callback_data=f"bj_hit:{user.id}:{amount}:{','.join(player)}:{','.join(dealer)}"),
         InlineKeyboardButton("✋ Rester", callback_data=f"bj_stand:{user.id}:{amount}:{','.join(player)}:{','.join(dealer)}"),
         InlineKeyboardButton("💥 Doubler", callback_data=f"bj_double:{user.id}:{amount}:{','.join(player)}:{','.join(dealer)}")]
    ]

    await update.message.reply_text(
        f"🃏 <b>Blackjack — Mise : {escape_html(fmt(amount))}</b>\n\n"
        f"Ton jeu : {escape_html(' '.join(player))} = {escape_html(pv)}\n"
        f"Croupier : {escape_html(dealer[0])} ?\n\n"
        f"Que fais-tu ?",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def bj_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    parts = query.data.split(":")
    action = parts[0]
    user_id = int(parts[1])
    amount = int(parts[2])
    player = parts[3].split(",")
    dealer_hand = parts[4].split(",")

    if query.from_user.id != user_id:
        await query.answer("Ce n'est pas ton jeu !", show_alert=True)
        return

    from gameplay.casino import blackjack_action
    game = {"status": "active", "bet": amount, "player_hand": player, "dealer_hand": dealer_hand}
    try:
        result_data = await blackjack_action(user_id, game, action.removeprefix("bj_"))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return

    player, dealer_hand = result_data["player_hand"], result_data["dealer_hand"]
    pv = hand_value(player)
    if result_data["status"] == "active":
        keyboard = [[
            InlineKeyboardButton("🃏 Tirer", callback_data=f"bj_hit:{user_id}:{amount}:{','.join(player)}:{','.join(dealer_hand)}"),
            InlineKeyboardButton("✋ Rester", callback_data=f"bj_stand:{user_id}:{amount}:{','.join(player)}:{','.join(dealer_hand)}"),
        ]]
        await query.edit_message_text(
            f"🃏 <b>Blackjack</b>\n\nTon jeu : {escape_html(' '.join(player))} = {escape_html(pv)}\nCroupier : {escape_html(dealer_hand[0])} ?",
            parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))
        return
    if result_data["status"] == "bust":
        await query.edit_message_text(
            f"🃏 <b>Blackjack — Bust !</b>\n\nTon jeu : {escape_html(' '.join(player))} = {escape_html(pv)}\n\n❌ Tu dépasses 21 ! Perdu {escape_html(fmt(amount))}.",
            parse_mode="HTML")
        return
    status = result_data["status"]
    result = "✅ Tu gagnes !" if status == "win" else ("🤝 Égalité !" if status == "push" else "❌ Le croupier gagne.")
    win = result_data["gross_payout"]
    loot_msg = f"\n\n🎁 Tu as gagné un item : {result_data['loot']} !" if result_data.get("loot") else ""
    await query.edit_message_text(
        f"🃏 <b>Blackjack — Résultat</b>\n\n"
        f"Ton jeu : {escape_html(' '.join(player))} = {escape_html(pv)}\n"
        f"Croupier : {escape_html(' '.join(dealer_hand))} = {escape_html(result_data['dealer_value'])}\n\n"
        f"{escape_html(result)}\n"
        f"{escape_html('💵 Gain : ' + fmt(win) if win > 0 else '💸 Perdu : ' + fmt(result_data['bet']))}{escape_html(loot_msg)}",
        parse_mode="HTML")

# ─────────────────────────────────────────────────────────────────────────────
# 3. ROULETTE (interactive)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@require_location("casino")
async def cmd_roulette(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_casino_open():
        await update.message.reply_text(get_casino_status_text(), parse_mode="HTML")
        return

    user = update.effective_user
    u = await get_user(user.id)
    amount, err = validate_bet(u, context.args)
    if err:
        await update.message.reply_text(err)
        return

    await update_balance(user.id, -amount, sink="casino")

    keyboard = [
        [
            InlineKeyboardButton("🔴 Rouge", callback_data=f"roulette_bet:{user.id}:{amount}:rouge"),
            InlineKeyboardButton("⚫ Noir", callback_data=f"roulette_bet:{user.id}:{amount}:noir"),
        ],
        [
            InlineKeyboardButton("🟢 Pair", callback_data=f"roulette_bet:{user.id}:{amount}:pair"),
            InlineKeyboardButton("🟣 Impair", callback_data=f"roulette_bet:{user.id}:{amount}:impair"),
        ],
        [
            InlineKeyboardButton("🎡 1-18", callback_data=f"roulette_bet:{user.id}:{amount}:1-18"),
            InlineKeyboardButton("🎡 19-36", callback_data=f"roulette_bet:{user.id}:{amount}:19-36"),
        ],
        [
            InlineKeyboardButton("🎡 1-12", callback_data=f"roulette_bet:{user.id}:{amount}:1-12"),
            InlineKeyboardButton("🎡 13-24", callback_data=f"roulette_bet:{user.id}:{amount}:13-24"),
            InlineKeyboardButton("🎡 25-36", callback_data=f"roulette_bet:{user.id}:{amount}:25-36"),
        ],
        [InlineKeyboardButton("🎯 Numéro (0-36)", callback_data=f"roulette_number:{user.id}:{amount}")],
    ]
    msg = await update.message.reply_text(
        f"🎡 <b>Roulette</b>\n\n"
        f"💰 Mise : {escape_html(fmt(amount))}\n"
        f"Choisis ton pari, puis appuie sur LANCER.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    active_games[(user.id, msg.message_id)] = {
        "game": "roulette",
        "amount": amount,
        "user_id": user.id,
        "message_id": msg.message_id,
        "chat_id": msg.chat_id,
        "bet_type": None,
        "created_at": int(time.time()),   # ⭐ FIX #3
    }

async def roulette_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data.split(":")
    action = data[0]
    user_id = int(data[1])
    amount = int(data[2])

    if query.from_user.id != user_id:
        await query.answer("Ce n'est pas ton jeu !", show_alert=True)
        return

    game_key = (user_id, query.message.message_id)
    game = active_games.get(game_key)
    if not game:
        await query.answer("Partie expirée.", show_alert=True)
        return

    if action == "roulette_bet":
        bet_type = data[3]
        game["bet_type"] = bet_type
        keyboard = [[InlineKeyboardButton("🎡 LANCER", callback_data=f"roulette_spin:{user_id}:{amount}")]]
        await query.edit_message_text(
            f"🎡 <b>Roulette</b>\n\n"
            f"💰 Mise : {escape_html(fmt(amount))}\n"
            f"Pari choisi : <b>{escape_html(bet_type)}</b>\n\n"
            f"Appuie sur LANCER pour faire tourner la roue.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif action == "roulette_number":
        await query.edit_message_text(
            f"🎡 <b>Roulette</b>\n\n"
            f"💰 Mise : {escape_html(fmt(amount))}\n"
            f"✏️ Envoie le numéro (0-36) dans la conversation.\n\n"
            f"<i>(le bot attend ta réponse)</i>",
            parse_mode="HTML",
            reply_markup=None
        )
        game["awaiting_number"] = True
        context.user_data["roulette_awaiting"] = True
        context.user_data["roulette_game_key"] = game_key
        context.user_data["roulette_amount"] = amount

    elif action == "roulette_spin":
        bet_type = game.get("bet_type")
        if not bet_type:
            await query.answer("Choisis d'abord un pari !", show_alert=True)
            return

        from gameplay.casino import settle_roulette
        settled = await settle_roulette(user_id, amount, bet_type, stake_predebited=True)
        spin = settled["number"]
        win = settled["gross_payout"]
        spin_color = {"red": "🔴", "black": "⚫", "green": "🟢"}[settled["color"]]
        loot_msg = f"\n\n🎁 Tu as gagné un item : {settled['loot']} !" if settled["loot"] else ""

        await query.edit_message_text(
            f"🎡 <b>Roulette</b>\n\n"
            f"La bille tombe sur : <b>{spin_color} {spin}</b>\n\n"
            f"Ton pari : {bet_type}\n"
            f"{'🎉 <b>GAGNÉ !</b>' if win > 0 else '❌ <b>Perdu !</b>'}\n"
            f"{'💵 Gain : ' + fmt(win) if win > 0 else '💸 Perdu : ' + fmt(amount)}\n"
            f"💵 Solde : {fmt(settled['balance'])}{loot_msg}",
            parse_mode="HTML",
            reply_markup=None
        )
        active_games.pop(game_key, None)

async def roulette_number_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_user or not update.message or not update.message.text:
        return
    if context.user_data is None:
        return

    user = update.effective_user

    if not context.user_data.get("roulette_awaiting"):
        return

    game_key = context.user_data.get("roulette_game_key")
    if not game_key:
        return

    game = active_games.get(game_key)
    if not game or game["user_id"] != user.id:
        context.user_data.pop("roulette_awaiting", None)
        context.user_data.pop("roulette_game_key", None)
        return

    try:
        num = int(update.message.text.strip())
        if not (0 <= num <= 36):
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Numéro invalide. Envoie un nombre entre 0 et 36.")
        return

    amount = context.user_data.get("roulette_amount") or game["amount"]

    from gameplay.casino import settle_roulette
    settled = await settle_roulette(user.id, amount, f"number:{num}", stake_predebited=True)
    spin = settled["number"]
    win = settled["gross_payout"]
    spin_color = {"red": "🔴", "black": "⚫", "green": "🟢"}[settled["color"]]
    loot_msg = f"\n\n🎁 Tu as gagné un item : {settled['loot']} !" if settled["loot"] else ""

    try:
        await context.bot.edit_message_text(
            f"🎡 <b>Roulette</b>\n\n"
            f"La bille tombe sur : <b>{spin_color} {spin}</b>\n\n"
            f"Ton pari : numéro {num}\n"
            f"{'🎉 <b>GAGNÉ !</b>' if win > 0 else '❌ <b>Perdu !</b>'}\n"
            f"{'💵 Gain : ' + fmt(win) if win > 0 else '💸 Perdu : ' + fmt(amount)}\n"
            f"💵 Solde : {fmt(settled['balance'])}{loot_msg}",
            parse_mode="HTML",
            chat_id=game["chat_id"],
            message_id=game["message_id"],
            reply_markup=None
        )
    except Exception:
        await update.message.reply_text("❌ Impossible de mettre à jour le message.")

    active_games.pop(game_key, None)
    context.user_data.pop("roulette_awaiting", None)
    context.user_data.pop("roulette_game_key", None)
    context.user_data.pop("roulette_amount", None)
    
# ─────────────────────────────────────────────────────────────────────────────
# 4. CRASH (interactif)
# ─────────────────────────────────────────────────────────────────────────────
active_crash_games = {}

@require_registered
@require_free
@require_location("casino")
async def cmd_crash(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_casino_open():
        await update.message.reply_text(get_casino_status_text(), parse_mode="HTML")
        return

    user = update.effective_user
    u = await get_user(user.id)
    amount, err = validate_bet(u, context.args)
    if err:
        await update.message.reply_text(err)
        return

    # ⚖️ Crash classique : P(point >= m) = 0,92 / m  →  retour joueur de 92 % quel que soit
    # le moment où il encaisse (avant : jusqu'à ~101 % en encaissant à x1.1).
    from gameplay.casino import crash_point_from_roll
    crash_point = crash_point_from_roll(random.random())

    await update_balance(user.id, -amount, sink="casino")

    game_data = {
        "user_id": user.id,
        "amount": amount,
        "crash_point": crash_point,
        "current_mult": 1.0,
        "running": True,
        "status": "active",
        "message_id": None,
        "chat_id": update.effective_chat.id,
        "created_at": int(time.time()),   # ⭐ FIX #3 : timestamp cleanup
    }

    keyboard = [[InlineKeyboardButton("💸 ENCAISSER", callback_data=f"crash_cashout:{user.id}:{amount}")]]

    msg = await update.message.reply_text(
        f"🚀 <b>CRASH GAME</b>\n\n"
        f"💰 Mise : <b>{escape_html(fmt(amount))}</b>\n"
        f"📈 Multiplicateur : <b>1.00x</b>\n"
        f"💵 Gain potentiel : <b>{escape_html(fmt(amount))}</b>\n\n"
        f"⚠️ Le crash peut arriver à tout moment !\n"
        f"👇 Appuie sur ENCAISSER avant le crash !",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

    game_data["message_id"] = msg.message_id
    game_data["chat_id"] = msg.chat_id
    active_crash_games[(user.id, msg.message_id)] = game_data

    async def run_crash_game():
        mult = 1.0
        interval = 0.15

        from gameplay.casino import advance_crash
        while game_data["running"] and mult < crash_point:
            mult, crashed = advance_crash(game_data)

            if int(mult * 20) % 5 == 0 or mult >= crash_point:
                try:
                    potential_win = int(amount * mult)
                    new_text = (
                        f"🚀 <b>CRASH GAME</b>\n\n"
                        f"💰 Mise : <b>{escape_html(fmt(amount))}</b>\n"
                        f"📈 Multiplicateur : <b>{mult:.2f}x</b>\n"
                        f"💵 Gain potentiel : <b>{escape_html(fmt(potential_win))}</b>\n\n"
                        f"⚠️ Le crash peut arriver à tout moment !\n"
                        f"👇 Appuie sur ENCAISSER avant le crash !"
                    )
                    await context.bot.edit_message_text(
                        new_text,
                        chat_id=game_data["chat_id"],
                        message_id=game_data["message_id"],
                        parse_mode="HTML",
                        reply_markup=InlineKeyboardMarkup(keyboard)
                    )
                except Exception:
                    swallowed('handlers/casino.py')
            if crashed:
                break
            await asyncio.sleep(interval)

        if game_data["running"] and mult >= crash_point:
            game_data["running"] = False
            game_data["status"] = "crashed"
        if game_data.get("status") == "crashed":
            try:
                await context.bot.edit_message_text(
                    f"💥 <b>CRASH !</b>\n\n"
                    f"💰 Mise : {escape_html(fmt(amount))}\n"
                    f"📈 Dernier multiplicateur : <b>{mult:.2f}x</b>\n"
                    f"❌ Tu n'as pas encaissé à temps.\n"
                    f"💸 Perte : <b>{escape_html(fmt(amount))}</b>\n\n",
                    chat_id=game_data["chat_id"],
                    message_id=game_data["message_id"],
                    parse_mode="HTML"
                )
            except Exception:
                swallowed('handlers/casino.py')

        active_crash_games.pop((user.id, msg.message_id), None)

    asyncio.create_task(run_crash_game())


async def crash_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    parts = query.data.split(":")
    user_id = int(parts[1])
    amount = int(parts[2])

    if query.from_user.id != user_id:
        await query.answer("Ce n'est pas ton jeu !", show_alert=True)
        return

    game_key = (user_id, query.message.message_id)
    game_data = active_crash_games.get(game_key)

    if game_data is None:
        await query.answer("Le jeu est déjà terminé !", show_alert=True)
        return

    if not game_data["running"]:
        await query.answer("Le jeu a déjà crashé !", show_alert=True)
        return

    from gameplay.casino import settle_crash_cashout
    try:
        settled = await settle_crash_cashout(user_id, game_data)
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    current_mult = settled["multiplier"]
    win = settled["gross_payout"]

    profit = win - amount
    if profit > 0:
        profit_text = f"✅ Profit : **+{fmt(profit)}**"
    elif profit < 0:
        profit_text = f"❌ Perte : **{fmt(profit)}**"
    else:
        profit_text = "🤝 Équilibre"

    loot_msg = f"\n\n🎁 Tu as gagné un item : {settled['loot']} !" if settled["loot"] else ""

    await query.edit_message_text(
        f"💸 <b>ENCAISSEMENT RÉUSSI !</b>\n\n"
        f"💰 Mise : {escape_html(fmt(amount))}\n"
        f"📈 Multiplicateur : <b>{current_mult:.2f}x</b>\n"
        f"💵 Gain : <b>{escape_html(fmt(win))}</b>\n"
        f"{escape_html(profit_text)}{escape_html(loot_msg)}\n\n",
        parse_mode="HTML"
    )

    active_crash_games.pop(game_key, None)


# ─────────────────────────────────────────────────────────────────────────────
# 5. POKER (vidéo poker automatique)
# ─────────────────────────────────────────────────────────────────────────────
def hand_rank(hand):
    from gameplay.casino import poker_hand_rank
    return poker_hand_rank(hand)


@require_registered
@require_free
@require_location("casino")
async def cmd_poker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_casino_open():
        await update.message.reply_text(get_casino_status_text(), parse_mode="HTML")
        return

    user = update.effective_user
    u = await get_user(user.id)
    amount, err = validate_bet(u, context.args)
    if err:
        await update.message.reply_text(err)
        return

    from gameplay.casino import play_video_poker
    result_data = await play_video_poker(user.id, amount)
    player_hand = result_data["player_hand"]
    dealer_hand = result_data["dealer_hand"]
    p_name = result_data["player_name"]
    d_name = result_data["dealer_name"]
    win = result_data["gross_payout"]
    if result_data["outcome"] == "win":
        result = f"🎉 **Tu gagnes !** x{result_data['multiplier']}\n💵 Gain : {fmt(win)}"
    elif result_data["outcome"] == "push":
        result = f"🤝 **Égalité !**\n💵 Récupéré : {fmt(amount)}"
    else:
        result = f"❌ **Perdu !**\n💸 Perdu : {fmt(amount)}"
    loot_msg = f"\n\n🎁 Tu as gagné un item : {result_data['loot']} !" if result_data["loot"] else ""

    await update.message.reply_text(
        f"♠️ <b>Poker — Video Poker</b>\n\n"
        f"Ta main : {escape_html(' '.join(player_hand))}\n"
        f"🎴 {escape_html(p_name)}\n\n"
        f"Croupier : {escape_html(' '.join(dealer_hand))}\n"
        f"🎴 {escape_html(d_name)}\n\n"
        f"{escape_html(result)}\n"
        f"💵 Solde : {escape_html(fmt(result_data['balance']))}{escape_html(loot_msg)}",
        parse_mode="HTML"
    )


# ─────────────────────────────────────────────────────────────────────────────
# 6. MINES (interactif)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@require_location("casino")
@cooldown("casino_last", 10, "⏳ Attends 10 secondes avant de rejouer.")
async def cmd_mines(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_casino_open():
        await update.message.reply_text(get_casino_status_text(), parse_mode="HTML")
        return

    user = update.effective_user
    u = await get_user(user.id)
    amount, err = validate_bet(u, context.args)
    if err:
        await update.message.reply_text(err)
        return

    MAX_BET = 200_000
    if amount > MAX_BET:
        await update.message.reply_text(f"❌ Mise maximale pour Mines : {fmt(MAX_BET)}")
        return

    try:
        await update_balance(user.id, -amount, sink="casino")
    except ValueError:      # solde insuffisant entre la validation de la mise et le débit : aucune partie n'est créée
        await update.message.reply_text("❌ Fonds insuffisants pour cette mise.")
        return

    from gameplay.casino import mines_layout
    mines = mines_layout()
    revealed = set()
    multiplier = 1.0

    def build_keyboard():
        buttons = []
        for i in range(5):
            row = []
            for j in range(5):
                idx = i*5 + j
                if idx in revealed:
                    text = "💣" if idx in mines else "💎"
                else:
                    text = "⬛"
                callback = f"mines_click:{user.id}:{amount}:{idx}"
                row.append(InlineKeyboardButton(text, callback_data=callback))
            buttons.append(row)
        buttons.append([InlineKeyboardButton("💰 ENCAISSER", callback_data=f"mines_cashout:{user.id}:{amount}")])
        return InlineKeyboardMarkup(buttons)

    msg = await update.message.reply_text(
        f"💣 <b>MINES</b>\n\n"
        f"💰 Mise : {escape_html(fmt(amount))}\n"
        f"💎 Cases sûres révélées : {escape_html(len(revealed))}\n"
        f"📈 Multiplicateur actuel : {multiplier:.2f}x\n"
        f"💵 Gain potentiel : {escape_html(fmt(int(amount * multiplier)))}\n\n"
        f"Clique sur une case pour la révéler, ou encaisse !",
        parse_mode="HTML",
        reply_markup=build_keyboard()
    )

    active_games[(user.id, msg.message_id)] = {
        "game": "mines",
        "amount": amount,
        "user_id": user.id,
        "message_id": msg.message_id,
        "chat_id": msg.chat_id,
        "mines": mines,
        "revealed": revealed,
        "multiplier": multiplier,
        "game_over": False,
        "created_at": int(time.time()),   # ⭐ FIX #3
    }


def build_mines_keyboard(game):
    buttons = []
    for i in range(5):
        row = []
        for j in range(5):
            idx = i*5 + j
            if idx in game["revealed"]:
                text = "💣" if idx in game["mines"] else "💎"
            else:
                text = "⬛"
            callback = f"mines_click:{game['user_id']}:{game['amount']}:{idx}"
            row.append(InlineKeyboardButton(text, callback_data=callback))
        buttons.append(row)
    buttons.append([InlineKeyboardButton("💰 ENCAISSER", callback_data=f"mines_cashout:{game['user_id']}:{game['amount']}")])
    return InlineKeyboardMarkup(buttons)


async def mines_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data.split(":")
    action = data[0]
    user_id = int(data[1])
    amount = int(data[2])

    if query.from_user.id != user_id:
        await query.answer("Ce n'est pas ton jeu !", show_alert=True)
        return

    game_key = (user_id, query.message.message_id)
    game = active_games.get(game_key)
    if not game or game.get("game_over"):
        await query.answer("Partie terminée.", show_alert=True)
        return

    if action == "mines_click":
        idx = int(data[3])
        from gameplay.casino import mines_reveal, mines_lost
        game.setdefault("status", "active")
        try:
            transition = mines_reveal(game, idx)
        except ValueError as exc:
            await query.answer(str(exc), show_alert=True)
            return
        if transition["status"] == "loss":
            game["game_over"] = True
            await mines_lost(user_id, game)
            await query.edit_message_text(
                f"💣 <b>MINE !</b>\n\n"
                f"💥 Tu as cliqué sur une mine !\n"
                f"💸 Perdu : {escape_html(fmt(amount))}\n"
                f"💵 Solde : {escape_html(fmt((await get_user(user_id))['balance']))}",
                parse_mode="HTML",
                reply_markup=None
            )
            active_games.pop(game_key, None)
            return
        else:
            multiplier = transition["multiplier"]
            potential_win = int(amount * multiplier)
            keyboard = build_mines_keyboard(game)
            await query.edit_message_text(
                f"💣 <b>MINES</b>\n\n"
                f"💰 Mise : {escape_html(fmt(amount))}\n"
                f"💎 Cases sûres révélées : {escape_html(len(game['revealed']))}\n"
                f"📈 Multiplicateur actuel : {multiplier:.2f}x\n"
                f"💵 Gain potentiel : {escape_html(fmt(potential_win))}\n\n"
                f"Clique sur une case pour continuer, ou encaisse !",
                parse_mode="HTML",
                reply_markup=keyboard
            )

    elif action == "mines_cashout":
        from gameplay.casino import mines_cashout
        game.setdefault("status", "active")
        try:
            settled = await mines_cashout(user_id, game)
        except ValueError as exc:
            await query.answer(str(exc), show_alert=True)
            return
        multiplier = settled["multiplier"]
        win = settled["gross_payout"]
        loot_msg = f"\n\n🎁 Tu as gagné un item : {settled['loot']} !" if settled["loot"] else ""

        game["game_over"] = True
        await query.edit_message_text(
            f"💰 <b>ENCAISSEMENT RÉUSSI !</b>\n\n"
            f"💰 Mise : {escape_html(fmt(amount))}\n"
            f"📈 Multiplicateur : {multiplier:.2f}x\n"
            f"💵 Gain : {escape_html(fmt(win))}\n"
            f"💵 Solde : {escape_html(fmt(settled['balance']))}{escape_html(loot_msg)}",
            parse_mode="HTML",
            reply_markup=None
        )
        active_games.pop(game_key, None)


# ─────────────────────────────────────────────────────────────────────────────
# 7. PMU (interactif)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@require_location("casino")
async def cmd_pmu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_casino_open():
        await update.message.reply_text(get_casino_status_text(), parse_mode="HTML")
        return

    user = update.effective_user
    u = await get_user(user.id)
    amount, err = validate_bet(u, context.args)
    if err:
        await update.message.reply_text(err)
        return

    await update_balance(user.id, -amount, sink="casino")

    from gameplay.casino import PMU_HORSES
    horses = PMU_HORSES

    keyboard = []
    for i, h in enumerate(horses):
        keyboard.append([InlineKeyboardButton(
            f"{h['emoji']} {h['name']} (x{h['odds']})",
            callback_data=f"pmu_bet:{user.id}:{amount}:{i}"
        )])
    keyboard.append([InlineKeyboardButton("🚀 LANCER LA COURSE", callback_data=f"pmu_run:{user.id}:{amount}")])

    msg = await update.message.reply_text(
        f"🏇 <b>Paris Hippiques</b>\n\n"
        f"💰 Mise : {escape_html(fmt(amount))}\n"
        f"Choisis ton cheval, puis lance la course.",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    active_games[(user.id, msg.message_id)] = {
        "game": "pmu",
        "amount": amount,
        "user_id": user.id,
        "message_id": msg.message_id,
        "chat_id": msg.chat_id,
        "chosen": None,
        "horses": horses,
        "created_at": int(time.time()),   # ⭐ FIX #3
    }


async def pmu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data.split(":")
    action = data[0]
    user_id = int(data[1])
    amount = int(data[2])

    if query.from_user.id != user_id:
        await query.answer("Ce n'est pas ton jeu !", show_alert=True)
        return

    game_key = (user_id, query.message.message_id)
    game = active_games.get(game_key)
    if not game:
        await query.answer("Partie expirée.", show_alert=True)
        return

    if action == "pmu_bet":
        idx = int(data[3])
        game["chosen"] = idx
        horse = game["horses"][idx]
        await query.edit_message_text(
            f"🏇 <b>Paris Hippiques</b>\n\n"
            f"💰 Mise : {escape_html(fmt(amount))}\n"
            f"Cheval choisi : {escape_html(horse['emoji'])} {escape_html(horse['name'])} (cote {escape_html(horse['odds'])}x)\n\n"
            f"Appuie sur LANCER LA COURSE pour voir le résultat.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🚀 LANCER LA COURSE", callback_data=f"pmu_run:{user_id}:{amount}")]])
        )

    elif action == "pmu_run":
        chosen_idx = game.get("chosen")
        if chosen_idx is None:
            await query.answer("Choisis d'abord un cheval !", show_alert=True)
            return

        from gameplay.casino import settle_pmu
        settled = await settle_pmu(user_id, amount, chosen_idx, stake_predebited=True)
        horses = settled["horses"]
        ranking = settled["ranking"]
        winner_idx = settled["winner_index"]
        winner = horses[winner_idx]
        win = settled["gross_payout"]
        if settled["won"]:
            result = f"🎉 **TON CHEVAL GAGNE !**\n💵 Gain : {fmt(win)} (x{horses[chosen_idx]['odds']})"
        else:
            result = f"❌ **{winner['emoji']} {winner['name']} gagne !**\n💸 Perdu : {fmt(amount)}"
        loot_msg = f"\n\n🎁 Tu as gagné un item : {settled['loot']} !" if settled["loot"] else ""

        podium = "\n".join(f"{i+1}. {horses[pos]['emoji']} {horses[pos]['name']}" for i, pos in enumerate(ranking[:3]))
        await query.edit_message_text(
            f"🏇 <b>Course terminée !</b>\n\n"
            f"🏆 <b>Podium :</b>\n{escape_html(podium)}\n\n"
            f"{escape_html(result)}\n"
            f"💵 Solde : {escape_html(fmt(settled['balance']))}{escape_html(loot_msg)}",
            parse_mode="HTML",
            reply_markup=None
        )
        active_games.pop(game_key, None)


# ─────────────────────────────────────────────────────────────────────────────
# Export des fonctions pour bot.py
# ─────────────────────────────────────────────────────────────────────────────
__all__ = [
    "cmd_casino",
    "cmd_slots", "cmd_blackjack", "cmd_roulette", "cmd_crash",
    "cmd_poker", "cmd_mines", "cmd_pmu",
    "bj_callback", "crash_callback",
    "slots_callback", "roulette_callback", "mines_callback", "pmu_callback",
    "roulette_number_input",
    "cleanup_casino_games",   # ⭐ FIX #3 + #26 : EXPORT
]


# ═══════════════════════════════════════════════════════════════════
#              🎰 MENU INTERACTIF DU CASINO
# ═══════════════════════════════════════════════════════════════════
from types import SimpleNamespace
from utils.aesthetics import card as render_card  # alias : ne pas écraser card() (tirage Blackjack, ligne 150)
from utils.helpers import safe_edit


def _fake_context_for_game(query, amount: int) -> SimpleNamespace:
    """Construit un contexte minimal compatible avec les commandes casino."""
    return SimpleNamespace(args=[str(amount)])


def _fake_update_from_query_for_game(query) -> SimpleNamespace:
    """Construit un update minimal compatible avec les commandes casino."""
    return SimpleNamespace(
        effective_user=query.from_user,
        message=query.message,
        effective_message=query.message,
        callback_query=query,
        effective_chat=query.message.chat,
    )


# ─── Menu principal casino ────────────────────────────────────────
async def show_casino_menu(query, user_id: int):
    """Menu interactif du casino."""
    u = await get_user(user_id)
    is_open = is_casino_open()
    status_text = get_casino_status_text()

    body = [
        status_text.replace("🎰 <b>Casino</b>\n", ""),
        "",
        f"💰 Ton solde : <b>{fmt(u['balance'])}</b>",
    ]

    # ⭐ Afficher les bonus VIP
    vbonus = casino_bonus(u)
    cbonus = chance_boost_bonus(u)
    if vbonus > 0:
        body.append(f"⭐ Bonus VIP casino : <b>+{int(vbonus*100)}%</b>")
    if cbonus > 0:
        body.append(f"🎲 Boost Chance : <b>+{int(cbonus*100)}%</b>")

    keyboard = []
    if is_open:
        keyboard = [
            [InlineKeyboardButton("🎰 Slots", callback_data="cas_game_slots"),
             InlineKeyboardButton("🃏 Blackjack", callback_data="cas_game_bj")],
            [InlineKeyboardButton("🎡 Roulette", callback_data="cas_game_roulette"),
             InlineKeyboardButton("💥 Crash", callback_data="cas_game_crash")],
            [InlineKeyboardButton("♠️ Poker", callback_data="cas_game_poker"),
             InlineKeyboardButton("💣 Mines", callback_data="cas_game_mines")],
            [InlineKeyboardButton("🐎 PMU", callback_data="cas_game_pmu")],
            [InlineKeyboardButton("⬅️ Loisirs", callback_data="fun_menu")],
        ]
    else:
        body += ["", "<i>Le casino est fermé. Reviens à l'ouverture !</i>"]
        keyboard = [[InlineKeyboardButton("⬅️ Loisirs", callback_data="fun_menu")]]

    await safe_edit(
        query,
        render_card("🎰 CASINO", body, icon="🎰", style="thick",
             footer=f"Les paris vont de {fmt(CASINO_MIN_BET)} à {fmt(CASINO_MAX_BET)}"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


# ─── Choix de la mise ─────────────────────────────────────────────
GAME_LABELS = {
    "slots":    {"name": "🎰 Slots", "cmd": cmd_slots, "min": 100, "max": 100_000},
    "bj":       {"name": "🃏 Blackjack", "cmd": cmd_blackjack, "min": 100, "max": 1_000_000},
    "roulette": {"name": "🎡 Roulette", "cmd": cmd_roulette, "min": 100, "max": 1_000_000},
    "crash":    {"name": "💥 Crash", "cmd": cmd_crash, "min": 100, "max": 500_000},
    "poker":    {"name": "♠️ Poker", "cmd": cmd_poker, "min": 100, "max": 500_000},
    "mines":    {"name": "💣 Mines", "cmd": cmd_mines, "min": 100, "max": 200_000},
    "pmu":      {"name": "🐎 PMU", "cmd": cmd_pmu, "min": 100, "max": 1_000_000},
}


async def show_casino_bet_menu(query, user_id: int, game_key: str):
    if game_key not in GAME_LABELS:
        await safe_edit(query, "❌ Jeu inconnu.")
        return

    game = GAME_LABELS[game_key]
    u = await get_user(user_id)

    if not is_casino_open():
        await safe_edit(
            query,
            get_casino_status_text(),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="cas_menu")]])
        )
        return

    body = [
        f"💰 Ton solde : <b>{fmt(u['balance'])}</b>",
        "",
        f"Choisis ta mise pour <b>{game['name']}</b>.",
    ]

    base = max(game["min"], min(u["balance"] // 20, game["max"]))
    candidates = sorted(set([
        max(game["min"], base // 2),
        base,
        min(game["max"], base * 2),
    ]))
    candidates = [c for c in candidates if c <= u["balance"]]
    if not candidates:
        candidates = [game["min"]]

    keyboard = []
    row = []
    for c in candidates:
        row.append(InlineKeyboardButton(fmt(c), callback_data=f"cas_bet_{game_key}_{c}"))
    keyboard.append(row)
    keyboard.append([InlineKeyboardButton("💰 Autre montant", callback_data=f"cas_other_{game_key}")])
    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="cas_menu")])

    await safe_edit(
        query,
        render_card(f"🎰 {game['name']}", body, icon="🎰", style="round"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


# ─── Lancement du jeu ─────────────────────────────────────────────
async def launch_casino_game(query, user_id: int, game_key: str, amount: int):
    if game_key not in GAME_LABELS:
        await safe_edit(query, "❌ Jeu inconnu.")
        return
    game = GAME_LABELS[game_key]

    if not is_casino_open():
        await safe_edit(query, get_casino_status_text(), parse_mode="HTML")
        return

    if amount < game["min"]:
        await safe_edit(query, f"❌ Mise minimale pour {game['name']} : {fmt(game['min'])}")
        return
    if amount > game["max"]:
        await safe_edit(query, f"❌ Mise maximale pour {game['name']} : {fmt(game['max'])}")
        return

    u = await get_user(user_id)
    if u["balance"] < amount:
        await safe_edit(query, f"❌ Fonds insuffisants. Solde : {fmt(u['balance'])}")
        return

    fake_update = _fake_update_from_query_for_game(query)
    fake_context = _fake_context_for_game(query, amount)

    try:
        await game["cmd"](fake_update, fake_context)
    except Exception as e:
        import logging
        logging.getLogger(__name__).exception("Erreur lancement casino %s", game_key)
        try:
            await query.message.reply_text(
                f"❌ Erreur au lancement du jeu : {e}",
            )
        except Exception:
            swallowed('handlers/casino.py')


# ─── Callback routeur ─────────────────────────────────────────────
async def casino_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routeur des callbacks 'cas_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "cas_menu":
        await show_casino_menu(query, user_id)
        return

    if data.startswith("cas_game_"):
        game_key = data.replace("cas_game_", "")
        await show_casino_bet_menu(query, user_id, game_key)
        return

    if data.startswith("cas_bet_"):
        rest = data.replace("cas_bet_", "")
        try:
            game_key, amount_str = rest.rsplit("_", 1)
            amount = int(amount_str)
        except Exception:
            await safe_edit(query, "❌ Format invalide.")
            return
        await launch_casino_game(query, user_id, game_key, amount)
        return

    if data.startswith("cas_other_"):
        game_key = data.replace("cas_other_", "")
        game = GAME_LABELS.get(game_key)
        if not game:
            await safe_edit(query, "❌ Jeu inconnu.")
            return

        # ⭐ FIX #2 : cmd_map propre (évite "//blackjack")
        cmd_map = {
            "bj": "blackjack",
            "slots": "slots",
            "roulette": "roulette",
            "crash": "crash",
            "poker": "poker",
            "mines": "mines",
            "pmu": "pmu",
        }
        cmd_name = cmd_map.get(game_key, game_key)

        body = [
            f"<b>{game['name']}</b>",
            "",
            "Envoie la commande avec ta mise :",
            f"<code>/{cmd_name} [montant]</code>",
            "",
            "<i>Exemples :</i>",
            f"  • <code>/{cmd_name} 500</code>",
            f"  • <code>/{cmd_name} 5000</code>",
            f"  • <code>/{cmd_name} 50000</code>",
            "",
            f"<i>Mise min/max : {fmt(CASINO_MIN_BET)} – {fmt(CASINO_MAX_BET)}</i>",
        ]
        await safe_edit(
            query,
            render_card(f"💰 {game['name']} — Mise personnalisée", body, icon="💰", style="round"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data=f"cas_game_{game_key}")]])
        )
        return


# ═══════════════════════════════════════════════════════════════════
#   ⭐ FIX #3 + #26 : Nettoyage périodique des parties abandonnées
# ═══════════════════════════════════════════════════════════════════
async def cleanup_casino_games():
    """
    Purge les parties abandonnées (> 1h) pour éviter les fuites mémoire.
    Appelée par le scheduler (job 'casino_cleanup').
    """
    cutoff = int(time.time()) - 3600
    cleaned = 0

    for key in list(active_games.keys()):
        game = active_games.get(key)
        if not game:
            active_games.pop(key, None)
            continue
        created = game.get("created_at", 0)
        if created and created < cutoff:
            active_games.pop(key, None)
            cleaned += 1

    for key in list(active_crash_games.keys()):
        game = active_crash_games.get(key)
        if not game:
            active_crash_games.pop(key, None)
            continue
        created = game.get("created_at", 0)
        if created and created < cutoff:
            active_crash_games.pop(key, None)
            cleaned += 1

    if cleaned:
        import logging
        logging.getLogger(__name__).info(
            "🧹 Casino : %s parties abandonnées nettoyées.", cleaned
        )
