"""
handlers/hub.py — 🎮 MENU PRINCIPAL UNIQUE
═══════════════════════════════════════════
Le seul menu du jeu, en trois niveaux faciles à retenir :

    🎮 Menu principal  →  zone (ex. 💼 Économie)  →  rubrique (ex. 🏦 Banques & prêts)  →  action

• Chaque niveau a ses boutons « ⬅️ Retour » (niveau au-dessus) et « 🎮 Menu principal ».
• Les anciens menus thématiques (`menu_<thème>`, `<module>_menu`, `hub:<zone>:<n>`) ramènent à la
  DERNIÈRE rubrique visitée de la zone : revenir d'une action te remet exactement là où tu étais.

Callbacks : hub:home · hub:<zone> (liste des rubriques) · hs:<zone>:<rubrique>[:<page>] (actions)
            · hubr:<n> (lancer l'action n du catalogue)
"""
from __future__ import annotations

import html
import importlib
import re

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from handlers.hub_data import AREAS, FORM_DESC, FORM_LABEL, HIDDEN, ITEMS, SECTIONS, ZONE_INTRO
from utils.aesthetics import card
from utils.auto_forms import form_key, module_of
from utils.forms import FORMS
from utils.input_flow import call_cmd
from utils.ui import layout

PAGE = 10

# Anciens menus thématiques → zone du menu unique (dérivé de AREAS, donc toujours synchronisé)
ZONE_OF_MENU = {menu[5:]: key for key, _label, menu in AREAS if menu and menu.startswith("menu_")}
ZONE_OF_MENU["missions"] = "progression"   # l'ancien menu Missions vit dans la zone Progression
_FORM_PREFIX = {"entreprises": ("c_",), "societe": ("g_",), "marche": ("m_",)}   # préfixes historiques ; un nouveau module déclare plutôt Form(area="zone")

# Immobilier : actions converties en formulaires (handlers/realestate.py)
_RE_FORMS = {"acheter_bien": "re_buy", "hypotheque": "re_mortgage", "entretenir": "re_maintain",
             "propriete_info": "re_info", "proposer_location": "re_rent_out",
             "quitter_logement": "re_leave", "vendre_bien": "re_sell"}


# Actions du jardin ouvertes directement sur leur écran à boutons (handlers/garden.py)
_GARDEN_SCREENS = {"planter": "show_plant_menu", "arroser": "show_water_menu"}

# Actions d'argent ouvertes directement sur leur écran à boutons (handlers/economy.py + economy_flows.py)
_ECO_SCREENS = {"depot": "show_depot_menu", "retrait": "show_retrait_menu",
                "payer": "show_payer_menu", "don": "show_don_menu"}


# 🎨 Décor : un emoji par action (premier mot-clé trouvé dans l'id ou le libellé), sinon l'emoji de la zone
_ICONS = [
    ("ordre", "🚓"), ("justice", "⚖️"), ("armurerie", "🔫"), ("chambre d'armes", "🔫"), ("armes", "🔫"),
    ("nommer", "🎖️"), ("renvoyer", "🚪"), ("quitter ma faction", "🚪"), ("accepter", "✅"), ("refuser", "❌"),
    ("divorc", "💔"), ("depot ", "📥"), ("retrait ", "🏧"), ("payer ", "💸"), ("don faire", "🎁"),
    ("ambulance", "🚑"), ("hopital", "🏥"), ("medic", "💊"), ("sante", "🩺"), ("assurance", "🛡️"),
    ("dormir", "😴"), ("manger", "🍽️"), ("gym", "🏋️"), ("logement", "🏠"), ("vie", "🧬"),
    ("banque", "🏦"), ("compte", "💳"), ("pret", "🤝"), ("rembours", "💸"), ("impot", "🧾"),
    ("loterie", "🎟️"), ("ticket", "🎫"), ("tirage", "🎰"), ("richesse", "💎"), ("quotidien", "🎁"),
    ("travail", "🛠️"), ("faction", "🎖️"), ("candidat", "📝"), ("competence", "🧠"), ("examen", "📝"),
    ("formation", "🎓"), ("etude", "📚"), ("metier", "💼"), ("promotion", "📈"), ("reviser", "📖"),
    ("bourse", "📊"), ("marche", "🛒"), ("action", "📈"), ("portefeuille", "👜"), ("bien", "🏡"),
    ("propriet", "🏘️"), ("hypotheque", "🏦"), ("location", "🔑"), ("historique", "🕘"),
    ("entreprise", "🏢"), ("contrat", "📑"), ("fusion", "🤝"), ("produit", "📦"), ("audit", "🔍"),
    ("journal", "📔"), ("classement", "🏆"), ("production", "🏭"), ("transfert", "🔄"),
    ("annonce", "📣"), ("objet", "🎒"), ("item", "🎒"), ("cargo", "🚚"), ("offre", "💌"),
    ("vip", "👑"), ("luxe", "💍"), ("prestige", "🌟"), ("vehicule", "🚗"), ("garage", "🚘"),
    ("repair", "🔧"), ("refuel", "⛽"), ("boutique", "🛍️"), ("etoile", "⭐"),
    ("casino", "🎰"), ("blackjack", "🃏"), ("poker", "♠️"), ("roulette", "🎡"), ("slots", "🎰"),
    ("crash", "📉"), ("mines", "💣"), ("pmu", "🐎"), ("parier", "🎲"), ("arene", "⚔️"),
    ("defi", "🥊"), ("jardin", "🌱"), ("planter", "🌱"), ("arroser", "💧"), ("recolter", "🧺"),
    ("voyag", "✈️"), ("destination", "🗺️"), ("timbre", "🛂"), ("evenement", "🎉"), ("event", "🎉"),
    ("social", "🌐"), ("poster", "📝"), ("story", "📸"), ("live", "🔴"), ("tendance", "🔥"),
    ("sondage", "📊"), ("vote", "🗳️"), ("communaute", "👥"), ("abonn", "👤"), ("plateforme", "📲"),
    ("collab", "🤝"), ("partager", "🔁"), ("analytique", "📈"),
    ("mariage", "💍"), ("adopter", "👶"), ("ami", "🤗"), ("famille", "👨‍👩‍👧"), ("clan", "🛡️"),
    ("arbre", "🌳"), ("cadeau", "🎁"), ("echange", "🔀"), ("relation", "💞"), ("salut", "👋"),
    ("crime", "🔫"), ("commettre", "🔫"), ("hack", "💻"), ("noir", "🕶️"), ("defense", "🛡️"),
    ("gang", "🏴‍☠️"), ("caution", "🔓"), ("avocat", "👨‍⚖️"), ("tribunal", "⚖️"),
    ("election", "🗳️"), ("parti", "🎗️"), ("constitution", "📜"), ("loi", "📜"), ("referendum", "🗳️"),
    ("destituer", "🚫"), ("ministre", "🏛️"), ("poste", "🪑"), ("signer", "✍️"),
    ("mission", "🎯"), ("graph", "📉"), ("achievement", "🏆"), ("succes", "🏆"), ("tutorial", "🎓"),
    ("badge", "🏅"), ("shop", "🛍️"), ("location", "📍"), ("lieu", "📍"), ("xp", "✨"),
    ("titre", "👑"), ("notification", "🔔"), ("inventaire", "🎒"), ("karma", "☯️"), ("bio", "✍️"),
    ("stats", "📊"), ("profil", "📜"), ("niveau", "⭐"), ("nouveaute", "🆕"), ("parrainage", "💌"),
    ("about", "ℹ️"), ("aller", "🧭"), ("position", "📍"), ("phone", "📱"), ("status", "💬"), ("report", "🚨"),
]


def _icon(zone_label: str, fn: str, label: str) -> str:
    probe = f"{fn} {label}".lower()
    for kw, emoji in _ICONS:
        if kw in probe:
            return emoji
    return zone_label.split(" ", 1)[0]   # emoji de la zone


def _rubriques(area: str) -> list[tuple[str, list[tuple]]]:
    """Rubriques d'une zone, dans l'ordre : [(titre, [entrées])]. L'index d'une rubrique est stable
    (il sert dans les callbacks `hs:<zone>:<index>`)."""
    groups: list[tuple[str, list[tuple]]] = []
    for it in _area_items(area):
        if groups and groups[-1][0] == it[4]:
            groups[-1][1].append(it)
        else:
            groups.append((it[4], [it]))
    return groups


_LAST: dict[tuple[int, str], int] = {}   # (joueur, zone) → dernière rubrique vue, pour que « Retour » revienne au bon endroit


_SYNC_SIG: tuple | None = None   # (nb formulaires, nb entrées) lors de la dernière synchro


def _sync_back() -> None:
    """Chaque formulaire du hub renvoie, via « Retour », à la rubrique d'où il a été ouvert.

    Le calcul n'est refait que si le nombre de formulaires ou d'entrées du hub a changé."""
    global _SYNC_SIG
    sig = (len(FORMS), len(ITEMS))
    if sig == _SYNC_SIG:
        return
    import dataclasses
    for area, _label, _menu in AREAS:
        for si, (_title, entries) in enumerate(_rubriques(area)):
            for it in entries:
                if it[0] == "form" and it[1] in FORMS:
                    back = f"hs:{area}:{si}"
                    if FORMS[it[1]].back != back:
                        FORMS[it[1]] = dataclasses.replace(FORMS[it[1]], back=back)
    _SYNC_SIG = sig


def _module_of(fn: str) -> str | None:
    mod = module_of(fn)
    return mod.split(".", 1)[1] if mod else None


def _area_items(area: str) -> list[tuple]:
    """Entrées de la zone, classées par rubrique (voir hub_data.SECTIONS) :
    (\"form\"|\"run\", clé ou index, libellé, description, titre de la rubrique)."""
    secs = SECTIONS.get(area, [])
    rank = {fn: (si, pos) for si, (_t, fns) in enumerate(secs) for pos, fn in enumerate(fns)}
    other = (len(secs), 0)
    entries: list[tuple] = []        # (rang, entrée)
    prefix = _FORM_PREFIX.get(area)
    for key, form in FORMS.items():
        if key in HIDDEN:
            continue
        # Un formulaire appartient à la zone s'il le déclare (Form.area) ou, à défaut, par son préfixe historique.
        if form.area == area or (prefix and key.startswith(prefix)):
            entries.append((rank.get(key, other), ("form", key, FORM_LABEL.get(key, form.label), FORM_DESC.get(key, form.label))))
    for idx, (a, fn, _cmd, _argless, _usage, label, desc) in enumerate(ITEMS):
        if a != area:
            continue
        key = _RE_FORMS.get(fn) or form_key(fn)
        if key in HIDDEN:
            continue
        kind, ref = ("form", key) if key in FORMS else ("run", idx)
        entries.append((rank.get(fn, other), (kind, ref, label, desc)))
    entries.sort(key=lambda e: e[0])         # tri stable : l'ordre des rubriques puis celui de la rubrique
    titles = [t for t, _ in secs] + ["📌 Autres"]
    return [e + (titles[r[0]],) for r, e in entries]


# 🌱 MODE DÉBUTANT — au début, seules les zones essentielles sont affichées (5 boutons au lieu de 16),
# avec les 3 premières actions à faire. « Voir toutes les zones » débloque tout ; passé le niveau
# BEGINNER_MAX_LEVEL le menu complet s'affiche tout seul.
BEGINNER_MAX_LEVEL = 5
ESSENTIAL_ZONES = ("vie", "eco", "carriere", "progression", "phone")
_FULL: set[int] = set()          # joueurs ayant demandé le menu complet (mémoire de session)


def _item_idx(fn: str) -> int | None:
    return next((i for i, it in enumerate(ITEMS) if it[1] == fn), None)


async def is_beginner(user_id: int) -> bool:
    if not user_id or user_id in _FULL:
        return False
    try:
        from database import get_user
        u = await get_user(user_id)
        return int(u.get("level", 1) or 1) < BEGINNER_MAX_LEVEL
    except Exception:
        return False


def home_markup(simple: bool = False) -> InlineKeyboardMarkup:
    """Clavier du menu principal unique : une zone = un bouton, plus l'aide.
    simple=True : menu débutant (zones essentielles + premières actions)."""
    rows: list[list[InlineKeyboardButton]] = []
    if simple:
        quick = []
        for fn, lab in (("quotidien", "🎁 Bonus du jour"), ("travailler", "🛠️ Travailler")):
            idx = _item_idx(fn)
            if idx is not None:
                quick.append(InlineKeyboardButton(lab, callback_data=f"hubr:{idx}"))
        tuto = _item_idx("tutorial")
        if tuto is not None:
            quick.append(InlineKeyboardButton("🎓 Tutoriel", callback_data=f"hubr:{tuto}"))
        if quick:
            rows.append(quick)
        zones = [(k, l) for k, l, _ in AREAS if k in ESSENTIAL_ZONES]
    else:
        zones = [(k, l) for k, l, _ in AREAS]
    btns = [InlineKeyboardButton(label, callback_data=f"hub:{key}") for key, label in zones]
    rows += layout(btns)
    rows.insert(0, [InlineKeyboardButton("🧭 Se déplacer dans la ville", callback_data="loc_map")])
    if simple:
        rows.append([InlineKeyboardButton(f"🔓 Voir toutes les zones ({len(AREAS)})", callback_data="hub:all")])
    rows.append([InlineKeyboardButton("📖 Aide & tutoriel", callback_data="help:home")])
    return InlineKeyboardMarkup(rows)


async def home_markup_for(user_id: int) -> InlineKeyboardMarkup:
    return home_markup(simple=await is_beginner(user_id))


def home_text(header: list[str] | None = None, simple: bool = False) -> str:
    body = list(header or [])
    if body:
        body.append("")
    if simple:
        body += ["🌱 <b>Pour bien démarrer, fais dans l'ordre :</b>",
                 "  1️⃣ 🎁 Prends ton <b>bonus du jour</b>",
                 "  2️⃣ 🛠️ <b>Travaille</b> pour gagner de l'argent",
                 "  3️⃣ 🎓 Suis le <b>tutoriel</b> : il te donne des récompenses",
                 "",
                 "🧬 Pense à manger et dormir (zone Vie).",
                 "",
                 "👇 <b>Zones essentielles :</b>"]
        footer = "🌱 Menu simplifié · « Voir toutes les zones » pour tout débloquer"
    else:
        body += ["🌍 Ton monde t'attend : ta vie, ton argent, ta carrière, tes proches, ta ville.",
                 "Chaque zone rassemble une partie de ton histoire ; ouvre-en une pour voir ses rubriques.",
                 "",
                 "👇 <b>Où veux-tu aller ?</b>"]
        footer = "🌟 Earth Angel RP · vis plus fort que la réalité"
    return card("MENU PRINCIPAL", body, footer=footer, icon="🎮", style="double")


async def show_home(query, header: list[str] | None = None) -> None:
    uid = getattr(getattr(query, "from_user", None), "id", 0)
    simple = await is_beginner(uid)
    await query.edit_message_text(home_text(header, simple), parse_mode="HTML", reply_markup=home_markup(simple))


async def open_zone(query, menu_key: str) -> bool:
    """Ouvre la zone qui remplace l'ancien menu `menu_key` (ex. 'life', 'economy') : la dernière rubrique vue
    si elle existe, sinon la liste des rubriques. False si inconnu."""
    zone = ZONE_OF_MENU.get(menu_key)
    if not zone:
        return False
    await show_back_to(query, zone)
    return True


async def show_back_to(query, zone: str) -> None:
    uid = getattr(getattr(query, "from_user", None), "id", 0)
    last = _LAST.get((uid, zone))
    if last is not None and 0 <= last < len(_rubriques(zone)):
        await show_rubrique(query, zone, last, 0)
    else:
        await show_zone(query, zone)


def _zone_label(key: str) -> str:
    return next((label for k, label, _m in AREAS if k == key), key)


# B5 : consoles réservées au staff : jamais affichées aux joueurs
_STAFF_ONLY = {"controle", "entretien_chef"}


def _fn_of(it: tuple) -> str:
    return it[1] if it[0] == "form" else ITEMS[it[1]][1]


async def _visible(key: str, uid: int) -> list[tuple[int, str, list[tuple]]]:
    """Rubriques affichées au joueur : (index stable, titre, entrées). Une rubrique vide est cachée."""
    from utils.decorators import get_user_role_async
    is_staff = bool(uid) and (await get_user_role_async(uid)) != "PLAYER"
    out = []
    for si, (title, entries) in enumerate(_rubriques(key)):
        if uid and not is_staff:
            entries = [it for it in entries if _fn_of(it) not in _STAFF_ONLY]
        if key == "marche" and uid:      # « Vendre un objet » : visible uniquement pour les commerçants
            from handlers.market import is_merchant
            if not await is_merchant(uid):
                entries = [it for it in entries
                           if (it[1] if it[0] == "form" else ITEMS[it[1]][1]) not in ("a_sellitem", "sellitem")]
        if entries:
            out.append((si, title, entries))
    return out


def _entry_line(label: str, it: tuple) -> tuple[str, str, str]:
    if it[0] == "form":
        fn_id, lab, desc, data = it[1], it[2], it[3], f"fm:{it[1]}"
    else:
        fn_id, lab, desc, data = ITEMS[it[1]][1], it[2], it[3], f"hubr:{it[1]}"
    ico = _icon(label, fn_id, lab)
    line = f"{ico} <b>{html.escape(lab)}</b>\n      <i>{html.escape(desc)}</i>"
    return line, f"{ico} {lab}", data


async def show_zone(query, key: str) -> None:
    """Niveau 2 : la liste des rubriques d'une zone."""
    areas = {k: (label, menu) for k, label, menu in AREAS}
    if key not in areas:
        await show_home(query)
        return
    label = areas[key][0]
    _sync_back()
    uid = getattr(getattr(query, "from_user", None), "id", 0)
    rubs = await _visible(key, uid)
    if len(rubs) == 1:                        # une seule rubrique : on va directement aux actions
        await show_rubrique(query, key, rubs[0][0], 0)
        return
    title = label.split(" ", 1)[1] if " " in label else label
    lines = [f"<i>{html.escape(ZONE_INTRO.get(key, ''))}</i>", ""] if ZONE_INTRO.get(key) else []
    rows: list[list[InlineKeyboardButton]] = []
    total = 0
    for si, rtitle, entries in rubs:
        total += len(entries)
        sample = ", ".join(re.sub(r"^\W+\s*", "", e[2]) for e in entries[:3])
        lines.append(f"<b>{html.escape(rtitle)}</b>  ·  {len(entries)}\n      <i>{html.escape(sample)}{'…' if len(entries) > 3 else ''}</i>")
        rows.append([InlineKeyboardButton(f"{rtitle}  ({len(entries)})"[:40], callback_data=f"hs:{key}:{si}")])
    rows.append([InlineKeyboardButton("⬅️ Retour au menu", callback_data="hub:home")])
    text = card(title.upper(), lines, footer=f"{len(rubs)} rubriques  ·  {total} actions",
                icon=label.split(" ", 1)[0], style="round")
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(rows))


async def show_rubrique(query, key: str, si: int, page: int = 0) -> None:
    """Niveau 3 : les actions d'une rubrique (avec leur description)."""
    areas = {k: label for k, label, _menu in AREAS}
    if key not in areas:
        await show_home(query)
        return
    label = areas[key]
    _sync_back()
    uid = getattr(getattr(query, "from_user", None), "id", 0)
    rubs = await _visible(key, uid)
    cur = next((r for r in rubs if r[0] == si), None)
    if cur is None:
        await show_zone(query, key)
        return
    _si, rtitle, entries = cur
    pages = max(1, -(-len(entries) // PAGE))
    page = max(0, min(page, pages - 1))
    chunk = entries[page * PAGE:(page + 1) * PAGE]
    _LAST[(uid, key)] = si
    lines: list[str] = []
    btns: list[InlineKeyboardButton] = []
    for it in chunk:
        line, text_btn, data = _entry_line(label, it)
        lines.append(line)
        btns.append(InlineKeyboardButton(text_btn, callback_data=data))
    rows = layout(btns)
    if pages > 1:
        nav = []
        if page > 0:
            nav.append(InlineKeyboardButton("◀️ Préc.", callback_data=f"hs:{key}:{si}:{page - 1}"))
        nav.append(InlineKeyboardButton(f"{page + 1}/{pages}", callback_data=f"hs:{key}:{si}:{page}"))
        if page < pages - 1:
            nav.append(InlineKeyboardButton("Suiv. ▶️", callback_data=f"hs:{key}:{si}:{page + 1}"))
        rows.append(nav)
    if len(rubs) > 1:
        zone_name = label.split(" ", 1)[1] if " " in label else label
        rows.append([InlineKeyboardButton(f"⬅️ {zone_name}"[:32], callback_data=f"hub:{key}"),
                     InlineKeyboardButton("🎮 Menu principal", callback_data="hub:home")])
    else:
        rows.append([InlineKeyboardButton("⬅️ Retour au menu", callback_data="hub:home")])
    rtitle_clean = rtitle.split(" ", 1)[1] if " " in rtitle else rtitle
    text = card(rtitle_clean.upper(), lines, footer=f"{label}  ·  {len(entries)} action{'s' if len(entries) > 1 else ''}",
                icon=rtitle.split(" ", 1)[0], style="round")
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(rows))


async def show_area(query, key: str, page: int = 0) -> None:
    """Compatibilité : ancienne entrée « zone + page » → dernière rubrique vue, sinon liste des rubriques."""
    await show_back_to(query, key)


async def run_item(query, context, idx: int) -> None:
    try:
        _a, fn, _cmd, _argless, _u, _l, _d = ITEMS[idx]
    except IndexError:
        await query.answer("Action introuvable", show_alert=True)
        return
    garden = _GARDEN_SCREENS.get(fn)           # planter / arroser : boutons du jardin, rien à taper
    if garden:
        from handlers import garden as _g
        await getattr(_g, garden)(query, query.from_user.id)
        return
    eco = _ECO_SCREENS.get(fn)                 # dépôt / retrait / payer / don : montants en boutons
    if eco:
        from handlers import economy as _e
        await getattr(_e, eco)(query, query.from_user.id)
        return
    mod = _module_of(fn)
    if not mod:
        await query.answer("Action indisponible pour le moment.", show_alert=True)
        return
    cmd = getattr(importlib.import_module(f"handlers.{mod}"), f"cmd_{fn}")
    await call_cmd(query, context, cmd, [])


async def hub_callback(update, context) -> None:
    q = update.callback_query
    await q.answer()
    from utils.character import gate as _character_gate
    if await _character_gate(update, q.from_user.id):
        return
    parts = q.data.split(":")
    if parts[0] == "hub" and len(parts) == 2 and parts[1] in ("all", "simple"):
        if parts[1] == "all":
            _FULL.add(q.from_user.id)
        else:
            _FULL.discard(q.from_user.id)
        await show_home(q)
        return
    if parts[0] == "hubr":
        await run_item(q, context, int(parts[1]))
    elif parts[0] == "hs" and len(parts) >= 3 and parts[2].isdigit():
        await show_rubrique(q, parts[1], int(parts[2]), int(parts[3]) if len(parts) > 3 and parts[3].isdigit() else 0)
    elif len(parts) == 2 and parts[1] != "home":
        await show_zone(q, parts[1])                   # hub:<zone> → liste des rubriques
    elif len(parts) > 2:
        await show_back_to(q, parts[1])                # ancien hub:<zone>:<page> → dernière rubrique vue
    else:
        await show_home(q)


_FORM_BY_CMD: dict[str, str] = {}
_NOT_TYPABLE = {"unknown_command", "garage_select", "garage_repair", "garage_refuel"}   # réservées aux boutons


def _form_for_command(name: str) -> str | None:
    """Clé du formulaire qui appelle `cmd_<name>` (toutes les familles : entreprises, gangs, factions…)."""
    if not _FORM_BY_CMD:
        _FORM_BY_CMD.clear()
        for key, form in FORMS.items():
            fn = form.cmd.rsplit(":", 1)[-1]
            if fn.startswith("cmd_"):
                _FORM_BY_CMD.setdefault(fn[4:], key)
    return _FORM_BY_CMD.get(name)


async def run_typed_command(update, context, name: str) -> bool:
    """Commande tapée (/xxx) sans handler dédié : ouvre l'action du jeu qui porte ce nom.
    Ordre : formulaire à boutons (si l'action demande une saisie) → écran du menu → fonction directe.
    False si aucune action ne correspond."""
    name = (name or "").lower().lstrip("/")
    fn = name
    key = form_key(fn)
    if key not in FORMS:
        key = _form_for_command(fn) or key
    if key in FORMS:
        from utils.forms import start_form
        await start_form(update, context, key)
        return True
    if fn in _GARDEN_SCREENS or fn in _ECO_SCREENS:
        zone = next((a for a, f, *_ in ITEMS if f == fn), None)
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🎮 Ouvrir le menu", callback_data=f"hub:{zone or 'home'}:0")]])
        await update.effective_message.reply_text("👇 Retrouve cette action dans le 🎮 Menu principal.", reply_markup=kb)
        return True
    if fn in _NOT_TYPABLE:
        return False
    mod = _module_of(fn)                       # fonction cmd_<fn> d'un module joueur (menu ou non)
    if mod:
        cmd = getattr(importlib.import_module(f"handlers.{mod}"), f"cmd_{fn}", None)
        if cmd:
            await call_cmd(update, context, cmd, list(getattr(context, "args", None) or []))
            return True
    return False
