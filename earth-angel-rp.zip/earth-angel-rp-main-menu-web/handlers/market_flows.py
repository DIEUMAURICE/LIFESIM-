"""
handlers/market_flows.py — Mise en vente d'un objet par boutons
(remplace /sellitem : choix de l'objet → prix → quantité)
"""
from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from database import db_connection
from utils.helpers import escape_html, fmt
from utils.forms import Form, P, provider, register
from utils.input_flow import ask, call_cmd, flow

BACK = "market_menu"


async def show_sell_picker(query, user_id: int) -> None:
    async with db_connection() as db:
        async with db.execute(
            "SELECT item_id, item_name, quantity FROM inventory "
            "WHERE user_id=? AND quantity>0 ORDER BY item_name LIMIT 40",
            (user_id,),
        ) as cur:
            items = await cur.fetchall()
    back = [[InlineKeyboardButton("⬅️ Retour", callback_data=BACK)]]
    if not items:
        await query.edit_message_text(
            "📦 Ton inventaire est vide : rien à vendre pour l'instant.",
            reply_markup=InlineKeyboardMarkup(back))
        return
    rows = [[InlineKeyboardButton(f"{(name or 'Objet')[:28]} ×{qty}",
                                  callback_data=f"market_sellpick_{iid}")]
            for iid, name, qty in items]
    await query.edit_message_text(
        "💸 <b>METTRE EN VENTE</b>\n\nChoisis l'objet à vendre :",
        parse_mode="HTML", reply_markup=InlineKeyboardMarkup(rows + back))


async def start_sell(query, context, item_id: int) -> None:
    async with db_connection() as db:
        async with db.execute(
            "SELECT item_name, quantity FROM inventory WHERE user_id=? AND item_id=?",
            (query.from_user.id, item_id),
        ) as cur:
            row = await cur.fetchone()
    if not row or row[1] <= 0:
        await query.edit_message_text(
            "❌ Tu ne possèdes plus cet objet.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data=BACK)]]))
        return
    name, owned = row
    await ask(
        query, context, "market_sell_price",
        f"💸 <b>{escape_html(name or 'Objet')}</b> (tu en as {owned})\n\n"
        f"Envoie le <b>prix unitaire</b> (ex : <code>10000</code>, <code>2k</code>).",
        kind="amount", min_value=1, data={"item_id": item_id, "name": name, "owned": owned},
        back="market_sell_info",
    )


@flow("market_sell_price")
async def _price(update, context, value, data):
    await ask(
        update, context, "market_sell_qty",
        f"💸 <b>{escape_html(data['name'] or 'Objet')}</b> à {fmt(value)} l'unité\n\n"
        f"Combien d'exemplaires mettre en vente ? (1 à {data['owned']})",
        kind="int", min_value=1, max_value=data["owned"],
        data={**data, "price": value}, back="market_sell_info",
    )


@flow("market_sell_qty")
async def _qty(update, context, value, data):
    from handlers.market import cmd_sellitem
    await call_cmd(update, context, cmd_sellitem,
                   [str(data["item_id"]), str(data["price"]), str(value)])


# ── Vendre à un commerçant (civil) : tout en boutons ────────────────
@provider("merchants")
async def _merchants(uid):
    async with db_connection() as db:
        async with db.execute(
                "SELECT user_id, COALESCE(full_name,'Joueur') FROM users WHERE job='Commerçant' AND registered=1 "
                "AND user_id!=? ORDER BY full_name LIMIT 20", (uid,)) as cur:
            return [(f"🛍️ {n}", str(i)) for i, n in await cur.fetchall()]


@provider("my_items")
async def _my_items(uid):
    async with db_connection() as db:
        async with db.execute(
                "SELECT item_id, COALESCE(item_name,'Objet'), quantity FROM inventory "
                "WHERE user_id=? AND quantity>0 ORDER BY item_name LIMIT 30", (uid,)) as cur:
            return [(f"{n[:28]} ×{q}", str(i)) for i, n, q in await cur.fetchall()]


register(
    Form("m_vendre", "🛍️ Vendre à un commerçant", "handlers.market:cmd_vendre_commercant",
         (P("merchant", "choice", "À quel commerçant proposer ton objet ?", choices="merchants"),
          P("item", "choice", "Quel objet vends-tu ?", choices="my_items"),
          P("price", "amount", "Prix <b>unitaire</b> demandé (ex : <code>2k</code>) ?", min=1),
          P("qty", "int", "Combien d'exemplaires ?", min=1)),
         (), back="market_menu"),
)
