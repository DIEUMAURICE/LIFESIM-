"""
handlers/economy_flows.py — Paiement, don, dépôt, retrait par boutons
═══════════════════════════════════════════════════════════════════════
Remplace /payer, /don, /depot, /retrait et les anciens drapeaux
`awaiting_*` de bot.handle_economy_input. Parcours :

    bouton → montant (saisi ou raccourci) → cible (@pseudo / ID / banque) → action
"""
from __future__ import annotations

from utils.swallow import swallowed
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from database import get_user, transfer_money, increment_field, add_life_journal
from handlers.missions import update_mission_progress
from handlers.multiplayer import _bump_relation
from utils.helpers import fmt
from utils.input_flow import ask, call_cmd, flow

BACK = "eco_retour"

TAX_PAY_THRESHOLD = 100_000
TAX_DON_THRESHOLD = 50_000


# ═══════════════════════════════════════════════════════════════════
#   POINTS D'ENTRÉE (appelés par economy_callback)
# ═══════════════════════════════════════════════════════════════════
async def start_amount(query, context, prefix: str, balance: int | None = None) -> None:
    """Bouton « Autre montant » : demande un nombre libre."""
    titres = {"payer": "💸 Paiement", "don": "🎁 Don",
              "depot": "🏦 Dépôt", "retrait": "🏧 Retrait"}
    await ask(
        query, context, f"{prefix}_montant",
        f"<b>{titres[prefix]}</b>\n\nEnvoie le <b>montant</b> (ex : <code>5000</code>, "
        f"<code>2k</code>, <code>50%</code>, <code>tout</code>).",
        kind="amount", min_value=1, balance=balance, back=BACK,
    )


async def start_target(query, context, prefix: str, amount: int) -> None:
    """Bouton montant rapide : passe directement à la 2ᵉ étape."""
    await _ask_second_step(query, context, prefix, amount)


async def _ask_second_step(target, context, prefix: str, amount: int) -> None:
    if prefix in ("payer", "don"):
        qui = "destinataire" if prefix == "payer" else "bénéficiaire"
        await ask(
            target, context, f"{prefix}_cible",
            f"<b>{'💸 Paiement' if prefix == 'payer' else '🎁 Don'} de {fmt(amount)}</b>\n\n"
            f"Envoie le <b>@pseudo</b> ou l'<b>ID</b> du {qui}.",
            kind="user", data={"amount": amount}, back=BACK,
        )
    else:
        titre = "🏦 Dépôt" if prefix == "depot" else "🏧 Retrait"
        await ask(
            target, context, f"{prefix}_banque",
            f"<b>{titre} de {fmt(amount)}</b>\n\nEnvoie le <b>nom de la banque</b>.",
            kind="text", data={"amount": amount}, back=BACK,
        )


# ═══════════════════════════════════════════════════════════════════
#   ÉTAPE 1 — le montant est saisi → on demande la cible
# ═══════════════════════════════════════════════════════════════════
def _register_amount_flow(prefix: str) -> None:
    @flow(f"{prefix}_montant")
    async def _handler(update, context, value, data):
        await _ask_second_step(update, context, prefix, value)


for _p in ("payer", "don", "depot", "retrait"):
    _register_amount_flow(_p)


# ═══════════════════════════════════════════════════════════════════
#   ÉTAPE 2 — PAIEMENT / DON
# ═══════════════════════════════════════════════════════════════════
async def _check_transfer(update, amount: int, target_id: int):
    """Contrôles communs. Retourne (sender, target_user) ou None (message déjà envoyé)."""
    msg = update.effective_message
    uid = update.effective_user.id
    if target_id == uid:
        await msg.reply_text("❌ Tu ne peux pas t'envoyer de l'argent à toi-même.")
        return None
    sender = await get_user(uid)
    if sender["balance"] < amount:
        await msg.reply_text(f"❌ Fonds insuffisants. Solde : {fmt(sender['balance'])}")
        return None
    target_user = await get_user(target_id)
    if not target_user or not target_user.get("registered"):
        await msg.reply_text("❌ Ce joueur n'est pas enregistré.")
        return None
    return sender, target_user


def _done_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data=BACK)]])


@flow("payer_cible")
async def _payer_cible(update, context, value, data):
    target_id, _name = value
    amount = data["amount"]
    checked = await _check_transfer(update, amount, target_id)
    if not checked:
        return
    sender, target_user = checked
    uid = update.effective_user.id
    tax = int(amount * 0.01) if amount > TAX_PAY_THRESHOLD else 0
    if not await transfer_money(uid, target_id, amount, tax=tax):
        await update.effective_message.reply_text("❌ Erreur lors du transfert.")
        return
    await update_mission_progress(uid, "pay", 1)
    if amount >= TAX_PAY_THRESHOLD:
        await increment_field(uid, "karma", 1)
    if tax:
        await add_life_journal(uid, "taxe",
                               f"Taxe de 1% sur transfert de {fmt(amount)} : {fmt(tax)} prélevé.",
                               severity="warning")
    taxe_ligne = f"💸 Taxe (1%) : -{fmt(tax)}\n" if tax else ""
    await update.effective_message.reply_text(
        f"💸 <b>Paiement réussi !</b>\n\n👤 À : {target_user['full_name']}\n"
        f"💰 Montant : {fmt(amount)}\n{taxe_ligne}"
        f"💵 Ton solde : {fmt(sender['balance'] - amount)}",
        parse_mode="HTML", reply_markup=_done_keyboard(),
    )
    try:
        await context.bot.send_message(
            target_id,
            f"💸 <b>Tu as reçu un paiement !</b>\n\nDe : {sender['full_name']}\n"
            f"💰 Montant : {fmt(amount - tax)}", parse_mode="HTML")
    except Exception:
        swallowed('handlers/economy_flows.py')


@flow("don_cible")
async def _don_cible(update, context, value, data):
    target_id, _name = value
    amount = data["amount"]
    checked = await _check_transfer(update, amount, target_id)
    if not checked:
        return
    sender, target_user = checked
    uid = update.effective_user.id
    tax = int(amount * 0.01) if amount > TAX_DON_THRESHOLD else 0
    after_tax = amount - tax
    if not await transfer_money(uid, target_id, amount, tax=tax):
        await update.effective_message.reply_text("❌ Erreur lors du transfert.")
        return
    karma_gain = min(50, max(1, after_tax // 5_000))
    await increment_field(uid, "karma", karma_gain)
    await increment_field(uid, "charity_given", amount)
    await _bump_relation(uid, target_id, 5, "bienfaiteur")
    await update.effective_message.reply_text(
        f"🎁 <b>Don effectué !</b>\n\n👤 À : {target_user['full_name']}\n"
        f"💰 Montant : {fmt(amount)}\n🌟 Karma gagné : +{karma_gain}",
        parse_mode="HTML", reply_markup=_done_keyboard(),
    )
    try:
        await context.bot.send_message(
            target_id,
            f"🎁 <b>Tu as reçu un don !</b>\n\nDe : {sender['full_name']}\n"
            f"💰 Montant : {fmt(after_tax)}", parse_mode="HTML")
    except Exception:
        swallowed('handlers/economy_flows.py')


# ═══════════════════════════════════════════════════════════════════
#   ÉTAPE 2 — DÉPÔT / RETRAIT (la logique reste dans handlers.bank)
# ═══════════════════════════════════════════════════════════════════
@flow("depot_banque")
async def _depot_banque(update, context, value, data):
    from handlers.bank import cmd_depot
    await call_cmd(update, context, cmd_depot, [str(data["amount"]), value])


@flow("retrait_banque")
async def _retrait_banque(update, context, value, data):
    from handlers.bank import cmd_retrait
    await call_cmd(update, context, cmd_retrait, [str(data["amount"]), value])
