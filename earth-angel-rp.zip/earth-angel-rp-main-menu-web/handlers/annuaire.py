# handlers/annuaire.py — 🗺️ Annuaire : entreprises, gangs, communautés, factions (préfixe `an:`)
"""
Une seule vitrine, décorée et structurée, pour trouver où aller :
  🏢 Entreprises · 🏴‍☠️ Gangs · 👥 Communautés · 🎖️ Factions
Chaque liste se trie (taille, réputation, trésorerie, récent), se feuillette par pages et s'ouvre en fiche détaillée
avec le bouton pour rejoindre. Les mêmes écrans servent à toutes les listes : un seul code, aucun doublon.
"""
import html
import logging

import aiosqlite
from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M, Update
from telegram.ext import ContextTypes

from config import GOV_FACTIONS
from config_chain import stage_emoji, stage_name
from database import db_connection, get_user, now
from utils.aesthetics import card
from utils.decorators import require_registered
from utils.helpers import fmt
from utils.ui import esc, layout

logger = logging.getLogger(__name__)
CB = "an:"
PAGE = 5
NUM = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"]
MEDAL = ["🥇", "🥈", "🥉"]
NEW_AFTER = 3 * 86400                         # « 🆕 » pendant 3 jours de jeu

TABS = {
    "co": ("🏢", "Entreprises"), "ga": ("🏴‍☠️", "Gangs"), "cm": ("👥", "Communautés"),
    "fa": ("🎖️", "Factions"),
}
# onglet → {clé de tri: (libellé, ORDER BY)}
SORTS = {
    "co": {"t": ("👥 Taille", "members DESC, c.reputation DESC"), "r": ("⭐ Réputation", "c.reputation DESC, members DESC"),
           "c": ("💰 Caisse", "c.treasury DESC"), "n": ("🆕 Récentes", "c.created_at DESC")},
    "ga": {"p": ("🔥 Puissance", "g.reputation DESC, members DESC"), "t": ("👥 Membres", "members DESC, g.reputation DESC"),
           "c": ("💰 Caisse", "g.treasury DESC"), "n": ("🆕 Récents", "g.created_at DESC")},
    "cm": {"t": ("👥 Membres", "members DESC"), "n": ("🆕 Récentes", "c.created_at DESC")},
    "fa": {"t": ("👥 Effectif", "")},
}


async def _send(update: Update, text: str, markup: M) -> None:
    q = update.callback_query
    if q:
        try:
            await q.edit_message_text(text[:4000], parse_mode="HTML", reply_markup=markup)
            return
        except Exception:
            await q.message.reply_text(text[:4000], parse_mode="HTML", reply_markup=markup)
            return
    await update.effective_message.reply_text(text[:4000], parse_mode="HTML", reply_markup=markup)


def _e(s) -> str:
    return esc(str(s), quote=False)


def _bar(value: int, total: int = 100, width: int = 5) -> str:
    full = round(max(0, min(value, total)) / total * width) if total else 0
    return "█" * full + "░" * (width - full)


def _icon(rank: int) -> str:
    return MEDAL[rank] if rank < 3 else NUM[rank % PAGE] if rank < 5 else f"{rank + 1}."


async def _uname(uid: int) -> str:
    u = await get_user(uid)
    return u.get("full_name") or (("@" + u["username"]) if u.get("username") else str(uid))


# ─────────────────────────────────────────────────────────────────────────────
#  Données
# ─────────────────────────────────────────────────────────────────────────────
async def _rows(tab: str, sort: str) -> list[dict]:
    order = SORTS[tab].get(sort, next(iter(SORTS[tab].values())))[1]
    async with db_connection(row_factory=aiosqlite.Row) as db:
        if tab == "co":
            sql = ("SELECT c.company_id AS id, c.name, c.sector, c.reputation, c.level, c.treasury, c.created_at, c.owner_id, "
                   "(SELECT COUNT(*) FROM company_members m WHERE m.company_id=c.company_id) AS members "
                   f"FROM companies c WHERE c.dissolved=0 ORDER BY {order}")
        elif tab == "ga":
            sql = ("SELECT g.gang_id AS id, g.name, g.reputation, g.treasury, g.created_at, g.founder_id, "
                   "(SELECT COUNT(*) FROM gang_members m WHERE m.gang_id=g.gang_id) AS members "
                   f"FROM gangs g ORDER BY {order}")
        elif tab == "cm":
            sql = ("SELECT c.community_id AS id, c.name, c.owner_id, c.created_at, "
                   "(SELECT COUNT(*) FROM social_community_members m WHERE m.community_id=c.community_id) AS members "
                   f"FROM social_communities c WHERE c.disbanded=0 ORDER BY {order}")
        else:
            async with db.execute("SELECT faction, COUNT(*) AS n FROM faction_members GROUP BY faction") as cur:
                counts = {r["faction"]: r["n"] for r in await cur.fetchall()}
            rows = [{"id": k, "name": f["name"], "emoji": f["emoji"], "members": counts.get(k, 0)} for k, f in GOV_FACTIONS.items()]
            return sorted(rows, key=lambda r: -r["members"])
        async with db.execute(sql) as cur:
            return [dict(r) for r in await cur.fetchall()]


def _is_new(row: dict) -> str:
    return " 🆕" if row.get("created_at") and now() - int(row["created_at"]) < NEW_AFTER else ""


async def _entry(tab: str, r: dict) -> list[str]:
    if tab == "co":
        return [f"<b>{_e(r['name'])}</b>{_is_new(r)}",
                f"   {stage_emoji(r['level'])} {_e(r['sector'])} · {_e(stage_name(r['level']))}",
                f"   👥 {r['members']} · ⭐ {_bar(r['reputation'])} {r['reputation']} · 💰 {fmt(r['treasury'])}"]
    if tab == "ga":
        return [f"<b>{_e(r['name'])}</b>{_is_new(r)}",
                f"   🔥 Puissance {r['reputation']} · 👥 {r['members']} membre(s)",
                f"   💰 {fmt(r['treasury'])} · 👑 {_e(await _uname(r['founder_id']))}"]
    if tab == "cm":
        return [f"<b>{_e(r['name'])}</b>{_is_new(r)}",
                f"   👥 {r['members']} membre(s) · 👑 {_e(await _uname(r['owner_id']))}"]
    return [f"{r['emoji']} <b>{_e(r['name'])}</b>", f"   👥 {r['members']} membre(s)"]


# ─────────────────────────────────────────────────────────────────────────────
#  Liste
# ─────────────────────────────────────────────────────────────────────────────
async def show_list(update: Update, tab: str, sort: str = "", page: int = 0) -> None:
    if tab not in TABS:
        tab = "co"
    sorts = SORTS[tab]
    sort = sort if sort in sorts else next(iter(sorts))
    rows = await _rows(tab, sort)
    pages = max(1, -(-len(rows) // PAGE))
    page = max(0, min(page, pages - 1))
    chunk = rows[page * PAGE:(page + 1) * PAGE]
    icon, name = TABS[tab]
    lines: list[str] = []
    btns: list = []
    for i, r in enumerate(chunk):
        rank = page * PAGE + i
        mark = MEDAL[rank] if rank < 3 else (NUM[i] if i < len(NUM) else f"{rank + 1}.")
        entry = await _entry(tab, r)
        lines.append(f"{mark} {entry[0]}\n" + "\n".join(entry[1:]))
        btns.append(B(f"{mark} {r['name']}"[:30], callback_data=f"{CB}d:{tab}:{r['id']}:{sort}:{page}"))
    if not rows:
        lines.append("Rien à afficher pour le moment : sois le premier à en créer une !")
    sort_label = sorts[sort][0]
    footer = f"{len(rows)} au total · tri : {sort_label}" + (f" · page {page + 1}/{pages}" if pages > 1 else "")
    text = card(f"ANNUAIRE · {name.upper()}", lines, footer=footer, icon=icon, style="round")
    kb = []
    kb += layout([B(f"{i} {n}" + (" ✔" if k == tab else ""), callback_data=f"{CB}l:{k}::0") for k, (i, n) in TABS.items()], per_row=3)
    if len(sorts) > 1:
        kb.append([B(("• " if k == sort else "") + lab, callback_data=f"{CB}l:{tab}:{k}:0") for k, (lab, _o) in sorts.items()][:4])
    kb += [[b] for b in btns]
    if pages > 1:
        nav = []
        if page > 0:
            nav.append(B("◀️", callback_data=f"{CB}l:{tab}:{sort}:{page - 1}"))
        nav.append(B(f"{page + 1}/{pages}", callback_data=f"{CB}l:{tab}:{sort}:{page}"))
        if page < pages - 1:
            nav.append(B("▶️", callback_data=f"{CB}l:{tab}:{sort}:{page + 1}"))
        kb.append(nav)
    kb.append([B("🎮 Menu principal", callback_data="hub:home")])
    await _send(update, text, M(kb))


# ─────────────────────────────────────────────────────────────────────────────
#  Fiche détaillée
# ─────────────────────────────────────────────────────────────────────────────
def _hub(fn: str, zone: str) -> str:
    from handlers.phone import _hub_cb
    return _hub_cb(fn, zone)


async def show_detail(update: Update, tab: str, ident: str, sort: str, page: int) -> None:
    rows = await _rows(tab, sort)
    r = next((x for x in rows if str(x["id"]) == str(ident)), None)
    back = f"{CB}l:{tab}:{sort}:{page}"
    if not r:
        await show_list(update, tab, sort, page)
        return
    icon, tab_name = TABS[tab]
    lines: list[str] = []
    action: list = []
    async with db_connection() as db:
        async def many(sql, params=()):
            async with db.execute(sql, params) as cur:
                return await cur.fetchall()
        if tab == "co":
            roles = await many("SELECT poste, COUNT(*) FROM company_members WHERE company_id=? GROUP BY poste ORDER BY 2 DESC", (r["id"],))
            lines = [f"{stage_emoji(r['level'])} <b>{_e(stage_name(r['level']))}</b> · {_e(r['sector'])}",
                     f"👑 Patron : <b>{_e(await _uname(r['owner_id']))}</b>", "",
                     f"⭐ Réputation  {_bar(r['reputation'])} <b>{r['reputation']}/100</b>",
                     f"💰 Trésorerie  <b>{fmt(r['treasury'])}</b>", f"👥 Équipe  <b>{r['members']}</b> membre(s)"]
            lines += [f"   • {_e(p)} × {n}" for p, n in roles[:5]]
            action = [B("📨 Postuler", callback_data="fm:c_postuler")]
        elif tab == "ga":
            roles = await many("SELECT role, COUNT(*) FROM gang_members WHERE gang_id=? GROUP BY role ORDER BY 2 DESC", (r["id"],))
            lines = [f"👑 Fondateur : <b>{_e(await _uname(r['founder_id']))}</b>", "",
                     f"🔥 Puissance  <b>{r['reputation']}</b>", f"💰 Caisse  <b>{fmt(r['treasury'])}</b>",
                     f"👥 Membres  <b>{r['members']}</b>"]
            lines += [f"   • {_e(p)} × {n}" for p, n in roles[:5]]
            action = [B("🤝 Rejoindre", callback_data="fm:g_rejoindre")]
        elif tab == "cm":
            from handlers.reseau import slug
            tag = slug(r["name"])
            posts = (await many("SELECT COUNT(*) FROM rp_hashtags WHERE tag=?", (tag,)))[0][0]
            polls = (await many("SELECT COUNT(*) FROM social_polls WHERE community_id=? AND active=1", (r["id"],)))[0][0]
            lines = [f"👑 Chef : <b>{_e(await _uname(r['owner_id']))}</b>", "", f"👥 Membres  <b>{r['members']}</b>",
                     f"#️⃣ Hashtag officiel  <b>#{_e(tag)}</b>", f"📝 Publications  <b>{posts}</b> · 🗳️ Sondages en cours  <b>{polls}</b>"]
            action = [B("🔑 Rejoindre", callback_data=_hub("rejoindre_communaute", "social")),
                      B("📰 Voir le fil", callback_data=f"rs:feed:#{tag}:0")]
        else:
            from utils.factions import coffre_balance
            f = GOV_FACTIONS[r["id"]]
            head = await many("SELECT user_id, rank FROM faction_members WHERE faction=? ORDER BY rank DESC LIMIT 1", (r["id"],))
            ranks = f.get("ranks", [])
            lines = [f"{f['emoji']} <b>{_e(f['name'])}</b>", ""]
            if head:
                title = ranks[head[0][1]][0] if head[0][1] < len(ranks) else "Dirigeant"
                lines.append(f"👑 {_e(title)} : <b>{_e(await _uname(head[0][0]))}</b>")
            lines += [f"👥 Effectif  <b>{r['members']}</b>", f"🏦 Coffre  <b>{fmt(await coffre_balance(r['id']))}</b>",
                      f"💼 Budget quotidien  <b>{fmt(f.get('daily_budget', 0))}</b>"]
            if ranks:
                lines += ["", "<b>Grades</b> : " + " › ".join(_e(x[0]) for x in ranks[:7])]
            action = [B("🎖️ Postuler", callback_data=_hub("faction_postuler", "etat"))]
    kb = [action, [B("⬅️ Annuaire", callback_data=back), B("🎮 Menu principal", callback_data="hub:home")]]
    text = card(_e(r["name"]).upper(), lines, footer=f"{tab_name[:-1] if tab_name.endswith('s') else tab_name}",
                icon=icon, style="round")
    await _send(update, text, M(kb))


# ─────────────────────────────────────────────────────────────────────────────
#  Entrées
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_annuaire_entreprises(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_list(update, "co")


@require_registered
async def cmd_annuaire_gangs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_list(update, "ga")


@require_registered
async def cmd_annuaire_communautes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_list(update, "cm")


@require_registered
async def cmd_annuaire_factions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_list(update, "fa")


async def an_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    p = (q.data or "").split(":")
    p += [""] * 6
    try:
        await q.answer()
        if p[1] == "d" and p[2] in TABS:
            await show_detail(update, p[2], p[3], p[4], int(p[5]) if p[5].isdigit() else 0)
        else:
            await show_list(update, p[2] or "co", p[3], int(p[4]) if p[4].isdigit() else 0)
    except Exception:
        logger.exception("Annuaire : erreur sur %s", q.data)
