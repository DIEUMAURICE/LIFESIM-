from utils.swallow import swallowed
import asyncio
"""
handlers/multiplayer.py — LIFESIM ULTRA V2  ◀ NOUVEAU MODULE
═══════════════════════════════════════════════════════════════════════
Système multijoueur complet :
  • /cadeau @user montant  ─ Offrir un cadeau (boost relation)
  • /don @user montant     ─ Charity (boost karma)
  • /echange @user         ─ Échange sécurisé inter-joueur
  • /troc @user offre→demande ─ Troc d'items
  • /salutations @user     ─ Interaction sociale
  • /relations             ─ Vue des relations
  • /classements           ─ Top 10 dans plusieurs catégories
  • /tradeaccept / /tradedecline ─ Réponse aux échanges
"""
import aiosqlite
import random
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from database import DeferredReply, DB_PATH, get_user, update_field, db_connection
from utils.decorators import require_registered, require_free
from utils.helpers import fmt, parse_amount, now, escape_html
from utils.aesthetics import card, alert



async def init_mp_tables():
    async with db_connection() as db:
        # Échanges en cours
        await db.execute("""
        CREATE TABLE IF NOT EXISTS mp_trades (
            trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_id INTEGER, to_id INTEGER,
            offer_money INTEGER DEFAULT 0,
            request_money INTEGER DEFAULT 0,
            offer_items TEXT DEFAULT '',
            request_items TEXT DEFAULT '',
            status TEXT DEFAULT 'pending',
            created_at INTEGER, expires_at INTEGER
        )""")
        # Relations sociales
        await db.execute("""
        CREATE TABLE IF NOT EXISTS mp_relations (
            user_id INTEGER, other_id INTEGER,
            score INTEGER DEFAULT 0,
            last_interaction INTEGER DEFAULT 0,
            relation_type TEXT DEFAULT 'connu',
            PRIMARY KEY(user_id, other_id)
        )""")
        # Cadeaux reçus
        await db.execute("""
        CREATE TABLE IF NOT EXISTS mp_gifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_id INTEGER, to_id INTEGER,
            amount INTEGER, message TEXT,
            created_at INTEGER
        )""")
        await db.commit()


MP_BATCH = 500


async def process_multiplayer_maintenance():
    """Expire les échanges en attente (remboursement), par lots de MP_BATCH."""
    current = now()
    while True:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")

                async with db.execute(
                    "SELECT trade_id,from_id,offer_money FROM mp_trades "
                    "WHERE status='pending' AND expires_at<? LIMIT ?",
                    (current, MP_BATCH),
                ) as cursor:
                    expired = await cursor.fetchall()

                for trade in expired:
                    claim = await db.execute(
                        "UPDATE mp_trades SET status='expired' "
                        "WHERE trade_id=? AND status='pending'",
                        (trade["trade_id"],),
                    )
                    if claim.rowcount != 1:
                        continue
                    await db.execute(
                        "UPDATE users SET balance=balance+? WHERE user_id=?",
                        (trade["offer_money"], trade["from_id"]),
                    )

                await db.commit()
            except Exception:
                await db.rollback()
                raise
        if len(expired) < MP_BATCH:
            break
        await asyncio.sleep(0)


# ─── Helpers ──────────────────────────────────────────────────────
async def _resolve_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Résout le joueur cible depuis un reply ou @username/id."""
    if update.message.reply_to_message:
        return update.message.reply_to_message.from_user
    if not context.args:
        return None
    from utils.user_lookup import find_user       # ID d'abord, puis @pseudo
    found = await find_user(context.args[0])
    if not found:
        return None
    row = (found["user_id"], found["username"], found["full_name"])

    class Fake:
        def __init__(self, uid, username, fn):
            self.id = uid; self.username = username; self.full_name = fn
    return Fake(row[0], row[1] or "", row[2] or "Joueur")


async def _bump_relation(user_id: int, other_id: int, delta: int, kind: str = None):
    """Met à jour la relation entre deux joueurs (dans les 2 sens)."""
    if user_id == other_id:
        return
    async with db_connection() as db:
        for a, b in [(user_id, other_id), (other_id, user_id)]:
            await db.execute(
                "INSERT INTO mp_relations(user_id, other_id, score, last_interaction, relation_type) "
                "VALUES(?,?,?,?,?) "
                "ON CONFLICT(user_id, other_id) DO UPDATE SET "
                "score = score + ?, last_interaction = ?, "
                "relation_type = COALESCE(?, relation_type)",
                (a, b, delta, now(), kind or "connu", delta, now(), kind),
            )
        await db.commit()


# ═══════════════════════════════════════════════════════════════════
#                          /cadeau
# ═══════════════════════════════════════════════════════════════════
@require_registered
@require_free
async def cmd_cadeau(update: Update, context: ContextTypes.DEFAULT_TYPE):
    sender = update.effective_user
    target = await _resolve_target(update, context)
    if not target:
        await update.message.reply_text(
            alert("info",
                  "Ouvre cette action depuis 🎮 Menu → 👥 Multijoueur & famille."
                  "Ou réponds à un message depuis le 🎮 Menu principal"),
            parse_mode="HTML")
        return

    args = context.args[1:] if context.args and not update.message.reply_to_message else context.args
    if not args:
        await update.message.reply_text(alert("warning", "Précise un montant."), parse_mode="HTML")
        return

    sender_data = await get_user(sender.id)
    amount = parse_amount(args[0], sender_data["balance"])
    if not amount or amount <= 0:
        await update.message.reply_text(alert("error", "Montant invalide."), parse_mode="HTML")
        return
    if amount > sender_data["balance"]:
        await update.message.reply_text(alert("error", f"Solde insuffisant. Tu as {fmt(sender_data['balance'])}."), parse_mode="HTML")
        return
    if target.id == sender.id:
        await update.message.reply_text(alert("warning", "Tu ne peux pas t'offrir un cadeau à toi-même."), parse_mode="HTML")
        return

    message = " ".join(args[1:]) if len(args) > 1 else "Sans mot doux"

    # Transaction
    async with db_connection() as db:
        await db.execute("UPDATE users SET balance = balance - ?, total_spent = total_spent + ? WHERE user_id=?",
                         (amount, amount, sender.id))
        await db.execute("UPDATE users SET balance = balance + ?, total_earned = total_earned + ? WHERE user_id=?",
                         (amount, amount, target.id))
        await db.execute(
            "INSERT INTO mp_gifts(from_id, to_id, amount, message, created_at) VALUES(?,?,?,?,?)",
            (sender.id, target.id, amount, message, now()),
        )
        await db.commit()

    # Relations & karma léger
    await _bump_relation(sender.id, target.id, 3, "ami")
    await update_field(sender.id, "karma", sender_data.get("karma", 0) + 2)

    await update.message.reply_text(
        card(
            "🎁 Cadeau envoyé !",
            [
                f"De : <b>{sender.full_name}</b>",
                f"À : <b>{target.full_name}</b>",
                f"💰 Montant : <b>{fmt(amount)}</b>",
                f"💌 Message : <i>{message}</i>",
                "",
                "✨ Relation +3  ·  🌟 Karma +2",
            ],
            icon="🎁", style="stars",
        ),
        parse_mode="HTML",
    )

    # Notif au destinataire
    try:
        await context.bot.send_message(
            target.id,
            card(
                "🎁 Tu as reçu un cadeau !",
                [
                    f"De : <b>{sender.full_name}</b>",
                    f"💰 Montant : <b>{fmt(amount)}</b>",
                    f"💌 « {message} »",
                ],
                icon="🎁", style="stars",
            ),
            parse_mode="HTML",
        )
    except Exception:
        swallowed('handlers/multiplayer.py')


# ═══════════════════════════════════════════════════════════════════
#                          /salutations
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_salutations(update: Update, context: ContextTypes.DEFAULT_TYPE):
    sender = update.effective_user
    target = await _resolve_target(update, context)
    if not target:
        await update.message.reply_text(
            alert("info", "Ouvre cette action depuis 🎮 Menu → 👥 Multijoueur & famille."),
            parse_mode="HTML")
        return
    if target.id == sender.id:
        await update.message.reply_text(alert("warning", "Tu peux pas te saluer toi-même 🤔"), parse_mode="HTML")
        return

    await _bump_relation(sender.id, target.id, 1, "connu")
    await update.message.reply_text(
        card(
            "👋 Salutations !",
            [
                f"<b>{sender.full_name}</b> salue <b>{target.full_name}</b>.",
                "",
                "✨ Relation +1",
                "<i>Les liens se tissent lentement, mais ils tiennent longtemps.</i>",
            ],
            icon="👋", style="round",
        ),
        parse_mode="HTML",
    )


# ═══════════════════════════════════════════════════════════════════
#                          /echange
# ═══════════════════════════════════════════════════════════════════
@require_registered
@require_free
async def cmd_echange(update: Update, context: ContextTypes.DEFAULT_TYPE):
    sender = update.effective_user
    if not context.args or len(context.args) < 3:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 👥 Multijoueur & famille."
        )
        return

    target = await _resolve_target(update, context)
    if not target or target.id == sender.id:
        await update.message.reply_text("❌ Cible invalide.")
        return

    sender_data = await get_user(sender.id)
    offer = parse_amount(context.args[1], sender_data["balance"])
    request = parse_amount(context.args[2])
    if not offer or not request or offer <= 0 or request <= 0:
        await update.message.reply_text("❌ Montants invalides.")
        return

    try:
        async with db_connection() as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                    "WHERE user_id=? AND balance>=?",
                    (offer, offer, sender.id, offer),
                )
                if debit.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Fonds insuffisants.")

                cursor = await db.execute(
                    "INSERT INTO mp_trades "
                    "(from_id,to_id,offer_money,request_money,status,created_at,expires_at) "
                    "VALUES (?,?,?,?,'pending',?,?)",
                    (sender.id, target.id, offer, request, now(), now() + 3600),
                )
                trade_id = cursor.lastrowid
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton(
            f"✅ Accepter (-{fmt(request)})",
            callback_data=f"trade_accept_{trade_id}",
        ),
        InlineKeyboardButton(
            "❌ Refuser",
            callback_data=f"trade_decline_{trade_id}",
        ),
    ]])

    await update.message.reply_text(
        f"🤝 Échange #{trade_id} créé. Offre bloquée : {fmt(offer)}."
    )
    try:
        await context.bot.send_message(
            target.id,
            f"🤝 {sender.full_name} offre {fmt(offer)} et demande {fmt(request)}.",
            reply_markup=keyboard,
        )
    except Exception:
        # La proposition reste consultable/traitable et expirera avec remboursement.
        pass

# ═══════════════════════════════════════════════════════════════════
#                          Callback échange
# ═══════════════════════════════════════════════════════════════════
async def trade_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    parts = query.data.split("_")
    if len(parts) != 3 or parts[0] != "trade":
        await query.edit_message_text("❌ Action invalide.")
        return

    action = parts[1]
    try:
        trade_id = int(parts[2])
    except ValueError:
        await query.edit_message_text("❌ Échange invalide.")
        return

    if action not in ("accept", "decline"):
        await query.edit_message_text("❌ Action inconnue.")
        return

    user_id = query.from_user.id
    result = None

    try:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                async with db.execute(
                    "SELECT * FROM mp_trades WHERE trade_id=?",
                    (trade_id,),
                ) as cursor:
                    trade = await cursor.fetchone()

                if not trade:
                    await db.rollback()
                    raise DeferredReply(query.edit_message_text, "❌ Échange introuvable.")
                if trade["to_id"] != user_id:
                    await db.rollback()
                    raise DeferredReply(query.answer, "⛔ Ce n'est pas ton échange.", show_alert=True)
                if trade["status"] != "pending":
                    await db.rollback()
                    raise DeferredReply(query.edit_message_text, f"⚠️ Échange déjà traité ({trade['status']}).")

                # Réserver l'échange. Un seul callback peut passer.
                claim = await db.execute(
                    "UPDATE mp_trades SET status='processing' "
                    "WHERE trade_id=? AND status='pending'",
                    (trade_id,),
                )
                if claim.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(query.edit_message_text, "⚠️ Échange déjà en traitement.")

                if now() > trade["expires_at"]:
                    await db.execute(
                        "UPDATE users SET balance=balance+? WHERE user_id=?",
                        (trade["offer_money"], trade["from_id"]),
                    )
                    await db.execute(
                        "UPDATE mp_trades SET status='expired' WHERE trade_id=?",
                        (trade_id,),
                    )
                    await db.commit()
                    result = "⏰ Échange expiré. L'offrant a été remboursé."

                elif action == "decline":
                    await db.execute(
                        "UPDATE users SET balance=balance+? WHERE user_id=?",
                        (trade["offer_money"], trade["from_id"]),
                    )
                    await db.execute(
                        "UPDATE mp_trades SET status='declined' WHERE trade_id=?",
                        (trade_id,),
                    )
                    await db.commit()
                    result = "❌ Échange refusé. L'offrant a été remboursé."

                else:
                    debit = await db.execute(
                        "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                        "WHERE user_id=? AND balance>=?",
                        (
                            trade["request_money"],
                            trade["request_money"],
                            user_id,
                            trade["request_money"],
                        ),
                    )
                    if debit.rowcount != 1:
                        await db.execute(
                            "UPDATE users SET balance=balance+? WHERE user_id=?",
                            (trade["offer_money"], trade["from_id"]),
                        )
                        await db.execute(
                            "UPDATE mp_trades SET status='failed' WHERE trade_id=?",
                            (trade_id,),
                        )
                        await db.commit()
                        result = "❌ Fonds insuffisants. L'offrant a été remboursé."
                    else:
                        await db.execute(
                            "UPDATE users SET balance=balance+?, total_earned=total_earned+? "
                            "WHERE user_id=?",
                            (
                                trade["request_money"],
                                trade["request_money"],
                                trade["from_id"],
                            ),
                        )
                        await db.execute(
                            "UPDATE users SET balance=balance+?, total_earned=total_earned+? "
                            "WHERE user_id=?",
                            (
                                trade["offer_money"],
                                trade["offer_money"],
                                user_id,
                            ),
                        )
                        await db.execute(
                            "UPDATE mp_trades SET status='accepted' WHERE trade_id=?",
                            (trade_id,),
                        )
                        await db.commit()
                        result = (
                            f"✅ Échange accepté ! Reçu : {fmt(trade['offer_money'])}, "
                            f"payé : {fmt(trade['request_money'])}."
                        )
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    await query.edit_message_text(result)
    if trade and result and result.startswith("✅"):
        await _bump_relation(trade["from_id"], user_id, 2, "partenaire")


# ═══════════════════════════════════════════════════════════════════
#                          /relations
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_relations(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT r.other_id, r.score, r.relation_type, u.full_name "
            "FROM mp_relations r JOIN users u ON u.user_id = r.other_id "
            "WHERE r.user_id=? ORDER BY r.score DESC LIMIT 15",
            (user.id,)
        ) as cur:
            rows = await cur.fetchall()

    if not rows:
        await update.message.reply_text(
            alert("info", "Tu n'as encore aucune relation enregistrée.\nInteragis avec d'autres joueurs !"),
            parse_mode="HTML")
        return

    body = []
    for r in rows:
        score = r["score"]
        if score >= 50:  emoji = "💖"
        elif score >= 20: emoji = "💚"
        elif score >= 0:  emoji = "⚪"
        elif score >= -20: emoji = "💔"
        else: emoji = "🖤"
        body.append(f"{emoji} <b>{r['full_name']}</b> ─ {score:+d}  <i>({r['relation_type']})</i>")

    await update.message.reply_text(
        card("Mes relations", body,
             icon="💞", style="thick",
             footer="Cadeaux et interactions augmentent les liens."),
        parse_mode="HTML",
    )


# ═══════════════════════════════════════════════════════════════════
#                          /classements
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_classements(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_for_update
    await show_for_update(update, None)


# ═══════════════════════════════════════════════════════════════════
#              🤝 MENU INTERACTIF MULTIJOUEUR
# ═══════════════════════════════════════════════════════════════════
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from utils.helpers import safe_edit


async def show_mp_cadeau_info(query, user_id: int):
    body = [
        "<b>Comment offrir un cadeau :</b>",
        "",
        "1️⃣ <b>Réponds</b> au message du joueur",
        "2️⃣ Tape : le 🎮 Menu principal",
        "",
        "<b>Ou :</b>",
        "le 🎮 Menu principal",
        "",
        "💡 <b>Effets :</b>",
        "  • 💰 Envoie de l'argent",
        "  • 💞 Relation +3",
        "  • 🌟 Karma +2",
        "",
        "<i>Le cadeau est transféré instantanément.</i>",
    ]
    await safe_edit(
        query,
        card("🎁 OFFRIR UN CADEAU", body, icon="🎁", style="stars"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="mp_menu")]])
    )


async def show_mp_salut_info(query, user_id: int):
    body = [
        "<b>Comment saluer un joueur :</b>",
        "",
        "1️⃣ <b>Réponds</b> au message du joueur",
        "2️⃣ Tape : le 🎮 Menu principal",
        "",
        "<b>Ou :</b>",
        "le 🎮 Menu principal",
        "",
        "💡 <b>Effet :</b> Relation +1",
        "",
        "<i>Simple et gratuit !</i>",
    ]
    await safe_edit(
        query,
        card("💬 SALUTATIONS", body, icon="👋", style="round"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="mp_menu")]])
    )


async def show_mp_echange_info(query, user_id: int):
    body = [
        "<b>Comment proposer un échange :</b>",
        "",
        "le 🎮 Menu principal",
        "",
        "<b>Exemple :</b>",
        "le 🎮 Menu principal",
        "→ J'offre 10 000 €A, je demande 5 000 €A en retour",
        "",
        "💡 <b>Comment ça marche :</b>",
        "  • Ton offre est bloquée dès l'envoi",
        "  • Le destinataire reçoit un message avec ✅/❌",
        "  • Expire après 1 heure (remboursement auto)",
        "",
        "<i>Sécurisé et sans risque.</i>",
    ]
    await safe_edit(
        query,
        card("🤝 PROPOSER UN ÉCHANGE", body, icon="🤝", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="mp_menu")]])
    )


async def show_mp_relations_view(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT r.other_id, r.score, r.relation_type, u.full_name "
            "FROM mp_relations r JOIN users u ON u.user_id = r.other_id "
            "WHERE r.user_id=? ORDER BY r.score DESC LIMIT 15",
            (user_id,)
        ) as cur:
            rows = await cur.fetchall()

    if not rows:
        await safe_edit(
            query,
            "💞 <b>Mes relations</b>\n\n"
            "<i>Tu n'as encore aucune relation enregistrée.</i>\n\n"
            "Interagis avec d'autres joueurs (cadeaux, salutations) pour tisser des liens !",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="mp_menu")]])
        )
        return

    body = []
    for r in rows:
        score = r["score"]
        if score >= 50:  emoji = "💖"
        elif score >= 20: emoji = "💚"
        elif score >= 0:  emoji = "⚪"
        elif score >= -20: emoji = "💔"
        else: emoji = "🖤"
        body.append(f"{emoji} <b>{escape_html(r['full_name'])}</b> ─ {score:+d}  <i>({r['relation_type']})</i>")

    await safe_edit(
        query,
        card("💞 MES RELATIONS", body, icon="💞", style="thick",
             footer="Cadeaux et interactions augmentent les liens."),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="mp_menu")]])
    )


async def show_mp_classements_view(query, user_id: int):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_in_query
    await show_in_query(query, user_id, None)


async def multiplayer_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routeur des callbacks 'mp_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "mp_menu":
        from handlers.hub import open_zone; await open_zone(query, "mp")
        return
    if data == "mp_cadeau_info":
        await show_mp_cadeau_info(query, user_id)
        return
    if data == "mp_salut_info":
        await show_mp_salut_info(query, user_id)
        return
    if data == "mp_echange_info":
        await show_mp_echange_info(query, user_id)
        return
    if data == "mp_relations_view":
        await show_mp_relations_view(query, user_id)
        return
    if data == "mp_classements_view":
        await show_mp_classements_view(query, user_id)
        return