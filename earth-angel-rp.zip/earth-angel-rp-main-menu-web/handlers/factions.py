# handlers/factions.py — factions gouvernementales (joueur) + rôles d'entreprise
import logging

import aiosqlite
import html

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from config import GOV_FACTIONS, SANTE_HEAD_LEVEL, ADMIN_RANK_MINISTER
from database import db_connection, get_user_company, get_user, now
from utils.company_roles import set_role, get_role
from utils.decorators import require_registered, require_free, admin_only
from utils.factions import (
    get_membership, join_faction, leave_faction, try_auto_promotion, rank_name,
    rank_salary, salary_unit, coffre_balance,
)
from utils.notify import notify

logger = logging.getLogger(__name__)

_MIN_RECRUITER_RANK = 3   # grade minimal (index) pour recruter / promouvoir dans une faction


def _min_rank(key: str) -> int:
    """Santé publique : seuls les DG / le PDG recrutent (les postes ne sont pas une échelle de grades)."""
    return SANTE_HEAD_LEVEL if key == "sante" else _MIN_RECRUITER_RANK


def _faction_list_text() -> str:
    lines = ["🏛️ <b>Factions gouvernementales</b>\n"]
    for key, f in GOV_FACTIONS.items():
        low, high = f["ranks"][0][1], f["ranks"][-1][1]
        lines.append(f"{f['emoji']} <b>{f['name']}</b> (<code>{key}</code>) — {low:,} à {high:,}{salary_unit(key)}")
    lines.append("\n👉 Menu État & factions → Rejoindre une faction : candidature puis entretien d'embauche")
    return "\n".join(lines)


@require_registered
async def cmd_factions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(_faction_list_text(), parse_mode="HTML")


@require_registered
async def cmd_faction(update: Update, context: ContextTypes.DEFAULT_TYPE):
    m = await get_membership(update.effective_user.id)
    if not m:
        await update.message.reply_text("Tu n'es dans aucune faction.\n" + _faction_list_text(), parse_mode="HTML")
        return
    f = GOV_FACTIONS[m["faction"]]
    ranks = f["ranks"]
    coffre = await coffre_balance(m["faction"])
    if m["faction"] == "sante":
        pay = f"💰 Salaire : <b>{m['salary']:,}</b> par heure de jeu (payé par le coffre)\n"
        nxt = "attribué par ta direction (DG / PDG)"
        tip = "👉 Menu État & factions → Santé publique → Mon poste santé"
    elif m["faction"] in ("police", "armee", "justice"):
        pay = f"💰 Salaire : <b>{m['salary']:,}</b> par heure de jeu (payé par le coffre)\n"
        nxt = "attribué par ta direction (DG / chef de poste)"
        tip = "👉 Menu État & factions → Police & Armée → Mon poste"
    else:
        pay = f"💰 Solde quotidien : <b>{m['salary']:,}</b> (versé chaque fin de jour)\n"
        nxt = (f"{ranks[m['rank'] + 1][0]} ({ranks[m['rank'] + 1][1]:,}/jour)"
               if m["rank"] + 1 < len(ranks) else "—")
        tip = ""
    await update.message.reply_text(
        f"{f['emoji']} <b>{f['name']}</b>\n"
        f"🎖️ Poste : <b>{m['rank_name']}</b>\n"
        f"{pay}"
        f"🏦 Coffre général : <b>{coffre:,}</b>\n"
        f"⚡ Activité : <b>{m['activity_score']}</b>\n"
        f"⬆️ Prochain grade : {nxt}\n\n"
        f"{tip}",
        parse_mode="HTML")


@require_registered
@require_free
async def cmd_faction_postuler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Candidature : TOUTES les factions recrutent par entretien d'embauche (voir utils/ordre.py).
    Sans argument : liste des factions en boutons ; avec une faction : choix du poste (ou envoi direct)."""
    from handlers import ordre as ordre_h
    from utils import ordre
    user = update.effective_user
    key = context.args[0].lower() if context.args else ""
    if key not in ordre.RECRUIT_FACTIONS:
        await ordre_h.show_apply(update, user.id)
        return
    if await get_membership(user.id):
        await update.effective_message.reply_text("❌ Tu fais déjà partie d'une faction.")
        return
    stations = ordre.station_ids(key)
    if len(stations) == 1:
        await ordre_h.do_apply(update, user.id, key, stations[0])
    else:
        await ordre_h.show_apply_station(update, user.id, key)


def _can_recruit(m: dict | None) -> bool:
    """Ancien recrutement sans entretien : supprimé, toutes les factions passent par l'entretien (Candidatures)."""
    return False


def _can_lead(m: dict | None) -> bool:
    """Nommer un grade (factions « simples ») : réservé à l'encadrement."""
    if m and m["faction"] in ("police", "armee", "justice", "sante"):
        return False      # postes gérés par la direction (Police & Armée / Santé publique)
    return bool(m) and m["rank"] >= _min_rank(m["faction"])


def _apps_button() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("📨 Candidatures & entretiens", callback_data="ord:apps")]])


async def _candidatures_view(m: dict):
    """Liste des candidatures en attente : numéro + nom + boutons ✅ / ❌ (plus rien à taper)."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT a.id, u.full_name, u.username FROM faction_applications a JOIN users u ON u.user_id=a.user_id "
            "WHERE a.faction=? AND a.status='pending' ORDER BY a.id LIMIT 20", (m["faction"],)) as cur:
            rows = await cur.fetchall()
    back = [InlineKeyboardButton("🎮 Menu principal", callback_data="hub:home")]
    if not rows:
        return "📨 <b>Candidatures</b>\n\nAucune candidature en attente.", InlineKeyboardMarkup([back])
    lines = ["📨 <b>Candidatures reçues</b>", "",
             "Appuie sur ✅ pour recruter ou ❌ pour refuser : le numéro est déjà pris en compte.", ""]
    kb = []
    for r in rows:
        name = r["full_name"] or r["username"] or "Joueur"
        tag = f" (@{r['username']})" if r["username"] else ""
        lines.append(f"🔹 <b>n°{r['id']}</b> — {html.escape(name)}{html.escape(tag)}")
        kb.append([InlineKeyboardButton(f"✅ n°{r['id']} {name}"[:30], callback_data=f"fcand:acc:{r['id']}"),
                   InlineKeyboardButton(f"❌ n°{r['id']}", callback_data=f"fcand:ref:{r['id']}")])
    kb.append(back)
    return "\n".join(lines), InlineKeyboardMarkup(kb)


@require_registered
async def cmd_faction_candidatures(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from handlers import ordre as ordre_h
    from utils import ordre
    if not await ordre.recruiter(update.effective_user.id):
        await update.effective_message.reply_text("❌ Réservé à l'encadrement de la faction.")
        return
    await ordre_h.show_apps(update, update.effective_user.id)


async def _apply_decision(user_id: int, app_id: int, accept: bool) -> str:
    """Accepte / refuse la candidature `app_id` et renvoie le message de résultat."""
    m = await get_membership(user_id)
    if not _can_recruit(m):
        return "❌ Réservé à l'encadrement de la faction."
    async with db_connection(row_factory=aiosqlite.Row) as db:
        cur = await db.execute(
            "UPDATE faction_applications SET status=? WHERE id=? AND faction=? AND status='pending'",
            ("accepted" if accept else "refused", app_id, m["faction"]))
        await db.commit()
        if not cur.rowcount:
            return "❌ Candidature introuvable ou déjà traitée."
        async with db.execute("SELECT user_id FROM faction_applications WHERE id=?", (app_id,)) as c:
            applicant = (await c.fetchone())["user_id"]
    f = GOV_FACTIONS[m["faction"]]
    if accept:
        ok, msg = await join_faction(applicant, m["faction"], 0)
        if not ok:
            return f"⚠️ Impossible de recruter : {msg}"
        if m["faction"] == "sante":
            from utils import sante
            await sante.register_recruit(applicant, m.get("hospital_id") or "grand")
        await notify(applicant, "🎉 Candidature acceptée",
                     f"Tu rejoins {f['emoji']} <b>{f['name']}</b> au grade <b>{rank_name(m['faction'], 0)}</b>.",
                     "success")
        return "✅ Recrue acceptée."
    await notify(applicant, "❌ Candidature refusée",
                 f"{f['emoji']} <b>{f['name']}</b> n'a pas retenu ta candidature.", "warning")
    return "Candidature refusée."


async def _decide(update: Update, context: ContextTypes.DEFAULT_TYPE, accept: bool):
    await update.effective_message.reply_text(
        "🗣️ Chaque candidature passe par un entretien : ouvre « Candidatures & entretiens », "
        "choisis le candidat puis 🗣️ Entretien, ✅ Recruter ou ❌ Refuser.", reply_markup=_apps_button())


async def faction_cand_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Boutons ✅ / ❌ de la liste des candidatures (callback fcand:acc:<n> / fcand:ref:<n>)."""
    q = update.callback_query
    await q.answer()
    _, action, raw = q.data.split(":")
    result = await _apply_decision(q.from_user.id, int(raw), action == "acc")
    m = await get_membership(q.from_user.id)
    if not _can_recruit(m):
        await q.edit_message_text(result)
        return
    text, kb = await _candidatures_view(m)
    await q.edit_message_text(f"{result}\n\n{text}", parse_mode="HTML", reply_markup=kb)


@require_registered
async def cmd_faction_accepter(update, context):
    await _decide(update, context, True)


@require_registered
async def cmd_faction_refuser(update, context):
    await _decide(update, context, False)


@require_registered
async def cmd_faction_quitter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ok = await leave_faction(update.effective_user.id)
    await update.message.reply_text("🚪 Tu as quitté ta faction." if ok else "Tu n'es dans aucune faction.")


@require_registered
async def cmd_faction_nommer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/faction_nommer <grade 1..n> en répondant à un membre : nomination par l'encadrement
    (uniquement vers un grade strictement inférieur au sien)."""
    user = update.effective_user
    m = await get_membership(user.id)
    if m and m["faction"] in ("police", "armee", "justice"):
        await update.message.reply_text(
            "🚓 Les postes se gèrent depuis Police & Armée → 👥 Équipe.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("👥 Équipe", callback_data="ord:team")]]))
        return
    if not _can_lead(m):
        await update.message.reply_text("❌ Réservé à l'encadrement de la faction.")
        return
    if m["faction"] == "sante":
        await update.message.reply_text("🏥 Santé publique : utilise Menu État & factions → Santé publique → Poste santé (poste précis par employé).")
        return
    if not update.message.reply_to_message or not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🎖️ État & factions.")
        return
    target_id = update.message.reply_to_message.from_user.id
    tm = await get_membership(target_id)
    if not tm or tm["faction"] != m["faction"]:
        await update.message.reply_text("❌ Ce joueur n'est pas dans ta faction.")
        return
    ranks = GOV_FACTIONS[m["faction"]]["ranks"]
    try:
        new_rank = int(context.args[0]) - 1
    except ValueError:
        new_rank = -1
    if not (0 <= new_rank < m["rank"]) or tm["rank"] >= m["rank"]:
        await update.message.reply_text("❌ Tu ne peux nommer que jusqu'à un grade inférieur au tien.")
        return
    if m["faction"] == "mairie" and new_rank >= ADMIN_RANK_MINISTER:
        await update.message.reply_text("❌ Les ministres sont nommés par le Président (menu Politique → Nommer un ministre).")
        return
    async with db_connection() as db:
        await db.execute("UPDATE faction_members SET rank=? WHERE user_id=?", (new_rank, target_id))
        await db.commit()
    await notify(target_id, "🎖️ Nomination",
                 f"Tu es nommé(e) <b>{ranks[new_rank][0]}</b> — <b>{ranks[new_rank][1]:,}</b>{salary_unit(m['faction'])}.", "achievement")
    await update.message.reply_text(f"✅ Nommé(e) {ranks[new_rank][0]}.")


@admin_only
async def cmd_faction_chef(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """le menu en répondant à un joueur : l'installe au grade le plus élevé (admin)."""
    if not update.message.reply_to_message or not context.args or context.args[0].lower() not in GOV_FACTIONS:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🎖️ État & factions.")
        return
    key = context.args[0].lower()
    if key == "sante":
        await update.message.reply_text("🏥 Santé publique : le Game Leader nomme le PDG avec /nommer_pdg.")
        return
    if key in ("police", "armee", "justice"):
        await update.message.reply_text("🚓 Police / armée / justice : menu État & factions → Police & Armée → 👑 Nommer la direction.")
        return
    target = update.message.reply_to_message.from_user
    top = len(GOV_FACTIONS[key]["ranks"]) - 1
    async with db_connection() as db:
        await db.execute("DELETE FROM company_members WHERE user_id=?", (target.id,))
        await db.execute(
            "INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) VALUES (?,?,?,0,?) "
            "ON CONFLICT(user_id) DO UPDATE SET faction=excluded.faction, rank=excluded.rank",
            (target.id, key, top, now()))
        await db.commit()
    await notify(target.id, "🎖️ Nomination",
                 f"Tu diriges désormais {GOV_FACTIONS[key]['emoji']} <b>{GOV_FACTIONS[key]['name']}</b> "
                 f"(<b>{rank_name(key, top)}</b>).", "achievement")
    await update.message.reply_text("✅ Chef installé.")


# ─────────────────────────────────────────────────────────────────────────────
# Rôles d'entreprise
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_role(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """le menu manager|employe (en répondant à l'employé) — réservé au créateur."""
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Réservé au créateur de l'entreprise.")
        return
    if not update.message.reply_to_message or not context.args:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 🎖️ État & factions."
            "• <b>manager</b> : recrute, licencie, gère produits et annonces\n"
            "• <b>employe</b> : produit et vend", parse_mode="HTML")
        return
    target = update.message.reply_to_message.from_user
    role = context.args[0].lower().replace("é", "e").replace("gerant", "manager")
    ok, msg = await set_role(company["company_id"], user.id, target.id, role)
    if not ok:
        await update.message.reply_text(f"❌ {msg}")
        return
    await notify(target.id, "👔 Nouveau rôle",
                 f"Dans <b>{company['name']}</b> tu es maintenant <b>{'gérant' if role == 'manager' else 'employé'}</b>.",
                 "info")
    await update.message.reply_text(f"✅ {target.full_name} est maintenant {'gérant' if role == 'manager' else 'employé'}.")
