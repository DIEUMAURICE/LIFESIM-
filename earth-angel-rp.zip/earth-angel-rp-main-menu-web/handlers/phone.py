# handlers/phone.py — SmartPhone Hub v4.0 (UX améliorée)
# Menu plus clair, catégories visuelles, aide intégrée, navigation fluide.
# ⭐ PATCH D.1 : Statuts VoidGram persistés en BDD (table phone_status)

from utils.swallow import swallowed
import aiosqlite
import time
import random
import re
import calendar
import asyncio
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import (
    db_connection,
    DB_PATH, get_user, update_balance, update_field, now, add_notification,
    get_inventory, get_bank_account, get_all_bank_accounts, get_user_company,
    get_vehicles, get_properties, get_marriage
)
from utils.decorators import require_registered
from utils.helpers import fmt, escape_html, fmt_time, get_level
from utils.aesthetics import card, alert, rich_bar
from utils.gametime import game_datetime, real_now, fmt_game_date
from config import SEASON_EFFECTS, VEHICLES, VIP_LUXE_REQUIRED, BANKS
from handlers.vehicles import get_active_vehicle, get_vehicle_stats


# ============================================================
# HELPER : édition sécurisée
# ============================================================
async def safe_edit(query, text, parse_mode="HTML", reply_markup=None):
    """Édite un message en gérant les cas photo/message inchangé."""
    try:
        await query.edit_message_text(text, parse_mode=parse_mode, reply_markup=reply_markup)
    except Exception as e:
        err = str(e)
        if "Message is not modified" in err:
            return
        if "no text in the message" in err.lower():
            try:
                await query.message.reply_text(text, parse_mode=parse_mode, reply_markup=reply_markup)
                try:
                    await query.message.delete()
                except Exception:
                    swallowed('handlers/phone.py')
            except Exception:
                swallowed('handlers/phone.py')
            return
        raise


# ============================================================
# LIENS VERS LES VRAIES ACTIONS DU MENU (boutons fonctionnels)
# ============================================================
def _hub_cb(fn: str, zone: str) -> str:
    """callback_data qui lance l'action `fn` du menu principal (formulaire en boutons si il existe,
    sinon lancement direct, sinon ouverture de la zone `zone`)."""
    from handlers.hub_data import ITEMS
    from utils.forms import FORMS
    from utils.auto_forms import form_key
    if form_key(fn) in FORMS:
        return f"fm:{form_key(fn)}"
    for idx, it in enumerate(ITEMS):
        if it[1] == fn:
            return f"hubr:{idx}"
    return f"hub:{zone}:0"


STATUS_TTL = 86400          # un statut reste affiché 24 h


async def get_status(user_id: int) -> str:
    """Dernier statut (moins de 24 h) d'un joueur, ou chaîne vide."""
    async with db_connection() as db:
        async with db.execute(
            "SELECT text FROM phone_status WHERE user_id = ? AND created_at > ? "
            "ORDER BY created_at DESC LIMIT 1", (user_id, now() - STATUS_TTL)
        ) as cur:
            row = await cur.fetchone()
    return row[0] if row else ""


# ============================================================
# INFOS DE JEU (heure, date, saison, météo)
# ============================================================
def get_game_datetime():
    """Date/heure/saison/météo DU JEU — identiques pour tous les joueurs au même instant."""
    d = game_datetime()
    season = d["season"]

    weather_options = {
        "Printemps": ["☀️ Ensoleillé", "🌦️ Averses", "🌈 Arc-en-ciel", "☁️ Nuageux", "🌸 Fleuri"],
        "Été": ["☀️ Torride", "⛅ Nuageux", "🌩️ Orage", "🌤️ Doux", "🏖️ Canicule"],
        "Automne": ["🍂 Brumeux", "🌧️ Pluvieux", "☁️ Couvert", "🌫️ Brouillard", "🍁 Venteux"],
        "Hiver": ["❄️ Neigeux", "🌨️ Tempête", "☀️ Froid sec", "🌬️ Vent glacial", "☁️ Givré"],
    }
    # Météo : même ciel pour tout le monde, change toutes les 6 h de jeu.
    rng = random.Random(d["game_ts"] // (6 * 3600))
    weather = rng.choice(weather_options.get(season, ["🌤️ Variable"]))

    return {
        "hour": d["hour"], "minute": d["minute"], "day": d["day"], "month": d["month"],
        "year": d["year"], "season": season, "weather": weather,
        "game_ts": d["game_ts"], "real_ts": real_now(),
    }


# ============================================================
# ÉCRAN D'ACCUEIL AMÉLIORÉ
# ============================================================
async def get_smartphone_home_text(user_id: int) -> str:
    u = await get_user(user_id)
    dt = get_game_datetime()

    async with db_connection() as db:
        async with db.execute(
            "SELECT COUNT(*) FROM notifications WHERE user_id = ? AND sent = 0",
            (user_id,)
        ) as cur:
            notif_count = (await cur.fetchone())[0] or 0

    active_vehicle = await get_active_vehicle(user_id)
    vehicle_name = active_vehicle.get("veh_type", "Aucun") if active_vehicle else "Aucun"

    my_status = await get_status(user_id)
    status_line = (f"💬 <i>{escape_html(my_status)}</i>\n" if my_status
                   else "💬 <i>Aucun statut : publie-en un (Actions rapides)</i>\n")

    battery = random.randint(65, 100)
    battery_bar = "█" * (battery // 10) + "░" * (10 - battery // 10)

    text = (
        f"📱 <b>SMARTPHONE OS v4.0</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🕒 {dt['hour']:02d}:{dt['minute']:02d}  📅 {dt['day']:02d}/{dt['month']:02d}/{dt['year']}\n"
        f"🌤️ {dt['weather']}  🍃 {dt['season']}\n"
        f"🔋 Batterie : <code>{battery_bar}</code> {battery}%\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>{escape_html(u.get('full_name', 'Joueur'))}</b>\n"
        f"💰 {fmt(u.get('balance', 0))}  ·  ⭐ Niv.{u.get('level', 1)}\n"
        f"🚗 {escape_html(vehicle_name)}  ·  📩 {notif_count} notif(s)\n"
        f"{status_line}"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💡 <i>Choisis une application ci-dessous</i>\n"
        f"❓ <i>Appuie sur Aide pour comprendre chaque application</i>"
    )
    return text


async def get_smartphone_home_keyboard(user_id: int) -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton("🏦 Banque", callback_data="phone_app_wallet"),
            InlineKeyboardButton("🏎️ Garage", callback_data="phone_app_garage"),
        ],
        [
            InlineKeyboardButton("🌐 Réseaux", callback_data="phone_app_social"),
            InlineKeyboardButton("📊 Classements", callback_data="phone_app_rankings"),
        ],
        [
            InlineKeyboardButton("📦 Sac", callback_data="phone_app_inventory"),
            InlineKeyboardButton("🏪 Marché", callback_data="phone_app_market"),
        ],
        [
            InlineKeyboardButton("🏠 Logement", callback_data="phone_app_realestate"),
            InlineKeyboardButton("❤️ Relations", callback_data="phone_app_relations"),
        ],
        [
            InlineKeyboardButton("👤 Profil", callback_data="phone_app_profile"),
            InlineKeyboardButton("⚙️ Paramètres", callback_data="phone_app_settings"),
        ],
        [
            InlineKeyboardButton("⚡ Actions rapides", callback_data="phone_actions_menu"),
        ],
        [
            InlineKeyboardButton("❓ Aide", callback_data="phone_help"),
            InlineKeyboardButton("❌ Éteindre", callback_data="phone_power_off"),
        ],
    ]
    return InlineKeyboardMarkup(keyboard)


# ============================================================
# ÉCRAN D'ACTIONS RAPIDES
# ============================================================
async def show_actions_menu(query, user_id: int):
    text = (
        f"⚡ <b>ACTIONS RAPIDES</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<i>Écris un message, publie un statut ou planifie un événement.</i>\n\n"
        f"📅 <b>Nouvel événement</b>\n"
        f"   <i>Ajoute une date au calendrier du jeu</i>\n\n"
        f"✉️ <b>Nouveau message privé</b>\n"
        f"   <i>Envoie un message direct à un autre joueur</i>\n\n"
        f"📢 <b>Publier un statut VoidGram</b>\n"
        f"   <i>Affiché sur ton téléphone, ton profil et le fil VoidGram (24 h)</i>\n"
    )
    keyboard = [
        [InlineKeyboardButton("📅 Créer un événement", callback_data="phone_action_event")],
        [InlineKeyboardButton("✉️ Envoyer un message", callback_data="phone_action_msg")],
        [InlineKeyboardButton("📢 Publier un statut", callback_data="phone_action_status"),
         InlineKeyboardButton("🗑️ Effacer mon statut", callback_data="phone_status_clear")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ============================================================
# ÉCRAN D'AIDE
# ============================================================
async def show_phone_help(query, user_id: int):
    text = (
        f"❓ <b>AIDE DU SMARTPHONE</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>🏦 Banque</b> : Voir ton solde, tes comptes et tes prêts\n"
        f"<b>🏎️ Garage</b> : Gérer ton véhicule, faire le plein, accès VIP\n"
        f"<b>🌐 Réseaux</b> : VoidGram (statuts, followers, SocialCoins)\n"
        f"<b>📊 Classements</b> : Top joueurs (richesse, XP, prestige)\n"
        f"<b>📦 Sac</b> : Ton inventaire d'objets\n"
        f"<b>🏪 Marché</b> : Voir les annonces des autres joueurs\n"
        f"<b>🏠 Logement</b> : Tes propriétés immobilières\n"
        f"<b>❤️ Relations</b> : Mariage, amis, famille\n"
        f"<b>👤 Profil</b> : Tes infos, statistiques détaillées\n"
        f"<b>⚙️ Paramètres</b> : Thème, sonnerie, notifications\n"
        f"<b>⚡ Actions rapides</b> : Écrire, publier, planifier\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
    )
    keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ============================================================
# COMMANDE PRINCIPALE
# ============================================================
@require_registered
async def cmd_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = await get_smartphone_home_text(user_id)
    reply_markup = await get_smartphone_home_keyboard(user_id)
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)


# ============================================================
# CALLBACK PRINCIPAL
# ============================================================
async def phone_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    try:
        await query.answer()
    except Exception:
        swallowed('handlers/phone.py')

    data = query.data
    user_id = query.from_user.id

    from utils.character import gate as _character_gate
    if await _character_gate(update, user_id):
        return

    if data == "phone_home":
        await show_home(query, user_id)
        return

    if data == "phone_power_off":
        await safe_edit(query, "📱 SmartPhone éteint.\nAppuie sur « 🎮 Menu principal » ou envoie /start.", parse_mode="HTML")
        return

    if data == "phone_help":
        await show_phone_help(query, user_id)
        return

    if data == "phone_actions_menu":
        await show_actions_menu(query, user_id)
        return

    if data == "phone_action_event":
        await start_event_flow(query, context)
        return
    if data == "phone_action_msg":
        await start_msg_flow(query, context)
        return
    if data == "phone_action_status":
        await start_status_flow(query, context)
        return
    if data == "phone_status_clear":
        async with db_connection() as db:
            await db.execute("DELETE FROM phone_status WHERE user_id = ?", (user_id,))
            await db.commit()
        await query.answer("🗑️ Statut effacé")
        await show_actions_menu(query, user_id)
        return
    if data == "phone_cancel":
        for k in [
            'phone_awaiting_event_title', 'phone_pending_event_title',
            'phone_awaiting_event_date', 'phone_awaiting_msg_target',
            'phone_pending_msg_target', 'phone_pending_msg_name',
            'phone_awaiting_msg_content', 'phone_awaiting_status_content',
        ]:
            context.user_data.pop(k, None)
        await safe_edit(query, "❌ Action annulée.\n\nAppuie sur « 🎮 Menu principal » ou envoie /start.", parse_mode="HTML")
        return

    if data == "phone_app_wallet":
        await app_wallet(query, user_id)
    elif data == "phone_app_garage":
        await app_garage(query, user_id)
    elif data == "phone_app_social":
        from handlers.hub import open_zone
        await open_zone(query, "social")
    elif data == "phone_app_rankings":
        await app_rankings(query, user_id)
    elif data == "phone_app_inventory":
        await app_inventory(query, user_id)
    elif data == "phone_app_market":
        await app_market(query, user_id)
    elif data == "phone_app_realestate":
        await app_realestate(query, user_id)
    elif data == "phone_app_relations":
        await app_relations(query, user_id)
    elif data == "phone_app_profile":
        await app_profile(query, user_id)
    elif data == "phone_app_settings":
        await app_settings(query, user_id)
    else:
        if data.startswith("phone_wallet_"):
            await app_wallet_sub(query, user_id, data)
        elif data.startswith("phone_garage_"):
            await app_garage_sub(query, user_id, data)
        elif data.startswith("phone_social_"):
            await app_social_sub(query, user_id, data)
        elif data.startswith("phone_profile_"):
            await app_profile_sub(query, user_id, data)
        elif data.startswith("phone_settings_"):
            await app_settings_sub(query, user_id, data)


# ============================================================
# APPLICATION A : WALLET (Banque & Finance)
# ============================================================
async def app_wallet(query, user_id: int):
    u = await get_user(user_id)
    accounts = await get_all_bank_accounts(user_id)

    total_bank = sum(a["balance"] for a in accounts)
    total_loan = sum(a["loan"] for a in accounts)

    text = (
        f"🏦 <b>BANQUE</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💰 Espèces : <b>{fmt(u.get('balance', 0))}</b>\n"
        f"🏦 En banque : <b>{fmt(total_bank)}</b>\n"
        f"💳 Prêts : <b>-{fmt(total_loan)}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💎 Total net : <b>{fmt(u.get('balance', 0) + total_bank - total_loan)}</b>\n"
        f"📊 Comptes ouverts : <b>{len(accounts)}</b>\n"
        f"📈 Plus-value : <b>{fmt(u.get('total_earned', 0) - u.get('total_spent', 0))}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💡 <i>Dépose ton argent pour qu'il génère des intérêts</i>"
    )

    keyboard = [
        [InlineKeyboardButton("💰 Déposer", callback_data="eco_depot"),
         InlineKeyboardButton("💳 Retirer", callback_data="eco_retrait")],
        [InlineKeyboardButton("📊 Mes comptes", callback_data="phone_wallet_accounts"),
         InlineKeyboardButton("💸 Vendre un item", callback_data="fm:m_vendre")],
        [InlineKeyboardButton("📈 Historique", callback_data="phone_wallet_history")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def app_wallet_sub(query, user_id: int, data: str):
    action = data.replace("phone_wallet_", "")

    if action == "home":
        await show_home(query, user_id)
        return

    if action == "accounts":
        accounts = await get_all_bank_accounts(user_id)
        if not accounts:
            text = (
                f"🏦 <b>MES COMPTES</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"📭 Tu n'as aucun compte bancaire.\n\n"
                f"Ouvre-en un depuis le menu Économie."
            )
        else:
            text = f"🏦 <b>MES COMPTES</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
            for acc in accounts:
                bank = next((b for b in BANKS if b["name"] == acc["bank_name"]), {})
                interest = int(acc["balance"] * bank.get("interest", 0))
                text += f"\n🏛️ <b>{escape_html(acc['bank_name'])}</b>\n"
                text += f"   💰 {fmt(acc['balance'])}\n"
                text += f"   📈 +{fmt(interest)}/jour\n"
                if acc['loan'] > 0:
                    text += f"   💳 Prêt : {fmt(acc['loan'])}\n"
        await safe_edit(
            query, text, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="phone_app_wallet")]])
        )
        return

    if action == "history":
        u = await get_user(user_id)
        text = (
            f"📈 <b>HISTORIQUE FINANCIER</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💰 Total gagné : {fmt(u.get('total_earned', 0))}\n"
            f"💸 Total dépensé : {fmt(u.get('total_spent', 0))}\n"
            f"📊 Plus-value : {fmt(u.get('total_earned', 0) - u.get('total_spent', 0))}\n"
        )
        await safe_edit(
            query, text, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="phone_app_wallet")]])
        )
        return


# ============================================================
# APPLICATION B : GARAGE & LUXE
# ============================================================
async def app_garage(query, user_id: int):
    active = await get_active_vehicle(user_id)

    if active:
        veh_data = await get_vehicle_stats(active["veh_type"])
        vehicle_luxe = active.get("luxury", 0) or veh_data.get("luxury", 0)
        vehicle_name = active.get("veh_type", "Inconnu")
        vehicle_speed = active.get("speed", 0) or veh_data.get("speed", 0)
        vehicle_cargo = active.get("cargo", 0) or veh_data.get("cargo", 0)
        condition = active.get("condition", 100)

        progress = min(100, int((vehicle_luxe / VIP_LUXE_REQUIRED) * 100))
        bar = rich_bar(progress, 100, 10)
        cond_bar = rich_bar(condition, 100, 10)

        text = (
            f"🏎️ <b>GARAGE</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🚗 <b>{escape_html(vehicle_name)}</b> ✅ ACTIF\n"
            f"⚡ Vitesse : {vehicle_speed}/100\n"
            f"📦 Cargo : {vehicle_cargo}/100\n"
            f"✨ Luxe : {vehicle_luxe}/100\n"
            f"🛠️ État : <code>{cond_bar}</code> {condition}%\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"<b>Progression VIP</b>\n"
            f"<code>{bar}</code> {progress}%\n"
            f"{'✅ ACCÈS VIP DÉBLOQUÉ' if vehicle_luxe >= VIP_LUXE_REQUIRED else '🔒 ' + str(VIP_LUXE_REQUIRED - vehicle_luxe) + ' pts manquants'}"
        )
    else:
        text = (
            f"🏎️ <b>GARAGE</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🚫 Aucun véhicule actif\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💡 Tu n'as pas encore de véhicule."
        )

    keyboard = [
        [InlineKeyboardButton("📋 Voir le garage", callback_data="phone_garage_view")],
        [InlineKeyboardButton("🔧 Réparer", callback_data=_hub_cb("repair_vehicle", "vehicules")),
         InlineKeyboardButton("⛽ Faire le plein", callback_data=_hub_cb("refuel", "vehicules"))],
        [InlineKeyboardButton("✨ Accès VIP", callback_data="phone_garage_vip"),
         InlineKeyboardButton("📦 Bonus cargo", callback_data="phone_garage_cargo")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def app_garage_sub(query, user_id: int, data: str):
    action = data.replace("phone_garage_", "")

    if action == "home":
        await show_home(query, user_id)
        return

    if action == "view":
        vehicles = await get_vehicles(user_id)
        if not vehicles:
            text = (
                f"📭 <b>GARAGE VIDE</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"Aucun véhicule pour l'instant."
            )
        else:
            text = f"🏎️ <b>MES VÉHICULES</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
            for v in vehicles[:5]:
                veh_data = await get_vehicle_stats(v["veh_type"])
                text += (
                    f"\n{veh_data.get('emoji', '🚗')} <b>{escape_html(v['veh_type'])}</b>\n"
                    f"   ✨ Luxe : {v.get('luxury', 0) or veh_data.get('luxury', 0)}/100\n"
                    f"   🛠️ État : {v.get('condition', 100)}%\n"
                )
                if v.get("insured"):
                    text += "   ✅ Assuré\n"
            if len(vehicles) > 5:
                text += f"\n<i>... et {len(vehicles)-5} autres</i>"
        await safe_edit(
            query, text, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="phone_app_garage")]])
        )
        return

    if action == "vip":
        active = await get_active_vehicle(user_id)
        if not active:
            text = (
                f"🚫 <b>PAS DE VÉHICULE</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"Tu n'as pas encore de véhicule."
            )
        else:
            veh_data = await get_vehicle_stats(active["veh_type"])
            vehicle_luxe = active.get("luxury", 0) or veh_data.get("luxury", 0)
            if vehicle_luxe >= VIP_LUXE_REQUIRED:
                text = (
                    f"✅ <b>ACCÈS VIP ACCORDÉ</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"✨ Luxe : {vehicle_luxe}/100\n\n"
                    f"🥂 Profite des salons privés !"
                )
            else:
                missing = VIP_LUXE_REQUIRED - vehicle_luxe
                text = (
                    f"🔒 <b>ACCÈS REFUSÉ</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"✨ Luxe actuel : {vehicle_luxe}/100\n"
                    f"🎯 Seuil requis : {VIP_LUXE_REQUIRED}\n\n"
                    f"⚠️ Il te manque {missing} pts"
                )
        await safe_edit(
            query, text, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="phone_app_garage")]])
        )
        return

    if action == "cargo":
        active = await get_active_vehicle(user_id)
        if not active:
            text = "🚫 Aucun véhicule actif."
        else:
            veh_data = await get_vehicle_stats(active["veh_type"])
            cargo = active.get("cargo", 0) or veh_data.get("cargo", 0)
            bonus = 1 + (cargo / 500)
            bonus = min(1.20, bonus)
            text = (
                f"📦 <b>BONUS CARGO</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━\n"
                f"🚗 Véhicule : {escape_html(active.get('veh_type', 'Inconnu'))}\n"
                f"📦 Cargo : {cargo}/100\n"
                f"💰 Bonus sur les ventes : +{int((bonus - 1) * 100)}%\n\n"
                f"<i>Ce bonus s'applique quand tu vends des items au marché.</i>"
            )
        await safe_edit(
            query, text, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="phone_app_garage")]])
        )
        return


# ============================================================
# APPLICATION C : VOIDGRAM (Réseaux sociaux)
# ⭐ PATCH D.1 : statuts persistés en BDD (plus de _status_cache)
# ============================================================
async def app_social(query, user_id: int):
    """Voidgram : le téléphone ouvre le Réseau RP (un seul réseau pour tout le jeu)."""
    u = await get_user(user_id)
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT author_id, platform, text, likes FROM rp_posts WHERE deleted=0 AND kind='post' AND created_at > ? "
            "ORDER BY created_at DESC LIMIT 5", (now() - 86400,)
        ) as cur:
            rows = await cur.fetchall()
        async with db.execute("SELECT COUNT(*) FROM rp_dms WHERE to_id=? AND is_read=0", (user_id,)) as cur:
            unread = (await cur.fetchone())[0]

    lines = []
    for r in rows:
        author = await get_user(r["author_id"])
        name = author.get("full_name", f"Joueur {r['author_id']}")
        lines.append(f"👤 <b>{escape_html(name)}</b> · {escape_html(r['platform'])}\n"
                     f"   <i>{escape_html(r['text'][:90])}</i> ❤️ {r['likes']}")
    feed = "\n\n".join(lines) if lines else "📭 Aucun post récent : lance la conversation !"

    text = (
        f"🌐 <b>VOIDGRAM</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 {escape_html(u.get('full_name', 'Joueur'))}\n"
        f"📱 Abonnés : <b>{u.get('social_followers', 0):,}</b>\n"
        f"💎 SocialCoins : <b>{u.get('social_coins', 0)}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>📰 Derniers posts des joueurs</b>\n"
        f"{feed}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💡 <i>Voidgram et le Réseau RP ne font qu'un.</i>"
    )

    keyboard = [
        [InlineKeyboardButton("📰 Mon fil", callback_data="rs:feed:fol:0"),
         InlineKeyboardButton("🔥 Explorer", callback_data="rs:feed:exp:0")],
        [InlineKeyboardButton("✍️ Publier", callback_data="rs:post"),
         InlineKeyboardButton(f"💌 Messages{f' ({unread})' if unread else ''}", callback_data="rs:inbox")],
        [InlineKeyboardButton("🌐 Réseau complet", callback_data="rs:home"),
         InlineKeyboardButton("🏆 Top", callback_data="phone_social_rank")],
        [InlineKeyboardButton("💎 SocialCoins", callback_data="phone_social_coins")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def app_social_sub(query, user_id: int, data: str):
    action = data.replace("phone_social_", "")

    if action == "home":
        await show_home(query, user_id)
        return

    if action == "rank":
        async with db_connection() as db:
            cursor = await db.execute(
                "SELECT full_name, social_followers FROM users WHERE social_followers > 0 ORDER BY social_followers DESC LIMIT 5"
            )
            rows = await cursor.fetchall()
        if not rows:
            text = "📊 Aucun influenceur pour l'instant."
        else:
            text = f"🏆 <b>TOP INFLUENCEURS</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
            medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"]
            for i, (name, followers) in enumerate(rows):
                text += f"{medals[i]} <b>{escape_html(name)}</b>\n   {followers:,} abonnés\n"
        await safe_edit(
            query, text, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="phone_app_social")]])
        )
        return

    if action == "coins":
        u = await get_user(user_id)
        text = (
            f"💎 <b>SOCIALCOINS</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💰 Ton solde : <b>{u.get('social_coins', 0)}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💡 Gagne des SocialCoins en publiant"
        )
        await safe_edit(
            query, text, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎁 Donner des SocialCoins", callback_data=_hub_cb("donner_socialcoins", "social"))],
                [InlineKeyboardButton("⬅️ Retour", callback_data="phone_app_social")],
            ])
        )
        return


# ============================================================
# APPLICATION D : CLASSEMENTS
# ============================================================
async def app_rankings(query, user_id: int):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_in_query
    await show_in_query(query, user_id, None)


# ============================================================
# APPLICATION E : INVENTAIRE
# ============================================================
async def app_inventory(query, user_id: int):
    items = await get_inventory(user_id)

    if not items:
        text = (
            f"📦 <b>INVENTAIRE</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📭 Inventaire vide.\n\n"
            f"💡 Gagne des objets avec les missions, le casino, l'arène…"
        )
    else:
        text = f"📦 <b>INVENTAIRE</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
        for item in items[:8]:
            text += f"• {item.get('item_name', 'Objet')} ×{item.get('quantity', 1)}\n"
        if len(items) > 8:
            text += f"\n<i>... et {len(items)-8} autres</i>"

    keyboard = [
        [InlineKeyboardButton("📦 Utiliser un item", callback_data=_hub_cb("useitem", "marche"))],
        [InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ============================================================
# APPLICATION F : MARCHÉ
# ============================================================
async def app_market(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ml.listing_id, ml.price, ml.quantity, i.name, i.emoji, u.full_name as seller
            FROM market_listings ml
            JOIN items i ON i.item_id = ml.item_id
            JOIN users u ON u.user_id = ml.seller_id
            WHERE ml.status = 'active' AND ml.expires_at > ?
            ORDER BY ml.price ASC
            LIMIT 5
        """, (now(),)) as cur:
            listings = await cur.fetchall()

    if not listings:
        text = (
            f"🏪 <b>MARCHÉ</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📭 Aucune annonce pour l'instant."
        )
    else:
        text = f"🏪 <b>MARCHÉ</b>\n━━━━━━━━━━━━━━━━━━━━━━\n"
        for l in listings:
            text += f"\n{l['emoji']} <b>{escape_html(l['name'])}</b>\n"
            text += f"   💰 {fmt(l['price'])}/u × {l['quantity']}\n"
            text += f"   Vendeur : {escape_html(l['seller'])}"

    keyboard = [
        [InlineKeyboardButton("🛒 Voir tout", callback_data="hub:marche:0")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ============================================================
# APPLICATION G : IMMOBILIER
# ============================================================
async def app_realestate(query, user_id: int):
    properties = await get_properties(user_id)

    text = (
        f"🏠 <b>LOGEMENT</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🏘️ Propriétés : <b>{len(properties)}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━"
    )

    keyboard = [
        [InlineKeyboardButton("📋 Mes biens", callback_data=_hub_cb("mesbiens", "invest"))],
        [InlineKeyboardButton("🏪 Marché immobilier", callback_data=_hub_cb("proprietes", "invest"))],
        [InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ============================================================
# APPLICATION H : RELATIONS
# ============================================================
async def app_relations(query, user_id: int):
    marriage = await get_marriage(user_id)
    u = await get_user(user_id)

    partner_text = "💔 Célibataire"
    if marriage:
        partner = await get_user(marriage["partner_id"])
        partner_text = f"💍 Marié(e) à {escape_html(partner.get('full_name', 'Inconnu'))}"

    async with db_connection() as db:
        async with db.execute(
            "SELECT COUNT(*) FROM friendships WHERE user_id = ?",
            (user_id,)
        ) as cur:
            friends_count = (await cur.fetchone())[0] or 0

    text = (
        f"❤️ <b>RELATIONS</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"{partner_text}\n"
        f"👥 Amis : <b>{friends_count}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━"
    )

    keyboard = [
        [InlineKeyboardButton("👥 Mes amis", callback_data=_hub_cb("mesamis", "multi")),
         InlineKeyboardButton("🏠 Ma famille", callback_data=_hub_cb("famille", "multi"))],
        [InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ============================================================
# APPLICATION I : PROFIL
# ============================================================
async def app_profile(query, user_id: int):
    u = await get_user(user_id)

    text = (
        f"👤 <b>PROFIL</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 {escape_html(u.get('full_name', 'Joueur'))}\n"
        f"🆔 <code>{user_id}</code>\n"
        f"⭐ Niv.{u.get('level', 1)} — {u.get('xp', 0)} XP\n"
        f"💰 {fmt(u.get('balance', 0))}\n"
        f"🌟 Karma : {u.get('karma', 0)}\n"
        f"👑 Prestige : {u.get('prestige', 0)}\n"
        f"💼 {escape_html(u.get('job', 'Sans emploi'))}\n"
        f"🎓 {escape_html(u.get('diplome', 'Aucun'))}\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📱 Followers : {u.get('social_followers', 0):,}\n"
        f"🏠 {escape_html(u.get('location', 'Inconnu'))}"
    )

    keyboard = [
        [InlineKeyboardButton("📊 Stats détaillées", callback_data="phone_profile_stats")],
        [InlineKeyboardButton("📝 Modifier bio", callback_data="prof_bio_edit")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def app_profile_sub(query, user_id: int, data: str):
    action = data.replace("phone_profile_", "")

    if action == "stats":
        u = await get_user(user_id)
        text = (
            f"📊 <b>STATS DÉTAILLÉES</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"❤️ Santé : {u.get('health', 100)}%\n"
            f"⚡ Énergie : {u.get('energy', 100)}%\n"
            f"🍽️ Faim : {u.get('hunger', 100)}%\n"
            f"😊 Bonheur : {u.get('happiness', 100)}%\n"
            f"😰 Stress : {u.get('stress', 0)}%\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💼 Crimes : {u.get('crimes_done', 0)}\n"
            f"🥊 Arène : {u.get('arena_wins', 0)}W / {u.get('arena_losses', 0)}L\n"
            f"✈️ Voyages : {u.get('travel_count', 0)}"
        )
        await safe_edit(
            query, text, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="phone_app_profile")]])
        )
        return

# ============================================================
# APPLICATION J : PARAMÈTRES
# ============================================================
async def app_settings(query, user_id: int):
    u = await get_user(user_id)
    theme = u.get("phone_theme", "dark")
    ringtone = u.get("phone_ringtone", "classic")

    text = (
        f"⚙️ <b>PARAMÈTRES</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🎨 Thème : <b>{'🌙 Sombre' if theme == 'dark' else '☀️ Clair'}</b>\n"
        f"🔔 Sonnerie : <b>{'🎵 Classique' if ringtone == 'classic' else '🎶 Moderne'}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━\n"
        f"💡 Personnalise ton téléphone"
    )

    keyboard = [
        [InlineKeyboardButton("🎨 Changer le thème", callback_data="phone_settings_theme"),
         InlineKeyboardButton("🔔 Changer sonnerie", callback_data="phone_settings_ringtone")],
        [InlineKeyboardButton("📩 Notifications", callback_data="phone_settings_notifs")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="phone_home")],
    ]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def app_settings_sub(query, user_id: int, data: str):
    action = data.replace("phone_settings_", "")

    if action == "theme":
        async with db_connection() as db:
            async with db.execute("SELECT phone_theme FROM users WHERE user_id = ?", (user_id,)) as cur:
                row = await cur.fetchone()
            current = row[0] if row else "dark"
            new_theme = "light" if current == "dark" else "dark"
            await db.execute("UPDATE users SET phone_theme = ? WHERE user_id = ?", (new_theme, user_id))
            await db.commit()
        await query.answer(f"🎨 Thème changé en {new_theme}")
        await app_settings(query, user_id)
        return

    if action == "ringtone":
        async with db_connection() as db:
            async with db.execute("SELECT phone_ringtone FROM users WHERE user_id = ?", (user_id,)) as cur:
                row = await cur.fetchone()
            current = row[0] if row else "classic"
            new_ringtone = "modern" if current == "classic" else "classic"
            await db.execute("UPDATE users SET phone_ringtone = ? WHERE user_id = ?", (new_ringtone, user_id))
            await db.commit()
        await query.answer(f"🔔 Sonnerie changée en {new_ringtone}")
        await app_settings(query, user_id)
        return

    if action == "notifs":
        async with db_connection() as db:
            async with db.execute("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND sent = 0", (user_id,)) as cur:
                pending = (await cur.fetchone())[0] or 0
            async with db.execute("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND sent = 1", (user_id,)) as cur:
                sent = (await cur.fetchone())[0] or 0

        text = (
            f"📩 <b>NOTIFICATIONS</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ En attente : {pending}\n"
            f"✅ Reçues : {sent}\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
        )
        await safe_edit(
            query, text, parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="phone_app_settings")]])
        )
        return


# ============================================================
# RETOUR À L'ACCUEIL
# ============================================================
async def show_home(query, user_id: int):
    await asyncio.sleep(0.2)
    text = await get_smartphone_home_text(user_id)
    reply_markup = await get_smartphone_home_keyboard(user_id)
    await safe_edit(query, text, parse_mode="HTML", reply_markup=reply_markup)


# ============================================================
# FLUX INTERACTIFS : ÉVÉNEMENT / MESSAGE / STATUT
# ============================================================
async def start_event_flow(query, context):
    context.user_data['phone_awaiting_event_title'] = True
    context.user_data.pop('phone_pending_event_title', None)
    context.user_data.pop('phone_awaiting_event_date', None)

    text = (
        "📅 <b>NOUVEL ÉVÉNEMENT</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "<b>Étape 1/2</b> : Envoie le <b>titre</b> de l'événement.\n\n"
        "<i>Exemple : Réunion importante</i>\n\n"
        "💡 Ouvre le menu pour annuler"
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="phone_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_msg_flow(query, context):
    context.user_data['phone_awaiting_msg_target'] = True
    context.user_data.pop('phone_pending_msg_target', None)
    context.user_data.pop('phone_pending_msg_name', None)
    context.user_data.pop('phone_awaiting_msg_content', None)

    text = (
        "✉️ <b>NOUVEAU MESSAGE</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "<b>Étape 1/2</b> : Envoie le <b>destinataire</b>.\n\n"
        "<i>Exemple : @mauridieu</i>\n\n"
        "💡 Ouvre le menu pour annuler"
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="phone_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def start_status_flow(query, context):
    context.user_data['phone_awaiting_status_content'] = True

    text = (
        "📢 <b>PUBLIER UN STATUT</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Envoie le contenu de ton statut (max 200 caractères).\n\n"
        "<i>Ton statut sera visible par tous les joueurs.</i>\n\n"
        "💡 Ouvre le menu pour annuler"
    )
    keyboard = [[InlineKeyboardButton("❌ Annuler", callback_data="phone_cancel")]]
    await safe_edit(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


async def resolve_username_to_id(username: str):
    """ID d'abord, puis @pseudo (joueur inscrit)."""
    from utils.user_lookup import find_user
    row = await find_user(username, registered_only=True)
    return (row["user_id"], row["full_name"]) if row else (None, None)


async def handle_phone_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Capture les saisies utilisateur pour les flux du téléphone."""
    if not update.message or not update.message.text:
        return

    text = update.message.text.strip()
    user_id = update.effective_user.id

    if text.lower() in ("/annuler", "/cancel", "annuler", "cancel"):
        for k in [
            'phone_awaiting_event_title', 'phone_pending_event_title',
            'phone_awaiting_event_date', 'phone_awaiting_msg_target',
            'phone_pending_msg_target', 'phone_pending_msg_name',
            'phone_awaiting_msg_content', 'phone_awaiting_status_content',
        ]:
            context.user_data.pop(k, None)
        await update.message.reply_text("❌ Action annulée.\n\nAppuie sur « 🎮 Menu principal » ou envoie /start.")
        return

    # ─── Événement : titre ───
    if context.user_data.get('phone_awaiting_event_title'):
        context.user_data['phone_awaiting_event_title'] = False
        context.user_data['phone_pending_event_title'] = text[:80]
        context.user_data['phone_awaiting_event_date'] = True
        await update.message.reply_text(
            f"📅 <b>Titre enregistré : {escape_html(text[:80])}</b>\n\n"
            f"Maintenant, envoie la <b>date</b> au format <code>JJ MM AAAA</code>.\n"
            f"<i>Exemple : 25 12 2026</i>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("❌ Annuler", callback_data="phone_cancel")
            ]])
        )
        return

    # ─── Événement : date ───
    if context.user_data.get('phone_awaiting_event_date'):
        title = context.user_data.get('phone_pending_event_title', 'Sans titre')
        parts = text.strip().split()
        if len(parts) != 3 or not all(p.isdigit() for p in parts):
            await update.message.reply_text(
                "❌ Format invalide. Utilise <code>JJ MM AAAA</code>.\n"
                "Exemple : <code>25 12 2026</code>",
                parse_mode="HTML"
            )
            return

        day, month, year = int(parts[0]), int(parts[1]), int(parts[2])
        try:
            date_ts = calendar.timegm((year, month, day, 0, 0, 0))
        except Exception:
            await update.message.reply_text("❌ Date invalide. Vérifie les valeurs.")
            return

        if date_ts < now():
            await update.message.reply_text("❌ La date doit être dans le futur.")
            return

        async with db_connection() as db:
            await db.execute(
                "INSERT INTO game_calendar (date, title, description, created_at, user_id) VALUES (?, ?, ?, ?, ?)",
                (date_ts, title, f"Événement de {update.effective_user.full_name}", now(), user_id)
            )
            await db.commit()

        date_display = fmt_game_date(date_ts)
        context.user_data.pop('phone_pending_event_title', None)
        context.user_data.pop('phone_awaiting_event_date', None)

        await update.message.reply_text(
            f"✅ <b>Événement ajouté !</b>\n\n"
            f"📅 <b>{escape_html(title)}</b>\n"
            f"📆 Le {date_display}",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("📱 Retour au téléphone", callback_data="phone_home")
            ]])
        )
        return

    # ─── Message : destinataire ───
    if context.user_data.get('phone_awaiting_msg_target'):
        target_id, target_name = await resolve_username_to_id(text)
        if not target_id:
            await update.message.reply_text(
                "❌ Destinataire introuvable.\n"
                "Vérifie le @username ou l'ID.\n\n"
                "Réessaie ou Ouvre le menu."
            )
            return

        if target_id == user_id:
            await update.message.reply_text("❌ Tu ne peux pas t'envoyer un message à toi-même.")
            return

        context.user_data['phone_awaiting_msg_target'] = False
        context.user_data['phone_pending_msg_target'] = target_id
        context.user_data['phone_pending_msg_name'] = target_name
        context.user_data['phone_awaiting_msg_content'] = True

        await update.message.reply_text(
            f"✉️ <b>Destinataire : {escape_html(target_name)}</b>\n\n"
            f"Envoie le <b>contenu</b> du message (max 500 caractères).",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("❌ Annuler", callback_data="phone_cancel")
            ]])
        )
        return

    # ─── Message : contenu ───
    if context.user_data.get('phone_awaiting_msg_content'):
        target_id = context.user_data.get('phone_pending_msg_target')
        target_name = context.user_data.get('phone_pending_msg_name', 'Destinataire')
        if not target_id:
            await update.message.reply_text("❌ Erreur : aucun destinataire. Ouvre le menu et recommence.")
            return
        if len(text) > 500:
            await update.message.reply_text("❌ Message trop long (max 500 caractères).")
            return

        async with db_connection() as db:
            await db.execute(
                "INSERT INTO phone_messages (from_id, to_id, message, created_at, read) VALUES (?, ?, ?, ?, 0)",
                (user_id, target_id, text, now())
            )
            await db.commit()

        await add_notification(
            target_id,
            f"📱 Nouveau message de {update.effective_user.full_name} : {text[:100]}{'...' if len(text) > 100 else ''}"
        )

        context.user_data.pop('phone_pending_msg_target', None)
        context.user_data.pop('phone_pending_msg_name', None)
        context.user_data.pop('phone_awaiting_msg_content', None)

        await update.message.reply_text(
            f"✅ <b>Message envoyé !</b>\n\n"
            f"👤 À : {escape_html(target_name)}\n"
            f"📝 <i>{escape_html(text[:100])}{'...' if len(text) > 100 else ''}</i>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("📱 Retour au téléphone", callback_data="phone_home")
            ]])
        )
        return

    # ─── Statut : contenu ───
    if context.user_data.get('phone_awaiting_status_content'):
        if len(text) > 200:
            await update.message.reply_text("❌ Statut trop long (max 200 caractères).")
            return

        # ⭐ PATCH D.1 : écriture en BDD au lieu du cache mémoire
        async with db_connection() as db:
            await db.execute(
                "INSERT INTO phone_status (user_id, text, created_at) VALUES (?, ?, ?)",
                (user_id, text, now())
            )
            await db.commit()
        context.user_data.pop('phone_awaiting_status_content', None)

        await update.message.reply_text(
            f"✅ <b>Statut publié !</b>\n\n"
            f"📝 <i>{escape_html(text)}</i>\n\n"
            f"👀 Visible 24 h sur ton téléphone, ton profil et le fil VoidGram.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("📱 Retour au téléphone", callback_data="phone_home")
            ]])
        )
        return

    return


# ============================================================
# COMMANDES D'ÉCRITURE (conservées pour compatibilité)
# ============================================================
@require_registered
async def cmd_phone_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not context.args:
        await update.message.reply_text(
            "📝 <b>Publier un statut</b>\n\n"
            "Ton statut s'affiche 24 h sur ton téléphone, ton profil et le fil VoidGram.\n"
            "Appuie sur le bouton ci-dessous puis écris ton message.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("📢 Écrire mon statut", callback_data="phone_action_status")]])
        )
        return

    message = " ".join(context.args)[:200]

    # ⭐ PATCH D.1 : écriture en BDD au lieu du cache mémoire
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO phone_status (user_id, text, created_at) VALUES (?, ?, ?)",
            (user.id, message, now())
        )
        await db.commit()

    await update.message.reply_text(
        f"✅ Statut publié !\n\n📝 {escape_html(message)}\n\n"
        f"👀 Visible 24 h sur ton téléphone, ton profil et le fil VoidGram.", parse_mode="HTML")


@require_registered
async def cmd_phone_event(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if len(context.args) < 2:
        await update.message.reply_text(
            "📅 <b>Ajouter un événement</b>\n\n"
            "Ouvre cette action depuis 🎮 Menu → 📱 Téléphone."
            "💡 Astuce : Utilise le bouton <b>Actions rapides</b> dans le menu pour un flux guidé.",
            parse_mode="HTML"
        )
        return

    text = " ".join(context.args)
    match = re.match(r'^"(.+?)"\s+(.+)$', text)
    if not match:
        await update.message.reply_text("❌ Titre invalide. Utilise des guillemets.")
        return
    title = match.group(1)
    rest = match.group(2)

    date_ts = None
    parts = rest.split()
    if len(parts) == 1 and parts[0].isdigit():
        date_ts = int(parts[0])
    elif len(parts) == 3 and all(p.isdigit() for p in parts):
        day, month, year = int(parts[0]), int(parts[1]), int(parts[2])
        try:
            date_ts = calendar.timegm((year, month, day, 0, 0, 0))
        except Exception:
            await update.message.reply_text("❌ Date invalide.")
            return
    else:
        await update.message.reply_text("❌ Format invalide.")
        return

    if date_ts < now():
        await update.message.reply_text("❌ La date doit être dans le futur.")
        return

    async with db_connection() as db:
        await db.execute(
            "INSERT INTO game_calendar (date, title, description, created_at, user_id) VALUES (?, ?, ?, ?, ?)",
            (date_ts, title, f"Événement de {user.full_name}", now(), user.id)
        )
        await db.commit()

    date_str = fmt_game_date(date_ts)
    await update.message.reply_text(f"✅ Événement <b>{title}</b> ajouté pour le {date_str}.", parse_mode="HTML")


@require_registered
async def cmd_phone_msg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if len(context.args) < 2:
        await update.message.reply_text(
            "✉️ <b>Envoyer un message</b>\n\n"
            "Ouvre cette action depuis 🎮 Menu → 📱 Téléphone.\n"
            "💡 Astuce : Utilise le bouton <b>Actions rapides</b> dans le menu pour un flux guidé.",
            parse_mode="HTML"
        )
        return

    target_id, target_name = await resolve_username_to_id(context.args[0])
    if not target_id:
        await update.message.reply_text("❌ Joueur introuvable.")
        return

    if target_id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas t'envoyer un message.")
        return

    message = " ".join(context.args[1:])
    if len(message) > 500:
        await update.message.reply_text("❌ Message trop long (max 500).")
        return

    async with db_connection() as db:
        await db.execute(
            "INSERT INTO phone_messages (from_id, to_id, message, created_at, read) VALUES (?, ?, ?, ?, 0)",
            (user.id, target_id, message, now())
        )
        await db.commit()

    await add_notification(target_id, f"📱 Message de {user.full_name} : {message[:100]}{'...' if len(message) > 100 else ''}")

    await update.message.reply_text(
        f"✅ Message envoyé à <b>{escape_html(target_name)}</b>\n"
        f"📝 <i>{escape_html(message[:100])}{'...' if len(message) > 100 else ''}</i>",
        parse_mode="HTML"
    )


# ============================================================
# ÉVÉNEMENTS ALÉATOIRES
# ============================================================
async def add_random_calendar_events():
    tomorrow_ts = now() + 86400
    day_start = tomorrow_ts - (tomorrow_ts % 86400)
    async with db_connection() as db:
        async with db.execute("SELECT id FROM game_calendar WHERE date = ?", (day_start,)) as cur:
            if await cur.fetchone():
                return
        events = [
            ("📈 Jour de paie", "Tous les joueurs reçoivent leur salaire."),
            ("🎉 Fête nationale", "Bonheur +10%."),
            ("🌪️ Tempête", "Jardins -20% récoltes."),
            ("🏛️ Élection", "Votez pour un nouveau leader."),
            ("🎪 Carnaval", "-20% sur les articles de luxe."),
            ("🔬 Découverte", "R&D +5%."),
            ("💥 Crash boursier", "Marché -15%."),
            ("🚀 Lancement spatial", "Voyages -30%."),
            ("🎭 Festival", "Prestige bonus."),
            ("☕ Journée du café", "Énergie gratuite."),
        ]
        chosen = random.choice(events)
        await db.execute(
            "INSERT INTO game_calendar (date, title, description, created_at) VALUES (?, ?, ?, ?)",
            (day_start, chosen[0], chosen[1], now())
        )
        await db.commit()


# ============================================================
# MAINTENANCE PÉRIODIQUE — ⭐ PATCH D.1
# ============================================================
async def process_phone_maintenance():
    """Supprime les statuts VoidGram de plus de 24h (appelé par le scheduler)."""
    async with db_connection() as db:
        await db.execute("DELETE FROM phone_status WHERE created_at < ?", (now() - 86400,))
        await db.commit()