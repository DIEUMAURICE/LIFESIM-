# handlers/investments.py — Version corrigée complète
import random
import aiosqlite
from types import SimpleNamespace
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from database import (
    DeferredReply,
    DB_PATH, get_user, increment_field,
    get_portfolio, get_market_price, update_market_price,
    db_connection, get_properties,
)
from utils.decorators import require_registered, cooldown, require_free
from utils.helpers import fmt, now, parse_amount
from utils.vip import add_xp
from utils.simulation import current_season, get_season_effect
from config import ASSETS, CITIES

# Handlers realestate (utilisés par le menu interactif)
from handlers.realestate import (
    cmd_proprietes, cmd_mesbiens, cmd_meslocations,
    get_residence, render_mesbiens,
)
from utils.input_flow import call_cmd
from handlers.missions import update_mission_progress
from utils.gametime import fmt_game_datetime
from utils.helpers import safe_edit as safe_edit_message
from utils.helpers import escape_html


# ✅ Fix #8/#9 : saisons -> source unique utils.simulation
_current_season = current_season


# ═══════════════════════════════════════════════════════════════════════
#                       HELPERS
# ═══════════════════════════════════════════════════════════════════════
def _find_asset(name: str) -> dict | None:
    for a in ASSETS:
        if a["name"].lower() == name.lower():
            return a
    return None


async def get_city_multipliers(user_id: int) -> dict:
    u = await get_user(user_id)
    city = u.get("location", "Paris") or "Paris"
    return CITIES.get(city, {
        "realestate_mult": 1.0, "vehicle_mult": 1.0,
        "salary_mult": 1.0, "market_mult": 1.0, "crime_mult": 1.0,
    })


async def _compute_local_price(user_id: int, global_price: float) -> int:
    """Calcule le prix local (ville + saison) pour un actif."""
    city_mult = await get_city_multipliers(user_id)
    season_fx = get_season_effect()
    mult = (
        city_mult.get("market_mult", 1.0)
        * season_fx.get("market_mult", 1.0)
    )
    return int(global_price * mult)


# ═══════════════════════════════════════════════════════════════════════
#                       MARCHÉ — /marche
# ═══════════════════════════════════════════════════════════════════════
@require_registered
async def cmd_marche(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    city_mult = await get_city_multipliers(user.id)
    season_fx = get_season_effect()
    market_mult = city_mult.get("market_mult", 1.0)
    season_market_mult = season_fx.get("market_mult", 1.0)

    season_name = _current_season()
    text = (
        f"📈 <b>Marché Boursier</b>\n"
        f"🍃 Saison : <b>{escape_html(season_name)}</b> "
        f"(×{season_market_mult:.2f} marché)\n\n"
    )

    for a in ASSETS:
        global_price = await get_market_price(a["name"])
        base = a["price"]
        local_price = int(global_price * market_mult * season_market_mult)
        change = ((global_price - base) / base) * 100 if base > 0 else 0
        arrow = "📈" if change >= 0 else "📉"
        text += (
            f"{escape_html(a['emoji'])} <b>{escape_html(a['name'])}</b>\n"
            f"  🌍 Mondial : {escape_html(fmt(int(global_price)))} {escape_html(arrow)} {change:+.1f}%\n"
            f"  🏙️ Local   : {escape_html(fmt(local_price))}\n"
            f"  📊 Volatilité : {escape_html(int(a['volatility'] * 100))}%\n\n"
        )
    text += "<i>Acheter, vendre et voir ton portefeuille : menu → 📈 Investissements (prix locaux).</i>"
    await update.message.reply_text(text, parse_mode="HTML")


# ═══════════════════════════════════════════════════════════════════════
#                       ACHAT ATOMIQUE
# ═══════════════════════════════════════════════════════════════════════
@require_registered
@require_free
@cooldown("buy_cooldown", 5, "⏳ Attends quelques secondes avant un autre ordre.")
async def cmd_acheteraction(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    if len(context.args) < 2:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 📈 Investissements."
        )
        return

    try:
        quantity = float(context.args[-1])
        asset_name = " ".join(context.args[:-1])
        if quantity <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Quantité invalide.")
        return

    asset = _find_asset(asset_name)
    if not asset:
        await update.message.reply_text(f"❌ Actif inconnu : {asset_name}\n/marche pour voir la liste.")
        return

    global_price = await get_market_price(asset["name"])
    local_price = await _compute_local_price(user.id, global_price)
    total_cost = int(local_price * quantity)

    if total_cost < 1000:
        await update.message.reply_text("❌ Montant minimum d'achat : 1 000 €A.")
        return

    try:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                    "WHERE user_id=? AND balance>=?",
                    (total_cost, total_cost, user.id, total_cost),
                )
                if debit.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Fonds insuffisants !")

                async with db.execute(
                    "SELECT quantity, avg_price FROM investments "
                    "WHERE user_id=? AND asset_name=?",
                    (user.id, asset["name"]),
                ) as cursor:
                    position = await cursor.fetchone()

                if position:
                    old_qty = position["quantity"]
                    old_avg = position["avg_price"]
                    new_qty = old_qty + quantity
                    new_avg = (old_qty * old_avg + quantity * local_price) / new_qty
                    await db.execute(
                        "UPDATE investments SET quantity=?, avg_price=? "
                        "WHERE user_id=? AND asset_name=?",
                        (new_qty, new_avg, user.id, asset["name"]),
                    )
                else:
                    await db.execute(
                        "INSERT INTO investments (user_id, asset_name, quantity, avg_price, bought_at) "
                        "VALUES (?,?,?,?,?)",
                        (user.id, asset["name"], quantity, local_price, now()),
                    )
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    # Impact marché si achat important
    if total_cost > 1_000_000:
        bump = min(0.05, total_cost / 100_000_000)
        await update_market_price(asset["name"], global_price * (1 + bump))

    await add_xp(user.id, 50)   # ✅ Fix #11 : boost VIP appliqué
    await update_mission_progress(user.id, "invest", 1)

    await update.message.reply_text(
        f"✅ <b>Achat exécuté !</b>\n\n"
        f"{escape_html(asset['emoji'])} <b>{escape_html(asset['name'])}</b>\n"
        f"📊 Quantité : {quantity:.3f}\n"
        f"💰 Prix unitaire (local) : {escape_html(fmt(local_price))}\n"
        f"💵 Total payé : {escape_html(fmt(total_cost))}\n\n"
        f"📈 Ton portefeuille s'enrichit !",
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════════
#                       VENTE ATOMIQUE
# ═══════════════════════════════════════════════════════════════════════
@require_registered
@require_free
@cooldown("sell_cooldown", 5, "⏳ Attends quelques secondes avant un autre ordre.")
async def cmd_vendreaction(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    if len(context.args) < 2:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 📈 Investissements."
        )
        return

    quantity_text = context.args[-1].lower()
    asset_name = " ".join(context.args[:-1])
    asset = _find_asset(asset_name)
    if not asset:
        await update.message.reply_text("❌ Actif inconnu. Utilise le menu pour voir la liste.")
        return

    global_price = await get_market_price(asset["name"])
    local_price = await _compute_local_price(user.id, global_price)

    try:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")

                async with db.execute(
                    "SELECT quantity, avg_price FROM investments "
                    "WHERE user_id=? AND asset_name=?",
                    (user.id, asset["name"]),
                ) as cursor:
                    position = await cursor.fetchone()

                if not position or position["quantity"] <= 0:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Tu ne possèdes pas cet actif.")

                if quantity_text in ("tout", "all"):
                    quantity = float(position["quantity"])
                else:
                    try:
                        quantity = float(quantity_text)
                    except ValueError:
                        await db.rollback()
                        raise DeferredReply(update.message.reply_text, "❌ Quantité invalide.")

                if quantity <= 0 or quantity > position["quantity"]:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Quantité indisponible.")

                remaining = position["quantity"] - quantity
                if remaining <= 0.000001:
                    claim = await db.execute(
                        "DELETE FROM investments "
                        "WHERE user_id=? AND asset_name=? AND quantity=?",
                        (user.id, asset["name"], position["quantity"]),
                    )
                else:
                    claim = await db.execute(
                        "UPDATE investments SET quantity=? "
                        "WHERE user_id=? AND asset_name=? AND quantity=?",
                        (remaining, user.id, asset["name"], position["quantity"]),
                    )
                if claim.rowcount != 1:
                    raise RuntimeError("Position modifiée pendant la vente, annulation.")

                revenue = int(local_price * quantity)
                profit = int((local_price - position["avg_price"]) * quantity)
                profit_percent = (
                    (local_price - position["avg_price"])
                    / max(0.000001, position["avg_price"])
                ) * 100

                await db.execute(
                    "UPDATE users SET balance=balance+?, total_earned=total_earned+? "
                    "WHERE user_id=?",
                    (revenue, revenue, user.id),
                )
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    if revenue > 1_000_000:
        drop = min(0.05, revenue / 100_000_000)
        await update_market_price(asset["name"], global_price * (1 - drop))

    await add_xp(user.id, 50)   # ✅ Fix #11 : boost VIP appliqué

    if profit >= 0:
        profit_text = f"📈 +{fmt(profit)} ({profit_percent:+.1f}%)"
    else:
        profit_text = f"📉 {fmt(profit)} ({profit_percent:+.1f}%)"

    await update.message.reply_text(
        f"✅ <b>Vente exécutée !</b>\n\n"
        f"{escape_html(asset['emoji'])} <b>{escape_html(asset['name'])}</b>\n"
        f"📊 Quantité vendue : {quantity:.3f}\n"
        f"💰 Prix de vente (local) : {escape_html(fmt(local_price))}\n"
        f"💵 Revenu total : {escape_html(fmt(revenue))}\n"
        f"📈 Plus-value : {escape_html(profit_text)}\n\n"
        f"{escape_html('🎉 Belle performance !' if profit > 0 else '😢 Vente à perte...' if profit < 0 else '😐 Équilibre.')}",
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════════
#                       PORTEFEUILLE
# ═══════════════════════════════════════════════════════════════════════
@require_registered
async def cmd_portefeuille(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    portfolio = await get_portfolio(user.id)
    city_mult = await get_city_multipliers(user.id)
    season_fx = get_season_effect()
    market_mult = city_mult.get("market_mult", 1.0)
    season_market_mult = season_fx.get("market_mult", 1.0)

    if not portfolio:
        await update.message.reply_text(
            "📊 Ton portefeuille est vide.\n"
        )
        return

    text = "📊 <b>Ton portefeuille d'investissement</b>\n\n"
    total_value = 0
    total_invested = 0

    for inv in portfolio:
        asset = _find_asset(inv["asset_name"])
        emoji = asset["emoji"] if asset else "📈"
        global_price = await get_market_price(inv["asset_name"])
        local_price = int(global_price * market_mult * season_market_mult)
        current_value = int(local_price * inv["quantity"])
        invested = int(inv["avg_price"] * inv["quantity"])
        pnl = current_value - invested
        pnl_pct = ((local_price - inv["avg_price"]) / max(0.001, inv["avg_price"])) * 100

        total_value += current_value
        total_invested += invested

        trend = "📈" if pnl >= 0 else "📉"
        text += (
            f"{escape_html(emoji)} <b>{escape_html(inv['asset_name'])}</b>\n"
            f"  Qté : {inv['quantity']:.3f} | Prix moy : {escape_html(fmt(int(inv['avg_price'])))}\n"
            f"  Valeur actuelle (locale) : {escape_html(fmt(current_value))}\n"
            f"  {escape_html(trend)} P&amp;L : {escape_html('+' if pnl >= 0 else '')}{escape_html(fmt(pnl))} ({pnl_pct:+.1f}%)\n\n"
        )

    total_pnl = total_value - total_invested
    total_pnl_pct = ((total_value - total_invested) / max(1, total_invested)) * 100

    text += (
        f"━━━━━━━━━━━━\n"
        f"💎 <b>Valeur totale (locale) : {escape_html(fmt(total_value))}</b>\n"
        f"💰 Investi : {escape_html(fmt(total_invested))}\n"
        f"{escape_html('📈' if total_pnl >= 0 else '📉')} P&amp;L total : {escape_html('+' if total_pnl >= 0 else '')}{escape_html(fmt(total_pnl))} ({total_pnl_pct:+.1f}%)"
    )
    await update.message.reply_text(text, parse_mode="HTML")


# ═══════════════════════════════════════════════════════════════════════
#                       HISTORIQUE
# ═══════════════════════════════════════════════════════════════════════
@require_registered
async def cmd_historique(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche l'historique des prix pour un actif donné."""
    if not context.args:
        names = ", ".join(a["name"] for a in ASSETS)
        await update.message.reply_text(
            f"📊 **Historique des prix**\n\nOuvre cette action depuis 🎮 Menu → 📈 Investissements.\nActifs : {names}"
        )
        return

    name = " ".join(context.args)
    asset = _find_asset(name)
    if not asset:
        await update.message.reply_text(f"❌ Actif introuvable : {name}")
        return

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT price, recorded_at FROM price_history "
            "WHERE asset_name=? ORDER BY recorded_at DESC LIMIT 20",
            (asset["name"],),
        ) as cur:
            rows = await cur.fetchall()

    current = await get_market_price(asset["name"])
    text = f"📊 <b>Historique — {escape_html(asset['name'])}</b>\n\nPrix actuel (mondial) : <b>{escape_html(fmt(current))}</b>\n\n"

    if not rows:
        text += "<i>Aucun historique disponible pour le moment.</i>"
    else:
        for r in rows[:10]:
            dt = fmt_game_datetime(r["recorded_at"], sep=" ")
            text += f"• [{escape_html(dt)}] {escape_html(fmt(r['price']))}\n"

    base = asset["price"]
    change = ((current - base) / base) * 100 if base > 0 else 0
    text += f"\n📉 Base d'origine : {escape_html(fmt(base))}\n"
    text += f"{escape_html('📈' if change >= 0 else '📉')} Variation totale : {change:+.1f}%"
    await update.message.reply_text(text, parse_mode="HTML")


# ═══════════════════════════════════════════════════════════════════════
#                       FLUCTUATION MARCHÉ (scheduler)
# ═══════════════════════════════════════════════════════════════════════
async def fluctuate_market():
    """Mise à jour périodique des prix du marché (appelé par scheduler)."""
    for asset in ASSETS:
        price = await get_market_price(asset["name"])
        volatility = asset["volatility"]
        change = random.gauss(0, volatility * 0.1)
        new_price = max(asset["price"] * 0.1, price * (1 + change))
        await update_market_price(asset["name"], round(new_price, 2))


# ═══════════════════════════════════════════════════════════════════════
#                       HELPERS UI INTERACTIVE
# ═══════════════════════════════════════════════════════════════════════


def encode_asset(name: str) -> str:
    return name.replace(" ", "_")


def decode_asset(encoded: str) -> str:
    return encoded.replace("_", " ")


def _fake_user_and_update(user_id: int, query_message):
    fake_user = SimpleNamespace(
        id=user_id,
        username="",
        full_name="Joueur",
        first_name="Joueur",
        last_name="",
        name="Joueur",
    )
    fake_update = SimpleNamespace(
        effective_user=fake_user,
        message=query_message,
        callback_query=None,
        effective_message=query_message,
    )
    return fake_update


async def show_marche_menu(query, user_id: int):
    text = "📈 <b>Marché Boursier</b>\n\n"
    keyboard = []

    for asset in ASSETS:
        price = await get_market_price(asset["name"])
        base = asset["price"]
        change = ((price - base) / base) * 100 if base > 0 else 0
        arrow = "📈" if change >= 0 else "📉"
        encoded = encode_asset(asset["name"])
        text += f"{escape_html(asset['emoji'])} <b>{escape_html(asset['name'])}</b> — {escape_html(fmt(int(price)))} {escape_html(arrow)} {change:+.1f}%\n"
        keyboard.append([
            InlineKeyboardButton(f"{asset['emoji']} Acheter", callback_data=f"marche_acheter_{encoded}"),
            InlineKeyboardButton("💰 Vendre", callback_data=f"marche_vendre_{encoded}"),
        ])

    keyboard.append([
        InlineKeyboardButton("📊 Mon portefeuille", callback_data="marche_portefeuille"),
        InlineKeyboardButton("📈 Historique", callback_data="marche_historique"),
    ])
    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="invest_menu")])

    await safe_edit_message(query, text, parse_mode="HTML",
                            reply_markup=InlineKeyboardMarkup(keyboard))


async def show_historique_menu(query, user_id: int):
    text = "📈 <b>Historique des prix</b>\n\nSélectionne un actif :\n\n"
    keyboard = []
    for asset in ASSETS:
        price = await get_market_price(asset["name"])
        base = asset["price"]
        change = ((price - base) / base) * 100 if base > 0 else 0
        arrow = "📈" if change >= 0 else "📉"
        text += f"{escape_html(asset['emoji'])} <b>{escape_html(asset['name'])}</b> — {escape_html(fmt(int(price)))} {escape_html(arrow)} {change:+.1f}%\n"
        encoded = encode_asset(asset["name"])
        keyboard.append([InlineKeyboardButton(
            f"{asset['emoji']} {asset['name']}",
            callback_data=f"marche_historique_{encoded}"
        )])
    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="marche_retour")])

    await safe_edit_message(query, text, parse_mode="HTML",
                            reply_markup=InlineKeyboardMarkup(keyboard))


async def show_acheter_action_menu(query, user_id: int, asset_encoded: str):
    asset_name = decode_asset(asset_encoded)
    price = await get_market_price(asset_name)
    u = await get_user(user_id)

    # ✅ Fix #17 : vérifier qu'on peut acheter AU MOINS 1 action avant de proposer
    if price <= 0:
        await safe_edit_message(
            query,
            f"❌ Prix indisponible pour {escape_html(asset_name)}. Réessaie plus tard.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Retour", callback_data="marche_retour")]
            ])
        )
        return

    max_qty = int(u['balance'] / price)
    if max_qty < 1:
        await safe_edit_message(
            query,
            f"❌ <b>Solde insuffisant</b>\n\n"
            f"📈 {escape_html(asset_name)} coûte <b>{escape_html(fmt(int(price)))}</b> par action.\n"
            f"💵 Ton solde : <b>{escape_html(fmt(u['balance']))}</b>\n\n"
            f"Travaille ou réduis tes dépenses pour investir.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Retour", callback_data="marche_retour")]
            ])
        )
        return

    text = f"📈 <b>Acheter {escape_html(asset_name)}</b>\n\n"
    text += f"💰 Prix unitaire : {escape_html(fmt(int(price)))}\n"
    text += f"💵 Ton solde : {escape_html(fmt(u['balance']))}\n"
    text += f"🎯 Max achetable : <b>{escape_html(max_qty)}</b> actions\n\n"
    text += "Choisis une quantité :"

    quantities = [1, 5, 10, 25, 50, 100]
    quantities = [q for q in quantities if q <= max_qty]

    keyboard = []
    for qty in quantities[:5]:
        total = int(price * qty)
        if total <= u['balance']:
            keyboard.append([InlineKeyboardButton(
                f"📈 {qty} actions ({fmt(total)})",
                callback_data=f"marche_acheter_qty_{asset_encoded}_{qty}"
            )])

    if max_qty > (max(quantities) if quantities else 0):
        keyboard.append([InlineKeyboardButton(
            f"💰 Max ({max_qty} actions)",
            callback_data=f"marche_acheter_qty_{asset_encoded}_{max_qty}"
        )])

    keyboard.append([InlineKeyboardButton(
        "✏️ Autre quantité",
        callback_data=f"marche_acheter_autre_{asset_encoded}"
    )])
    keyboard.append([
        InlineKeyboardButton("❌ Annuler", callback_data="marche_cancel"),
        InlineKeyboardButton("⬅️ Retour", callback_data="marche_retour"),
    ])

    if not keyboard:
        keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="marche_retour")])

    await safe_edit_message(query, text, parse_mode="HTML",
                            reply_markup=InlineKeyboardMarkup(keyboard))


async def show_vendre_action_menu(query, user_id: int, asset_encoded: str):
    asset_name = decode_asset(asset_encoded)
    price = await get_market_price(asset_name)
    portfolio = await get_portfolio(user_id)

    asset = next((p for p in portfolio if p["asset_name"] == asset_name), None)
    if not asset or asset["quantity"] <= 0:
        await safe_edit_message(
            query,
            f"❌ Tu ne possèdes pas d'actions {escape_html(asset_name)}.",
            parse_mode="HTML"
        )
        return

    text = f"📉 <b>Vendre {escape_html(asset_name)}</b>\n\n"
    text += f"💰 Prix unitaire : {escape_html(fmt(int(price)))}\n"
    text += f"📊 Quantité possédée : {asset['quantity']:.3f}\n"
    text += f"💵 Valeur totale : {escape_html(fmt(int(price * asset['quantity'])))}\n\n"
    text += "Choisis une quantité :"

    quantities = [1, 5, 10, 25, 50, 100]
    quantities = [q for q in quantities if q <= asset["quantity"]]

    keyboard = []
    for qty in quantities[:5]:
        total = int(price * qty)
        keyboard.append([InlineKeyboardButton(
            f"📈 {qty} actions ({fmt(total)})",
            callback_data=f"marche_vendre_qty_{asset_encoded}_{qty}"
        )])

    if asset["quantity"] > (max(quantities) if quantities else 0):
        keyboard.append([InlineKeyboardButton(
            f"📦 Tout vendre ({int(asset['quantity'])} actions)",
            callback_data=f"marche_vendre_qty_{asset_encoded}_{int(asset['quantity'])}"
        )])

    keyboard.append([InlineKeyboardButton(
        "✏️ Autre quantité",
        callback_data=f"marche_vendre_autre_{asset_encoded}"
    )])
    keyboard.append([
        InlineKeyboardButton("❌ Annuler", callback_data="marche_cancel"),
        InlineKeyboardButton("⬅️ Retour", callback_data="marche_retour"),
    ])

    if not keyboard:
        keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="marche_retour")])

    await safe_edit_message(query, text, parse_mode="HTML",
                            reply_markup=InlineKeyboardMarkup(keyboard))


# ─── Immobilier (boutons + formulaires de handlers/realestate.py) ─────────────
async def show_immobilier_menu(query, user_id: int):
    properties = await get_properties(user_id)
    u = await get_user(user_id)
    res = await get_residence(user_id)
    debt = sum(int(p.get("mortgage") or 0) for p in properties)

    text = "🏠 <b>Immobilier</b>\n\n"
    text += f"🏘️ Propriétés possédées : {len(properties)}\n"
    text += f"💰 Solde : {fmt(u['balance'])}\n"
    if debt:
        text += f"💳 Hypothèques restantes : {fmt(debt)}\n"
    if res:
        text += f"🛏️ Ton logement : {res['label']}\n"
    else:
        text += ("\n🏚️ <b>Tu es sans domicile !</b> Sans logement : repos réduit de moitié et "
                 "aucun service en entreprise ou en faction. Achète un bien, loue-en un ou prends une chambre.\n")
    text += "\n<i>Choisis une action :</i>"

    B = InlineKeyboardButton
    keyboard = [
        [B("🏪 Marché", callback_data="immobilier_marche"), B("🏠 Acheter", callback_data="fm:re_buy")],
        [B("🏦 Hypothèque", callback_data="fm:re_mortgage"),
         B("💳 Solder l'hypothèque", callback_data="fm:re_payoff")],
        [B("📋 Mes biens", callback_data="immobilier_mesbiens"), B("🔍 Détails", callback_data="fm:re_info")],
        [B("🔧 Entretenir", callback_data="fm:re_maintain"), B("💰 Vendre", callback_data="fm:re_sell")],
        [B("🤝 Louer mon bien", callback_data="fm:re_rent_out"),
         B("📄 Mes locations", callback_data="immobilier_meslocations")],
        [B("🚪 Quitter un logement", callback_data="fm:re_leave"),
         B("🛏️ Mon logement", callback_data="logement_home")],
        [B("⬅️ Retour", callback_data="invest_menu")],
    ]
    await safe_edit_message(query, text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))


# ═══════════════════════════════════════════════════════════════════════
#                       CALLBACK PRINCIPAL
# ═══════════════════════════════════════════════════════════════════════
async def investments_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    action = query.data
    user_id = query.from_user.id

    # ─── Menu principal ───
    if action == "invest_menu":
        from handlers.hub import open_zone; await open_zone(query, "invest"); return
    if action == "invest_marche":
        await show_marche_menu(query, user_id); return
    if action == "invest_immobilier":
        await show_immobilier_menu(query, user_id); return

    # ─── Retours ───
    if action == "marche_retour":
        await show_marche_menu(query, user_id); return
    if action == "marche_cancel":
        await safe_edit_message(query, "❌ Action annulée."); return
    if action == "immobilier_retour":
        await show_immobilier_menu(query, user_id); return

    # ─── Historique ───
    if action == "marche_historique":
        await show_historique_menu(query, user_id); return
    if action.startswith("marche_historique_"):
        asset_name = decode_asset(action.replace("marche_historique_", ""))
        fake_update = _fake_user_and_update(user_id, query.message)
        await cmd_historique(fake_update, SimpleNamespace(args=[asset_name]))
        return

    # ─── Achat quantité prédéfinie ───
    if action.startswith("marche_acheter_qty_"):
        rest = action.replace("marche_acheter_qty_", "")
        parts = rest.rsplit("_", 1)
        if len(parts) == 2:
            asset_encoded, qty_str = parts
            asset_name = decode_asset(asset_encoded)
            fake_update = _fake_user_and_update(user_id, query.message)
            await cmd_acheteraction(fake_update, SimpleNamespace(args=[asset_name, qty_str]))
        return

    if action.startswith("marche_vendre_qty_"):
        rest = action.replace("marche_vendre_qty_", "")
        parts = rest.rsplit("_", 1)
        if len(parts) == 2:
            asset_encoded, qty_str = parts
            asset_name = decode_asset(asset_encoded)
            fake_update = _fake_user_and_update(user_id, query.message)
            await cmd_vendreaction(fake_update, SimpleNamespace(args=[asset_name, qty_str]))
        return

    # ─── Achat/Vente quantité personnalisée ───
    if action.startswith("marche_acheter_autre_"):
        asset_name = decode_asset(action.replace("marche_acheter_autre_", ""))
        await safe_edit_message(
            query,
            f"📈 <b>Acheter {escape_html(asset_name)}</b>\n\nEnvoie le nombre d'actions (ex: 15).",
            parse_mode="HTML"
        )
        context.user_data['awaiting_marche_buy'] = asset_name
        return

    if action.startswith("marche_vendre_autre_"):
        asset_name = decode_asset(action.replace("marche_vendre_autre_", ""))
        await safe_edit_message(
            query,
            f"📉 <b>Vendre {escape_html(asset_name)}</b>\n\nEnvoie le nombre d'actions (ex: 15).",
            parse_mode="HTML"
        )
        context.user_data['awaiting_marche_sell'] = asset_name
        return

    # ─── Ouvrir menu acheter/vendre ───
    if action.startswith("marche_acheter_"):
        await show_acheter_action_menu(query, user_id, action.replace("marche_acheter_", "")); return
    if action.startswith("marche_vendre_"):
        await show_vendre_action_menu(query, user_id, action.replace("marche_vendre_", "")); return

    # ─── Portefeuille ───
    if action == "marche_portefeuille":
        fake_update = _fake_user_and_update(user_id, query.message)
        await cmd_portefeuille(fake_update, context); return

    # ─── Immobilier : vues sans saisie (les actions à saisie passent par les formulaires fm:re_*) ───
    if action == "immobilier_marche":
        await call_cmd(query, context, cmd_proprietes, []); return
    if action.startswith("immobilier_mesbiens"):
        tail = action.rsplit("_", 1)[-1]
        page = int(tail) if tail.isdigit() else 1
        text, kb = await render_mesbiens(user_id, page)
        await safe_edit_message(query, text, parse_mode="HTML", reply_markup=kb); return
    if action == "immobilier_meslocations":
        await call_cmd(query, context, cmd_meslocations, []); return

    # ─── Fallback ───
    await safe_edit_message(query, "❌ Action inconnue.", parse_mode="HTML")