# handlers/places.py — /aller, /position : se déplacer dans le monde RP
from utils.swallow import swallowed
import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from config import LOCATIONS
from utils.decorators import require_registered
from utils.helpers import fmt_time
from utils.location import (
    get_position, location_label, plan_options, start_travel, distance_km,
)
from utils.helpers import send_or_edit as _send

logger = logging.getLogger(__name__)


async def _show_map(update: Update, user_id: int):
    pos = await get_position(user_id)
    if pos["in_transit"]:
        text = (f"🚶 <b>En déplacement</b>\n{location_label(pos['travel_from'])} ➜ "
                f"{location_label(pos['travel_to'])}\n"
                f"⏳ Arrivée dans <b>{fmt_time(pos['remaining'])}</b>")
        await _send(update, text, InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔄 Actualiser", callback_data="loc_map")]]))
        return
    here = pos["location"]
    rows, row = [], []
    for key in LOCATIONS:
        if key == here:
            continue
        row.append(InlineKeyboardButton(
            f"{LOCATIONS[key]['emoji']} {LOCATIONS[key]['name']} ({distance_km(here, key):g} km)",
            callback_data=f"loc_go:{key}"))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton("🎮 Menu principal", callback_data="hub:home")])
    text = f"📍 Tu es ici : <b>{location_label(here)}</b>\nOù veux-tu aller ?"
    await _send(update, text, InlineKeyboardMarkup(rows))


@require_registered
async def cmd_aller(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await _show_map(update, update.effective_user.id)


@require_registered
async def cmd_position(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pos = await get_position(update.effective_user.id)
    if pos["in_transit"]:
        await _show_map(update, update.effective_user.id)
        return
    await update.effective_message.reply_text(
        f"📍 Tu es ici : <b>{location_label(pos['location'])}</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🧭 Se déplacer", callback_data="loc_map")]]))


async def _show_modes(update: Update, user_id: int, dest: str):
    pos = await get_position(user_id)
    if pos["in_transit"]:
        await _show_map(update, user_id)
        return
    opts = await plan_options(user_id, pos["location"], dest)
    lines = [f"🧭 <b>{location_label(pos['location'])} ➜ {location_label(dest)}</b> "
             f"({distance_km(pos['location'], dest):g} km)\n"]
    rows = []
    for o in opts:
        cost = []
        if o["energy"]:
            cost.append(f"⚡-{o['energy']}")
        if o["fuel"]:
            cost.append(f"⛽-{o['fuel']}")
        if o.get("money"):
            cost.append(f"💶-{o['money']:,}")
        detail = f"{fmt_time(o['duration'])}" + (f" · {' '.join(cost)}" if cost else "")
        if o["ok"]:
            lines.append(f"{o['label']} — {detail}")
            rows.append([InlineKeyboardButton(f"{o['label']} · {fmt_time(o['duration'])}" + (f" · 💶{o['money']:,}" if o.get("money") else ""),
                                              callback_data=f"loc_do:{dest}:{o['mode']}")])
        else:
            lines.append(f"{o['label']} — ❌ {o['why']}")
    rows.append([InlineKeyboardButton("⬅️ Retour", callback_data="loc_map")])
    await _send(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def places_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    user_id = update.effective_user.id
    data = q.data or ""
    try:
        if data == "loc_map":
            await q.answer()
            await _show_map(update, user_id)
        elif data.startswith("loc_go:"):
            dest = data.split(":", 1)[1]
            await q.answer()
            if dest in LOCATIONS:
                await _show_modes(update, user_id, dest)
        elif data.startswith("loc_do:"):
            _, dest, mode = data.split(":", 2)
            ok, msg = await start_travel(user_id, dest, mode)
            await q.answer("🚶 En route !" if ok else "❌", show_alert=not ok)
            if ok:
                await _send(update, f"🚶 <b>Départ</b> vers {location_label(dest)}\n{msg}\n"
                                    f"🔔 Tu seras notifié à l'arrivée.")
            else:
                await _send(update, f"❌ {msg}",
                            InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="loc_map")]]))
        else:
            await q.answer()
    except Exception:
        logger.exception("places_callback")
        try:
            await q.answer("Erreur, réessaie.", show_alert=True)
        except Exception:
            swallowed('handlers/places.py')
