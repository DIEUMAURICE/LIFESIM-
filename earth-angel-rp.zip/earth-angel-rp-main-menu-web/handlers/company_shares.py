"""Entreprises — capital : parts, achat/vente, dividendes, transfert.

L'achat, la vente et les dividendes délèguent à `gameplay/companies.py`, le même service pur que
`webapp/routers/companies_router.py` — aucune règle n'est recalculée ici, et chaque opération
est désormais atomique (une seule transaction) là où l'ancienne implémentation enchaînait
plusieurs commits séparés."""
from telegram.ext import ContextTypes
from database import get_company_by_name, get_user_company, log_company_action, db_connection
from telegram import Update
import gameplay.companies as companies_service
from utils.helpers import fmt, escape_md, escape_html
from utils.decorators import require_registered, require_free


@require_registered
@require_free
async def cmd_parts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company:
        await update.message.reply_text("❌ Tu n'es pas dans une entreprise.")
        return
    shareholders = await companies_service.shareholders(company["company_id"])
    async with db_connection() as db:
        async with db.execute(
            "SELECT COUNT(*) FROM company_members WHERE company_id=?", (company["company_id"],)
        ) as cur:
            emp_count = (await cur.fetchone())[0]
    total_shares = sum(s["shares"] for s in shareholders) or 1
    rd_level = company.get("rd_level", 0)
    share_value = companies_service.share_price(company["treasury"], company["reputation"], rd_level)
    market_cap = total_shares * share_value
    text = f"📊 <b>Parts — {escape_html(escape_md(company['name']))}</b>\n\n"
    text += f"💰 Trésorerie : {escape_html(fmt(company['treasury']))}\n"
    text += f"👥 Employés : {escape_html(emp_count)}\n"
    text += f"⭐ Réputation : {escape_html(company['reputation'])}/100\n"
    text += f"🔬 R&amp;D : Niveau {escape_html(rd_level)}\n\n"
    text += f"<b>Valorisation estimée</b>\n"
    text += f"  • Valeur par part : {escape_html(fmt(share_value))}\n"
    text += f"  • Capitalisation : {escape_html(fmt(market_cap))}\n\n"
    text += f"<b>Actionnaires</b>\n"
    for s in shareholders[:10]:
        pct = s["shares"] / total_shares * 100
        text += f"  • {escape_html(escape_md(s['full_name']))} : {escape_html(s['shares'])} parts ({pct:.1f}%)\n"
    if len(shareholders) > 10:
        text += f"  <i>... et {escape_html(len(shareholders)-10)} autres</i>"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
async def cmd_acheterparts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if len(context.args) < 1:
        await update.message.reply_text(
            "📈 **Achat de parts**\n\n"
            "Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises."
            "Ou si tu es déjà dans une entreprise, le 🎮 Menu principal achète des parts de ton entreprise.\n\n"
            "Le prix par part dépend de la trésorerie, réputation et R&D."
        )
        return
    if len(context.args) == 1:
        try:
            shares = int(context.args[0])
            company = await get_user_company(user.id)
            if not company:
                await update.message.reply_text("❌ Tu n'es dans aucune entreprise. Précise le nom de l'entreprise cible.")
                return
        except ValueError:
            await update.message.reply_text("❌ Le nombre doit être un entier positif.")
            return
    else:
        try:
            shares = int(context.args[-1])
            company_name = " ".join(context.args[:-1])
            company = await get_company_by_name(company_name)
            if not company:
                await update.message.reply_text(f"❌ Entreprise '{company_name}' introuvable.")
                return
        except ValueError:
            await update.message.reply_text("❌ Le nombre doit être un entier positif.")
            return
    if shares <= 0:
        await update.message.reply_text("❌ Nombre invalide.")
        return
    rd_level = company.get("rd_level", 0)
    result = await companies_service.buy_shares(
        user.id, company["company_id"], company["treasury"], company["reputation"], rd_level, shares
    )
    if result.get("capped"):
        await update.message.reply_text("⚠️ Le prix par part a été plafonné à 10 milliards pour éviter un dépassement.")
    if not result["ok"]:
        if result["reason"] == "total_too_large":
            await update.message.reply_text("❌ Le coût total est trop élevé. Contactez un administrateur.")
        elif result["reason"] == "insufficient_funds":
            await update.message.reply_text(
                f"❌ Fonds insuffisants. Coût : {escape_html(fmt(result['total_cost']))}", parse_mode="HTML"
            )
        else:
            await update.message.reply_text("❌ Nombre invalide.")
        return
    await log_company_action(
        company["company_id"], "achat_parts", user.id, f"{shares} parts ({fmt(result['total_cost'])})"
    )
    await update.message.reply_text(
        f"📈 <b>Achat de parts réussi !</b>\n\n"
        f"🏢 Entreprise : <b>{escape_html(escape_md(company['name']))}</b>\n"
        f"📊 {escape_html(shares)} parts à {escape_html(fmt(result['price_per_share']))} chacune.\n"
        f"💰 Total : {escape_html(fmt(result['total_cost']))}\n"
        f"💎 Tu détiens maintenant {escape_html(result['shares_owned'])} parts de cette entreprise.\n\n"
        f"<i>L'entreprise reçoit cet argent pour se développer.</i>",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_vendreparts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if len(context.args) < 1:
        await update.message.reply_text(
            "📉 **Vente de parts**\n\n"
            "Ouvre cette action depuis 🎮 Menu → 🏢 Entreprises."
            "Ou si tu es déjà dans une entreprise, le 🎮 Menu principal vend des parts de ton entreprise.\n\n"
            "Le prix de vente est le même que le prix d'achat (basé sur la valeur actuelle)."
        )
        return
    if len(context.args) == 1:
        try:
            shares = int(context.args[0])
            company = await get_user_company(user.id)
            if not company:
                await update.message.reply_text("❌ Tu n'es dans aucune entreprise. Précise le nom de l'entreprise cible.")
                return
        except ValueError:
            await update.message.reply_text("❌ Le nombre doit être un entier positif.")
            return
    else:
        try:
            shares = int(context.args[-1])
            company_name = " ".join(context.args[:-1])
            company = await get_company_by_name(company_name)
            if not company:
                await update.message.reply_text(f"❌ Entreprise '{company_name}' introuvable.")
                return
        except ValueError:
            await update.message.reply_text("❌ Le nombre doit être un entier positif.")
            return
    if shares <= 0:
        await update.message.reply_text("❌ Nombre invalide.")
        return
    rd_level = company.get("rd_level", 0)
    result = await companies_service.sell_shares(
        user.id, company["company_id"], company["treasury"], company["reputation"], rd_level, shares
    )
    if result.get("capped"):
        await update.message.reply_text("⚠️ Le prix par part a été plafonné à 10 milliards pour éviter un dépassement.")
    if not result["ok"]:
        if result["reason"] == "no_shares":
            await update.message.reply_text(
                f"❌ Tu ne possèdes aucune part de <b>{escape_html(escape_md(company['name']))}</b>.", parse_mode="HTML"
            )
        elif result["reason"] == "not_enough_shares":
            await update.message.reply_text(
                f"❌ Tu ne possèdes que {escape_html(result['current_shares'])} parts de cette entreprise.",
                parse_mode="HTML",
            )
        elif result["reason"] == "total_too_large":
            await update.message.reply_text("❌ La valeur totale est trop élevée. Contactez un administrateur.")
        else:
            await update.message.reply_text("❌ Nombre invalide.")
        return
    await log_company_action(
        company["company_id"], "vente_parts", user.id, f"{shares} parts ({fmt(result['total_value'])})"
    )
    await update.message.reply_text(
        f"💰 <b>Vente de parts réussie !</b>\n\n"
        f"🏢 Entreprise : <b>{escape_html(escape_md(company['name']))}</b>\n"
        f"📉 {escape_html(shares)} parts vendues à {escape_html(fmt(result['price_per_share']))} chacune.\n"
        f"💵 Reçu : {escape_html(fmt(result['total_value']))}\n"
        f"📊 Il te reste {escape_html(result['shares_remaining'])} parts de cette entreprise.",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_dividendes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Seul le PDG peut verser des dividendes.")
        return
    percent = 10
    if context.args and context.args[0].replace("%", "").isdigit():
        percent = int(context.args[0].replace("%", ""))
        percent = max(0, min(100, percent))
    result = await companies_service.distribute_dividends(company["company_id"], company["treasury"], percent)
    if not result["ok"]:
        if result["reason"] == "treasury_too_low":
            await update.message.reply_text(
                f"💰 Trésorerie trop faible pour verser {result['percent']}% de dividendes significatifs."
            )
        else:
            await update.message.reply_text("❌ Aucune part en circulation.")
        return
    await log_company_action(
        company["company_id"], "dividendes", user.id, f"{result['percent']}% ({fmt(result['dividend_total'])})"
    )
    await update.message.reply_text(
        f"💎 <b>Dividendes versés !</b>\n\n"
        f"📊 {escape_html(result['percent'])}% de la trésorerie, soit {escape_html(fmt(result['dividend_total']))}\n"
        f"👥 Réparti entre {escape_html(result['shareholder_count'])} actionnaires.\n"
        f"🏦 Nouvelle trésorerie : {escape_html(fmt(company['treasury'] - result['dividend_total']))}",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_transfert_entreprise(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    company = await get_user_company(user.id)
    if not company or company["owner_id"] != user.id:
        await update.message.reply_text("❌ Seul le PDG peut transférer l'entreprise.")
        return
    if not update.message.reply_to_message:
        await update.message.reply_text("❌ Réponds au message du joueur à qui tu veux transférer l'entreprise.")
        return
    target = update.message.reply_to_message.from_user
    if target.id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas te transférer l'entreprise à toi-même.")
        return
    result = await companies_service.transfer_ownership(user.id, company["company_id"], target.id)
    if not result["ok"]:
        if result["reason"] == "target_not_member":
            await update.message.reply_text(f"❌ {target.full_name} n'est pas employé dans cette entreprise.")
        else:
            await update.message.reply_text("❌ Seul le PDG peut transférer l'entreprise.")
        return
    await update.message.reply_text(
        f"👑 **Transfert d'entreprise réussi !**\n\n"
        f"**{company['name']}** est désormais dirigée par **{target.full_name}**.\n"
        f"Tu es devenu 'Ex-PDG'."
    )
