# handlers/crime.py
import random
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import Outbox, DeferredReply, DB_PATH, get_user, update_balance, update_field, increment_field, db_connection
from utils.decorators import require_registered, require_free
from utils.helpers import fmt, fmt_time, now, roll_success, parse_amount, escape_html
from utils.aesthetics import card
from utils.vip import chance_boost_bonus, add_xp
from config import CRIMES, BAIL_COST_RATIO, LAWYER_COST, CRIME_COOLDOWN
from handlers.missions import update_mission_progress
from handlers.vehicles import get_active_vehicle


async def add_random_item(user_id: int, min_rarity: str = "common", max_rarity: str = "legendary"):
    """Ajoute un item aléatoire à l'inventaire du joueur."""
    rarity_order = ["common", "rare", "epic", "legendary"]
    min_idx = rarity_order.index(min_rarity)
    max_idx = rarity_order.index(max_rarity)
    possible = [r for r in rarity_order if min_idx <= rarity_order.index(r) <= max_idx]
    chosen_rarity = random.choice(possible)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT item_id, name, emoji, rarity FROM items WHERE rarity = ? ORDER BY RANDOM() LIMIT 1",
            (chosen_rarity,)
        ) as cur:
            item = await cur.fetchone()
        if not item:
            return None

        async with db.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?",
            (user_id, item["item_id"])
        ) as cur2:
            existing = await cur2.fetchone()
        if existing:
            await db.execute(
                "UPDATE inventory SET quantity = quantity + 1 WHERE user_id = ? AND item_id = ?",
                (user_id, item["item_id"])
            )
        else:
            await db.execute("""
                INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, item["item_id"], "loot", item["name"], 1, now()))
        await db.commit()
    return f"{item['emoji']} {item['name']} ({item['rarity']})"


# ═══════════════════════════════════════════════════════════════════
#              ⚔️ LISTE DES CRIMES (boutons d'action)
# ═══════════════════════════════════════════════════════════════════
async def show_crime_list(query, user_id: int):
    u = await get_user(user_id)
    last_crime = u.get("last_crime", 0)
    if now() - last_crime < CRIME_COOLDOWN:
        rem = CRIME_COOLDOWN - (now() - last_crime)
        await safe_edit(
            query,
            f"⏳ Calme-toi ! Attends <b>{fmt_time(rem)}</b>.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
        )
        return

    if u.get("prison_until", 0) > now():
        await safe_edit(
            query,
            "⛓️ Tu es en prison !",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
        )
        return

    body = [
        "🎯 <b>Choisis un crime :</b>",
        "",
    ]

    keyboard = []
    for i, (crime_name, data) in enumerate(CRIMES.items()):
        min_r, max_r = data["reward"]
        # Indicateur de risque
        chance = int(data["success"] * 100)
        risk_icon = "🟢" if chance >= 60 else "🟡" if chance >= 45 else "🟠" if chance >= 30 else "🔴"

        keyboard.append([
            InlineKeyboardButton(
                f"{risk_icon} {crime_name} · {chance}% · {fmt(min_r)}–{fmt(max_r)}",
                callback_data=f"crime_do_{i}"
            )
        ])

    keyboard.append([InlineKeyboardButton("🎯 Crimes sur des joueurs", callback_data="ord:pc")])
    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")])

    await safe_edit(
        query,
        "⚔️ <b>CRIMES DISPONIBLES</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_commit_crime(query, user_id: int, crime_index: int):
    crime_names = list(CRIMES.keys())
    if crime_index < 0 or crime_index >= len(crime_names):
        await safe_edit(query, "❌ Crime invalide.")
        return

    crime_name = crime_names[crime_index]
    data = CRIMES[crime_name]
    u = await get_user(user_id)

    if u.get("health", 100) <= 0 and not u.get("god_mode"):
        await safe_edit(query, "💀 Ta santé est à zéro : tu es hors d'état d'agir. Soigne-toi d'abord.", parse_mode="HTML",
                        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]]))
        return
    from utils.ordre import restraint_reason
    restrained = await restraint_reason(user_id)
    if restrained:
        await safe_edit(query, f"⛓️ Impossible : tu es {restrained}", parse_mode="HTML",
                        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]]))
        return

    # Vérifs
    if u.get("prison_until", 0) > now():
        await safe_edit(
            query,
            "⛓️ Tu es en prison !",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
        )
        return

    if now() - u.get("last_crime", 0) < CRIME_COOLDOWN:
        rem = CRIME_COOLDOWN - (now() - u.get("last_crime", 0))
        await safe_edit(
            query,
            f"⏳ Attends encore <b>{fmt_time(rem)}</b>.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
        )
        return

    from handlers.gangs import require_gang, NO_GANG_CRIME_TEXT
    if not await require_gang(user_id):
        await safe_edit(
            query, NO_GANG_CRIME_TEXT,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
        )
        return

    # Calcul du succès
    from database import get_skill
    discretion = await get_skill(user_id, "Discrétion")
    agility = await get_skill(user_id, "Agilité")
    skill_bonus = (discretion * 0.02) + (agility * 0.01)
    karma_bonus = max(-0.1, min(0.1, u.get("karma", 0) / 1000))

    # ⭐ Boost chance VIP
    chance_boost = chance_boost_bonus(u)

    gang_bonus = 0
    async with db_connection() as db:
        async with db.execute(
            "SELECT g.reputation FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
            (user_id,)
        ) as cur:
            gang_row = await cur.fetchone()
        if gang_row:
            gang_bonus = (gang_row[0] - 50) / 200

    # 🔫 Arme équipée : bonus de chance + munitions consommées ; certains gros crimes exigent une arme à feu
    from config import WEAPON_REQUIRED_CRIMES
    from utils import weapons
    weapon_bonus, weapon_msg, weapon_ok = await weapons.use_for_action(
        user_id, need_firearm=crime_name in WEAPON_REQUIRED_CRIMES)
    if not weapon_ok:
        await safe_edit(query, f"🔫 <b>{crime_name}</b> : {weapon_msg}", parse_mode="HTML",
                        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🕶️ Marché noir", callback_data="wp:shop")],
                                                           [InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]]))
        return

    success = roll_success(data["success"], skill_bonus + gang_bonus + chance_boost + weapon_bonus, karma_bonus)

    await update_field(user_id, "last_crime", now())
    await increment_field(user_id, "crimes_done")

    active_vehicle = await get_active_vehicle(user_id)
    vehicle_speed = active_vehicle.get("speed", 0) if active_vehicle else 0

    prison_time = 0
    arrested = False

    if success:
        min_r, max_r = data["reward"]
        reward = random.randint(min_r, max_r)
        from handlers.gangs import split_crime_reward
        reward = await split_crime_reward(user_id, reward)    # une part du butin va au coffre du gang
        await increment_field(user_id, "karma", data["karma"])
        await increment_field(user_id, "crimes_success")
        # ⭐ Utilisation de add_xp (boost XP appliqué automatiquement)
        await add_xp(user_id, 150)
        await update_mission_progress(user_id, "crime", 1)

        # Fuite : plus d'arrestation immédiate. Le butin est empoché ; la police ouvrira une enquête
        # après un délai (mini-jeu des enquêteurs) — voir utils/ordre.py. « Se cacher » rallonge le délai.
        from utils import ordre
        await ordre.register_bot_crime(user_id, crime_name, reward)
        async with db_connection() as db:
            await db.execute(
                "INSERT INTO crime_log (user_id, crime_type, success, reward, timestamp) VALUES (?,?,1,?,?)",
                (user_id, crime_name, reward, now())
            )
            await db.commit()

        # Loot
        loot_msg = ""
        if random.random() < 0.2:
            if crime_name in ("Hold-up banque", "Cybercriminalité"):
                item = await add_random_item(user_id, "rare", "legendary")
            elif crime_name in ("Braquage", "Trafic drogue"):
                item = await add_random_item(user_id, "common", "epic")
            else:
                item = await add_random_item(user_id, "common", "rare")
            if item:
                loot_msg = f"\n\n🎁 Objet trouvé : {item}"

        crime_flavor = {
            "Pickpocket":      "Tu glisses ta main dans une poche… Jackpot ! 🤫",
            "Vol à l'étalage": "Tu sors du magasin sans te faire remarquer 😏",
            "Cambriolage":     "La maison était vide — parfait ! 🏠💨",
            "Arnaque":         "L'idiot a mordu à l'hameçon ! 🎣",
            "Braquage":        "Le coffre était plein ! Tu fuis dans une voiture volée 🚗💨",
            "Trafic drogue":   "La marchandise est livrée sans accroc 💊",
            "Cybercriminalité":"Les virements sont passés avant l'alerte 💻",
            "Hold-up banque":  "La police aux trousses mais tu t'en sors ! 🏦🔫",
        }

        if arrested:
            body = [
                f"✅ <b>{crime_name} — RÉUSSI</b>",
                f"<i>{crime_flavor.get(crime_name, 'Mission accomplie !')}</i>",
                "",
                f"💰 Butin : <b>{fmt(reward)}</b>",
                f"🌟 Karma : <b>{data['karma']:+d}</b>",
                f"✨ +150 XP{loot_msg}",
                "",
                f"🚨 <b>Mais tu es pris en fuite !</b>",
                f"⛓️ Prison : <b>{fmt_time(prison_time)}</b>",
                f"<i>Utilise le menu pour sortir plus tôt</i>",
            ]
            kb = [
                [InlineKeyboardButton("💰 Payer la caution", callback_data="crime_caution_info")],
                [InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")],
            ]
        else:
            body = [
                f"✅ <b>{crime_name} — RÉUSSI</b>",
                f"<i>{crime_flavor.get(crime_name, 'Mission accomplie !')}</i>",
                "",
                f"💰 Butin : <b>{fmt(reward)}</b>",
                f"🌟 Karma : <b>{data['karma']:+d}</b>",
                f"✨ +150 XP{loot_msg}",
            ]
            from config import ORDRE
            body += [
                "",
                f"🏃 <b>Tu t'enfuis…</b> La police ouvrira une enquête dans ~<b>{ORDRE['flee_delay'] // 60} min</b>.",
                "<i>Les enquêteurs devront réussir un mini-jeu très difficile pour t'arrêter.</i>",
            ]
            kb = [
                [InlineKeyboardButton("🫥 Se cacher", callback_data="ord:hide")],
                [InlineKeyboardButton("⚔️ Autre crime", callback_data="crime_list")],
                [InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")],
            ]

    else:
        from utils import ordre
        prison_time = ordre.jail_for_bot_crime(crime_name)      # 15 à 30 min selon la gravité (max 60 min)
        await update_field(user_id, "prison_until", now() + prison_time)
        await ordre.register_arrest(user_id, crime_name, "crime", prison_time)

        async with db_connection() as db:
            await db.execute(
                "INSERT INTO crime_log (user_id, crime_type, success, jail_time, timestamp) VALUES (?,?,0,?,?)",
                (user_id, crime_name, prison_time, now())
            )
            await db.commit()

        fails = [
            "La police t'attendait… Tu te fais menotter 👮",
            "Un témoin a tout vu et appelé le 17 ! 📞",
            "Une alarme silencieuse te trahit 🚨",
            "Ton complice t'a dénoncé ! 🐀",
            "Tu as laissé des empreintes partout 🔍",
            "Un passant t'a filmé en direct 📱",
        ]

        caution = int((data["reward"][0] + data["reward"][1]) / 2 * BAIL_COST_RATIO)

        body = [
            f"❌ <b>{crime_name} — ÉCHEC</b>",
            f"<i>{random.choice(fails)}</i>",
            "",
            f"⛓️ Prison : <b>{fmt_time(prison_time)}</b>",
            "",
            f"💡 <b>Options :</b>",
            f"  • Payer <b>{fmt(caution)}</b> de caution",
            f"  • Passer au tribunal (risqué)",
            f"  • Prendre un avocat (<b>{fmt(LAWYER_COST)}</b>)",
        ]
        kb = [
            [InlineKeyboardButton("💰 Payer la caution", callback_data="crime_caution_info")],
            [InlineKeyboardButton("⚖️ Tribunal", callback_data="crime_tribunal_info"),
             InlineKeyboardButton("👨‍⚖️ Avocat", callback_data="crime_avocat_info")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")],
        ]

    if weapon_msg:
        body = [*body, "", weapon_msg]
    await safe_edit(
        query,
        card("⚔️ RÉSULTAT", body, icon="⚔️", style="stars" if success else "thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(kb),
    )


# ═══════════════════════════════════════════════════════════════════
#              💰 CAUTION — affichage + paiement
# ═══════════════════════════════════════════════════════════════════
async def show_caution_info(query, user_id: int):
    u = await get_user(user_id)
    if u.get("prison_until", 0) <= now():
        await safe_edit(
            query,
            "✅ Tu n'es pas en prison !",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
        )
        return

    remaining = u["prison_until"] - now()
    caution = int(remaining / 3600 * 5_000)

    body = [
        f"⏳ Temps restant : <b>{fmt_time(remaining)}</b>",
        f"💰 Caution requise : <b>{fmt(caution)}</b>",
        f"💵 Ton solde : <b>{fmt(u['balance'])}</b>",
    ]

    if u["balance"] >= caution:
        keyboard = [
            [InlineKeyboardButton(f"💰 Payer {fmt(caution)}", callback_data="crime_caution_pay")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")],
        ]
    else:
        body.append("")
        body.append("❌ <b>Fonds insuffisants pour payer la caution</b>")
        keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]]

    await safe_edit(
        query,
        card("💰 CAUTION", body, icon="💰", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_pay_caution(query, user_id: int):
    u = await get_user(user_id)
    if u.get("prison_until", 0) <= now():
        await safe_edit(query, "✅ Tu n'es pas en prison !")
        return

    remaining = u["prison_until"] - now()
    caution = int(remaining / 3600 * 5_000)

    if u["balance"] < caution:
        await safe_edit(query, f"❌ Fonds insuffisants. Caution : {fmt(caution)}")
        return

    await update_balance(user_id, -caution, sink="amendes")
    await update_field(user_id, "prison_until", 0)

    await safe_edit(
        query,
        f"🔓 <b>LIBERTÉ !</b>\n\n"
        f"💰 Caution payée : <b>{fmt(caution)}</b>\n\n"
        f"<i>Tu sors par la porte de derrière…</i>\n"
        f"⚠️ Évite les crimes pendant quelques temps !",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              ⚖️ TRIBUNAL
# ═══════════════════════════════════════════════════════════════════
async def show_tribunal_info(query, user_id: int):
    u = await get_user(user_id)
    if u.get("prison_until", 0) <= now():
        await safe_edit(
            query,
            "✅ Tu n'es pas en prison !",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
        )
        return

    remaining = u["prison_until"] - now()
    karma = u.get("karma", 0)

    if karma >= 100:
        chance = 60
    elif karma >= 0:
        chance = 40
    elif karma >= -100:
        chance = 25
    else:
        chance = 10

    body = [
        f"⏳ Temps restant : <b>{fmt_time(remaining)}</b>",
        f"🌟 Ton karma : <b>{karma:+d}</b>",
        "",
        f"⚖️ Chance d'acquittement estimée : <b>{chance}%</b>",
        "",
        "<i>Trois issues possibles :</i>",
        "  ✅ <b>Acquitté</b> — libre immédiatement (+5 karma)",
        "  ⚠️ <b>Peine réduite</b> — 50% en moins",
        "  ❌ <b>Condamné</b> — peine allongée + amende + -10 karma",
    ]

    keyboard = [
        [InlineKeyboardButton("⚖️ PASSER AU TRIBUNAL", callback_data="crime_tribunal_do")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")],
    ]

    await safe_edit(
        query,
        card("⚖️ TRIBUNAL", body, icon="⚖️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_tribunal(query, user_id: int):
    u = await get_user(user_id)
    if u.get("prison_until", 0) <= now():
        await safe_edit(query, "✅ Tu n'es pas en prison !")
        return

    remaining = u["prison_until"] - now()
    karma = u.get("karma", 0)
    if karma >= 100:
        acquit_chance = 0.60
    elif karma >= 0:
        acquit_chance = 0.40
    elif karma >= -100:
        acquit_chance = 0.25
    else:
        acquit_chance = 0.10

    roll = random.random()

    if roll < acquit_chance:
        await update_field(user_id, "prison_until", 0)
        await increment_field(user_id, "karma", 5)
        body = [
            "⚖️ <b>ACQUITTÉ !</b>",
            "<i>Le juge a reconnu ton bon comportement.</i>",
            "",
            "🎉 Tu es libre !",
            "🌟 +5 Karma",
        ]
    elif roll < acquit_chance + 0.3:
        new_time = now() + remaining // 2
        await update_field(user_id, "prison_until", new_time)
        body = [
            "⚖️ <b>Peine réduite !</b>",
            "<i>Le juge est clément.</i>",
            "",
            f"⏳ Peine réduite de moitié : <b>{fmt_time(remaining // 2)}</b>",
        ]
    else:
        extra = random.randint(1, 3) * 3600
        new_time = u["prison_until"] + extra
        fine = random.randint(10_000, 100_000)
        await update_field(user_id, "prison_until", new_time)
        if u["balance"] >= fine:
            await update_balance(user_id, -fine, sink="amendes")
        await increment_field(user_id, "karma", -10)
        body = [
            "⚖️ <b>CONDAMNÉ !</b>",
            "<i>Le juge était de mauvaise humeur…</i>",
            "",
            f"⛓️ Peine allongée de <b>{fmt_time(extra)}</b>",
            f"💸 Amende : <b>{fmt(fine)}</b>",
            f"🌟 Karma : <b>-10</b>",
        ]

    await safe_edit(
        query,
        card("⚖️ VERDICT", body, icon="⚖️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              👨‍⚖️ AVOCAT
# ═══════════════════════════════════════════════════════════════════
async def show_avocat_info(query, user_id: int):
    u = await get_user(user_id)
    if u.get("prison_until", 0) <= now():
        await safe_edit(
            query,
            "✅ Tu n'es pas en prison !",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
        )
        return

    remaining = u["prison_until"] - now()

    body = [
        f"⏳ Temps restant : <b>{fmt_time(remaining)}</b>",
        f"💰 Honoraires : <b>{fmt(LAWYER_COST)}</b>",
        f"💵 Ton solde : <b>{fmt(u['balance'])}</b>",
        "",
        "👨‍⚖️ <b>Maître Leblanc</b>",
        "<i>70% de chance de réduire ta peine à 1/3</i>",
    ]

    if u["balance"] >= LAWYER_COST:
        keyboard = [
            [InlineKeyboardButton(f"👨‍⚖️ Engager ({fmt(LAWYER_COST)})", callback_data="crime_avocat_do")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")],
        ]
    else:
        body.append("")
        body.append("❌ <b>Fonds insuffisants</b>")
        keyboard = [[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]]

    await safe_edit(
        query,
        card("👨‍⚖️ AVOCAT", body, icon="👨‍⚖️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_avocat(query, user_id: int):
    u = await get_user(user_id)
    if u.get("prison_until", 0) <= now():
        await safe_edit(query, "✅ Tu n'es pas en prison !")
        return
    if u["balance"] < LAWYER_COST:
        await safe_edit(query, f"❌ Fonds insuffisants. Coût : {fmt(LAWYER_COST)}")
        return

    await update_balance(user_id, -LAWYER_COST, sink="justice")
    remaining = u["prison_until"] - now()

    if random.random() < 0.70:
        new_time = now() + remaining // 3
        await update_field(user_id, "prison_until", new_time)
        body = [
            "👨‍⚖️ <b>Avocat intervenu !</b>",
            "<i>Maître Leblanc plaide brillamment.</i>",
            "",
            f"✅ Peine réduite à <b>{fmt_time(remaining // 3)}</b>",
            f"💰 Honoraires : <b>{fmt(LAWYER_COST)}</b>",
        ]
    else:
        body = [
            "👨‍⚖️ <b>L'avocat a échoué…</b>",
            "<i>Maître Leblanc n'a pas convaincu le juge.</i>",
            "",
            f"❌ Peine inchangée : <b>{fmt_time(remaining)}</b>",
            f"💰 Honoraires perdus : <b>{fmt(LAWYER_COST)}</b>",
        ]

    await safe_edit(
        query,
        card("👨‍⚖️ RÉSULTAT AVOCAT", body, icon="👨‍⚖️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              📊 INFO CRIMES (sans action)
# ═══════════════════════════════════════════════════════════════════
async def show_crime_info_list(query, user_id: int):
    body = ["<i>Chaque crime présente des risques. Liste complète :</i>", ""]
    for crime_name, data in CRIMES.items():
        min_r, max_r = data["reward"]
        body.append(
            f"💀 <b>{crime_name}</b>\n"
            f"   💰 {fmt(min_r)} – {fmt(max_r)}\n"
            f"   ✅ {int(data['success'] * 100)}% | ⛓️ {fmt_time(data['jail'])}\n"
            f"   🌟 Karma : {data['karma']:+d}"
        )
    await safe_edit(
        query,
        card("⚔️ CATALOGUE DES CRIMES", body, icon="⚔️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
    )


async def show_gang_info(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT g.*, gm.role FROM gang_members gm
            JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?
        """, (user_id,)) as cur:
            gang = await cur.fetchone()

    if not gang:
        from utils.forms import form_rows
        body = ["<i>Tu n'es dans aucun gang.</i>", "", "Crée le tien ou rejoins-en un ci-dessous."]
        await safe_edit(
            query,
            card("🔫 MON GANG", body, icon="🔫", style="round"),
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([*form_rows("gang_none"),
                [InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
        )
        return

    async with db_connection() as db:
        async with db.execute(
            "SELECT COUNT(*) FROM gang_members WHERE gang_id=?", (gang["gang_id"],)
        ) as cur:
            count = (await cur.fetchone())[0]

    body = [
        f"🏴 <b>{escape_html(gang['name'])}</b>",
        f"👤 Ton rôle : <b>{escape_html(gang['role'])}</b>",
        f"👥 Membres : <b>{count}</b>",
        f"💰 Caisse : <b>{fmt(gang['treasury'])}</b>",
        f"⭐ Réputation : <b>{gang['reputation']}</b>",
    ]
    from utils.forms import form_rows
    await safe_edit(
        query,
        card("🔫 MON GANG", body, icon="🔫", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([*form_rows("gang_in"),
            [InlineKeyboardButton("⬅️ Retour", callback_data="crime_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              🎯 CALLBACK ROUTEUR CRIME
# ═══════════════════════════════════════════════════════════════════
async def crime_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gère tous les callbacks commençant par 'crime_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "crime_menu":
        from handlers.hub import open_zone; await open_zone(query, "society")
        return
    if data == "crime_noop":
        return
    if data == "crime_list":
        await show_crime_list(query, user_id)
        return
    if data.startswith("crime_do_"):
        try:
            idx = int(data.replace("crime_do_", ""))
        except ValueError:
            return
        await do_commit_crime(query, user_id, idx)
        return
    if data in ("crime_caution_info", "crime_caution_pay", "crime_tribunal_info", "crime_tribunal_do",
                "crime_avocat_info", "crime_avocat_do"):
        from utils import justice
        if await justice.has_judges():                       # ⚖️ la Justice est en place : elle remplace l'automatique
            from handlers.justice import show_me
            await show_me(update, user_id)
            return
    if data == "crime_caution_info":
        await show_caution_info(query, user_id)
        return
    if data == "crime_caution_pay":
        await do_pay_caution(query, user_id)
        return
    if data == "crime_tribunal_info":
        await show_tribunal_info(query, user_id)
        return
    if data == "crime_tribunal_do":
        await do_tribunal(query, user_id)
        return
    if data == "crime_avocat_info":
        await show_avocat_info(query, user_id)
        return
    if data == "crime_avocat_do":
        await do_avocat(query, user_id)
        return
    if data == "crime_info_list":
        await show_crime_info_list(query, user_id)
        return
    if data == "crime_gang_info":
        await show_gang_info(query, user_id)
        return


# ═══════════════════════════════════════════════════════════════════
#              COMMANDES TEXTE EXISTANTES (compatibilité)
# ═══════════════════════════════════════════════════════════════════

@require_registered
@require_free
async def cmd_crimes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = "🔫 <b>Crimes disponibles</b>\n\n"
    text += "<i>Chaque crime est un risque — tu pourrais aller en prison !</i>\n\n"
    for crime, data in CRIMES.items():
        min_r, max_r = data["reward"]
        text += (
            f"💀 <b>{escape_html(crime)}</b>\n"
            f"  💰 Gain : {escape_html(fmt(min_r))} – {escape_html(fmt(max_r))}\n"
            f"  ✅ Chance : {escape_html(int(data['success'] * 100))}%\n"
            f"  ⛓️ Prison si pris : {escape_html(fmt_time(data['jail']))}\n"
            f"  🌟 Impact karma : {escape_html(data['karma'])}\n\n"
        )
    text += "<i>Pour tenter le coup : menu → 🏛️ Société → Crime</i>"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
async def cmd_commettre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    from handlers.gangs import require_gang, NO_GANG_CRIME_TEXT
    if not await require_gang(user.id):
        await update.message.reply_text(NO_GANG_CRIME_TEXT)
        return

    last_crime = u.get("last_crime", 0)
    if now() - last_crime < CRIME_COOLDOWN:
        remaining = CRIME_COOLDOWN - (now() - last_crime)
        await update.message.reply_text(f"⏳ Calme-toi ! Attends {fmt_time(remaining)} avant un autre crime.")
        return

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🔫 Crime & sécurité.")
        return

    crime_name = " ".join(context.args).title()
    matched = None
    for c in CRIMES:
        if c.lower() == crime_name.lower():
            matched = c
            break
    if not matched:
        await update.message.reply_text("❌ Crime inconnu. Utilise le menu pour voir la liste.")
        return

    data = CRIMES[matched]

    from database import get_skill
    discretion = await get_skill(user.id, "Discrétion")
    agility = await get_skill(user.id, "Agilité")
    skill_bonus = (discretion * 0.02) + (agility * 0.01)
    karma_bonus = max(-0.1, min(0.1, u.get("karma", 0) / 1000))

    # ⭐ Boost chance VIP
    chance_boost = chance_boost_bonus(u)

    gang_bonus = 0
    async with db_connection() as db:
        async with db.execute(
            "SELECT g.reputation FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
            (user.id,)
        ) as cur:
            gang_row = await cur.fetchone()
        if gang_row:
            gang_bonus = (gang_row[0] - 50) / 200

    from config import WEAPON_REQUIRED_CRIMES
    from utils import weapons
    weapon_bonus, weapon_msg, weapon_ok = await weapons.use_for_action(
        user.id, need_firearm=matched in WEAPON_REQUIRED_CRIMES)
    if not weapon_ok:
        await update.message.reply_text(f"🔫 {matched} : {weapon_msg}")
        return
    success = roll_success(data["success"], skill_bonus + gang_bonus + chance_boost + weapon_bonus, karma_bonus)

    await update_field(user.id, "last_crime", now())
    await increment_field(user.id, "crimes_done")

    active_vehicle = await get_active_vehicle(user.id)
    vehicle_speed = active_vehicle.get("speed", 0) if active_vehicle else 0

    prison_time = 0
    arrested = False

    if success:
        min_r, max_r = data["reward"]
        reward = random.randint(min_r, max_r)
        from handlers.gangs import split_crime_reward
        reward = await split_crime_reward(user.id, reward)    # une part du butin va au coffre du gang
        await increment_field(user.id, "karma", data["karma"])
        await increment_field(user.id, "crimes_success")
        # ⭐ Utilisation de add_xp (boost XP appliqué automatiquement)
        await add_xp(user.id, 150)
        await update_mission_progress(user.id, "crime", 1)

        # Fuite + enquête de la police (voir utils/ordre.py) à la place de l'ancienne arrestation immédiate
        from utils import ordre
        await ordre.register_bot_crime(user.id, matched, reward)
        async with db_connection() as db:
            await db.execute(
                "INSERT INTO crime_log (user_id, crime_type, success, reward, timestamp) VALUES (?,?,1,?,?)",
                (user.id, matched, reward, now())
            )
            await db.commit()

        loot_msg = ""
        if random.random() < 0.2:
            if matched in ("Hold-up banque", "Cybercriminalité"):
                item = await add_random_item(user.id, "rare", "legendary")
            elif matched in ("Braquage", "Trafic drogue"):
                item = await add_random_item(user.id, "common", "epic")
            else:
                item = await add_random_item(user.id, "common", "rare")
            if item:
                loot_msg = f"\n\n🎁 Tu as trouvé un objet : {item} !"

        if arrested:
            await update.message.reply_text(
                f"✅ <b>Crime réussi : {escape_html(matched)}</b>\n\n"
                f"💰 Butin : <b>{escape_html(fmt(reward))}</b>\n"
                f"🌟 Karma : {data['karma']:+d}\n"
                f"✨ +150 XP{escape_html(loot_msg)}\n\n"
                f"🚨 <b>Mais tu es pris en fuite !</b>\n"
                f"⛓️ Prison pour {escape_html(fmt_time(prison_time))}.",
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text(
                f"✅ <b>Crime réussi : {escape_html(matched)}</b>\n\n"
                f"💰 Butin : <b>{escape_html(fmt(reward))}</b>\n"
                f"🌟 Karma : {data['karma']:+d}\n"
                f"✨ +150 XP{escape_html(loot_msg)}\n\n"
                f"🏃 Tu t'enfuis… la police ouvrira une enquête bientôt (menu Ordre public → Se cacher).",
                parse_mode="HTML"
            )

    else:
        # 🛡️ Assurance anti-arrestation (boutique Étoiles) : consomme 1 charge
        # et annule la prison si le joueur en a en réserve.
        shield_charges = u.get("crime_shield_charges", 0) or 0
        shield_used = shield_charges > 0

        if shield_used:
            await increment_field(user.id, "crime_shield_charges", -1)
            prison_time = 0
        else:
            from utils import ordre
            prison_time = ordre.jail_for_bot_crime(matched)      # 15 à 30 min selon la gravité (max 60 min)
            await update_field(user.id, "prison_until", now() + prison_time)
            await ordre.register_arrest(user.id, matched, "crime", prison_time)

        async with db_connection() as db:
            await db.execute(
                "INSERT INTO crime_log (user_id, crime_type, success, jail_time, timestamp) VALUES (?,?,0,?,?)",
                (user.id, matched, prison_time, now())
            )
            await db.commit()

        caution = int((data["reward"][0] + data["reward"][1]) / 2 * BAIL_COST_RATIO)

        if shield_used:
            await update.message.reply_text(
                f"❌ <b>Crime échoué : {escape_html(matched)}</b>\n\n"
                f"🛡️ <b>Ton assurance anti-arrestation t'a protégé !</b>\n"
                f"Tu repars libre (charges restantes : {escape_html(shield_charges - 1)}).",
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text(
                f"❌ <b>Crime échoué : {escape_html(matched)}</b>\n\n"
                f"⛓️ Tu es en prison pour <b>{escape_html(fmt_time(prison_time))}</b> !\n\n"
                f"💡 Tu peux engager un avocat ({escape_html(fmt(LAWYER_COST))}) depuis le menu Société → Crime, "
                f"ou acheter une 🔓 Carte Sortie de Prison dans la boutique en Étoiles (/boutique).",
                parse_mode="HTML"
            )


@require_registered
async def cmd_caution(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from utils import justice
    if await justice.has_judges():
        from handlers.justice import show_home as justice_home
        await justice_home(update, update.effective_user.id, "⚖️ La Justice remplace l'ancien système automatique.")
        return
    user = update.effective_user
    u = await get_user(user.id)

    prison_time = u.get("prison_until", 0)
    if prison_time <= now():
        await update.message.reply_text("✅ Tu n'es pas en prison !")
        return

    remaining = prison_time - now()
    caution = int(remaining / 3600 * 5_000)

    if u["balance"] < caution:
        await update.message.reply_text(
            f"❌ Caution insuffisante !\n"
            f"💰 Caution requise : {escape_html(fmt(caution))}\n"
            f"💵 Ton solde : {escape_html(fmt(u['balance']))}",
            parse_mode="HTML"
        )
        return

    await update_balance(user.id, -caution, sink="amendes")
    await update_field(user.id, "prison_until", 0)

    await update.message.reply_text(
        f"🔓 <b>Liberté recouvrée !</b>\n\n"
        f"💰 Caution payée : {escape_html(fmt(caution))}",
        parse_mode="HTML"
    )


@require_registered
async def cmd_tribunal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from utils import justice
    if await justice.has_judges():
        from handlers.justice import show_home as justice_home
        await justice_home(update, update.effective_user.id, "⚖️ La Justice remplace l'ancien système automatique.")
        return
    user = update.effective_user
    u = await get_user(user.id)

    prison_time = u.get("prison_until", 0)
    if prison_time <= now():
        await update.message.reply_text("✅ Tu n'es pas en prison !")
        return

    remaining = prison_time - now()
    karma = u.get("karma", 0)
    if karma >= 100:
        acquit_chance = 0.60
    elif karma >= 0:
        acquit_chance = 0.40
    elif karma >= -100:
        acquit_chance = 0.25
    else:
        acquit_chance = 0.10

    roll = random.random()

    if roll < acquit_chance:
        await update_field(user.id, "prison_until", 0)
        await increment_field(user.id, "karma", 5)
        await update.message.reply_text(
            f"⚖️ <b>ACQUITTÉ !</b>\n\n🎉 Tu es libre !\n🌟 +5 Karma",
            parse_mode="HTML"
        )
    elif roll < acquit_chance + 0.3:
        new_time = now() + remaining // 2
        await update_field(user.id, "prison_until", new_time)
        await update.message.reply_text(
            f"⚖️ <b>Peine réduite !</b>\n\n⏳ {escape_html(fmt_time(remaining // 2))}",
            parse_mode="HTML"
        )
    else:
        extra = random.randint(1, 3) * 3600
        new_time = prison_time + extra
        fine = random.randint(10_000, 100_000)
        await update_field(user.id, "prison_until", new_time)
        if u["balance"] >= fine:
            await update_balance(user.id, -fine, sink="amendes")
        await increment_field(user.id, "karma", -10)
        await update.message.reply_text(
            f"⚖️ <b>CONDAMNÉ !</b>\n\n⛓️ +{escape_html(fmt_time(extra))}\n💸 Amende : {escape_html(fmt(fine))}",
            parse_mode="HTML"
        )


@require_registered
async def cmd_avocat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from utils import justice
    if await justice.has_judges():
        from handlers.justice import show_home as justice_home
        await justice_home(update, update.effective_user.id, "⚖️ La Justice remplace l'ancien système automatique.")
        return
    user = update.effective_user
    u = await get_user(user.id)

    prison_time = u.get("prison_until", 0)
    if prison_time <= now():
        await update.message.reply_text("✅ Tu n'es pas en prison.")
        return

    if u["balance"] < LAWYER_COST:
        await update.message.reply_text(f"❌ Avocat coûte {fmt(LAWYER_COST)}.")
        return

    await update_balance(user.id, -LAWYER_COST, sink="justice")
    remaining = prison_time - now()

    if random.random() < 0.70:
        new_time = now() + remaining // 3
        await update_field(user.id, "prison_until", new_time)
        await update.message.reply_text(
            f"👨‍⚖️ <b>Avocat intervenu !</b>\n\n✅ Peine réduite à {escape_html(fmt_time(remaining // 3))}",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            f"👨‍⚖️ <b>L'avocat a échoué...</b>\n\n❌ Peine inchangée : {escape_html(fmt_time(remaining))}",
            parse_mode="HTML"
        )


# ─── GANGS : on garde les commandes existantes telles quelles ───

@require_registered
@require_free
async def cmd_gang(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT g.*, gm.role FROM gang_members gm
            JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?
        """, (user.id,)) as cur:
            gang = await cur.fetchone()

    if not gang:
        await update.message.reply_text(
            "🔫 Tu n'es dans aucun gang.\n\n"
        )
        return

    async with db_connection() as db:
        async with db.execute(
            "SELECT COUNT(*) FROM gang_members WHERE gang_id=?", (gang["gang_id"],)
        ) as cur:
            count = (await cur.fetchone())[0]

    from handlers.gangs import share_text as _share_line
    await update.message.reply_text(
        f"🔫 **Gang : {gang['name']}**\n\n"
        f"👤 Ton rôle : {gang['role']}\n"
        f"👥 Membres : {count}\n"
        f"💰 Caisse : {fmt(gang['treasury'])}\n"
        f"⭐ Réputation : {gang['reputation']}\n\n"
        + await _share_line(gang["gang_id"], user.id, gang["role"]),
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_creergand(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    from gameplay.gangs import GangError, create_gang
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🔫 Crime & sécurité.")
        return
    try:
        result = await create_gang(user.id, " ".join(context.args)[:40])
    except GangError as exc:
        await update.message.reply_text(f"❌ {exc}")
        return
    await update.message.reply_text(f"🔫 <b>Gang créé : {escape_html(result['name'])}</b>\n\n💰 Coût : {fmt(result['cost'])}", parse_mode="HTML")
    return

    u = await get_user(user.id)

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🔫 Crime & sécurité.")
        return

    name = " ".join(context.args)[:40]
    GANG_CREATION_COST = 50_000

    if u["balance"] < GANG_CREATION_COST:
        await update.message.reply_text(
            f"❌ Créer un gang coûte <b>{escape_html(fmt(GANG_CREATION_COST))}</b>.",
            parse_mode="HTML"
        )
        return

    try:
        async with db_connection() as db:
            async with db.execute(
                "SELECT g.name FROM gangs g JOIN gang_members gm ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
                (user.id,)
            ) as cur:
                existing = await cur.fetchone()
            if existing:
                raise DeferredReply(update.message.reply_text, f"❌ Tu es déjà membre du gang **{existing[0]}**.")

            async with db.execute("SELECT gang_id FROM gangs WHERE LOWER(name)=LOWER(?)", (name,)) as cur:
                if await cur.fetchone():
                    raise DeferredReply(update.message.reply_text, f"❌ Le nom **{name}** est déjà pris.")

            await db.execute(
                "INSERT INTO gangs (name, founder_id, treasury, reputation, created_at) VALUES (?,?,0,0,?)",
                (name, user.id, now())
            )
            async with db.execute("SELECT last_insert_rowid()") as cur:
                gang_id = (await cur.fetchone())[0]
            await db.execute(
                "INSERT INTO gang_members (gang_id, user_id, role, joined_at) VALUES (?,?,'Chef',?)",
                (gang_id, user.id, now())
            )
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()

    await update_balance(user.id, -GANG_CREATION_COST, sink="gangs")

    await update.message.reply_text(
        f"🔫 <b>Gang créé : {escape_html(name)}</b>\n\n"
        f"💰 Coût : {escape_html(fmt(GANG_CREATION_COST))}",
        parse_mode="HTML"
    )


from handlers.gangs import cmd_rejoindregang  # noqa: E402,F401  (candidature + encadrement)
from utils.helpers import safe_edit


@require_registered
@require_free
async def cmd_quittergang(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    from gameplay.gangs import GangError, leave_gang
    try:
        result = await leave_gang(user.id)
    except GangError as exc:
        await update.message.reply_text(f"❌ {exc}")
        return
    message = f"💀 Le gang <b>{escape_html(result['name'])}</b> a été dissous." if result["dissolved"] else f"👋 Tu as quitté le gang <b>{escape_html(result['name'])}</b>."
    await update.message.reply_text(message, parse_mode="HTML")
    return

    async with Outbox() as _out:
        async with db_connection() as db:
            async with db.execute(
                "SELECT g.gang_id, g.name, gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
                (user.id,)
            ) as cur:
                member = await cur.fetchone()
            if not member:
                _out.add(update.message.reply_text, "❌ Tu n'es dans aucun gang.")
                return

            gang_id, gang_name, role = member
            if role == "Chef":
                async with db.execute("SELECT COUNT(*) FROM gang_members WHERE gang_id=?", (gang_id,)) as cur:
                    count = (await cur.fetchone())[0]
                if count > 1:
                    _out.add(update.message.reply_text, "❌ Tu es le chef ! Transfère ou dissous d'abord.")
                    return
                else:
                    await db.execute("DELETE FROM gangs WHERE gang_id=?", (gang_id,))
                    await db.execute("DELETE FROM gang_members WHERE gang_id=?", (gang_id,))
                    await db.commit()
                    _out.add(update.message.reply_text, f"💀 Le gang **{gang_name}** a été dissous.")
                    return
            else:
                await db.execute("DELETE FROM gang_members WHERE user_id=? AND gang_id=?", (user.id, gang_id))
                await db.commit()
                _out.add(update.message.reply_text, f"👋 Tu as quitté le gang **{gang_name}**.")


@require_registered
@require_free
async def cmd_dissoudregang(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    from gameplay.gangs import GangError, dissolve_gang
    try:
        result = await dissolve_gang(user.id)
    except GangError as exc:
        await update.message.reply_text(f"❌ {exc}")
        return
    refund = f"\n💰 Trésorerie reversée : {fmt(result['refunded'])}" if result["refunded"] else ""
    await update.message.reply_text(f"💀 <b>Gang {escape_html(result['name'])} dissous</b>.{refund}", parse_mode="HTML")
    return

    try:
        async with db_connection() as db:
            async with db.execute(
                "SELECT g.gang_id, g.name, g.treasury, gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
                (user.id,)
            ) as cur:
                gang = await cur.fetchone()
            if not gang:
                raise DeferredReply(update.message.reply_text, "❌ Tu n'es dans aucun gang.")
            gang_id, gang_name, treasury, role = gang
            if role != "Chef":
                raise DeferredReply(update.message.reply_text, "❌ Seul le chef peut dissoudre le gang.")

            await db.execute("DELETE FROM gang_members WHERE gang_id=?", (gang_id,))
            await db.execute("DELETE FROM gangs WHERE gang_id=?", (gang_id,))
            if treasury > 0:
                await update_balance(user.id, treasury)
                msg_remb = f"\n💰 Trésorerie reversée : {fmt(treasury)}"
            else:
                msg_remb = ""
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()

    await update.message.reply_text(
        f"💀 <b>Gang {escape_html(gang_name)} dissous</b>.{escape_html(msg_remb)}",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_ganginfo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🔫 Crime & sécurité.")
        return

    name = " ".join(context.args)
    async with Outbox() as _out:
        async with db_connection() as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM gangs WHERE LOWER(name)=LOWER(?)", (name,)) as cur:
                gang = await cur.fetchone()
            if not gang:
                _out.add(update.message.reply_text, f"❌ Gang **{name}** introuvable.")
                return

            async with db.execute("SELECT COUNT(*) FROM gang_members WHERE gang_id=?", (gang["gang_id"],)) as cur:
                count = (await cur.fetchone())[0]

            async with db.execute("""
            SELECT u.full_name, gm.role, gm.joined_at
            FROM gang_members gm JOIN users u ON u.user_id=gm.user_id
            WHERE gm.gang_id=?
        """, (gang["gang_id"],)) as cur:
                members = await cur.fetchall()

    text = f"🔫 <b>Gang : {escape_html(gang['name'])}</b>\n\n"
    text += f"💰 Caisse : {escape_html(fmt(gang['treasury']))}\n"
    text += f"⭐ Réputation : {escape_html(gang['reputation'])}\n"
    text += f"👥 Membres : {escape_html(count)}\n\n"
    for m in members[:15]:
        text += f"  • {escape_html(m['full_name'])} — {escape_html(m['role'])}\n"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
async def cmd_gangactions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        async with db.execute(
            "SELECT g.*, gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
            (user.id,)
        ) as cur:
            gang = await cur.fetchone()
    if not gang:
        await update.message.reply_text("❌ Tu n'es dans aucun gang.")
        return

    role = gang[5]
    text = f"🔫 <b>Actions du gang — {escape_html(gang[1])}</b>\n\n"
    text += "Agis depuis 🎮 Menu → 🔫 Crime &amp; sécurité → Mon gang.\n"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
async def cmd_gangcaisse(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    from gameplay.gangs import GangError, deposit as gang_deposit, withdraw as gang_withdraw
    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🔫 Crime & sécurité.")
        return
    try:
        amount = parse_amount(context.args[1], None)
        result = await (gang_deposit if context.args[0].lower() == "depot" else gang_withdraw)(user.id, amount)
    except (GangError, TypeError) as exc:
        await update.message.reply_text(f"❌ {exc}")
        return
    await update.message.reply_text(f"🏦 {'Dépôt' if context.args[0].lower() == 'depot' else 'Retrait'} de {fmt(result['amount'])} effectué.")
    return

    u = await get_user(user.id)

    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🔫 Crime & sécurité.")
        return

    action = context.args[0].lower()
    amount = parse_amount(context.args[1], u["balance"] if action == "depot" else None)
    if not amount or amount <= 0:
        await update.message.reply_text("❌ Montant invalide.")
        return

    async with Outbox() as _out:
        async with db_connection() as db:
            async with db.execute(
                "SELECT g.gang_id, g.treasury, gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
                (user.id,)
            ) as cur:
                gang = await cur.fetchone()
            if not gang:
                _out.add(update.message.reply_text, "❌ Tu n'es dans aucun gang.")
                return

            gang_id, treasury, role = gang
            if action == "depot":
                if amount > u["balance"]:
                    _out.add(update.message.reply_text, "❌ Fonds insuffisants.")
                    return
                await update_balance(user.id, -amount)
                await db.execute("UPDATE gangs SET treasury=treasury+? WHERE gang_id=?", (amount, gang_id))
                await db.commit()
                _out.add(update.message.reply_text, f"🏦 Dépôt de {fmt(amount)} effectué.")
            elif action == "retrait":
                if role != "Chef":
                    _out.add(update.message.reply_text, "❌ Seul le chef peut retirer.")
                    return
                if amount > treasury:
                    _out.add(update.message.reply_text, "❌ Caisse insuffisante.")
                    return
                await db.execute("UPDATE gangs SET treasury=treasury-? WHERE gang_id=?", (amount, gang_id))
                await update_balance(user.id, amount)
                await db.commit()
                _out.add(update.message.reply_text, f"🏦 Retrait de {fmt(amount)} effectué.")


@require_registered
@require_free
async def cmd_transfertchef(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    from gameplay.gangs import GangError, transfer_chief
    if not update.message.reply_to_message:
        await update.message.reply_text("Réponds au message du nouveau chef.")
        return
    target = update.message.reply_to_message.from_user
    try:
        await transfer_chief(user.id, target.id)
    except GangError as exc:
        await update.message.reply_text(f"❌ {exc}")
        return
    await update.message.reply_text(f"👑 {escape_html(target.full_name)} est le nouveau chef.", parse_mode="HTML")
    return

    if not update.message.reply_to_message:
        await update.message.reply_text("Réponds au message du nouveau chef.")
        return

    target = update.message.reply_to_message.from_user

    try:
        async with db_connection() as db:
            async with db.execute(
                "SELECT g.gang_id, g.name, gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
                (user.id,)
            ) as cur:
                my_gang = await cur.fetchone()
            if not my_gang or my_gang[2] != "Chef":
                raise DeferredReply(update.message.reply_text, "❌ Tu n'es pas chef.")

            gang_id, gang_name, _ = my_gang
            await db.execute("UPDATE gang_members SET role='Chef' WHERE gang_id=? AND user_id=?", (gang_id, target.id))
            await db.execute("UPDATE gang_members SET role='Bras droit' WHERE gang_id=? AND user_id=?", (gang_id, user.id))
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()

    await update.message.reply_text(f"👑 {target.full_name} est le nouveau chef.")


@require_registered
@require_free
async def cmd_ganghold(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    from gameplay.gangs import GangError, hold_up
    try:
        result = await hold_up(user.id)
    except GangError as exc:
        await update.message.reply_text(f"❌ {exc}")
        return
    if result["success"]:
        await update.message.reply_text(f"💰 <b>Hold-up réussi !</b>\n\n🏦 Caisse : +{fmt(result['reward'])}\n⭐ Réputation : +{result['reputation_change']}", parse_mode="HTML")
    else:
        await update.message.reply_text(f"💥 <b>Hold-up échoué !</b>\n⭐ Réputation -10\n🏦 Perte de caisse : {fmt(result['treasury_change'])}", parse_mode="HTML")
    return

    async with db_connection() as db:
        async with db.execute(
            "SELECT g.gang_id, g.name, g.treasury, g.reputation FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
            (user.id,)
        ) as cur:
            gang = await cur.fetchone()
    if not gang:
        await update.message.reply_text("❌ Tu n'es dans aucun gang.")
        return

    gang_id, gang_name, treasury, rep = gang
    async with db_connection() as db:
        async with db.execute("SELECT user_id FROM gang_members WHERE gang_id=?", (gang_id,)) as cur:
            members = [row[0] for row in await cur.fetchall()]

    success_chance = min(0.95, 0.3 + rep / 200)
    if random.random() > success_chance:
        loss = int(treasury * 0.1) if treasury > 0 else 0
        async with db_connection() as db:
            await db.execute("UPDATE gangs SET reputation=?, treasury=? WHERE gang_id=?", (max(0, rep - 10), treasury - loss, gang_id))
            await db.commit()
        await update.message.reply_text(f"💥 **Hold-up échoué !**\n⭐ Réputation -10")
        return

    base_reward = random.randint(50_000, 200_000)
    rep_gain = random.randint(5, 15)
    async with db_connection() as db:
        await db.execute("UPDATE gangs SET treasury=treasury+?, reputation=MIN(100, reputation+?) WHERE gang_id=?", (base_reward, rep_gain, gang_id))
        await db.commit()

    await update.message.reply_text(
        f"💰 <b>Hold-up réussi !</b>\n\n"
        f"🏦 Caisse : +{escape_html(fmt(base_reward))} (partagé entre les {escape_html(len(members))} membres selon leur poste)\n"
        f"⭐ Réputation : +{escape_html(rep_gain)}",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_gangupgrade(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    from gameplay.gangs import GangError, upgrade as gang_upgrade
    try:
        result = await gang_upgrade(user.id)
    except GangError as exc:
        await update.message.reply_text(f"❌ {exc}")
        return
    await update.message.reply_text(f"⭐ <b>Gang {escape_html(result['name'])} amélioré !</b>\n\nRéputation : {result['old_reputation']} → {result['reputation']}", parse_mode="HTML")
    return

    async with db_connection() as db:
        async with db.execute(
            "SELECT g.gang_id, g.name, g.treasury, g.reputation, gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?",
            (user.id,)
        ) as cur:
            gang = await cur.fetchone()
    if not gang or gang[4] not in ("Chef", "Bras droit", "Lieutenant"):
        await update.message.reply_text("❌ Seuls l'encadrement (chef, bras droit, lieutenant) peut améliorer le gang.")
        return

    gang_id, name, treasury, rep, _ = gang
    cost = 100_000
    if treasury < cost:
        await update.message.reply_text(f"❌ Caisse insuffisante. Coût : {fmt(cost)}")
        return

    new_rep = min(100, rep + 10)
    async with db_connection() as db:
        await db.execute("UPDATE gangs SET treasury=treasury-?, reputation=? WHERE gang_id=?", (cost, new_rep, gang_id))
        await db.commit()

    await update.message.reply_text(
        f"⭐ <b>Gang {escape_html(name)} amélioré !</b>\n\nRéputation : {escape_html(rep)} → {escape_html(new_rep)}",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_gangclassement(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_for_update
    await show_for_update(update, 'gangs')


async def process_gang_maintenance():
    from gameplay.gangs import maintenance
    return await maintenance()

    """Frais quotidiens des gangs (5% de la trésorerie ou baisse de réputation).

    Deux requêtes globales au lieu d'une connexion par gang.
    ⚠️ ORDRE IMPORTANT : la réputation est traitée EN PREMIER, car sa condition
    dépend de la trésorerie d'origine, que la seconde requête va modifier.
    """
    async with db_connection() as db:
        # Trésorerie trop faible (frais < 1) : -5 points de réputation
        await db.execute(
            "UPDATE gangs SET reputation = MAX(0, reputation - 5) "
            "WHERE NOT (treasury > 0 AND CAST(treasury * 0.05 AS INTEGER) > 0)"
        )
        # Les autres paient 5 % de leur trésorerie
        await db.execute(
            "UPDATE gangs SET treasury = treasury - CAST(treasury * 0.05 AS INTEGER) "
            "WHERE treasury > 0 AND CAST(treasury * 0.05 AS INTEGER) > 0"
        )
        await db.commit()
