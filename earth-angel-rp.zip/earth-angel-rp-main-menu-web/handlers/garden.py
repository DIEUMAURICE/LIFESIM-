from utils.swallow import swallowed
import logging
# handlers/garden.py
import random
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import db_connection, DB_PATH, get_user, update_balance, update_field, increment_field
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, fmt_time, now, escape_html
from config import PLANTS, SEASON_EFFECTS
from handlers.missions import update_mission_progress
from utils.vip import garden_growth_multiplier, max_garden_plots, add_xp, add_coins
from utils.helpers import safe_edit

MAX_PLOTS = 10  # Base (les bonus VIP s'ajoutent)
WATER_COOLDOWN = 900  # 15 minutes


async def get_max_plots(user_id: int) -> int:
    """Retourne le nombre max de parcelles (base + bonus VIP)."""
    u = await get_user(user_id)
    return max_garden_plots(u, MAX_PLOTS)


async def get_season_multiplier(user_id: int = None) -> float:
    """Multiplicateur de jardinage (saison × boost VIP si actif)."""
    from utils.gametime import game_month
    m = game_month()
    if m in (12, 1, 2):
        season = "Hiver"
    elif m in (3, 4, 5):
        season = "Printemps"
    elif m in (6, 7, 8):
        season = "Été"
    else:
        season = "Automne"

    base = SEASON_EFFECTS.get(season, {}).get("garden_mult", 1.0)

    if user_id is not None:
        try:
            u = await get_user(user_id)
            base *= garden_growth_multiplier(u)
        except Exception:
            swallowed('handlers/garden.py')

    return base


async def get_garden(user_id: int):
    """Récupère toutes les parcelles d'un utilisateur."""
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM garden WHERE user_id = ? ORDER BY plot_id",
            (user_id,)
        ) as cur:
            rows = await cur.fetchall()
    return [dict(r) for r in rows] if rows else []


# ═══════════════════════════════════════════════════════════════════
#              🌱 MENU PRINCIPAL JARDIN (boutons)
# ═══════════════════════════════════════════════════════════════════
async def show_garden_menu(query, user_id: int):
    """Menu interactif Jardin."""
    plots = await get_garden(user_id)
    season_mult = await get_season_multiplier(user_id)
    max_plots = await get_max_plots(user_id)
    t = now()

    # Compter les états
    ready_count = 0
    waterable_count = 0
    for p in plots:
        data = PLANTS.get(p["plant_type"], {})
        needed = int(data.get("grow_time", 3600) / season_mult)
        if t - p["planted_at"] >= needed:
            ready_count += 1
        water_needed = data.get("water_needed", 1)
        if p.get("water_count", 0) < water_needed:
            waterable_count += 1

    # Résumé saison
    from utils.gametime import game_month
    m = game_month()
    if m in (12, 1, 2): season_name = "❄️ Hiver"
    elif m in (3, 4, 5): season_name = "🌸 Printemps"
    elif m in (6, 7, 8): season_name = "☀️ Été"
    else: season_name = "🍂 Automne"

    # ⭐ Bonus actif ?
    u = await get_user(user_id)
    boost_active = garden_growth_multiplier(u) > 1.0

    body = [
        f"🌿 Parcelles : <b>{len(plots)}/{max_plots}</b>",
        f"🍃 Saison : <b>{season_name}</b> (multiplicateur ×{season_mult:.1f})",
    ]
    if boost_active:
        body.append("⚡ <b>Boost Jardin x3 ACTIF !</b>")
    if ready_count > 0:
        body.append(f"✅ <b>{ready_count} plante(s) prête(s) à récolter !</b>")
    if waterable_count > 0:
        body.append(f"💧 <b>{waterable_count} plante(s) à arroser</b>")

    keyboard = []

    if plots:
        keyboard.append([
            InlineKeyboardButton("🌿 Voir mes parcelles", callback_data="garden_view"),
        ])

    if len(plots) < max_plots:
        keyboard.append([
            InlineKeyboardButton("🌱 Planter", callback_data="garden_plant_menu"),
        ])

    if ready_count > 0:
        keyboard.append([
            InlineKeyboardButton("🌾 RÉCOLTER TOUT", callback_data="garden_harvest_all"),
        ])

    if plots:
        keyboard.append([
            InlineKeyboardButton("💧 Arroser", callback_data="garden_water_menu"),
            InlineKeyboardButton("🌾 Récolter", callback_data="garden_harvest_menu"),
        ])

    keyboard.append([InlineKeyboardButton("⬅️ Menu principal", callback_data="menu_main")])

    await safe_edit(
        query,
        "🌱 <b>MON JARDIN</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


# ═══════════════════════════════════════════════════════════════════
#              🌿 VOIR LES PARCELLES
# ═══════════════════════════════════════════════════════════════════
async def show_garden_view(query, user_id: int):
    plots = await get_garden(user_id)
    season_mult = await get_season_multiplier(user_id)
    max_plots = await get_max_plots(user_id)
    t = now()

    if not plots:
        await safe_edit(
            query,
            "🌿 <b>Jardin vide</b>\n\nAucune parcelle plantée.\nTape sur <b>🌱 Planter</b> pour commencer.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")]])
        )
        return

    body = [f"🌿 <b>Tes parcelles ({len(plots)}/{max_plots})</b>", ""]
    for plot in plots:
        data = PLANTS.get(plot["plant_type"], {})
        needed = int(data.get("grow_time", 3600) / season_mult)
        elapsed = t - plot["planted_at"]
        ready = elapsed >= needed
        remaining = max(0, needed - elapsed)
        water_needed = data.get("water_needed", 1)
        water_count = plot.get("water_count", 0)

        status = "✅ PRÊTE !" if ready else f"⏳ {fmt_time(remaining)}"
        water_status = f"💧 {water_count}/{water_needed}"
        illegal = " ⚠️ Illégal" if data.get("illegal") else ""

        body.append(
            f"#{plot['plot_id']} {data.get('emoji','🌱')} <b>{plot['plant_type']}</b>{illegal}\n"
            f"   {status} | {water_status}\n"
            f"   💰 Valeur : {fmt(int(data.get('value', 0) * season_mult))}"
        )

    await safe_edit(
        query,
        "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💧 Arroser", callback_data="garden_water_menu"),
             InlineKeyboardButton("🌾 Récolter", callback_data="garden_harvest_menu")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")],
        ])
    )


# ═══════════════════════════════════════════════════════════════════
#              🌱 PLANTER — choisir la plante
# ═══════════════════════════════════════════════════════════════════
async def show_plant_menu(query, user_id: int):
    plots = await get_garden(user_id)
    max_plots = await get_max_plots(user_id)
    if len(plots) >= max_plots:
        await safe_edit(
            query,
            f"❌ Jardin plein ! ({max_plots}/{max_plots})\nRécolte d'abord tes plantes.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")]])
        )
        return

    season_mult = await get_season_multiplier(user_id)
    u = await get_user(user_id)

    body = [
        f"💰 Ton solde : <b>{fmt(u['balance'])}</b>",
        f"🍃 Saison : multiplicateur ×{season_mult:.1f}",
        "",
        "<i>Tape sur une plante pour la semer.</i>",
    ]

    keyboard = []
    for i, (plant, data) in enumerate(PLANTS.items()):
        seed_cost = int(data["value"] * season_mult // 10)
        illegal = " ⚠️" if data.get("illegal") else ""
        can_afford = "✅" if u["balance"] >= seed_cost else "❌"
        keyboard.append([
            InlineKeyboardButton(
                f"{can_afford} {data['emoji']} {plant}{illegal} — {fmt(seed_cost)}",
                callback_data=f"garden_seed_{i}"
            )
        ])

    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")])

    await safe_edit(
        query,
        "🌱 <b>PLANTER</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_plant_seed(query, user_id: int, plant_index: int):
    plants_list = list(PLANTS.keys())
    if plant_index < 0 or plant_index >= len(plants_list):
        await safe_edit(query, "❌ Plante invalide.")
        return

    plant_name = plants_list[plant_index]
    data = PLANTS[plant_name]
    season_mult = await get_season_multiplier(user_id)
    u = await get_user(user_id)

    plots = await get_garden(user_id)
    max_plots = await get_max_plots(user_id)
    if len(plots) >= max_plots:
        await safe_edit(
            query,
            f"❌ Jardin plein ! ({max_plots}/{max_plots})",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")]])
        )
        return

    seed_cost = int(data["value"] * season_mult // 10)

    # Plante illégale → confirmation
    if data.get("illegal"):
        await safe_edit(
            query,
            f"⚠️ <b>PLANTE ILLÉGALE</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{data['emoji']} <b>{plant_name}</b>\n"
            f"💰 Coût des graines : <b>{fmt(seed_cost)}</b>\n\n"
            f"<b>Risques :</b>\n"
            f"  • Risque d'arrestation à la récolte\n"
            f"  • Karma négatif si découvert\n\n"
            f"<i>Confirmer l'achat ?</i>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(f"⚠️ Confirmer ({fmt(seed_cost)})", callback_data=f"garden_seed_confirm_{plant_index}")],
                [InlineKeyboardButton("❌ Annuler", callback_data="garden_plant_menu")],
            ])
        )
        return

    if u["balance"] < seed_cost:
        await safe_edit(
            query,
            f"❌ Fonds insuffisants.\n💰 Coût : <b>{fmt(seed_cost)}</b>\n💵 Solde : <b>{fmt(u['balance'])}</b>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_plant_menu")]])
        )
        return

    # ✅ FIX : watered_at = 0 → pas de cooldown après plantation
    await update_balance(user_id, -seed_cost, sink="agriculture")
    await update_mission_progress(user_id, "plant", 1)

    async with db_connection() as db:
        await db.execute(
            "INSERT INTO garden (user_id, plant_type, planted_at, watered_at, water_count, ready) VALUES (?,?,?,?,0,0)",
            (user_id, plant_name, now(), 0)
        )
        await db.commit()

    grow_time = int(data["grow_time"] / season_mult)
    await safe_edit(
        query,
        f"✅ <b>{plant_name} planté !</b>\n\n"
        f"{data['emoji']} Nouvelle parcelle ajoutée\n"
        f"💰 Graines : <b>{fmt(seed_cost)}</b>\n"
        f"⏱️ Croissance : <b>{fmt_time(grow_time)}</b>\n"
        f"💧 Arrosages : <b>{data['water_needed']}×</b>\n"
        f"💰 Valeur finale : <b>{fmt(int(data['value'] * season_mult))}</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💧 Arroser maintenant", callback_data="garden_water_menu")],
            [InlineKeyboardButton("🌱 Planter encore", callback_data="garden_plant_menu")],
            [InlineKeyboardButton("⬅️ Menu jardin", callback_data="garden_menu")],
        ])
    )


# ═══════════════════════════════════════════════════════════════════
#              💧 ARROSER — choisir la parcelle
# ═══════════════════════════════════════════════════════════════════
async def show_water_menu(query, user_id: int):
    plots = await get_garden(user_id)

    if not plots:
        await safe_edit(
            query,
            "🌿 Jardin vide, rien à arroser.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")]])
        )
        return

    body = ["💧 <b>ARROSER UNE PARCELLE</b>", ""]
    keyboard = []
    for plot in plots:
        data = PLANTS.get(plot["plant_type"], {})
        water_needed = data.get("water_needed", 1)
        water_count = plot.get("water_count", 0)
        status = "✅" if water_count >= water_needed else f"💧{water_count}/{water_needed}"

        body.append(f"{status} #{plot['plot_id']} {data.get('emoji','🌱')} {plot['plant_type']}")
        if water_count < water_needed:
            keyboard.append([
                InlineKeyboardButton(
                    f"💧 Arroser #{plot['plot_id']} ({plot['plant_type']})",
                    callback_data=f"garden_water_do_{plot['plot_id']}"
                )
            ])

    if not keyboard:
        body.append("")
        body.append("<i>Toutes tes plantes sont suffisamment arrosées ✅</i>")

    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")])

    await safe_edit(
        query,
        "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_water_plot(query, user_id: int, plot_id: int):
    plots = await get_garden(user_id)
    plot = next((p for p in plots if p["plot_id"] == plot_id), None)
    if not plot:
        await safe_edit(
            query,
            "❌ Parcelle introuvable.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")]])
        )
        return

    data = PLANTS.get(plot["plant_type"], {})
    water_needed = data.get("water_needed", 1)
    water_count = plot.get("water_count", 0)

    if water_count >= water_needed:
        await safe_edit(
            query,
            f"💧 <b>{plot['plant_type']}</b> a déjà assez d'eau ({water_count}/{water_needed}).",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_water_menu")]])
        )
        return

    # ✅ FIX : cooldown 15min, et seulement si on a DÉJÀ arrosé (watered_at > 0)
    last_water = plot.get("watered_at", 0) or 0
    if last_water > 0 and now() - last_water < WATER_COOLDOWN:
        rem = WATER_COOLDOWN - (now() - last_water)
        await safe_edit(
            query,
            f"⏳ Cette parcelle vient d'être arrosée !\n⏱️ Attends <b>{fmt_time(rem)}</b>.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_water_menu")]])
        )
        return

    async with db_connection() as db:
        await db.execute(
            "UPDATE garden SET water_count = water_count + 1, watered_at = ? WHERE plot_id = ?",
            (now(), plot_id)
        )
        await db.commit()

    new_water = water_count + 1
    msg = f"💧 <b>{plot['plant_type']} arrosée !</b>\n💧 Eau : {new_water}/{water_needed}"
    if new_water >= water_needed:
        msg += "\n✅ <b>Suffisamment arrosée !</b>"

    await safe_edit(
        query,
        msg,
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💧 Arroser une autre", callback_data="garden_water_menu")],
            [InlineKeyboardButton("⬅️ Menu jardin", callback_data="garden_menu")],
        ])
    )


# ═══════════════════════════════════════════════════════════════════
#              🌾 RÉCOLTER — choisir la parcelle
# ═══════════════════════════════════════════════════════════════════
async def _grant_recolte(user_id: int, n: int) -> None:
    """Chaque plante récoltée donne aussi des « Récoltes fraîches » (intrant des entreprises d'alimentation)."""
    try:
        from config_chain import GARDEN_GOOD, GARDEN_UNITS_PER_PLANT
        from utils.chain import inv_add
        from database import db_connection as _dbc
        async with _dbc() as db:
            await inv_add(db, user_id, GARDEN_GOOD, max(1, n) * GARDEN_UNITS_PER_PLANT)
            await db.commit()
    except Exception:
        logging.getLogger(__name__).exception("Récolte → intrant impossible")


async def show_harvest_menu(query, user_id: int):
    plots = await get_garden(user_id)
    season_mult = await get_season_multiplier(user_id)
    t = now()

    if not plots:
        await safe_edit(
            query,
            "🌿 Jardin vide, rien à récolter.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")]])
        )
        return

    body = ["🌾 <b>RÉCOLTER UNE PARCELLE</b>", ""]
    keyboard = []
    for plot in plots:
        data = PLANTS.get(plot["plant_type"], {})
        grow_time = int(data.get("grow_time", 0) / season_mult)
        elapsed = t - plot["planted_at"]
        ready = elapsed >= grow_time

        if ready:
            water_count = plot.get("water_count", 0)
            water_needed = data.get("water_needed", 1)
            water_bonus = min(1.5, 1.0 + (water_count / max(1, water_needed)) * 0.5)
            value = int(data.get("value", 0) * water_bonus * season_mult)
            body.append(f"✅ #{plot['plot_id']} {data.get('emoji','🌱')} {plot['plant_type']} — {fmt(value)}")
            keyboard.append([
                InlineKeyboardButton(
                    f"🌾 Récolter #{plot['plot_id']} ({plot['plant_type']})",
                    callback_data=f"garden_harvest_do_{plot['plot_id']}"
                )
            ])
        else:
            rem = grow_time - elapsed
            body.append(f"⏳ #{plot['plot_id']} {data.get('emoji','🌱')} {plot['plant_type']} — {fmt_time(rem)} restant")

    if not keyboard:
        body.append("")
        body.append("<i>Aucune plante prête pour le moment.</i>")

    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")])

    await safe_edit(
        query,
        "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_harvest_plot(query, user_id: int, plot_id: int):
    plots = await get_garden(user_id)
    plot = next((p for p in plots if p["plot_id"] == plot_id), None)
    if not plot:
        await safe_edit(query, "❌ Parcelle introuvable.")
        return

    season_mult = await get_season_multiplier(user_id)
    t = now()
    data = PLANTS.get(plot["plant_type"], {})
    grow_time = int(data.get("grow_time", 0) / season_mult)

    if t - plot["planted_at"] < grow_time:
        rem = (plot["planted_at"] + grow_time) - t
        await safe_edit(
            query,
            f"⏳ Pas encore prête ! Reste <b>{fmt_time(rem)}</b>.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_harvest_menu")]])
        )
        return

    u = await get_user(user_id)
    water_count = plot.get("water_count", 0)
    water_needed = data.get("water_needed", 1)
    water_bonus = min(1.5, 1.0 + (water_count / max(1, water_needed)) * 0.5)
    value = int(data.get("value", 0) * water_bonus * season_mult)

    # Plante illégale → risque d'arrestation
    if data.get("illegal"):
        arrest_risk = 0.2 - (u.get("karma", 0) / 5000)
        if random.random() < max(0.05, min(0.4, arrest_risk)):
            jail_time = 7200
            await update_field(user_id, "prison_until", now() + jail_time)
            async with db_connection() as db:
                await db.execute("DELETE FROM garden WHERE plot_id = ?", (plot_id,))
                await db.commit()
            await safe_edit(
                query,
                f"🚨 <b>ARRESTATION !</b>\n\n"
                f"La police t'a surpris en récoltant du <b>{plot['plant_type']}</b> !\n"
                f"⛓️ Prison : <b>{fmt_time(jail_time)}</b>",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")]])
            )
            return

    # Récolte
    async with db_connection() as db:
        await db.execute("DELETE FROM garden WHERE plot_id = ?", (plot_id,))
        await db.commit()

    # ⭐ Utilisation de add_coins (boost Coins appliqué automatiquement)
    await add_coins(user_id, value)
    await increment_field(user_id, "plants_grown")
    await _grant_recolte(user_id, 1)   # 🥕 bien de base pour les entreprises
    # ⭐ Utilisation de add_xp (boost XP appliqué automatiquement)
    await add_xp(user_id, 50)
    await update_mission_progress(user_id, "harvest", 1)

    bonus_msg = ""
    if water_bonus > 1.0:
        bonus_msg = f"\n💧 Bonus arrosage : ×{water_bonus:.2f}"

    await safe_edit(
        query,
        f"🌾 <b>Récolte !</b>\n\n"
        f"{data.get('emoji','🌿')} <b>{plot['plant_type']}</b>\n"
        f"💰 Valeur : <b>{fmt(value)}</b>{bonus_msg}\n"
        f"✨ +50 XP",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🌾 Récolter une autre", callback_data="garden_harvest_menu")],
            [InlineKeyboardButton("⬅️ Menu jardin", callback_data="garden_menu")],
        ])
    )


# ═══════════════════════════════════════════════════════════════════
#              🌾 RÉCOLTER TOUT
# ═══════════════════════════════════════════════════════════════════
async def do_harvest_all(query, user_id: int):
    from gameplay.garden import GardenError, harvest_all_ready
    try:
        result = await harvest_all_ready(user_id)
    except GardenError as exc:
        await safe_edit(
            query,
            f"🌿 {escape_html(str(exc))}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="garden_menu")]])
        )
        return

    body = ["🌾 <b>Récolte groupée</b>", ""]
    for crop in result["harvested"]:
        body.append(f"{escape_html(crop['emoji'])} {escape_html(crop['plant_type'])} — {fmt(crop['value'])}")
    if result["total"] > 0:
        body += ["", f"💰 <b>Total : {fmt(result['total'])}</b>", f"✨ +{result['xp']} XP"]
    if result["arrested"]:
        body += ["", "🚨 <b>ARRESTATION !</b>",
                 f"Confisqué : {escape_html(', '.join(result['arrested']))}",
                 f"⛓️ Prison : <b>{fmt_time(result['jail_seconds'])}</b>"]
    if not result["harvested"] and not result["arrested"]:
        body.append("❌ Aucune récolte valide.")

    await safe_edit(
        query,
        "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("⬅️ Menu jardin", callback_data="garden_menu")],
        ])
    )


# ═══════════════════════════════════════════════════════════════════
#              🎯 CALLBACK ROUTEUR JARDIN
# ═══════════════════════════════════════════════════════════════════
async def garden_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Gère tous les callbacks commençant par 'garden_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "garden_menu":
        await show_garden_menu(query, user_id)
        return

    if data == "garden_view":
        await show_garden_view(query, user_id)
        return

    if data == "garden_plant_menu":
        await show_plant_menu(query, user_id)
        return

    if data.startswith("garden_seed_confirm_"):
        try:
            idx = int(data.replace("garden_seed_confirm_", ""))
        except ValueError:
            return
        plants_list = list(PLANTS.keys())
        if idx < 0 or idx >= len(plants_list):
            return
        plant_name = plants_list[idx]
        data_plant = PLANTS[plant_name]
        season_mult = await get_season_multiplier(user_id)
        u = await get_user(user_id)
        seed_cost = int(data_plant["value"] * season_mult // 10)
        if u["balance"] < seed_cost:
            await safe_edit(query, f"❌ Fonds insuffisants. Coût : {fmt(seed_cost)}")
            return
        plots = await get_garden(user_id)
        max_plots = await get_max_plots(user_id)
        if len(plots) >= max_plots:
            await safe_edit(query, "❌ Jardin plein.")
            return

        # ✅ FIX : watered_at = 0
        await update_balance(user_id, -seed_cost, sink="agriculture")
        await update_mission_progress(user_id, "plant", 1)
        async with db_connection() as db:
            await db.execute(
                "INSERT INTO garden (user_id, plant_type, planted_at, watered_at, water_count, ready) VALUES (?,?,?,?,0,0)",
                (user_id, plant_name, now(), 0)
            )
            await db.commit()
        await safe_edit(
            query,
            f"✅ <b>{plant_name} planté !</b>\n\n"
            f"⚠️ <i>Plante illégale — risque à la récolte.</i>\n\n"
            f"💧 Tu peux arroser dès maintenant.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💧 Arroser maintenant", callback_data="garden_water_menu")],
                [InlineKeyboardButton("🌿 Voir mes parcelles", callback_data="garden_view")],
                [InlineKeyboardButton("⬅️ Menu jardin", callback_data="garden_menu")],
            ])
        )
        return

    if data.startswith("garden_seed_"):
        try:
            idx = int(data.replace("garden_seed_", ""))
        except ValueError:
            return
        await do_plant_seed(query, user_id, idx)
        return

    if data == "garden_water_menu":
        await show_water_menu(query, user_id)
        return

    if data.startswith("garden_water_do_"):
        try:
            plot_id = int(data.replace("garden_water_do_", ""))
        except ValueError:
            return
        await do_water_plot(query, user_id, plot_id)
        return

    if data == "garden_harvest_menu":
        await show_harvest_menu(query, user_id)
        return

    if data == "garden_harvest_all":
        await do_harvest_all(query, user_id)
        return

    if data.startswith("garden_harvest_do_"):
        try:
            plot_id = int(data.replace("garden_harvest_do_", ""))
        except ValueError:
            return
        await do_harvest_plot(query, user_id, plot_id)
        return


# ═══════════════════════════════════════════════════════════════════
#              COMMANDES TEXTE EXISTANTES (compatibilité)
# ═══════════════════════════════════════════════════════════════════
@require_registered
async def cmd_jardin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    plots = await get_garden(user.id)
    t = now()
    season_mult = await get_season_multiplier(user.id)
    max_plots = await get_max_plots(user.id)

    if not plots:
        plants_text = "\n".join(
            f"• {data['emoji']} **{plant}** — {fmt_time(int(data['grow_time'] / season_mult))} — 💰 {fmt(int(data['value'] * season_mult))}"
            for plant, data in PLANTS.items()
        )
        await update.message.reply_text(
            f"🌿 <b>Ton jardin est vide !</b>\n\n"
            f"Tu as {escape_html(max_plots)} parcelles disponibles.\n\n"
            f"<b>Plantes disponibles :</b>\n{escape_html(plants_text)}\n\n"
            f"<i>Ou utilise le menu → 🎲 Loisirs → Jardin</i>",
            parse_mode="HTML"
        )
        return

    text = f"🌿 <b>Ton jardin ({escape_html(len(plots))}/{escape_html(max_plots)} parcelles)</b>\n\n"
    for plot in plots:
        data = PLANTS.get(plot["plant_type"], {})
        needed = int(data.get("grow_time", 3600) / season_mult)
        elapsed = t - plot["planted_at"]
        ready = elapsed >= needed
        remaining = max(0, needed - elapsed)
        water_needed = data.get("water_needed", 1)
        water_count = plot.get("water_count", 0)

        status = "✅ PRÊTE !" if ready else f"⏳ {fmt_time(remaining)}"
        water_status = f"💧 Eau : {water_count}/{water_needed}"
        illegal = "⚠️ Illégale" if data.get("illegal") else ""

        text += (
            f"#{escape_html(plot['plot_id'])} {escape_html(data.get('emoji','🌱'))} <b>{escape_html(plot['plant_type'])}</b> {escape_html(illegal)}\n"
            f"  {escape_html(status)} | {escape_html(water_status)}\n"
            f"  💰 Valeur (saison) : {escape_html(fmt(int(data.get('value', 0) * season_mult)))}\n\n"
        )

    text += "<i>Ou utilise le menu → 🎲 Loisirs → Jardin</i>"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
@cooldown("plant_cooldown", 5, "⏳ Attends un instant avant de replanter.")
async def cmd_planter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    plots = await get_garden(user.id)
    max_plots = await get_max_plots(user.id)

    if len(plots) >= max_plots:
        await update.message.reply_text(
            f"❌ Ton jardin est plein ! ({max_plots}/{max_plots} parcelles)\n"
            "Récolte d'abord les plantes prêtes depuis le menu"
        )
        return

    if not context.args:
        season_mult = await get_season_multiplier(user.id)
        text = "🌱 <b>Plantes disponibles</b>\n\n"
        for plant, data in PLANTS.items():
            illegal = "⚠️ Illégal" if data.get("illegal") else ""
            text += (
                f"{escape_html(data['emoji'])} <b>{escape_html(plant)}</b> {escape_html(illegal)}\n"
                f"  ⏱️ {escape_html(fmt_time(int(data['grow_time'] / season_mult)))}\n"
                f"  💰 Valeur (saison) : {escape_html(fmt(int(data['value'] * season_mult)))}\n"
                f"  💧 Arrosages : {escape_html(data['water_needed'])}x\n\n"
            )
        text += "<i>/planter [nom] pour planter</i>"
        await update.message.reply_text(text, parse_mode="HTML")
        return

    plant_name = " ".join(context.args).capitalize()
    matched = None
    for p in PLANTS:
        if p.lower() == plant_name.lower():
            matched = p
            break
    if not matched:
        await update.message.reply_text("❌ Plante inconnue. Utilise le menu pour voir la liste.")
        return

    plant_data = PLANTS[matched]
    season_mult = await get_season_multiplier(user.id)

    if plant_data.get("illegal"):
        if len(context.args) >= 2 and context.args[1].lower() in ("oui", "yes", "--force"):
            pass
        else:
            await update.message.reply_text(
                f"⚠️ **Attention !** {matched} est une plante illégale.\n"
                f"Planter et récolter peut conduire à la prison.\n\n"
                f"Si tu veux continuer, utilise le bouton « Planter quand même »."
            )
            return

    seed_cost = int(plant_data["value"] * season_mult // 10)
    if u["balance"] < seed_cost:
        await update.message.reply_text(
            f"❌ Graines trop chères !\n"
            f"💰 Coût des graines (saison) : {fmt(seed_cost)}\n"
            f"💵 Ton solde : {fmt(u['balance'])}"
        )
        return

    await update_balance(user.id, -seed_cost, sink="agriculture")
    await update_mission_progress(user.id, "plant", 1)

    # ✅ FIX : watered_at = 0
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO garden (user_id, plant_type, planted_at, watered_at, water_count, ready) VALUES (?,?,?,?,0,0)",
            (user.id, matched, now(), 0)
        )
        await db.commit()

    await update.message.reply_text(
        f"🌱 <b>{escape_html(matched)} planté !</b>\n\n"
        f"{escape_html(plant_data['emoji'])} Dans ta parcelle #{escape_html(len(plots) + 1)}\n"
        f"💰 Graines (saison) : {escape_html(fmt(seed_cost))}\n"
        f"⏱️ Temps de croissance (saison) : {escape_html(fmt_time(int(plant_data['grow_time'] / season_mult)))}\n"
        f"💧 Arrosages nécessaires : {escape_html(plant_data['water_needed'])}x\n"
        f"💰 Valeur à la récolte (saison) : {escape_html(fmt(int(plant_data['value'] * season_mult)))}",
        parse_mode="HTML"
    )


@require_registered
@cooldown("water_cooldown", 60, "⏳ Attends un peu avant d'arroser à nouveau.")
async def cmd_arroser(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    plots = await get_garden(user.id)

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🎲 Loisirs → Jardin.")
        return

    try:
        plot_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID invalide.")
        return

    plot = next((p for p in plots if p["plot_id"] == plot_id), None)
    if not plot:
        await update.message.reply_text("❌ Parcelle introuvable.")
        return

    plant_data = PLANTS.get(plot["plant_type"], {})
    water_needed = plant_data.get("water_needed", 1)
    water_count = plot.get("water_count", 0)

    if water_count >= water_needed:
        await update.message.reply_text(f"💧 Cette plante a déjà assez d'eau (max {water_needed}).")
        return

    # ✅ FIX : cooldown 15min seulement si déjà arrosé
    last_water = plot.get("watered_at", 0) or 0
    if last_water > 0 and now() - last_water < WATER_COOLDOWN:
        rem = WATER_COOLDOWN - (now() - last_water)
        await update.message.reply_text(f"⏳ Cette parcelle vient d'être arrosée ! Attends {fmt_time(rem)}.")
        return

    async with db_connection() as db:
        await db.execute(
            "UPDATE garden SET water_count = water_count + 1, watered_at = ? WHERE plot_id = ?",
            (now(), plot_id)
        )
        await db.commit()

    new_water = water_count + 1
    await update.message.reply_text(
        f"💧 **{plot['plant_type']} arrosé !**\n\n"
        f"💧 Arrosages : {new_water}/{water_needed}\n"
        f"{'✅ Suffisamment arrosé !' if new_water >= water_needed else f'⏳ Encore {water_needed - new_water}x nécessaire.'}"
    )


@require_registered
@require_free
@cooldown("harvest_cooldown", 5, "⏳ Attends un instant avant de récolter à nouveau.")
async def cmd_recolter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    plots = await get_garden(user.id)
    t = now()
    season_mult = await get_season_multiplier(user.id)

    if not context.args:
        from gameplay.garden import GardenError, harvest_all_ready
        try:
            result = await harvest_all_ready(user.id)
        except GardenError as exc:
            await update.message.reply_text(f"🌿 {escape_html(str(exc))}", parse_mode="HTML")
            return
        harvested = result["harvested"]
        text = "🌾 <b>Récolte groupée !</b>\n\n"
        for crop in harvested:
            text += f"{escape_html(crop['emoji'])} {escape_html(crop['plant_type'])} — {escape_html(fmt(crop['value']))}\n"
        if result["total"]:
            text += f"\n💰 <b>Total : {escape_html(fmt(result['total']))}</b>\n✨ +{result['xp']} XP"
        else:
            text += "\n❌ Aucune récolte valide."
        if result["arrested"]:
            text += f"\n\n🚨 <b>ARRESTATION !</b>\nConfisqué : {escape_html(', '.join(result['arrested']))}\n⛓️ Prison : <b>{escape_html(fmt_time(result['jail_seconds']))}</b>"
        await update.message.reply_text(text, parse_mode="HTML")
        return

    try:
        plot_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID invalide. Utilise le bouton « Tout récolter ».")
        return

    plot = next((p for p in plots if p["plot_id"] == plot_id), None)
    if not plot:
        await update.message.reply_text("❌ Parcelle introuvable.")
        return

    plant_data = PLANTS.get(plot["plant_type"], {})
    grow_time = int(plant_data.get("grow_time", 0) / season_mult)
    if t < plot["planted_at"] + grow_time:
        rem = (plot["planted_at"] + grow_time) - t
        await update.message.reply_text(f"⏳ Pas encore prête ! Attends {fmt_time(rem)}.")
        return

    water_count = plot.get("water_count", 0)
    water_needed = plant_data.get("water_needed", 1)
    water_bonus = min(1.5, 1.0 + (water_count / max(1, water_needed)) * 0.5)
    base_val = plant_data.get("value", 0)
    value = int(base_val * water_bonus * season_mult)

    if plant_data.get("illegal"):
        arrest_risk = 0.2 - (u.get("karma", 0) / 5000)
        if random.random() < max(0.05, min(0.4, arrest_risk)):
            jail_time = 7200
            await update_field(user.id, "prison_until", now() + jail_time)
            await update.message.reply_text(
                f"🚨 <b>ARRESTATION !</b>\n\nLa police t'a surpris en récoltant du <b>{escape_html(plot['plant_type'])}</b> !\n"
                f"⛓️ Prison : {escape_html(fmt_time(jail_time))}",
                parse_mode="HTML"
            )
            async with db_connection() as db2:
                await db2.execute("DELETE FROM garden WHERE plot_id = ?", (plot_id,))
                await db2.commit()
            return

    async with db_connection() as db2:
        await db2.execute("DELETE FROM garden WHERE plot_id = ?", (plot_id,))
        await db2.commit()

    # ⭐ Utilisation de add_coins (boost Coins appliqué automatiquement)
    await add_coins(user.id, value)
    await increment_field(user.id, "plants_grown")
    await _grant_recolte(user.id, 1)   # 🥕 bien de base pour les entreprises
    # ⭐ Utilisation de add_xp (boost XP appliqué automatiquement)
    await add_xp(user.id, 50)
    await update_mission_progress(user.id, "harvest", 1)

    import html as _html
    msg = (
        f"🌾 <b>Récolte !</b>\n\n"
        f"{plant_data.get('emoji','🌿')} <b>{_html.escape(str(plot['plant_type']))}</b>\n"
        f"💰 Valeur (saison) : {fmt(value)}\n"
    )
    if water_bonus > 1.0:
        msg += f"💧 Bonus arrosage : x{round(water_bonus, 1)}\n"
    msg += f"✨ +50 XP"
    await update.message.reply_text(msg, parse_mode="HTML")


@require_registered
async def cmd_vendrecolte(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Vendre toutes les plantes prêtes à récolter (appel de le menu groupé)."""
    await cmd_recolter(update, context)


async def process_garden_maintenance():
    """Retire les plantes mortes et avertit leur propriétaire une seule fois."""
    from collections import defaultdict
    async with db_connection() as db:
        t = now()
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT plot_id,user_id,plant_type,planted_at FROM garden") as cur:
            rows = await cur.fetchall()
        dead_by_user = defaultdict(list)
        from config import PLANTS
        for plot_id, user_id, plant_type, planted_at in rows:
            data = PLANTS.get(plant_type)
            if data and int(planted_at or 0) + int(data.get("grow_time", 0)) * 2 < t:
                await db.execute("DELETE FROM garden WHERE plot_id=? AND user_id=?", (plot_id, user_id))
                dead_by_user[int(user_id)].append(str(plant_type))
        for user_id, dead in dead_by_user.items():
            counts = defaultdict(int)
            for plant in dead:
                counts[plant] += 1
            summary = ", ".join(f"{name} ×{count}" for name, count in sorted(counts.items()))
            message = f"🌿 Maintenance du jardin : {len(dead)} plante(s) morte(s) et retirée(s) faute de récolte ({summary})."
            await db.execute(
                "INSERT INTO notifications (user_id,title,message,created_at) VALUES (?, 'Jardin', ?, ?)",
                (user_id, message, t),
            )
        await db.commit()
    return sum(len(dead) for dead in dead_by_user.values())
