# handlers/personnage.py — 🪪 Mon personnage : identité RP et avatar (préfixe `pc:`)
"""
Création guidée en 3 étapes (prénom, nom, sexe), puis carte d'identité modifiable à tout moment.
Un brouillon est enregistré à chaque étape : on peut quitter et reprendre. Sans effet sur l'équilibre du jeu.
"""
import html
import logging

from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M, Update
from telegram.ext import ContextTypes

from utils import character as chr_
from utils.decorators import require_registered
from utils.input_flow import ask, flow
from utils.notify import notify
from utils.ui import esc, layout

logger = logging.getLogger(__name__)
CB = "pc:"
SEP = "━━━━━━━━━━━━━━━━━━"
HELP = {
    "first_name": "Quel est le <b>prénom</b> de ton personnage ? (2 à 20 caractères)",
    "last_name": "Et son <b>nom de famille</b> ? (2 à 20 caractères)",
}


async def _send(update: Update, text: str, markup: M) -> None:
    q = update.callback_query
    if q:
        try:
            await q.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
            return
        except Exception:
            await q.message.reply_text(text, parse_mode="HTML", reply_markup=markup)
            return
    await update.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


def _nav(rows=None, back: str = "hub:profil") -> M:
    rows = list(rows or [])
    rows.append([B("⬅️ Retour", callback_data=back), B("🎮 Menu principal", callback_data="hub:home")])
    return M(rows)


async def show_home(update: Update, uid: int, note: str = "") -> None:
    ch = await chr_.get(uid)
    if ch and ch["complete"]:
        lines = [f"🪪 <b>CARTE D'IDENTITÉ</b>\n{SEP}"] + ([note] if note else []) + chr_.card_lines(ch)
        rows = [[B("✏️ Modifier mon personnage", callback_data=CB + "edit")]]
        await _send(update, "\n".join(lines), _nav(rows))
        return
    started = bool(ch and (ch["first_name"] or ch["gender"]))
    lines = [f"🪪 <b>MON PERSONNAGE</b>\n{SEP}"] + ([note] if note else []) + [
        "Donne une identité à ton personnage : prénom, nom et sexe.",
        "", "<i>Ce sont des choix d'identité : ils n'influencent ni l'argent, ni l'XP, ni les gains.</i>"]
    if started:
        lines.append(f"\n✏️ Création en cours — il te reste des étapes.")
    rows = [[B("▶️ Continuer la création" if started else "✨ Créer mon personnage", callback_data=CB + "go")]]
    await _send(update, "\n".join(lines), _nav(rows))


async def show_step(update: Update, context, uid: int, field: str, editing: bool = False) -> None:
    ch = await chr_.ensure(uid)
    idx = chr_.STEPS.index(field) + 1
    head = f"🪪 <b>{chr_.FIELD_LABEL[field].upper()}</b>  ·  étape {idx}/{len(chr_.STEPS)}\n{SEP}\n"
    if field in HELP:
        back = CB + ("edit" if editing else "home")
        await ask(update.callback_query or update, context, "pc_text", head + HELP[field], kind="text",
                  data={"field": field, "editing": editing}, back=back)
        return
    opts = dict(chr_.options(field))
    btns = [B(f"{e} {l}", callback_data=f"{CB}set:{field}:{code}:{int(editing)}") for code, (e, l) in opts.items()]
    cur = ch.get(field)
    note = f"\nActuel : <b>{esc(str(chr_.options(field).get(cur, ('', cur))[1]))}</b>" if cur else ""
    await _send(update, head + "Choisis :" + note, _nav(layout(btns), back=CB + ("edit" if editing else "home")))


async def _after(update: Update, context, uid: int, editing: bool) -> None:
    """Étape suivante de la création, ou retour à la carte si on modifie / si tout est rempli."""
    ch = await chr_.get(uid)
    if editing or (ch and ch["complete"]):
        await show_home(update, uid, "✅ Modifié.")
        return
    nxt = chr_.next_missing(ch)
    if nxt:
        await show_step(update, context, uid, nxt)
    else:
        await _finish(update, uid)


async def _finish(update: Update, uid: int) -> None:
    if await chr_.finish(uid):
        await notify(uid, "🪪 Personnage créé", "Ta carte d'identité est prête : retrouve-la dans "
                     "🎮 Menu → 📜 Profil & infos → Mon personnage.", "success")
        ch = await chr_.get(uid)
        lines = [f"🪪 <b>CARTE D'IDENTITÉ</b>\n{SEP}", "🎉 <b>Ton personnage est prêt ! Bienvenue dans Earth Angel RP.</b>"] \
            + chr_.card_lines(ch)
        rows = [[B("🚀 Entrer dans le jeu", callback_data="menu_main")],
                [B("✏️ Modifier mon personnage", callback_data=CB + "edit")]]
        await _send(update, "\n".join(lines), _nav(rows))
    else:
        await show_home(update, uid, "ℹ️ Il reste des étapes à remplir.")


@flow("pc_text")
async def _flow_text(update, context, value, data):
    uid = update.effective_user.id
    field = data["field"]
    ok = await chr_.set_field(uid, field, str(value))
    if not ok:
        await ask(update, context, "pc_text", "❌ Valeur refusée (longueur ou caractères). Réessaie :", kind="text",
                  data=data, back=CB + "home")
        return
    await _after(update, context, uid, bool(data.get("editing")))


async def show_edit(update: Update, uid: int) -> None:
    btns = [B(chr_.FIELD_LABEL[f], callback_data=f"{CB}ed:{f}") for f in chr_.STEPS]
    await _send(update, f"✏️ <b>MODIFIER MON PERSONNAGE</b>\n{SEP}\nQue veux-tu changer ?", _nav(layout(btns), back=CB + "home"))


async def show_card_of(update: Update, uid: int, target: int) -> None:
    ch = await chr_.get(target)
    if not ch or not ch["complete"]:
        await _send(update, "🪪 Ce joueur n'a pas encore créé son personnage.", _nav(back="rs:home"))
        return
    await _send(update, f"🪪 <b>CARTE D'IDENTITÉ</b>\n{SEP}\n" + "\n".join(chr_.card_lines(ch)), _nav(back=f"rs:pf:{target}"))


@require_registered
async def cmd_personnage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_home(update, update.effective_user.id)


async def pc_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    uid = q.from_user.id
    p = (q.data or "").split(":")
    act = p[1] if len(p) > 1 else "home"
    try:
        await q.answer()
        if act == "go":
            ch = await chr_.ensure(uid)
            nxt = chr_.next_missing(ch)
            if nxt:
                await show_step(update, context, uid, nxt)
            else:
                await _finish(update, uid)
        elif act == "edit":
            await show_edit(update, uid)
        elif act == "ed" and len(p) > 2 and p[2] in chr_.STEPS:
            await show_step(update, context, uid, p[2], editing=True)
        elif act == "set" and len(p) > 4 and p[2] in chr_.FIELDS:
            ok = await chr_.set_field(uid, p[2], p[3])
            if not ok:
                await show_step(update, context, uid, p[2], editing=p[4] == "1")
                return
            await _after(update, context, uid, p[4] == "1")
        elif act == "view" and len(p) > 2 and p[2].isdigit():
            await show_card_of(update, uid, int(p[2]))
        else:
            await show_home(update, uid)
    except Exception:
        logger.exception("Personnage : erreur sur %s", q.data)
