from utils.swallow import swallowed
import asyncio
# handlers/realestate.py — Immobilier 100 % boutons + saisies (plus aucune commande Telegram)
#
# Les fonctions `cmd_*` restent la logique métier ; elles sont appelées par les boutons du menu
# Immobilier et par les formulaires (utils/forms.py) définis en bas de ce fichier.
# Les biens sont désignés par leur identifiant interne (prop_id) : jamais de numéro à retaper.
import aiosqlite
import random
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import (
    Outbox,
    DeferredReply,
    DB_PATH, get_user, update_balance, update_field, get_properties,
    add_notification, now, db_connection,
)
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, parse_amount, fmt_time, escape_html
from utils.vip import max_properties as vip_max_properties
from config import PROPERTIES, CITIES, SEASON_EFFECTS
from utils.gametime import add_game_months, add_game_years

MAX_PROPERTIES = 20  # Base (les bonus VIP s'ajoutent)
DOWN_PAYMENT_RATE = 0.20      # apport demandé pour une hypothèque
MORTGAGE_YEARS = 30
PER_PAGE = 6                  # biens par page dans « Mes biens »

CB_MENU = "invest_immobilier"   # bouton « retour » vers le menu Immobilier


def _back_kb(*extra_rows) -> InlineKeyboardMarkup:
    rows = [list(r) for r in extra_rows]
    rows.append([InlineKeyboardButton("🏠 Immobilier", callback_data=CB_MENU)])
    return InlineKeyboardMarkup(rows)


async def get_max_properties(user_id: int) -> int:
    """Retourne le nombre max de propriétés (base + bonus VIP)."""
    u = await get_user(user_id)
    return vip_max_properties(u, MAX_PROPERTIES)


# ==================== HELPERS MULTIPLICATEURS ====================
async def get_city_multipliers(user_id: int) -> dict:
    u = await get_user(user_id)
    city = u.get("location", "Paris")
    return CITIES.get(city, {"realestate_mult": 1.0, "vehicle_mult": 1.0, "salary_mult": 1.0,
                             "market_mult": 1.0, "crime_mult": 1.0})


async def get_season_multiplier() -> float:
    try:
        from handlers.events import get_calendar
        cal = await get_calendar()
        season = cal["season"]
        fx = SEASON_EFFECTS.get(season, {})
        return fx.get("garden_mult", 1.0)
    except ImportError:
        return 1.0


# ==================== OUTILS ====================
def _match_type(raw: str) -> str | None:
    raw = (raw or "").strip().lower()
    for p in PROPERTIES:
        if p.lower() == raw:
            return p
    return None


async def _owned(user_id: int, raw_id) -> dict | None:
    """Bien du joueur par prop_id (None si inconnu ou s'il ne lui appartient pas)."""
    try:
        pid = int(raw_id)
    except (TypeError, ValueError):
        return None
    for p in await get_properties(user_id):
        if p["prop_id"] == pid:
            return p
    return None


def _cond_bar(condition: int) -> str:
    condition = max(0, min(100, int(condition)))
    return "█" * (condition // 10) + "░" * (10 - condition // 10)


def _prop_label(p: dict, mult_val: float = 1.0) -> str:
    data = PROPERTIES.get(p["prop_type"], {})
    name = (p.get("name") or p["prop_type"])[:22]
    return f"{data.get('emoji', '🏠')} {p['prop_type']} — {name}"


async def _drop_npc_room(db, user_id: int) -> None:
    """Un vrai logement (bien acheté ou location) remplace la chambre PNJ : plus de frais en double."""
    await db.execute("DELETE FROM housing_npc WHERE user_id=?", (user_id,))
    await db.execute("DELETE FROM housing_arrears WHERE kind='npc' AND ref_id=?", (user_id,))


# ==================== CATALOGUE ====================
@require_registered
@require_free
async def cmd_proprietes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    mult = await get_city_multipliers(user.id)
    season_mult = await get_season_multiplier()
    rmult = mult.get("realestate_mult", 1.0)

    text = "🏠 <b>Marché immobilier</b>\n\n"
    for ptype, data in PROPERTIES.items():
        price = int(data['price'] * rmult * season_mult)
        rent = int(data['rent'] * rmult)
        maint = int(data['maint'] * rmult)
        net_month = rent - maint
        yield_annual = (net_month * 12 / price) * 100 if price > 0 else 0
        text += (
            f"{data['emoji']} <b>{ptype}</b>\n"
            f"  💰 Prix : {fmt(price)}\n"
            f"  🏦 Apport hypothèque ({int(DOWN_PAYMENT_RATE * 100)} %) : {fmt(int(price * DOWN_PAYMENT_RATE))}\n"
            f"  💵 Loyer possible : {fmt(rent)}/mois · 🔧 Entretien : {fmt(maint)}/mois\n"
            f"  📈 Rendement net : {fmt(net_month)}/mois ({yield_annual:.1f} %/an)\n\n"
        )
    text += "<i>Choisis une action ci-dessous.</i>"
    kb = _back_kb(
        [InlineKeyboardButton("🏠 Acheter", callback_data="fm:re_buy"),
         InlineKeyboardButton("🏦 Hypothèque", callback_data="fm:re_mortgage")],
    )
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=kb)


# ==================== ACHAT COMPTANT ====================
@require_registered
@require_free
@cooldown("buy_property", 10, "⏳ Attends un instant avant d'acheter à nouveau.")
async def cmd_acheter_bien(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    mult = await get_city_multipliers(user.id)
    kb = _back_kb()

    matched = _match_type(" ".join(context.args)) if context.args else None
    if not matched:
        await update.message.reply_text("❌ Type de bien inconnu.", reply_markup=kb)
        return

    data = PROPERTIES[matched]
    rmult = mult.get("realestate_mult", 1.0)
    price = int(data["price"] * rmult)
    props = await get_properties(user.id)
    max_props = await get_max_properties(user.id)
    if len(props) >= max_props:
        await update.message.reply_text(
            f"❌ Tu possèdes déjà {max_props} biens : maximum atteint.\n"
            f"💡 <i>La boutique Étoiles propose <b>+5 propriétés max</b>.</i>",
            parse_mode="HTML", reply_markup=kb)
        return

    if u["balance"] < price:
        await update.message.reply_text(
            f"❌ Fonds insuffisants !\n💰 Prix : {fmt(price)}\n💵 Ton solde : {fmt(u['balance'])}\n\n"
            f"💡 Avec l'<b>hypothèque</b>, tu ne paies que {int(DOWN_PAYMENT_RATE * 100)} % maintenant "
            f"({fmt(int(price * DOWN_PAYMENT_RATE))}).",
            parse_mode="HTML",
            reply_markup=_back_kb([InlineKeyboardButton("🏦 Hypothèque", callback_data="fm:re_mortgage")]))
        return

    name = f"{matched} de {user.full_name}"[:50]

    try:
        async with db_connection() as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                    "WHERE user_id=? AND balance>=?",
                    (price, price, user.id, price),
                )
                if debit.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Fonds insuffisants.")

                await db.execute(
                    "INSERT INTO properties "
                    "(user_id,prop_type,name,purchased_at,condition,last_maintenance) "
                    "VALUES (?,?,?,?,100,?)",
                    (user.id, matched, name, now(), now()),
                )
                await _drop_npc_room(db, user.id)
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    rent_m = int(data['rent'] * rmult)
    maint_m = int(data['maint'] * rmult)
    await update.message.reply_text(
        f"🏠 <b>Propriété achetée !</b>\n\n"
        f"{data['emoji']} <b>{matched}</b>\n"
        f"💰 Prix payé : {fmt(price)}\n"
        f"💵 Loyer possible : {fmt(rent_m)}/mois · 🔧 Entretien : {fmt(maint_m)}/mois\n"
        f"📈 Rendement net mensuel : {fmt(rent_m - maint_m)}\n\n"
        f"✅ Tu as maintenant un logement : tu y dors et ton employeur a ton adresse.",
        parse_mode="HTML",
        reply_markup=_back_kb([InlineKeyboardButton("📋 Mes biens", callback_data="immobilier_mesbiens"),
                               InlineKeyboardButton("🤝 Louer", callback_data="fm:re_rent_out")]))


# ==================== ACHAT À CRÉDIT ====================
@require_registered
@require_free
@cooldown("mortgage", 10, "⏳ Attends un instant avant d'utiliser l'hypothèque.")
async def cmd_hypotheque(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)
    mult = await get_city_multipliers(user.id)
    kb = _back_kb()

    matched = _match_type(" ".join(context.args)) if context.args else None
    if not matched:
        await update.message.reply_text("❌ Type de bien inconnu.", reply_markup=kb)
        return

    data = PROPERTIES[matched]
    price = int(data["price"] * mult.get("realestate_mult", 1.0))
    down = int(price * DOWN_PAYMENT_RATE)
    mortgage = price - down
    daily = max(1, int(mortgage / 360))

    props = await get_properties(user.id)
    max_props = await get_max_properties(user.id)
    if len(props) >= max_props:
        await update.message.reply_text(
            f"❌ Tu possèdes déjà {max_props} biens : maximum atteint.\n"
            f"💡 <i>La boutique Étoiles propose <b>+5 propriétés max</b>.</i>",
            parse_mode="HTML", reply_markup=kb)
        return

    if u["balance"] < down:
        await update.message.reply_text(
            f"❌ Apport insuffisant !\n💰 Apport requis ({int(DOWN_PAYMENT_RATE * 100)} %) : {fmt(down)}\n"
            f"💵 Ton solde : {fmt(u['balance'])}", parse_mode="HTML", reply_markup=kb)
        return

    name = f"{matched} (hypothèque)"

    try:
        async with db_connection() as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                    "WHERE user_id=? AND balance>=?",
                    (down, down, user.id, down),
                )
                if debit.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Apport insuffisant.")

                await db.execute(
                    "INSERT INTO properties "
                    "(user_id,prop_type,name,purchased_at,mortgage,mortgage_due,"
                    "condition,last_maintenance) VALUES (?,?,?,?,?,?,100,?)",
                    (user.id, matched, name, now(), mortgage, add_game_years(now(), MORTGAGE_YEARS), now()),
                )
                await _drop_npc_room(db, user.id)
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    await update.message.reply_text(
        f"🏦 <b>Hypothèque accordée !</b>\n\n"
        f"{data['emoji']} <b>{matched}</b> acheté !\n"
        f"💰 Apport versé : {fmt(down)}\n"
        f"💳 Capital restant dû : {fmt(mortgage)}\n"
        f"📅 Prélèvement automatique chaque jour de jeu : ≈ {fmt(daily)} "
        f"(1/360 du capital restant)\n"
        f"⏳ Durée : {MORTGAGE_YEARS} ans\n\n"
        f"💡 Dès que tu as l'argent, tu peux <b>solder l'hypothèque d'un coup</b> "
        f"(bouton « Solder l'hypothèque »).",
        parse_mode="HTML",
        reply_markup=_back_kb([InlineKeyboardButton("💳 Solder l'hypothèque", callback_data="fm:re_payoff")]))


# ==================== SOLDER L'HYPOTHÈQUE (paiement total du restant) ====================
@require_registered
@require_free
@cooldown("payoff_mortgage", 5, "⏳ Attends un instant.")
async def cmd_solder_hypotheque(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Rembourse d'un coup tout le capital restant dû d'un bien (si le solde le permet)."""
    user = update.effective_user
    kb = _back_kb()
    prop = await _owned(user.id, context.args[0]) if context.args else None
    if not prop:
        await update.message.reply_text("❌ Bien introuvable.", reply_markup=kb)
        return
    owed = int(prop.get("mortgage") or 0)
    if owed <= 0:
        await update.message.reply_text("✅ Ce bien n'a pas (ou plus) d'hypothèque.", reply_markup=kb)
        return

    u = await get_user(user.id)
    if u["balance"] < owed:
        await update.message.reply_text(
            f"❌ Il te manque <b>{fmt(owed - u['balance'])}</b> pour solder.\n"
            f"💳 Reste dû : {fmt(owed)}\n💵 Ton solde : {fmt(u['balance'])}\n\n"
            f"<i>Les prélèvements automatiques continuent en attendant.</i>",
            parse_mode="HTML", reply_markup=kb)
        return

    try:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                async with db.execute(
                        "SELECT mortgage FROM properties WHERE prop_id=? AND user_id=?",
                        (prop["prop_id"], user.id)) as cur:
                    row = await cur.fetchone()
                owed_now = int(row["mortgage"] or 0) if row else 0
                if owed_now <= 0:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "✅ Ce bien n'a plus d'hypothèque.")
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                    "WHERE user_id=? AND balance>=?",
                    (owed_now, owed_now, user.id, owed_now),
                )
                if debit.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Fonds insuffisants.")
                await db.execute(
                    "UPDATE properties SET mortgage=0, mortgage_due=0 WHERE prop_id=? AND user_id=?",
                    (prop["prop_id"], user.id),
                )
                await db.commit()
                owed = owed_now
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    await update.message.reply_text(
        f"🎉 <b>Hypothèque soldée !</b>\n\n"
        f"{escape_html(_prop_label(prop))}\n"
        f"💰 Payé d'un coup : {fmt(owed)}\n"
        f"✅ Ce bien est maintenant à toi, sans aucune dette.",
        parse_mode="HTML", reply_markup=kb)


# ==================== MES BIENS ====================
async def render_mesbiens(user_id: int, page: int = 1) -> tuple[str, InlineKeyboardMarkup]:
    props = await get_properties(user_id)
    mult_val = (await get_city_multipliers(user_id)).get("realestate_mult", 1.0)
    max_props = await get_max_properties(user_id)

    if not props:
        return ("🏠 Tu ne possèdes aucune propriété.\nOuvre le marché pour en acheter une.",
                _back_kb([InlineKeyboardButton("🏪 Marché", callback_data="immobilier_marche"),
                          InlineKeyboardButton("🏠 Acheter", callback_data="fm:re_buy")]))

    total_value = sum(int(PROPERTIES.get(p["prop_type"], {}).get("price", 0) * mult_val) for p in props)
    total_debt = sum(int(p.get("mortgage") or 0) for p in props)
    total_rent = sum(int(PROPERTIES.get(p["prop_type"], {}).get("rent", 0) * mult_val)
                     for p in props if p.get("rented_to"))

    pages = max(1, -(-len(props) // PER_PAGE))
    page = max(1, min(page, pages))
    chunk = props[(page - 1) * PER_PAGE: page * PER_PAGE]

    lines = [f"🏠 <b>Tes propriétés ({len(props)}/{max_props})</b>  <i>page {page}/{pages}</i>\n"]
    for p in chunk:
        data = PROPERTIES.get(p["prop_type"], {})
        val = int(data.get("price", 0) * mult_val)
        rent = int(data.get("rent", 0) * mult_val)
        cond = int(p.get("condition", 100))
        state = "✅ Louée" if p.get("rented_to") else "🔑 Libre"
        debt = f"\n  💳 Hypothèque restante : {fmt(p['mortgage'])}" if (p.get("mortgage") or 0) > 0 else ""
        warn = "  ⚠️ <b>inhabitable</b>" if cond <= 0 else ""
        lines.append(
            f"{data.get('emoji', '🏠')} <b>{p['prop_type']}</b> — {escape_html(p.get('name', ''))}\n"
            f"  💰 Valeur : {fmt(val)} · {state}{debt}\n"
            f"  🏚️ État : <code>{_cond_bar(cond)}</code> {cond} %{warn}\n"
            f"  💵 Loyer : {fmt(rent)}/mois")
    lines.append(f"\n📊 <b>Valeur totale : {fmt(total_value)}</b>"
                 + (f" · 💳 Dettes : {fmt(total_debt)}" if total_debt else "")
                 + f"\n💵 Loyers actifs : {fmt(total_rent)}/mois")

    nav = []
    if page > 1:
        nav.append(InlineKeyboardButton("◀️", callback_data=f"immobilier_mesbiens_{page - 1}"))
    if page < pages:
        nav.append(InlineKeyboardButton("▶️", callback_data=f"immobilier_mesbiens_{page + 1}"))
    rows = [nav] if nav else []
    rows.append([InlineKeyboardButton("🔧 Entretenir", callback_data="fm:re_maintain"),
                 InlineKeyboardButton("💰 Vendre", callback_data="fm:re_sell")])
    if total_debt:
        rows.append([InlineKeyboardButton("💳 Solder l'hypothèque", callback_data="fm:re_payoff")])
    return "\n".join(lines), _back_kb(*rows)


@require_registered
@require_free
async def cmd_mesbiens(update: Update, context: ContextTypes.DEFAULT_TYPE):
    page = int(context.args[0]) if context.args and str(context.args[0]).isdigit() else 1
    text, kb = await render_mesbiens(update.effective_user.id, page)
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=kb)


# ==================== LOCATION SÉCURISÉE ====================
@require_registered
@require_free
@cooldown("propose_rental", 10, "⏳ Attends un instant.")
async def cmd_proposer_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """args = [prop_id, @locataire | id, loyer mensuel]"""
    user = update.effective_user
    kb = _back_kb()

    if len(context.args) < 3:
        await update.message.reply_text("❌ Il manque des informations.", reply_markup=kb)
        return

    prop = await _owned(user.id, context.args[0])
    if not prop:
        await update.message.reply_text("❌ Bien introuvable.", reply_markup=kb)
        return

    tenant_mention = context.args[1]
    tenant_id = None
    from utils.user_lookup import resolve_id       # ID d'abord, puis @pseudo
    tenant_id = await resolve_id(tenant_mention)
    if not tenant_id:
        await update.message.reply_text("❌ Locataire introuvable.", reply_markup=kb)
        return

    try:
        rent = int(context.args[2])
        if rent <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Loyer invalide (nombre positif attendu).", reply_markup=kb)
        return

    if prop.get("rented_to"):
        await update.message.reply_text("❌ Ce bien est déjà loué.", reply_markup=kb)
        return
    if (prop.get("condition") or 0) <= 0:
        await update.message.reply_text("❌ Ce bien est inhabitable : entretiens-le avant de le louer.",
                                        reply_markup=kb)
        return
    if tenant_id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas te louer ton propre bien.", reply_markup=kb)
        return

    tenant = await get_user(tenant_id)
    if not tenant.get("registered"):
        await update.message.reply_text("❌ Ce joueur n'est pas enregistré.", reply_markup=kb)
        return

    async with db_connection() as db:
        await db.execute(
            "UPDATE rental_proposals SET status='cancelled' "
            "WHERE property_id=? AND tenant_id=? AND status='pending'",
            (prop["prop_id"], tenant_id))
        cursor = await db.execute(
            "INSERT INTO rental_proposals (property_id, owner_id, tenant_id, rent, proposed_at) "
            "VALUES (?, ?, ?, ?, ?)", (prop["prop_id"], user.id, tenant_id, rent, now()))
        proposal_id = cursor.lastrowid
        await db.commit()

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Accepter", callback_data=f"rent_accept_{proposal_id}"),
         InlineKeyboardButton("❌ Refuser", callback_data=f"rent_refuse_{proposal_id}")]
    ])
    try:
        await context.bot.send_message(
            tenant_id,
            f"🏠 <b>Proposition de location</b>\n\n"
            f"De : {escape_html(user.full_name)}\n"
            f"Bien : {prop['prop_type']} — {escape_html(prop.get('name', ''))}\n"
            f"💰 Loyer : {fmt(rent)}/mois (prélevé chaque jour de jeu)\n\n"
            f"Souhaites-tu louer ce bien ?",
            reply_markup=keyboard, parse_mode="HTML")
        await update.message.reply_text(
            f"📨 Proposition envoyée à {escape_html(tenant['full_name'])}.", reply_markup=kb)
    except Exception:
        await update.message.reply_text(
            "❌ Impossible d'envoyer la proposition : ce joueur n'a pas ouvert le bot en privé.",
            reply_markup=kb)


async def rental_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    try:
        prefix, action, raw_id = query.data.split("_")
        proposal_id = int(raw_id)
        if prefix != "rent" or action not in ("accept", "refuse"):
            raise ValueError
    except (ValueError, AttributeError):
        await query.edit_message_text("❌ Proposition invalide.")
        return

    owner_id = None
    property_id = None
    rent = None

    try:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                async with db.execute(
                    "SELECT * FROM rental_proposals WHERE id=?",
                    (proposal_id,),
                ) as cursor:
                    proposal = await cursor.fetchone()

                if not proposal or proposal["status"] != "pending":
                    await db.rollback()
                    raise DeferredReply(query.edit_message_text, "❌ Proposition déjà traitée.")
                if proposal["tenant_id"] != query.from_user.id:
                    await db.rollback()
                    raise DeferredReply(query.answer, "Ce n'est pas pour toi.", show_alert=True)

                owner_id = proposal["owner_id"]
                property_id = proposal["property_id"]
                rent = proposal["rent"]

                if action == "refuse":
                    claim = await db.execute(
                        "UPDATE rental_proposals SET status='refused' "
                        "WHERE id=? AND status='pending'",
                        (proposal_id,),
                    )
                    if claim.rowcount != 1:
                        await db.rollback()
                        raise DeferredReply(query.edit_message_text, "❌ Proposition déjà traitée.")
                    await db.commit()
                    raise DeferredReply(query.edit_message_text, "❌ Location refusée.")

                reserve = await db.execute(
                    "UPDATE properties SET rented_to=? "
                    "WHERE prop_id=? AND user_id=? "
                    "AND COALESCE(rented_to,0)=0 AND condition>0",
                    (proposal["tenant_id"], property_id, owner_id),
                )
                if reserve.rowcount != 1:
                    await db.execute(
                        "UPDATE rental_proposals SET status='cancelled' "
                        "WHERE id=? AND status='pending'",
                        (proposal_id,),
                    )
                    await db.commit()
                    raise DeferredReply(query.edit_message_text, "❌ Ce bien n'est plus disponible.")

                await db.execute(
                    "INSERT INTO rental_agreements "
                    "(property_id,owner_id,tenant_id,rent,start_date,status) "
                    "VALUES (?,?,?,?,?,'active')",
                    (property_id, owner_id, proposal["tenant_id"], rent, now()),
                )
                await db.execute(
                    "UPDATE rental_proposals SET status='accepted' "
                    "WHERE id=? AND status='pending'",
                    (proposal_id,),
                )
                await db.execute(
                    "UPDATE rental_proposals SET status='cancelled' "
                    "WHERE property_id=? AND id<>? AND status='pending'",
                    (property_id, proposal_id),
                )
                await _drop_npc_room(db, proposal["tenant_id"])
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    await query.edit_message_text(
        f"✅ Location signée : loyer {fmt(rent)}/mois, prélevé chaque jour de jeu.\n"
        f"🏠 Tu as maintenant un logement.")
    try:
        await context.bot.send_message(
            owner_id, f"🏠 Un de tes biens vient d'être loué pour {fmt(rent)}/mois.")
    except Exception:
        swallowed('handlers/realestate.py')


@require_registered
async def cmd_meslocations(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ra.id, p.prop_type, p.name, ra.rent, ra.start_date
            FROM rental_agreements ra
            JOIN properties p ON p.prop_id = ra.property_id
            WHERE ra.tenant_id = ? AND ra.status = 'active'
        """, (user.id,)) as cur:
            rentals = await cur.fetchall()
    if not rentals:
        await update.message.reply_text(
            "🏠 Tu ne loues aucun logement.\n"
            "Un propriétaire peut te faire une proposition, ou prends une chambre dans le menu Logement.",
            reply_markup=_back_kb([InlineKeyboardButton("🛏️ Logement", callback_data="logement_home")]))
        return
    text = "📄 <b>Tes locations</b>\n\n"
    for r in rentals:
        elapsed = now() - r['start_date']
        since_str = "aujourd'hui" if elapsed < 86400 else fmt_time(elapsed)
        text += (f"📍 <b>{r['prop_type']}</b> — {escape_html(r['name'])}\n"
                 f"💰 Loyer : {fmt(r['rent'])}/mois · 📅 Depuis : {since_str}\n\n")
    await update.message.reply_text(
        text, parse_mode="HTML",
        reply_markup=_back_kb([InlineKeyboardButton("🚪 Quitter un logement", callback_data="fm:re_leave")]))


@require_registered
@require_free
async def cmd_quitter_logement(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """args = [id_contrat]"""
    user = update.effective_user
    kb = _back_kb()
    try:
        contract_id = int(context.args[0])
    except (ValueError, IndexError):
        await update.message.reply_text("❌ Contrat introuvable.", reply_markup=kb)
        return
    async with Outbox() as _out:
        async with db_connection() as db:
            async with db.execute("""
            SELECT ra.property_id, ra.owner_id
            FROM rental_agreements ra
            WHERE ra.id = ? AND ra.tenant_id = ? AND ra.status = 'active'
        """, (contract_id, user.id)) as cur:
                rental = await cur.fetchone()
            if not rental:
                _out.add(update.message.reply_text, "❌ Contrat de location introuvable.", reply_markup=kb)
                return
            property_id, owner_id = rental
            await db.execute("UPDATE rental_agreements SET status = 'terminated', end_date = ? WHERE id = ?",
                             (now(), contract_id))
            await db.execute("UPDATE properties SET rented_to = 0 WHERE prop_id = ?", (property_id,))
            await db.commit()
            await add_notification(owner_id, f"🏠 {escape_html(user.full_name)} a quitté un de tes logements. "
                                             f"Le bien est de nouveau disponible.")
    await update.message.reply_text(
        "👋 Tu as quitté ton logement : les loyers ne seront plus prélevés.\n"
        "⚠️ Pense à te trouver un autre logement, sinon tu seras sans domicile.",
        reply_markup=_back_kb([InlineKeyboardButton("🛏️ Trouver un logement", callback_data="logement_home")]))


# ==================== VENTE ET ENTRETIEN ====================
@require_registered
@require_free
@cooldown("sell_property", 10, "⏳ Attends un instant avant de vendre à nouveau.")
async def cmd_vendre_bien(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    mult = await get_city_multipliers(user.id)
    mult_val = mult.get("realestate_mult", 1.0)
    kb = _back_kb()

    prop = await _owned(user.id, context.args[0]) if context.args else None
    if not prop:
        await update.message.reply_text("❌ Bien introuvable.", reply_markup=kb)
        return
    if prop.get("rented_to"):
        await update.message.reply_text("❌ Impossible de vendre un bien actuellement loué.", reply_markup=kb)
        return

    data = PROPERTIES.get(prop["prop_type"], {})
    condition = prop.get("condition", 100)
    base_price = data.get("price", 0) * mult_val
    sell_price = int(base_price * 0.85 * condition / 100)

    mortgage = int(prop.get("mortgage") or 0)
    if mortgage > 0:
        if sell_price < mortgage:
            await update.message.reply_text(
                f"❌ La vente ne couvrirait pas ton hypothèque !\n"
                f"Valeur nette : {fmt(sell_price)}\nHypothèque due : {fmt(mortgage)}",
                parse_mode="HTML", reply_markup=kb)
            return
        sell_price -= mortgage

    try:
        async with db_connection() as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                deletion = await db.execute(
                    "DELETE FROM properties WHERE prop_id=? AND user_id=? "
                    "AND COALESCE(rented_to,0)=0",
                    (prop["prop_id"], user.id),
                )
                if deletion.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Bien indisponible ou déjà vendu.")

                await db.execute(
                    "UPDATE users SET balance=balance+?, total_earned=total_earned+? "
                    "WHERE user_id=?",
                    (sell_price, sell_price, user.id),
                )
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    still_housed = await get_residence(user.id)
    warn = "" if still_housed else ("\n\n⚠️ <b>Tu n'as plus de logement.</b> Trouve-en un vite : "
                                    "sans domicile, ton repos est réduit et ton employeur te refuse.")
    await update.message.reply_text(
        f"✅ <b>Propriété vendue !</b>\n\n"
        f"{data.get('emoji', '🏠')} {prop['prop_type']} — {escape_html(prop.get('name', ''))}\n"
        f"💰 Prix de vente (net) : {fmt(sell_price)}\n"
        f"🏚️ État au moment de la vente : {condition} %\n"
        f"<i>(-15 % de frais d'agence{', hypothèque remboursée' if mortgage > 0 else ''})</i>{warn}",
        parse_mode="HTML",
        reply_markup=_back_kb(*([[InlineKeyboardButton("🛏️ Logement", callback_data="logement_home")]]
                                if not still_housed else [])))


@require_registered
@require_free
@cooldown("maintain_property", 86400, "⏳ Tu ne peux entretenir qu'une fois par jour.")
async def cmd_entretenir(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    kb = _back_kb()

    prop = await _owned(user.id, context.args[0]) if context.args else None
    if not prop:
        await update.message.reply_text("❌ Bien introuvable.", reply_markup=kb)
        return

    condition = prop.get("condition", 100)
    if condition >= 100:
        await update.message.reply_text("✅ Cette propriété est déjà en excellent état.", reply_markup=kb)
        return

    base_price = PROPERTIES.get(prop["prop_type"], {}).get("price", 0)
    mult = await get_city_multipliers(user.id)
    price = int(base_price * mult.get("realestate_mult", 1.0))
    cost = int(price * 0.01)

    new_condition = min(100, condition + 20)
    try:
        async with db_connection() as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                    "WHERE user_id=? AND balance>=?", (cost, cost, user.id, cost))
                if debit.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text,
                                        f"❌ Fonds insuffisants pour l'entretien. Coût : {fmt(cost)}",
                                        reply_markup=kb)
                await db.execute("UPDATE properties SET condition=?, last_maintenance=? WHERE prop_id=? AND user_id=?",
                                 (new_condition, now(), prop["prop_id"], user.id))
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    await update.message.reply_text(
        f"🔧 <b>Entretien effectué !</b>\n\n"
        f"{escape_html(_prop_label(prop))}\n"
        f"🏚️ État : {condition} % → {new_condition} %\n"
        f"💰 Coût : {fmt(cost)}\n"
        f"<i>Entretiens régulièrement pour éviter la dégradation accélérée.</i>",
        parse_mode="HTML", reply_markup=kb)


# ==================== INFOS DÉTAILLÉES ====================
@require_registered
async def cmd_propriete_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    kb = _back_kb()
    prop = await _owned(user.id, context.args[0]) if context.args else None
    if not prop:
        await update.message.reply_text("❌ Bien introuvable.", reply_markup=kb)
        return

    mult_val = (await get_city_multipliers(user.id)).get("realestate_mult", 1.0)
    data = PROPERTIES.get(prop["prop_type"], {})
    price = int(data.get("price", 0) * mult_val)
    rent = int(data.get("rent", 0) * mult_val)
    maint = int(data.get("maint", 0) * mult_val)
    condition = prop.get("condition", 100)
    last_maint = prop.get("last_maintenance", 0)
    mortgage = int(prop.get("mortgage") or 0)
    rented_to = prop.get("rented_to", 0)

    text = (
        f"🏠 <b>{prop['prop_type']}</b> — {escape_html(prop.get('name', ''))}\n\n"
        f"💰 Valeur actuelle : {fmt(price)}\n"
        f"💵 Loyer de base : {fmt(rent)}/mois\n"
        f"🔧 Charges : {fmt(maint)}/mois\n"
        f"🏚️ État : <code>{_cond_bar(condition)}</code> {condition} %\n"
    )
    if condition <= 0:
        text += "⚠️ <b>Inhabitable</b> : entretiens-le pour pouvoir y vivre ou le louer.\n"
    if last_maint:
        text += f"🔧 Dernier entretien : il y a {fmt_time(now() - last_maint)}\n"
    if mortgage > 0:
        text += f"💳 Hypothèque restante : {fmt(mortgage)}\n"
    if rented_to:
        tenant = await get_user(rented_to)
        who = escape_html((tenant or {}).get("full_name") or "un joueur")
        text += f"✅ <b>Loué à</b> : {who}\n"
    else:
        text += "🔑 <b>Libre</b>\n"

    rows = [[InlineKeyboardButton("🔧 Entretenir", callback_data="fm:re_maintain")]]
    if mortgage > 0:
        rows.append([InlineKeyboardButton("💳 Solder l'hypothèque", callback_data="fm:re_payoff")])
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=_back_kb(*rows))


# ==================== MAINTENANCE (scheduler) ====================
RE_BATCH = 1000


async def process_realestate_maintenance():
    """
    Usure des biens + remboursement des hypothèques (job quotidien).

    ⚠️ update_balance / add_notification ouvrent leur propre connexion :
    on commit d'abord, puis on les appelle (sinon « database is locked »).
    """
    notifications: list[tuple[int, str]] = []
    cutoff = add_game_months(now(), -1)

    # Usure + négligence, par lots de RE_BATCH biens (une courte transaction par lot)
    last_id = 0
    while True:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            async with db.execute(
                "SELECT prop_id FROM properties WHERE prop_id > ? ORDER BY prop_id LIMIT ?",
                (last_id, RE_BATCH),
            ) as cur:
                ids = [r[0] for r in await cur.fetchall()]
            if not ids:
                break
            lo, hi = ids[0], ids[-1]
            await db.execute(
                "UPDATE properties SET condition = MAX(0, condition - 2) "
                "WHERE condition > 0 AND prop_id BETWEEN ? AND ?", (lo, hi)
            )
            async with db.execute(
                "SELECT * FROM properties WHERE last_maintenance < ? AND condition > 0 "
                "AND prop_id BETWEEN ? AND ?", (cutoff, lo, hi)
            ) as cur:
                neglected = [dict(r) for r in await cur.fetchall()]
            for prop in neglected:
                new_cond = max(0, prop["condition"] - random.randint(5, 15))
                await db.execute(
                    "UPDATE properties SET condition = ? WHERE prop_id = ?", (new_cond, prop["prop_id"])
                )
                if new_cond < prop["condition"]:
                    notifications.append((
                        prop["user_id"],
                        f"🏚️ Votre bien {prop['prop_type']} se dégrade faute d'entretien (état {new_cond}%).",
                    ))
            await db.commit()
        last_id = hi
        await asyncio.sleep(0)   # laisse passer les autres tâches entre deux lots

    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM properties WHERE mortgage > 0 AND mortgage_due > 0") as cur:
            mortgaged = [dict(r) for r in await cur.fetchall()]

    for prop in mortgaged:
        mortgage = prop["mortgage"]
        monthly = int(mortgage / 360)
        if monthly <= 0:
            continue
        owner = await get_user(prop["user_id"])
        if not owner:
            continue
        async with db_connection() as db:
            if owner["balance"] >= monthly:
                await update_balance(prop["user_id"], -monthly)
                new_mortgage = mortgage - monthly
                if new_mortgage <= 0:
                    await db.execute(
                        "UPDATE properties SET mortgage=0, mortgage_due=0 WHERE prop_id=?",
                        (prop["prop_id"],),
                    )
                else:
                    await db.execute(
                        "UPDATE properties SET mortgage=? WHERE prop_id=?",
                        (new_mortgage, prop["prop_id"]),
                    )
            else:
                await db.execute(
                    "UPDATE properties SET condition = MAX(0, condition - 10) WHERE prop_id=?",
                    (prop["prop_id"],),
                )
                notifications.append((
                    prop["user_id"],
                    "⚠️ Impayé sur votre hypothèque ! L'état de votre bien se dégrade.",
                ))
            await db.commit()

    for uid, text in notifications:
        try:
            await add_notification(uid, text)
        except Exception:
            swallowed('handlers/realestate.py')


# ══════════════════════════════════════════════════════════════════════
#  LOGEMENT OBLIGATOIRE — résidence, frais quotidiens, menu Logement
# ══════════════════════════════════════════════════════════════════════
import logging
from collections import defaultdict
from config import (HOUSING_DAYS_PER_MONTH, HOUSING_EVICT_AFTER, HOUSING_NPC, PROPERTIES)
from database import db_connection, get_user, now
from utils.notify import notify

logger = logging.getLogger(__name__)


DAY = 86400


def game_day() -> int:
    return now() // DAY


async def get_residence(user_id: int) -> dict | None:
    """{'kind': 'owned'|'rented'|'npc', 'label': str, 'sleep': float} ou None (sans domicile)."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT prop_id, prop_type, name FROM properties WHERE user_id=? AND rented_to=0 AND condition>0 "
                "ORDER BY prop_id LIMIT 1", (user_id,)) as cur:
            own = await cur.fetchone()
        if own:
            return {"kind": "owned", "label": f"{own['prop_type']} (à toi)", "sleep": 1.0, "ref": own["prop_id"]}
        async with db.execute(
                "SELECT ra.id, p.prop_type FROM rental_agreements ra JOIN properties p ON p.prop_id=ra.property_id "
                "WHERE ra.tenant_id=? AND ra.status='active' LIMIT 1", (user_id,)) as cur:
            rent = await cur.fetchone()
        if rent:
            return {"kind": "rented", "label": f"{rent['prop_type']} (location)", "sleep": 1.0, "ref": rent["id"]}
        async with db.execute("SELECT name FROM housing_npc WHERE user_id=?", (user_id,)) as cur:
            npc = await cur.fetchone()
        if npc:
            return {"kind": "npc", "label": npc["name"], "ref": user_id,
                    "sleep": HOUSING_NPC.get(npc["name"], {}).get("sleep", 1.0)}
    return None


async def _charge(db, kind: str, entity: str, payer: int, payee: int | None, amount: int, day: int) -> str:
    """'paid' | 'unpaid' | 'dup' — débit conditionnel, une seule fois par (entité, jour)."""
    done = await db.execute("INSERT OR IGNORE INTO payroll_log VALUES ('housing',?,?,?,?,'paid')",
                            (entity, payer, day, amount))
    if not done.rowcount:
        return "dup"
    debit = await db.execute(
        "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
        (amount, amount, payer, amount))
    if debit.rowcount != 1:
        await db.execute("UPDATE payroll_log SET status='unpaid' WHERE kind='housing' AND entity=? AND user_id=? "
                         "AND day=?", (entity, payer, day))
        return "unpaid"
    if payee:
        await db.execute("UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                         (amount, amount, payee))
    return "paid"


async def _arrears(db, kind: str, ref: int, paid: bool) -> int:
    """Met à jour le compteur d'impayés et le renvoie (0 si payé)."""
    if paid:
        await db.execute("DELETE FROM housing_arrears WHERE kind=? AND ref_id=?", (kind, ref))
        return 0
    await db.execute("INSERT INTO housing_arrears(kind, ref_id, days) VALUES (?,?,1) "
                     "ON CONFLICT(kind, ref_id) DO UPDATE SET days=days+1", (kind, ref))
    async with db.execute("SELECT days FROM housing_arrears WHERE kind=? AND ref_id=?", (kind, ref)) as cur:
        return (await cur.fetchone())[0]


def _daily(monthly: int) -> int:
    return max(1, int(monthly) // HOUSING_DAYS_PER_MONTH)


async def run_housing_charges(day: int | None = None) -> dict:
    """Prélève les frais de logement du jour de jeu et notifie chaque joueur concerné."""
    day = game_day() if day is None else day
    lines: dict[int, list[str]] = defaultdict(list)
    kinds: dict[int, str] = {}
    stats = {"paid": 0, "unpaid": 0, "evicted": 0}

    def say(uid, text, kind="info"):
        lines[uid].append(text)
        if kind == "warning" or uid not in kinds:
            kinds[uid] = kind

    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            # 1) locataires de joueurs
            async with db.execute("SELECT * FROM rental_agreements WHERE status='active'") as cur:
                rentals = [dict(r) for r in await cur.fetchall()]
            for r in rentals:
                amount = _daily(r["rent"])
                res = await _charge(db, "rental", f"rental:{r['id']}", r["tenant_id"], r["owner_id"], amount, day)
                if res == "dup":
                    continue
                if res == "paid":
                    stats["paid"] += 1
                    await _arrears(db, "rental", r["id"], True)
                    say(r["tenant_id"], f"🏠 Loyer : -{fmt(amount)}")
                    say(r["owner_id"], f"🏠 Loyer reçu (bien #{r['property_id']}) : +{fmt(amount)}")
                else:
                    stats["unpaid"] += 1
                    n = await _arrears(db, "rental", r["id"], False)
                    if n >= HOUSING_EVICT_AFTER:
                        stats["evicted"] += 1
                        await db.execute("UPDATE rental_agreements SET status='terminated', end_date=? WHERE id=?",
                                         (now(), r["id"]))
                        await db.execute("UPDATE properties SET rented_to=0 WHERE prop_id=?", (r["property_id"],))
                        await db.execute("DELETE FROM housing_arrears WHERE kind='rental' AND ref_id=?", (r["id"],))
                        say(r["tenant_id"], f"🚪 Expulsé(e) : {n} jours de loyer impayés. Trouve un logement : menu Investissements → Immobilier → Mon logement",
                            "warning")
                        say(r["owner_id"], f"🚪 Ton locataire est parti (loyers impayés). Le bien #{r['property_id']} "
                                           f"est de nouveau libre.", "warning")
                    else:
                        say(r["tenant_id"], f"⚠️ Loyer impayé ({fmt(amount)}) : jour {n}/{HOUSING_EVICT_AFTER} "
                                            f"avant expulsion.", "warning")
                        say(r["owner_id"], f"⚠️ Loyer impayé de ton locataire (bien #{r['property_id']}).", "warning")

            # 2) chambres PNJ (supprimées si le joueur a désormais un vrai logement : bien ou location)
            async with db.execute("SELECT * FROM housing_npc") as cur:
                npcs = [dict(r) for r in await cur.fetchall()]
            async with db.execute(
                    "SELECT DISTINCT user_id FROM properties WHERE rented_to=0 AND condition>0 "
                    "UNION SELECT DISTINCT tenant_id FROM rental_agreements WHERE status='active'") as cur:
                housed = {r[0] for r in await cur.fetchall()}
            for n_ in [n for n in npcs if n["user_id"] in housed]:
                await _drop_npc_room(db, n_["user_id"])
            npcs = [n for n in npcs if n["user_id"] not in housed]
            for n_ in npcs:
                uid, amount = n_["user_id"], n_["daily_cost"]
                res = await _charge(db, "npc", f"npc:{uid}", uid, None, amount, day)
                if res == "dup":
                    continue
                if res == "paid":
                    stats["paid"] += 1
                    await _arrears(db, "npc", uid, True)
                    say(uid, f"🛏️ {n_['name']} : -{fmt(amount)}")
                else:
                    stats["unpaid"] += 1
                    n = await _arrears(db, "npc", uid, False)
                    if n >= HOUSING_EVICT_AFTER:
                        stats["evicted"] += 1
                        await db.execute("DELETE FROM housing_npc WHERE user_id=?", (uid,))
                        await db.execute("DELETE FROM housing_arrears WHERE kind='npc' AND ref_id=?", (uid,))
                        say(uid, f"🚪 {n_['name']} : expulsé(e) pour impayés. Tu es sans domicile : menu Vie → Logement", "warning")
                    else:
                        say(uid, f"⚠️ {n_['name']} impayé ({fmt(amount)}) : jour {n}/{HOUSING_EVICT_AFTER}.", "warning")

            # 3) charges des propriétaires : logement occupé + biens loués
            async with db.execute(
                    "SELECT prop_id, user_id, prop_type, rented_to, condition FROM properties ORDER BY user_id, prop_id") as cur:
                props = [dict(r) for r in await cur.fetchall()]
            lived = set()
            for p in props:
                free = p["rented_to"] == 0 and p["condition"] > 0
                if free and p["user_id"] not in lived:
                    lived.add(p["user_id"])
                    charged = True
                else:
                    charged = p["rented_to"] != 0
                if not charged:
                    continue
                maint = PROPERTIES.get(p["prop_type"], {}).get("maint", 0)
                if maint <= 0:
                    continue
                amount = _daily(maint)
                res = await _charge(db, "owner", f"owner:{p['prop_id']}", p["user_id"], None, amount, day)
                if res == "dup":
                    continue
                if res == "paid":
                    stats["paid"] += 1
                    await _arrears(db, "owner", p["prop_id"], True)
                    say(p["user_id"], f"🔧 Charges {p['prop_type']} #{p['prop_id']} : -{fmt(amount)}")
                else:
                    stats["unpaid"] += 1
                    await _arrears(db, "owner", p["prop_id"], False)
                    await db.execute("UPDATE properties SET condition=MAX(0, condition-5) WHERE prop_id=?",
                                     (p["prop_id"],))
                    say(p["user_id"], f"⚠️ Charges impayées ({p['prop_type']} #{p['prop_id']}) : le bien se dégrade.",
                        "warning")
            await db.commit()
        except Exception:
            await db.rollback()
            raise

    for uid, rows in lines.items():
        try:
            await notify(uid, "🏠 Frais de logement", "\n".join(rows), kinds.get(uid, "info"))
        except Exception:
            logger.exception("Notification logement impossible pour %s", uid)
    return stats


# ══════════════════════════════════════════════════════════════════════
#  LOGEMENT — vue « Mon logement » (boutons uniquement)
# ══════════════════════════════════════════════════════════════════════
_NPC_KEYS = list(HOUSING_NPC)


async def _residence_lines(user_id: int, res: dict) -> str:
    """Détails du logement actuel : propriétaire, loyer, état du bien…"""
    kind = res["kind"]
    out = ""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        if kind == "owned":
            async with db.execute("SELECT prop_type, name, condition, mortgage FROM properties WHERE prop_id=?",
                                  (res["ref"],)) as cur:
                p = await cur.fetchone()
            if p:
                out += f"🏚️ État du bien : <code>{_cond_bar(p['condition'])}</code> {p['condition']} %\n"
                if (p["mortgage"] or 0) > 0:
                    out += f"💳 Hypothèque restante : {fmt(p['mortgage'])}\n"
            out += "🔧 Les charges du logement sont prélevées chaque jour de jeu.\n"
        elif kind == "rented":
            async with db.execute(
                    "SELECT ra.rent, u.full_name FROM rental_agreements ra "
                    "LEFT JOIN users u ON u.user_id=ra.owner_id WHERE ra.id=?", (res["ref"],)) as cur:
                r = await cur.fetchone()
            if r:
                out += (f"👤 Propriétaire : {escape_html(r['full_name'] or 'un joueur')}\n"
                        f"💸 Loyer : {fmt(r['rent'])}/mois, prélevé chaque jour de jeu "
                        f"(÷ {HOUSING_DAYS_PER_MONTH}).\n")
        else:
            daily = HOUSING_NPC.get(res["label"], {}).get("daily", 0)
            out += f"💸 {fmt(daily)} par jour, prélevés et notifiés chaque jour de jeu.\n"
    return out


async def _view(user_id: int) -> tuple[str, InlineKeyboardMarkup]:
    res = await get_residence(user_id)
    kb: list[list[InlineKeyboardButton]] = []

    if res:
        text = f"🏠 <b>Ton logement</b> : {escape_html(res['label'])}\n"
        text += await _residence_lines(user_id, res)
        text += f"⚠️ {HOUSING_EVICT_AFTER} jours d'impayés = expulsion (location ou chambre).\n"
    else:
        props = await get_properties(user_id)
        text = "🏚️ <b>Tu es sans domicile.</b>\n\n"
        if any((p.get("condition") or 0) <= 0 and not p.get("rented_to") for p in props):
            text += ("🔧 Tu possèdes un bien <b>inhabitable</b> (état 0 %) : entretiens-le pour pouvoir "
                     "y vivre à nouveau.\n\n")
            kb.append([InlineKeyboardButton("🔧 Entretenir un bien", callback_data="fm:re_maintain")])
        text += ("<b>Sans logement :</b>\n"
                 "• Tu dors dehors : repos réduit de moitié, −3 % santé et +5 % stress à chaque nuit.\n"
                 "• Aucun service possible en entreprise ou en faction : ton employeur exige une adresse.\n\n"
                 "<b>Trouve un logement :</b> prends une chambre ci-dessous, achète un bien, "
                 "ou loue chez un joueur.\n")

    if not res or res["kind"] == "npc":
        text += "\n<b>Chambres disponibles :</b>\n"
        for i, (name, d) in enumerate(HOUSING_NPC.items()):
            current = bool(res and res["kind"] == "npc" and res["label"] == name)
            text += f"{d['emoji']} <b>{name}</b> — {fmt(d['daily'])}/jour · {d['desc']}{' ← ici' if current else ''}\n"
            if not current:
                kb.append([InlineKeyboardButton(f"{d['emoji']} {name} · {fmt(d['daily'])}/jour",
                                                callback_data=f"logement_npc_{i}")])
    if res and res["kind"] == "npc":
        kb.append([InlineKeyboardButton("🚪 Quitter cette chambre", callback_data="logement_leave")])

    if not res or res["kind"] == "npc":
        text += ("\n💡 <i>Un bien à toi ou une location te coûte souvent moins cher à long terme, "
                 "et remplace automatiquement la chambre.</i>")
    kb.append([InlineKeyboardButton("🏘️ Acheter un bien", callback_data="invest_immobilier"),
               InlineKeyboardButton("📄 Mes locations", callback_data="immobilier_meslocations")])
    kb.append([InlineKeyboardButton("⬅️ Retour", callback_data="invest_immobilier")])
    return text, InlineKeyboardMarkup(kb)


@require_registered
@require_free
async def cmd_logement(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text, kb = await _view(update.effective_user.id)
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=kb)


async def logement_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    uid = q.from_user.id
    data = q.data or ""
    res = await get_residence(uid)
    notice = ""
    if data == "logement_leave":
        if res and res["kind"] == "npc":
            async with db_connection() as db:
                await _drop_npc_room(db, uid)
                await db.commit()
            notice = "👋 Tu as quitté ta chambre.\n\n"
    elif data.startswith("logement_npc_"):
        try:
            name = _NPC_KEYS[int(data.rsplit("_", 1)[1])]
        except (ValueError, IndexError):
            return
        if res and res["kind"] != "npc":
            notice = "ℹ️ Tu as déjà un vrai logement : pas besoin d'une chambre.\n\n"
        else:
            async with db_connection() as db:
                await db.execute(
                    "INSERT INTO housing_npc(user_id, name, daily_cost, since) VALUES (?,?,?,?) "
                    "ON CONFLICT(user_id) DO UPDATE SET name=excluded.name, daily_cost=excluded.daily_cost",
                    (uid, name, HOUSING_NPC[name]["daily"], now()))
                await db.execute("DELETE FROM housing_arrears WHERE kind='npc' AND ref_id=?", (uid,))
                await db.commit()
            notice = f"✅ Tu t'installes : {name}.\n\n"
    text, kb = await _view(uid)
    try:
        await q.edit_message_text(notice + text, parse_mode="HTML", reply_markup=kb)
    except Exception:
        swallowed('handlers/realestate.py')


# ══════════════════════════════════════════════════════════════════════
#  FORMULAIRES À BOUTONS ET SAISIES (remplacent les anciennes commandes)
# ══════════════════════════════════════════════════════════════════════
from utils.forms import Form, P, provider, register  # noqa: E402


@provider("re_types")
async def _prov_types(user_id: int):
    rm = (await get_city_multipliers(user_id)).get("realestate_mult", 1.0)
    return [(f"{d['emoji']} {t} · {fmt(int(d['price'] * rm))}", t) for t, d in PROPERTIES.items()]


@provider("re_types_mortgage")
async def _prov_types_mortgage(user_id: int):
    rm = (await get_city_multipliers(user_id)).get("realestate_mult", 1.0)
    return [(f"{d['emoji']} {t} · apport {fmt(int(d['price'] * rm * DOWN_PAYMENT_RATE))}", t)
            for t, d in PROPERTIES.items()]


async def _props_where(user_id: int, keep) -> list[tuple[str, str]]:
    return [(_prop_label(p), str(p["prop_id"])) for p in await get_properties(user_id) if keep(p)]


@provider("re_biens")
async def _prov_biens(user_id: int):
    return await _props_where(user_id, lambda p: True)


@provider("re_biens_libres")
async def _prov_biens_libres(user_id: int):
    return await _props_where(user_id, lambda p: not p.get("rented_to") and (p.get("condition") or 0) > 0)


@provider("re_biens_vendables")
async def _prov_biens_vendables(user_id: int):
    return await _props_where(user_id, lambda p: not p.get("rented_to"))


@provider("re_biens_hypo")
async def _prov_biens_hypo(user_id: int):
    return [(f"{_prop_label(p)[:24]} · reste {fmt(p['mortgage'])}", str(p["prop_id"]))
            for p in await get_properties(user_id) if (p.get("mortgage") or 0) > 0]


@provider("re_biens_abimes")
async def _prov_biens_abimes(user_id: int):
    return [(f"{_prop_label(p)[:26]} · {p.get('condition', 100)} %", str(p["prop_id"]))
            for p in await get_properties(user_id) if (p.get("condition") or 100) < 100]


@provider("re_contrats")
async def _prov_contrats(user_id: int):
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT ra.id, p.prop_type, p.name, ra.rent FROM rental_agreements ra "
                "JOIN properties p ON p.prop_id=ra.property_id "
                "WHERE ra.tenant_id=? AND ra.status='active'", (user_id,)) as cur:
            rows = await cur.fetchall()
    return [(f"{r['prop_type']} — {(r['name'] or '')[:18]} · {fmt(r['rent'])}/mois", str(r["id"])) for r in rows]


_BACK = CB_MENU
register(
    Form("re_buy", "🏠 Acheter un bien", "handlers.realestate:cmd_acheter_bien",
         params=(P("type", "choice", "Quel bien veux-tu acheter (paiement comptant) ?", choices="re_types"),),
         back=_BACK),
    Form("re_mortgage", "🏦 Acheter avec hypothèque", "handlers.realestate:cmd_hypotheque",
         params=(P("type", "choice",
                   f"Quel bien veux-tu acheter ? Tu paies {int(DOWN_PAYMENT_RATE * 100)} % maintenant, "
                   f"le reste est prélevé chaque jour de jeu (et tu peux solder quand tu veux).",
                   choices="re_types_mortgage"),),
         back=_BACK),
    Form("re_payoff", "💳 Solder l'hypothèque", "handlers.realestate:cmd_solder_hypotheque",
         params=(P("prop", "choice", "Quel bien veux-tu solder ? Tu paies tout le capital restant d'un coup.",
                   choices="re_biens_hypo"),),
         confirm="Tu vas payer <b>tout le capital restant dû</b> de ce bien en une fois. Confirmer ?",
         back=_BACK),
    Form("re_sell", "💰 Vendre un bien", "handlers.realestate:cmd_vendre_bien",
         params=(P("prop", "choice", "Quel bien veux-tu vendre ?", choices="re_biens_vendables"),),
         confirm="Vente à 85 % de la valeur (frais d'agence), selon l'état du bien. "
                 "Une hypothèque éventuelle est remboursée avec le prix. Confirmer ?",
         back=_BACK),
    Form("re_maintain", "🔧 Entretenir un bien", "handlers.realestate:cmd_entretenir",
         params=(P("prop", "choice", "Quel bien veux-tu entretenir (+20 % d'état, 1 fois par jour) ?",
                   choices="re_biens_abimes"),),
         back=_BACK),
    Form("re_info", "🔍 Détails d'un bien", "handlers.realestate:cmd_propriete_info",
         params=(P("prop", "choice", "Quel bien veux-tu consulter ?", choices="re_biens"),),
         back=_BACK),
    Form("re_rent_out", "🤝 Louer mon bien", "handlers.realestate:cmd_proposer_location",
         params=(P("prop", "choice", "Quel bien veux-tu mettre en location ?", choices="re_biens_libres"),
                 P("tenant", "user", "Envoie le <b>@pseudo</b> (ou l'ID) du futur locataire."),
                 P("rent", "amount", "Quel <b>loyer mensuel</b> proposes-tu ? (ex : 2000, 3k)", min=1)),
         back=_BACK),
    Form("re_leave", "🚪 Quitter un logement", "handlers.realestate:cmd_quitter_logement",
         params=(P("contract", "choice", "Quel logement veux-tu quitter ?", choices="re_contrats"),),
         confirm="Tu mets fin à cette location. Sans autre logement, tu seras sans domicile. Confirmer ?",
         back=_BACK),
)
