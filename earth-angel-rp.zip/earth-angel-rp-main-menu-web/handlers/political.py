"""
handlers/political.py — Système politique massif, sans simulation.
Les joueurs contrôlent tout (élections, lois, constitution, référendums, destitution).
Le bot applique les règles (coûts, quorum, majorité, délais).

MODIFICATIONS :
 - Dépouillement automatique des élections terminées (dans political_maintenance)
 - /candidater peut maintenant cibler une élection précise (par ID ou par poste)
"""
from utils.swallow import swallowed
import aiosqlite
import asyncio
from telegram import Update
from telegram.ext import ContextTypes
from database import (
    db_connection,
    Outbox,
    DeferredReply,
    DB_PATH, get_user, update_balance, update_field, increment_field,
    now, get_all_users_count, add_notification
)
from utils.decorators import require_registered, require_free, cooldown
from utils.roles import (politician_only, players_only, can_play, install_president, install_minister,
                         remove_minister, remove_president, minister_of, is_president)
from utils.helpers import fmt_duration
from utils import politics
from gameplay import elections as elections_service
from gameplay import laws as laws_service
from gameplay import cabinet as cabinet_service
from utils.aesthetics import fmt_money, card, bullet_list
from config import (
    ELECTION_COST, POLITICAL_POSTS, ELECTION_KARMA_REQUIRED, ELECTION_QUORUM,
    ELECTION_COOLDOWN, ELECTION_DEFAULT_DURATION_HOURS, ELECTION_MAX_DURATION_HOURS,
    LAW_PROPOSAL_COST, LAW_VOTE_DURATION, LAW_DEFAULT_MAJORITY,
    REFERENDUM_COST, REFERENDUM_DURATION,
    MOTION_SIGNATURES_NEEDED, MOTION_VOTE_DURATION, MOTION_MAJORITY, MOTION_COOLDOWN, MOTION_SIGNATURE_DURATION, MOTION_IMMUNITY,
    CABINET_POSITIONS, DEFAULT_CONSTITUTION, ELECTED_POSTS, MINISTRIES, MOTION_COST, POLL_MIN_VOTES
)

# ----------------------------------------------------------------------
# 1. GESTION DE LA CONSTITUTION
# ----------------------------------------------------------------------
@require_registered
async def cmd_constitution(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche la constitution actuelle."""
    async with db_connection() as db:
        async with db.execute("SELECT text, amended_at, amended_by FROM constitution WHERE id=1") as cur:
            row = await cur.fetchone()
    if not row:
        text = DEFAULT_CONSTITUTION
        await update.message.reply_text(card("📜 Constitution", [text], icon="⚖️", style="thick"), parse_mode="HTML")
        return
    text, amended_at, amended_by = row
    footer = f"Dernière modification : {fmt_duration(now() - amended_at)} par {amended_by}"
    await update.message.reply_text(
        card("📜 Constitution", [text], icon="⚖️", style="thick", footer=footer),
        parse_mode="HTML"
    )

@require_registered
@require_free
@cooldown("last_constitution", 7*86400, "⏳ La constitution ne peut être modifiée qu'une fois par semaine.")
async def cmd_modifierconstitution(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Propose une modification de la constitution (déclenche un référendum)."""
    user = update.effective_user
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections.")
        return
    result = await laws_service.propose_constitution(user.id, " ".join(context.args))
    if not result["ok"]:
        text = {
            "too_short": "❌ Le texte doit faire au moins 10 caractères.",
            "not_government": "❌ Seuls le Président et les ministres peuvent proposer une modification de la constitution.",
        }.get(result["reason"], "❌ Proposition impossible.")
        await update.message.reply_text(text)
        return
    await update.message.reply_text(
        f"✅ Proposition de modification constitutionnelle enregistrée.\n"
        f"Un référendum est ouvert pour {fmt_duration(REFERENDUM_DURATION)}. Tous les joueurs peuvent voter depuis le 🎮 Menu principal.\n"
        f"Majorité requise : 60 % (au moins {POLL_MIN_VOTES} votes). Si le oui l'emporte, la constitution est remplacée."
    )

# ----------------------------------------------------------------------
# 2. PARTIS POLITIQUES
# ----------------------------------------------------------------------

# ----------------------------------------------------------------------
# 3. ÉLECTIONS (sans simulation)
# ----------------------------------------------------------------------
def _parse_duration(duration_str: str | None):
    """« 1h », « 24 », « 2heure », « 3hr » -> texte numérique ; None si absent (le service borne la durée)."""
    if not duration_str:
        return None
    return duration_str.lower().replace('h', '').replace('heure', '').replace('hr', '').strip()


@require_registered
@require_free
@cooldown("last_election", ELECTION_COOLDOWN, "⏳ Tu as déjà lancé une élection récemment.")
@politician_only
async def cmd_lancerelection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    args = context.args
    if len(args) < 1:
        await update.message.reply_text(
            f"Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections.\nPostes : {', '.join(POLITICAL_POSTS)}\n"
            f"Durée par défaut : {ELECTION_DEFAULT_DURATION_HOURS}h, max {ELECTION_MAX_DURATION_HOURS}h.\n"
            f"Coût : variable. Karma requis : {ELECTION_KARMA_REQUIRED}."
        )
        return

    # --- Reconstruction du nom du poste (peut contenir plusieurs mots) ---
    poste = None
    duration_str = None
    for i in range(1, len(args) + 1):
        found = elections_service.resolve_poste(" ".join(args[:i]))
        if found:
            poste = found
            if i < len(args):
                duration_str = args[i]
            break
    if not poste:
        await update.message.reply_text(f"❌ Poste inconnu. Choisis parmi : {', '.join(POLITICAL_POSTS)}")
        return

    result = await elections_service.start_election(user.id, poste, _parse_duration(duration_str))
    if not result["ok"]:
        reason = result["reason"]
        if reason == "not_elected_post":
            text = (f"🗳️ Seul le poste de {', '.join(ELECTED_POSTS)} est élu par les joueurs. "
                    f"Les ministres sont nommés par le président avec le bouton « Nommer un ministre ».")
        elif reason == "already_open":
            text = f"❌ Une élection pour {poste} est déjà en cours."
        elif reason == "insufficient_funds":
            text = f"❌ Solde insuffisant. Coût : {fmt_money(result['cost'])}"
        elif reason == "karma":
            text = f"❌ Karma insuffisant ({ELECTION_KARMA_REQUIRED} requis)."
        else:
            text = "❌ Élection impossible."
        await update.message.reply_text(text)
        return

    await update.message.reply_text(
        card(f"🗳️ Élection lancée : {poste}",
             [f"💰 Coût : {fmt_money(result['cost'])}", f"⏳ Durée : {result['duration_hours']}h",
              f"📢 le 🎮 Menu principal pour se présenter", f"🗳️ le 🎮 Menu principal pour voter"],
             icon="🏛️", style="thick")
    )

@require_registered
@require_free
@politician_only
async def cmd_candidater(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Se présenter à une élection.
    Usage:
      /candidater                     → dernière élection ouverte
      /candidater <ID>                → élection spécifique par ID
      /candidater <poste>             → élection ouverte pour ce poste
      /candidater <poste> programme   → avec programme
      /candidater <ID> programme      → avec programme
    """
    user = update.effective_user
    args = context.args
    election_id = None
    poste = None
    program = "Aucun programme"
    if args:
        try:
            election_id = int(args[0])
            program = " ".join(args[1:]) or program
        except ValueError:
            for i in range(1, len(args) + 1):
                found = elections_service.resolve_poste(" ".join(args[:i]))
                if found:
                    poste = found
                    program = " ".join(args[i:]) or program
                    break
            else:
                program = " ".join(args)  # comportement historique : tout est le programme

    election = await elections_service.find_open_election(election_id, poste)
    if not election:
        open_now = await elections_service.list_open_elections()
        if not open_now:
            text = "❌ Aucune élection ouverte."
        elif election_id is not None:
            listing = "\n".join(f"ID {e['id']} : {e['poste']}" for e in open_now)
            text = f"❌ Aucune élection ouverte avec cet ID.\n\nÉlections en cours :\n{listing}"
        elif poste is not None:
            listing = ", ".join(sorted({e['poste'] for e in open_now}))
            text = f"❌ Aucune élection ouverte pour le poste '{poste}'.\nÉlections en cours : {listing}"
        else:
            text = "❌ Aucune élection ouverte."
        await update.message.reply_text(text)
        return

    result = await elections_service.register_candidate(user.id, election["id"], program)
    if not result["ok"]:
        text = {
            "already_candidate": "❌ Tu es déjà candidat à cette élection.",
            "karma": f"❌ Karma insuffisant ({ELECTION_KARMA_REQUIRED} requis).",
        }.get(result["reason"], "❌ Candidature impossible.")
        await update.message.reply_text(text)
        return
    await update.message.reply_text(
        f"✅ Candidature enregistrée pour **{result['poste']}** (élection #{result['election_id']}).")

@require_registered
@players_only
async def cmd_voter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections.")
        return
    from utils.user_lookup import find_user       # ID d'abord, puis @pseudo
    target = await find_user(context.args[0])
    if not target:
        await update.message.reply_text("❌ Candidat introuvable.")
        return
    election = await elections_service.find_open_election()
    if not election:
        await update.message.reply_text("❌ Aucune élection ouverte.")
        return
    result = await elections_service.cast_vote(user.id, election["id"], target["user_id"])
    if not result["ok"]:
        text = {
            "already_voted": "❌ Tu as déjà voté.",
            "not_candidate": "❌ Ce joueur n'est pas candidat.",
        }.get(result["reason"], "❌ Vote impossible.")
        await update.message.reply_text(text)
        return
    await update.message.reply_text(f"✅ Vote enregistré pour {target['full_name']}.")

@require_registered
async def cmd_depouiller(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clôture l'élection terminée, vérifie le quorum et déclare le vainqueur."""
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, poste, started_by FROM elections WHERE status='open' AND ends_at<=? ORDER BY started_at DESC LIMIT 1",
            (now(),)
        ) as cur:
            election = await cur.fetchone()
    if not election:
        await update.message.reply_text("❌ Aucune élection terminée en attente.")
        return
    election_id = election["id"]
    poste = election["poste"]
    await auto_depouiller(election_id, poste)
    await update.message.reply_text("✅ Élection dépouillée automatiquement.")  # en fait c'est déjà fait dans auto_depouiller, mais on renvoie un message

# ----------------------------------------------------------------------
# 4. LOIS
# ----------------------------------------------------------------------
@require_registered
@require_free
@players_only
async def cmd_proposerloi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Propose une nouvelle loi (vote de tous les joueurs)."""
    user = update.effective_user
    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections.")
        return
    full = " ".join(context.args)
    if "|" in full:
        title_part, rest = full.split("|", 1)
        title, rest = title_part.strip(), rest.strip()
    else:
        title, rest = "Loi", full
    # Effet simple optionnel : /proposerloi Taxe de luxe | Augmente les impôts tax 5
    effect_type = None
    effect_value = None
    words = rest.split()
    if len(words) >= 2 and words[-2].lower() in ("tax", "subsidy", "policy"):
        try:
            effect_value = int(words[-1])
            effect_type = words[-2].lower()
            rest = " ".join(words[:-2])
        except ValueError:
            effect_type = None
    result = await laws_service.propose_law(user.id, title, rest, effect_type, effect_value)
    if not result["ok"]:
        if result["reason"] == "insufficient_funds":
            await update.message.reply_text(f"❌ Coût de proposition : {fmt_money(LAW_PROPOSAL_COST)}")
        else:
            await update.message.reply_text("❌ Titre et description requis.")
        return
    await update.message.reply_text(
        card(f"📜 Proposition de loi : {result['title']}",
             [f"📝 {result['description']}",
              f"🗳️ Vote ouvert jusqu'au {fmt_duration(LAW_VOTE_DURATION)}",
              f"Majorité requise : {int(LAW_DEFAULT_MAJORITY*100)}%",
              f"Ouvrez cette action depuis 🎮 Menu → 🏛️ Politique & élections"],
             icon="⚖️", style="thick")
    )

@require_registered
@players_only
async def cmd_voterloi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Vote pour ou contre une loi en cours."""
    user = update.effective_user
    if len(context.args) < 2:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections.")
        return
    title = " ".join(context.args[:-1])
    choice = laws_service.parse_choice(context.args[-1])
    if choice is None:
        await update.message.reply_text("Choix : pour ou contre")
        return
    law_id = await laws_service.find_law(title)
    if law_id is None:
        await update.message.reply_text("❌ Loi introuvable ou vote terminé.")
        return
    result = await laws_service.vote_law(user.id, law_id, choice)
    if not result["ok"]:
        text = ("❌ Tu as déjà voté sur cette loi." if result["reason"] == "already_voted"
                else "❌ Loi introuvable ou vote terminé.")
        await update.message.reply_text(text)
        return
    await update.message.reply_text(f"✅ Vote enregistré : {context.args[-1].lower()} pour la loi {title}.")

# ----------------------------------------------------------------------
# 5. GOUVERNEMENT (CABINET)
# ----------------------------------------------------------------------
@require_registered
@players_only
async def cmd_nommer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Le PRÉSIDENT élu nomme un MINISTRE. Le ministre entre dans l'Administration au grade « Ministre » et dirige
    une faction d'État (Intérieur → Police, Défense → Armée, Justice, Santé, Économie → impôt et Administration).
    Le nommé peut être un joueur ou un Admin N1 — au président de décider. Règles : `gameplay/cabinet.py`."""
    user = update.effective_user
    options = list(CABINET_POSITIONS)
    if len(context.args) < 2:
        await update.message.reply_text(f"Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections. Ministères : {', '.join(options)}")
        return
    position = cabinet_service.resolve_position(" ".join(context.args[1:]))
    if position is None:
        await update.message.reply_text(f"❌ Ministère inconnu. Choisis parmi : {', '.join(options)}")
        return
    if not await is_president(user.id):
        await update.message.reply_text("❌ Seul le Président élu nomme les ministres.")
        return
    from utils.user_lookup import find_user       # ID d'abord, puis @pseudo
    target = await find_user(context.args[0])
    if not target:
        await update.message.reply_text("❌ Joueur introuvable.")
        return
    result = await cabinet_service.appoint(user.id, target["user_id"], position)
    if not result["ok"]:
        text = {
            "target_not_player": "❌ Cette personne n'intervient pas dans la politique (Admin N2 ou plus).",
            "refused": f"❌ {result.get('message', 'Nomination impossible.')}",
        }.get(result["reason"], "❌ Nomination impossible.")
        await update.message.reply_text(text)
        return
    await update.message.reply_text(f"✅ {(target.get('full_name') or target.get('username') or target['user_id'])} est nommé(e) {result['label']}.")

@require_registered
async def cmd_nommer_ministre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Entrée du menu Politique : même logique que cmd_nommer (nom distinct de la commande d'entreprise)."""
    await cmd_nommer(update, context)


@require_registered
@players_only
async def cmd_revoquer_ministre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Le Président révoque un ministre : il reste dans l'Administration comme directeur."""
    user = update.effective_user
    if not context.args:
        await update.message.reply_text(f"Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections. Ministères : {', '.join(CABINET_POSITIONS)}")
        return
    position = cabinet_service.resolve_position(" ".join(context.args))
    if position is None:
        await update.message.reply_text(f"❌ Ministère inconnu. Choisis parmi : {', '.join(CABINET_POSITIONS)}")
        return
    if not await is_president(user.id):
        await update.message.reply_text("❌ Seul le Président élu révoque un ministre.")
        return
    result = await cabinet_service.dismiss(user.id, position)
    if not result["ok"]:
        await update.message.reply_text(f"❌ Le ministère {position} est déjà vacant.")
        return
    await update.message.reply_text(f"✅ Ministère {position} vacant.")

async def _government_lines() -> list[str]:
    """Président + ministres (avec la faction qu'ils dirigent), en HTML."""
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT u.full_name FROM political_offices po JOIN users u ON u.user_id=po.occupant_id "
            "WHERE po.poste='Président'") as cur:
            pres = await cur.fetchone()
        async with db.execute(
            "SELECT c.position, u.full_name FROM cabinet_positions c LEFT JOIN users u ON u.user_id=c.occupant_id") as cur:
            held = {r["position"]: r["full_name"] for r in await cur.fetchall()}
    lines = [f"👑 <b>Président</b> — {escape_html(pres['full_name']) if pres else '<i>vacant</i>'}", ""]
    for pos, info in MINISTRIES.items():
        who = held.get(pos)
        lines.append(f"{info['emoji']} <b>Ministre de {escape_html(pos)}</b> — "
                     f"{escape_html(who) if who else '<i>vacant</i>'}\n   <i>{escape_html(info['power'])}</i>")
    return lines


@require_registered
async def cmd_lois(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Lois en vigueur (adoptées par les joueurs)."""
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, title, description, votes_for, votes_against FROM laws WHERE status='passed' ORDER BY enacted_at DESC, id DESC LIMIT 10"
        ) as cur:
            laws = await cur.fetchall()
    if not laws:
        await update.message.reply_text("📜 Aucune loi en vigueur pour l'instant.")
        return
    lines = [f"📜 <b>{escape_html(l['title'])}</b> <i>(#{l['id']}, {l['votes_for']} pour / {l['votes_against']} contre)</i>\n"
             f"   {escape_html((l['description'] or '')[:140])}" for l in laws]
    await update.message.reply_text(card("📜 LOIS EN VIGUEUR", lines, icon="⚖️", style="thick"), parse_mode="HTML")


@require_registered
async def cmd_journal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Journal officiel : élections, nominations, motions, destitutions, lois, référendums."""
    events = await politics.recent_events(12)
    if not events:
        await update.message.reply_text("📰 Le journal officiel est encore vide.")
        return
    icons = {"election": "🗳️", "destitution": "⚖️", "motion": "⚠️", "loi": "📜", "referendum": "📢", "mandat": "🏛️", "nomination": "🎖️"}
    lines = [f"{icons.get(t, '•')} {escape_html(d)}\n   <i>il y a {fmt_duration(max(0, now() - ts))}</i>" for t, d, ts in events]
    await update.message.reply_text(card("📰 JOURNAL OFFICIEL", lines, icon="🏛️", style="thick"), parse_mode="HTML")


@require_registered
async def cmd_ministres(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche le gouvernement actuel : le Président et ses ministres (grades de l'Administration)."""
    await update.message.reply_text(
        card("🏛️ GOUVERNEMENT", await _government_lines(), icon="🏛️", style="thick"), parse_mode="HTML")

# ----------------------------------------------------------------------
# 6. RÉFÉRENDUMS
# ----------------------------------------------------------------------
@require_registered
@require_free
@players_only
async def cmd_referendum(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Propose un référendum (vote direct de tous)."""
    user = update.effective_user
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections.")
        return
    result = await laws_service.propose_referendum(user.id, " ".join(context.args))
    if not result["ok"]:
        await update.message.reply_text(f"❌ Coût : {fmt_money(REFERENDUM_COST)}")
        return
    await update.message.reply_text(
        card("🗳️ Référendum",
             [f"Question : {result['question']}",
              f"Votez depuis le 🎮 Menu principal",
              f"Durée : {fmt_duration(REFERENDUM_DURATION)}"],
             icon="📢", style="thick")
    )

@require_registered
@players_only
async def cmd_votereferendum(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    choice = laws_service.parse_choice(context.args[0]) if context.args else None
    if choice is None:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections.")
        return
    open_refs = await laws_service.list_referendums()
    if len(context.args) > 1 and context.args[1].lstrip("#").isdigit():
        wanted = int(context.args[1].lstrip("#"))
        open_refs = [r for r in open_refs if r["id"] == wanted]
    if not open_refs:
        await update.message.reply_text("❌ Aucun référendum ouvert.")
        return
    if len(open_refs) > 1:
        listing = "\n".join(f"#{r['id']} — {r['question'][:60]}" for r in sorted(open_refs, key=lambda r: r["id"]))
        await update.message.reply_text(
            f"Plusieurs référendums sont ouverts :\n{listing}\n\nRelance avec le numéro : /votereferendum pour <n°>")
        return
    result = await laws_service.vote_referendum(user.id, open_refs[0]["id"], choice)
    if not result["ok"]:
        text = "❌ Tu as déjà voté." if result["reason"] == "already_voted" else "❌ Aucun référendum ouvert."
        await update.message.reply_text(text)
        return
    await update.message.reply_text("✅ Vote enregistré.")

# ----------------------------------------------------------------------
# 7. DESTITUTION (MOTION) — règles dans utils/politics.py
# ----------------------------------------------------------------------
async def _find_target(token: str):
    """ID ou @pseudo → (user_id, full_name) ou None (ID d'abord)."""
    from utils.user_lookup import find_user
    row = await find_user(token)
    return (row["user_id"], row["full_name"]) if row else None


@require_registered
@require_free
@players_only
async def cmd_destituer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Lance une motion de destitution contre le Président ou un ministre (coût, immunité, signatures, quorum)."""
    user = update.effective_user
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections.")
        return
    target = await _find_target(context.args[0])
    if not target:
        await update.message.reply_text("❌ Joueur introuvable.")
        return
    target_id, target_name = target
    from utils.cooldowns import claim_cooldown, cooldown_left
    left = await cooldown_left(user.id, "last_motion", MOTION_COOLDOWN)
    if left:
        await update.message.reply_text(f"⏳ Tu as déjà lancé une motion récemment : encore {fmt_duration(left)}.")
        return
    ok, msg, info = await politics.check_motion(user.id, target_id)
    if not ok:
        await update.message.reply_text(f"❌ {msg}")
        return
    u = await get_user(user.id)
    if u["balance"] < MOTION_COST:
        await update.message.reply_text(f"❌ Lancer une motion coûte {fmt_money(MOTION_COST)} (versé au Trésor public).")
        return
    await update_balance(user.id, -MOTION_COST, sink="politique")
    await politics.create_motion(user.id, target_id)
    await claim_cooldown(user.id, "last_motion", MOTION_COOLDOWN)      # cooldown personnel, posé une fois la motion lancée
    await update.message.reply_text(
        card(f"⚖️ Motion contre {target_name}",
             [f"Poste : {info['label']}", f"Signatures nécessaires : {MOTION_SIGNATURES_NEEDED}",
              f"Délai pour signer : {fmt_duration(MOTION_SIGNATURE_DURATION)}",
              f"Coût payé : {fmt_money(MOTION_COST)}",
              "Les joueurs signent depuis 🎮 Menu → 🏛️ Politique & élections"],
             icon="⚠️", style="round")
    )


@require_registered
@players_only
async def cmd_signer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections.")
        return
    target = await _find_target(context.args[0])
    if not target:
        await update.message.reply_text("❌ Joueur introuvable.")
        return
    ok, msg = await politics.sign_motion(user.id, target[0])
    await update.message.reply_text(("✅ " if ok else "❌ ") + msg)


@require_registered
@players_only
async def cmd_vote_destitution(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/vote_destitution pour|contre [@cible] — la cible est facultative s'il n'y a qu'un vote ouvert."""
    user = update.effective_user
    if not context.args or context.args[0].lower() not in ('pour', 'contre'):
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏛️ Politique & élections.")
        return
    target_id = None
    if len(context.args) > 1:
        target = await _find_target(context.args[1])
        if not target:
            await update.message.reply_text("❌ Joueur introuvable.")
            return
        target_id = target[0]
    ok, msg = await politics.vote_motion(user.id, context.args[0].lower(), target_id)
    await update.message.reply_text(("✅ " if ok else "❌ ") + msg)

# ----------------------------------------------------------------------
# 8. COMMANDES UTILITAIRES
# ----------------------------------------------------------------------
@require_registered
async def cmd_monposte(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if await is_president(user.id):
        label, power = "Président", "Tu diriges l'Administration, nommes les ministres et répartis le Trésor public."
        left = await politics.term_left(user.id)
        if left is not None:
            power += f" Mandat : encore {fmt_duration(max(0, left))}."
    else:
        pos = await minister_of(user.id)
        if not pos:
            await update.message.reply_text("Tu n'occupes aucun poste au gouvernement.")
            return
        label, power = f"Ministre de {pos}", MINISTRIES[pos]["power"].capitalize() + "."
    await update.message.reply_text(
        card("🏛️ Ton mandat", [f"Poste : <b>{label}</b>", power, "Pour démissionner : 🎮 Menu → 🏛️ Politique & élections"],
             icon="📜", style="thick"), parse_mode="HTML")

@require_registered
@require_free
async def cmd_demissionnerposte(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not context.args or context.args[0].lower() != "confirmer":
        await update.message.reply_text("⚠️ Confirme depuis le 🎮 Menu principal")
        return
    if await is_president(user.id):
        await remove_president(user.id)
        poste = "Président"
    else:
        pos = await minister_of(user.id)
        if not pos:
            await update.message.reply_text("❌ Tu n'occupes aucun poste.")
            return
        await remove_minister(pos)
        poste = f"Ministre de {pos}"
    await update.message.reply_text(f"👋 Tu as démissionné ({poste}). Tu restes directeur de l'Administration.")

@require_registered
async def cmd_postes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Même affichage que /ministres : le gouvernement est le seul ensemble de postes politiques."""
    await cmd_ministres(update, context)

@require_registered
async def cmd_candidats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche la liste des candidats pour une élection spécifique ou toutes."""
    args = context.args
    # Nettoyer l'argument (minuscules, suppression des espaces superflus)
    poste_filter = " ".join(args).strip().lower() if args else None

    async with Outbox() as _out:
        async with db_connection() as db:
            db.row_factory = aiosqlite.Row
            if poste_filter:
                # Comparaison insensible à la casse (LOWER)
                async with db.execute(
                    "SELECT id, poste FROM elections WHERE status='open' AND ends_at > ? AND LOWER(poste) = ? ORDER BY started_at DESC LIMIT 1",
                    (now(), poste_filter)
                ) as cur:
                    election = await cur.fetchone()
                if not election:
                    # Lister les élections ouvertes pour aider
                    async with db.execute("SELECT DISTINCT poste FROM elections WHERE status='open' AND ends_at > ?", (now(),)) as cur2:
                        open_postes = [r["poste"] for r in await cur2.fetchall()]
                    if open_postes:
                        _out.add(update.message.reply_text, f"❌ Aucune élection ouverte pour ce poste.\nÉlections en cours : {', '.join(open_postes)}")
                    else:
                        _out.add(update.message.reply_text, "❌ Aucune élection ouverte actuellement.")
                    return
                elections = [election]
            else:
                async with db.execute(
                    "SELECT id, poste FROM elections WHERE status='open' AND ends_at > ? ORDER BY started_at ASC",
                    (now(),)
                ) as cur:
                    elections = await cur.fetchall()
                if not elections:
                    _out.add(update.message.reply_text, "Aucune élection ouverte.")
                    return

            all_messages = []
            for election in elections:
                election_id = election["id"]
                poste = election["poste"]
                async with db.execute("""
                SELECT u.user_id, u.full_name, u.username, c.program
                FROM candidates c
                JOIN users u ON u.user_id = c.user_id
                WHERE c.election_id = ?
            """, (election_id,)) as cur:
                    candidates = await cur.fetchall()
                if not candidates:
                    lines = [f"🏛️ <b>Élection : {poste}</b>", "   Aucun candidat pour le moment."]
                else:
                    lines = [f"🏛️ <b>Élection : {poste}</b>"]
                    for idx, cand in enumerate(candidates, 1):
                        prog = (cand["program"][:100] + "…") if len(cand["program"]) > 100 else cand["program"]
                        username = cand["username"] or "inconnu"
                        lines.append(f"{idx}. <b>{cand['full_name']}</b> (@{username})\n   📝 {prog}")
                all_messages.append("\n".join(lines))

            _out.add(update.message.reply_text, "\n\n━━━━━━━━━━━━━━━━━━━━━━\n\n".join(all_messages), parse_mode="HTML")

# ----------------------------------------------------------------------
# 9. MAINTENANCE AUTOMATIQUE (clôture des votes, application des résultats)
# ----------------------------------------------------------------------
async def auto_depouiller(election_id: int, poste: str):
    """Dépouille une élection terminée (règles : `gameplay/elections.tally_election`)."""
    await elections_service.tally_election(election_id, poste)


async def political_maintenance():
    """
    À appeler périodiquement (toutes les 5 minutes) :
    élections terminées, lois et référendums expirés, motions de destitution, fin du mandat présidentiel.
    """
    now_ts = now()
    async with db_connection() as db:
        async with db.execute(
            "SELECT id, poste FROM elections WHERE status='open' AND ends_at <= ?",
            (now_ts,)
        ) as cur:
            expired_elections = await cur.fetchall()
    for election_id, poste in expired_elections:
        await auto_depouiller(election_id, poste)

    for uid, msg in await laws_service.close_expired():
        try:
            await add_notification(uid, msg)
        except Exception:
            swallowed('handlers/political.py')

    # Destitutions (expiration des signatures, clôture des votes) puis fin de mandat du Président
    await politics.close_motions()
    await politics.expire_president_term()


@require_registered
async def cmd_elections(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Liste toutes les élections en cours."""
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, poste, started_by, started_at, ends_at, "
            "(SELECT COUNT(*) FROM candidates WHERE election_id = elections.id) as nb_candidats "
            "FROM elections WHERE status='open' AND ends_at > ? ORDER BY ends_at ASC",
            (now(),)
        ) as cur:
            elections = await cur.fetchall()
    if not elections:
        await update.message.reply_text("Aucune élection en cours.")
        return
    import html as _html
    lines = ["🗳️ <b>Élections en cours</b>\n"]
    for e in elections:
        time_left = e["ends_at"] - now()
        lines.append(
            f"🏛️ <b>{_html.escape(str(e['poste']))}</b> — {fmt_duration(time_left)} restant\n"
            f"   📢 Candidats : {e['nb_candidats']}   |   le menu"
        )
    await update.message.reply_text("\n\n".join(lines), parse_mode="HTML")
    


# ═══════════════════════════════════════════════════════════════════
#              🏛️ MENU INTERACTIF POLITIQUE
# ═══════════════════════════════════════════════════════════════════
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from utils.helpers import escape_html
from utils.helpers import safe_edit


# ═══════════════════════════════════════════════════════════════════
#              🗳️ SOUS-MENU : ÉLECTIONS
# ═══════════════════════════════════════════════════════════════════
async def show_pol_elections(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, poste, started_at, ends_at, "
            "(SELECT COUNT(*) FROM candidates WHERE election_id = elections.id) as nb "
            "FROM elections WHERE status='open' AND ends_at > ? ORDER BY ends_at ASC",
            (now(),)
        ) as cur:
            elections = await cur.fetchall()

    body = ["<i>Élections en cours :</i>", ""]
    if not elections:
        body.append("<i>Aucune élection ouverte actuellement.</i>")
    else:
        for e in elections:
            time_left = e["ends_at"] - now()
            body.append(
                f"🏛️ <b>{escape_html(e['poste'])}</b>\n"
                f"   📢 {e['nb']} candidat(s) · ⏳ {fmt_duration(time_left)}"
            )

    body += [
        "",
        "<b>Actions :</b>",
        "  • le 🎮 Menu principal — Lancer une élection",
        "  • le 🎮 Menu principal — Se présenter",
        "  • le 🎮 Menu principal — Voter pour un candidat",
        "  • le 🎮 Menu principal — Clôturer et proclamer le résultat",
        "  • le 🎮 Menu principal — Voir les candidats",
        "  • le 🎮 Menu principal — Liste complète",
    ]

    await safe_edit(
        query,
        card("🗳️ ÉLECTIONS", body, icon="🗳️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="pol_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              🏛️ SOUS-MENU : PARTIS
# ═══════════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════════
#              ⚖️ SOUS-MENU : LOIS
# ═══════════════════════════════════════════════════════════════════
async def show_pol_laws(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, title, description, status, votes_for, votes_against, voting_ends_at "
            "FROM laws WHERE status='voting' AND voting_ends_at > ? ORDER BY created_at DESC LIMIT 5",
            (now(),)
        ) as cur:
            laws = await cur.fetchall()

    body = ["<i>Lois en vote :</i>", ""]
    if not laws:
        body.append("<i>Aucune loi en vote actuellement.</i>")
    else:
        for law in laws:
            total = (law["votes_for"] or 0) + (law["votes_against"] or 0)
            body.append(
                f"📜 <b>{escape_html(law['title'])}</b>\n"
                f"   {escape_html(law['description'][:80])}\n"
                f"   ✅ {law['votes_for']} · ❌ {law['votes_against']} (total {total})"
            )

    body += [
        "",
        "<b>Actions :</b>",
        f"  • le 🎮 Menu principal — Coût : {fmt_money(LAW_PROPOSAL_COST)}",
        "  • le 🎮 Menu principal",
    ]

    await safe_edit(
        query,
        card("⚖️ LOIS", body, icon="⚖️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="pol_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              📢 SOUS-MENU : RÉFÉRENDUMS
# ═══════════════════════════════════════════════════════════════════
async def show_pol_referendums(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, question, votes_for, votes_against, voting_ends_at "
            "FROM referendums WHERE status='open' AND voting_ends_at > ? ORDER BY created_at DESC LIMIT 5",
            (now(),)
        ) as cur:
            refs = await cur.fetchall()

    body = ["<i>Référendums en cours :</i>", ""]
    if not refs:
        body.append("<i>Aucun référendum actif.</i>")
    else:
        for r in refs:
            total = (r["votes_for"] or 0) + (r["votes_against"] or 0)
            body.append(
                f"📢 <b>{escape_html(r['question'][:80])}</b>\n"
                f"   ✅ {r['votes_for']} · ❌ {r['votes_against']} (total {total})"
            )

    body += [
        "",
        "<b>Actions :</b>",
        f"  • le 🎮 Menu principal — Coût : {fmt_money(REFERENDUM_COST)}",
        "  • le 🎮 Menu principal",
    ]

    await safe_edit(
        query,
        card("📢 RÉFÉRENDUMS", body, icon="📢", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="pol_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              ⚔️ SOUS-MENU : DESTITUTION
# ═══════════════════════════════════════════════════════════════════
async def show_pol_motions(query, user_id: int):
    motions = await politics.motions_overview()
    body = ["<i>Destitution du Président ou d'un ministre.</i>", ""]
    if not motions:
        body.append("<i>Aucune motion active.</i>")
    for m in motions:
        if m["status"] == "pending":
            state = f"✍️ signatures {m['signatures']}/{m['needed']} · {fmt_duration(max(0, m['left']))} pour signer"
        else:
            state = f"🗳️ vote : ✅ {m['pour']} · ❌ {m['contre']} · {fmt_duration(max(0, m['left']))} restant"
        body.append(f"⚔️ <b>{escape_html(m['target_name'])}</b> — {escape_html(m['office'])}\n   {state}")
    body += [
        "",
        "<b>Règles :</b>",
        f"  • Lancer une motion : {fmt_money(MOTION_COST)} · {MOTION_SIGNATURES_NEEDED} signatures en {fmt_duration(MOTION_SIGNATURE_DURATION)}",
        f"  • Vote de {fmt_duration(MOTION_VOTE_DURATION)} · majorité 60 % (Président) ou 50 % (ministre) · quorum 10 % (5 à 50 votes)",
        f"  • Un nouveau titulaire est protégé {fmt_duration(MOTION_IMMUNITY)} · la cible ne signe ni ne vote",
        "",
        "<b>Actions :</b>",
        "  • 🎮 Menu → 🏛️ Politique — Lancer une motion / Signer / Voter",
    ]
    await safe_edit(
        query,
        card("⚔️ DESTITUTION", body, icon="⚔️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="pol_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              🏛️ SOUS-MENU : GOUVERNEMENT (Président + ministres = Administration)
# ═══════════════════════════════════════════════════════════════════
async def show_pol_government(query, user_id: int):
    body = ["<i>Le Président est élu par les joueurs. Il dirige l'Administration et nomme les ministres : "
            "chaque ministre est un grade de l'Administration qui dirige une faction d'État.</i>", ""]
    body += await _government_lines()
    body += [
        "",
        "<b>Actions :</b>",
        "  • 🎮 Menu → 🏛️ Politique — Nommer / révoquer un ministre (Président)",
        "  • 🎮 Menu → 🏛️ Politique — Voir ton mandat",
        "  • 🎮 Menu → 🎖️ État & factions → Trésor public — dotations et impôt",
    ]
    await safe_edit(
        query,
        card("🏛️ GOUVERNEMENT", body, icon="🏛️", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="pol_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              📜 CONSTITUTION
# ═══════════════════════════════════════════════════════════════════
async def show_pol_constitution(query, user_id: int):
    async with db_connection() as db:
        async with db.execute("SELECT text, amended_at FROM constitution WHERE id=1") as cur:
            row = await cur.fetchone()

    if row:
        text, amended_at = row
        body = [text, "", f"<i>Dernière modification : il y a {fmt_duration(now() - amended_at)}</i>"]
    else:
        body = [DEFAULT_CONSTITUTION]

    body += [
        "",
        "<b>Action :</b>",
        "  • le 🎮 Menu principal",
        "  <i>(Président et ministres uniquement)</i>",
    ]

    await safe_edit(
        query,
        card("📜 CONSTITUTION", body, icon="📜", style="thick"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="pol_menu")]])
    )


# ═══════════════════════════════════════════════════════════════════
#              🎯 CALLBACK ROUTEUR
# ═══════════════════════════════════════════════════════════════════
async def political_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routeur des callbacks 'pol_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "pol_menu":
        from handlers.hub import open_zone; await open_zone(query, "political")
        return
    if data == "pol_elections":
        await show_pol_elections(query, user_id)
        return
    if data == "pol_laws":
        await show_pol_laws(query, user_id)
        return
    if data == "pol_refs":
        await show_pol_referendums(query, user_id)
        return
    if data == "pol_motions":
        await show_pol_motions(query, user_id)
        return
    if data in ("pol_cabinet", "pol_government"):
        await show_pol_government(query, user_id)
        return
    if data == "pol_constitution":
        await show_pol_constitution(query, user_id)
        return
    if data == "pol_posts":
        await show_pol_government(query, user_id)
        return