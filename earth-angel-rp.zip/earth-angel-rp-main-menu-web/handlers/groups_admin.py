# handlers/groups_admin.py — gestion des groupes autorisés (Lead Staff et plus)
"""
/autoriser_groupe [ID]   — autorise le groupe courant, ou le groupe dont on donne l'ID (en privé)
/retirer_groupe [ID]     — retire l'autorisation (le bot reste dans le groupe mais ne fonctionne plus)
/groupes_autorises       — liste des groupes autorisés
"""
from utils.swallow import swallowed
import html

from telegram import Update
from telegram.ext import ContextTypes

from utils import groups
from utils.decorators import lead_staff_only


def _target_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int | None:
    if context.args:
        arg = context.args[0].strip()
        return int(arg) if arg.lstrip("-").isdigit() else None
    chat = update.effective_chat
    return chat.id if chat and chat.type in groups.GROUP_TYPES else None


_USAGE = ("ℹ️ Dans un groupe : <code>/autoriser_groupe</code>\n"
          "En privé : <code>/autoriser_groupe -1001234567890</code> (l'ID est affiché par le bot quand "
          "il est ajouté à un groupe non autorisé).")


@lead_staff_only
async def cmd_autoriser_groupe(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cid = _target_id(update, context)
    if cid is None or cid > 0:
        await update.effective_message.reply_text(_USAGE, parse_mode="HTML")
        return
    title = ""
    try:
        chat = await context.bot.get_chat(cid)
        title = chat.title or ""
    except Exception:
        swallowed('handlers/groups_admin.py')
    added = await groups.add_group(cid, title, update.effective_user.id)
    label = html.escape(title) if title else f"<code>{cid}</code>"
    await update.effective_message.reply_text(
        f"✅ Groupe autorisé : {label}" if added else f"ℹ️ Ce groupe était déjà autorisé : {label}",
        parse_mode="HTML")


@lead_staff_only
async def cmd_retirer_groupe(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cid = _target_id(update, context)
    if cid is None or cid > 0:
        await update.effective_message.reply_text(
            "ℹ️ Dans un groupe : <code>/retirer_groupe</code>\nEn privé : <code>/retirer_groupe -1001234567890</code>",
            parse_mode="HTML")
        return
    if cid in groups.ALLOWED_GROUP_IDS:
        await update.effective_message.reply_text(
            "⚠️ Ce groupe est autorisé par le fichier <code>.env</code> (ALLOWED_GROUP_IDS) : "
            "retire-le de ce fichier pour le supprimer.", parse_mode="HTML")
        return
    removed = await groups.remove_group(cid)
    await update.effective_message.reply_text(
        f"🗑️ Autorisation retirée : <code>{cid}</code> (le bot reste dans le groupe mais ne fonctionne plus)." if removed
        else f"ℹ️ Ce groupe n'était pas dans la liste : <code>{cid}</code>", parse_mode="HTML")


@lead_staff_only
async def cmd_groupes_autorises(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = await groups.list_groups()
    if not rows:
        await update.effective_message.reply_text(
            "📋 Aucun groupe autorisé pour le moment.\nAjoute-en un avec <code>/autoriser_groupe</code>.",
            parse_mode="HTML")
        return
    lines = ["📋 <b>Groupes autorisés</b>", ""]
    for cid, title, origin in rows:
        name = html.escape(title) if title else "<i>sans titre</i>"
        tag = " · .env" if origin == "env" else ""
        lines.append(f"• {name}\n   <code>{cid}</code>{tag}")
    lines += ["", "<i>/autoriser_groupe · /retirer_groupe</i>"]
    await update.effective_message.reply_text("\n".join(lines), parse_mode="HTML")
