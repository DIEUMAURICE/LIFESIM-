# handlers/events.py
# ✅ Fix #7 : mapping cohérent avec config.WORLD_EVENTS
#             (suppression des effets orphelins : economic_crisis, gold_rush, crime_wave)
# ✅ Harmonisation : clé happiness_gain_mult utilisée par social.py

from utils.swallow import swallowed
import random
import aiosqlite
from telegram import Update
from telegram.ext import ContextTypes
from database import db_connection, DB_PATH, get_active_event, get_user, update_field, increment_field, now
from utils.decorators import require_registered
from utils.helpers import fmt, fmt_time, parse_amount
from utils.aesthetics import card
from config import WORLD_EVENTS, SEASON_EFFECTS
from utils.gametime import game_datetime, game_season


# ═══════════════════════════════════════════════════════════════════════════
#   DESCRIPTIONS DES EFFETS D'ÉVÉNEMENTS (source unique de vérité)
#   → Utilisé par /createevent (admin) ET /evenements + /eventinfo (joueur)
# ═══════════════════════════════════════════════════════════════════════════
EVENT_EFFECTS_DESCRIPTIONS = {
    "market_crash": {
        "emoji": "📉",
        "label": "Krach boursier",
        "desc": "Le marché perd ~50% de sa valeur. Les investisseurs paniquent.",
    },
    "market_boom": {
        "emoji": "📈",
        "label": "Boom économique",
        "desc": "Le marché grimpe de ~80%. Les actionnaires font fortune.",
    },
    "health_crisis": {
        "emoji": "🏥",
        "label": "Crise sanitaire",
        "desc": "Les soins coûtent 2× plus cher. Les hôpitaux sont débordés.",
    },
    "tech_boom": {
        "emoji": "💻",
        "label": "Révolution technologique",
        "desc": "Les salaires du secteur Tech augmentent fortement.",
    },
    "trade_war": {
        "emoji": "⚔️",
        "label": "Guerre commerciale",
        "desc": "Les taxes et impôts augmentent légèrement pour tous.",
    },
    "political_shift": {
        "emoji": "🏛️",
        "label": "Changement politique",
        "desc": "Réorganisation politique, approbation des postes en hausse.",
    },
    "disaster": {
        "emoji": "🌪️",
        "label": "Catastrophe naturelle",
        "desc": "Propriétés endommagées, santé des joueurs en baisse.",
    },
    "energy_shift": {
        "emoji": "⚡",
        "label": "Révolution énergétique",
        "desc": "Le carburant et l'énergie coûtent 2× moins cher.",
    },
    "realestate_crash": {
        "emoji": "🏚️",
        "label": "Crise immobilière",
        "desc": "La valeur des propriétés chute brutalement.",
    },
    "happiness_boost": {
        "emoji": "🎉",
        "label": "Festival mondial",
        "desc": "Tous les joueurs gagnent +bonheur chaque jour.",
    },
}


def _relative_time(ts: int) -> str:
    """Retourne une durée relative lisible pour un timestamp UNIX."""
    if not ts:
        return "inconnu"
    return fmt_time(max(0, now() - ts))


# ═══════════════════════════════════════════════════════════════════════════
#                            /evenements
# ═══════════════════════════════════════════════════════════════════════════
@require_registered
async def cmd_evenements(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche l'événement actif et l'historique."""
    event = await get_active_event()

    text = "🌍 <b>Événements mondiaux</b>\n\n"

    if event:
        time_left = max(0, event["ends_at"] - now())
        severity = event.get("severity", 0.3)
        effect_key = event.get("effect", "")
        effect_data = EVENT_EFFECTS_DESCRIPTIONS.get(effect_key)

        text += "⚡ <b>ÉVÉNEMENT EN COURS :</b>\n"
        text += f"📋 <b>{event['name']}</b>\n"
        text += f"⏳ Se termine dans : <b>{fmt_time(time_left)}</b>\n"
        text += f"⚡ Intensité : <b>{int(severity * 100)}%</b>\n\n"

        if effect_data:
            text += f"{effect_data['emoji']} Effet : <b>{effect_data['label']}</b>\n"
            text += f"   <i>{effect_data['desc']}</i>\n\n"
        else:
            text += f"📊 Effet : <code>{effect_key}</code>\n\n"
    else:
        text += "<i>Aucun événement actif en ce moment.</i>\n\n"

    # ─── 3 derniers événements passés ───
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT name, effect, started_at, ends_at FROM world_events "
            "WHERE active=0 AND ends_at > 0 ORDER BY ends_at DESC LIMIT 3"
        ) as cur:
            past = await cur.fetchall()

    if past:
        text += "📜 <b>Derniers événements :</b>\n"
        for ev in past:
            effect_data = EVENT_EFFECTS_DESCRIPTIONS.get(ev["effect"], {})
            emoji = effect_data.get("emoji", "🌍")
            ago = _relative_time(ev["started_at"]) if ev["started_at"] else "?"
            text += f"• {emoji} <b>{ev['name']}</b> — il y a {ago}\n"

    text += "\n<i>Utilise le menu ou [effet] pour plus de détails.</i>"
    await update.message.reply_text(text, parse_mode="HTML")


# ═══════════════════════════════════════════════════════════════════════════
#                            /eventinfo
# ═══════════════════════════════════════════════════════════════════════════
@require_registered
async def cmd_eventinfo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les détails d'un événement (récents ou config).

    Accepte :
      - /eventinfo <nom exact ou partiel>    → cherche dans la BDD (actifs + passés)
      - /eventinfo <effect_key>              → cherche par clé d'effet (ex : market_crash)
      - /eventinfo <nom dans WORLD_EVENTS>   → cherche dans la config par défaut
    """
    if not context.args:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 🎮 Menu principal."
            "Exemples :\n"
            "  • le 🎮 Menu principal",
            parse_mode="HTML"
        )
        return

    query = " ".join(context.args).strip()
    query_lower = query.lower()

    # ══════════════════════════════════════════════════════════════
    #   1. Recherche en BDD (priorité aux événements récents)
    # ══════════════════════════════════════════════════════════════
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT * FROM world_events
            WHERE LOWER(name) = ?
               OR LOWER(effect) = ?
               OR LOWER(name) LIKE ?
            ORDER BY started_at DESC
            LIMIT 1
        """, (query_lower, query_lower, f"%{query_lower}%")) as cur:
            db_event = await cur.fetchone()

    if db_event:
        effect_key = db_event["effect"]
        effect_data = EVENT_EFFECTS_DESCRIPTIONS.get(effect_key, {})
        emoji = effect_data.get("emoji", "🌍")
        label = effect_data.get("label", effect_key)
        desc = effect_data.get("desc", "Effet non documenté.")

        if db_event["active"] and db_event["ends_at"] > now():
            time_left = db_event["ends_at"] - now()
            status_line = f"⏳ En cours — se termine dans <b>{fmt_time(time_left)}</b>"
        else:
            ended_ago = _relative_time(db_event["ends_at"])
            status_line = f"✅ Terminé — il y a <b>{ended_ago}</b>"

        started_str = _relative_time(db_event["started_at"]) if db_event["started_at"] else "inconnu"
        severity = db_event["severity"] if "severity" in db_event.keys() else 0.5

        body = [
            f"📛 Nom : <b>{db_event['name']}</b>",
            "",
            f"{emoji} Effet : <b>{label}</b>",
            f"   <i>{desc}</i>",
            f"   Clé : <code>{effect_key}</code>",
            "",
            f"⚡ Intensité : <b>{int((severity or 0.5) * 100)}%</b>",
            f"📅 Lancé il y a : <b>{started_str}</b>",
            f"{status_line}",
        ]
        await update.message.reply_text(
            card(f"📋 ÉVÉNEMENT — {db_event['name']}", body, icon="⚡", style="thick"),
            parse_mode="HTML"
        )
        return

    # ══════════════════════════════════════════════════════════════
    #   2. Fallback : recherche dans la config fixe WORLD_EVENTS
    # ══════════════════════════════════════════════════════════════
    config_event = None
    for e in WORLD_EVENTS:
        name_match = query_lower in e["name"].lower()
        effect_match = query_lower == e["effect"].lower()
        if name_match or effect_match:
            config_event = e
            break

    if config_event:
        effect_key = config_event["effect"]
        effect_data = EVENT_EFFECTS_DESCRIPTIONS.get(effect_key, {})
        emoji = effect_data.get("emoji", "🌍")
        label = effect_data.get("label", effect_key)
        desc = effect_data.get("desc", "Effet non documenté.")

        body = [
            f"📛 Nom : <b>{config_event['name']}</b>",
            "",
            f"{emoji} Effet : <b>{label}</b>",
            f"   <i>{desc}</i>",
            f"   Clé : <code>{effect_key}</code>",
            "",
            f"⚡ Intensité par défaut : <b>{int(config_event.get('severity', 0.3) * 100)}%</b>",
            "",
            "<i>Cet événement fait partie du catalogue par défaut du jeu.</i>",
        ]
        await update.message.reply_text(
            card(f"📋 ÉVÉNEMENT — {config_event['name']}", body, icon="⚡", style="thick"),
            parse_mode="HTML"
        )
        return

    # ══════════════════════════════════════════════════════════════
    #   3. Rien trouvé → liste d'aide
    # ══════════════════════════════════════════════════════════════
    effects_list = ", ".join(f"<code>{k}</code>" for k in EVENT_EFFECTS_DESCRIPTIONS.keys())
    await update.message.reply_text(
        card(
            "❌ ÉVÉNEMENT INTROUVABLE",
            [
                f"Aucun événement ne correspond à : <b>{query}</b>",
                "",
                "<b>Tu peux essayer :</b>",
                "  • Un nom d'événement récent (voir le menu)",
                "  • Une clé d'effet :",
                f"  {effects_list}",
            ],
            icon="❓", style="round",
        ),
        parse_mode="HTML"
    )


# ═══════════════════════════════════════════════════════════════════════════
#                     Effets multiplicateurs
# ✅ Fix #7 : seuls les effets de config.WORLD_EVENTS sont gérés
# ═══════════════════════════════════════════════════════════════════════════
async def get_event_effect() -> dict:
    """
    Retourne l'effet de l'événement actif sous forme de multiplicateurs.
    ✅ Fix #7 : les clés retournées correspondent exactement aux effets
                déclarés dans config.WORLD_EVENTS. Plus d'effets orphelins.
    """
    event = await get_active_event()
    if not event:
        return {
            "work_mult": 1.0,
            "crime_mult": 1.0,
            "crime_jail_mult": 1.0,
            "health_cost_mult": 1.0,
            "tax_mult": 1.0,
            "happiness_gain_mult": 1.0,
            "market_mult": 1.0,
            "travel_cost_mult": 1.0,
            "travel_happiness_mult": 1.0,
        }

    effect = event["effect"]
    severity = event.get("severity", 0.3)

    defaults = {
        "work_mult": 1.0,
        "crime_mult": 1.0,
        "crime_jail_mult": 1.0,
        "health_cost_mult": 1.0,
        "tax_mult": 1.0,
        "happiness_gain_mult": 1.0,
        "market_mult": 1.0,
        "travel_cost_mult": 1.0,
        "travel_happiness_mult": 1.0,
    }

    # ⭐ Mapping canonique — chaque clé existe dans config.WORLD_EVENTS
    if effect == "market_crash":
        defaults["market_mult"] = 1 - severity

    elif effect == "market_boom":
        defaults["market_mult"] = 1 + severity * 0.8

    elif effect == "health_crisis":
        defaults["health_cost_mult"] = 2.0

    elif effect == "tech_boom":
        # Le secteur tech paie mieux : bonus de revenus de travail
        defaults["work_mult"] = 1 + severity * 0.5

    elif effect == "trade_war":
        defaults["tax_mult"] = 1.05

    elif effect == "political_shift":
        # Légère amélioration du moral (nouvelle ère politique)
        defaults["happiness_gain_mult"] = 1 + severity * 0.15

    elif effect == "disaster":
        defaults["health_cost_mult"] = 1 + severity
        defaults["work_mult"] = 1 - severity * 0.3

    elif effect == "energy_shift":
        # Voyages moins chers + gains de travail boostés
        defaults["work_mult"] = 1 + severity * 0.2
        defaults["travel_cost_mult"] = max(0.5, 1 - severity * 0.5)

    elif effect == "realestate_crash":
        defaults["market_mult"] = 1 - severity * 0.5

    elif effect == "happiness_boost":
        defaults["happiness_gain_mult"] = 1.5
        defaults["travel_happiness_mult"] = 1.3

    return defaults


# ═══════════════════════════════════════════════════════════════════════════
#                        Trigger (utilisé par le scheduler)
# ═══════════════════════════════════════════════════════════════════════════
async def trigger_random_event(bot, user_ids: list):
    """Déclenche un événement mondial aléatoire et notifie tous les joueurs."""
    total_weight = sum(e.get("weight", 10) for e in WORLD_EVENTS)
    roll = random.uniform(0, total_weight)
    cumul = 0
    chosen = WORLD_EVENTS[0]
    for e in WORLD_EVENTS:
        cumul += e.get("weight", 10)
        if roll <= cumul:
            chosen = e
            break

    duration = random.randint(6, 48) * 3600
    severity = chosen.get("severity", random.uniform(0.2, 0.6))

    async with db_connection() as db:
        await db.execute("UPDATE world_events SET active=0")
        await db.execute(
            "INSERT INTO world_events (name, effect, severity, started_at, ends_at, active) VALUES (?,?,?,?,?,1)",
            (chosen["name"], chosen["effect"], severity, now(), now() + duration)
        )
        await db.commit()

    if chosen["effect"] == "market_crash":
        from database import get_market_price, update_market_price
        from config import ASSETS
        for asset in ASSETS:
            price = await get_market_price(asset["name"])
            await update_market_price(asset["name"], price * (1 - severity))
    elif chosen["effect"] == "market_boom":
        from database import get_market_price, update_market_price
        from config import ASSETS
        for asset in ASSETS:
            price = await get_market_price(asset["name"])
            await update_market_price(asset["name"], price * (1 + severity * 0.8))

    effect_data = EVENT_EFFECTS_DESCRIPTIONS.get(chosen["effect"], {})
    emoji = effect_data.get("emoji", "🌍")
    label = effect_data.get("label", chosen["effect"])
    desc = effect_data.get("desc", "")

    announcement = (
        f"🌍 <b>ÉVÉNEMENT MONDIAL : {chosen['name']}</b>\n\n"
        f"{emoji} <b>{label}</b>\n"
        f"<i>{desc}</i>\n\n"
        f"📉 Intensité : <b>{int(severity * 100)}%</b>\n"
        f"⏳ Durée : <b>{fmt_time(duration)}</b>\n\n"
        f"<i>Utilise le menu pour plus d'informations.</i>"
    )

    count = 0
    for uid in user_ids[:500]:
        try:
            await bot.send_message(uid, announcement, parse_mode="HTML")
            count += 1
        except Exception:
            swallowed('handlers/events.py')
    print(f"📢 Événement '{chosen['name']}' notifié à {count} joueurs.")


# ═══════════════════════════════════════════════════════════════════════════
#                 Maintenance : nettoyer les événements expirés
# ═══════════════════════════════════════════════════════════════════════════
async def process_expired_events():
    """Désactive les événements expirés."""
    async with db_connection() as db:
        await db.execute("UPDATE world_events SET active=0 WHERE ends_at < ?", (now(),))
        await db.commit()


# ─────────────────────────────────────────────────────────────────────────────
# Calendrier du jeu : saison, date — identiques pour TOUS les joueurs (ex handlers/calendar.py)
# ─────────────────────────────────────────────────────────────────────────────
def get_real_season() -> dict:
    """Saison du monde de jeu (conservé sous ce nom pour compatibilité)."""
    d = game_datetime()
    return {"season": d["season"], "day": d["yday"]}


async def get_user_season(user_id: int) -> dict:
    """Saison du jeu (globale) + effets. `user_id` conservé pour compatibilité."""
    season = game_season()
    return {
        "season": season,
        "effects": SEASON_EFFECTS.get(season, SEASON_EFFECTS["Printemps"]),
    }


async def get_calendar(user_id: int = None):
    """Point d'entrée principal : saison du jeu partagée par tous les joueurs."""
    if user_id is not None:
        return await get_user_season(user_id)
    return get_real_season()
