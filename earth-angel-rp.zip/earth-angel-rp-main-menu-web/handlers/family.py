# handlers/family.py
import aiosqlite
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes
from database import db_connection, DeferredReply, DB_PATH, get_user, update_field, update_balance, get_marriage, get_top_rich
from utils.decorators import require_registered, require_free
from utils.helpers import fmt, now, get_title, escape_md
from utils.helpers import escape_html

# ─────────────────────────────────────────────────────────────────────────────
# Mariage
# ─────────────────────────────────────────────────────────────────────────────

@require_registered
@require_free
async def cmd_mariage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not update.message.reply_to_message:
        await update.message.reply_text("❌ Réponds au message de la personne à qui tu veux te marier.")
        return

    target = update.message.reply_to_message.from_user
    if target.id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas te marier à toi-même !")
        return

    # Vérifier l'âge minimum (18 ans)
    if u.get("age", 0) < 18:
        await update.message.reply_text("❌ Tu dois avoir au moins 18 ans pour te marier.")
        return

    t_data = await get_user(target.id)
    if t_data.get("age", 0) < 18:
        await update.message.reply_text(f"❌ {escape_md(target.full_name)} doit avoir au moins 18 ans pour se marier.")
        return

    # Vérifier si déjà marié
    marriage = await get_marriage(user.id)
    if marriage:
        await update.message.reply_text("❌ Tu es déjà marié(e) ! Divorce d'abord depuis le menu.")
        return

    target_marriage = await get_marriage(target.id)
    if target_marriage:
        await update.message.reply_text(f"❌ {escape_md(target.full_name)} est déjà marié(e) !")
        return

    # Coût du mariage
    MARRY_COST = 50_000
    if u["balance"] < MARRY_COST:
        await update.message.reply_text(
            f"❌ Le mariage coûte <b>{escape_html(fmt(MARRY_COST))}</b>.\nTon solde : {escape_html(fmt(u['balance']))}",
            parse_mode="HTML"
        )
        return

    # Envoyer la demande
    async with db_connection() as db:
        await db.execute("DELETE FROM marriage_requests WHERE to_id=?", (target.id,))
        await db.execute(
            "INSERT INTO marriage_requests (from_id, to_id, created_at) VALUES (?,?,?)",
            (user.id, target.id, now())
        )
        await db.commit()

    await update.message.reply_text(
        f"💍 <b>Demande en mariage envoyée !</b>\n\n"
        f"👤 De : {escape_html(escape_md(user.full_name))}\n"
        f"👤 Vers : {escape_html(escape_md(target.full_name))}\n"
        f"💰 Frais : {escape_html(fmt(MARRY_COST))} (déduits au moment de l'acceptation)\n\n"
        f"<i>{escape_html(escape_md(target.full_name))}, utilise le menu pour accepter !</i>",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_acceptermariage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM marriage_requests WHERE to_id=? ORDER BY created_at DESC LIMIT 1",
            (user.id,)
        ) as cur:
            req = await cur.fetchone()

    if not req:
        await update.message.reply_text("❌ Tu n'as pas de demande en mariage en attente.")
        return

    from_user = await get_user(req["from_id"])
    MARRY_COST = 50_000

    if u["balance"] < MARRY_COST:
        await update.message.reply_text(
            f"❌ Le mariage coûte <b>{escape_html(fmt(MARRY_COST))}</b>.\nTon solde : {escape_html(fmt(u['balance']))}",
            parse_mode="HTML"
        )
        return

    await update_balance(user.id, -MARRY_COST, sink="etat_civil")
    await update_balance(from_user["user_id"], -MARRY_COST)

    async with db_connection() as db:
        await db.execute(
            "INSERT OR REPLACE INTO marriages (user_id, partner_id, married_at, status) VALUES (?,?,?,?)",
            (user.id, req["from_id"], now(), "active")
        )
        await db.execute(
            "INSERT OR REPLACE INTO marriages (user_id, partner_id, married_at, status) VALUES (?,?,?,?)",
            (req["from_id"], user.id, now(), "active")
        )
        await db.execute("DELETE FROM marriage_requests WHERE to_id=?", (user.id,))
        await db.commit()

    await update.message.reply_text(
        f"💒 <b>Mariage célébré !</b>\n\n"
        f"💍 {escape_html(escape_md(from_user['full_name']))} ❤️ {escape_html(escape_md(user.full_name))}\n"
        f"💰 Frais totaux : {escape_html(fmt(MARRY_COST * 2))}\n\n"
        f"<i>Que votre vie commune soit prospère !</i>\n\n"
        f"💡 Avantages du mariage :\n"
        f"• Bonus de 5% sur les revenus partagés\n"
        f"• Accès à l'arbre généalogique familial\n"
        f"• Possibilité d'adopter ensemble",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_divorce(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    marriage = await get_marriage(user.id)

    if not marriage:
        await update.message.reply_text("❌ Tu n'es pas marié(e).")
        return

    partner = await get_user(marriage["partner_id"])
    DIVORCE_COST = 25_000
    u = await get_user(user.id)

    if u["balance"] < DIVORCE_COST:
        await update.message.reply_text(
            f"❌ Le divorce coûte <b>{escape_html(fmt(DIVORCE_COST))}</b>.\nTon solde : {escape_html(fmt(u['balance']))}",
            parse_mode="HTML"
        )
        return

    await update_balance(user.id, -DIVORCE_COST, sink="etat_civil")

    async with db_connection() as db:
        await db.execute(
            "UPDATE marriages SET status='divorced', divorced_at=? WHERE user_id=? OR partner_id=?",
            (now(), user.id, user.id)
        )
        await db.commit()

    await update.message.reply_text(
        f"💔 <b>Divorce prononcé...</b>\n\n"
        f"Tu divorces de <b>{escape_html(escape_md(partner['full_name']))}</b>.\n"
        f"💰 Frais : {escape_html(fmt(DIVORCE_COST))}\n\n"
        f"<i>Une page se tourne. Vers de nouveaux horizons !</i>",
        parse_mode="HTML"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Arbre généalogique et famille
# ─────────────────────────────────────────────────────────────────────────────

@require_registered
async def cmd_arbre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT f.*, fm.role FROM family_members fm JOIN family f ON f.family_id=fm.family_id WHERE fm.user_id=?",
            (user.id,)
        ) as cur:
            fam_row = await cur.fetchone()

    marriage = await get_marriage(user.id)
    u = await get_user(user.id)

    text = f"🌳 <b>Arbre généalogique de {escape_html(escape_md(user.full_name))}</b>\n\n"

    if marriage:
        partner = await get_user(marriage["partner_id"])
        text += f"💍 Conjoint(e) : <b>{escape_html(escape_md(partner['full_name']))}</b>\n"
        text += f"   💰 {escape_html(fmt(partner['balance']))} | {escape_html(get_title(partner['balance']))}\n\n"

    # Enfants adoptés
    async with db_connection() as db:
        async with db.execute(
            "SELECT u.full_name, u.balance FROM adoptions a JOIN users u ON u.user_id=a.child_id WHERE a.parent_id=?",
            (user.id,)
        ) as cur:
            children = await cur.fetchall()
        async with db.execute(
            "SELECT u.full_name, u.balance FROM adoptions a JOIN users u ON u.user_id=a.parent_id WHERE a.child_id=?",
            (user.id,)
        ) as cur:
            parents = await cur.fetchall()

    if children:
        text += "👶 <b>Enfants adoptés :</b>\n"
        for c in children:
            text += f"  • {escape_html(escape_md(c[0]))} — {escape_html(fmt(c[1]))}\n"
        text += "\n"
    if parents:
        text += "👨‍👩 <b>Parents adoptifs :</b>\n"
        for p in parents:
            text += f"  • {escape_html(escape_md(p[0]))} — {escape_html(fmt(p[1]))}\n"
        text += "\n"

    if fam_row:
        text += f"👨‍👩‍👧 <b>Clan familial :</b> <b>{escape_html(escape_md(fam_row['name']))}</b>\n"
        text += f"📋 Ton rôle : {escape_html(escape_md(fam_row['role']))}\n\n"

        async with db_connection() as db:
            async with db.execute("""
                SELECT u.full_name, u.balance, fm.role
                FROM family_members fm JOIN users u ON u.user_id=fm.user_id
                WHERE fm.family_id=?
            """, (fam_row["family_id"],)) as cur:
                members = await cur.fetchall()

        text += "👥 <b>Membres :</b>\n"
        for m in members:
            text += f"  • <b>{escape_html(escape_md(m[0]))}</b> ({escape_html(escape_md(m[2]))}) — {escape_html(fmt(m[1]))}\n"
    else:
        text += "_Tu n'as pas de clan familial.\n/creerfamille [nom] pour en créer un !_"

    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
async def cmd_famille(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche les informations du clan familial (alias de le menu)."""
    await cmd_arbre(update, context)


@require_registered
@require_free
async def cmd_creer_famille(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Créer un clan familial."""
    user = update.effective_user
    u = await get_user(user.id)

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 👥 Multijoueur & famille.")
        return

    name = " ".join(context.args)[:40]
    FAMILY_COST = 30_000

    if u["balance"] < FAMILY_COST:
        await update.message.reply_text(
            f"❌ Créer un clan coûte <b>{escape_html(fmt(FAMILY_COST))}</b>.\nSolde : {escape_html(fmt(u['balance']))}",
            parse_mode="HTML"
        )
        return

    try:
        async with db_connection() as db:
            async with db.execute("SELECT family_id FROM family_members WHERE user_id=?", (user.id,)) as cur:
                if await cur.fetchone():
                    raise DeferredReply(update.message.reply_text, "❌ Tu es déjà membre d'un clan.")
            async with db.execute("SELECT family_id FROM family WHERE LOWER(name)=LOWER(?)", (name,)) as cur:
                if await cur.fetchone():
                    raise DeferredReply(update.message.reply_text, f"❌ Le nom <b>{escape_html(escape_md(name))}</b> est déjà pris.", parse_mode="HTML")

            await db.execute(
                "INSERT INTO family (name, founder_id, created_at) VALUES (?,?,?)",
                (name, user.id, now())
            )
            async with db.execute("SELECT last_insert_rowid()") as cur:
                fam_id = (await cur.fetchone())[0]
            await db.execute(
                "INSERT INTO family_members (family_id, user_id, role, joined_at) VALUES (?,?,'Fondateur',?)",
                (fam_id, user.id, now())
            )
            await db.commit()
    except DeferredReply as _deferred:
        return await _deferred.send()

    await update_balance(user.id, -FAMILY_COST, sink="etat_civil")
    await update.message.reply_text(
        f"👨‍👩‍👧 <b>Clan fondé !</b>\n\n"
        f"🏡 Nom : <b>{escape_html(escape_md(name))}</b>\n"
        f"👑 Fondateur : {escape_html(escape_md(user.full_name))}\n"
        f"💰 Coût : {escape_html(fmt(FAMILY_COST))}\n\n"
        f"_Invite des membres depuis le menu",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_inviterfamille(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Inviter un joueur à rejoindre son clan familial."""
    user = update.effective_user

    if not update.message.reply_to_message:
        await update.message.reply_text("❌ Réponds au message du joueur à inviter.")
        return

    target = update.message.reply_to_message.from_user
    if target.id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas t'inviter toi-même.")
        return

    async with db_connection() as db:
        async with db.execute(
            "SELECT f.family_id, f.name FROM family_members fm JOIN family f ON f.family_id=fm.family_id WHERE fm.user_id=?",
            (user.id,)
        ) as cur:
            family = await cur.fetchone()

    if not family:
        await update.message.reply_text("❌ Tu n'es dans aucun clan. Utilise le menu pour en créer un.")
        return

    try:
        async with db_connection() as db:
            async with db.execute(
                "SELECT family_id FROM family_members WHERE user_id=?", (target.id,)
            ) as cur:
                if await cur.fetchone():
                    raise DeferredReply(update.message.reply_text, f"❌ {escape_md(target.full_name)} est déjà dans un clan.")
    except DeferredReply as _deferred:
        return await _deferred.send()

    async with db_connection() as db:
        await db.execute(
            "INSERT OR REPLACE INTO family_invites (family_id, invited_id, invited_by, created_at) VALUES (?,?,?,?)",
            (family[0], target.id, user.id, now())
        )
        await db.commit()

    await update.message.reply_text(
        f"📨 Invitation envoyée à <b>{escape_html(escape_md(target.full_name))}</b> pour rejoindre <b>{escape_html(escape_md(family[1]))}</b> !\n"
        f"Il doit utiliser le menu pour accepter.",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_rejoindrefamille(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Rejoindre un clan sur invitation."""
    user = update.effective_user

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 👥 Multijoueur & famille.")
        return

    family_name = " ".join(context.args)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT f.family_id, f.name FROM family f WHERE LOWER(f.name)=LOWER(?)",
            (family_name,)
        ) as cur:
            family = await cur.fetchone()

    if not family:
        await update.message.reply_text(f"❌ Clan **{escape_md(family_name)}** introuvable.")
        return

    async with db_connection() as db:
        async with db.execute(
            "SELECT * FROM family_invites WHERE family_id=? AND invited_id=?",
            (family["family_id"], user.id)
        ) as cur:
            invite = await cur.fetchone()

    if not invite:
        await update.message.reply_text(f"❌ Tu n'as pas d'invitation pour **{escape_md(family['name'])}**.")
        return

    async with db_connection() as db:
        await db.execute(
            "INSERT INTO family_members (family_id, user_id, role, joined_at) VALUES (?,?,'Membre',?)",
            (family["family_id"], user.id, now())
        )
        await db.execute("DELETE FROM family_invites WHERE family_id=? AND invited_id=?", (family["family_id"], user.id))
        await db.commit()

    await update.message.reply_text(
        f"🎉 Bienvenue dans le clan <b>{escape_html(escape_md(family['name']))}</b> !\n"
        f"Utilise le menu pour voir tes nouveaux compagnons.",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_quitterfamille(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Quitter son clan familial."""
    user = update.effective_user

    async with db_connection() as db:
        async with db.execute(
            "SELECT f.family_id, f.name, fm.role FROM family_members fm JOIN family f ON f.family_id=fm.family_id WHERE fm.user_id=?",
            (user.id,)
        ) as cur:
            member = await cur.fetchone()

    if not member:
        await update.message.reply_text("❌ Tu n'es dans aucun clan.")
        return

    family_id, family_name, role = member

    if role == "Fondateur":
        async with db_connection() as db:
            async with db.execute(
                "SELECT COUNT(*) FROM family_members WHERE family_id=?", (family_id,)
            ) as cur:
                count = (await cur.fetchone())[0]
        if count > 1:
            await update.message.reply_text(
                "❌ Tu es le fondateur. Tu ne peux pas quitter sans dissoudre ou transférer.\n"
                "Ouvre le 🎮 Menu principal pour passer le leadership.\n"
                "Ou le 🎮 Menu principal pour dissoudre le clan."
            )
            return
        else:
            async with db_connection() as db:
                await db.execute("DELETE FROM family WHERE family_id=?", (family_id,))
                await db.execute("DELETE FROM family_members WHERE family_id=?", (family_id,))
                await db.commit()
            await update.message.reply_text(f"💀 Le clan **{escape_md(family_name)}** a été dissous car tu étais le dernier membre.")
            return
    else:
        async with db_connection() as db:
            await db.execute("DELETE FROM family_members WHERE user_id=? AND family_id=?", (user.id, family_id))
            await db.commit()
        await update.message.reply_text(f"👋 Tu as quitté le clan <b>{escape_html(escape_md(family_name))}</b>.", parse_mode="HTML")


# ─────────────────────────────────────────────────────────────────────────────
# Amis
# ─────────────────────────────────────────────────────────────────────────────

@require_registered
@require_free
async def cmd_ami(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not update.message.reply_to_message:
        await update.message.reply_text("❌ Réponds au message du joueur à ajouter en ami.")
        return

    target = update.message.reply_to_message.from_user
    if target.id == user.id:
        await update.message.reply_text("❌ Tu ne peux pas t'ajouter toi-même en ami !")
        return

    async with db_connection() as db:
        await db.execute(
            "INSERT OR IGNORE INTO friendships (user_id, friend_id, since) VALUES (?,?,?)",
            (user.id, target.id, now())
        )
        await db.commit()

    await update.message.reply_text(
        f"👫 <b>{escape_html(escape_md(target.full_name))} ajouté(e) en ami !</b>\n"
        f"<i>Prenez soin l'un de l'autre dans ce monde.</i>",
        parse_mode="HTML"
    )


@require_registered
async def cmd_mesamis(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT u.full_name, u.balance, f.since
            FROM friendships f JOIN users u ON u.user_id=f.friend_id
            WHERE f.user_id=?
        """, (user.id,)) as cur:
            friends = await cur.fetchall()

    if not friends:
        await update.message.reply_text(
            "👥 Tu n'as aucun ami.\n"
            "Réponds au message de qqn et utilise le menu pour l'ajouter."
        )
        return

    text = f"👥 <b>Tes amis ({escape_html(len(friends))})</b>\n\n"
    for f in friends:
        text += f"• <b>{escape_html(escape_md(f['full_name']))}</b> — {escape_html(fmt(f['balance']))} | {escape_html(get_title(f['balance']))}\n"
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("🗑️ Retirer un ami", callback_data="fm:a_retirerami")]])
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=kb)


@require_registered
@require_free
async def cmd_retirerami(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Retire un joueur de la liste d'amis (l'ami est choisi par bouton)."""
    user = update.effective_user
    try:
        friend_id = int(context.args[0])
    except (IndexError, ValueError):
        await update.message.reply_text("❌ Choisis l'ami à retirer depuis le menu Multijoueur → Retirer un ami.")
        return
    async with db_connection() as db:
        async with db.execute("SELECT full_name FROM users WHERE user_id=?", (friend_id,)) as cur:
            row = await cur.fetchone()
        res = await db.execute("DELETE FROM friendships WHERE user_id=? AND friend_id=?", (user.id, friend_id))
        await db.commit()
    if not res.rowcount:
        await update.message.reply_text("❌ Cette personne n'est pas dans ta liste d'amis.")
        return
    name = escape_md((row[0] if row else None) or "Ce joueur")
    await update.message.reply_text(f"👋 <b>{escape_html(name)}</b> a été retiré(e) de tes amis.", parse_mode="HTML")


# ─────────────────────────────────────────────────────────────────────────────
# Classement général
# ─────────────────────────────────────────────────────────────────────────────

@require_registered
async def cmd_leaderboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ouvre l'écran unique des classements (handlers/rankings.py)."""
    from handlers.rankings import show_for_update
    await show_for_update(update, 'richesse')


# ─────────────────────────────────────────────────────────────────────────────
# Adoption
# ─────────────────────────────────────────────────────────────────────────────

@require_registered
@require_free
async def cmd_adopter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not update.message.reply_to_message:
        await update.message.reply_text("❌ Réponds au message du joueur que tu veux adopter.")
        return
    target = update.message.reply_to_message.from_user
    try:
        from gameplay.family import FamilyError, adopt_child
        result = await adopt_child(user.id, target.id)
    except FamilyError as exc:
        await update.message.reply_text(f"❌ {escape_html(str(exc))}", parse_mode="HTML")
        return
    await update.message.reply_text(
        f"👨‍👩‍👧 <b>Adoption réussie !</b>\n\n"
        f"Tu as adopté <b>{escape_html(escape_md(target.full_name))}</b> !\n"
        f"💰 Frais d'adoption : {escape_html(fmt(result['cost_paid']))}\n\n"
        f"<i>Vous êtes maintenant liés dans l'arbre généalogique.</i>\n"
        f"Consulte le menu pour voir ta famille.",
        parse_mode="HTML"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Transfert de leadership de clan
# ─────────────────────────────────────────────────────────────────────────────

@require_registered
@require_free
async def cmd_transfertclan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    if not update.message.reply_to_message:
        await update.message.reply_text("❌ Réponds au message du joueur à qui tu veux transférer le leadership.")
        return

    target = update.message.reply_to_message.from_user
    try:
        from gameplay.family import FamilyError, transfer_family_founder
        result = await transfer_family_founder(user.id, target.id)
    except FamilyError as exc:
        await update.message.reply_text(f"❌ {escape_html(str(exc))}", parse_mode="HTML")
        return

    await update.message.reply_text(
        f"👑 <b>Transfert de leadership</b>\n\n"
        f"<b>{escape_html(escape_md(target.full_name))}</b> est maintenant le fondateur du clan <b>{escape_html(escape_md(result['family_name']))}</b>.\n"
        f"Tu deviens 'Ex-fondateur'.",
        parse_mode="HTML"
    )


@require_registered
@require_free
async def cmd_dissoudrefamille(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    async with db_connection() as db:
        async with db.execute(
            "SELECT f.family_id, f.name FROM family f WHERE f.founder_id=?",
            (user.id,)
        ) as cur:
            family = await cur.fetchone()

    if not context.args or context.args[0].lower() != "confirmer":
        if not family:
            await update.message.reply_text("❌ Tu n'es pas le fondateur d'un clan.")
            return
        await update.message.reply_text(
            f"⚠️ **DANGER : Dissolution du clan {escape_md(family[1])}**\n\n"
            f"Cette action est IRRÉVERSIBLE !\n"
            f""
        )
        return

    try:
        from gameplay.family import FamilyError, dissolve_family
        result = await dissolve_family(user.id)
    except FamilyError as exc:
        await update.message.reply_text(f"❌ {escape_html(str(exc))}", parse_mode="HTML")
        return
    await update.message.reply_text(f"💀 Le clan <b>{escape_html(escape_md(result['family_name']))}</b> a été dissous.", parse_mode="HTML")

# ─────────────────────────────────────────────────────────────────────────────
# Formulaire « Retirer un ami » (choix de l'ami par boutons)
# ─────────────────────────────────────────────────────────────────────────────
from utils.forms import Form, P, provider, register  # noqa: E402


@provider("friends_list")
async def _prov_friends(user_id: int):
    async with db_connection() as db:
        async with db.execute(
                "SELECT f.friend_id, COALESCE(u.full_name, u.username, 'Joueur') "
                "FROM friendships f LEFT JOIN users u ON u.user_id=f.friend_id "
                "WHERE f.user_id=? ORDER BY f.since DESC LIMIT 40", (user_id,)) as cur:
            rows = await cur.fetchall()
    return [(str(name)[:30], str(fid)) for fid, name in rows]


register(Form("a_retirerami", "🗑️ Retirer un ami", "handlers.family:cmd_retirerami",
              params=(P("friend", "choice", "Quel ami veux-tu retirer de ta liste ?", choices="friends_list"),),
              confirm="Retirer cet ami de ta liste ?", back="hub:multi:0"))
