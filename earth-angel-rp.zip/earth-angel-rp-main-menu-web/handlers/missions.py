# handlers/missions.py
# ✅ Fix #13 : UPSERT atomique dans _add_random_item_inner
# ✅ Fix #18 : add_life_journal reçoit la connexion courante (évite "database is locked")

from utils.gamerules import faucet
import random
import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import DB_PATH, get_user, update_balance, increment_field, db_connection
from utils.decorators import require_registered, require_free
from utils.helpers import fmt, now
from utils.vip import xp_boost_multiplier, coins_boost_multiplier
from config import DAILY_MISSIONS, WEEKLY_MISSIONS
from utils.gametime import game_now
from handlers.vehicles import get_active_vehicle
from utils.helpers import safe_edit
from utils.helpers import escape_html


# ─────────────────────────────────────────────────────────────────────────────
# Helper : ajouter un item aléatoire (avec pool de connexions)
# ─────────────────────────────────────────────────────────────────────────────
async def add_random_item(user_id: int, min_rarity: str = "common",
                          max_rarity: str = "legendary", db=None):
    """Ajoute un item aléatoire à l'inventaire du joueur.

    Si `db` est fourni, utilise cette connexion (pas de commit → c'est à l'appelant).
    Sinon, ouvre sa propre connexion via le pool.
    """
    rarity_order = ["common", "rare", "epic", "legendary"]
    min_idx = rarity_order.index(min_rarity)
    max_idx = rarity_order.index(max_rarity)
    possible = [r for r in rarity_order if min_idx <= rarity_order.index(r) <= max_idx]
    chosen_rarity = random.choice(possible)

    # ─── Cas 1 : connexion fournie par l'appelant ───
    if db is not None:
        return await _add_random_item_inner(db, user_id, chosen_rarity)

    # ─── Cas 2 : connexion propre via pool ───
    async with db_connection(row_factory=aiosqlite.Row) as db_conn:
        result = await _add_random_item_inner(db_conn, user_id, chosen_rarity)
        await db_conn.commit()
        return result


async def _add_random_item_inner(db, user_id: int, chosen_rarity: str):
    """
    Logique interne : utilise la connexion `db` fournie.
    ✅ Fix #13 : UPSERT atomique (INSERT ... ON CONFLICT DO UPDATE)
    """
    prev_factory = db.row_factory
    db.row_factory = aiosqlite.Row
    try:
        async with db.execute(
            "SELECT item_id, name, emoji, rarity FROM items "
            "WHERE rarity = ? ORDER BY RANDOM() LIMIT 1",
            (chosen_rarity,)
        ) as cur:
            item = await cur.fetchone()
        if not item:
            return None

        await db.execute(
            """
            INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at)
            VALUES (?, ?, ?, ?, 1, ?)
            ON CONFLICT(user_id, item_id) DO UPDATE SET
                quantity = inventory.quantity + 1
            """,
            (user_id, item["item_id"], "mission", item["name"], now())
        )
        return f"{item['emoji']} {item['name']} ({item['rarity']})"
    finally:
        db.row_factory = prev_factory


# ─────────────────────────────────────────────────────────────────────────────
# Gestion du temps de jeu (pour les reset)
# ─────────────────────────────────────────────────────────────────────────────
def get_game_day_reset() -> int:
    """Timestamp (temps de jeu) du début de la journée de jeu en cours (00:00 heure de jeu)."""
    t = game_now()
    return t - (t % 86_400)


def get_game_week_reset() -> int:
    """Timestamp (temps de jeu) du début de la semaine de jeu en cours (lundi 00:00 heure de jeu)."""
    t = game_now()
    monday_offset = 4 * 86_400          # le 05/01/1970 (premier lundi) = 4 jours après l'epoch UNIX
    return t - ((t - monday_offset) % 604_800)


# ─────────────────────────────────────────────────────────────────────────────
# Fonction pour récupérer les missions disponibles selon le cargo
# ─────────────────────────────────────────────────────────────────────────────
async def get_available_missions(user_id: int, missions: list) -> list:
    """Filtre les missions selon le cargo du véhicule actif."""
    active_vehicle = await get_active_vehicle(user_id)
    vehicle_cargo = active_vehicle.get("cargo", 0) if active_vehicle else 0

    available = []
    blocked = []

    for mission in missions:
        if mission.get("type") == "delivery" or "livraison" in mission.get("name", "").lower():
            required_cargo = mission.get("cargo_required", 50)
            if vehicle_cargo < required_cargo:
                blocked.append(mission)
                continue
        available.append(mission)

    return available, blocked, vehicle_cargo


# ─────────────────────────────────────────────────────────────────────────────
# Commandes utilisateur
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_missions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if u.get("hospital_until", 0) > now():
        await update.message.reply_text("🏥 Tu es hospitalisé(e) ! Repose-toi avant de consulter tes missions.")
        return

    await ensure_missions(user.id)
    await update_balance_mission(user.id)

    active_vehicle = await get_active_vehicle(user.id)
    vehicle_cargo = active_vehicle.get("cargo", 0) if active_vehicle else 0

    if active_vehicle:
        cargo_msg = f"🚛 Cargo du véhicule : {vehicle_cargo}/100"
        if vehicle_cargo >= 80:
            cargo_msg += " 🏆 Capacité maximale !"
        elif vehicle_cargo >= 50:
            cargo_msg += " ✅ Capacité suffisante pour les livraisons lourdes"
        else:
            cargo_msg += " ⚠️ Capacité limitée - missions de livraison restreintes"
    else:
        cargo_msg = "🚫 Aucun véhicule actif → missions de livraison indisponibles"

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM missions WHERE user_id=? ORDER BY completed ASC, period ASC",
            (user.id,)
        ) as cur:
            all_missions = [dict(m) for m in await cur.fetchall()]

    daily = [m for m in all_missions if m["period"] == "daily"]
    weekly = [m for m in all_missions if m["period"] == "weekly"]

    text = "🎯 <b>Tes missions</b>\n\n"
    text += f"<i>{escape_html(cargo_msg)}</i>\n\n"

    text += "<b>📅 Missions journalières</b>\n"
    for m in daily:
        is_delivery = m.get("mission_type") == "delivery" or "livraison" in m.get("mission_name", "").lower()
        cargo_ok = vehicle_cargo >= m.get("cargo_required", 50) if is_delivery else True

        if is_delivery and not cargo_ok:
            required = m.get("cargo_required", 50)
            text += (
                f"🔒 <b>{escape_html(m['mission_name'])}</b>\n"
                f"  🚛 Cargo requis : {escape_html(required)}\n"
                f"  ❌ Mission bloquée - cargo insuffisant\n\n"
            )
            continue

        progress_bar = "█" * int((m["progress"] / max(1, m["target"])) * 10)
        progress_bar = progress_bar[:10].ljust(10, "░")
        status = "✅" if m["completed"] else f"[{progress_bar}]"
        text += (
            f"{escape_html(status)} <b>{escape_html(m['mission_name'])}</b>\n"
            f"  Progress : {escape_html(m['progress'])}/{escape_html(m['target'])}\n"
            f"  Récompense : {escape_html(fmt(m['reward']))} + {escape_html(m['xp_reward'])} XP\n"
        )
        if is_delivery:
            text += f"  🚛 Cargo requis : {escape_html(m.get('cargo_required', 50))}\n"
        text += "\n"

    text += "\n<b>📆 Missions hebdomadaires</b>\n"
    for m in weekly:
        is_delivery = m.get("mission_type") == "delivery" or "livraison" in m.get("mission_name", "").lower()
        cargo_ok = vehicle_cargo >= m.get("cargo_required", 50) if is_delivery else True

        if is_delivery and not cargo_ok:
            required = m.get("cargo_required", 50)
            text += (
                f"🔒 <b>{escape_html(m['mission_name'])}</b>\n"
                f"  🚛 Cargo requis : {escape_html(required)}\n"
                f"  ❌ Mission bloquée - cargo insuffisant\n\n"
            )
            continue

        progress_bar = "█" * int((m["progress"] / max(1, m["target"])) * 10)
        progress_bar = progress_bar[:10].ljust(10, "░")
        status = "✅" if m["completed"] else f"[{progress_bar}]"
        text += (
            f"{escape_html(status)} <b>{escape_html(m['mission_name'])}</b>\n"
            f"  Progress : {escape_html(m['progress'])}/{escape_html(m['target'])}\n"
            f"  Récompense : {escape_html(fmt(m['reward']))} + {escape_html(m['xp_reward'])} XP\n"
        )
        if is_delivery:
            text += f"  🚛 Cargo requis : {escape_html(m.get('cargo_required', 50))}\n"
        text += "\n"

    completed = len([m for m in all_missions if m["completed"]])
    total = len(all_missions)

    blocked_deliveries = [
        m for m in daily + weekly
        if (m.get("mission_type") == "delivery" or "livraison" in m.get("mission_name", "").lower())
        and vehicle_cargo < m.get("cargo_required", 50)
    ]
    if blocked_deliveries:
        text += f"\n🔒 <b>Missions bloquées :</b> {escape_html(len(blocked_deliveries))}\n"
        text += "<i>Améliore ton cargo avec un véhicule plus grand !</i>\n"

    text += f"\n📊 Complétées : {escape_html(completed)}/{escape_html(total)}"
    await update.message.reply_text(text, parse_mode="HTML")


@require_registered
@require_free
async def cmd_missions_completed(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT mission_name, period, completed FROM missions "
            "WHERE user_id=? AND completed=1 ORDER BY completed_at DESC LIMIT 10",
            (user.id,)
        ) as cur:
            completed = await cur.fetchall()
    if not completed:
        await update.message.reply_text("📋 Tu n'as encore terminé aucune mission.")
        return
    text = "🏆 <b>Missions terminées récemment</b>\n\n"
    for m in completed:
        text += f"✅ {escape_html(m['mission_name'])} ({escape_html(m['period'])})\n"
    await update.message.reply_text(text, parse_mode="HTML")


# ─────────────────────────────────────────────────────────────────────────────
# Fonction interne pour créer les missions
# ─────────────────────────────────────────────────────────────────────────────
async def ensure_missions(user_id: int):
    """Crée les missions quotidiennes/hebdomadaires si elles n'existent pas."""
    async with db_connection() as db:
        today_reset = get_game_day_reset()
        week_reset = get_game_week_reset()

        for m in DAILY_MISSIONS:
            async with db.execute(
                "SELECT 1 FROM missions WHERE user_id=? AND mission_name=? "
                "AND period='daily' AND reset_at=?",
                (user_id, m["name"], today_reset)
            ) as cur:
                if await cur.fetchone():
                    continue
            await db.execute(
                "DELETE FROM missions WHERE user_id=? AND mission_name=? AND period='daily'",
                (user_id, m["name"])
            )
            await db.execute(
                "INSERT INTO missions (user_id, mission_name, mission_type, progress, target, "
                "reward, xp_reward, completed, period, reset_at, completed_at) "
                "VALUES (?,?,?,0,?,?,?,0,'daily',?,0)",
                (user_id, m["name"], m["type"], m["target"], m["reward"], m["xp"], today_reset)
            )

        for m in WEEKLY_MISSIONS:
            async with db.execute(
                "SELECT 1 FROM missions WHERE user_id=? AND mission_name=? "
                "AND period='weekly' AND reset_at=?",
                (user_id, m["name"], week_reset)
            ) as cur:
                if await cur.fetchone():
                    continue
            await db.execute(
                "DELETE FROM missions WHERE user_id=? AND mission_name=? AND period='weekly'",
                (user_id, m["name"])
            )
            await db.execute(
                "INSERT INTO missions (user_id, mission_name, mission_type, progress, target, "
                "reward, xp_reward, completed, period, reset_at, completed_at) "
                "VALUES (?,?,?,0,?,?,?,0,'weekly',?,0)",
                (user_id, m["name"], m["type"], m["target"], m["reward"], m["xp"], week_reset)
            )

        await db.commit()


# ─────────────────────────────────────────────────────────────────────────────
# Mise à jour de la progression (appelée depuis d'autres handlers)
# ✅ Fix #18 : add_life_journal partage la transaction SQLite courante
# ─────────────────────────────────────────────────────────────────────────────
async def update_mission_progress(user_id: int, mission_type: str, amount: int = 1):
    """Met à jour la progression d'une mission."""
    active_vehicle = await get_active_vehicle(user_id)
    vehicle_cargo = active_vehicle.get("cargo", 0) if active_vehicle else 0

    user_data = await get_user(user_id)
    xp_mult = xp_boost_multiplier(user_data)
    coins_mult = coins_boost_multiplier(user_data)
    old_xp = int(user_data.get("xp", 0) or 0)
    done_missions: list[tuple[str, int, int]] = []

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM missions WHERE user_id=? AND mission_type=? AND completed=0",
            (user_id, mission_type)
        ) as cur:
            missions = [dict(m) for m in await cur.fetchall()]

        for m in missions:
            is_delivery = (
                m.get("mission_type") == "delivery"
                or "livraison" in m.get("mission_name", "").lower()
            )
            if is_delivery:
                required_cargo = m.get("cargo_required", 50)
                if vehicle_cargo < required_cargo:
                    continue

            new_progress = m["progress"]
            if m["mission_type"] == "balance":
                new_progress = amount
            else:
                new_progress = m["progress"] + amount
            completed = 1 if new_progress >= m["target"] else 0
            completed_at = now() if completed else 0
            await db.execute(
                "UPDATE missions SET progress=?, completed=?, completed_at=? "
                "WHERE user_id=? AND mission_name=? AND period=?",
                (min(new_progress, m["target"]), completed, completed_at,
                 user_id, m["mission_name"], m["period"])
            )

            if completed and not m["completed"]:
                boosted_reward = await faucet("missions", int(m["reward"] * coins_mult))   # ⚙️ réglage du staff
                boosted_xp = int(m["xp_reward"] * xp_mult)
                done_missions.append((m["mission_name"], boosted_reward, boosted_xp))

                await db.execute(
                    "UPDATE users SET balance=balance+?, xp=xp+?, "
                    "missions_done=missions_done+1 WHERE user_id=?",
                    (boosted_reward, boosted_xp, user_id)
                )
                await db.execute(
                    "INSERT INTO mission_log (user_id, mission_name, reward, xp, completed_at) "
                    "VALUES (?,?,?,?,?)",
                    (user_id, m["mission_name"], boosted_reward, boosted_xp, now())
                )

                # ─────────────────────────────────────────────────────────
                # Récompense bonus : item aléatoire
                # ✅ Fix #18 : add_life_journal reçoit db=db → même transaction
                #             (évite le "database is locked" en cascade)
                # ─────────────────────────────────────────────────────────
                if random.random() < 0.4:
                    if m["period"] == "weekly":
                        item = await add_random_item(user_id, "rare", "legendary", db=db)
                    else:
                        item = await add_random_item(user_id, "common", "epic", db=db)
                    if item:
                        from database import add_life_journal
                        await add_life_journal(
                            user_id, "mission",
                            f"Mission '{m['mission_name']}' accomplie ! "
                            f"Récompense bonus : {item}",
                            severity="success",
                            db=db,                    # ⭐ FIX : même transaction
                        )

        await db.commit()

    if done_missions:                                    # 🔔 le joueur est toujours prévenu
        from utils.notify import notify
        from utils.progress_notify import check_level_up
        for name, reward, xp in done_missions:
            await notify(user_id, "🎯 Mission accomplie",
                         f"<b>{name}</b> — +{reward:,} €A et +{xp} XP ont été versés.", "reward")
        await check_level_up(user_id, old_xp)


# ─────────────────────────────────────────────────────────────────────────────
# Mise à jour de la mission "balance"
# ─────────────────────────────────────────────────────────────────────────────
async def update_balance_mission(user_id: int):
    """Met à jour la mission de type 'balance' avec le solde actuel."""
    u = await get_user(user_id)
    balance = u.get("balance", 0)
    await update_mission_progress(user_id, "balance", balance)


# ─────────────────────────────────────────────────────────────────────────────
# Réinitialisation automatique (appelée par le scheduler)
# ─────────────────────────────────────────────────────────────────────────────
async def reset_daily_missions():
    today_reset = get_game_day_reset()
    async with db_connection() as db:
        await db.execute("DELETE FROM missions WHERE period='daily' AND reset_at < ?", (today_reset,))
        await db.commit()


async def reset_weekly_missions():
    week_reset = get_game_week_reset()
    async with db_connection() as db:
        await db.execute("DELETE FROM missions WHERE period='weekly' AND reset_at < ?", (week_reset,))
        await db.commit()


# ─────────────────────────────────────────────────────────────────────────────
# Fonction pour récupérer les missions disponibles avec filtrage cargo
# ─────────────────────────────────────────────────────────────────────────────
async def get_missions_with_cargo_filter(user_id: int) -> dict:
    """Retourne un dictionnaire avec les missions disponibles et bloquées."""
    await ensure_missions(user_id)

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM missions WHERE user_id=? ORDER BY completed ASC, period ASC",
            (user_id,)
        ) as cur:
            all_missions = [dict(m) for m in await cur.fetchall()]

    active_vehicle = await get_active_vehicle(user_id)
    vehicle_cargo = active_vehicle.get("cargo", 0) if active_vehicle else 0

    available = []
    blocked = []

    for mission in all_missions:
        is_delivery = (
            mission.get("mission_type") == "delivery"
            or "livraison" in mission.get("mission_name", "").lower()
        )
        if is_delivery:
            required_cargo = mission.get("cargo_required", 50)
            if vehicle_cargo < required_cargo:
                blocked.append(mission)
                continue
        available.append(mission)

    return {
        "available": available,
        "blocked": blocked,
        "vehicle_cargo": vehicle_cargo,
        "has_vehicle": active_vehicle is not None
    }


# ═══════════════════════════════════════════════════════════════════
#              🎯 MENU INTERACTIF DES MISSIONS
# ═══════════════════════════════════════════════════════════════════



def _progress_bar(progress: int, target: int, length: int = 10) -> str:
    if target <= 0:
        return "░" * length
    ratio = min(1.0, max(0.0, progress / target))
    filled = int(ratio * length)
    return "█" * filled + "░" * (length - filled)


async def show_missions_daily(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM missions WHERE user_id=? AND period='daily' ORDER BY completed ASC",
            (user_id,)
        ) as cur:
            missions = [dict(m) for m in await cur.fetchall()]

    if not missions:
        await safe_edit(
            query,
            "📭 Aucune mission quotidienne pour le moment.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="miss_menu")]])
        )
        return

    active_vehicle = await get_active_vehicle(user_id)
    vehicle_cargo = active_vehicle.get("cargo", 0) if active_vehicle else 0

    body = []
    for m in missions:
        is_delivery = (m.get("mission_type") == "delivery"
                       or "livraison" in m.get("mission_name", "").lower())
        if is_delivery and vehicle_cargo < m.get("cargo_required", 50):
            body.append(
                f"🔒 <b>{m['mission_name']}</b>\n"
                f"   🚛 Cargo requis : {m.get('cargo_required', 50)} (bloqué)"
            )
            continue

        bar = _progress_bar(m["progress"], m["target"])
        status = "✅" if m["completed"] else "⏳"
        body.append(
            f"{status} <b>{m['mission_name']}</b>\n"
            f"   <code>{bar}</code> {m['progress']}/{m['target']}\n"
            f"   💰 {fmt(m['reward'])} · ✨ {m['xp_reward']} XP"
        )
        if is_delivery:
            body.append(f"   🚛 Cargo requis : {m.get('cargo_required', 50)}")

    await safe_edit(
        query,
        "📅 <b>MISSIONS QUOTIDIENNES</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="miss_menu")]])
    )


async def show_missions_weekly(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM missions WHERE user_id=? AND period='weekly' ORDER BY completed ASC",
            (user_id,)
        ) as cur:
            missions = [dict(m) for m in await cur.fetchall()]

    if not missions:
        await safe_edit(
            query,
            "📭 Aucune mission hebdomadaire pour le moment.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="miss_menu")]])
        )
        return

    active_vehicle = await get_active_vehicle(user_id)
    vehicle_cargo = active_vehicle.get("cargo", 0) if active_vehicle else 0

    body = []
    for m in missions:
        is_delivery = (m.get("mission_type") == "delivery"
                       or "livraison" in m.get("mission_name", "").lower())
        if is_delivery and vehicle_cargo < m.get("cargo_required", 50):
            body.append(
                f"🔒 <b>{m['mission_name']}</b>\n"
                f"   🚛 Cargo requis : {m.get('cargo_required', 50)} (bloqué)"
            )
            continue

        bar = _progress_bar(m["progress"], m["target"])
        status = "✅" if m["completed"] else "⏳"
        body.append(
            f"{status} <b>{m['mission_name']}</b>\n"
            f"   <code>{bar}</code> {m['progress']}/{m['target']}\n"
            f"   💰 {fmt(m['reward'])} · ✨ {m['xp_reward']} XP"
        )
        if is_delivery:
            body.append(f"   🚛 Cargo requis : {m.get('cargo_required', 50)}")

    await safe_edit(
        query,
        "📆 <b>MISSIONS HEBDOMADAIRES</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="miss_menu")]])
    )


async def show_missions_done(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT mission_name, period, completed_at FROM missions "
            "WHERE user_id=? AND completed=1 ORDER BY completed_at DESC LIMIT 15",
            (user_id,)
        ) as cur:
            rows = await cur.fetchall()

    if not rows:
        await safe_edit(
            query,
            "🏆 Tu n'as encore terminé aucune mission.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="miss_menu")]])
        )
        return

    body = []
    for r in rows:
        emoji = "📅" if r["period"] == "daily" else "📆"
        body.append(f"✅ {emoji} <b>{r['mission_name']}</b>")

    await safe_edit(
        query,
        "🏆 <b>MISSIONS TERMINÉES</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="miss_menu")]])
    )


async def do_claim_rewards(query, user_id: int):
    """Force la vérification des missions et affiche les récompenses reçues."""
    from gameplay.missions import reward_summary
    summary = await reward_summary(user_id)
    if not summary["missions"]:
        await safe_edit(
            query,
            "🎁 Aucune récompense à réclamer pour le moment.\n\n"
            "<i>Continue à progresser dans tes missions !</i>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="miss_menu")]])
        )
        return

    body = [
        f"🎁 <b>{summary['completed_count']} mission(s) accomplie(s)</b>",
        "",
        f"💰 Total déjà reçu : <b>{fmt(summary['total_coins'])}</b>",
        f"✨ Total déjà reçu : <b>{summary['total_xp']} XP</b>",
        "",
        "<i>Les récompenses sont versées automatiquement dès qu'une mission est complétée.</i>",
    ]

    await safe_edit(
        query,
        card_simple("🎁 RÉCOMPENSES", body, icon="🎁"),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="miss_menu")]])
    )


def card_simple(title: str, body: list, icon: str = "🎯", style: str = "thick") -> str:
    """Mini-wrapper safe qui évite d'importer card si absent."""
    try:
        from utils.aesthetics import card as _card
        return _card(title, body, icon=icon, style=style)
    except Exception:
        return f"{icon} <b>{title}</b>\n" + "\n".join(body)


async def missions_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routeur des callbacks 'miss_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "miss_menu":
        from handlers.hub import open_zone; await open_zone(query, "missions")
        return
    if data == "miss_daily":
        await show_missions_daily(query, user_id)
        return
    if data == "miss_weekly":
        await show_missions_weekly(query, user_id)
        return
    if data == "miss_done":
        await show_missions_done(query, user_id)
        return
    if data == "miss_claim":
        await do_claim_rewards(query, user_id)
        return
