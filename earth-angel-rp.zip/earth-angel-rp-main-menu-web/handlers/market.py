# handlers/market.py — Phase 1 : Marché joueur (commandes renommées)
# ✅ Fix #4 : UPDATE company_products filtré par company_id
# ✅ UPSERT atomique pour add_item (anti race-condition)

from utils.swallow import swallowed
import random
from utils.vip import add_xp
import aiosqlite
import asyncio
try:
    from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
except ImportError:  # tests unitaires qui fournissent un stub minimal de telegram
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    Update = object
try:
    from telegram.ext import ContextTypes
except ImportError:  # stub Telegram utilisé par les tests de helpers
    class ContextTypes:
        DEFAULT_TYPE = object
from database import (
    DeferredReply,
    DB_PATH, get_user, update_balance, add_life_journal,
    update_field, increment_field, log_company_action, db_connection,
    get_inventory,
)
from utils.decorators import require_registered, require_free, cooldown
from utils.helpers import fmt, now, parse_amount, fmt_time, escape_html
from utils.aesthetics import card, alert, section
from handlers.vehicles import get_active_vehicle, get_vehicle_stats

# ─────────────────────────────────────────────────────────────────────────────
# Helper : obtenir la quantité d'un item dans l'inventaire
# ─────────────────────────────────────────────────────────────────────────────
async def get_item_quantity(user_id: int, item_id: int) -> int:
    async with db_connection() as db:
        async with db.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?",
            (user_id, item_id)
        ) as cur:
            row = await cur.fetchone()
    return row[0] if row else 0


# ─────────────────────────────────────────────────────────────────────────────
# Helper : supprimer un item de l'inventaire (quantité)
# ─────────────────────────────────────────────────────────────────────────────
async def remove_item(user_id: int, item_id: int, quantity: int = 1) -> bool:
    qty = await get_item_quantity(user_id, item_id)
    if qty < quantity:
        return False
    async with db_connection() as db:
        if qty == quantity:
            await db.execute(
                "DELETE FROM inventory WHERE user_id = ? AND item_id = ?",
                (user_id, item_id)
            )
        else:
            await db.execute(
                "UPDATE inventory SET quantity = quantity - ? WHERE user_id = ? AND item_id = ?",
                (quantity, user_id, item_id)
            )
        await db.commit()
    return True


# ─────────────────────────────────────────────────────────────────────────────
# Helper : ajouter un item à l'inventaire (robuste)
# ─────────────────────────────────────────────────────────────────────────────
async def add_item(user_id: int, item_id: int, quantity: int, source: str = None):
    """Ajoute un item à l'inventaire d'un joueur. Si l'item n'existe pas, le crée."""
    # 1. S'assurer que l'item existe dans la table items
    await ensure_item_exists(item_id)

    # 2. Récupérer le nom de l'item
    async with db_connection() as db:
        async with db.execute("SELECT name FROM items WHERE item_id = ?", (item_id,)) as cur:
            row = await cur.fetchone()
        item_name = row[0] if row else f"Item #{item_id}"

        # 3. ⭐ UPSERT atomique (fix race-condition)
        await db.execute(
            """
            INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(user_id, item_id) DO UPDATE SET
                quantity = inventory.quantity + excluded.quantity
            """,
            (user_id, item_id, source or "market", item_name, quantity, now())
        )
        await db.commit()


# ─────────────────────────────────────────────────────────────────────────────
# Helper : s'assurer qu'un item existe dans la table items
# ─────────────────────────────────────────────────────────────────────────────
async def ensure_item_exists(item_id: int) -> bool:
    """Vérifie et crée l'item dans la table items si nécessaire."""
    async with db_connection() as db:
        # Vérifier si l'item existe déjà
        async with db.execute("SELECT item_id FROM items WHERE item_id = ?", (item_id,)) as cur:
            if await cur.fetchone():
                return True

        # L'item n'existe pas, on le crée
        # Essayer de récupérer le nom depuis l'inventaire
        async with db.execute(
            "SELECT item_name FROM inventory WHERE item_id = ? LIMIT 1",
            (item_id,)
        ) as cur2:
            inv_item = await cur2.fetchone()

        name = inv_item[0] if inv_item else f"Item #{item_id}"

        # Créer l'item avec un type par défaut
        await db.execute(
            """
            INSERT INTO items (item_id, name, type, rarity, value, emoji, description) 
            VALUES (?, ?, 'unknown', 'common', 0, '📦', ?)
            """,
            (item_id, name, f"Item récupéré automatiquement")
        )
        await db.commit()
        return True


# ─────────────────────────────────────────────────────────────────────────────
# Helper : calculer le bonus cargo pour les ventes
# ─────────────────────────────────────────────────────────────────────────────
async def get_cargo_bonus(user_id: int, base_price: int) -> tuple:
    active_vehicle = await get_active_vehicle(user_id)

    if active_vehicle:
        veh_data = await get_vehicle_stats(active_vehicle["veh_type"])
        vehicle_cargo = active_vehicle.get("cargo", 0)
        if vehicle_cargo == 0 and veh_data.get("cargo", 0) > 0:
            vehicle_cargo = veh_data.get("cargo", 0)
            async with db_connection() as db:
                await db.execute(
                    "UPDATE vehicles SET cargo = ? WHERE veh_id = ?",
                    (vehicle_cargo, active_vehicle["veh_id"])
                )
                await db.commit()
    else:
        vehicle_cargo = 0

    cargo_bonus_mult = 1 + (vehicle_cargo / 500)
    cargo_bonus_mult = min(1.20, cargo_bonus_mult)
    final_price = int(base_price * cargo_bonus_mult)
    return final_price, cargo_bonus_mult, vehicle_cargo


# ─────────────────────────────────────────────────────────────────────────────
# /market : afficher les annonces
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_market(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    page = 1
    if context.args and context.args[0].isdigit():
        page = int(context.args[0])

    per_page = 10
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ml.listing_id, ml.seller_id, ml.item_id, ml.quantity, ml.price,
                   i.name, i.emoji, i.rarity, u.full_name as seller_name
            FROM market_listings ml
            JOIN items i ON i.item_id = ml.item_id
            JOIN users u ON u.user_id = ml.seller_id
            WHERE ml.status = 'active' AND ml.expires_at > ?
            ORDER BY ml.price ASC, ml.created_at ASC
            LIMIT ? OFFSET ?
        """, (now(), per_page, (page - 1) * per_page)) as cur:
            listings = await cur.fetchall()

        async with db.execute("SELECT COUNT(*) FROM market_listings WHERE status = 'active' AND expires_at > ?", (now(),)) as cur2:
            total = (await cur2.fetchone())[0]

    if not listings:
        await update.message.reply_text(
            card("🏪 Marché joueur", ["Aucune annonce active pour le moment."],
                 icon="🏪", style="thick")
        )
        return

    text = f"🏪 <b>Marché joueur</b> (page {escape_html(page)}/{escape_html(max(1, (total + per_page - 1) // per_page))})\n\n"
    for l in listings:
        text += (
            f"{escape_html(l['emoji'])} <b>{escape_html(l['name'])}</b> ({escape_html(l['rarity'])})\n"
            f"  Vendeur : {escape_html(l['seller_name'])}\n"
            f"  Quantité : {escape_html(l['quantity'])} | Prix unitaire : {escape_html(fmt(l['price']))}\n"
            f"  ID annonce : <code>{escape_html(l['listing_id'])}</code>\n\n"
        )

    keyboard = []
    if page > 1:
        keyboard.append(InlineKeyboardButton("◀️ Page précédente", callback_data=f"market_page_{page-1}"))
    if (page * per_page) < total:
        keyboard.append(InlineKeyboardButton("Page suivante ▶️", callback_data=f"market_page_{page+1}"))

    if keyboard:
        reply_markup = InlineKeyboardMarkup([keyboard])
    else:
        reply_markup = None

    await update.message.reply_text(text, parse_mode="HTML", reply_markup=reply_markup)


async def market_page_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    page = int(query.data.split("_")[-1])
    context.args = [str(page)]
    await cmd_market(update, context)
    try:
        await query.message.delete()
    except Exception:
        swallowed('handlers/market.py')


# ─────────────────────────────────────────────────────────────────────────────
# /sellitem : mettre un item en vente
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@cooldown("sell_cooldown", 10, "⏳ Attends quelques secondes avant une autre vente.")
async def cmd_sellitem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    # Marché : réservé aux commerçants. Un civil revend à un commerçant (menu Marché).
    if not await can_sell_on_market(user.id):
        from utils.cooldowns import release_cooldown
        await release_cooldown(user.id, "sell_cooldown")
        await update.effective_message.reply_text(NOT_MERCHANT_TEXT, parse_mode="HTML")
        return

    if len(context.args) < 2:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 🏪 Marché."
        )
        return

    try:
        item_id = int(context.args[0])
        price = int(context.args[1])
        quantity = int(context.args[2]) if len(context.args) > 2 else 1
        if item_id <= 0 or price <= 0 or quantity <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return

    from gameplay.market import MarketError, create_listing
    try:
        result = await create_listing(user.id, item_id, price, quantity)
    except MarketError as exc:
        await update.message.reply_text(str(exc))
        return
    lines = ["📦 Item mis en vente !", f"{result['emoji']} {result['name']}",
             f"Quantité : {quantity}", f"Prix unitaire : {fmt(result['unit_price'])}",
             f"Annonce : #{result['listing_id']}"]
    if result["cargo_bonus_pct"] > 0:
        lines.append(f"📦 Bonus cargo : +{result['cargo_bonus_pct']}%")
    await update.message.reply_text(chr(10).join(lines))
    return

    await ensure_item_exists(item_id)
    final_price, cargo_mult, cargo = await get_cargo_bonus(user.id, price)
    expires_at = now() + 7 * 86400

    try:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")

                async with db.execute(
                    "SELECT name, emoji FROM items WHERE item_id=?",
                    (item_id,),
                ) as cursor:
                    item = await cursor.fetchone()
                if not item:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Item introuvable.")

                reserve = await db.execute(
                    "UPDATE inventory SET quantity=quantity-? "
                    "WHERE user_id=? AND item_id=? AND quantity>=?",
                    (quantity, user.id, item_id, quantity),
                )
                if reserve.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Stock insuffisant.")

                await db.execute(
                    "DELETE FROM inventory WHERE user_id=? AND item_id=? AND quantity=0",
                    (user.id, item_id),
                )
                cursor = await db.execute(
                    "INSERT INTO market_listings "
                    "(seller_id,item_id,quantity,price,created_at,expires_at,status) "
                    "VALUES (?,?,?,?,?,?,'active')",
                    (user.id, item_id, quantity, final_price, now(), expires_at),
                )
                listing_id = cursor.lastrowid
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    bonus = int((cargo_mult - 1) * 100)
    lines = [
        "📦 Item mis en vente !",
        f"{item['emoji']} {item['name']}",
        f"Quantité : {quantity}",
        f"Prix unitaire : {fmt(final_price)}",
        f"Annonce : #{listing_id}",
    ]
    if bonus > 0:
        lines.append(f"📦 Bonus cargo : +{bonus}%")
    await update.message.reply_text(chr(10).join(lines))


# ─────────────────────────────────────────────────────────────────────────────
# /cancelitem : annuler une vente
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
async def cmd_cancelitem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏪 Marché.")
        return

    try:
        listing_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID invalide.")
        return

    from gameplay.market import MarketError, cancel_listing
    try:
        result = await cancel_listing(user.id, listing_id)
    except MarketError as exc:
        await update.message.reply_text(str(exc))
        return
    await update.message.reply_text(f"✅ Annonce annulée. {result['quantity_returned']} objet(s) récupéré(s).")
    return

    try:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")
                async with db.execute(
                    "SELECT ml.*, i.name FROM market_listings ml "
                    "JOIN items i ON i.item_id=ml.item_id "
                    "WHERE ml.listing_id=? AND ml.seller_id=? "
                    "AND ml.status='active'",
                    (listing_id, user.id),
                ) as cursor:
                    listing = await cursor.fetchone()
                if not listing:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Annonce introuvable ou déjà traitée.")

                claim = await db.execute(
                    "UPDATE market_listings SET status='cancelled',quantity=0 "
                    "WHERE listing_id=? AND status='active'",
                    (listing_id,),
                )
                if claim.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Annonce déjà traitée.")

                await db.execute(
                    "INSERT INTO inventory "
                    "(user_id,item_id,item_type,item_name,quantity,acquired_at) "
                    "VALUES (?,?,?,?,?,?) "
                    "ON CONFLICT(user_id,item_id) DO UPDATE SET "
                    "quantity=inventory.quantity+excluded.quantity",
                    (
                        user.id,
                        listing["item_id"],
                        "market_return",
                        listing["name"],
                        listing["quantity"],
                        now(),
                    ),
                )
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    await update.message.reply_text(
        f"✅ Annonce annulée. {listing['quantity']} objet(s) récupéré(s)."
    )


# ─────────────────────────────────────────────────────────────────────────────
# /buyitem : acheter un item (✅ Fix #4 : company_products filtré)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@cooldown("buy_cooldown", 5, "⏳ Attends quelques secondes avant un autre achat.")
async def cmd_buyitem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    buyer = update.effective_user

    if not context.args:
        await update.message.reply_text("Ouvre cette action depuis 🎮 Menu → 🏪 Marché.")
        return

    try:
        listing_id = int(context.args[0])
        quantity = int(context.args[1]) if len(context.args) > 1 else 1
        if listing_id <= 0 or quantity <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return

    from gameplay.market import MarketError, buy_listing
    try:
        result = await buy_listing(buyer.id, listing_id, quantity)
    except MarketError as exc:
        await update.message.reply_text(str(exc))
        return
    await update.message.reply_text(chr(10).join([
        "✅ Achat réussi !",
        f"{result['emoji']} {result['name']} ({result['rarity']})",
        f"Quantité : {quantity}",
        f"Prix total : {fmt(result['total'])}",
    ]))
    return

    try:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            try:
                await db.execute("BEGIN IMMEDIATE")

                async with db.execute(
                    "SELECT ml.*, i.name, i.emoji, i.rarity "
                    "FROM market_listings ml "
                    "JOIN items i ON i.item_id=ml.item_id "
                    "WHERE ml.listing_id=? AND ml.status='active' "
                    "AND ml.expires_at>?",
                    (listing_id, now()),
                ) as cursor:
                    listing = await cursor.fetchone()

                if not listing:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Annonce indisponible.")
                if listing["seller_id"] == buyer.id:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Tu ne peux pas acheter ta propre annonce.")
                if listing["quantity"] < quantity:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Quantité insuffisante dans l'annonce.")

                total = listing["price"] * quantity
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                    "WHERE user_id=? AND balance>=?",
                    (total, total, buyer.id, total),
                )
                if debit.rowcount != 1:
                    await db.rollback()
                    raise DeferredReply(update.message.reply_text, "❌ Fonds insuffisants.")

                await db.execute(
                    "UPDATE users SET balance=balance+?, total_earned=total_earned+? "
                    "WHERE user_id=?",
                    (total, total, listing["seller_id"]),
                )

                remaining = listing["quantity"] - quantity
                if remaining == 0:
                    claim = await db.execute(
                        "UPDATE market_listings SET quantity=0,status='sold' "
                        "WHERE listing_id=? AND status='active' AND quantity=?",
                        (listing_id, listing["quantity"]),
                    )
                else:
                    claim = await db.execute(
                        "UPDATE market_listings SET quantity=? "
                        "WHERE listing_id=? AND status='active' AND quantity=?",
                        (remaining, listing_id, listing["quantity"]),
                    )
                if claim.rowcount != 1:
                    raise RuntimeError("Annonce modifiée pendant l'achat")

                await db.execute(
                    "INSERT INTO inventory "
                    "(user_id,item_id,item_type,item_name,quantity,acquired_at) "
                    "VALUES (?,?,?,?,?,?) "
                    "ON CONFLICT(user_id,item_id) DO UPDATE SET "
                    "quantity=inventory.quantity+excluded.quantity",
                    (
                        buyer.id,
                        listing["item_id"],
                        "market",
                        listing["name"],
                        quantity,
                        now(),
                    ),
                )

                # ✅ FIX #4 : ne crédite QUE le produit de l'entreprise du VENDEUR
                #    Avant : WHERE name=? → pouvait créditer les produits
                #    homonymes d'autres entreprises.
                #    Après : filtre par company_id via company_members.
                try:
                    await db.execute(
                        "UPDATE company_products SET "
                        "sales=sales+?, revenue=revenue+? "
                        "WHERE name=? "
                        "AND company_id IN ("
                        "  SELECT company_id FROM company_members WHERE user_id=?"
                        ")",
                        (quantity, total, listing["name"], listing["seller_id"]),
                    )
                except aiosqlite.OperationalError as exc:
                    # Les bases minimales des tests/conversions peuvent ne pas encore
                    # disposer des tables d’entreprise optionnelles.
                    if "no such table: company_members" not in str(exc):
                        raise
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except DeferredReply as _deferred:
        return await _deferred.send()

    await add_life_journal(
        buyer.id,
        "market",
        f"Achat de {quantity}x {listing['name']} pour {fmt(total)}",
        severity="success",
    )
    lines = [
        "✅ Achat réussi !",
        f"{listing['emoji']} {listing['name']} ({listing['rarity']})",
        f"Quantité : {quantity}",
        f"Prix total : {fmt(total)}",
    ]
    await update.message.reply_text(chr(10).join(lines))
    
# ─────────────────────────────────────────────────────────────────────────────
# /useitem : utiliser un item (consommable)
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
@require_free
@cooldown("use_cooldown", 2, "⏳ Attends 2 secondes avant d'utiliser un autre item.")
async def cmd_useitem(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await get_user(user.id)

    if not context.args:
        await update.message.reply_text(
            "Ouvre cette action depuis 🎮 Menu → 🏪 Marché.\n"
            "Les items consommables ont des effets :\n"
            "• <code>heal</code> : restaure des points de santé\n"
            "• <code>energy</code> : restaure de l'énergie\n"
            "• <code>xp</code> : donne de l'XP\n"
            "• <code>money</code> : donne de l'argent\n"
            "• <code>buff</code> : boost temporaire (bonheur +, stress -)\n\n"
            "Choisis l'objet à utiliser depuis ton inventaire (Menu → 🏪 Marché → Mes objets).",
            parse_mode="HTML"
        )
        return

    try:
        item_id = int(context.args[0])
        quantity = int(context.args[1]) if len(context.args) > 1 else 1
        if quantity <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Arguments invalides.")
        return

    from gameplay.market import MarketError, use_item
    try:
        result = await use_item(user.id, item_id, quantity)
    except MarketError as exc:
        await update.message.reply_text(str(exc), parse_mode="HTML")
        return
    await update.message.reply_text(
        f"✨ <b>Utilisation de {result['emoji']} {escape_html(result['name'])}</b> (x{result['quantity_used']})\n\n"
        f"{result['effect'].get('message', '')}\n\nIl te reste {result['remaining']} exemplaire(s).",
        parse_mode="HTML",
    )
    return

    current_qty = await get_item_quantity(user.id, item_id)
    if current_qty < quantity:
        await update.message.reply_text(f"❌ Tu ne possèdes que {current_qty} exemplaire(s) de cet item.")
        return

    # S'assurer que l'item existe dans la table items
    await ensure_item_exists(item_id)

    try:
        async with db_connection() as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT name, emoji, rarity, type, effect_type, effect_value FROM items WHERE item_id = ?",
                (item_id,)
            ) as cur:
                item = await cur.fetchone()
            if not item:
                raise DeferredReply(update.message.reply_text, "❌ Item introuvable.")
    except DeferredReply as _deferred:
        return await _deferred.send()

    if item["type"] != "consumable":
        await update.message.reply_text(
            f"❌ L'item {item['emoji']} <b>{escape_html(item['name'])}</b> n'est pas consommable.",
            parse_mode="HTML"
        )
        return

    effect_type = item["effect_type"]
    effect_value = item["effect_value"] * quantity

    effect_msg = ""
    if effect_type == "heal":
        new_health = min(100, u["health"] + effect_value)
        await update_field(user.id, "health", new_health)
        effect_msg = f"❤️ Santé : {u['health']} → {new_health}"
    elif effect_type == "energy":
        new_energy = min(100, u["energy"] + effect_value)
        await update_field(user.id, "energy", new_energy)
        effect_msg = f"⚡ Énergie : {u['energy']} → {new_energy}"
    elif effect_type == "xp":
        await add_xp(user.id, effect_value)   # ✅ Fix #11
        effect_msg = f"✨ +{effect_value} XP"
    elif effect_type == "money":
        await update_balance(user.id, effect_value)
        effect_msg = f"💰 +{fmt(effect_value)} coins"
    elif effect_type == "buff":
        new_happiness = min(100, u["happiness"] + effect_value)
        new_stress = max(0, u["stress"] - effect_value // 2)
        await update_field(user.id, "happiness", new_happiness)
        await update_field(user.id, "stress", new_stress)
        effect_msg = f"✨ Buff appliqué : Bonheur +{effect_value}, Stress -{effect_value//2}"
    elif effect_type == "chain":                       # produit fini d'une entreprise (utils/chain.py)
        from utils.chain import use_chain_item
        done, parts = 0, []
        for _ in range(quantity):
            ok, msg = await use_chain_item(user.id, item["name"])
            if not ok:
                if not done:
                    await update.message.reply_text(msg, parse_mode="HTML")
                    return
                break
            done += 1
            parts = [msg]
        quantity = done
        effect_msg = "\n".join(parts)
        await add_life_journal(user.id, "item", f"Utilisation de {quantity}x {item['emoji']} {item['name']}",
                               severity="success")
        await update.message.reply_text(
            f"✨ <b>{item['emoji']} {escape_html(item['name'])}</b> utilisé (x{quantity})\n\n{effect_msg}",
            parse_mode="HTML")
        return
    else:
        await update.message.reply_text(f"❌ Effet '{effect_type}' non implémenté pour le moment.")
        return

    await remove_item(user.id, item_id, quantity)

    await add_life_journal(
        user.id, "item",
        f"Utilisation de {quantity}x {item['emoji']} {item['name']} : {effect_msg}",
        severity="success"
    )

    await update.message.reply_text(
        f"✨ <b>Utilisation de {item['emoji']} {escape_html(item['name'])}</b> (x{quantity})\n\n"
        f"{effect_msg}\n\n"
        f"Il te reste {current_qty - quantity} exemplaire(s) de cet item.",
        parse_mode="HTML"
    )


# ─────────────────────────────────────────────────────────────────────────────
# /myitems : voir ses propres annonces
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_myitems(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ml.listing_id, ml.item_id, ml.quantity, ml.price, ml.created_at, ml.expires_at,
                   i.name, i.emoji, i.rarity
            FROM market_listings ml
            JOIN items i ON i.item_id = ml.item_id
            WHERE ml.seller_id = ? AND ml.status = 'active'
            ORDER BY ml.created_at DESC
        """, (user.id,)) as cur:
            listings = await cur.fetchall()

    if not listings:
        await update.message.reply_text("📭 Tu n'as aucune annonce active.")
        return

    text = "📦 <b>Tes annonces</b>\n\n"
    for l in listings:
        expires_in = l["expires_at"] - now()
        text += (
            f"ID: <code>{l['listing_id']}</code> — {l['emoji']} <b>{escape_html(l['name'])}</b> ({l['rarity']})\n"
            f"  Quantité : {l['quantity']} | Prix unitaire : {fmt(l['price'])}\n"
            f"  Expire dans : {fmt_time(expires_in)}\n\n"
        )
    text += "Pour annuler une annonce : Menu → Marché → Mes annonces."
    await update.message.reply_text(text, parse_mode="HTML")


# ─────────────────────────────────────────────────────────────────────────────
# /cargobonus : afficher le bonus de cargo actuel
# ─────────────────────────────────────────────────────────────────────────────
@require_registered
async def cmd_cargobonus(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Affiche le bonus de cargo actuel du véhicule."""
    user = update.effective_user

    active_vehicle = await get_active_vehicle(user.id)

    if not active_vehicle:
        await update.message.reply_text(
            "🚫 <b>Aucun véhicule actif</b>\n\n"
            "Ouvre le 🎮 Menu principal pour sélectionner un véhicule actif.\n"
            "Le bonus cargo s'applique sur les ventes d'items.",
            parse_mode="HTML"
        )
        return

    veh_data = await get_vehicle_stats(active_vehicle["veh_type"])
    vehicle_cargo = active_vehicle.get("cargo", 0)

    if vehicle_cargo == 0 and veh_data.get("cargo", 0) > 0:
        vehicle_cargo = veh_data.get("cargo", 0)
        async with db_connection() as db:
            await db.execute(
                "UPDATE vehicles SET cargo = ? WHERE veh_id = ?",
                (vehicle_cargo, active_vehicle["veh_id"])
            )
            await db.commit()

    vehicle_name = active_vehicle.get("veh_type", "Véhicule")

    cargo_bonus_mult = 1 + (vehicle_cargo / 500)
    cargo_bonus_mult = min(1.20, cargo_bonus_mult)
    bonus_pct = int((cargo_bonus_mult - 1) * 100)

    if vehicle_cargo >= 80:
        level = "🏆 Maximale"
        desc = "Vous profitez du bonus maximum sur vos ventes !"
    elif vehicle_cargo >= 50:
        level = "✅ Élevée"
        desc = "Bon bonus sur vos ventes. Les missions de livraison lourdes sont accessibles."
    elif vehicle_cargo >= 30:
        level = "📦 Moyenne"
        desc = "Bonus modéré sur les ventes. Envisagez un véhicule avec plus de cargo."
    elif vehicle_cargo >= 10:
        level = "🌱 Faible"
        desc = "Bonus limité. Un véhicule avec plus de cargo augmenterait vos profits."
    else:
        level = "⚠️ Minimale"
        desc = "Presque pas de bonus. Un véhicule utilitaire serait plus rentable."

    text = (
        f"📦 <b>Bonus de Cargo</b>\n\n"
        f"🚗 Véhicule : <b>{escape_html(vehicle_name)}</b>\n"
        f"📦 Cargo : <b>{vehicle_cargo}/100</b>\n"
        f"📊 Niveau : {level}\n"
        f"💰 Bonus sur les ventes : <b>+{bonus_pct}%</b>\n"
        f"📈 Multiplicateur : <b>x{cargo_bonus_mult:.2f}</b>\n\n"
        f"_{desc}_\n\n"
        f"💡 Les véhicules avec un cargo élevé augmentent vos profits lors des ventes sur le marché."
    )
    await update.message.reply_text(text, parse_mode="HTML")


# ─────────────────────────────────────────────────────────────────────────────
# Maintenance : nettoyer les annonces expirées
# ─────────────────────────────────────────────────────────────────────────────
async def clean_expired_listings():
    """Rend aux vendeurs les annonces expirées. Réessaie en cas de « database is locked »
    (sinon les annonces expirent en retard jusqu'au prochain passage du scheduler)."""
    from utils.simulation import _execute_with_retry
    await _execute_with_retry(_clean_expired_listings_once)


async def _clean_expired_listings_once():
    current = now()
    async with db_connection(row_factory=aiosqlite.Row) as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT ml.*, i.name FROM market_listings ml "
                "JOIN items i ON i.item_id=ml.item_id "
                "WHERE ml.status='active' AND ml.expires_at<=?",
                (current,),
            ) as cursor:
                listings = await cursor.fetchall()

            for listing in listings:
                claim = await db.execute(
                    "UPDATE market_listings SET status='expired',quantity=0 "
                    "WHERE listing_id=? AND status='active'",
                    (listing["listing_id"],),
                )
                if claim.rowcount != 1:
                    continue
                await db.execute(
                    "INSERT INTO inventory "
                    "(user_id,item_id,item_type,item_name,quantity,acquired_at) "
                    "VALUES (?,?,?,?,?,?) "
                    "ON CONFLICT(user_id,item_id) DO UPDATE SET "
                    "quantity=inventory.quantity+excluded.quantity",
                    (
                        listing["seller_id"],
                        listing["item_id"],
                        "market_return",
                        listing["name"],
                        listing["quantity"],
                        current,
                    ),
                )
            await db.commit()
        except Exception:
            await db.rollback()
            raise


# ═══════════════════════════════════════════════════════════════════
#              🛒 MENU INTERACTIF DU MARCHÉ JOUEUR
# ═══════════════════════════════════════════════════════════════════



async def show_market_browse(query, user_id: int, page: int = 1):
    per_page = 5
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ml.listing_id, ml.seller_id, ml.item_id, ml.quantity, ml.price,
                   i.name, i.emoji, i.rarity, u.full_name as seller_name
            FROM market_listings ml
            JOIN items i ON i.item_id = ml.item_id
            JOIN users u ON u.user_id = ml.seller_id
            WHERE ml.status = 'active' AND ml.expires_at > ?
            ORDER BY ml.price ASC, ml.created_at ASC
            LIMIT ? OFFSET ?
        """, (now(), per_page, (page - 1) * per_page)) as cur:
            listings = await cur.fetchall()
        async with db.execute(
            "SELECT COUNT(*) FROM market_listings WHERE status='active' AND expires_at > ?",
            (now(),)
        ) as cur:
            total = (await cur.fetchone())[0] or 0

    if not listings:
        await safe_edit(
            query,
            "🏪 <b>Marché vide</b>\n\nAucune annonce active pour le moment.\n"
            "<i>Sois le premier à vendre quelque chose !</i>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")]])
        )
        return

    total_pages = max(1, (total + per_page - 1) // per_page)
    body = [f"Page <b>{page}/{total_pages}</b>", ""]

    keyboard = []
    for l in listings:
        body.append(
            f"{l['emoji']} <b>{escape_html(l['name'])}</b> ({l['rarity']})\n"
            f"   💰 {fmt(l['price'])} · 📦 ×{l['quantity']}\n"
            f"   👤 {escape_html(l['seller_name'])}"
        )
        keyboard.append([
            InlineKeyboardButton(
                f"🛒 Acheter {l['emoji']} {l['name'][:15]} ({fmt(l['price'])})",
                callback_data=f"market_buy_{l['listing_id']}"
            )
        ])

    nav = []
    if page > 1:
        nav.append(InlineKeyboardButton("◀️", callback_data=f"market_page_{page-1}"))
    if page < total_pages:
        nav.append(InlineKeyboardButton("▶️", callback_data=f"market_page_{page+1}"))
    if nav:
        keyboard.append(nav)

    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")])

    await safe_edit(
        query,
        "🏪 <b>MARCHÉ JOUEUR</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def show_market_mine(query, user_id: int):
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ml.listing_id, ml.item_id, ml.quantity, ml.price, ml.expires_at,
                   i.name, i.emoji, i.rarity
            FROM market_listings ml
            JOIN items i ON i.item_id = ml.item_id
            WHERE ml.seller_id = ? AND ml.status = 'active'
            ORDER BY ml.created_at DESC
        """, (user_id,)) as cur:
            listings = await cur.fetchall()

    if not listings:
        await safe_edit(
            query,
            "📭 Tu n'as aucune annonce active.\n\n"
            "<i>Utilise <b>💸 Mettre en vente</b> pour publier une annonce.</i>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")]])
        )
        return

    body = []
    keyboard = []
    for l in listings:
        remaining = l["expires_at"] - now()
        body.append(
            f"{l['emoji']} <b>{escape_html(l['name'])}</b> ({l['rarity']})\n"
            f"   💰 {fmt(l['price'])} · 📦 ×{l['quantity']}\n"
            f"   ⏳ Expire dans {fmt_time(remaining)}"
        )
        keyboard.append([
            InlineKeyboardButton(
                f"❌ Annuler {l['emoji']} {l['name'][:15]}",
                callback_data=f"market_cancel_{l['listing_id']}"
            )
        ])

    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")])

    await safe_edit(
        query,
        "📦 <b>MES ANNONCES</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def show_market_sell_info(query, user_id: int):
    """Choix guidé de l'objet à vendre (remplace le menu)."""
    if not await can_sell_on_market(user_id):
        await safe_edit(query, NOT_MERCHANT_TEXT, reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")]]))
        return
    from handlers.market_flows import show_sell_picker
    await show_sell_picker(query, user_id)


async def show_market_use_list(query, user_id: int, page: int = 1):
    per_page = 5
    items = await get_inventory(user_id)

    # Filtrer les consommables uniquement
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        consumables = []
        for i in items:
            item_id = i.get("item_id")
            if not item_id:
                continue
            async with db.execute(
                "SELECT item_id, name, emoji, rarity, type, effect_type, effect_value FROM items WHERE item_id=?",
                (item_id,)
            ) as cur:
                def_item = await cur.fetchone()
            if def_item and def_item["type"] == "consumable":
                consumables.append(dict(def_item) | {"quantity": i["quantity"]})

    if not consumables:
        await safe_edit(
            query,
            "🎒 Tu n'as aucun consommable utilisable.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")]])
        )
        return

    total = len(consumables)
    total_pages = max(1, (total + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start = (page - 1) * per_page
    page_items = consumables[start:start + per_page]

    body = [f"Page <b>{page}/{total_pages}</b>", ""]
    keyboard = []
    for it in page_items:
        body.append(
            f"{it['emoji']} <b>{escape_html(it['name'])}</b> ({it['rarity']})\n"
            f"   📦 ×{it['quantity']} · effet <b>{it['effect_type']}</b> ({it['effect_value']})"
        )
        keyboard.append([
            InlineKeyboardButton(
                f"✨ Utiliser {it['emoji']} {it['name'][:15]}",
                callback_data=f"market_use_{it['item_id']}"
            )
        ])

    nav = []
    if page > 1:
        nav.append(InlineKeyboardButton("◀️", callback_data=f"market_use_page_{page-1}"))
    if page < total_pages:
        nav.append(InlineKeyboardButton("▶️", callback_data=f"market_use_page_{page+1}"))
    if nav:
        keyboard.append(nav)

    keyboard.append([InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")])

    await safe_edit(
        query,
        "🎒 <b>UTILISER UN ITEM</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        + "\n".join(body),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def do_market_buy_from_callback(query, user_id: int, listing_id: int):
    """Achète 1 unité d'une annonce, depuis un bouton."""
    from gameplay.market import MarketError, buy_listing
    try:
        result = await buy_listing(user_id, listing_id, 1)
    except MarketError as exc:
        await safe_edit(query, str(exc))
        return
    await safe_edit(query, f"✅ <b>Achat réussi !</b>\n\n{escape_html(result['emoji'])} <b>{escape_html(result['name'])}</b> ({escape_html(result['rarity'])})\n💰 Prix : <b>{fmt(result['total'])}</b>", parse_mode="HTML", reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton("🏪 Retour au marché", callback_data="market_browse")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")],
    ]))
    return

    async with db_connection(row_factory=aiosqlite.Row) as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT ml.*, i.name, i.emoji, i.rarity FROM market_listings ml "
                "JOIN items i ON i.item_id=ml.item_id "
                "WHERE ml.listing_id=? AND ml.status='active' AND ml.expires_at>?",
                (listing_id, now())
            ) as cur:
                listing = await cur.fetchone()
            if not listing:
                await db.rollback()
                await safe_edit(query, "❌ Annonce indisponible.")
                return
            if listing["seller_id"] == user_id:
                await db.rollback()
                await safe_edit(query, "❌ Tu ne peux pas acheter ta propre annonce.")
                return
            if listing["quantity"] < 1:
                await db.rollback()
                await safe_edit(query, "❌ Plus en stock.")
                return

            total = listing["price"]
            debit = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                "WHERE user_id=? AND balance>=?",
                (total, total, user_id, total)
            )
            if debit.rowcount != 1:
                await db.rollback()
                await safe_edit(query, "❌ Fonds insuffisants.")
                return

            await db.execute(
                "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                (total, total, listing["seller_id"])
            )

            remaining = listing["quantity"] - 1
            if remaining == 0:
                await db.execute(
                    "UPDATE market_listings SET quantity=0, status='sold' WHERE listing_id=?",
                    (listing_id,)
                )
            else:
                await db.execute(
                    "UPDATE market_listings SET quantity=? WHERE listing_id=?",
                    (remaining, listing_id)
                )

            await db.execute(
                "INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at) "
                "VALUES (?,?,?,?,1,?) "
                "ON CONFLICT(user_id,item_id) DO UPDATE SET quantity=quantity+1",
                (user_id, listing["item_id"], "market", listing["name"], now())
            )

            # ✅ FIX #4 : filtre company_id (idem cmd_buyitem)
            await db.execute(
                "UPDATE company_products SET sales=sales+1, revenue=revenue+? "
                "WHERE name=? "
                "AND company_id IN (SELECT company_id FROM company_members WHERE user_id=?)",
                (total, listing["name"], listing["seller_id"])
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise

    await safe_edit(
        query,
        f"✅ <b>Achat réussi !</b>\n\n"
        f"{listing['emoji']} <b>{escape_html(listing['name'])}</b> ({listing['rarity']})\n"
        f"💰 Prix : <b>{fmt(total)}</b>\n"
        f"📦 Quantité : <b>1</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🏪 Retour au marché", callback_data="market_browse")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")],
        ])
    )


async def do_market_cancel_from_callback(query, user_id: int, listing_id: int):
    from gameplay.market import MarketError, cancel_listing
    try:
        result = await cancel_listing(user_id, listing_id)
    except MarketError as exc:
        await safe_edit(query, str(exc))
        return
    await safe_edit(query, f"✅ Annonce annulée. {result['quantity_returned']} objet(s) récupéré(s).", parse_mode="HTML", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Mes annonces", callback_data="market_mine")]]))
    return

    async with db_connection(row_factory=aiosqlite.Row) as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT ml.*, i.name FROM market_listings ml "
                "JOIN items i ON i.item_id=ml.item_id "
                "WHERE ml.listing_id=? AND ml.seller_id=? AND ml.status='active'",
                (listing_id, user_id)
            ) as cur:
                listing = await cur.fetchone()
            if not listing:
                await db.rollback()
                await safe_edit(query, "❌ Annonce introuvable.")
                return

            await db.execute(
                "UPDATE market_listings SET status='cancelled', quantity=0 WHERE listing_id=?",
                (listing_id,)
            )
            await db.execute(
                "INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at) "
                "VALUES (?,?,?,?,?,?) "
                "ON CONFLICT(user_id,item_id) DO UPDATE SET quantity=quantity+excluded.quantity",
                (user_id, listing["item_id"], "market_return", listing["name"], listing["quantity"], now())
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise

    await safe_edit(
        query,
        f"✅ Annonce annulée. {listing['quantity']} objet(s) récupéré(s).",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Mes annonces", callback_data="market_mine")]])
    )


async def do_market_use_from_callback(query, user_id: int, item_id: int):
    """Utilise 1 exemplaire d'un item depuis un bouton."""
    from gameplay.market import MarketError, use_item
    try:
        result = await use_item(user_id, item_id, 1)
    except MarketError as exc:
        await safe_edit(query, str(exc))
        return
    await safe_edit(query, f"✨ <b>{escape_html(result['emoji'])} {escape_html(result['name'])} utilisé !</b>\n\n{escape_html(result['effect'].get('message', ''))}", parse_mode="HTML", reply_markup=InlineKeyboardMarkup([
        [InlineKeyboardButton("🎒 Utiliser un autre", callback_data="market_use_list")],
        [InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")],
    ]))
    return

    await ensure_item_exists(item_id)

    current_qty = await get_item_quantity(user_id, item_id)
    if current_qty < 1:
        await safe_edit(query, "❌ Tu n'as plus cet item.")
        return

    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT name, emoji, effect_type, effect_value, type FROM items WHERE item_id=?",
            (item_id,)
        ) as cur:
            item = await cur.fetchone()
        if not item:
            await safe_edit(query, "❌ Item introuvable.")
            return

    if item["type"] != "consumable":
        await safe_edit(query, f"❌ {item['name']} n'est pas consommable.")
        return

    u = await get_user(user_id)
    effect_type = item["effect_type"]
    effect_value = item["effect_value"]

    effect_msg = ""
    if effect_type == "heal":
        new_health = min(100, u["health"] + effect_value)
        await update_field(user_id, "health", new_health)
        effect_msg = f"❤️ Santé : {u['health']}% → {new_health}%"
    elif effect_type == "energy":
        new_energy = min(100, u["energy"] + effect_value)
        await update_field(user_id, "energy", new_energy)
        effect_msg = f"⚡ Énergie : {u['energy']}% → {new_energy}%"
    elif effect_type == "xp":
        await add_xp(user_id, effect_value)   # ✅ Fix #11
        effect_msg = f"✨ +{effect_value} XP"
    elif effect_type == "money":
        await update_balance(user_id, effect_value)
        effect_msg = f"💰 +{fmt(effect_value)}"
    elif effect_type == "buff":
        new_happiness = min(100, u["happiness"] + effect_value)
        new_stress = max(0, u["stress"] - effect_value // 2)
        await update_field(user_id, "happiness", new_happiness)
        await update_field(user_id, "stress", new_stress)
        effect_msg = f"✨ Bonheur +{effect_value}, Stress -{effect_value//2}"
    elif effect_type == "chain":                       # produit fini d'une entreprise (utils/chain.py)
        from utils.chain import use_chain_item
        ok, msg = await use_chain_item(user_id, item["name"])
        if not ok:
            await safe_edit(query, msg, parse_mode="HTML", reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")]]))
            return
        await safe_edit(
            query, f"✨ <b>{item['emoji']} {escape_html(item['name'])} utilisé !</b>\n\n{msg}",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎒 Utiliser un autre", callback_data="market_use_list")],
                [InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")]]))
        return
    else:
        await safe_edit(query, f"❌ Effet '{effect_type}' non supporté.")
        return

    await remove_item(user_id, item_id, 1)

    await safe_edit(
        query,
        f"✨ <b>{item['emoji']} {escape_html(item['name'])} utilisé !</b>\n\n"
        f"{effect_msg}\n\n"
        f"Il te reste {current_qty - 1} exemplaire(s).",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🎒 Utiliser un autre", callback_data="market_use_list")],
            [InlineKeyboardButton("⬅️ Retour", callback_data="market_menu")],
        ])
    )


async def market_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Routeur des callbacks 'market_'."""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data = query.data

    if data == "market_menu":
        from handlers.hub import open_zone; await open_zone(query, "market")
        return
    if data == "market_browse":
        await show_market_browse(query, user_id, 1)
        return
    if data.startswith("market_page_"):
        try:
            page = int(data.replace("market_page_", ""))
        except ValueError:
            return
        await show_market_browse(query, user_id, page)
        return
    if data == "market_mine":
        await show_market_mine(query, user_id)
        return
    if data == "market_sell_info":
        await show_market_sell_info(query, user_id)
        return
    if data == "market_use_list":
        await show_market_use_list(query, user_id, 1)
        return
    if data.startswith("market_use_page_"):
        try:
            page = int(data.replace("market_use_page_", ""))
        except ValueError:
            return
        await show_market_use_list(query, user_id, page)
        return
    if data.startswith("market_buy_"):
        try:
            lid = int(data.replace("market_buy_", ""))
        except ValueError:
            return
        await do_market_buy_from_callback(query, user_id, lid)
        return
    if data.startswith("market_cancel_"):
        try:
            lid = int(data.replace("market_cancel_", ""))
        except ValueError:
            return
        await do_market_cancel_from_callback(query, user_id, lid)
        return
    if data.startswith("market_sellpick_"):
        try:
            iid = int(data.replace("market_sellpick_", ""))
        except ValueError:
            return
        from handlers.market_flows import start_sell
        await start_sell(query, context, iid)
        return
    if data.startswith("market_use_"):
        try:
            iid = int(data.replace("market_use_", ""))
        except ValueError:
            return
        await do_market_use_from_callback(query, user_id, iid)
        return


# ══════════════════════════════════════════════════════════════════════
#  MARCHÉ DES COMMERÇANTS — revente civil → commerçant (ex handlers/merchants.py)
# ══════════════════════════════════════════════════════════════════════
import logging
from database import db_connection, get_user, now
from utils.decorators import get_user_role_async
from utils.helpers import parse_amount
from utils.notify import notify
from utils.helpers import safe_edit

logger = logging.getLogger(__name__)


MERCHANT_JOB = "Commerçant"
OFFER_TTL = 24 * 3600
NOT_MERCHANT_TEXT = (
    "🛍️ Seuls les <b>commerçants</b> peuvent vendre sur le marché.\n"
    "• Deviens commerçant : menu Métiers\n"
    "• Ou revends ton objet à un commerçant : Marché → « Vendre à un commerçant »"
)


async def is_merchant(user_id: int) -> bool:
    return ((await get_user(user_id)).get("job") or "") == MERCHANT_JOB


async def can_sell_on_market(user_id: int) -> bool:
    """Seuls les commerçants peuvent mettre en vente : personne d'autre (staff compris)."""
    return (await get_user(user_id)).get("job", "") == MERCHANT_JOB


@require_registered
@require_free
async def cmd_vendre_commercant(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    msg = update.message
    usage = "Utilise le bouton Marché → « Vendre à un commerçant »."
    from handlers.multiplayer import _resolve_target
    target = await _resolve_target(update, context)
    args = context.args if msg.reply_to_message else context.args[1:]
    if not target or len(args) < 2:
        await msg.reply_text(usage)
        return
    try:
        item_id = int(args[0])
        price = parse_amount(args[1])
        qty = int(args[2]) if len(args) > 2 else 1
        if item_id <= 0 or not price or price <= 0 or qty <= 0:
            raise ValueError
    except ValueError:
        await msg.reply_text("❌ Arguments invalides.\n" + usage)
        return
    if target.id == user.id:
        await msg.reply_text("❌ Tu ne peux pas te vendre un objet à toi-même.")
        return
    if not await is_merchant(target.id):
        await msg.reply_text("❌ Cette personne n'est pas commerçante : seuls les commerçants achètent aux civils.")
        return

    await ensure_item_exists(item_id)
    try:
        async with db_connection(row_factory=aiosqlite.Row) as db:
            await db.execute("BEGIN IMMEDIATE")
            try:
                async with db.execute("SELECT name, emoji FROM items WHERE item_id=?", (item_id,)) as c:
                    item = await c.fetchone()
                reserve = await db.execute(
                    "UPDATE inventory SET quantity=quantity-? WHERE user_id=? AND item_id=? AND quantity>=?",
                    (qty, user.id, item_id, qty))
                if reserve.rowcount != 1:
                    await db.rollback()
                    await msg.reply_text("❌ Stock insuffisant.")
                    return
                await db.execute("DELETE FROM inventory WHERE user_id=? AND item_id=? AND quantity=0",
                                 (user.id, item_id))
                cur = await db.execute(
                    "INSERT INTO merchant_offers(seller_id,merchant_id,item_id,quantity,unit_price,status,"
                    "created_at,expires_at) VALUES (?,?,?,?,?,'pending',?,?)",
                    (user.id, target.id, item_id, qty, price, now(), now() + OFFER_TTL))
                offer_id = cur.lastrowid
                await db.commit()
            except Exception:
                await db.rollback()
                raise
    except Exception:
        logger.exception("Offre commerçant impossible")
        await msg.reply_text("❌ Impossible de créer l'offre.")
        return

    label = f"{item['emoji']} {item['name']}" if item else f"Objet #{item_id}"
    total = price * qty
    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton(f"✅ Acheter (-{fmt(total)})", callback_data=f"mvente_accept_{offer_id}"),
        InlineKeyboardButton("❌ Refuser", callback_data=f"mvente_decline_{offer_id}"),
    ]])
    text = (f"🛍️ <b>Offre #{offer_id}</b> de {user.full_name}\n{label} ×{qty}\n"
            f"💰 {fmt(price)} l'unité · total <b>{fmt(total)}</b>\n<i>Valable 24 h.</i>")
    try:
        await context.bot.send_message(target.id, text, parse_mode="HTML", reply_markup=kb)
    except Exception:
        await notify(target.id, "🛍️ Offre d'un civil",
                     f"{user.full_name} te propose {label} ×{qty} pour {fmt(total)}. 👉 Marché → Offres de civils", "info")
    await msg.reply_text(f"📨 Offre #{offer_id} envoyée : {label} ×{qty} à {fmt(price)}/u. "
                         f"L'objet est mis de côté jusqu'à la réponse (24 h max).")


@require_registered
async def cmd_offres(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """le menu : offres de civils en attente (commerçant) ou mes offres envoyées."""
    uid = update.effective_user.id
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT o.*, COALESCE(i.name,'Objet') AS name FROM merchant_offers o "
                "LEFT JOIN items i ON i.item_id=o.item_id "
                "WHERE o.status='pending' AND (o.merchant_id=? OR o.seller_id=?) ORDER BY o.offer_id LIMIT 15",
                (uid, uid)) as cur:
            rows = await cur.fetchall()
    if not rows:
        await update.message.reply_text("Aucune offre en attente.")
        return
    for r in rows:
        mine = r["merchant_id"] == uid
        text = (f"🛍️ Offre #{r['offer_id']} — {r['name']} ×{r['quantity']} à {fmt(r['unit_price'])}/u "
                f"(total {fmt(r['unit_price'] * r['quantity'])})")
        kb = None
        if mine:
            kb = InlineKeyboardMarkup([[
                InlineKeyboardButton("✅ Acheter", callback_data=f"mvente_accept_{r['offer_id']}"),
                InlineKeyboardButton("❌ Refuser", callback_data=f"mvente_decline_{r['offer_id']}")]])
        else:
            text += " · en attente du commerçant"
        await update.message.reply_text(text, reply_markup=kb)


async def _return_items(db, offer: dict) -> None:
    async with db.execute("SELECT name FROM items WHERE item_id=?", (offer["item_id"],)) as c:
        row = await c.fetchone()
    name = row[0] if row else f"Item #{offer['item_id']}"
    await db.execute(
        "INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at) "
        "VALUES (?,?,?,?,?,?) ON CONFLICT(user_id, item_id) DO UPDATE SET "
        "quantity = inventory.quantity + excluded.quantity",
        (offer["seller_id"], offer["item_id"], "market", name, offer["quantity"], now()))


async def resolve_offer(offer_id: int, merchant_id: int, accept: bool) -> tuple[bool, str]:
    """Le commerçant accepte ou refuse. Retourne (succès, message pour le commerçant)."""
    notes: list[tuple[int, str, str, str]] = []
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                    "SELECT o.*, COALESCE(i.name,'Objet') AS name FROM merchant_offers o "
                    "LEFT JOIN items i ON i.item_id=o.item_id WHERE o.offer_id=?", (offer_id,)) as cur:
                o = await cur.fetchone()
            if not o or o["merchant_id"] != merchant_id:
                await db.rollback()
                return False, "❌ Offre introuvable."
            if o["status"] != "pending" or o["expires_at"] <= now():
                await db.rollback()
                return False, "⌛ Cette offre n'est plus valable."
            offer = dict(o)
            total = offer["unit_price"] * offer["quantity"]
            label = f"{offer['name']} ×{offer['quantity']}"
            if accept:
                debit = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                    "WHERE user_id=? AND balance>=?", (total, total, merchant_id, total))
                if debit.rowcount != 1:
                    await db.rollback()
                    return False, f"❌ Fonds insuffisants : il te faut {fmt(total)}."
                await db.execute("UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                                 (total, total, offer["seller_id"]))
                await db.execute(
                    "INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at) "
                    "VALUES (?,?,?,?,?,?) ON CONFLICT(user_id, item_id) DO UPDATE SET "
                    "quantity = inventory.quantity + excluded.quantity",
                    (merchant_id, offer["item_id"], "market", offer["name"], offer["quantity"], now()))
                await db.execute("UPDATE merchant_offers SET status='accepted' WHERE offer_id=?", (offer_id,))
                notes.append((offer["seller_id"], "🛍️ Vente conclue",
                              f"Le commerçant t'achète {label} : <b>+{fmt(total)}</b>", "economy"))
                msg = f"✅ Acheté : {label} pour {fmt(total)}."
            else:
                await _return_items(db, offer)
                await db.execute("UPDATE merchant_offers SET status='declined' WHERE offer_id=?", (offer_id,))
                notes.append((offer["seller_id"], "🛍️ Offre refusée",
                              f"Le commerçant refuse {label}. L'objet t'est rendu.", "warning"))
                msg = "❌ Offre refusée, l'objet retourne au vendeur."
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    for uid, title, body, kind in notes:
        await notify(uid, title, body, kind)
    return True, msg


async def merchant_offer_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "mvente_list":
        from utils.input_flow import call_cmd
        await call_cmd(q, context, cmd_offres, [])
        return
    try:
        _, action, oid = (q.data or "").split("_")
        offer_id = int(oid)
    except ValueError:
        return
    ok, msg = await resolve_offer(offer_id, q.from_user.id, action == "accept")
    try:
        await q.edit_message_text(msg)
    except Exception:
        swallowed('handlers/market.py')


async def expire_merchant_offers() -> None:
    """Tâche planifiée : les offres sans réponse après 24 h rendent l'objet au vendeur (notifié)."""
    notes = []
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                    "SELECT * FROM merchant_offers WHERE status='pending' AND expires_at<=?", (now(),)) as cur:
                rows = [dict(r) for r in await cur.fetchall()]
            for o in rows:
                await _return_items(db, o)
                await db.execute("UPDATE merchant_offers SET status='expired' WHERE offer_id=?", (o["offer_id"],))
                notes.append((o["seller_id"], "⏰ Offre expirée",
                              f"Le commerçant n'a pas répondu à l'offre #{o['offer_id']} : ton objet est de retour "
                              f"dans ton inventaire.", "warning"))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    for uid, title, body, kind in notes:
        await notify(uid, title, body, kind)


# Compatibilité : les anciens écrans qui importent ces primitives utilisent désormais
# le même service que les routes Web.
from gameplay.market import (
    get_item_quantity as _shared_get_item_quantity,
    remove_item as _shared_remove_item,
    add_item as _shared_add_item,
    ensure_item_exists as _shared_ensure_item_exists,
)
get_item_quantity = _shared_get_item_quantity
remove_item = _shared_remove_item
add_item = _shared_add_item
ensure_item_exists = _shared_ensure_item_exists
