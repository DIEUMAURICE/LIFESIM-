from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from config import SMALL_JOBS
from gameplay import work


@pytest.mark.asyncio
async def test_prepare_reserves_the_same_work_contract(monkeypatch):
    job_name, job = next(iter(SMALL_JOBS.items()))
    user = {"job": job_name, "energy": 100, "hunger": 100, "health": 100, "diplome": ""}
    monkeypatch.setattr(work, "get_user", AsyncMock(return_value=user))
    monkeypatch.setattr(work, "get_job_progress", AsyncMock(return_value={"rank": 0, "missions": 0}))
    monkeypatch.setattr(work, "get_user_role_async", AsyncMock(return_value="PLAYER"))
    monkeypatch.setattr(work, "is_exempt", AsyncMock(return_value=False))
    monkeypatch.setattr(work, "presence_error", AsyncMock(return_value=None))
    claimed = AsyncMock(return_value=(True, 0))
    monkeypatch.setattr(work, "claim_cooldown", claimed)
    monkeypatch.setattr(work.random, "randint", lambda *_args: job["min"])

    preparation = await work.prepare(42)

    assert preparation.user_id == 42
    assert preparation.job_name == job_name
    assert preparation.big is False
    assert preparation.base_gain == job["min"]
    claimed.assert_awaited_once_with(42, work.KEY, preparation.cooldown_seconds)


@pytest.mark.asyncio
async def test_resolve_applies_gain_xp_energy_goods_and_notification_once(monkeypatch):
    preparation = work.WorkPreparation(
        user_id=42,
        job_name="Livreur",
        rank=0,
        big=False,
        base_gain=100,
        cooldown_seconds=3600,
    )
    monkeypatch.setattr(work, "faucet", AsyncMock(return_value=150))
    balance = AsyncMock()
    xp = AsyncMock()
    mission = AsyncMock()
    field = AsyncMock()
    monkeypatch.setattr(work, "update_balance", balance)
    monkeypatch.setattr(work, "add_xp", xp)
    monkeypatch.setattr(work, "update_mission_progress", mission)
    monkeypatch.setattr(work, "update_field", field)
    monkeypatch.setattr(work, "get_user", AsyncMock(return_value={"energy": 80}))
    monkeypatch.setattr(work, "record_mission", AsyncMock(return_value={"good": None, "units": 0}))
    monkeypatch.setattr(work, "promotion_status", AsyncMock(return_value={"next": None, "ok": False}))
    notify = AsyncMock()
    monkeypatch.setattr(work, "notify", notify)
    monkeypatch.setattr(work.random, "randint", lambda *_args: 25)

    result = await work.resolve(preparation, score=3)

    assert result["gain"] == 150
    assert result["xp"] == 60
    assert result["energy_cost"] == 25
    assert result["energy_left"] == 55
    balance.assert_awaited_once_with(42, 150)
    xp.assert_awaited_once_with(42, 60)
    mission.assert_awaited_once_with(42, "work", 1)
    notify.assert_awaited_once_with(
        42,
        "🛠️ Mission freelance",
        "Ton repos est terminé : tu peux reprendre une mission de Livreur.",
        "info",
        delay=3600,
    )


@pytest.mark.asyncio
async def test_prepare_rejects_active_cooldown_before_any_reward(monkeypatch):
    job_name, _job = next(iter(SMALL_JOBS.items()))
    monkeypatch.setattr(
        work,
        "get_user",
        AsyncMock(return_value={"job": job_name, "energy": 100, "hunger": 100, "health": 100}),
    )
    monkeypatch.setattr(work, "get_job_progress", AsyncMock(return_value={"rank": 0, "missions": 0}))
    monkeypatch.setattr(work, "get_user_role_async", AsyncMock(return_value="ADMIN_N1"))
    monkeypatch.setattr(work, "is_exempt", AsyncMock(return_value=True))
    monkeypatch.setattr(work, "presence_error", AsyncMock(return_value=None))
    monkeypatch.setattr(work, "claim_cooldown", AsyncMock(return_value=(False, 123)))

    # Le staff exempté ne consomme pas le registre de cooldown.
    result = await work.prepare(42)
    assert result.user_id == 42

    monkeypatch.setattr(work, "get_user_role_async", AsyncMock(return_value="PLAYER"))
    monkeypatch.setattr(work, "claim_cooldown", AsyncMock(return_value=(False, 123)))
    monkeypatch.setattr(work, "is_exempt", AsyncMock(return_value=False))
    with pytest.raises(work.WorkError, match="fatigué"):
        await work.prepare(42)
