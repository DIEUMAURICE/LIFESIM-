# test/test_input_flow.py — saisie guidée par boutons
from types import SimpleNamespace

import pytest
from telegram.ext import ApplicationHandlerStop

from utils import input_flow as f

got: list = []


@f.flow("t_amt")
async def _amt(update, context, value, data):
    got.append(("amt", value, data))


@f.flow("t_user")
async def _usr(update, context, value, data):
    got.append(("user", value, data))


class _Msg:
    def __init__(self, text):
        self.text, self.sent = text, []

    async def reply_text(self, t, **kw):
        self.sent.append(t)


def _update(text):
    return SimpleNamespace(effective_message=_Msg(text), effective_user=SimpleNamespace(id=1))


def _query():
    async def edit(*a, **k):
        pass
    return SimpleNamespace(edit_message_text=edit)


async def _seed(isolated_db):
    import database
    async with database.db_connection() as db:
        await db.execute("INSERT INTO users(user_id, username, full_name) VALUES (111,'Alice','Alice A')")
        await db.execute("INSERT INTO users(user_id, username, full_name) VALUES (222,'bob_77','Bob')")
        await db.commit()


@pytest.mark.asyncio
async def test_resolve_user_pseudo_arobase_et_id(isolated_db):
    await _seed(isolated_db)
    assert await f.resolve_user("@alice") == (111, "Alice A")
    assert await f.resolve_user("bob_77") == (222, "Bob")
    assert await f.resolve_user("111") == (111, "Alice A")
    assert await f.resolve_user("@inconnu") is None
    assert await f.resolve_user("") is None


@pytest.mark.asyncio
async def test_montant_raccourcis_et_bornes():
    ctx = SimpleNamespace(user_data={})
    await f.ask(_query(), ctx, "t_amt", "?", kind="amount", min_value=1, balance=1000, data={"k": 1})
    with pytest.raises(ApplicationHandlerStop):
        await f.flow_message_handler(_update("50%"), ctx)
    assert got[-1] == ("amt", 500, {"k": 1})
    assert f.FLOW_KEY not in ctx.user_data


@pytest.mark.asyncio
async def test_saisie_invalide_conserve_le_flux():
    ctx = SimpleNamespace(user_data={})
    await f.ask(_query(), ctx, "t_amt", "?", kind="amount", min_value=1)
    upd = _update("abc")
    with pytest.raises(ApplicationHandlerStop):
        await f.flow_message_handler(upd, ctx)
    assert "invalide" in upd.effective_message.sent[0]
    assert f.FLOW_KEY in ctx.user_data


@pytest.mark.asyncio
async def test_expiration():
    ctx = SimpleNamespace(user_data={})
    await f.ask(_query(), ctx, "t_amt", "?", kind="int")
    ctx.user_data[f.FLOW_KEY].expires = 0
    upd = _update("5")
    with pytest.raises(ApplicationHandlerStop):
        await f.flow_message_handler(upd, ctx)
    assert "expirée" in upd.effective_message.sent[0]
    assert f.FLOW_KEY not in ctx.user_data


@pytest.mark.asyncio
async def test_sans_flux_le_message_passe():
    await f.flow_message_handler(_update("salut"), SimpleNamespace(user_data={}))  # pas d'exception


@pytest.mark.asyncio
async def test_flux_inconnu():
    with pytest.raises(KeyError):
        await f.ask(_query(), SimpleNamespace(user_data={}), "nope", "?")
