# test/test_concurrency.py
# test/test_concurrency.py
import asyncio
from types import SimpleNamespace

import aiosqlite
import pytest

# Import robuste : essaie `test.conftest` puis fallback direct `conftest`.
try:
    from test.conftest import (
        FakeUpdate,
        fetch_one,
        fetch_value,
        insert_user,
        unwrap_handler,
    )
except ImportError:  # pragma: no cover — filet de sécurité
    from conftest import (  # type: ignore
        FakeUpdate,
        fetch_one,
        fetch_value,
        insert_user,
        unwrap_handler,
    )

@pytest.mark.asyncio
async def test_atomic_cooldown_allows_only_one(isolated_db):
    from utils.cooldowns import claim_cooldown

    results = await asyncio.gather(
        *(
            claim_cooldown(1, "daily_reward", 3600)
            for _ in range(20)
        )
    )

    allowed = [result for result in results if result[0]]
    blocked = [result for result in results if not result[0]]
    assert len(allowed) == 1
    assert len(blocked) == 19
    assert all(remaining > 0 for _, remaining in blocked)


@pytest.mark.asyncio
async def test_arena_accept_double_click_debits_once(isolated_db):
    from utils.arena_store import accept_and_fund_match, create_match

    await insert_user(isolated_db, 1, 1_000, "Alice")
    await insert_user(isolated_db, 2, 1_000, "Bob")
    match_id = await create_match(1, 2, "combat", 100)

    first, second = await asyncio.gather(
        accept_and_fund_match(match_id, 2),
        accept_and_fund_match(match_id, 2),
    )

    assert sum(result is not None for result in (first, second)) == 1
    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM users WHERE user_id=1",
    ) == 900
    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM users WHERE user_id=2",
    ) == 900

    match = await fetch_one(
        isolated_db,
        "SELECT status,pot FROM arena_matches WHERE match_id=?",
        (match_id,),
    )
    assert match == {"status": "active", "pot": 200}


@pytest.mark.asyncio
async def test_arena_settlement_pays_winner_once(isolated_db):
    from utils.arena_store import (
        accept_and_fund_match,
        create_match,
        settle_winner,
    )

    await insert_user(isolated_db, 1, 1_000)
    await insert_user(isolated_db, 2, 1_000)
    match_id = await create_match(1, 2, "combat", 100)
    assert await accept_and_fund_match(match_id, 2)

    results = await asyncio.gather(
        settle_winner(match_id, 1, "Alice gagne"),
        settle_winner(match_id, 1, "Alice gagne encore"),
    )

    assert sorted(results) == [False, True]
    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM users WHERE user_id=1",
    ) == 1_100
    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM users WHERE user_id=2",
    ) == 900
    assert await fetch_value(
        isolated_db,
        "SELECT SUM(balance) FROM users",
    ) == 2_000


@pytest.mark.asyncio
async def test_arena_refund_runs_once(isolated_db):
    from utils.arena_store import (
        accept_and_fund_match,
        create_match,
        refund_match,
    )

    await insert_user(isolated_db, 1, 1_000)
    await insert_user(isolated_db, 2, 1_000)
    match_id = await create_match(1, 2, "quiz", 250)
    assert await accept_and_fund_match(match_id, 2)

    results = await asyncio.gather(
        refund_match(match_id),
        refund_match(match_id),
    )

    assert sorted(results) == [False, True]
    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM users WHERE user_id=1",
    ) == 1_000
    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM users WHERE user_id=2",
    ) == 1_000


@pytest.mark.asyncio
async def test_arena_failed_funding_changes_nothing(isolated_db):
    from utils.arena_store import accept_and_fund_match, create_match

    await insert_user(isolated_db, 1, 100)
    await insert_user(isolated_db, 2, 20)
    match_id = await create_match(1, 2, "combat", 50)

    result = await accept_and_fund_match(match_id, 2)
    assert result is None
    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM users WHERE user_id=1",
    ) == 100
    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM users WHERE user_id=2",
    ) == 20
    assert await fetch_value(
        isolated_db,
        "SELECT status FROM arena_matches WHERE match_id=?",
        (match_id,),
    ) == "pending"


@pytest.mark.asyncio
async def test_bank_concurrent_deposit_cannot_overdraw(
    isolated_db,
    monkeypatch,
):
    import handlers.bank as bank

    await insert_user(isolated_db, 10, 100)
    async with aiosqlite.connect(isolated_db) as db:
        await db.execute(
            "INSERT INTO bank_accounts(user_id,bank_name,balance) "
            "VALUES (10,'Banque Test',0)"
        )
        await db.commit()

    account = {"bank_name": "Banque Test", "balance": 0}

    async def fake_user(_user_id):
        return {"balance": 100}

    async def fake_accounts(_user_id):
        return [account]

    monkeypatch.setattr(bank, "get_user", fake_user)
    monkeypatch.setattr(bank, "get_all_bank_accounts", fake_accounts)

    command = unwrap_handler(bank.cmd_depot)
    update_a = FakeUpdate(10)
    update_b = FakeUpdate(10)
    context_a = SimpleNamespace(args=["100"])
    context_b = SimpleNamespace(args=["100"])

    await asyncio.gather(
        command(update_a, context_a),
        command(update_b, context_b),
    )

    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM users WHERE user_id=10",
    ) == 0
    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM bank_accounts WHERE user_id=10",
    ) == 100


@pytest.mark.asyncio
async def test_market_listing_can_only_be_bought_once(
    isolated_db,
    monkeypatch,
):
    import handlers.market as market

    await insert_user(isolated_db, 1, 0, "Seller")
    await insert_user(isolated_db, 2, 500, "Buyer A")
    await insert_user(isolated_db, 3, 500, "Buyer B")

    async with aiosqlite.connect(isolated_db) as db:
        await db.execute(
            "INSERT INTO items(item_id,name,emoji,rarity) "
            "VALUES (1,'Potion','🧪','common')"
        )
        cursor = await db.execute(
            "INSERT INTO market_listings "
            "(seller_id,item_id,quantity,price,created_at,expires_at,status) "
            "VALUES (1,1,1,100,0,9999999999,'active')"
        )
        listing_id = cursor.lastrowid
        await db.commit()

    async def no_journal(*args, **kwargs):
        return None

    monkeypatch.setattr(market, "add_life_journal", no_journal)
    command = unwrap_handler(market.cmd_buyitem)

    update_a = FakeUpdate(2)
    update_b = FakeUpdate(3)
    context_a = SimpleNamespace(args=[str(listing_id), "1"])
    context_b = SimpleNamespace(args=[str(listing_id), "1"])

    await asyncio.gather(
        command(update_a, context_a),
        command(update_b, context_b),
    )

    assert await fetch_value(
        isolated_db,
        "SELECT balance FROM users WHERE user_id=1",
    ) == 100
    assert await fetch_value(
        isolated_db,
        "SELECT SUM(quantity) FROM inventory WHERE item_id=1",
    ) == 1
    assert await fetch_value(
        isolated_db,
        "SELECT status FROM market_listings WHERE listing_id=?",
        (listing_id,),
    ) == "sold"
    assert await fetch_value(
        isolated_db,
        "SELECT SUM(balance) FROM users",
    ) == 1_000