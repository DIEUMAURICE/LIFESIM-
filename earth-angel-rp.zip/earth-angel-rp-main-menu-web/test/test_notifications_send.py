# test/test_notifications_send.py — HTML sûr, erreurs Telegram, remise en file
import asyncio
import os
import sys
import tempfile
import types

try:                                   # vrai python-telegram-bot si installé
    import telegram.error as tgerr
except ImportError:                    # sinon : vraies classes d'exception minimales + reste simulé
    import importlib.abc, importlib.machinery
    from unittest.mock import MagicMock
    tgerr = types.ModuleType("telegram.error")

    class TelegramError(Exception): pass
    class Forbidden(TelegramError): pass
    class BadRequest(TelegramError): pass
    class NetworkError(TelegramError): pass
    class TimedOut(NetworkError): pass
    class RetryAfter(TelegramError):
        def __init__(self, retry_after):
            super().__init__(f"retry {retry_after}"); self.retry_after = retry_after
    for _c in (TelegramError, Forbidden, BadRequest, NetworkError, TimedOut, RetryAfter):
        setattr(tgerr, _c.__name__, _c)
    sys.modules["telegram.error"] = tgerr

    class _F(importlib.abc.MetaPathFinder, importlib.abc.Loader):
        def find_spec(self, name, path, target=None):
            if name == "telegram" or name.startswith("telegram."):
                return importlib.machinery.ModuleSpec(name, self, is_package=True)
        def create_module(self, spec):
            m = MagicMock(); m.__path__ = []; m.__name__ = spec.name; m.__spec__ = spec; return m
        def exec_module(self, module): pass
    sys.meta_path.insert(0, _F())

os.environ.setdefault("BOT_TOKEN", "x"); os.environ.setdefault("ADMIN_IDS", "1")
import database as d
from handlers import notifications as n


def test_to_html_escapes_and_converts_bold():
    # <b>…</b> écrits par les modules sont rendus ; toute autre balise reste échappée
    out = n._to_html("**Gagné** <b>x</b> & Jean_Pierre* <script>")
    assert out == "<b>Gagné</b> <b>x</b> &amp; Jean_Pierre* &lt;script&gt;"


class FakeBot:
    def __init__(self, script):            # script : liste de comportements (exception ou None)
        self.script, self.calls = list(script), []
    async def send_message(self, uid, text, **kw):
        self.calls.append((uid, text, kw))
        act = self.script.pop(0) if self.script else None
        if act is not None:
            raise act


async def _no_sleep(*a, **k): return None


async def test_send_with_retry_outcomes():
    n.asyncio.sleep, real = _no_sleep, asyncio.sleep
    try:
        assert await n._send_with_retry(FakeBot([None]), 1, "<b>x</b>") is True
        assert await n._send_with_retry(FakeBot([tgerr.Forbidden("blocked")]), 1, "x") is True     # abandon
        b = FakeBot([tgerr.BadRequest("can't parse"), None])                                        # repli brut
        assert await n._send_with_retry(b, 1, "<b>x</b> &amp; y") is True
        assert "parse_mode" not in b.calls[1][2] and b.calls[1][1] == "x & y"
        assert await n._send_with_retry(FakeBot([tgerr.NetworkError("down")]), 1, "x") is False    # à réessayer
        assert await n._send_with_retry(FakeBot([tgerr.RetryAfter(1), None]), 1, "x") is True
        assert await n._send_with_retry(FakeBot([tgerr.RetryAfter(1), tgerr.RetryAfter(1)]), 1, "x") is False
    finally:
        n.asyncio.sleep = real


async def test_process_notifications_requeues_temporary_failures_only():
    path = os.path.join(tempfile.mkdtemp(prefix="lifesim_nt_"), "t.db")
    d.DB_PATH = path; d._DB_POOL = d.SQLiteConnectionPool(path, 5); d._READ_POOL = None
    d._db_global_lock = asyncio.Lock()
    await d.init_db()
    for uid in (1, 2, 3):
        await n.queue_notification(uid, "Titre", "Message **gras**")

    class Bot(FakeBot):
        async def send_message(self, uid, text, **kw):
            self.calls.append((uid, text, kw))
            if uid == 2: raise tgerr.NetworkError("down")
            if uid == 3: raise tgerr.Forbidden("blocked")

    bot = Bot([])
    n.NOTIF_SEND_PER_SEC = 1000
    await asyncio.wait_for(n.process_notifications(bot), 10)    # doit se terminer (pas de boucle)
    async with d.db_connection() as db:
        async with db.execute("SELECT user_id, sent FROM notifications ORDER BY user_id") as c:
            rows = {r[0]: r[1] for r in await c.fetchall()}
    assert rows == {1: 1, 2: 0, 3: 1}, rows        # 2 remis en file, 3 (bot bloqué) abandonné
    assert sum(1 for c in bot.calls if c[0] == 2) == 1           # un seul essai dans ce passage
    assert "<b>gras</b>" in bot.calls[0][1] and bot.calls[0][2]["parse_mode"] == "HTML"
