"""test/test_companies_shares.py — Parts/capital des entreprises : valorisation, achat, vente,
dividendes.

Couvre `gameplay/companies.py` (service pur, réel via une base migrée, pour vérifier que chaque
opération est bien atomique : une transaction unique, jamais de double commit) et
`webapp/routers/companies_router.py` (délégation au même service), comme
`handlers/company_shares.py` les appelle désormais.
"""
import asyncio
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
import gameplay.companies as companies_service
from webapp.routers import companies_router
from webapp.server import app


@pytest_asyncio.fixture
async def persistent_companies_db(monkeypatch, tmp_path):
    """Base réelle (schéma + migrations) pour vérifier que l'achat/vente/dividendes écrivent
    bien `users.balance`, `companies.treasury` et `company_shares` sous une seule transaction."""
    path = str(tmp_path / "companies-shares-persistent.db")
    pool = database.SQLiteConnectionPool(path, size=3)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(database, "_db_global_lock", asyncio.Lock())
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    yield path
    await database._DB_POOL.close()


async def _seed_user(user_id: int, balance: int) -> None:
    async with database.db_connection() as db:
        await db.execute(
            "INSERT INTO users (user_id, full_name, balance, total_earned, total_spent) VALUES (?,?,?,0,0)",
            (user_id, f"Joueur {user_id}", balance),
        )
        await db.commit()


async def _seed_company(company_id: int, owner_id: int, *, treasury: int = 100_000, reputation: int = 50) -> None:
    async with database.db_connection() as db:
        await db.execute(
            "INSERT INTO companies (company_id,name,owner_id,sector,treasury,reputation,level,dissolved,created_at) "
            "VALUES (?,?,?,?,?,?,1,0,?)",
            (company_id, f"Société {company_id}", owner_id, "Tech", treasury, reputation, database.now()),
        )
        await db.execute(
            "INSERT INTO company_shares (user_id,company_id,shares) VALUES (?,?,100)", (owner_id, company_id)
        )
        await db.commit()


async def _balance(user_id: int) -> int:
    async with database.db_connection() as db:
        async with db.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)) as cur:
            return (await cur.fetchone())[0]


async def _treasury(company_id: int) -> int:
    async with database.db_connection() as db:
        async with db.execute("SELECT treasury FROM companies WHERE company_id=?", (company_id,)) as cur:
            return (await cur.fetchone())[0]


# ─────────────────────────── gameplay/companies.py — valorisation ───────────────────────────


def test_share_price_uses_the_same_formula_as_the_bot():
    assert companies_service.share_price(100_000, 50, 0) == (100_000 // 1000) * (50 + 50) // 50
    assert companies_service.share_price(0, 0, 0) == 10  # plancher


def test_share_price_is_capped_at_max_share_price():
    assert companies_service.share_price(10**15, 100, 100) == companies_service.MAX_SHARE_PRICE


# ─────────────────────────── gameplay/companies.py — buy_shares ───────────────────────────


@pytest.mark.asyncio
async def test_buy_shares_debits_buyer_and_credits_treasury_atomically(persistent_companies_db):
    await _seed_user(1, balance=1_000_000)
    await _seed_company(10, owner_id=2, treasury=100_000, reputation=50)

    result = await companies_service.buy_shares(1, 10, 100_000, 50, 0, 10)

    assert result["ok"] is True
    price = companies_service.share_price(100_000, 50, 0)
    assert result["total_cost"] == price * 10
    assert result["shares_owned"] == 10
    assert await _balance(1) == 1_000_000 - price * 10
    assert await _treasury(10) == 100_000 + price * 10


@pytest.mark.asyncio
async def test_buy_shares_refuses_insufficient_funds_without_mutating_anything(persistent_companies_db):
    await _seed_user(1, balance=10)
    await _seed_company(10, owner_id=2, treasury=100_000, reputation=50)

    result = await companies_service.buy_shares(1, 10, 100_000, 50, 0, 1_000)

    assert result["ok"] is False
    assert result["reason"] == "insufficient_funds"
    assert await _balance(1) == 10
    assert await _treasury(10) == 100_000


@pytest.mark.asyncio
async def test_buy_shares_rejects_a_non_positive_quantity(persistent_companies_db):
    await _seed_user(1, balance=1_000_000)
    result = await companies_service.buy_shares(1, 10, 100_000, 50, 0, 0)
    assert result == {"ok": False, "reason": "invalid_quantity"}


# ─────────────────────────── gameplay/companies.py — sell_shares ───────────────────────────


@pytest.mark.asyncio
async def test_sell_shares_credits_seller_and_decrements_shares_atomically(persistent_companies_db):
    await _seed_user(2, balance=0)
    await _seed_company(10, owner_id=2, treasury=100_000, reputation=50)

    result = await companies_service.sell_shares(2, 10, 100_000, 50, 0, 40)

    assert result["ok"] is True
    price = companies_service.share_price(100_000, 50, 0)
    assert result["total_value"] == price * 40
    assert result["shares_remaining"] == 60
    assert await _balance(2) == price * 40


@pytest.mark.asyncio
async def test_sell_shares_deletes_the_row_when_selling_everything(persistent_companies_db):
    await _seed_user(2, balance=0)
    await _seed_company(10, owner_id=2, treasury=100_000, reputation=50)

    result = await companies_service.sell_shares(2, 10, 100_000, 50, 0, 100)

    assert result["ok"] is True
    assert result["shares_remaining"] == 0
    async with database.db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM company_shares WHERE user_id=2 AND company_id=10") as cur:
            assert (await cur.fetchone())[0] == 0


@pytest.mark.asyncio
async def test_sell_shares_refuses_more_than_owned(persistent_companies_db):
    await _seed_user(2, balance=0)
    await _seed_company(10, owner_id=2, treasury=100_000, reputation=50)

    result = await companies_service.sell_shares(2, 10, 100_000, 50, 0, 101)

    assert result == {"ok": False, "reason": "not_enough_shares", "current_shares": 100}
    assert await _balance(2) == 0


@pytest.mark.asyncio
async def test_sell_shares_refuses_a_non_holder(persistent_companies_db):
    await _seed_user(3, balance=0)
    await _seed_company(10, owner_id=2, treasury=100_000, reputation=50)
    result = await companies_service.sell_shares(3, 10, 100_000, 50, 0, 1)
    assert result == {"ok": False, "reason": "no_shares"}


# ─────────────────────────── gameplay/companies.py — distribute_dividends ───────────────────────────


@pytest.mark.asyncio
async def test_distribute_dividends_pays_shareholders_pro_rata_and_debits_treasury_once(persistent_companies_db):
    await _seed_user(2, balance=0)
    await _seed_user(3, balance=0)
    await _seed_company(10, owner_id=2, treasury=1_000_000, reputation=50)
    async with database.db_connection() as db:
        await db.execute("INSERT INTO company_shares (user_id,company_id,shares) VALUES (3,10,300)")
        await db.commit()
    # 100 parts (user 2) + 300 parts (user 3) = 400 au total.

    result = await companies_service.distribute_dividends(10, 1_000_000, 10)

    assert result["ok"] is True
    assert result["dividend_total"] == 100_000
    assert result["shareholder_count"] == 2
    assert await _treasury(10) == 900_000
    assert await _balance(2) == 100_000 * 100 // 400
    assert await _balance(3) == 100_000 * 300 // 400


@pytest.mark.asyncio
async def test_distribute_dividends_refuses_when_treasury_too_low(persistent_companies_db):
    await _seed_user(2, balance=0)
    await _seed_company(10, owner_id=2, treasury=1_000, reputation=50)

    result = await companies_service.distribute_dividends(10, 1_000, 10)

    assert result["ok"] is False
    assert result["reason"] == "treasury_too_low"
    assert await _treasury(10) == 1_000  # inchangée


@pytest.mark.asyncio
async def test_distribute_dividends_refuses_when_no_shares_outstanding(persistent_companies_db):
    await _seed_company(10, owner_id=2, treasury=1_000_000, reputation=50)
    async with database.db_connection() as db:
        await db.execute("DELETE FROM company_shares WHERE company_id=10")
        await db.commit()

    result = await companies_service.distribute_dividends(10, 1_000_000, 10)

    assert result == {"ok": False, "reason": "no_shares_outstanding"}


# ─────────────────────────── webapp/routers/companies_router.py ───────────────────────────


@pytest.mark.asyncio
async def test_shares_route_reports_valuation_and_shareholders(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "name": "Acme", "treasury": 100_000, "reputation": 50, "rd_level": 0}),
    )
    holders = AsyncMock(return_value=[{"full_name": "A", "user_id": 1, "shares": 100}])
    monkeypatch.setattr(companies_router.companies_service, "shareholders", holders)

    result = await companies_router.shares(user_id=1)

    assert result["shareholders"] == [{"full_name": "A", "user_id": 1, "shares": 100}]
    assert result["share_price"] == companies_service.share_price(100_000, 50, 0)


@pytest.mark.asyncio
async def test_buy_shares_route_delegates_and_logs(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "treasury": 100_000, "reputation": 50, "rd_level": 0}),
    )
    buy = AsyncMock(return_value={"ok": True, "price_per_share": 100, "total_cost": 1_000, "capped": False, "shares_owned": 10})
    log = AsyncMock()
    monkeypatch.setattr(companies_router.companies_service, "buy_shares", buy)
    monkeypatch.setattr(companies_router.database, "log_company_action", log)

    result = await companies_router.buy_shares(companies_router.SharesQuantityIn(quantity=10), user_id=1)

    assert result["shares_owned"] == 10
    buy.assert_awaited_once_with(1, 10, 100_000, 50, 0, 10)
    log.assert_awaited_once()


@pytest.mark.asyncio
async def test_buy_shares_route_raises_422_with_cost_on_insufficient_funds(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "treasury": 100_000, "reputation": 50, "rd_level": 0}),
    )
    monkeypatch.setattr(
        companies_router.companies_service, "buy_shares",
        AsyncMock(return_value={"ok": False, "reason": "insufficient_funds", "total_cost": 5_000}),
    )
    with pytest.raises(HTTPException) as exc:
        await companies_router.buy_shares(companies_router.SharesQuantityIn(quantity=1000), user_id=1)
    assert exc.value.status_code == 422
    assert "5000" in exc.value.detail


@pytest.mark.asyncio
async def test_sell_shares_route_raises_422_with_current_shares(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "treasury": 100_000, "reputation": 50, "rd_level": 0}),
    )
    monkeypatch.setattr(
        companies_router.companies_service, "sell_shares",
        AsyncMock(return_value={"ok": False, "reason": "not_enough_shares", "current_shares": 3}),
    )
    with pytest.raises(HTTPException) as exc:
        await companies_router.sell_shares(companies_router.SharesQuantityIn(quantity=10), user_id=1)
    assert exc.value.status_code == 422
    assert "3" in exc.value.detail


@pytest.mark.asyncio
async def test_dividends_route_refuses_a_non_owner(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 2, "treasury": 100_000}),
    )
    distribute = AsyncMock()
    monkeypatch.setattr(companies_router.companies_service, "distribute_dividends", distribute)

    with pytest.raises(HTTPException) as exc:
        await companies_router.distribute_dividends(companies_router.DividendPercentIn(percent=10), user_id=9)
    assert exc.value.status_code == 403
    distribute.assert_not_awaited()


@pytest.mark.asyncio
async def test_dividends_route_delegates_for_the_owner_and_logs(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 2, "treasury": 100_000}),
    )
    distribute = AsyncMock(
        return_value={"ok": True, "percent": 10, "dividend_total": 10_000, "shareholder_count": 2, "payouts": []}
    )
    log = AsyncMock()
    monkeypatch.setattr(companies_router.companies_service, "distribute_dividends", distribute)
    monkeypatch.setattr(companies_router.database, "log_company_action", log)

    result = await companies_router.distribute_dividends(companies_router.DividendPercentIn(percent=10), user_id=2)

    assert result["dividend_total"] == 10_000
    distribute.assert_awaited_once_with(10, 100_000, 10)
    log.assert_awaited_once()


def test_companies_shares_routes_are_registered_on_the_shared_api():
    paths = {route.path for route in app.routes}
    assert "/api/companies/shares" in paths
    assert "/api/companies/shares/buy" in paths
    assert "/api/companies/shares/sell" in paths
    assert "/api/companies/dividends" in paths


# ─────────────── Parts d'une entreprise tierce, ciblée par son nom (comme /acheterparts "Nom" N) ───────────────
OTHER = {"company_id": 20, "name": "Autre SA", "treasury": 500_000, "reputation": 60, "rd_level": 1}


@pytest.mark.asyncio
async def test_buy_shares_route_targets_another_company_by_name(monkeypatch):
    by_name = AsyncMock(return_value=OTHER)
    own = AsyncMock(side_effect=AssertionError("l'entreprise de l'appelant ne doit pas être utilisée"))
    buy = AsyncMock(return_value={"ok": True, "price_per_share": 10, "total_cost": 50, "capped": False, "shares_owned": 5})
    log = AsyncMock()
    monkeypatch.setattr(companies_router.database, "get_company_by_name", by_name)
    monkeypatch.setattr(companies_router.database, "get_user_company", own)
    monkeypatch.setattr(companies_router.companies_service, "buy_shares", buy)
    monkeypatch.setattr(companies_router.database, "log_company_action", log)

    await companies_router.buy_shares(
        companies_router.SharesQuantityIn(quantity=5, company_name="  autre sa "), user_id=1)

    by_name.assert_awaited_once_with("autre sa")
    buy.assert_awaited_once_with(1, 20, 500_000, 60, 1, 5)
    assert log.await_args.args[0] == 20


@pytest.mark.asyncio
async def test_sell_shares_route_targets_another_company_by_name(monkeypatch):
    monkeypatch.setattr(companies_router.database, "get_company_by_name", AsyncMock(return_value=OTHER))
    sell = AsyncMock(return_value={"ok": True, "price_per_share": 10, "total_value": 30, "capped": False, "shares_remaining": 1})
    monkeypatch.setattr(companies_router.companies_service, "sell_shares", sell)
    monkeypatch.setattr(companies_router.database, "log_company_action", AsyncMock())
    await companies_router.sell_shares(
        companies_router.SharesQuantityIn(quantity=3, company_name="Autre SA"), user_id=1)
    sell.assert_awaited_once_with(1, 20, 500_000, 60, 1, 3)


@pytest.mark.asyncio
async def test_share_routes_404_on_unknown_company_name(monkeypatch):
    monkeypatch.setattr(companies_router.database, "get_company_by_name", AsyncMock(return_value=None))
    for call in (
        companies_router.buy_shares(companies_router.SharesQuantityIn(quantity=1, company_name="Nope"), user_id=1),
        companies_router.sell_shares(companies_router.SharesQuantityIn(quantity=1, company_name="Nope"), user_id=1),
        companies_router.share_quote(name="Nope", user_id=1),
    ):
        with pytest.raises(HTTPException) as exc:
            await call
        assert exc.value.status_code == 404


@pytest.mark.asyncio
async def test_share_quote_returns_price_and_my_holding(monkeypatch):
    monkeypatch.setattr(companies_router.database, "get_company_by_name", AsyncMock(return_value=OTHER))
    monkeypatch.setattr(companies_router.companies_service, "get_user_shares", AsyncMock(return_value=7))
    result = await companies_router.share_quote(name="Autre SA", user_id=1)
    assert result["my_shares"] == 7
    assert result["share_price"] == companies_service.share_price(500_000, 60, 1)
    assert result["company"]["name"] == "Autre SA"


def test_share_quote_route_is_registered():
    assert "/api/companies/shares/quote" in {r.path for r in app.routes}
