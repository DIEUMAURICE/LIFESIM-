"""test/test_companies_transfer.py — Transfert de PDG (service pur sur base migrée + routeur)."""
import asyncio
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
import gameplay.companies as companies_service
from webapp.routers import companies_router
from webapp.server import app


@pytest_asyncio.fixture
async def persistent_companies_db(monkeypatch, tmp_path):
    path = str(tmp_path / "companies-transfer.db")
    pool = database.SQLiteConnectionPool(path, size=3)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(database, "_db_global_lock", asyncio.Lock())
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    yield path
    await database._DB_POOL.close()


async def _seed():
    async with database.db_connection() as db:
        for uid in (1, 2, 3):
            await db.execute("INSERT INTO users (user_id, full_name, balance) VALUES (?,?,0)", (uid, f"J{uid}"))
        await db.execute(
            "INSERT INTO companies (company_id,name,owner_id,sector,treasury,reputation,level,dissolved,created_at) "
            "VALUES (10,'Acme',1,'Tech',0,50,1,0,?)", (database.now(),))
        for uid, poste in ((1, "PDG"), (2, "Employé")):
            await db.execute(
                "INSERT INTO company_members (user_id,company_id,poste,salary,base_salary,activity_score,joined_at) "
                "VALUES (?,10,?,0,0,0,?)", (uid, poste, database.now()))
        await db.commit()


async def _rows():
    async with database.db_connection() as db:
        async with db.execute("SELECT owner_id FROM companies WHERE company_id=10") as cur:
            owner = (await cur.fetchone())[0]
        async with db.execute("SELECT user_id, poste FROM company_members ORDER BY user_id") as cur:
            return owner, await cur.fetchall()


@pytest.mark.asyncio
async def test_transfer_swaps_owner_and_postes_atomically(persistent_companies_db):
    await _seed()
    result = await companies_service.transfer_ownership(1, 10, 2)
    assert result == {"ok": True, "company_name": "Acme"}
    owner, members = await _rows()
    assert owner == 2
    assert [tuple(m) for m in members] == [(1, "Ex-PDG"), (2, "PDG")]


@pytest.mark.asyncio
async def test_transfer_refusals_leave_everything_untouched(persistent_companies_db):
    await _seed()
    assert await companies_service.transfer_ownership(1, 10, 1) == {"ok": False, "reason": "same_user"}
    assert await companies_service.transfer_ownership(1, 10, 3) == {"ok": False, "reason": "target_not_member"}
    assert await companies_service.transfer_ownership(2, 10, 1) == {"ok": False, "reason": "not_owner"}
    owner, members = await _rows()
    assert owner == 1
    assert [tuple(m) for m in members] == [(1, "PDG"), (2, "Employé")]


@pytest.mark.asyncio
async def test_transfer_route_checks_ownership_and_delegates(monkeypatch):
    monkeypatch.setattr(companies_router.database, "get_user_company",
                        AsyncMock(return_value={"company_id": 10, "owner_id": 1}))
    transfer = AsyncMock(return_value={"ok": True, "company_name": "Acme"})
    monkeypatch.setattr(companies_router.companies_service, "transfer_ownership", transfer)
    assert (await companies_router.transfer_ownership(companies_router.TransferIn(target_user_id=2), user_id=1))["ok"]
    transfer.assert_awaited_once_with(1, 10, 2)
    with pytest.raises(HTTPException) as exc:
        await companies_router.transfer_ownership(companies_router.TransferIn(target_user_id=2), user_id=9)
    assert exc.value.status_code == 403
    monkeypatch.setattr(companies_router.companies_service, "transfer_ownership",
                        AsyncMock(return_value={"ok": False, "reason": "target_not_member"}))
    with pytest.raises(HTTPException) as exc:
        await companies_router.transfer_ownership(companies_router.TransferIn(target_user_id=3), user_id=1)
    assert exc.value.status_code == 422


def test_transfer_route_is_registered():
    assert "/api/companies/transfer" in {r.path for r in app.routes}
