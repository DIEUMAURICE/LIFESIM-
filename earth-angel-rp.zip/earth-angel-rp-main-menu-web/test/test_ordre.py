# test/test_ordre.py — Ordre public : nominations, recrutement, crimes, enquêtes, pouvoirs, signalements, paie
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

import pytest
import pytest_asyncio

import database
import migrations
import utils.factions as factions
import utils.ordre as ordre
from config import ORDRE, ORDRE_PLAYER_CRIMES

LEADER, DG, CHEF, AGT, ENQ, CAD, CIV1, CIV2, CIV3, SOL, GOVV = 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311
USERS = (LEADER, DG, CHEF, AGT, ENQ, CAD, CIV1, CIV2, CIV3, SOL, GOVV)


@pytest_asyncio.fixture
async def odb(monkeypatch, tmp_path):
    path = str(tmp_path / "ordre.db")
    pool = database.SQLiteConnectionPool(path, size=5)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()

    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title, message))

    clock = {"t": 10 * 86400, "real": 2_000_000}
    for mod in (ordre, factions):
        monkeypatch.setattr(mod, "notify", fake_notify)
    monkeypatch.setattr(ordre, "now", lambda: clock["t"])
    monkeypatch.setattr(ordre, "real_now", lambda: clock["real"])

    async def not_protected(uid):
        return False

    monkeypatch.setattr(ordre, "is_protected", not_protected)

    where = {}

    async def fake_position(uid):
        return {"location": where.get(uid, "maison"), "in_transit": False}

    async def fake_exempt(uid):
        return False

    import utils.location as loc
    monkeypatch.setattr(loc, "get_position", fake_position)
    monkeypatch.setattr(loc, "is_exempt", fake_exempt)

    for uid in USERS:
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 100_000)
    yield {"sent": sent, "clock": clock, "where": where}


async def _staff(uid, faction, post, station="central", duty=True):
    async with database.db_connection() as db:
        await ordre._set_post(db, uid, faction, station, post)
        await db.execute("UPDATE ordre_staff SET on_duty=? WHERE user_id=?", (1 if duty else 0, uid))
        await db.commit()


async def _arm(uid, weapon="pistolet", ammo=12):
    """Donne et équipe une arme (le meurtre et le capture armée exigent une arme à feu)."""
    async with database.db_connection() as db:
        await db.execute("INSERT OR REPLACE INTO user_weapons(user_id, weapon, ammo, equipped, source) VALUES (?,?,?,1,'noir')",
                         (uid, weapon, ammo))
        await db.commit()


async def _bal(uid):
    return (await database.get_user(uid))["balance"]


async def _prison(uid):
    return (await database.get_user(uid))["prison_until"]


# ─── Direction & personnel ───────────────────────────────────────────────────
async def test_hierarchy(odb):
    ok, _ = await ordre.appoint_dg(LEADER, DG, "police")
    assert ok
    st = await ordre.get_staff(DG)
    assert st["post"] == "dg" and st["station_id"] == "central" and st["code"].startswith("POL-")
    # le DG nomme un chef de poste ; un simple joueur ne le peut pas
    ok, _ = await ordre.appoint_chief(DG, CHEF, "police", "sud")
    assert ok and (await ordre.get_staff(CHEF))["post"] == "chef"
    ok, _ = await ordre.appoint_chief(CIV1, CIV2, "police", "sud")
    assert not ok
    ok, msg = await ordre.appoint_chief(DG, CIV2, "police", "central")
    assert not ok
    # un nouveau DG remplace l'ancien (redevient poste de base)
    ok, _ = await ordre.appoint_dg(LEADER, CIV1, "police")
    assert ok and (await ordre.get_staff(DG))["post"] == "cadet"
    ok, _ = await ordre.revoke_dg(LEADER, "police", "test")
    assert ok and await ordre.get_head("police", "central") is None


async def test_assign_and_dismiss_scope(odb):
    await _staff(DG, "police", "dg")
    await _staff(CHEF, "police", "chef", "sud")
    await _staff(AGT, "police", "agent", "sud")
    await _staff(CAD, "police", "cadet", "affaires")
    # le chef du Sud gère son poste mais pas un autre
    ok, _ = await ordre.assign_post(CHEF, AGT, "sergent")
    assert ok and (await ordre.get_staff(AGT))["post"] == "sergent"
    ok, _ = await ordre.assign_post(CHEF, CAD, "agent")
    assert not ok
    ok, _ = await ordre.assign_post(CHEF, AGT, "agent", "affaires")
    assert not ok
    ok, _ = await ordre.assign_post(CHEF, AGT, "chef")           # poste de direction = nomination
    assert not ok
    ok, _ = await ordre.assign_post(DG, CAD, "agent", "sud")     # le DG affecte partout
    assert ok and (await ordre.get_staff(CAD))["station_id"] == "sud"
    ok, _ = await ordre.dismiss(CHEF, DG)
    assert not ok
    ok, _ = await ordre.dismiss(CHEF, AGT)
    assert ok and await ordre.get_staff(AGT) is None


async def test_recruit_with_interview(odb):
    await _staff(DG, "police", "dg")
    ok, _ = await ordre.apply_for_job(CIV1, "police", "central")
    assert ok
    ok, _ = await ordre.apply_for_job(CIV1, "police", "central")
    assert not ok                                                  # déjà en cours
    app = (await ordre.list_apps(DG))[0]
    ok, _ = await ordre.start_interview(DG, app["id"])
    assert ok
    # le bot relaie les messages dans les deux sens
    r = await ordre.relay_target(CIV1)
    assert r["to"] == DG
    r = await ordre.relay_target(DG)
    assert r["to"] == CIV1
    ok, _ = await ordre.decide_application(DG, app["id"], True)
    assert ok
    st = await ordre.get_staff(CIV1)
    assert st["post"] == "cadet" and st["agent_no"] > 0
    assert await ordre.active_chat(CIV1) is None
    # un candidat en prison est refusé
    await database.update_field(CIV3, "prison_until", 10 * 86400 + 500)
    ok, msg = await ordre.apply_for_job(CIV3, "police", "central")
    assert not ok and "prison" in msg
    ok, _ = await ordre.apply_for_job(CIV2, "police", "central")
    assert ok
    await database.update_field(CIV2, "prison_until", 10 * 86400 + 500)      # arrêté entre-temps
    app2 = (await ordre.list_apps(DG))[0]
    ok, msg = await ordre.decide_application(DG, app2["id"], True)
    assert not ok and "prison" in msg


async def test_every_gov_faction_recruits_by_interview(odb):
    """Toute faction gouvernementale (y compris l'Administration) recrute par candidature + entretien."""
    from config import GOV_FACTIONS
    assert set(ordre.RECRUIT_FACTIONS) == set(GOV_FACTIONS)
    # sans direction, personne ne peut faire passer d'entretien : embauche directe au grade d'entrée
    ok, _ = await ordre.apply_for_job(CIV3, "mairie", "central")
    assert ok and (await factions.get_membership(CIV3))["rank"] == 0
    # Administration : un chef (grade 3+) reçoit la candidature, mène l'entretien puis recrute
    async with database.db_connection() as db:
        await db.execute("INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) "
                         "VALUES (?, 'mairie', 4, 0, 0)", (DG,))
        await db.commit()
    assert ordre.station_ids("mairie") == ["central"]
    ok, _ = await ordre.apply_for_job(CIV1, "mairie", "central")
    assert ok
    assert any(u == DG and t == "📨 Candidature" for u, t, _m in odb["sent"])
    app = (await ordre.list_apps(DG))[0]
    ok, _ = await ordre.start_interview(DG, app["id"])
    assert ok and (await ordre.relay_target(CIV1))["to"] == DG
    ok, _ = await ordre.decide_application(DG, app["id"], True)
    assert ok
    m = await factions.get_membership(CIV1)
    assert m["faction"] == "mairie" and m["rank"] == 0
    # un simple membre (grade bas) ne voit aucune candidature
    ok, _ = await ordre.apply_for_job(CIV2, "mairie", "central")
    assert ok and await ordre.list_apps(CIV1) == []


# ─── Crime contre le bot → fuite → enquête ───────────────────────────────────
async def test_bot_crime_investigation(odb, monkeypatch):
    await _staff(ENQ, "police", "enqueteur")
    cid = await ordre.register_bot_crime(CIV1, "Braquage", 50_000)
    case = await ordre.get_case(cid)
    assert case["status"] == "fuite"
    # pas d'enquête avant la fin de la fuite
    ok, _, _ = await ordre.mg_start(ENQ, cid)
    assert not ok
    odb["clock"]["t"] += ORDRE["flee_delay"] + 1
    await ordre.ordre_maintenance()
    assert (await ordre.get_case(cid))["status"] == "open"
    ok, _, seq = await ordre.mg_start(ENQ, cid)
    assert ok and len(seq) >= 6
    # on ne peut pas répondre pendant l'affichage de la séquence
    r = await ordre.mg_press(ENQ, int(seq[0]))
    assert r["state"] == "wait"
    odb["clock"]["real"] += ORDRE["mg_show"] + 1
    for i, c in enumerate(seq):
        r = await ordre.mg_press(ENQ, int(c))
    assert r["state"] == "win"
    ok, msg = await ordre.arrest_case(ENQ, cid)
    assert ok
    jail = await _prison(CIV1) - odb["clock"]["t"]
    assert 0 < jail <= ORDRE["jail_max"]


async def test_investigation_fails_twice(odb):
    await _staff(ENQ, "police", "enqueteur")
    cid = await ordre.register_bot_crime(CIV1, "Pickpocket", 1000)
    odb["clock"]["t"] += ORDRE["flee_delay"] + 1
    await ordre.ordre_maintenance()
    for attempt in range(ORDRE["mg_attempts"]):
        ok, _, seq = await ordre.mg_start(ENQ, cid)
        assert ok
        odb["clock"]["real"] += ORDRE["mg_show"] + 1
        wrong = (int(seq[0]) + 1) % len(ordre.SYMBOLS)
        r = await ordre.mg_press(ENQ, wrong)
        assert r["state"] == "fail"
    assert r["retry"] is False
    assert (await ordre.get_case(cid))["status"] == "classe"
    assert await _prison(CIV1) == 0
    ok, _, _ = await ordre.mg_start(ENQ, cid)
    assert not ok


async def test_hide_delays_investigation(odb, monkeypatch):
    import random
    cid = await ordre.register_bot_crime(CIV1, "Braquage", 100)
    monkeypatch.setattr(random, "random", lambda: 0.0)
    ok, _ = await ordre.hide(CIV1)
    assert ok
    assert (await ordre.get_case(cid))["open_at"] >= (await ordre.get_case(cid))["created_at"] + ORDRE["hide_delay"]
    ok, msg = await ordre.hide(CIV1)             # cooldown
    assert not ok
    # un joueur qui n'est pas en fuite ne peut pas se cacher
    ok, _ = await ordre.hide(CIV2)
    assert not ok


async def test_mg_difficulty():
    base = ORDRE["mg_len"]
    assert ordre.mg_length(0, 0) == base
    assert ordre.mg_length(500, 0) > base            # bon karma : plus dur
    assert ordre.mg_length(0, 99) < base             # récidiviste : plus facile
    assert ordre.jail_for_bot_crime("Pickpocket") == ORDRE["jail_bot"][0]
    assert ordre.jail_for_bot_crime("Hold-up banque") == ORDRE["jail_bot"][1]
    assert ordre.clamp_sentence(10 ** 6) == ORDRE["jail_max"]


# ─── Crimes contre les joueurs ───────────────────────────────────────────────
async def test_player_theft_alerts_police(odb, monkeypatch):
    import utils.helpers as helpers
    monkeypatch.setattr(helpers, "roll_success", lambda *a, **k: True)
    await _staff(AGT, "police", "agent")
    await _staff(SOL, "armee", "soldat")
    res = await ordre.commit_player_crime(CIV1, "vol", CIV2)
    assert res["ok"] and res["success"] and res["amount"] > 0
    assert await _bal(CIV2) == 100_000 - res["amount"]
    assert await _bal(CIV1) == 100_000 + res["amount"]
    got = {u for u, t, m in odb["sent"] if t == "🚨 Alerte crime"}
    assert AGT in got and SOL not in got            # civil → police seule
    # même victime : protégée un moment
    res2 = await ordre.commit_player_crime(CIV3, "vol", CIV2)
    assert not res2["ok"]


async def test_gov_crime_alerts_army(odb, monkeypatch):
    import utils.helpers as helpers
    monkeypatch.setattr(helpers, "roll_success", lambda *a, **k: True)
    await _staff(AGT, "police", "agent")
    await _staff(SOL, "armee", "soldat")
    await _staff(GOVV, "police", "agent", duty=False)               # victime = membre du gouvernement
    res = await ordre.commit_player_crime(CIV1, "meurtre", GOVV)
    assert not res["ok"] and "arme" in res["msg"].lower()          # sans arme à feu : impossible
    await _arm(CIV1)
    res = await ordre.commit_player_crime(CIV1, "meurtre", GOVV)
    assert res["success"]
    got = {u for u, t, m in odb["sent"] if t == "🚨 Alerte crime"}
    assert AGT in got and SOL in got
    assert (await database.get_user(GOVV))["hospital_until"] > odb["clock"]["t"]
    assert (await ordre.army_wanted_case(CIV1))["victim_gov"] == 1


async def test_failed_player_crime_jails(odb, monkeypatch):
    import utils.helpers as helpers
    monkeypatch.setattr(helpers, "roll_success", lambda *a, **k: False)
    res = await ordre.commit_player_crime(CIV1, "vol", CIV2)
    assert res["ok"] and not res["success"]
    assert 0 < await _prison(CIV1) - odb["clock"]["t"] <= ORDRE["jail_max"]
    assert await _bal(CIV2) == 100_000


async def test_hack_and_defense(odb, monkeypatch):
    import utils.helpers as helpers
    monkeypatch.setattr(helpers, "roll_success", lambda *a, **k: True)
    async with database.db_connection() as db:
        await db.execute("INSERT INTO bank_accounts(user_id, bank_name, balance) VALUES (?,?,?)", (CIV2, "B", 200_000))
        await db.execute("INSERT OR REPLACE INTO skills(user_id, skill_name, level) VALUES (?,?,?)", (CIV1, "Technique", 5))
        await db.commit()
    await database.update_field(CIV2, "balance", 1_000_000)
    ok, _ = await ordre.buy_defense(CIV2, "pare_feu")
    assert ok
    res = await ordre.commit_player_crime(CIV1, "hack", CIV2)
    assert res["ok"] and not res["success"]                       # la défense pro bloque tout
    # sans défense : le hack ponctionne la banque
    async with database.db_connection() as db:
        await db.execute("DELETE FROM anti_hack")
        await db.commit()
    await database.update_field(CIV1, "prison_until", 0)
    res = await ordre.commit_player_crime(CIV1, "hack", CIV2)
    assert res["success"] and 0 < res["amount"] <= ORDRE_PLAYER_CRIMES["hack"]["cap"]
    # manque de compétence
    res = await ordre.commit_player_crime(CIV3, "hack", CIV2)
    assert not res["ok"]
    # défense : pas assez d'argent
    await database.update_field(CIV3, "balance", 10)
    ok, _ = await ordre.buy_defense(CIV3, "pare_feu")
    assert not ok


# ─── Pouvoirs police ─────────────────────────────────────────────────────────
async def test_stun_and_cuffs(odb):
    await _staff(AGT, "police", "agent")
    await _staff(CAD, "police", "cadet")
    ok, _ = await ordre.stun(CAD, CIV1)                           # un cadet n'a pas de pouvoirs
    assert not ok
    ok, _ = await ordre.stun(AGT, CIV1)
    assert ok and "neutralis" in await ordre.restraint_reason(CIV1)
    ok, _ = await ordre.stun(AGT, CIV1)                           # cooldown par cible
    assert not ok
    odb["clock"]["t"] += ORDRE["stun_seconds"] + 1
    assert await ordre.restraint_reason(CIV1) == ""
    for victim in (CIV1, CIV2, CIV3):
        ok, _ = await ordre.cuff(AGT, victim)
        assert ok
    ok, msg = await ordre.cuff(AGT, SOL)
    assert not ok and str(ORDRE["cuffs_max"]) in msg              # 3 menottes max
    ok, _ = await ordre.uncuff(AGT, CIV1)
    assert ok
    ok, _ = await ordre.cuff(AGT, SOL)
    assert ok
    # expiration automatique
    odb["clock"]["t"] += ORDRE["cuffs_seconds"] + 1
    assert await ordre.restraint_reason(CIV2) == ""


async def test_interrogation_flow(odb):
    await _staff(AGT, "police", "agent")
    odb["where"][AGT] = "commissariat"
    ok, _ = await ordre.escort_to_interrogation(AGT, CIV1)        # pas menotté
    assert not ok
    await ordre.cuff(AGT, CIV1)
    ok, _ = await ordre.escort_to_interrogation(AGT, CIV1)
    assert ok
    r = await ordre.relay_target(CIV1)
    assert r["to"] == AGT and r["chat"]["kind"] == "interro"
    assert "interrogatoire" in await ordre.restraint_reason(CIV1)
    ok, _ = await ordre.finish_interrogation(AGT, CIV1, jail_seconds=10 ** 6)   # plafonné à 60 min
    assert ok
    assert await _prison(CIV1) - odb["clock"]["t"] == ORDRE["jail_max"]
    assert await ordre.restraint_reason(CIV1) == ""
    assert await ordre.active_chat(AGT) is None
    # libération
    await ordre.cuff(AGT, CIV2)
    await ordre.escort_to_interrogation(AGT, CIV2)
    ok, _ = await ordre.finish_interrogation(AGT, CIV2, 0)
    assert ok and await _prison(CIV2) == 0
    # l'interrogatoire expire tout seul
    await ordre.cuff(AGT, CIV3)
    await ordre.escort_to_interrogation(AGT, CIV3)
    odb["clock"]["t"] += ORDRE["interro_seconds"] + 1
    await ordre.ordre_maintenance()
    assert await ordre.restraint_reason(CIV3) == "" and await ordre.active_chat(CIV3) is None


async def test_army_capture(odb, monkeypatch):
    import utils.helpers as helpers
    monkeypatch.setattr(helpers, "roll_success", lambda *a, **k: True)
    await _staff(SOL, "armee", "soldat")
    await _staff(GOVV, "police", "agent", duty=False)
    await _staff(AGT, "police", "agent")
    ok, _ = await ordre.army_capture(SOL, CIV2)                   # pas recherché
    assert not ok
    await _arm(CIV1)
    await ordre.commit_player_crime(CIV1, "meurtre", GOVV)
    ok, _ = await ordre.army_capture(AGT, CIV1)                   # la police ne capture pas pour l'armée
    assert not ok
    ok, msg = await ordre.army_capture(SOL, CIV1)                 # soldat sans arme : refus
    assert not ok and "arme" in msg.lower()
    await _arm(SOL)
    ok, _ = await ordre.army_capture(SOL, CIV1)
    assert ok
    ok, _ = await ordre.army_decide(SOL, CIV1, "deliver")
    assert ok and await _prison(CIV1) - odb["clock"]["t"] == ORDRE["jail_max"]
    # exécution
    await database.update_field(CIV1, "prison_until", 0)
    async with database.db_connection() as db:
        await db.execute("UPDATE ordre_cases SET status='open' WHERE suspect_id=?", (CIV1,))
        await db.commit()
    await ordre.army_capture(SOL, CIV1)
    before = await _bal(CIV1)
    ok, _ = await ordre.army_decide(SOL, CIV1, "execute")
    assert ok and await _bal(CIV1) == before - int(before * ORDRE["army_exec_cash_loss"])
    assert (await database.get_user(CIV1))["hospital_until"] > odb["clock"]["t"]
    # sans décision : livraison automatique à la police
    async with database.db_connection() as db:
        await db.execute("UPDATE ordre_cases SET status='open' WHERE suspect_id=?", (CIV1,))
        await db.commit()
    await database.update_field(CIV1, "prison_until", 0)
    await ordre.army_capture(SOL, CIV1)
    odb["clock"]["t"] += ORDRE["army_decision_seconds"] + 1
    await ordre.ordre_maintenance()
    assert await _prison(CIV1) > 0


# ─── Signalements ────────────────────────────────────────────────────────────
async def test_reports(odb):
    await _staff(AGT, "police", "agent")
    for i in range(ORDRE["report_daily_max"]):
        ok, _ = await ordre.report_player(CIV1, (CIV2, CIV3, SOL)[i], "gêne")
        assert ok
    ok, msg = await ordre.report_player(CIV1, GOVV, "encore")
    assert not ok
    reports = await ordre.list_reports()
    assert len(reports) == 3
    ok, _ = await ordre.handle_report(AGT, reports[0]["id"], True)
    assert ok
    case = (await ordre.list_cases())[0]
    assert case["kind"] == "signalement" and case["suspect_id"] == reports[0]["target_id"]
    k0 = (await database.get_user(CIV1))["karma"]
    ok, _ = await ordre.handle_report(AGT, reports[1]["id"], False)
    assert ok and (await database.get_user(CIV1))["karma"] == k0 + ORDRE["report_false_karma"]
    ok, _ = await ordre.handle_report(AGT, reports[1]["id"], False)   # déjà traité
    assert not ok
    # les vieux signalements expirent
    odb["clock"]["t"] += ORDRE["report_ttl"] + 1
    await ordre.ordre_maintenance()
    assert await ordre.list_reports() == []


# ─── Papiers & paie ──────────────────────────────────────────────────────────
async def test_papers(odb):
    await _staff(DG, "police", "dg")
    await _staff(AGT, "police", "agent", "sud")
    b = await ordre.badge(AGT)
    assert b["code"].startswith("POL-") and b["post_name"] == "Agent" and b["station_id"] == "sud"
    card = await ordre.id_card(CIV1)
    assert card["number"].startswith("CI-")
    wb = await ordre.work_book(AGT)
    assert wb["staff"]["post"] == "agent"
    rows, err = await ordre.staff_activity(DG)
    assert not err and len(rows) == 2
    rows, err = await ordre.staff_activity(AGT)                    # réservé à la direction
    assert err and rows == []


async def test_hourly_payroll(odb):
    await _staff(AGT, "police", "agent")
    await _staff(SOL, "armee", "soldat")
    async with database.db_connection() as db:
        await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES ('police',0)")
        await db.execute("UPDATE faction_state SET budget=250 WHERE faction='police'")      # moins que le salaire (500)
        await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES ('armee',0)")
        await db.execute("UPDATE faction_state SET budget=100000 WHERE faction='armee'")
        await db.commit()
    res = await ordre.run_ordre_payroll(hour=77)
    assert res["police"]["status"] == "partial" and res["police"]["paid"] == 250
    assert res["armee"]["status"] == "paid"
    assert await _bal(AGT) == 100_250 and await _bal(SOL) == 100_500
    again = await ordre.run_ordre_payroll(hour=77)                 # idempotent sur une même heure
    assert again["police"]["status"] == "none" and await _bal(AGT) == 100_250
