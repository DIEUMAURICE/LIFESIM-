import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
from database import db_connection
from gameplay.family import (
    FamilyError, adopt_child, adoptions_for_user, dissolve_family,
    transfer_family_founder,
)
from webapp.routers import family_router
from webapp.routers.family_router import (
    TargetIn, adopt as api_adopt, family_dissolve, family_transfer,
)

PARENT, CHILD, SECOND_PARENT, WEB_CHILD = 6101, 6102, 6103, -6104


@pytest_asyncio.fixture
async def family_db(monkeypatch, tmp_path):
    path = str(tmp_path / "family-parity.db")
    pool = database.SQLiteConnectionPool(path, size=8)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    for uid, age, balance in (
        (PARENT, 35, 500_000), (CHILD, 19, 0),
        (SECOND_PARENT, 30, 500_000), (WEB_CHILD, 17, 0),
    ):
        await database.get_user(uid, f"player{abs(uid)}", f"Player {uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "age", age)
        await database.update_field(uid, "balance", balance)
    async def allow_free(_uid):
        return None
    monkeypatch.setattr(family_router, "_free", allow_free)
    yield
    await pool.close()


async def _create_family(name, founder_id, member_ids):
    async with db_connection() as db:
        cur = await db.execute(
            "INSERT INTO family(name,founder_id,created_at) VALUES (?,?,?)",
            (name, founder_id, 1),
        )
        family_id = int(cur.lastrowid)
        for member_id in member_ids:
            role = "Fondateur" if member_id == founder_id else "Membre"
            await db.execute(
                "INSERT INTO family_members(family_id,user_id,role,joined_at) VALUES (?,?,?,?)",
                (family_id, member_id, role, 1),
            )
        await db.commit()
    return family_id


async def test_telegram_and_web_adoption_share_cost_tree_and_limits(family_db):
    import handlers.family as bot_family

    reply = SimpleNamespace(
        from_user=SimpleNamespace(id=CHILD, full_name="Child Telegram"),
    )
    update = SimpleNamespace(
        effective_user=SimpleNamespace(id=PARENT),
        message=SimpleNamespace(reply_to_message=reply, reply_text=AsyncMock()),
    )
    handler = bot_family.cmd_adopter
    while hasattr(handler, "__wrapped__"):
        handler = handler.__wrapped__
    await handler(update, None)
    update.message.reply_text.assert_awaited_once()
    assert "Adoption réussie" in update.message.reply_text.await_args.args[0]

    result = await api_adopt(TargetIn(target_id=WEB_CHILD), SECOND_PARENT)
    assert result["cost_paid"] == 50_000
    assert result["child_id"] == WEB_CHILD

    assert (await database.get_user(PARENT))["balance"] == 450_000
    assert (await database.get_user(PARENT))["total_spent"] == 50_000
    assert (await database.get_user(SECOND_PARENT))["balance"] == 450_000
    assert (await database.get_user(SECOND_PARENT))["total_spent"] == 50_000
    assert (await adoptions_for_user(PARENT))["children"][0]["user_id"] == CHILD
    home = await family_router.home(SECOND_PARENT)
    assert home["adoptions"]["children"][0]["user_id"] == WEB_CHILD


async def test_adoption_refusals_do_not_charge_or_create_relationship(family_db):
    with pytest.raises(FamilyError) as error:
        await adopt_child(CHILD, WEB_CHILD)
    assert error.value.code == "parent_too_young"

    await database.update_field(PARENT, "balance", 49_999)
    with pytest.raises(FamilyError) as error:
        await adopt_child(PARENT, CHILD)
    assert error.value.code == "insufficient_funds"
    assert (await database.get_user(PARENT))["balance"] == 49_999

    await database.update_field(PARENT, "balance", 200_000)
    with pytest.raises(HTTPException) as error:
        await api_adopt(TargetIn(target_id=PARENT), PARENT)
    assert error.value.status_code == 400

    with pytest.raises(FamilyError) as error:
        await adopt_child(PARENT, PARENT)
    assert error.value.code == "self_adoption"
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM adoptions") as cur:
            assert (await cur.fetchone())[0] == 0


async def test_adoption_duplicate_and_five_child_cap_are_enforced_atomically(family_db):
    duplicate_results = await asyncio.gather(
        adopt_child(PARENT, CHILD), adopt_child(SECOND_PARENT, CHILD),
        return_exceptions=True,
    )
    assert sum(not isinstance(result, Exception) for result in duplicate_results) == 1
    assert sum(isinstance(result, FamilyError) for result in duplicate_results) == 1
    async with db_connection() as db:
        async with db.execute("SELECT parent_id FROM adoptions WHERE child_id=?", (CHILD,)) as cur:
            adopted_by = int((await cur.fetchone())[0])

    for offset in range(5):
        child_id = -6200 - offset
        await database.get_user(child_id, f"child{offset}", f"Child {offset}")
        await database.update_field(child_id, "registered", 1)
        await database.update_field(child_id, "age", 15)
        if offset < 4:
            await adopt_child(adopted_by, child_id)

    extra_id = -6299
    await database.get_user(extra_id, "extra", "Extra Child")
    await database.update_field(extra_id, "registered", 1)
    await database.update_field(extra_id, "age", 16)
    # The winning parent now has the initial adoption plus four additional children.
    with pytest.raises(FamilyError) as error:
        await adopt_child(adopted_by, extra_id)
    assert error.value.code == "limit_reached"


async def test_family_leadership_transfer_uses_same_service_for_api_and_telegram(family_db):
    family_id = await _create_family("Les Étoiles", PARENT, (PARENT, CHILD, SECOND_PARENT))
    api_result = await family_transfer(TargetIn(target_id=CHILD), PARENT)
    assert api_result["founder_id"] == CHILD

    import handlers.family as bot_family
    update = SimpleNamespace(
        effective_user=SimpleNamespace(id=CHILD),
        message=SimpleNamespace(
            reply_to_message=SimpleNamespace(from_user=SimpleNamespace(id=SECOND_PARENT, full_name="Second Parent")),
            reply_text=AsyncMock(),
        ),
    )
    handler = bot_family.cmd_transfertclan
    while hasattr(handler, "__wrapped__"):
        handler = handler.__wrapped__
    await handler(update, None)
    update.message.reply_text.assert_awaited_once()
    async with db_connection() as db:
        async with db.execute("SELECT founder_id FROM family WHERE family_id=?", (family_id,)) as cur:
            assert (await cur.fetchone())[0] == SECOND_PARENT
        async with db.execute("SELECT role FROM family_members WHERE family_id=? AND user_id=?", (family_id, CHILD)) as cur:
            assert (await cur.fetchone())[0] == "Ex-fondateur"
        async with db.execute("SELECT role FROM family_members WHERE family_id=? AND user_id=?", (family_id, SECOND_PARENT)) as cur:
            assert (await cur.fetchone())[0] == "Fondateur"


async def test_family_transfer_denies_non_founder_and_non_member(family_db):
    await _create_family("Les Veilleurs", PARENT, (PARENT, CHILD))
    with pytest.raises(HTTPException) as error:
        await family_transfer(TargetIn(target_id=CHILD), SECOND_PARENT)
    assert error.value.status_code == 403
    with pytest.raises(HTTPException) as error:
        await family_transfer(TargetIn(target_id=WEB_CHILD), PARENT)
    assert error.value.status_code == 404


async def test_family_dissolution_api_and_bot_remove_members_and_invites(family_db):
    first_id = await _create_family("Les Aigles", PARENT, (PARENT, CHILD))
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO family_invites(family_id,invited_id,invited_by,created_at) VALUES (?,?,?,?)",
            (first_id, WEB_CHILD, PARENT, 1),
        )
        await db.commit()
    api_result = await family_dissolve(PARENT)
    assert api_result["dissolved"] is True

    second_id = await _create_family("Les Loups", SECOND_PARENT, (SECOND_PARENT, WEB_CHILD))
    import handlers.family as bot_family
    update = SimpleNamespace(
        effective_user=SimpleNamespace(id=SECOND_PARENT),
        message=SimpleNamespace(reply_text=AsyncMock()),
    )
    handler = bot_family.cmd_dissoudrefamille
    while hasattr(handler, "__wrapped__"):
        handler = handler.__wrapped__
    await handler(update, SimpleNamespace(args=[]))
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM family WHERE family_id=?", (second_id,)) as cur:
            assert await cur.fetchone()
    await handler(update, SimpleNamespace(args=["confirmer"]))
    async with db_connection() as db:
        for table in ("family", "family_members", "family_invites"):
            async with db.execute(f"SELECT COUNT(*) FROM {table} WHERE family_id=?", (second_id,)) as cur:
                assert (await cur.fetchone())[0] == 0
