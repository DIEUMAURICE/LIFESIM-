"""Tests du filet de sécurité HTML (utils/html_guard.py) — sans dépendance à Telegram."""
import asyncio

from utils.html_guard import _wrap, prepare_text  # noqa: F401


class DefaultValue:  # imite telegram._utils.defaultvalue.DefaultValue (DEFAULT_NONE)
    value = None


def test_plain_text_untouched():
    assert prepare_text("Bonjour tout le monde") == ("Bonjour tout le monde", None)
    assert prepare_text("Usage : /don <montant>") == ("Usage : /don <montant>", None)


def test_valid_tags_switch_to_html():
    assert prepare_text("Salut <b>toi</b>") == ("Salut <b>toi</b>", "HTML")


def test_stray_symbols_escaped_when_html():
    text, mode = prepare_text("<b>R&D</b> : /don <montant> si 2 < 3")
    assert mode == "HTML"
    assert text == "<b>R&amp;D</b> : /don &lt;montant&gt; si 2 &lt; 3"


def test_existing_entities_not_double_escaped():
    text, _ = prepare_text("<b>Tom &amp; Jerry</b>")
    assert text == "<b>Tom &amp; Jerry</b>"


def test_unbalanced_tags_stripped_not_crashing():
    assert prepare_text("<b>Texte coupé <i>ici") == ("Texte coupé ici", None)
    assert prepare_text("</b>orphelin") == ("orphelin", None)


def test_link_tag_supported():
    text, mode = prepare_text('Voir <a href="https://t.me/x">ici</a>')
    assert mode == "HTML" and text == 'Voir <a href="https://t.me/x">ici</a>'


def _run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


def test_wrapper_adds_parse_mode_for_keyword_and_positional():
    calls = []

    async def send_message(self, chat_id, text, parse_mode=None, **kw):
        calls.append((text, parse_mode))

    w = _wrap(send_message, "text", 1)
    _run(w(None, chat_id=1, text="<b>a</b>", parse_mode=DefaultValue()))
    _run(w(None, 1, "<b>b</b>"))
    assert calls == [("<b>a</b>", "HTML"), ("<b>b</b>", "HTML")]


def test_wrapper_respects_explicit_parse_mode():
    calls = []

    async def send_message(self, chat_id, text, parse_mode=None, **kw):
        calls.append((text, parse_mode))

    w = _wrap(send_message, "text", 1)
    _run(w(None, chat_id=1, text="<b>z</b>", parse_mode=None))
    _run(w(None, chat_id=1, text="<b>y</b>", parse_mode="HTML"))
    assert calls == [("<b>z</b>", None), ("<b>y</b>", "HTML")]


def test_markdown_v1_converted_to_html():
    from utils.html_guard import md1_to_html
    assert md1_to_html("✊ **Résultat**") == "✊ <b>Résultat</b>"
    assert md1_to_html("*Gain* : 5") == "<b>Gain</b> : 5"
    assert md1_to_html("_italique_") == "<i>italique</i>"
    assert md1_to_html("Jean_Paul gagne") == "Jean_Paul gagne"          # pseudo avec underscore préservé
    assert md1_to_html("code `a_b` ici") == "code <code>a_b</code> ici"
    assert md1_to_html("R&D <x>") == "R&amp;D &lt;x&gt;"                # texte échappé


def test_markdown_mode_sent_as_html():
    calls = []

    async def send_message(self, chat_id, text, parse_mode=None, **kw):
        calls.append((text, parse_mode))

    w = _wrap(send_message, "text", 1)
    _run(w(None, chat_id=1, text="💤 **Bonne nuit !**", parse_mode="Markdown"))
    assert calls == [("💤 <b>Bonne nuit !</b>", "HTML")]


def test_entity_refusal_falls_back_to_plain_text():
    calls = []

    class BadRequest(Exception):
        pass

    async def send_message(self, chat_id, text, parse_mode=None, **kw):
        calls.append((text, parse_mode))
        if parse_mode:
            raise BadRequest("Can't parse entities: can't find end of the entity")
        return text

    w = _wrap(send_message, "text", 1)
    _run(w(None, chat_id=1, text="<b>Solde</b> : 5", parse_mode="HTML"))
    assert calls[-1] == ("Solde : 5", None)


def test_wrapper_caption():
    calls = []

    async def send_photo(self, chat_id, photo, caption=None, parse_mode=None, **kw):
        calls.append((caption, parse_mode))

    w = _wrap(send_photo, "caption", None)
    _run(w(None, 1, "photo", caption="<b>légende</b>", parse_mode=DefaultValue()))
    assert calls == [("<b>légende</b>", "HTML")]
