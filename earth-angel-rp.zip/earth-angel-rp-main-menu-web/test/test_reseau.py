# test/test_reseau.py — 🌐 Réseau RP entre joueurs + ⚙️ règles du jeu (robinets, interrupteurs)
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio

import database
import migrations
import handlers.reseau as rs
import utils.gamerules as gr
from test.test_ordre_ui import Recorder

A, B_ = 901, 902


@pytest_asyncio.fixture
async def rdb(monkeypatch, tmp_path):
    path = str(tmp_path / "rs.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    gr._cache.clear()
    monkeypatch.setattr(rs, "notify", AsyncMock())
    import utils.vip as vip
    monkeypatch.setattr(vip, "add_xp", AsyncMock())
    for uid in (A, B_):
        await database.get_user(uid, f"u{uid}", f"Joueur{uid}")
        await database.update_field(uid, "registered", 1)
    yield


def _update(uid):
    sent = []

    async def reply(text, **k):
        sent.append(text)

    msg = SimpleNamespace(reply_text=reply)
    return SimpleNamespace(callback_query=None, effective_user=SimpleNamespace(id=uid), effective_message=msg), sent


async def _click(uid, data):
    q = Recorder(uid, data)
    upd = SimpleNamespace(callback_query=q, effective_user=q.from_user, effective_message=q.message)
    await rs.rs_callback(upd, SimpleNamespace(user_data={}))
    return q


async def _post(uid, text="Salut le monde", platform="TikTok"):
    """Le moteur de publication est unique (handlers/social.cmd_poster) : il appelle publish_post."""
    return await rs.publish_post(uid, platform, text)


async def test_publish_then_read_in_explore(rdb):
    await _post(A)
    q = await _click(B_, "rs:feed:exp:0")
    assert "Salut le monde" in q.text
    assert any(b.startswith("rs:lk:") for b in q.buttons)


async def test_hashtags_are_extracted_indexed_and_trending(rdb):
    assert rs.extract_tags("Hello #Bienvenue #bienvenue #a #Festival_2026") == ["bienvenue", "festival_2026"]
    await _post(A, "Salut #Bienvenue")
    await _post(B_, "Moi aussi #bienvenue #fun")
    q = await _click(B_, "rs:trend")
    assert "#bienvenue" in q.text and "2 post" in q.text
    q = await _click(A, "rs:feed:#fun:0")
    assert "Moi aussi" in q.text


async def test_community_poll_vote_and_close(rdb):
    async with database.db_connection() as db:
        await db.execute("INSERT INTO social_communities(name, owner_id, created_at) VALUES ('Les Anges', ?, 0)", (A,))
        await db.execute("INSERT INTO social_community_members(community_id,user_id,role,joined_at) VALUES (1,?,'owner',0)", (A,))
        await db.execute("INSERT INTO social_community_members(community_id,user_id,role,joined_at) VALUES (1,?,'member',0)", (B_,))
        await db.commit()
    upd, sent = _update(A)
    await rs._flow_poll_o(upd, None, "Oui | Non", {"q": "On fait une fête ?"})
    assert "Sondage lancé" in sent[-1]
    await _click(B_, "rs:vt:1:0")
    await _click(B_, "rs:vt:1:1")                                  # un seul vote par joueur
    async with database.db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM social_poll_votes") as c:
            assert (await c.fetchone())[0] == 1
    await _click(A, "rs:pc:1")
    q = await _click(B_, "rs:pv:1")
    assert "clos" in q.text


async def test_like_toggle_and_no_self_like(rdb):
    await _post(A)
    async with database.db_connection() as db:
        async with db.execute("SELECT id FROM rp_posts") as c:
            pid = (await c.fetchone())[0]
    await _click(B_, f"rs:lk:{pid}:exp:0")
    async with database.db_connection() as db:
        async with db.execute("SELECT likes FROM rp_posts WHERE id=?", (pid,)) as c:
            assert (await c.fetchone())[0] == 1
    await _click(B_, f"rs:lk:{pid}:exp:0")                  # 2e clic = retire le like
    async with database.db_connection() as db:
        async with db.execute("SELECT likes FROM rp_posts WHERE id=?", (pid,)) as c:
            assert (await c.fetchone())[0] == 0
    q = await _click(A, f"rs:lk:{pid}:exp:0")               # pas d'auto-like
    assert "propre post" in q.text
    async with database.db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM rp_likes") as c:
            assert (await c.fetchone())[0] == 0


async def test_follow_fills_feed_and_notifies(rdb):
    await _post(A)
    q = await _click(B_, "rs:feed:fol:0")
    assert "Aucune publication" in q.text or "Abonne-toi" in q.text
    await _click(B_, f"rs:fp:{A}")
    q = await _click(B_, "rs:feed:fol:0")
    assert "Salut le monde" in q.text
    rs.notify.assert_awaited()


async def test_dm_roundtrip_and_unread(rdb):
    upd, _ = _update(A)
    await rs._flow_dm(upd, None, "Coucou", {"to": B_})
    q = await _click(B_, "rs:home")
    assert "Messages (1)" in " ".join(str(b) for row in q.screens[-1][1].inline_keyboard for b in [x.text for x in row])
    q = await _click(B_, f"rs:dm:{A}")
    assert "Coucou" in q.text
    q = await _click(B_, "rs:home")
    assert "Messages (" not in " ".join(x.text for row in q.screens[-1][1].inline_keyboard for x in row)


async def test_mute_blocks_writing_and_staff_only(rdb):
    q = await _click(B_, f"rs:mute:{A}:fol:0")              # B n'est pas staff
    assert "staff" in q.text.lower()
    async with database.db_connection() as db:
        await db.execute("INSERT INTO rp_mutes (user_id, until) VALUES (?,?)", (A, 4_102_444_800))
        await db.commit()
    sent = await _post(A)
    assert "sourdine" in sent[-1]


async def test_network_can_be_closed_by_staff(rdb):
    await gr.toggle_switch("rp_network", 1)
    q = await _click(A, "rs:home")
    assert "fermé" in q.text
    await gr.toggle_switch("rp_network", 1)
    q = await _click(A, "rs:home")
    assert "RÉSEAU RP" in q.text


async def test_faucet_multiplier_and_log(rdb):
    assert await gr.faucet("daily", 1000) == 1000
    await gr.set_rule("faucet:daily", "50", 1)
    assert await gr.faucet("daily", 1000) == 500
    await gr.set_rule("faucet:daily", "0", 1)
    assert await gr.faucet("daily", 1000) == 0
    assert await gr.faucet("daily", -300) == -300            # les dépenses ne sont jamais touchées
    log = await gr.recent_changes()
    assert [r["new_value"] for r in log][:2] == ["0", "50"]


async def test_real_payments_switch_default_on(rdb):
    assert await gr.switch_on("real_payments") is True
    await gr.toggle_switch("real_payments", 1)
    assert await gr.switch_on("real_payments") is False
