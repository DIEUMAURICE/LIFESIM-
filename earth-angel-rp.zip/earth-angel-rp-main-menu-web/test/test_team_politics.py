# test/test_team_politics.py — hiérarchie, chats d'équipe, politique réservée aux Admins N1
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from types import SimpleNamespace

import pytest
import pytest_asyncio

import database
import migrations
import utils.factions as factions
import utils.ordre as ordre
import utils.roles as roles
import utils.team as team

N1, N1B, GL, EMP, EMP2, PDG, BOSS, CIV, DGP = 701, 702, 703, 704, 705, 706, 707, 708, 709
USERS = (N1, N1B, GL, EMP, EMP2, PDG, BOSS, CIV, DGP)
ROLES = {N1: "ADMIN_N1", N1B: "ADMIN_N1", GL: "GAME_LEADER"}


@pytest_asyncio.fixture
async def tdb(monkeypatch, tmp_path):
    path = str(tmp_path / "team.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()

    async def role_of(uid):
        return ROLES.get(uid, "PLAYER")

    monkeypatch.setattr(roles, "role_of", role_of)
    team._LAST_SENT.clear()
    for uid in USERS:
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 1_000_000)
    yield


async def _faction(uid, faction, rank=0, score=0):
    async with database.db_connection() as db:
        await db.execute("INSERT OR REPLACE INTO faction_members(user_id, faction, rank, activity_score, joined_at) VALUES (?,?,?,?,0)",
                         (uid, faction, rank, score))
        await db.commit()


async def _company(owner, members):
    async with database.db_connection() as db:
        cur = await db.execute("INSERT INTO companies(name, owner_id, sector, created_at) VALUES ('Acme', ?, 'tech', 0)", (owner,))
        cid = cur.lastrowid
        await db.execute("INSERT INTO company_members(user_id, company_id, poste, activity_score, joined_at) VALUES (?,?,?,?,0)",
                         (owner, cid, "PDG", 99))
        for uid, poste, score in members:
            await db.execute("INSERT INTO company_members(user_id, company_id, poste, activity_score, joined_at) VALUES (?,?,?,?,0)",
                             (uid, cid, poste, score))
        await db.commit()
    return cid


# ─── Hiérarchie ──────────────────────────────────────────────────────────────
async def test_faction_roster_visibility(tdb):
    await _faction(DGP, "mairie", 3, 40)       # directeur = direction
    await _faction(EMP, "mairie", 0, 7)
    r = await team.roster(EMP, "faction")
    assert not r["can_see_activity"]                                   # un employé ne voit pas l'activité
    names = [m["user_id"] for m in r["members"]]
    assert names == [DGP, EMP]                                         # classé par grade
    assert r["members"][0]["username"] and r["members"][0]["title"] == "Directeur"
    r = await team.roster(DGP, "faction")
    assert r["can_see_activity"] and {m["user_id"]: m["activity"] for m in r["members"]}[EMP] == 7
    r = await team.roster(CIV, "faction")
    assert r["error"]


async def test_company_roster(tdb):
    await _company(PDG, [(EMP, "Employé", 12), (EMP2, "Directeur", 30)])
    r = await team.roster(EMP, "company")
    assert [m["user_id"] for m in r["members"]][0] == PDG and not r["can_see_activity"]
    assert r["members"][0]["title"].startswith("PDG")
    for boss in (PDG, EMP2):
        assert (await team.roster(boss, "company"))["can_see_activity"]
    assert (await team.roster(CIV, "company"))["error"]


async def test_roster_of_police_and_sante(tdb):
    async with database.db_connection() as db:
        await ordre._set_post(db, EMP, "police", "sud", "agent")
        await ordre._set_post(db, DGP, "police", "central", "dg")
        await db.execute("INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) VALUES (?,'sante',0,0,0)", (EMP2,))
        await db.execute("INSERT INTO sante_staff(user_id, hospital_id, post, on_duty, since) VALUES (?,?,?,0,0)", (EMP2, "grand", "medecin"))
        await db.commit()
    r = await team.roster(EMP, "faction")
    assert r["members"][0]["title"].startswith("Directeur") and r["members"][1]["title"] == "Agent"
    assert r["members"][1]["place"] and not r["can_see_activity"]
    assert (await team.roster(DGP, "faction"))["can_see_activity"]
    r = await team.roster(EMP2, "faction")
    assert r["members"][0]["title"] == "Médecin"


# ─── Chats ───────────────────────────────────────────────────────────────────
async def test_faction_chat_shows_name_and_post(tdb):
    await _faction(EMP, "mairie", 1)
    await _faction(EMP2, "mairie", 3)
    await _faction(PDG, "police", 0)
    chans = dict(await team.my_channels(EMP))
    assert "f:mairie" in chans and team.GOV_CHANNEL in chans
    ok, _ = await team.enter(EMP, "f:police")                           # pas sa faction
    assert not ok
    ok, _ = await team.enter(EMP, "f:mairie")
    assert ok and await team.get_channel(EMP) == "f:mairie"
    prep = await team.prepare_message(EMP, "Bonjour l'équipe")
    assert prep["recipients"] == [EMP2]                                 # la police ne reçoit pas le chat de la mairie
    assert prep["name"] == "User704"
    assert "Secrétaire" in prep["post"]                                 # nom + poste affichés
    assert prep["text"] == "Bonjour l'équipe"
    assert await team.prepare_message(CIV, "salut") is None             # hors chat : rien


async def test_government_channel_reaches_every_faction(tdb):
    await _faction(EMP, "mairie", 0)
    await _faction(EMP2, "justice", 0)
    await _faction(PDG, "police", 0)
    await _faction(CIV, "sante", 0)
    await team.enter(EMP, team.GOV_CHANNEL)
    prep = await team.prepare_message(EMP, "Réunion d'État")
    assert set(prep["recipients"]) == {EMP2, PDG, CIV}
    assert "Administration" in prep["post"]                             # la faction est précisée côté gouvernement


async def test_company_chat_and_mute_and_limits(tdb):
    cid = await _company(PDG, [(EMP, "Employé", 0), (EMP2, "Employé", 0)])
    assert (await team.my_channels(EMP))[0][0] == f"c:{cid}"
    await team.enter(EMP, f"c:{cid}")
    prep = await team.prepare_message(EMP, "Salut la boîte")
    assert set(prep["recipients"]) == {PDG, EMP2} and "Employé" in prep["post"]
    assert "Acme" in prep["title"]
    team._LAST_SENT.clear()
    assert await team.toggle_mute(EMP2, f"c:{cid}") is True            # sourdine
    prep = await team.prepare_message(EMP, "Encore")
    assert prep["recipients"] == [PDG]
    err = await team.prepare_message(EMP, "trop vite")                  # anti-spam
    assert "error" in err
    team._LAST_SENT.clear()
    assert "error" in await team.prepare_message(EMP, "x" * 600)         # trop long
    await team.leave(EMP)
    assert await team.prepare_message(EMP, "plus de chat") is None
    # un employé licencié perd l'accès
    await team.enter(EMP2, f"c:{cid}")
    async with database.db_connection() as db:
        await db.execute("DELETE FROM company_members WHERE user_id=?", (EMP2,))
        await db.commit()
    team._LAST_SENT.clear()
    res = await team.prepare_message(EMP2, "je suis encore là ?")
    assert "plus accès" in res["error"] and await team.get_channel(EMP2) is None


# ─── Politique & rôles ───────────────────────────────────────────────────────
async def test_roles(tdb):
    # can_play = participation à la politique / aux élections (le reste du jeu est ouvert à tous)
    assert await roles.can_play(CIV) and await roles.can_play(N1)
    assert not await roles.can_play(GL)
    assert await roles.is_politician(N1) and not await roles.is_politician(CIV) and not await roles.is_politician(GL)


async def test_politician_and_player_decorators(tdb):
    replies = []

    async def reply(text, **k):
        replies.append(text)

    def upd(uid):
        return SimpleNamespace(effective_user=SimpleNamespace(id=uid), callback_query=None,
                               effective_message=SimpleNamespace(reply_text=reply))

    calls = []

    @roles.politician_only
    async def only_n1(update, context):
        calls.append(update.effective_user.id)

    @roles.players_only
    async def for_players(update, context):
        calls.append(update.effective_user.id)

    await only_n1(upd(N1), None)
    await only_n1(upd(CIV), None)
    await only_n1(upd(GL), None)
    await for_players(upd(CIV), None)
    await for_players(upd(N1), None)
    await for_players(upd(GL), None)
    assert calls == [N1, CIV, N1]
    assert len(replies) == 3 and "Admins N1" in replies[0]


async def test_elected_president_heads_administration(tdb):
    import handlers.political as pol
    await _faction(DGP, "mairie", 3)
    await _faction(CIV, "police", 0)
    async with database.db_connection() as db:
        await db.execute("INSERT INTO elections(poste, started_by, started_at, ends_at, status) VALUES ('Président', ?, 0, 1, 'open')", (N1,))
        for voter in (EMP, EMP2, PDG, BOSS, CIV):
            await db.execute("INSERT INTO votes(election_id, voter_id, candidate_id, voted_at) VALUES (1, ?, ?, 0)", (voter, N1))
        await db.commit()
    await pol.auto_depouiller(1, "Président")
    m = await factions.get_membership(N1)
    assert m["faction"] == "mairie" and m["rank_name"] == "Président"
    # un second président remplace le premier, qui redevient simple directeur
    await roles.install_president(N1B)
    assert (await factions.get_membership(N1B))["rank_name"] == "Président"
    assert (await factions.get_membership(N1))["rank_name"] != "Président"
    # le président (N1 ou joueur) dirige l'Administration : il voit l'activité de ses employés
    assert (await team.roster(N1B, "faction"))["can_see_activity"]


# ─── Gouvernement unifié : Président + ministres = grades de l'Administration ───────────────────
async def test_minister_is_administration_grade_and_directs_a_faction(tdb):
    await roles.install_president(N1)
    ok, label = await roles.install_minister(N1, EMP, "Santé")
    assert ok and "Santé" in label
    m = await factions.get_membership(EMP)
    assert m["faction"] == "mairie" and m["rank_name"] == "Ministre"
    assert await roles.minister_of(EMP) == "Santé"
    assert await roles.can_direct_faction(EMP, "sante")
    assert not await roles.can_direct_faction(EMP, "police")        # pas son ministère
    assert not await roles.can_direct_faction(CIV, "sante")
    assert await roles.can_direct_faction(GL, "police")             # Game Leader : toutes les factions
    # un nouveau titulaire remplace l'ancien, qui reste directeur de l'Administration
    await roles.install_minister(N1, EMP2, "Santé")
    assert (await factions.get_membership(EMP))["rank_name"] == "Directeur"
    assert await roles.minister_of(EMP) is None
    # le Président ne peut pas être ministre ; on ne nomme pas un ministère inconnu
    assert not (await roles.install_minister(N1B, N1, "Justice"))[0]
    assert not (await roles.install_minister(N1, CIV, "Éducation"))[0]


async def test_minister_leaves_previous_faction_and_can_be_revoked(tdb):
    await _faction(CIV, "police", 0)
    await roles.install_president(N1)
    await roles.install_minister(N1, CIV, "Intérieur")
    assert (await factions.get_membership(CIV))["faction"] == "mairie"
    assert await roles.remove_minister("Intérieur") == CIV
    assert await roles.minister_of(CIV) is None
    assert (await factions.get_membership(CIV))["rank_name"] == "Directeur"
    assert await roles.remove_minister("Intérieur") is None         # déjà vacant


async def test_president_end_of_term_and_destitution_path(tdb):
    import handlers.political as pol
    async with database.db_connection() as db:
        await db.execute("INSERT INTO political_offices(poste, occupant_id, elected_at, election_id, last_activity) VALUES ('Président', ?, 0, 1, 0)", (N1,))
        await db.commit()
    await roles.install_president(N1)
    assert await roles.is_president(N1)
    assert await roles.remove_president(N1)
    assert not await roles.is_president(N1)
    assert (await factions.get_membership(N1))["rank_name"] == "Directeur"
    # les anciens postes (Maire, Député…) ne sont plus des postes
    import config
    assert config.POLITICAL_POSTS == ["Président"] and set(config.ELECTION_COST) == {"Président"}
    assert set(config.CABINET_POSITIONS) == {"Intérieur", "Défense", "Justice", "Santé", "Économie"}


async def test_economy_minister_sets_tax_factor(tdb):
    import handlers.economy as eco
    import utils.state_settings as ss
    from utils import treasury as tr
    ss._tax_factor = 1.0
    try:
        await roles.install_president(N1)
        await roles.install_minister(N1, EMP, "Économie")
        await roles.install_minister(N1, EMP2, "Santé")
        assert await tr.can_set_tax(EMP) and await tr.can_set_tax(N1)
        assert not await tr.can_set_tax(EMP2) and not await tr.can_set_tax(CIV)
        base = eco._monthly_tax_rate(300_000)                       # tranche 2 %
        assert base == 2
        ok, _ = await ss.set_tax_factor(1.5)
        assert ok and eco._monthly_tax_rate(300_000) == 3
        ok, msg = await ss.set_tax_factor(0.5)                      # un seul changement par jour de jeu
        assert not ok and eco._monthly_tax_rate(300_000) == 3
        assert ss.clamp_factor(9) == 1.5 and ss.clamp_factor(0) == 0.5 and ss.clamp_factor(1.1) == 1.0
        ss._tax_factor = 1.0
        assert await ss.refresh() == 1.5                            # persisté en base
    finally:
        ss._tax_factor = 1.0


# ─── Destitution, quorum, mandat, lois et référendums ────────────────────────────────────────────
async def _expire_votes(motion_id):
    async with database.db_connection() as db:
        await db.execute("UPDATE motions SET ends_at=0 WHERE motion_id=?", (motion_id,))
        await db.commit()


async def _motion_status(motion_id):
    async with database.db_connection() as db:
        async with db.execute("SELECT status FROM motions WHERE motion_id=?", (motion_id,)) as cur:
            return (await cur.fetchone())[0]


async def test_motion_full_cycle_removes_a_minister(tdb):
    import utils.politics as pol
    await roles.install_president(N1)
    await roles.install_minister(N1, EMP, "Santé")
    ok, msg, _ = await pol.check_motion(CIV, EMP)
    assert not ok and "protégé" in msg                                   # immunité juste après la nomination
    async with database.db_connection() as db:
        await db.execute("UPDATE cabinet_positions SET appointed_at=0 WHERE position='Santé'")
        await db.commit()
    ok, _, info = await pol.check_motion(EMP, EMP)
    assert not ok                                                        # pas contre soi-même
    ok, _, info = await pol.check_motion(CIV, EMP)
    assert ok and info["label"] == "Ministre de Santé"
    mid = await pol.create_motion(CIV, EMP)
    assert not (await pol.check_motion(DGP, EMP))[0]                     # une motion à la fois par cible
    assert not (await pol.sign_motion(CIV, EMP))[0]                      # déjà signé (l'initiateur signe d'office)
    assert not (await pol.sign_motion(EMP, EMP))[0]                      # la cible ne signe pas
    for uid in (801, 802, 803):
        assert (await pol.sign_motion(uid, EMP))[0]
    ok, msg = await pol.sign_motion(804, EMP)
    assert ok and "ouvert" in msg and await _motion_status(mid) == "voting"
    assert not (await pol.vote_motion(EMP, "pour"))[0]                   # la cible ne vote pas
    for uid in range(1, 7):
        assert (await pol.vote_motion(uid, "pour"))[0]
    assert not (await pol.vote_motion(1, "contre"))[0]                   # un seul vote par joueur
    for uid in (11, 12):
        await pol.vote_motion(uid, "contre")
    await _expire_votes(mid)
    await pol.close_motions()
    assert await _motion_status(mid) == "accepted"
    assert await roles.minister_of(EMP) is None
    assert (await factions.get_membership(EMP))["rank_name"] == "Directeur"
    assert "destitution" in {e[0] for e in await pol.recent_events(20)}


async def test_motion_needs_quorum_and_expires_without_signatures(tdb):
    import utils.politics as pol
    await roles.install_president(N1)
    await roles.install_minister(N1, EMP, "Justice")
    async with database.db_connection() as db:
        await db.execute("UPDATE cabinet_positions SET appointed_at=0")
        await db.commit()
    mid = await pol.create_motion(CIV, EMP)
    for uid in (801, 802, 803, 804):
        await pol.sign_motion(uid, EMP)
    for uid in (1, 2, 3):                                                # 3 votes < quorum de 5
        await pol.vote_motion(uid, "pour")
    await _expire_votes(mid)
    await pol.close_motions()
    assert await _motion_status(mid) == "rejected" and await roles.minister_of(EMP) == "Justice"
    ok, msg, _ = await pol.check_motion(DGP, EMP)
    assert not ok and "échoué récemment" in msg                          # délai avant une nouvelle motion
    # une motion sans signatures expire (avant, elle bloquait la cible à vie)
    await roles.install_minister(N1, EMP2, "Défense")
    async with database.db_connection() as db:
        await db.execute("UPDATE cabinet_positions SET appointed_at=0")
        await db.commit()
    mid2 = await pol.create_motion(CIV, EMP2)
    await _expire_votes(mid2)
    await pol.close_motions()
    assert await _motion_status(mid2) == "expired"
    assert not (await pol.sign_motion(DGP, EMP2))[0]


async def test_president_needs_sixty_percent_to_be_removed(tdb):
    import utils.politics as pol
    async with database.db_connection() as db:
        await db.execute("INSERT INTO political_offices(poste, occupant_id, elected_at, election_id) VALUES ('Président', ?, 0, 1)", (N1,))
        await db.commit()
    await roles.install_president(N1)
    mid = await pol.create_motion(CIV, N1)
    for uid in (801, 802, 803, 804):
        await pol.sign_motion(uid, N1)
    for uid in range(1, 12):
        await pol.vote_motion(uid, "pour")                               # 11 pour
    for uid in range(21, 30):
        await pol.vote_motion(uid, "contre")                             # 9 contre = 55 %
    await _expire_votes(mid)
    await pol.close_motions()
    assert await _motion_status(mid) == "rejected" and await roles.is_president(N1)


async def test_president_term_expires(tdb):
    import utils.politics as pol
    async with database.db_connection() as db:
        await db.execute("INSERT INTO political_offices(poste, occupant_id, elected_at, election_id) VALUES ('Président', ?, 1, 1)", (N1,))
        await db.commit()
    await roles.install_president(N1)
    assert await pol.expire_president_term() == N1
    assert not await roles.is_president(N1)
    assert (await factions.get_membership(N1))["rank_name"] == "Directeur"


async def test_election_tie_and_quorum_cancel_the_vote(tdb):
    import handlers.political as pol
    async with database.db_connection() as db:
        for eid, votes in ((1, [(EMP, N1), (EMP2, N1)]),                 # 2 votes < quorum 3
                           (2, [(EMP, N1), (EMP2, N1B), (PDG, N1), (BOSS, N1B)])):   # égalité 2–2
            await db.execute("INSERT INTO elections(poste, started_by, started_at, ends_at, status) VALUES ('Président', ?, 0, 1, 'open')", (N1,))
            for cand in (N1, N1B):
                await db.execute("INSERT INTO candidates(election_id, user_id) VALUES (?,?)", (eid, cand))
            for voter, cand in votes:
                await db.execute("INSERT INTO votes(election_id, voter_id, candidate_id, voted_at) VALUES (?,?,?,0)", (eid, voter, cand))
        await db.commit()
    await pol.auto_depouiller(1, "Président")
    await pol.auto_depouiller(2, "Président")
    async with database.db_connection() as db:
        async with db.execute("SELECT status FROM elections ORDER BY id") as cur:
            assert [r[0] for r in await cur.fetchall()] == ["cancelled", "cancelled"]
        async with db.execute("SELECT COUNT(*) FROM political_offices") as cur:
            assert (await cur.fetchone())[0] == 0


async def test_maintenance_enacts_laws_and_constitution_referendum(tdb):
    import handlers.political as pol
    async with database.db_connection() as db:
        for title, pour, contre in (("Loi A", 2, 0), ("Loi B", 5, 2), ("Loi C", 2, 5)):
            await db.execute("INSERT INTO laws(title, description, proposer_id, status, votes_for, votes_against, required_majority, created_at, voting_ends_at) "
                             "VALUES (?, 'x', ?, 'voting', ?, ?, 0.5, 0, 1)", (title, EMP, pour, contre))
        await db.execute("INSERT INTO referendums(question, proposer_id, created_at, voting_ends_at, votes_for, votes_against, required_majority, payload) "
                         "VALUES ('Modifier la constitution : N', ?, 0, 1, 7, 3, 0.6, 'constitution:Nouveau texte complet')", (EMP,))
        await db.execute("INSERT INTO referendums(question, proposer_id, created_at, voting_ends_at, votes_for, votes_against, required_majority, payload) "
                         "VALUES ('Modifier la constitution : M', ?, 0, 1, 5, 5, 0.6, 'constitution:Texte refusé')", (EMP2,))
        await db.commit()
    await pol.political_maintenance()
    async with database.db_connection() as db:
        async with db.execute("SELECT title, status FROM laws") as cur:
            assert dict(await cur.fetchall()) == {"Loi A": "rejected", "Loi B": "passed", "Loi C": "rejected"}
        async with db.execute("SELECT status FROM referendums ORDER BY id") as cur:
            assert [r[0] for r in await cur.fetchall()] == ["accepted", "rejected"]
        async with db.execute("SELECT text, amended_by FROM constitution WHERE id=1") as cur:
            assert tuple(await cur.fetchone()) == ("Nouveau texte complet", EMP)
