# test/test_treasury_esprit.py — 🏛️ Trésor public, 🏭 production horaire
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

import pytest
import pytest_asyncio

import config_chain as cc
import database
import migrations
import utils.payroll as prod
from database import db_connection
from utils import treasury as tr
from utils.factions import coffre_balance


@pytest_asyncio.fixture
async def tdb(monkeypatch, tmp_path):
    path = str(tmp_path / "tr.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    for uid in (1, 2, 3):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 1_000_000)
    yield


async def _admin_member(uid, rank):
    async with db_connection() as db:
        await db.execute("INSERT INTO faction_members(user_id, faction, rank, joined_at) VALUES (?,?,?,0)",
                         (uid, "mairie", rank))
        await db.commit()


async def test_spending_with_sink_feeds_treasury_only(tdb):
    await database.update_balance(1, -50_000, sink="etudes")
    await database.update_balance(1, -1_000)                       # sans sink : rien pour le Trésor
    assert await tr.balance() == 50_000
    rep = await tr.report(1)
    assert rep["in"] == [("etudes", 50_000)]


async def test_only_president_and_ministers_can_grant(tdb):
    await database.update_balance(1, -200_000, sink="casino")
    ok, _ = await tr.grant(2, "police", 10_000)
    assert not ok                                                  # pas dans l'Administration
    await _admin_member(3, 1)
    ok, _ = await tr.grant(3, "police", 10_000)
    assert not ok                                                  # rang trop bas
    await _admin_member(1, 4)
    ok, _ = await tr.grant(1, "police", 10_000)
    assert not ok                                                  # un simple directeur ne distribue plus
    await _admin_member(2, 6)                                      # Président
    ok, _ = await tr.grant(2, "police", 10_000)
    assert ok
    assert await coffre_balance("police") == 10_000
    assert await tr.balance() == 190_000


async def test_minister_grants_only_to_own_ministry(tdb):
    await database.update_balance(1, -200_000, sink="casino")
    await _admin_member(2, 5)
    async with db_connection() as db:
        await db.execute("INSERT INTO cabinet_positions(position, occupant_id, appointed_by, appointed_at) "
                         "VALUES ('Défense', 2, 1, 0)")
        await db.commit()
    assert await tr.grant_targets(2) == ["armee"]
    assert not (await tr.grant(2, "police", 10_000))[0]            # pas son ministère
    assert (await tr.grant(2, "armee", 10_000))[0]
    assert await coffre_balance("armee") == 10_000


async def test_grant_guards(tdb):
    await database.update_balance(1, -100_000, sink="casino")
    await _admin_member(2, 6)
    assert not (await tr.grant(2, "police", 500))[0]               # trop petit
    assert not (await tr.grant(2, "police", 60_000))[0]            # > 50 % du Trésor
    assert not (await tr.grant(2, "inconnue", 10_000))[0]
    assert (await tr.grant(2, "mairie", 20_000))[0]                # alimenter son propre coffre


async def test_auto_funding_does_not_drain_treasury_when_administration_leads(tdb):
    await database.update_balance(1, -100_000, sink="casino")
    await _admin_member(2, 6)
    await prod.fund_factions(day=5)
    assert await tr.balance() == 100_000


async def test_hourly_production_matches_daily_total_and_is_idempotent(tdb, monkeypatch):
    sent = []

    async def fake_notify(uid, title, msg, kind="info"):
        sent.append(title)

    monkeypatch.setattr(prod, "notify", fake_notify)
    async with db_connection() as db:
        await db.execute("INSERT INTO companies(name, owner_id, sector, treasury, level, created_at) "
                         "VALUES ('Resto', 2, 'Alimentation', 500000, 1, 0)")
        await db.execute("INSERT INTO company_members(user_id, company_id, poste, joined_at) VALUES (2,1,'PDG',0)")
        await db.commit()
    d = list(cc.sector_depts("Alimentation"))
    await prod.record_activity(1, 400, day=100, dept=d[0])
    await prod.record_activity(1, 400, day=100, dept=d[1])
    for h in range(24):
        await prod.produce_company(1, 100, h)
    again = await prod.produce_company(1, 100, 23)
    assert again["produced"] == 0                                  # heure déjà produite
    async with db_connection() as db:
        async with db.execute("SELECT produced FROM company_production_log WHERE company_id=1 AND day=100") as c:
            assert (await c.fetchone())[0] == 36
    assert sent == ["🏭 Bilan du jour — Resto"]                    # un seul bilan, en fin de journée


async def test_duty_is_credited_continuously_and_never_twice(tdb):
    from utils import duty
    async with db_connection() as db:
        await db.execute("INSERT INTO companies(name, owner_id, sector, treasury, level, created_at) "
                         "VALUES ('Resto', 2, 'Alimentation', 200000, 1, 0)")
        await db.execute("INSERT INTO company_members(user_id, company_id, poste, joined_at) VALUES (2,1,'PDG',0)")
        await db.execute("INSERT INTO work_duty(user_id, since) VALUES (2, ?)", (database.now() - 7200,))
        await db.commit()
    for uid, since, credited in await duty.running():
        total = duty.points_for(database.now() - since)
        await duty.mark_credited(uid, total)
        await duty.credit_activity(uid, "company", 1, total - credited)
    for uid, since, credited in await duty.running():
        assert duty.points_for(database.now() - since) - credited <= 0      # pas de double crédit
    ok, _elapsed, left = await duty.stop_duty(2)
    assert ok and left == 0
    diag = await prod.diagnose(1)
    assert diag["pools"].get("", 0) > 0 and diag["lines"]


def test_button_layout_gives_long_labels_their_own_row():
    from types import SimpleNamespace as B
    from utils.ui import layout
    rows = layout([B(text="🏠 Maison"), B(text="🚗 Garage"), B(text="🛠️ Réparer un véhicule abîmé"), B(text="OK")])
    assert [len(r) for r in rows] == [2, 1, 1]


async def _company_ready():
    async with db_connection() as db:
        await db.execute("INSERT INTO companies(name, owner_id, sector, treasury, level, created_at) "
                         "VALUES ('Resto', 2, 'Alimentation', 500000, 1, 0)")
        await db.execute("INSERT INTO company_members(user_id, company_id, poste, joined_at) VALUES (2,1,'PDG',0)")
        await db.commit()
    d = list(cc.sector_depts("Alimentation"))
    await prod.record_activity(1, 400, day=100, dept=d[0])
    await prod.record_activity(1, 400, day=100, dept=d[1])


async def test_bot_roles_can_be_closed_by_staff(tdb, monkeypatch):
    from utils import chain, gamerules as gr
    monkeypatch.setattr(prod, "notify", lambda *a, **k: None)
    gr._cache.clear()
    await _company_ready()
    await gr.set_rule("bot:npc_orders", "0", 1)                    # marché national fermé
    r = await prod.produce_company(1, 100)
    assert r["produced"] > 0 and r["sold"] == 0                    # la production reste en stock pour les joueurs
    await gr.set_rule("bot:npc_counter", "0", 1)
    ok, msg = await chain.counter_sell(1, next(iter(cc.INTRANTS)), 1)
    assert not ok and "fermé" in msg


async def test_closed_national_supplier_blocks_production_without_intrants(tdb, monkeypatch):
    from utils import gamerules as gr
    monkeypatch.setattr(prod, "notify", lambda *a, **k: None)
    gr._cache.clear()
    await _company_ready()
    await gr.set_rule("bot:npc_supply", "0", 1)
    r = await prod.produce_company(1, 100)
    assert r["produced"] == 0                                      # plus d'intrants du bot : il faut les joueurs
    diag = await prod.diagnose(1, 100)
    assert diag["lines"] and diag["lines"][0]["reason"] in ("supply", "points", "treasury")


async def test_bot_activity_is_accounted_and_intrants_feed_the_treasury(tdb, monkeypatch):
    monkeypatch.setattr(prod, "notify", lambda *a, **k: None)
    await _company_ready()
    await prod.produce_company(1, 100)
    rep = await tr.report(1)
    assert ("intrants", rep["in"][0][1]) in rep["in"] and rep["total_in"] > 0


async def test_shop_orders_are_idempotent_refundable_and_limited(tdb):
    from utils import shop
    assert await shop.seed() > 0 and await shop.seed() == 0
    delivered = []

    async def ok(kind, key, target):
        delivered.append(key)
        return "ok"

    async def boom(kind, key, target):
        raise RuntimeError("effet cassé")

    oid, new = await shop.create_order("CH1", 1, 1, "boost_xp2", "shop", 50)
    assert new and (await shop.create_order("CH1", 1, 1, "boost_xp2", "shop", 50)) == (oid, False)   # doublon Telegram
    assert (await shop.deliver(oid, ok))[0] == "delivered" and (await shop.deliver(oid, ok))[0] == "already"
    assert delivered == ["boost_xp2"]                                                                  # livré une seule fois
    bad, _ = await shop.create_order("CH2", 1, 1, "boost_coins2", "shop", 50)
    assert (await shop.deliver(bad, boom))[0] == "failed"
    assert (await shop.get_item("boost_coins2"))["sold"] == 0                                         # stock rendu
    code = await shop.create_custom("Couronne", 30, stock=1)
    a, _ = await shop.create_order("CH3", 1, 1, code, "custom", 30)
    b, _ = await shop.create_order("CH4", 2, 2, code, "custom", 30)

    async def custom(kind, key, target):
        return await shop.grant_cosmetic(target, key)

    assert (await shop.deliver(a, custom))[0] == "delivered" and (await shop.deliver(b, custom))[0] == "soldout"


async def test_shop_prices_deal_welcome_and_loyalty(tdb):
    from utils import shop
    await shop.seed()
    starter, xp = await shop.get_item("pack_starter"), await shop.get_item("boost_xp2")
    assert shop.price(starter, welcome=True)[0] < shop.price(starter)[0]
    assert shop.price(xp, deal="boost_xp2")[1] == shop.DEAL_PCT
    await shop.set_field("boost_xp2", "promo_pct", 30)
    assert shop.price(await shop.get_item("boost_xp2"), deal="boost_xp2")[1] == 30            # la meilleure remise seule
    assert shop.deal_key(await shop.items()) not in {k for k in shop.MONEY_ITEMS}
    oid, _ = await shop.create_order("CH5", 1, 1, "pack_prestige", "shop", 500)

    async def ok(kind, key, target):
        return "ok"

    await shop.deliver(oid, ok)
    loy = await shop.loyalty(1)
    assert loy["spent"] == 500 and sum(t["reached"] for t in loy["tiers"]) == 3
    assert (await shop.claim_reward(1, 0, ok))[0] and not (await shop.claim_reward(1, 0, ok))[0]
