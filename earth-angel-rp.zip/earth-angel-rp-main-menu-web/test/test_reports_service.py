# test/test_reports_service.py — Signalements : service partagé bot/API + routes
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
from gameplay import reports as svc
from webapp.routers import reports_router as router

P1, P2, STAFF = 1201, 1202, 1203


@pytest_asyncio.fixture
async def rdb(monkeypatch, tmp_path):
    path = str(tmp_path / "reports.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=3))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    for uid in (P1, P2, STAFF):
        await database.get_user(uid, f"u{uid}", f"User{uid}")

    async def role(uid):
        return "ADMIN_N1" if uid == STAFF else "PLAYER"

    monkeypatch.setattr(svc, "get_user_role_async", role)
    yield


async def test_submit_rules(rdb):
    assert (await svc.submit(P1, "bug", "abc"))["reason"] == "too_short"
    ok = await svc.submit(P1, "bug", "Un vrai problème ici")
    assert ok["ok"] and ok["report_type"] == "bug"
    again = await svc.submit(P1, "bug", "Un autre problème")
    assert again["reason"] == "cooldown" and again["remaining"] > 0
    assert [r["message"] for r in await svc.get_user_reports(P1)] == ["Un vrai problème ici"]


async def test_unknown_type_becomes_other_and_staff_skips_cooldown(rdb):
    assert (await svc.submit(P2, "nimportequoi", "Texte suffisant"))["report_type"] == "other"
    assert (await svc.submit(STAFF, "bug", "Premier message"))["ok"]
    assert (await svc.submit(STAFF, "bug", "Deuxième message"))["ok"]


async def test_player_report_rules(rdb):
    assert (await svc.submit(P1, None, "Il triche beaucoup", P1))["reason"] == "self_target"
    assert (await svc.submit(P1, None, "Il triche beaucoup", 999999))["reason"] == "unknown_target"
    ok = await svc.submit(P1, None, "Il m'insulte tout le temps", P2)
    assert ok["ok"] and ok["report_type"] == "harassment"
    # même cible dans l'heure : refusé avant même le cooldown
    assert (await svc.submit(P1, None, "Encore une fois", P2))["reason"] == "recent_target"
    assert svc.classify_player_report("il triche") == "exploit"


async def test_staff_handling_notifies_reporter(rdb, monkeypatch):
    await svc.submit(P1, "bug", "Un vrai problème ici")
    rid = (await svc.get_user_reports(P1))[0]["id"]
    notify = AsyncMock()
    monkeypatch.setattr(svc, "add_notification", notify)
    assert await svc.set_status(rid, "resolved", "Corrigé") == P1
    notify.assert_awaited_once()
    assert notify.await_args.args[0] == P1 and "résolu" in notify.await_args.args[1]
    row = (await svc.get_user_reports(P1))[0]
    assert row["status"] == "resolved" and row["admin_response"] == "Corrigé"
    assert await svc.set_status(9999, "resolved") is None
    with pytest.raises(ValueError):
        await svc.set_status(rid, "bogus")
    stats = await svc.get_report_stats()
    assert stats["resolved"] == 1 and stats["by_type"] == {"bug": 1}


async def test_router_staff_guard_and_error_mapping(monkeypatch):
    monkeypatch.setattr(router.reports_service, "is_staff", AsyncMock(return_value=False))
    for call in (router.staff_list("pending", user_id=5),
                 router.staff_handle(1, router.HandleIn(status="resolved"), user_id=5)):
        with pytest.raises(HTTPException) as exc:
            await call
        assert exc.value.status_code == 403
    monkeypatch.setattr(router.reports_service, "submit",
                        AsyncMock(return_value={"ok": False, "reason": "cooldown", "remaining": 60}))
    with pytest.raises(HTTPException) as exc:
        await router.submit(router.ReportIn(message="x" * 10), user_id=5)
    assert exc.value.status_code == 429
    monkeypatch.setattr(router.reports_service, "submit",
                        AsyncMock(return_value={"ok": False, "reason": "too_short"}))
    with pytest.raises(HTTPException) as exc:
        await router.submit(router.ReportIn(message="x"), user_id=5)
    assert exc.value.status_code == 422


async def test_router_staff_handle_not_found(monkeypatch):
    monkeypatch.setattr(router.reports_service, "is_staff", AsyncMock(return_value=True))
    monkeypatch.setattr(router.reports_service, "set_status", AsyncMock(return_value=None))
    with pytest.raises(HTTPException) as exc:
        await router.staff_handle(7, router.HandleIn(status="resolved"), user_id=5)
    assert exc.value.status_code == 404


def test_report_routes_registered():
    from webapp.server import app
    paths = {r.path for r in app.routes}
    assert {"/api/reports", "/api/reports/staff", "/api/reports/staff/{report_id}"} <= paths
