# test/test_db_primitives.py — connexion rendue au pool, DeferredReply, Outbox
import asyncio
import pytest
import database as d


@pytest.fixture
def small_pool(tmp_path, monkeypatch):
    monkeypatch.setattr(d, "_DB_POOL", d.SQLiteConnectionPool(str(tmp_path / "t.db"), 2))


def test_cancelled_tasks_do_not_leak_connections(small_pool):
    async def run():
        async def slow():
            async with d.db_connection():
                await asyncio.sleep(10)
        for _ in range(5):                       # > taille du pool (2)
            t = asyncio.create_task(slow())
            await asyncio.sleep(0.05)
            t.cancel()
            with pytest.raises(asyncio.CancelledError):
                await t

        async def quick():
            async with d.db_connection() as db:
                async with db.execute("SELECT 1") as c:
                    return (await c.fetchone())[0]
        assert await asyncio.wait_for(quick(), 2) == 1
        assert not d._db_global_lock.locked()
    asyncio.run(run())


def test_deferred_reply_sent_after_lock_released(small_pool):
    async def run():
        seen = {}

        async def fake_send(txt):
            seen["locked"] = d._db_global_lock.locked()

        try:
            async with d.db_connection():
                raise d.DeferredReply(fake_send, "x", _ret=7)
        except d.DeferredReply as x:
            assert await x.send() == 7
        assert seen["locked"] is False
    asyncio.run(run())


def test_outbox_sends_on_return_and_drops_on_error(small_pool):
    async def run():
        sent = []

        async def snd(t):
            sent.append((t, d._db_global_lock.locked()))

        async def ok():
            async with d.Outbox() as out:
                async with d.db_connection():
                    out.add(snd, "A")
                    return "fin"

        async def ko():
            async with d.Outbox() as out:
                async with d.db_connection():
                    out.add(snd, "NON")
                    raise ValueError

        assert await ok() == "fin"
        with pytest.raises(ValueError):
            await ko()
        assert sent == [("A", False)]
    asyncio.run(run())
