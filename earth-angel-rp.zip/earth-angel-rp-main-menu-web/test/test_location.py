# test/test_location.py — monde RP : déplacements, présence, notifications d'arrivée
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

import aiosqlite
import pytest
import pytest_asyncio

import database
import migrations
import utils.location as loc
from config import START_LOCATION

UID = 4242


@pytest_asyncio.fixture
async def rp_db(monkeypatch, tmp_path):
    path = str(tmp_path / "rp.db")
    pool = database.SQLiteConnectionPool(path, size=5)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()

    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title, message))

    import utils.notify
    monkeypatch.setattr(utils.notify, "notify", fake_notify)

    clock = {"t": 1_000_000}
    monkeypatch.setattr(loc, "now", lambda: clock["t"])
    await database.get_user(UID, "tester", "Tester")
    await database.update_field(UID, "registered", 1)
    await database.update_field(UID, "energy", 100)
    yield {"sent": sent, "clock": clock}
    await pool.close() if hasattr(pool, "close") else None


async def _add_vehicle(veh_type="Voiture", fuel=40, condition=100):
    async with database.db_connection() as db:
        cur = await db.execute(
            "INSERT INTO vehicles (user_id, veh_type, condition, purchased_at, fuel) VALUES (?,?,?,?,?)",
            (UID, veh_type, condition, 0, fuel))
        await db.commit()
        return cur.lastrowid


def test_distances_are_symmetric_and_known():
    from config import LOCATIONS
    keys = list(LOCATIONS)
    for a in keys:
        assert loc.distance_km(a, a) == 0
        for b in keys:
            assert loc.distance_km(a, b) == loc.distance_km(b, a) > 0 or a == b


async def test_new_player_starts_at_home(rp_db):
    pos = await loc.get_position(UID)
    assert pos["location"] == START_LOCATION and not pos["in_transit"]


async def test_migration_places_existing_users_at_home(rp_db):
    async with database.db_connection() as db:
        async with db.execute("SELECT location FROM user_position WHERE user_id=?", (UID,)) as c:
            row = await c.fetchone()
    # la ligne peut être créée paresseusement : get_position doit de toute façon répondre « maison »
    assert (row is None) or row[0] == START_LOCATION


async def test_walk_costs_energy_and_takes_time(rp_db):
    ok, msg = await loc.start_travel(UID, "casino", "walk")
    assert ok, msg
    u = await database.get_user(UID)
    assert u["energy"] == 100 - 3          # maison→centre = 3 km
    pos = await loc.get_position(UID)
    assert pos["in_transit"] and pos["travel_to"] == "casino"
    # pas encore arrivé : le casino est refusé
    err = await loc.presence_error(UID, ("casino",))
    assert err and "en route" in err
    # le temps passe
    rp_db["clock"]["t"] += pos["remaining"] + 1
    pos = await loc.get_position(UID)
    assert pos["location"] == "casino" and not pos["in_transit"]
    assert await loc.presence_error(UID, ("casino",)) is None
    assert any("Arrivée" in t for _, t, _ in rp_db["sent"])


async def test_arrival_notified_exactly_once(rp_db):
    await loc.start_travel(UID, "banque", "walk")
    rp_db["clock"]["t"] += 10 * 3600
    await loc.get_position(UID)
    await loc.resolve_arrivals()
    await loc.get_position(UID)
    assert len([1 for _, t, _ in rp_db["sent"] if "Arrivée" in t]) == 1


async def test_wrong_place_message_points_to_aller(rp_db):
    err = await loc.presence_error(UID, ("casino",))
    assert err and "/aller" in err and "Casino" in err


async def test_cannot_start_second_trip_while_travelling(rp_db):
    assert (await loc.start_travel(UID, "casino", "walk"))[0]
    ok, msg = await loc.start_travel(UID, "banque", "walk")
    assert not ok and "route" in msg
    assert (await database.get_user(UID))["energy"] == 97   # un seul débit


async def test_too_tired_to_walk(rp_db):
    await database.update_field(UID, "energy", 1)
    ok, _ = await loc.start_travel(UID, "aeroport", "walk")
    assert not ok
    assert (await database.get_user(UID))["energy"] == 1
    assert (await loc.get_position(UID))["location"] == START_LOCATION


async def test_vehicle_is_faster_and_uses_fuel(rp_db):
    vid = await _add_vehicle("Voiture", fuel=40)
    opts = {o["mode"]: o for o in await loc.plan_options(UID, "maison", "casino")}
    assert opts[f"v{vid}"]["duration"] < opts["walk"]["duration"]
    ok, _ = await loc.start_travel(UID, "casino", f"v{vid}")
    assert ok
    veh = (await database.get_vehicles(UID))[0]
    assert veh["fuel"] < 40 and veh["condition"] < 100
    assert (await database.get_user(UID))["energy"] == 100   # pas d'énergie dépensée


async def test_vehicle_without_fuel_or_broken_is_refused(rp_db):
    empty = await _add_vehicle("Voiture", fuel=0)
    broken = await _add_vehicle("SUV", fuel=60, condition=5)
    ok, msg = await loc.start_travel(UID, "casino", f"v{empty}")
    assert not ok and "essence" in msg
    ok, msg = await loc.start_travel(UID, "casino", f"v{broken}")
    assert not ok and "panne" in msg
    assert (await loc.get_position(UID))["location"] == START_LOCATION


async def test_bicycle_needs_no_fuel(rp_db):
    vid = await _add_vehicle("Vélo", fuel=0)
    ok, _ = await loc.start_travel(UID, "casino", f"v{vid}")
    assert ok


async def test_boat_and_jet_not_usable_in_town(rp_db):
    await _add_vehicle("Yacht", fuel=200)
    modes = [o["mode"] for o in await loc.plan_options(UID, "maison", "casino")]
    assert modes == ["walk"]


async def test_same_place_and_unknown_place(rp_db):
    assert not (await loc.start_travel(UID, START_LOCATION, "walk"))[0]
    assert not (await loc.start_travel(UID, "narnia", "walk"))[0]


def test_require_location_rejects_unknown_place():
    with pytest.raises(ValueError):
        loc.require_location("narnia")
