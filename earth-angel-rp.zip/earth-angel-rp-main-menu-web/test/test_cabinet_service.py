# test/test_cabinet_service.py — Gouvernement : nomination/révocation partagées bot/API
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
import utils.roles as roles
from gameplay import cabinet as svc
from webapp.routers import political_router as router

PRES, MIN, OUT, GL = 1001, 1002, 1003, 1004
ROLES = {GL: "GAME_LEADER"}


@pytest_asyncio.fixture
async def cdb(monkeypatch, tmp_path):
    path = str(tmp_path / "cabinet.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()

    async def role_of(uid):
        return ROLES.get(uid, "PLAYER")

    monkeypatch.setattr(roles, "role_of", role_of)
    for uid in (PRES, MIN, OUT, GL):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
    await roles.install_president(PRES)
    yield


async def test_appoint_then_dismiss(cdb):
    result = await svc.appoint(PRES, MIN, "Santé")
    assert result["ok"] and "Santé" in result["label"]
    gov = await svc.government()
    santé = next(m for m in gov["ministries"] if m["position"] == "Santé")
    assert santé["occupant_id"] == MIN
    assert (await roles.minister_of(MIN)) == "Santé"
    out = await svc.dismiss(PRES, "Santé")
    assert out == {"ok": True, "position": "Santé", "former_id": MIN}
    assert await roles.minister_of(MIN) is None
    assert (await svc.dismiss(PRES, "Santé"))["reason"] == "vacant"


async def test_appoint_refusals(cdb):
    assert (await svc.appoint(MIN, OUT, "Santé"))["reason"] == "not_president"
    assert (await svc.appoint(PRES, OUT, "Inconnu"))["reason"] == "unknown_position"
    assert (await svc.appoint(PRES, GL, "Santé"))["reason"] == "target_not_player"
    assert (await svc.appoint(PRES, PRES, "Santé"))["reason"] == "refused"
    assert (await svc.dismiss(OUT, "Santé"))["reason"] == "not_president"
    assert all(m["occupant_id"] is None for m in (await svc.government())["ministries"])


def test_resolve_position():
    assert svc.resolve_position("santé") == "Santé" and svc.resolve_position("zzz") is None


async def test_router_maps_reasons(monkeypatch):
    monkeypatch.setattr(router.cabinet_service, "appoint",
                        AsyncMock(return_value={"ok": False, "reason": "not_president"}))
    with pytest.raises(HTTPException) as exc:
        await router.appoint_minister(router.AppointIn(position="Santé", target_user_id=2), user_id=1)
    assert exc.value.status_code == 403
    monkeypatch.setattr(router.cabinet_service, "appoint",
                        AsyncMock(return_value={"ok": False, "reason": "refused", "message": "Le Président ne peut pas être ministre."}))
    with pytest.raises(HTTPException) as exc:
        await router.appoint_minister(router.AppointIn(position="Santé", target_user_id=1), user_id=1)
    assert exc.value.status_code == 422 and "Président" in exc.value.detail
    with pytest.raises(HTTPException) as exc:
        await router.dismiss_minister(router.DismissIn(position="Nope"), user_id=1)
    assert exc.value.status_code == 422
    dismiss = AsyncMock(return_value={"ok": True, "position": "Santé", "former_id": 5})
    monkeypatch.setattr(router.cabinet_service, "dismiss", dismiss)
    assert (await router.dismiss_minister(router.DismissIn(position="santé"), user_id=1))["ok"]
    dismiss.assert_awaited_once_with(1, "Santé")


def test_government_routes_registered():
    from webapp.server import app
    paths = {r.path for r in app.routes}
    assert {"/api/political/government", "/api/political/government/appoint",
            "/api/political/government/dismiss"} <= paths
