"""Résolution d'un joueur : l'ID passe partout (avec ou sans @), puis le @pseudo."""
import pytest

from utils import user_lookup as ul


def test_normalize_and_is_id():
    assert ul.normalize(" @Bob. ") == "Bob"
    assert ul.is_id("123456") and ul.is_id("@123456") and ul.is_id("-42")
    assert not ul.is_id("bob") and not ul.is_id("")


@pytest.fixture
def fake_db(monkeypatch):
    import contextlib
    import sqlite3

    class _Cur:
        def __init__(self, rows): self.rows = rows
        async def fetchone(self): return self.rows[0] if self.rows else None
        async def __aenter__(self): return self
        async def __aexit__(self, *a): return False

    class _Db:
        def __init__(self, con): self.con = con
        def execute(self, q, p=()): return _Cur(self.con.execute(q, p).fetchall())

    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE users(user_id INTEGER, username TEXT, full_name TEXT, registered INT)")
    con.executemany("INSERT INTO users VALUES(?,?,?,?)", [(11, "Alice", "Alice A", 1), (22, None, "Sans Pseudo", 1),
                                                         (-5, None, "Web", 0)])

    @contextlib.asynccontextmanager
    async def _conn(*a, **k):
        yield _Db(con)

    monkeypatch.setattr(ul, "db_connection", _conn)


async def test_id_without_username(fake_db):
    assert await ul.resolve_id("22") == 22
    assert await ul.resolve_id("@22") == 22
    assert await ul.resolve_id("-5") == -5


async def test_username_case_insensitive(fake_db):
    assert await ul.resolve_id("@alice") == 11
    assert await ul.resolve_id("ALICE,") == 11
    assert await ul.resolve_id("inconnu") is None


async def test_registered_only(fake_db):
    assert await ul.resolve_id("-5", registered_only=True) is None
