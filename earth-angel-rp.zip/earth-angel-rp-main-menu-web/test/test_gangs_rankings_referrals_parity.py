import pytest
import pytest_asyncio

import database
import migrations
from gameplay.gangs import apply_to_gang, change_role, create_gang, deposit, dissolve_gang, exclude_member, hold_up, leave_gang, transfer_chief, upgrade
from gameplay.referrals import process_activation, start_referral


@pytest_asyncio.fixture
async def social_db(monkeypatch, tmp_path):
    path = str(tmp_path / "social.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=8))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db(); await database.run_migrations(); await migrations.run_migrations()
    for uid in (1, 2, 3):
        await database.get_user(uid, f"u{uid}", f"User {uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 200_000)
    yield


@pytest.mark.asyncio
async def test_gang_mutations_are_shared_and_atomic(social_db):
    created = await create_gang(1, "Les Corbeaux")
    assert created["cost"] == 50_000
    applied = await apply_to_gang(2, created["gang_id"])
    assert applied["status"] == "pending"
    deposited = await deposit(1, 100_000)
    assert deposited["amount"] == 100_000
    async with database.db_connection() as db:
        await db.execute("INSERT INTO gang_members(gang_id,user_id,role,joined_at) VALUES (?,?,?,0)", (created["gang_id"], 3, "Recrue"))
        await db.commit()
    upgraded = await upgrade(1)
    assert upgraded["reputation"] == 10
    with pytest.raises(Exception):
        await leave_gang(1)


@pytest.mark.asyncio
async def test_referral_join_and_activation_are_idempotent(social_db):
    joined = await start_referral(2, 1)
    assert joined["cash"] == 7_500
    await database.update_field(2, "level", 3)
    await database.update_field(2, "total_earned", 25_000)
    activated = await process_activation(2)
    assert activated and activated["cash"] == 20_000
    assert await process_activation(2) is None
    assert (await database.get_user(1))["referral_count"] == 1


@pytest.mark.asyncio
async def test_advanced_gang_roles_share_same_rules(social_db):
    created = await create_gang(1, "Les Aigles")
    async with database.db_connection() as db:
        await db.execute("INSERT INTO gang_members(gang_id,user_id,role,joined_at) VALUES (?,?,?,0)", (created["gang_id"], 2, "Recrue"))
        await db.execute("INSERT INTO gang_members(gang_id,user_id,role,joined_at) VALUES (?,?,?,0)", (created["gang_id"], 3, "Recrue"))
        await db.commit()
    changed = await change_role(1, 2, "Soldat")
    assert changed["role"] == "Soldat"
    transferred = await transfer_chief(1, 2)
    assert transferred["target_id"] == 2
    excluded = await exclude_member(2, 3)
    assert excluded["target_id"] == 3
    with pytest.raises(Exception):
        await transfer_chief(3, 1)


@pytest.mark.asyncio
async def test_gang_hold_up_and_dissolution_use_shared_rules(social_db, monkeypatch):
    import gameplay.gangs as service
    created = await create_gang(1, "Les Loups")
    await deposit(1, 100_000)
    monkeypatch.setattr(service.random, "random", lambda: 0.0)
    monkeypatch.setattr(service.random, "randint", lambda a, b: a)
    result = await hold_up(1)
    assert result["success"] and result["reward"] == 50_000
    dissolved = await dissolve_gang(1)
    assert dissolved["refunded"] == 150_000
