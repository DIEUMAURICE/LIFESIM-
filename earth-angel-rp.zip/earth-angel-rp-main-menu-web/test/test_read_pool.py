# test/test_read_pool.py — db_read : lectures hors verrou global, get_user chemin rapide
import asyncio
import os
import tempfile

import aiosqlite
import database as d


async def _fresh_db():
    """Base temporaire complète (init_db) : remplace pool d'écriture et chemin."""
    path = os.path.join(tempfile.mkdtemp(prefix="lifesim_rp_"), "t.db")
    d.DB_PATH = path
    d._DB_POOL = d.SQLiteConnectionPool(path, 5)
    d._READ_POOL = None
    d._db_global_lock = asyncio.Lock()   # un Lock module-level se lie à la boucle du 1er test qui le dispute
    await d.init_db()
    return path


async def test_reader_does_not_wait_for_global_lock():
    await _fresh_db()
    async with d.db_connection() as db:   # ← verrou global tenu...
        async def read():
            async with d.db_read() as r:
                async with r.execute("SELECT 1") as c:
                    return (await c.fetchone())[0]
        # ...mais une lecture autonome passe quand même (depuis un autre task)
        assert await asyncio.wait_for(asyncio.create_task(read()), 1.0) == 1
        assert d._db_global_lock.locked()


async def test_read_sees_committed_write_and_nested_sees_own_uncommitted():
    await _fresh_db()
    async with d.db_connection() as db:
        await db.execute("INSERT INTO notifications (user_id,title,message,created_at) VALUES (1,'a','b',1)")
        # imbriqué dans le même task : réutilise la connexion → voit sa propre écriture
        async with d.db_read() as r:
            async with r.execute("SELECT COUNT(*) FROM notifications") as c:
                assert (await c.fetchone())[0] == 1
        await db.commit()

    async def count():
        async with d.db_read() as r:
            async with r.execute("SELECT COUNT(*) FROM notifications") as c:
                return (await c.fetchone())[0]
    assert await count() == 1                     # lecteur autonome : voit le committé


async def test_read_connection_is_read_only():
    await _fresh_db()

    async def attempt():
        async with d.db_read() as r:
            await r.execute("DELETE FROM notifications")
    try:
        await attempt()
    except aiosqlite.OperationalError:
        pass
    else:
        raise AssertionError("une connexion de lecture a pu écrire")


async def test_get_user_fast_path_and_write_path():
    await _fresh_db()
    u = await d.get_user(42, "bob", "Bob B")            # inscription (chemin écriture)
    assert u["user_id"] == 42

    held = asyncio.Event(); release = asyncio.Event()

    async def hold_lock():
        async with d.db_connection():
            held.set(); await release.wait()
    t = asyncio.create_task(hold_lock()); await held.wait()

    # même pseudo → chemin rapide : ne doit PAS attendre le verrou
    u2 = await asyncio.wait_for(d.get_user(42, "bob", "Bob B"), 1.0)
    assert u2["username"] == "bob"
    # pseudo changé → écriture : doit attendre le verrou
    w = asyncio.create_task(d.get_user(42, "bobby", "Bob B"))
    await asyncio.sleep(0.2)
    assert not w.done()
    release.set(); await t; await asyncio.wait_for(w, 2.0)
    assert (await d.get_user(42))["username"] == "bobby"


async def test_many_parallel_reads_and_writes():
    await _fresh_db()
    for i in range(1, 21):
        await d.get_user(i, f"u{i}", f"U {i}")

    async def work(i):
        uid = 1 + i % 20
        await d.get_user(uid, f"u{uid}", f"U {uid}")
        await d.update_balance(uid, 10)
        return await d.get_top_rich(3)
    res = await asyncio.gather(*(work(i) for i in range(300)))
    assert all(len(r) == 3 for r in res)
    assert not d._db_global_lock.locked()
