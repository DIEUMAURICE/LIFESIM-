# test/test_staff_scope.py — le staff Admin N2+ est ignoré par les classements et agrégats
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

import sqlite3

import pytest_asyncio

import database
import migrations
from utils import politics, rankings, staff_scope

N2, PLAYER_A, PLAYER_B, N1, DYN = 1301, 1302, 1303, 1304, 1305


def test_ignored_roles_are_everything_above_admin_n1():
    assert "ADMIN_N1" not in staff_scope.IGNORED_ROLES and "PLAYER" not in staff_scope.IGNORED_ROLES
    assert {"ADMIN_N2", "GAME_LEADER", "LEAD_STAFF_GLOBAL", "LEAD_STUDIO", "LEAD_PRINCIPAL",
            "LEAD_INFLUENCEURS"} == set(staff_scope.IGNORED_ROLES)


def test_excluded_sql_filters_dynamic_roles_only_when_active_and_ignored():
    db = sqlite3.connect(":memory:")
    db.execute("CREATE TABLE users(user_id INTEGER)")
    db.execute("CREATE TABLE admin_roles(user_id INTEGER, role TEXT, revoked_at INTEGER DEFAULT 0)")
    for uid in (1, 2, 3, 4):
        db.execute("INSERT INTO users VALUES(?)", (uid,))
    db.execute("INSERT INTO admin_roles VALUES(1,'ADMIN_N2',0)")      # actif : ignoré
    db.execute("INSERT INTO admin_roles VALUES(2,'ADMIN_N2',99)")     # révoqué : compte
    db.execute("INSERT INTO admin_roles VALUES(3,'ADMIN_N1',0)")      # N1 : compte
    kept = sorted(r[0] for r in db.execute("SELECT user_id FROM users WHERE " + staff_scope.excluded_sql("user_id")))
    assert kept == [2, 3, 4]


@pytest_asyncio.fixture
async def sdb(monkeypatch, tmp_path):
    path = str(tmp_path / "staff-scope.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=3))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    monkeypatch.setattr(staff_scope, "_static_ids", lambda: [N2])
    for uid, balance in ((N2, 9_000_000), (PLAYER_A, 500), (PLAYER_B, 300), (N1, 100), (DYN, 8_000_000)):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", balance)
    async with database.db_connection() as db:
        await db.execute("INSERT INTO admin_roles(user_id, role, assigned_by, assigned_at) VALUES (?,?,?,?)",
                         (DYN, "GAME_LEADER", 1, 0))
        await db.commit()
    yield


async def test_get_top_rich_skips_staff(sdb, monkeypatch):
    top = await database.get_top_rich(10)
    ids = [row["user_id"] for row in top]
    assert N2 not in ids and DYN not in ids
    assert ids[:3] == [PLAYER_A, PLAYER_B, N1]


async def test_registered_count_excludes_staff_but_keeps_admin_n1(sdb):
    assert await politics.registered_count() == 3          # PLAYER_A, PLAYER_B, N1
