"""test/test_smoke.py — Tests de fumée"""
import importlib

import aiosqlite
import pytest


def test_import_bot():
    import bot  # noqa: F401


def test_build_app():
    """Le build_app() doit produire une Application avec des handlers."""
    import bot
    import config

    # Sécuriser un token factice pour éviter les appels réseau
    if not config.BOT_TOKEN or config.BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        config.BOT_TOKEN = "123456:TEST_TOKEN_FOR_SMOKE"

    app = bot.build_app()
    assert app is not None
    assert len(app.handlers) > 0


@pytest.mark.parametrize("module", [
    "handlers.general",
    "handlers.economy",
    "handlers.bank",
    "handlers.profile",
    "handlers.casino",
    "handlers.companies",
    "handlers.social",
    "handlers.political",
    "handlers.multiplayer",
])
def test_handler_modules_import(module):
    importlib.import_module(module)


@pytest.mark.asyncio
async def test_db_init(isolated_db):
    """La base isolée doit contenir les tables minimales."""
    async with aiosqlite.connect(isolated_db) as conn:
        async with conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ) as cur:
            tables = [row[0] for row in await cur.fetchall()]

    assert "users" in tables
    assert "inventory" in tables
    assert "market_listings" in tables
    assert "arena_matches" in tables