# test/test_arms_justice.py — armes (marché noir, chambres d'armes), Justice, recrutement de l'hôpital
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from types import SimpleNamespace

import pytest
import pytest_asyncio

import database
import migrations
import utils.factions as factions
import utils.justice as justice
import utils.ordre as ordre
import utils.weapons as weapons
import utils.sante as sante
from config import JUSTICE, ORDRE, WEAPONS

LEAD, JUGE, AVO, SOL, ARM, AGT, CIV1, CIV2, MED, CANDI = 501, 502, 503, 504, 505, 506, 507, 508, 509, 510
USERS = (LEAD, JUGE, AVO, SOL, ARM, AGT, CIV1, CIV2, MED, CANDI)


@pytest_asyncio.fixture
async def adb(monkeypatch, tmp_path):
    path = str(tmp_path / "aj.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title))

    clock = {"t": 10 * 86400}
    for mod in (ordre, factions, justice, weapons):
        monkeypatch.setattr(mod, "notify", fake_notify)
    monkeypatch.setattr(ordre, "now", lambda: clock["t"])
    monkeypatch.setattr(justice, "now", lambda: clock["t"])
    monkeypatch.setattr(justice, "real_now", lambda: clock["t"])
    monkeypatch.setattr(weapons, "real_now", lambda: clock["t"])

    async def free(uid):
        return False

    monkeypatch.setattr(ordre, "is_protected", free)
    import utils.location as loc

    async def pos(uid):
        return {"location": "tribunal" if uid in (JUGE, AVO) else "commissariat", "in_transit": False}

    monkeypatch.setattr(loc, "get_position", pos)
    monkeypatch.setattr(loc, "is_exempt", free)
    for uid in USERS:
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 1_000_000)
    yield {"clock": clock, "sent": sent}


async def _staff(uid, faction, post, station="central", duty=True):
    async with database.db_connection() as db:
        await ordre._set_post(db, uid, faction, station, post)
        await db.execute("UPDATE ordre_staff SET on_duty=? WHERE user_id=?", (1 if duty else 0, uid))
        await db.commit()


async def _fund(faction, amount=1_000_000):
    async with database.db_connection() as db:
        await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES (?,0)", (faction,))
        await db.execute("UPDATE faction_state SET budget=? WHERE faction=?", (amount, faction))
        await db.commit()


async def _bal(uid):
    return (await database.get_user(uid))["balance"]


# ─── Marché noir & arsenal ───────────────────────────────────────────────────
async def test_black_market_weapons_and_ammo(adb):
    ok, _ = await weapons.buy_weapon(CIV1, "taser")                 # non vendu
    assert not ok
    ok, _ = await weapons.buy_weapon(CIV1, "pistolet")
    assert ok and (await weapons.list_weapons(CIV1))[0]["ammo"] == WEAPONS["pistolet"]["mag"]
    ok, _ = await weapons.buy_weapon(CIV1, "pistolet")              # racheter = plus de munitions
    assert ok and (await weapons.list_weapons(CIV1))[0]["ammo"] == 2 * WEAPONS["pistolet"]["mag"]
    for _ in range(5):
        await weapons.buy_ammo(CIV1, "pistolet")
    assert (await weapons.list_weapons(CIV1))[0]["ammo"] == weapons.max_ammo("pistolet")   # plafond
    ok, msg = await weapons.buy_ammo(CIV1, "pistolet")
    assert not ok and "Maximum" in msg
    ok, _ = await weapons.equip(CIV1, "pistolet")
    assert ok and (await weapons.equipped(CIV1))["key"] == "pistolet"
    await database.update_field(CIV2, "balance", 10)
    ok, _ = await weapons.buy_weapon(CIV2, "pistolet")              # pas assez d'argent
    assert not ok


async def test_weapon_use_consumes_ammo(adb):
    await weapons.buy_weapon(CIV1, "fusil_pompe")
    bonus, msg, ok = await weapons.use_for_action(CIV1, need_firearm=True)
    assert not ok                                                   # pas équipée
    await weapons.equip(CIV1, "fusil_pompe")
    bonus, msg, ok = await weapons.use_for_action(CIV1, need_firearm=True)
    assert ok and bonus == WEAPONS["fusil_pompe"]["bonus"]
    assert (await weapons.list_weapons(CIV1))[0]["ammo"] == WEAPONS["fusil_pompe"]["mag"] - WEAPONS["fusil_pompe"]["per_use"]
    await database.update_field(CIV1, "balance", 0)
    async with database.db_connection() as db:                      # arme vide → plus de bonus
        await db.execute("UPDATE user_weapons SET ammo=0 WHERE user_id=?", (CIV1,))
        await db.commit()
    bonus, msg, ok = await weapons.use_for_action(CIV1, need_firearm=True)
    assert not ok and bonus == 0


# ─── Chambres d'armes ────────────────────────────────────────────────────────
async def test_armory_craft_deliver_take(adb):
    await _staff(ARM, "armee", "armurier")
    await _staff(SOL, "armee", "soldat")
    await _staff(AGT, "police", "agent")
    await _fund("armee")
    ok, _ = await weapons.craft_weapon(SOL, "pistolet")             # un simple soldat ne fabrique pas
    assert not ok
    ok, _ = await weapons.craft_weapon(ARM, "pistolet")
    assert ok
    ok, msg = await weapons.craft_weapon(ARM, "pistolet")           # temps de refroidissement
    assert not ok
    adb["clock"]["t"] += ORDRE["stun_seconds"] * 10
    ok, _ = await weapons.craft_ammo(ARM, "pistolet")
    assert ok
    # la police n'a rien tant que l'armée n'a pas livré
    ok, _ = await weapons.take_weapon(AGT, "pistolet")
    assert not ok
    ok, _ = await weapons.deliver_to_police(SOL, "pistolet")        # un soldat ne livre pas
    assert not ok
    ok, _ = await weapons.deliver_to_police(ARM, "pistolet")
    assert ok
    ok, _ = await weapons.take_weapon(AGT, "pistolet")
    assert ok
    w = (await weapons.list_weapons(AGT))[0]
    assert w["source"] == "police" and w["ammo"] == WEAPONS["pistolet"]["mag"]
    ok, _ = await weapons.take_weapon(AGT, "pistolet")              # déjà en possession
    assert not ok
    ok, _ = await weapons.return_weapon(AGT, "pistolet")
    assert ok and await weapons.list_weapons(AGT) == []
    # coffre insuffisant
    await _fund("armee", 10)
    adb["clock"]["t"] += 1000
    ok, msg = await weapons.craft_weapon(ARM, "fusil_assaut")
    assert not ok and "coffre" in msg.lower()


async def test_dismissed_agent_returns_weapons(adb):
    await _staff(SOL, "armee", "soldat")
    await _staff(ARM, "armee", "dg")
    await _fund("armee")
    await _staff(CIV2, "armee", "armurier")
    await weapons.craft_weapon(CIV2, "pistolet")
    await weapons.take_weapon(SOL, "pistolet")
    ok, _ = await ordre.dismiss(ARM, SOL)
    assert ok and await weapons.list_weapons(SOL) == []
    stock = {w["key"]: w for w in await weapons.armory_stock("armee")}
    assert stock["pistolet"]["qty"] == 1


async def test_armed_crimes(adb, monkeypatch):
    import utils.helpers as helpers
    monkeypatch.setattr(helpers, "roll_success", lambda *a, **k: True)
    await weapons.buy_weapon(CIV1, "pistolet")
    await weapons.equip(CIV1, "pistolet")
    res = await ordre.commit_player_crime(CIV1, "vol", CIV2)
    assert res["success"] and "utilisé" in res["msg"]
    assert (await weapons.list_weapons(CIV1))[0]["ammo"] == WEAPONS["pistolet"]["mag"] - 1


# ─── Justice ─────────────────────────────────────────────────────────────────
async def test_justice_file_bail_and_lawyer(adb):
    await ordre.appoint_dg(LEAD, JUGE, "justice")
    assert (await ordre.get_staff(JUGE))["post"] == "juge"
    ok, _ = await ordre.appoint_dg(LEAD, AVO, "justice")             # plusieurs juges possibles
    assert ok and (await ordre.get_staff(JUGE))["post"] == "juge"
    await ordre.revoke_judge(LEAD, AVO)
    assert (await ordre.get_staff(AVO))["post"] == "avocat"
    async with database.db_connection() as db:
        await db.execute("UPDATE ordre_staff SET on_duty=1 WHERE faction='justice'")
        await db.commit()
    assert await justice.has_judges()
    # arrestation → dossier
    await database.update_field(CIV1, "prison_until", adb["clock"]["t"] + 3000)
    await ordre.register_arrest(CIV1, "Cambriolage", "police", 3000)
    f = await justice.my_file(CIV1)
    assert f and f["crime"] == "Cambriolage"
    ok, _ = await justice.pay_bail(CIV1)                             # caution pas encore fixée
    assert not ok
    ok, _ = await justice.set_bail(JUGE, f["id"], 50_000)
    assert ok
    ok, _ = await justice.hire_lawyer(CIV1, AVO)
    assert ok and await _bal(AVO) == 1_000_000 + JUSTICE["lawyer_fee"]
    ok, _ = await justice.plead(AVO, f["id"])                        # réussie ou ratée, une seule fois
    assert ok
    ok, _ = await justice.plead(AVO, f["id"])
    assert not ok
    f = await justice.get_file(f["id"])
    due = justice.effective_bail(f)
    assert due in (50_000, int(50_000 * (1 - JUSTICE["plead_reduction"])))
    ok, _ = await justice.pay_bail(CIV1)
    assert ok and (await database.get_user(CIV1))["prison_until"] == 0
    assert await justice.my_file(CIV1) is None
    from utils.factions import coffre_balance
    assert await coffre_balance("justice") == due


async def test_justice_verdicts_and_warrant(adb):
    await _staff(JUGE, "justice", "juge")
    await _staff(AGT, "police", "agent")
    ok, _ = await justice.judge_file(CIV1, 1, "acquit")              # pas juge
    assert not ok
    await database.update_field(CIV1, "prison_until", adb["clock"]["t"] + 3000)
    fid = await justice.open_file(CIV1, "Vol", "police", 3000)
    ok, _ = await justice.judge_file(JUGE, fid, "prison", 10 ** 6)   # plafonné à 3 h
    assert ok
    assert (await database.get_user(CIV1))["prison_until"] - adb["clock"]["t"] == JUSTICE["sentence_max"]
    fid = await justice.open_file(CIV2, "Piratage", "police", 3000)
    await database.update_field(CIV2, "prison_until", adb["clock"]["t"] + 3000)
    bal = await _bal(CIV2)
    ok, _ = await justice.judge_file(JUGE, fid, "amende", 40_000)
    assert ok and await _bal(CIV2) == bal - 40_000 and (await database.get_user(CIV2))["prison_until"] == 0
    # mandat d'arrêt : la police est alertée, le joueur devient « recherché »
    ok, _ = await justice.issue_warrant(JUGE, CIV1, "fuite")
    assert ok and any(t == "📜 Mandat d'arrêt" and u == AGT for u, t in adb["sent"])
    card = await ordre.player_card(CIV1)
    assert card["case"] and card["case"]["kind"] == "signalement"
    ok, _ = await justice.issue_warrant(JUGE, CIV1, "encore")
    assert not ok
    # un dossier se clôt quand la peine est purgée
    fid = await justice.open_file(CIV2, "Vol", "police", 100)
    await database.update_field(CIV2, "prison_until", adb["clock"]["t"] + 100)
    adb["clock"]["t"] += 200
    await justice.maintenance()
    assert await justice.my_file(CIV2) is None


async def test_arrests_open_files(adb, monkeypatch):
    await _staff(AGT, "police", "agent")
    await ordre.cuff(AGT, CIV1)
    ok, _ = await ordre.escort_to_interrogation(AGT, CIV1)
    assert ok
    ok, _ = await ordre.finish_interrogation(AGT, CIV1, 1800)
    assert ok
    f = await justice.my_file(CIV1)
    assert f and f["source"] == "police"
    import utils.helpers as helpers
    monkeypatch.setattr(helpers, "roll_success", lambda *a, **k: False)
    res = await ordre.commit_player_crime(CIV2, "vol", CIV1)
    assert res["ok"] and not res["success"]
    assert (await justice.my_file(CIV2))["source"] == "crime"


async def test_justice_hearing_is_a_single_transition(adb):
    await _staff(JUGE, "justice", "juge")
    fid = await justice.open_file(CIV1, "Cambriolage", "crime", 1800)

    ok, _ = await justice.request_hearing(CIV1)
    assert ok
    duplicate, message = await justice.request_hearing(CIV1)
    assert not duplicate and "déjà" in message
    assert (await justice.get_file(fid))["status"] == "audience"


async def test_concurrent_lawyer_hiring_charges_and_credits_once(adb):
    import asyncio

    await _staff(AVO, "justice", "avocat")
    fid = await justice.open_file(CIV1, "Cambriolage", "crime", 1800)
    fee = JUSTICE["lawyer_fee"]

    results = await asyncio.gather(
        justice.hire_lawyer(CIV1, AVO), justice.hire_lawyer(CIV1, AVO)
    )

    assert sum(1 for ok, _ in results if ok) == 1
    assert await _bal(CIV1) == 1_000_000 - fee
    assert await _bal(AVO) == 1_000_000 + fee
    assert (await justice.get_file(fid))["lawyer_id"] == AVO


async def test_concurrent_judicial_bail_is_paid_once(adb):
    import asyncio
    from utils.factions import coffre_balance

    fid = await justice.open_file(CIV1, "Cambriolage", "crime", 1800)
    async with database.db_connection() as db:
        await db.execute("UPDATE justice_files SET bail=50000 WHERE id=?", (fid,))
        await db.commit()

    results = await asyncio.gather(justice.pay_bail(CIV1), justice.pay_bail(CIV1))

    assert sum(1 for ok, _ in results if ok) == 1
    assert await _bal(CIV1) == 950_000
    assert await coffre_balance("justice") == 50_000
    assert await justice.my_file(CIV1) is None


# ─── Recrutement de l'hôpital (même système que la police) ───────────────────
async def test_hospital_recruitment_with_interview(adb):
    async with database.db_connection() as db:
        await db.execute("INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) "
                         "VALUES (?, 'sante', 6, 0, 0)", (MED,))
        await db.execute("INSERT INTO sante_staff(user_id, hospital_id, post, on_duty, since) VALUES (?,?,?,0,0)",
                         (MED, "grand", "pdg"))
        await db.commit()
    rec = await ordre.recruiter(MED)
    assert rec and rec["faction"] == "sante" and rec["is_head"] and rec["central"]
    ok, _ = await ordre.apply_for_job(CANDI, "sante", "sud")
    assert ok
    apps = await ordre.list_apps(MED)
    assert len(apps) == 1 and apps[0]["station_id"] == "sud"
    ok, _ = await ordre.start_interview(MED, apps[0]["id"])
    assert ok and (await ordre.relay_target(CANDI))["to"] == MED
    ok, _ = await ordre.decide_application(MED, apps[0]["id"], True)
    assert ok
    st = await sante.get_staff(CANDI)
    assert st["hospital_id"] == "sud" and st["post"] == "recolteur"
    # refus
    ok, _ = await ordre.apply_for_job(CIV1, "sante", "grand")
    app2 = (await ordre.list_apps(MED))[0]
    ok, _ = await ordre.decide_application(MED, app2["id"], False)
    assert ok and await sante.get_staff(CIV1) is None
    # un DG de petit hôpital ne voit que ses candidatures
    async with database.db_connection() as db:
        await db.execute("INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) VALUES (?, 'sante', 5, 0, 0)", (AGT,))
        await db.execute("INSERT INTO sante_staff(user_id, hospital_id, post, on_duty, since) VALUES (?,?,?,0,0)", (AGT, "sud", "dg"))
        await db.commit()
    await ordre.apply_for_job(CIV2, "sante", "affaires")
    assert await ordre.list_apps(AGT) == []
