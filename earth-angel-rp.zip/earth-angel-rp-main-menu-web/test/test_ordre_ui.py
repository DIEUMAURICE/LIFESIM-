# test/test_ordre_ui.py — Ordre public : parcours des écrans à boutons (callbacks `ord:…`)
import asyncio
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from types import SimpleNamespace

import pytest
import pytest_asyncio

import database
import migrations
import utils.factions as factions
import utils.ordre as ordre
import handlers.ordre as ui
from config import ORDRE

DG, AGT, ENQ, CIV1, CIV2, GL = 401, 402, 403, 404, 405, 406
USERS = (DG, AGT, ENQ, CIV1, CIV2, GL)


class Recorder:
    """Faux CallbackQuery : mémorise tous les écrans affichés et vérifie les callback_data (≤ 64 octets)."""

    def __init__(self, uid, data):
        self.from_user = SimpleNamespace(id=uid, full_name=f"User{uid}")
        self.data = data
        self.screens = []
        self.replies = []
        self.message = SimpleNamespace(chat_id=uid, message_id=1, reply_text=self._reply)
        self.answered = 0

    async def answer(self, *a, **k):
        self.answered += 1

    async def edit_message_text(self, text, parse_mode=None, reply_markup=None, **k):
        self.screens.append((text, reply_markup))
        if reply_markup:
            for row in reply_markup.inline_keyboard:
                for b in row:
                    assert len(b.callback_data.encode()) <= 64, b.callback_data

    async def _reply(self, text, **k):
        self.replies.append(text)

    @property
    def text(self):
        return self.screens[-1][0] if self.screens else ""

    @property
    def buttons(self):
        return [b.callback_data for row in self.screens[-1][1].inline_keyboard for b in row] if self.screens else []


async def click(uid, data, context=None):
    q = Recorder(uid, data)
    ctx = context or SimpleNamespace(bot=SimpleNamespace(), user_data={})
    upd = SimpleNamespace(callback_query=q, effective_user=q.from_user, effective_message=q.message)
    await ui.ord_callback(upd, ctx)
    return q


@pytest_asyncio.fixture
async def udb(monkeypatch, tmp_path):
    path = str(tmp_path / "ui.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title))

    clock = {"t": 10 * 86400, "real": 3_000_000}
    for mod in (ordre, factions):
        monkeypatch.setattr(mod, "notify", fake_notify)
    monkeypatch.setattr(ordre, "now", lambda: clock["t"])
    monkeypatch.setattr(ordre, "real_now", lambda: clock["real"])

    async def free(uid):
        return False

    async def role(uid):
        return "GAME_LEADER" if uid == GL else "PLAYER"

    monkeypatch.setattr(ordre, "is_protected", free)
    monkeypatch.setattr(ui, "get_user_role_async", role)
    import utils.location as loc

    async def fake_position(uid):
        return {"location": "commissariat" if uid in (DG, AGT, ENQ) else "maison", "in_transit": False}

    monkeypatch.setattr(loc, "get_position", fake_position)
    monkeypatch.setattr(loc, "is_exempt", free)

    async def fake_housing(uid):
        return None

    import handlers.sante as hs
    monkeypatch.setattr(hs, "_housing_error", fake_housing)
    class _Task:
        def add_done_callback(self, fn):
            pass

    class _AsyncioShim:
        """Proxy d'asyncio visible UNIQUEMENT depuis handlers.ordre : seul create_task est neutralisé,
        le module asyncio réel (partagé par tous les tests) n'est jamais modifié."""
        def __getattr__(self, name):
            return getattr(asyncio, name)

        @staticmethod
        def create_task(coro, *args, **kwargs):
            coro.close()
            return _Task()

    monkeypatch.setattr(ui, "asyncio", _AsyncioShim())
    for uid in USERS:
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 1_000_000)
    yield {"clock": clock, "sent": sent}


async def _staff(uid, faction, post, station="central", duty=True):
    async with database.db_connection() as db:
        await ordre._set_post(db, uid, faction, station, post)
        await db.execute("UPDATE ordre_staff SET on_duty=? WHERE user_id=?", (1 if duty else 0, uid))
        await db.commit()


async def test_civilian_screens(udb):
    q = await click(CIV1, "ord:home")
    assert "Ordre public" in q.text and "ord:apply" in q.buttons and "ord:papers" in q.buttons
    for data in ("ord:papers", "ord:doc:id", "ord:doc:work", "ord:doc:car", "ord:stations", "ord:ah", "ord:pc",
                 "ord:apply", "ord:apf:police", "ord:apf:armee"):
        q = await click(CIV1, data)
        assert q.text, data
    q = await click(CIV1, "ord:ahb:pare_feu")
    assert "installée" in q.text
    q = await click(CIV1, "ord:ahb:inconnu")
    assert "inconnue" in q.text
    # carnet / insigne : pas d'insigne pour un civil
    q = await click(CIV1, "ord:doc:badge")
    assert "Mes papiers" in q.text


async def test_apply_interview_hire_via_buttons(udb):
    await _staff(DG, "police", "dg")
    q = await click(CIV1, "ord:ap:police:central")
    assert "Candidature envoyée" in q.text
    q = await click(DG, "ord:apps")
    app_btn = next(b for b in q.buttons if b.startswith("ord:app:"))
    app_id = app_btn.split(":")[2]
    q = await click(DG, app_btn)
    assert "Papiers du candidat" in q.text and f"ord:acc:{app_id}" in q.buttons
    q = await click(DG, f"ord:int:{app_id}")
    assert "Entretien ouvert" in q.text and "ord:endchat" in q.buttons
    q = await click(DG, f"ord:acc:{app_id}")
    assert "recruté" in q.text
    assert (await ordre.get_staff(CIV1))["post"] == "cadet"


async def test_leader_appoints_dg_and_dg_team(udb):
    q = await click(CIV1, "ord:dg")
    assert "Réservé" in q.text
    q = await click(GL, "ord:dg")
    assert "ord:dgn:police" in q.buttons
    ctx = SimpleNamespace(bot=SimpleNamespace(), user_data={})
    q = await click(GL, "ord:dgn:police", ctx)
    assert ctx.user_data.get("_flow") and ctx.user_data["_flow"].name == "ord_dg_target"
    await ordre.appoint_dg(GL, DG, "police")
    await _staff(AGT, "police", "agent", "sud")
    q = await click(DG, "ord:team")
    assert f"ord:m:{AGT}" in q.buttons and "ord:chief" in q.buttons
    q = await click(DG, f"ord:mp:{AGT}")
    assert any(b.startswith(f"ord:mpo:{AGT}:") for b in q.buttons)
    q = await click(DG, f"ord:mpo:{AGT}:sergent")
    assert "Sergent" in q.text
    q = await click(DG, f"ord:ms:{AGT}")
    q = await click(DG, f"ord:mst:{AGT}:affaires")
    assert (await ordre.get_staff(AGT))["station_id"] == "affaires"
    q = await click(DG, f"ord:mf:{AGT}")
    q = await click(DG, f"ord:mfy:{AGT}")
    assert await ordre.get_staff(AGT) is None


async def test_powers_via_buttons(udb):
    await _staff(AGT, "police", "agent")
    q = await click(AGT, "ord:pl:0")
    assert f"ord:p:{CIV1}" in q.buttons
    q = await click(AGT, f"ord:p:{CIV1}")
    assert f"ord:a:stun:{CIV1}" in q.buttons and "Karma" in q.text
    q = await click(AGT, f"ord:a:cuff:{CIV1}")
    assert "menotté" in q.text and f"ord:a:esc:{CIV1}" in q.buttons
    q = await click(AGT, f"ord:a:esc:{CIV1}")
    assert "Interrogatoire" in q.text and any(b.startswith(f"ord:jail:{CIV1}:") for b in q.buttons)
    q = await click(AGT, f"ord:jail:{CIV1}:3600")
    assert any("emprisonné" in r for r in q.replies)
    assert (await database.get_user(CIV1))["prison_until"] > udb["clock"]["t"]
    q = await click(CIV2, "ord:pl:0")                       # un civil n'a pas accès
    assert "Réservé" in q.text


async def test_investigation_via_buttons(udb):
    await _staff(ENQ, "police", "enqueteur")
    cid = await ordre.register_bot_crime(CIV1, "Braquage", 1000)
    udb["clock"]["t"] += ORDRE["flee_delay"] + 1
    await ordre.ordre_maintenance()
    q = await click(ENQ, "ord:cases")
    assert f"ord:case:{cid}" in q.buttons
    q = await click(ENQ, f"ord:case:{cid}")
    assert f"ord:mg:{cid}" in q.buttons
    q = await click(ENQ, f"ord:mg:{cid}")
    assert "mémorise" in q.text
    async with database.db_connection() as db:
        async with db.execute("SELECT seq FROM ordre_mg WHERE user_id=?", (ENQ,)) as cur:
            seq = (await cur.fetchone())[0]
    udb["clock"]["real"] += ORDRE["mg_show"] + 1
    for c in seq[:-1]:
        q = await click(ENQ, f"ord:mgp:{c}")
        assert "Progression" in q.text
    q = await click(ENQ, f"ord:mgp:{seq[-1]}")
    assert "Enquête réussie" in q.text and f"ord:arrest:{cid}" in q.buttons
    q = await click(ENQ, f"ord:arrest:{cid}")
    assert "arrêté" in q.text
    assert (await database.get_user(CIV1))["prison_until"] > udb["clock"]["t"]


async def test_player_crime_flow_and_reports(udb, monkeypatch):
    ctx = SimpleNamespace(bot=SimpleNamespace(), user_data={})
    # pas de gang → refus propre
    q = await click(CIV1, "ord:pcx:vol", ctx)
    assert "gang" in q.text.lower() or "Crimes sur des joueurs" in q.text
    # signalement : saisie guidée en 2 temps
    q = await click(CIV1, "ord:report", ctx)
    assert ctx.user_data["_flow"].name == "ord_report_target"
    sent = []
    msg = SimpleNamespace(reply_text=lambda text, **k: _collect(sent, text))
    upd = SimpleNamespace(effective_user=SimpleNamespace(id=CIV1), effective_message=msg, callback_query=None)
    await ui._flow_report_target(upd, ctx, (CIV2, "User405"), {})
    assert ctx.user_data["_flow"].name == "ord_report_reason"
    await ui._flow_report_reason(upd, ctx, "il m'embête", ctx.user_data["_flow"].data)
    assert any("Signalement transmis" in t for t in sent)
    await _staff(AGT, "police", "agent")
    q = await click(AGT, "ord:reps")
    rid = next(b for b in q.buttons if b.startswith("ord:repd:") and b.endswith(":1")).split(":")[2]
    q = await click(AGT, f"ord:repd:{rid}:1")
    assert "dossier" in q.text.lower()


async def _collect(sent, text):
    sent.append(text)


async def test_job_duty_and_relay(udb):
    await _staff(AGT, "police", "agent", duty=False)
    q = await click(AGT, "ord:job")
    assert "ord:duty:on" in q.buttons and "POL-" in q.text
    q = await click(AGT, "ord:duty:on")
    assert "en service" in q.text.lower() and "🟢" in q.text
    # relais d'une discussion
    await _staff(DG, "police", "dg")
    await ordre.apply_for_job(CIV1, "police", "central")
    app = (await ordre.list_apps(DG))[0]
    await ordre.start_interview(DG, app["id"])
    delivered = []

    async def send_message(to, text, **k):
        delivered.append((to, text))

    ctx = SimpleNamespace(bot=SimpleNamespace(send_message=send_message), user_data={})
    msg = SimpleNamespace(text="Bonjour, je suis motivé", reply_text=lambda *a, **k: _collect([], a[0]))
    upd = SimpleNamespace(effective_message=msg, effective_user=SimpleNamespace(id=CIV1))
    try:
        await ui.relay_message_handler(upd, ctx)
        assert False, "le relais doit stopper la propagation"
    except Exception as e:
        assert e.__class__.__name__ in ("ApplicationHandlerStop", "Stop")
    assert delivered and delivered[0][0] == DG and "motivé" in delivered[0][1]
