# test/test_payroll_factions.py — salaires auto, rôles d'entreprise, factions, conversion des secteurs d'État
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

import pytest
import pytest_asyncio

import database
import migrations
import utils.payroll as payroll
import utils.factions as factions
from config import GOV_FACTIONS
from utils.company_roles import can_manage, get_role, set_role

OWNER, EMP1, EMP2, MGR = 101, 102, 103, 104


@pytest_asyncio.fixture
async def gov_db(monkeypatch, tmp_path):
    path = str(tmp_path / "gov.db")
    pool = database.SQLiteConnectionPool(path, size=5)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()

    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title, message))

    for mod in (payroll, factions):
        monkeypatch.setattr(mod, "notify", fake_notify)
    clock = {"t": 5 * 86400}
    monkeypatch.setattr(payroll, "now", lambda: clock["t"])
    monkeypatch.setattr(factions, "now", lambda: clock["t"])
    for uid in (OWNER, EMP1, EMP2, MGR):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
    yield {"sent": sent, "clock": clock}


async def _balance(uid):
    return (await database.get_user(uid))["balance"]


async def _company(treasury=100_000, sector="Commerce", name="Acme"):
    async with database.db_connection() as db:
        cur = await db.execute(
            "INSERT INTO companies (name, owner_id, sector, treasury, created_at) VALUES (?,?,?,?,?)",
            (name, OWNER, sector, treasury, 0))
        cid = cur.lastrowid
        await db.execute("INSERT INTO company_members (user_id, company_id, poste, base_salary, role, joined_at) "
                         "VALUES (?,?,?,?,?,0)", (OWNER, cid, "PDG", 0, "owner"))
        await db.execute("INSERT INTO company_members (user_id, company_id, poste, base_salary, joined_at) "
                         "VALUES (?,?,?,?,0)", (EMP1, cid, "Employé", 5_000))
        await db.execute("INSERT INTO company_members (user_id, company_id, poste, base_salary, joined_at) "
                         "VALUES (?,?,?,?,0)", (EMP2, cid, "Employé", 3_000))
        await db.commit()
    return cid


async def test_company_payroll_pays_everyone_but_owner_once_per_day(gov_db):
    cid = await _company(treasury=100_000)
    r = await payroll.pay_company(cid, day=5)
    assert r["status"] == "paid" and r["total"] == 8_000 and r["count"] == 2
    assert await _balance(EMP1) == 15_000                               # 10 000 de départ + 5 000 de salaire
    b1, b2, bo = await _balance(EMP1), await _balance(EMP2), await _balance(OWNER)
    # relance le même jour : rien de plus
    again = await payroll.pay_company(cid, day=5)
    assert again["status"] == "none"
    assert (await _balance(EMP1), await _balance(EMP2), await _balance(OWNER)) == (b1, b2, bo)
    async with database.db_connection() as db:
        async with db.execute("SELECT treasury FROM companies WHERE company_id=?", (cid,)) as c:
            assert (await c.fetchone())[0] == 92_000
    # le lendemain : payé de nouveau
    assert (await payroll.pay_company(cid, day=6))["status"] == "paid"
    assert await _balance(EMP1) == b1 + 5_000
    assert any(t == "💰 Salaire reçu" and u == EMP1 for u, t, _ in gov_db["sent"])


async def test_company_payroll_unpaid_when_treasury_short(gov_db):
    cid = await _company(treasury=7_999)    # 1 de moins que nécessaire
    before = (await _balance(EMP1), await _balance(EMP2))
    r = await payroll.pay_company(cid, day=5)
    assert r["status"] == "unpaid"
    assert (await _balance(EMP1), await _balance(EMP2)) == before
    async with database.db_connection() as db:
        async with db.execute("SELECT treasury, reputation FROM companies WHERE company_id=?", (cid,)) as c:
            t, rep = await c.fetchone()
    assert t == 7_999 and rep == 45
    titles = [(u, t) for u, t, _ in gov_db["sent"]]
    assert (EMP1, "⚠️ Salaire impayé") in titles and (OWNER, "🚨 Paie impossible") in titles


async def test_roles_manager_vs_employee(gov_db):
    cid = await _company()
    comp = {"company_id": cid, "owner_id": OWNER}
    assert await get_role(OWNER, comp) == "owner" and await can_manage(OWNER, comp)
    assert await get_role(EMP1, comp) == "employe" and not await can_manage(EMP1, comp)
    assert await get_role(MGR, comp) is None
    ok, _ = await set_role(cid, OWNER, EMP1, "manager")
    assert ok and await can_manage(EMP1, comp)
    assert not (await set_role(cid, OWNER, OWNER, "employe"))[0]       # le créateur reste créateur
    assert not (await set_role(cid, OWNER, MGR, "manager"))[0]         # pas membre
    assert not (await set_role(cid, OWNER, EMP1, "pdg"))[0]


async def test_faction_exclusive_with_company(gov_db):
    await _company()
    ok, msg = await factions.join_faction(EMP1, "police")
    assert not ok and "entreprise" in msg
    ok, _ = await factions.join_faction(MGR, "police")
    assert ok
    ok, msg = await factions.join_faction(MGR, "sante")
    assert not ok and "faction" in msg


async def test_auto_promotion_needs_skills_and_activity(gov_db):
    assert (await factions.join_faction(MGR, "mairie"))[0]
    ok, msg = await factions.try_auto_promotion(MGR)
    assert not ok and "Activité" in msg                                  # 0/5
    async with database.db_connection() as db:
        await db.execute("UPDATE faction_members SET activity_score=5 WHERE user_id=?", (MGR,))
        await db.execute("INSERT INTO skills(user_id, skill_name, level) VALUES (?,?,1)", (MGR, "Discrétion"))
        await db.commit()
    ok, msg = await factions.try_auto_promotion(MGR)
    assert ok and msg == GOV_FACTIONS["mairie"]["ranks"][1][0]
    # rang 2 : activité 15 + Intelligence 2 + Endurance 2
    async with database.db_connection() as db:
        await db.execute("UPDATE faction_members SET activity_score=15 WHERE user_id=?", (MGR,))
        await db.commit()
    ok, msg = await factions.try_auto_promotion(MGR)
    assert not ok and "Intelligence" in msg and "Endurance" in msg
    async with database.db_connection() as db:
        for sk in ("Intelligence", "Endurance"):
            await db.execute("INSERT INTO skills(user_id, skill_name, level) VALUES (?,?,2)", (MGR, sk))
        await db.commit()
    assert (await factions.try_auto_promotion(MGR))[0]


async def test_police_et_armee_promotion_par_la_direction(gov_db):
    """Police / armée : plus de promotion automatique, les postes sont attribués par la direction (Ordre public)."""
    assert (await factions.join_faction(MGR, "police"))[0]
    async with database.db_connection() as db:
        await db.execute("UPDATE faction_members SET activity_score=9999 WHERE user_id=?", (MGR,))
        await db.commit()
    ok, msg = await factions.try_auto_promotion(MGR)
    assert not ok and "direction" in msg


async def test_auto_promotion_stops_at_cap(gov_db):
    assert (await factions.join_faction(MGR, "mairie"))[0]
    cap = GOV_FACTIONS["mairie"]["auto_cap"]
    async with database.db_connection() as db:
        await db.execute("UPDATE faction_members SET rank=?, activity_score=9999 WHERE user_id=?", (cap, MGR))
        for sk in ("Intelligence", "Endurance", "Leadership", "Négociation", "Discrétion"):
            await db.execute("INSERT INTO skills(user_id, skill_name, level) VALUES (?,?,99)", (MGR, sk))
        await db.commit()
    ok, msg = await factions.try_auto_promotion(MGR)
    assert not ok and "nomination" in msg


async def test_faction_payroll_full_then_partial(gov_db):
    for uid, rank in ((EMP1, 0), (EMP2, 1)):
        assert (await factions.join_faction(uid, "police", rank))[0]
    ranks = GOV_FACTIONS["police"]["ranks"]
    need = ranks[0][1] + ranks[1][1]
    async with database.db_connection() as db:
        await db.execute("INSERT OR REPLACE INTO faction_state VALUES ('police', ?)", (need,))
        await db.commit()
    r = await payroll.pay_faction("police", day=7)
    assert r["status"] == "paid" and r["paid"] == need
    assert await _balance(EMP2) >= ranks[1][1]
    # jour suivant : budget à moitié → paie proportionnelle
    async with database.db_connection() as db:
        await db.execute("UPDATE faction_state SET budget=? WHERE faction='police'", (need // 2,))
        await db.commit()
    before = await _balance(EMP2)
    r = await payroll.pay_faction("police", day=8)
    assert r["status"] == "partial" and r["paid"] <= need // 2
    assert 0 < await _balance(EMP2) - before < ranks[1][1]
    assert any(t == "⚠️ Solde partiel" for _, t, _ in gov_db["sent"])


async def test_funding_once_per_day_and_uses_state_taxes(gov_db):
    from config import GOV_MINT_RATIO
    async with database.db_connection() as db:
        await db.execute("INSERT OR REPLACE INTO faction_state VALUES ('_state', ?)", (10**9,))
        await db.commit()
    await payroll.fund_factions(day=9)
    await payroll.fund_factions(day=9)       # relance : sans effet
    async with database.db_connection() as db:
        async with db.execute("SELECT faction, budget FROM faction_state") as c:
            st = dict(await c.fetchall())
    for key, f in GOV_FACTIONS.items():
        assert st[key] == f["daily_budget"]                      # financé à 100 % par l'impôt
    spent = sum(f["daily_budget"] for f in GOV_FACTIONS.values())
    assert st["_state"] == 10**9 - spent
    # sans impôt : dotation de base seulement
    async with database.db_connection() as db:
        await db.execute("UPDATE faction_state SET budget=0")
        await db.commit()
    await payroll.fund_factions(day=10)
    async with database.db_connection() as db:
        async with db.execute("SELECT budget FROM faction_state WHERE faction='police'") as c:
            assert (await c.fetchone())[0] == int(GOV_FACTIONS["police"]["daily_budget"] * GOV_MINT_RATIO)


async def test_migrate_gov_company_to_faction_lossless_and_idempotent(gov_db):
    cid = await _company(treasury=50_000, sector="Santé", name="Clinique")
    async with database.db_connection() as db:
        await db.execute("INSERT INTO company_shares(user_id, company_id, shares) VALUES (?,?,?)", (MGR, cid, 30))
        await db.commit()
    ow_before, mgr_before = await _balance(OWNER), await _balance(MGR)
    assert await factions.migrate_gov_companies() == 1
    assert await factions.migrate_gov_companies() == 0                       # idempotent
    m_owner = await factions.get_membership(OWNER)
    assert m_owner["faction"] == "sante" and m_owner["rank"] > GOV_FACTIONS["sante"]["auto_cap"]
    assert (await factions.get_membership(EMP1))["rank"] <= GOV_FACTIONS["sante"]["auto_cap"]
    # trésorerie répartie : moitié aux actionnaires, reste au créateur ; total conservé
    gained = (await _balance(OWNER) - ow_before) + (await _balance(MGR) - mgr_before)
    assert gained == 50_000 and await _balance(MGR) - mgr_before == 25_000
    async with database.db_connection() as db:
        async with db.execute("SELECT dissolved, treasury FROM companies WHERE company_id=?", (cid,)) as c:
            assert tuple(await c.fetchone()) == (1, 0)
        async with db.execute("SELECT COUNT(*) FROM company_members WHERE company_id=?", (cid,)) as c:
            assert (await c.fetchone())[0] == 0
    assert any(t == "🏛️ Entreprise nationalisée" for _, t, _ in gov_db["sent"])


async def test_private_sector_company_untouched_by_migration(gov_db):
    await _company(sector="Commerce")
    assert await factions.migrate_gov_companies() == 0


def test_requirements_scale_beyond_table():
    from config import PROMOTION_REQUIREMENTS
    last = max(PROMOTION_REQUIREMENTS)
    assert factions.requirements_for(PROMOTION_REQUIREMENTS, last + 2)["activity"] > PROMOTION_REQUIREMENTS[last]["activity"]


async def test_service_le_temps_de_jeu_en_service_donne_l_activite(gov_db, monkeypatch):
    import utils.duty as duty
    from config import ACTIVITY_MINUTES_PER_POINT, DUTY_MAX_SECONDS
    assert (await factions.join_faction(MGR, "police"))[0]
    t = {"v": 1_000_000}
    monkeypatch.setattr(duty, "now", lambda: t["v"])                          # horloge DE JEU
    assert await duty.start_duty(MGR) and not await duty.start_duty(MGR)      # déjà en service
    t["v"] += ACTIVITY_MINUTES_PER_POINT * 60 * 3 + 30                        # 3 tranches complètes
    was_on, elapsed, pts = await duty.stop_duty(MGR)
    assert was_on and pts == 3
    await duty.credit_activity(MGR, "faction", None, pts)
    async with database.db_connection() as db:
        async with db.execute("SELECT activity_score FROM faction_members WHERE user_id=?", (MGR,)) as cur:
            assert (await cur.fetchone())[0] == 3
    assert (await duty.stop_duty(MGR))[0] is False                            # plus en service
    # plafond : un service oublié pendant 24 h de jeu ne compte que DUTY_MAX_SECONDS
    assert duty.points_for(24 * 3600) == duty.points_for(DUTY_MAX_SECONDS)


async def test_paie_ne_donne_plus_d_activite_automatique(gov_db):
    cid = await _company()
    await payroll.pay_company(cid, 7)
    async with database.db_connection() as db:
        async with db.execute("SELECT activity_score FROM company_members WHERE user_id=? AND company_id=?",
                              (EMP1, cid)) as cur:
            assert (await cur.fetchone())[0] == 0
