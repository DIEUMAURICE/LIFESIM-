import asyncio

import pytest

from utils.user_locks import KeyedLocks, run_serialized_per_user, user_locks


@pytest.mark.asyncio
async def test_same_user_is_serialized():
    order = []

    async def job(tag):
        order.append(f"start-{tag}")
        await asyncio.sleep(0.02)
        order.append(f"end-{tag}")

    await asyncio.gather(
        run_serialized_per_user(1, job("a")),
        run_serialized_per_user(1, job("b")),
    )
    assert order == ["start-a", "end-a", "start-b", "end-b"]


@pytest.mark.asyncio
async def test_different_users_run_in_parallel():
    running = 0
    peak = 0

    async def job():
        nonlocal running, peak
        running += 1
        peak = max(peak, running)
        await asyncio.sleep(0.02)
        running -= 1

    await asyncio.gather(*(run_serialized_per_user(i, job()) for i in range(20)))
    assert peak == 20


@pytest.mark.asyncio
async def test_locks_are_cleaned_up():
    locks = KeyedLocks()

    async def work():
        async with locks.hold(42):
            await asyncio.sleep(0.01)

    await asyncio.gather(*(work() for _ in range(10)))
    assert len(locks) == 0
    assert len(user_locks) == 0


@pytest.mark.asyncio
async def test_exception_releases_lock():
    async def boom():
        raise ValueError("x")

    with pytest.raises(ValueError):
        await run_serialized_per_user(7, boom())

    async def ok():
        return None

    await asyncio.wait_for(run_serialized_per_user(7, ok()), timeout=1)
    assert len(user_locks) == 0
