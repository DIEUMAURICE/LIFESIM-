# test/test_arms_justice_ui.py — écrans à boutons : marché noir, armes, chambre d'armes, Justice
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from types import SimpleNamespace

import pytest
import pytest_asyncio

import database
import migrations
import utils.factions as factions
import utils.justice as justice
import utils.ordre as ordre
import utils.weapons as weapons
import handlers.justice as jui
import handlers.weapons as wui
import handlers.ordre as oui
from test.test_ordre_ui import Recorder

JUGE, AVO, SOL, CIV1 = 601, 602, 603, 604
USERS = (JUGE, AVO, SOL, CIV1)


async def click(module_cb, uid, data, ctx=None):
    q = Recorder(uid, data)
    ctx = ctx or SimpleNamespace(bot=SimpleNamespace(), user_data={})
    upd = SimpleNamespace(callback_query=q, effective_user=q.from_user, effective_message=q.message)
    await module_cb(upd, ctx)
    return q


@pytest_asyncio.fixture
async def udb(monkeypatch, tmp_path):
    path = str(tmp_path / "ajui.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()

    async def fake_notify(*a, **k):
        return None

    clock = {"t": 10 * 86400}
    for mod in (ordre, factions, justice, weapons):
        monkeypatch.setattr(mod, "notify", fake_notify)
    monkeypatch.setattr(ordre, "now", lambda: clock["t"])
    monkeypatch.setattr(justice, "now", lambda: clock["t"])
    monkeypatch.setattr(justice, "real_now", lambda: clock["t"])
    monkeypatch.setattr(weapons, "real_now", lambda: clock["t"])

    async def free(uid):
        return False

    async def role(uid):
        return "PLAYER"

    monkeypatch.setattr(ordre, "is_protected", free)
    monkeypatch.setattr(oui, "get_user_role_async", role)
    import utils.location as loc

    async def pos(uid):
        return {"location": "tribunal", "in_transit": False}

    monkeypatch.setattr(loc, "get_position", pos)
    monkeypatch.setattr(loc, "is_exempt", free)
    for uid in USERS:
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 1_000_000)
    yield clock


async def _staff(uid, faction, post, station="central", duty=True):
    async with database.db_connection() as db:
        await ordre._set_post(db, uid, faction, station, post)
        await db.execute("UPDATE ordre_staff SET on_duty=? WHERE user_id=?", (1 if duty else 0, uid))
        await db.commit()


async def test_black_market_screens(udb):
    q = await click(wui.wp_callback, CIV1, "wp:shop")
    assert "Marché noir" in q.text and "wp:buy:pistolet" in q.buttons
    assert "wp:buy:taser" not in q.buttons                      # le taser n'est pas en vente
    q = await click(wui.wp_callback, CIV1, "wp:buy:pistolet")
    assert "acheté" in q.text and "wp:ammo:pistolet" in q.buttons
    q = await click(wui.wp_callback, CIV1, "wp:eq:pistolet")
    assert "équipé" in q.text
    q = await click(wui.wp_callback, CIV1, "wp:inv")
    assert "wp:uneq" in q.buttons
    q = await click(wui.wp_callback, CIV1, "wp:arm")
    assert "Réservé" in q.text


async def test_armory_screens(udb):
    await _staff(SOL, "armee", "armurier")
    async with database.db_connection() as db:
        await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES ('armee', 500000)")
        await db.execute("UPDATE faction_state SET budget=500000 WHERE faction='armee'")
        await db.commit()
    q = await click(wui.wp_callback, SOL, "wp:arm")
    assert "wp:cr:pistolet" in q.buttons
    q = await click(wui.wp_callback, SOL, "wp:cr:pistolet")
    assert "fabriqué" in q.text and "wp:take:pistolet" in q.buttons and "wp:dl:pistolet" in q.buttons
    q = await click(wui.wp_callback, SOL, "wp:take:pistolet")
    assert "retiré" in q.text
    q = await click(wui.wp_callback, SOL, "wp:inv")
    assert "wp:ret:pistolet" in q.buttons


async def test_justice_screens(udb):
    await ordre.appoint_dg(1, JUGE, "justice")
    await _staff(JUGE, "justice", "juge")
    await _staff(AVO, "justice", "avocat")
    q = await click(jui.jus_callback, CIV1, "jus:home")
    assert "Justice" in q.text and "jus:me" in q.buttons
    q = await click(jui.jus_callback, CIV1, "jus:me")
    assert "Aucun dossier" in q.text
    await database.update_field(CIV1, "prison_until", udb["t"] + 3000)
    fid = await justice.open_file(CIV1, "Cambriolage", "police", 3000)
    q = await click(jui.jus_callback, JUGE, "jus:files")
    assert f"jus:f:{fid}" in q.buttons
    q = await click(jui.jus_callback, JUGE, f"jus:f:{fid}")
    assert any(b.startswith(f"jus:bail:{fid}:") for b in q.buttons) and any(b.startswith(f"jus:ve:{fid}:") for b in q.buttons)
    q = await click(jui.jus_callback, JUGE, f"jus:bail:{fid}:25000")
    assert "Caution fixée" in q.text
    q = await click(jui.jus_callback, CIV1, "jus:me")
    assert "jus:pay" in q.buttons and "jus:law" in q.buttons
    q = await click(jui.jus_callback, CIV1, "jus:law")
    assert f"jus:hire:{AVO}" in q.buttons
    q = await click(jui.jus_callback, CIV1, f"jus:hire:{AVO}")
    assert "Avocat engagé" in q.text
    q = await click(jui.jus_callback, AVO, "jus:cl")
    assert f"jus:pl:{fid}" in q.buttons
    q = await click(jui.jus_callback, AVO, f"jus:pl:{fid}")
    assert "laidoirie" in q.text
    q = await click(jui.jus_callback, JUGE, f"jus:ve:{fid}:acquit:0")
    assert "jugé" in q.text
    assert (await database.get_user(CIV1))["prison_until"] == 0
    q = await click(jui.jus_callback, CIV1, "jus:files")             # un civil n'a pas accès aux dossiers
    assert "Réservé" in q.text


async def test_recruit_menus_include_all_factions(udb, monkeypatch):
    import handlers.sante as hs

    async def no_housing_error(uid):
        return None

    monkeypatch.setattr(hs, "_housing_error", no_housing_error)
    q = await click(oui.ord_callback, CIV1, "ord:apply")
    for f in ("police", "armee", "justice", "sante"):
        assert f"ord:apf:{f}" in q.buttons
    q = await click(oui.ord_callback, CIV1, "ord:apf:sante")
    assert "ord:ap:sante:sud" in q.buttons
    q = await click(oui.ord_callback, CIV1, "ord:ap:justice:central")
    assert "Candidature envoyée" in q.text
