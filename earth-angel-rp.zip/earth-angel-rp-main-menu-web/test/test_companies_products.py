"""test/test_companies_products.py — Catalogue de produits des entreprises.

Couvre `gameplay/companies.py` (le service pur, réel via une base migrée, sans mocks sur les
tables produits) et `webapp/routers/companies_router.py` (délégation au même service, contrôles
d'accès PDG/gérant), exactement comme `handlers/company_products.py` les appelle désormais.
"""
import asyncio
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
import gameplay.companies as companies_service
from webapp.routers import companies_router
from webapp.server import app


@pytest_asyncio.fixture
async def persistent_companies_db(monkeypatch, tmp_path):
    """Base réelle (schéma + migrations) pour vérifier que le service pur lit/écrit bien les
    tables `company_products`/`items`/`inventory` — pas de mocks sur ces tables."""
    path = str(tmp_path / "companies-persistent.db")
    pool = database.SQLiteConnectionPool(path, size=3)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(database, "_db_global_lock", asyncio.Lock())
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    yield path
    await database._DB_POOL.close()


async def _seed_company_with_product(owner_id: int, company_id: int, *, stock: int = 3) -> int:
    """Crée une entreprise, son PDG et un produit en stock dans son inventaire. → item_id."""
    async with database.db_connection() as db:
        await db.execute(
            "INSERT INTO companies (company_id,name,owner_id,sector,treasury,reputation,level,dissolved,created_at) "
            "VALUES (?,?,?,?,0,50,1,0,?)",
            (company_id, f"Société {company_id}", owner_id, "Tech", database.now()),
        )
        await db.execute(
            "INSERT INTO company_members (user_id,company_id,poste,salary,base_salary,activity_score,joined_at) "
            "VALUES (?,?,'PDG',0,0,0,?)",
            (owner_id, company_id, database.now()),
        )
        cur = await db.execute(
            "INSERT INTO items (name,type,value,emoji) VALUES (?,?,?,?)",
            ("Gadget", "product", 100, "🔧"),
        )
        item_id = cur.lastrowid
        await db.execute(
            "INSERT INTO company_products (company_id,name,price,sales,revenue) VALUES (?,?,?,0,0)",
            (company_id, "Gadget", 100),
        )
        await db.execute(
            "INSERT INTO inventory (user_id,item_id,item_type,item_name,quantity,acquired_at) VALUES (?,?,?,?,?,?)",
            (owner_id, item_id, "product", "Gadget", stock, database.now()),
        )
        await db.commit()
    return item_id


# ─────────────────────────── gameplay/companies.py (service pur) ───────────────────────────


@pytest.mark.asyncio
async def test_list_products_reports_price_sales_and_caller_stock(persistent_companies_db):
    await _seed_company_with_product(owner_id=1, company_id=10, stock=7)

    products = await companies_service.list_products(1, 10)

    assert len(products) == 1
    assert products[0]["name"] == "Gadget"
    assert products[0]["price"] == 100
    assert products[0]["stock"] == 7


@pytest.mark.asyncio
async def test_list_products_shows_zero_stock_for_a_non_owning_caller(persistent_companies_db):
    await _seed_company_with_product(owner_id=1, company_id=10, stock=7)

    products = await companies_service.list_products(999, 10)

    assert products[0]["stock"] == 0


@pytest.mark.asyncio
async def test_set_product_price_updates_items_and_company_products(persistent_companies_db):
    await _seed_company_with_product(owner_id=1, company_id=10)

    ok = await companies_service.set_product_price(10, "Gadget", 250)
    assert ok is True

    async with database.db_connection() as db:
        async with db.execute("SELECT value FROM items WHERE name='Gadget'") as cur:
            assert (await cur.fetchone())[0] == 250
        async with db.execute("SELECT price FROM company_products WHERE company_id=10 AND name='Gadget'") as cur:
            assert (await cur.fetchone())[0] == 250


@pytest.mark.asyncio
async def test_set_product_price_rejects_a_negative_price(persistent_companies_db):
    await _seed_company_with_product(owner_id=1, company_id=10)
    with pytest.raises(ValueError):
        await companies_service.set_product_price(10, "Gadget", -1)


@pytest.mark.asyncio
async def test_set_product_price_returns_false_for_an_unknown_product(persistent_companies_db):
    await _seed_company_with_product(owner_id=1, company_id=10)
    assert await companies_service.set_product_price(10, "Inconnu", 50) is False


@pytest.mark.asyncio
async def test_delete_product_removes_catalogue_item_and_owner_inventory_rows(persistent_companies_db):
    await _seed_company_with_product(owner_id=1, company_id=10)

    ok = await companies_service.delete_product(10, 1, "Gadget")
    assert ok is True

    async with database.db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM company_products WHERE company_id=10") as cur:
            assert (await cur.fetchone())[0] == 0
        async with db.execute("SELECT COUNT(*) FROM items WHERE name='Gadget'") as cur:
            assert (await cur.fetchone())[0] == 0
        async with db.execute("SELECT COUNT(*) FROM inventory WHERE user_id=1 AND item_name='Gadget'") as cur:
            assert (await cur.fetchone())[0] == 0


@pytest.mark.asyncio
async def test_delete_product_returns_false_when_not_in_the_catalogue(persistent_companies_db):
    await _seed_company_with_product(owner_id=1, company_id=10)
    assert await companies_service.delete_product(10, 1, "Inconnu") is False


@pytest.mark.asyncio
async def test_withdraw_product_decrements_owner_inventory(persistent_companies_db):
    item_id = await _seed_company_with_product(owner_id=1, company_id=10, stock=5)

    ok, message, name = await companies_service.withdraw_product(1, item_id, 2)

    assert ok is True
    assert name == "Gadget"
    assert "2" in message
    async with database.db_connection() as db:
        async with db.execute("SELECT quantity FROM inventory WHERE user_id=1 AND item_id=?", (item_id,)) as cur:
            assert (await cur.fetchone())[0] == 3


@pytest.mark.asyncio
async def test_withdraw_product_refuses_more_than_available(persistent_companies_db):
    item_id = await _seed_company_with_product(owner_id=1, company_id=10, stock=2)

    ok, message, name = await companies_service.withdraw_product(1, item_id, 5)

    assert ok is False
    assert name is None
    assert "2" in message
    async with database.db_connection() as db:
        async with db.execute("SELECT quantity FROM inventory WHERE user_id=1 AND item_id=?", (item_id,)) as cur:
            assert (await cur.fetchone())[0] == 2  # inchangé


@pytest.mark.asyncio
async def test_withdraw_product_rejects_a_non_positive_quantity(persistent_companies_db):
    item_id = await _seed_company_with_product(owner_id=1, company_id=10, stock=5)
    ok, message, name = await companies_service.withdraw_product(1, item_id, 0)
    assert ok is False
    assert name is None


# ─────────────────────────── webapp/routers/companies_router.py ───────────────────────────


@pytest.mark.asyncio
async def test_products_route_delegates_for_the_owning_pdg(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 5}),
    )
    listing = AsyncMock(return_value=[{"name": "Gadget", "price": 100}])
    monkeypatch.setattr(companies_router.companies_service, "list_products", listing)

    result = await companies_router.products(user_id=5)

    assert result == {"products": [{"name": "Gadget", "price": 100}]}
    listing.assert_awaited_once_with(5, 10)


@pytest.mark.asyncio
async def test_products_route_refuses_a_non_owning_member(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 5}),
    )
    with pytest.raises(HTTPException) as exc:
        await companies_router.products(user_id=6)
    assert exc.value.status_code == 403


@pytest.mark.asyncio
async def test_set_product_price_route_delegates_for_a_manager(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 5}),
    )
    monkeypatch.setattr(companies_router, "can_manage", AsyncMock(return_value=True))
    set_price = AsyncMock(return_value=True)
    monkeypatch.setattr(companies_router.companies_service, "set_product_price", set_price)

    result = await companies_router.set_product_price(
        companies_router.ProductPriceIn(name="Gadget", price=250), user_id=7,
    )

    assert result == {"updated": True, "name": "Gadget", "price": 250}
    set_price.assert_awaited_once_with(10, "Gadget", 250)


@pytest.mark.asyncio
async def test_set_product_price_route_raises_404_for_an_unknown_product(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 5}),
    )
    monkeypatch.setattr(companies_router, "can_manage", AsyncMock(return_value=True))
    monkeypatch.setattr(companies_router.companies_service, "set_product_price", AsyncMock(return_value=False))

    with pytest.raises(HTTPException) as exc:
        await companies_router.set_product_price(
            companies_router.ProductPriceIn(name="Inconnu", price=10), user_id=5,
        )
    assert exc.value.status_code == 404


@pytest.mark.asyncio
async def test_set_product_price_route_rejects_a_negative_price_before_calling_the_service(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 5}),
    )
    monkeypatch.setattr(companies_router, "can_manage", AsyncMock(return_value=True))
    set_price = AsyncMock()
    monkeypatch.setattr(companies_router.companies_service, "set_product_price", set_price)

    with pytest.raises(HTTPException) as exc:
        await companies_router.set_product_price(
            companies_router.ProductPriceIn(name="Gadget", price=-5), user_id=5,
        )
    assert exc.value.status_code == 422
    set_price.assert_not_awaited()


@pytest.mark.asyncio
async def test_delete_product_route_refuses_a_plain_employee(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 5}),
    )
    monkeypatch.setattr(companies_router, "can_manage", AsyncMock(return_value=False))
    delete = AsyncMock()
    monkeypatch.setattr(companies_router.companies_service, "delete_product", delete)

    with pytest.raises(HTTPException) as exc:
        await companies_router.delete_product(companies_router.ProductNameIn(name="Gadget"), user_id=9)
    assert exc.value.status_code == 403
    delete.assert_not_awaited()


@pytest.mark.asyncio
async def test_withdraw_product_route_delegates_and_reports_the_service_refusal(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 5}),
    )
    monkeypatch.setattr(companies_router, "can_manage", AsyncMock(return_value=True))
    withdraw = AsyncMock(return_value=(False, "Quantité insuffisante. Tu en possèdes 1.", None))
    monkeypatch.setattr(companies_router.companies_service, "withdraw_product", withdraw)

    with pytest.raises(HTTPException) as exc:
        await companies_router.withdraw_product(
            companies_router.ProductWithdrawIn(item_id=42, quantity=5), user_id=5,
        )
    assert exc.value.status_code == 422
    assert "insuffisante" in exc.value.detail
    withdraw.assert_awaited_once_with(5, 42, 5)


def test_companies_product_routes_are_registered_on_the_shared_api():
    paths = {route.path for route in app.routes}
    assert "/api/companies/products" in paths
    assert "/api/companies/products/price" in paths
    assert "/api/companies/products/delete" in paths
    assert "/api/companies/products/withdraw" in paths
