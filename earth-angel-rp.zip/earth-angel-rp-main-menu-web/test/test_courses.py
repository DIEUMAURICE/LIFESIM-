# test/test_courses.py — cours à réviser puis examen par questions sur les cours révisés
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from types import SimpleNamespace

import pytest
import pytest_asyncio

import database
import migrations
import handlers.education as edu
import utils.courses as courses
from config import JOBS
from test.test_ordre_ui import Recorder

STU, STU2 = 801, 802


@pytest_asyncio.fixture
async def edb(monkeypatch, tmp_path):
    path = str(tmp_path / "edu.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    clock = {"t": 10 * 86400}
    monkeypatch.setattr(edu, "now", lambda: clock["t"])
    monkeypatch.setattr(courses, "now", lambda: clock["t"])

    async def no_xp(*a, **k):
        return None

    monkeypatch.setattr(edu, "add_xp", no_xp)
    for uid in (STU, STU2):
        await database.get_user(uid, f"u{uid}", f"Eleve{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 5_000_000)
    yield clock


async def _enroll(uid, dip_index=0):
    q = Recorder(uid, "x")
    await edu.do_inscription(q, uid, dip_index)
    return q


def _right_choice(ex):
    return ex["questions"][ex["pos"]]["a"]


# ─── Catalogue ───────────────────────────────────────────────────────────────
async def test_catalog_is_well_formed():
    assert len(courses.catalog()) >= 12
    for lid, les in courses.catalog().items():
        assert les["text"] and les["title"] and 0 <= les["level"] <= 2, lid
        assert les["questions"], lid
        for q in les["questions"]:
            opts = [q["right"], *q["wrong"]]
            assert len(set(opts)) == len(opts) >= 3 and q["right"] not in q["wrong"], (lid, q["q"])
    for dip in edu.DIPLOME_ORDER:                              # un cours « importance du diplôme » pour chacun
        les = courses.lesson(f"dip:{dip}")
        assert les and les["questions"] and dip in les["text"]
        for q in les["questions"]:
            opts = [q["right"], *q["wrong"]]
            assert len(set(opts)) == len(opts) >= 3, (dip, q["q"])
    jobs = [j for j, v in JOBS.items() if v["need"] == "Licence"]
    les = courses.lesson("dip:Licence")
    assert all(j in les["text"] for j in jobs)                 # les métiers débloqués viennent de la config


# ─── Réviser = recevoir un cours ─────────────────────────────────────────────
async def test_revision_gives_lessons(edb):
    q = await _enroll(STU)
    assert "Inscription réussie" in q.text and "cours" in q.text.lower()
    seen_titles = []
    for n in range(1, courses.MAX_REVISIONS + 1):
        q = Recorder(STU, "edu_reviser")
        await edu.do_reviser_btn(q, STU)
        assert f"COURS {n}/{courses.MAX_REVISIONS}" in q.text
        if n == 1:
            assert "Brevet" in q.text                          # 1er cours : l'importance du diplôme préparé
        seen_titles.append(q.text.split("\n")[0])
        await database.update_field(STU, "energy", 100)
    assert len(set(seen_titles)) == courses.MAX_REVISIONS      # jamais deux fois le même cours
    q = Recorder(STU, "edu_reviser")
    await edu.do_reviser_btn(q, STU)
    assert "maximum" in q.text
    q = Recorder(STU, "edu_cours")
    await edu.show_cours_menu(q, STU)
    assert "Mes cours" in q.text and len(q.screens[-1][1].inline_keyboard) >= courses.MAX_REVISIONS
    q = Recorder(STU, "edu_lecon_0")
    await edu.show_lecon(q, STU, 0)
    assert "Brevet" in q.text


async def test_revision_needs_energy_and_enrollment(edb):
    q = Recorder(STU, "edu_reviser")
    await edu.do_reviser_btn(q, STU)
    assert "aucune formation" in q.text
    await _enroll(STU)
    await database.update_field(STU, "energy", 5)
    q = Recorder(STU, "edu_reviser")
    await edu.do_reviser_btn(q, STU)
    assert "fatigué" in q.text and await courses.seen_lessons(STU, "Brevet") == []


# ─── Examen : questions sur les cours révisés ───────────────────────────────
async def test_exam_requires_time_and_revisions(edb):
    await _enroll(STU)
    q = Recorder(STU, "edu_examen")
    await edu.do_examen_btn(q, STU)
    assert "Pas encore prêt" in q.text
    edb["t"] += 10 ** 6                                        # le temps de formation est écoulé
    q = Recorder(STU, "edu_examen")
    await edu.do_examen_btn(q, STU)
    assert "aucun cours" in q.text                             # rien révisé : pas d'examen


async def test_exam_questions_come_from_revised_lessons_and_pass(edb):
    await _enroll(STU)
    for _ in range(3):
        await edu.do_reviser_btn(Recorder(STU, "r"), STU)
        await database.update_field(STU, "energy", 100)
    seen = set(await courses.seen_lessons(STU, "Brevet"))
    edb["t"] += 10 ** 6
    q = Recorder(STU, "edu_examen")
    await edu.do_examen_btn(q, STU)
    assert "Question 1/3" in q.text and "bonnes réponses" in q.text
    ex = await courses.get_exam(STU)
    assert ex["total"] == 3 and {x["lid"] for x in ex["questions"]} <= seen   # uniquement les cours révisés
    # reprise : rouvrir l'examen redonne la même question
    q = Recorder(STU, "edu_examen")
    await edu.do_examen_btn(q, STU)
    assert "Question 1/3" in q.text
    for i in range(3):
        ex = await courses.get_exam(STU)
        q = Recorder(STU, f"edu_rep_{_right_choice(ex)}")
        await edu.do_reponse(q, STU, _right_choice(ex))
        assert "Bonne réponse" in q.text
        q = Recorder(STU, "edu_suite")
        await edu.do_examen_btn(q, STU)
    assert "FÉLICITATIONS" in q.text and "3/3" in q.text and "Très Bien" in q.text
    assert (await database.get_user(STU))["diplome"] == "Brevet"
    assert (await database.get_user(STU))["study_diplome"] == ""
    assert await courses.get_exam(STU) is None
    assert "Bonus de salaire" in q.text


async def test_exam_failure_and_retry(edb):
    await _enroll(STU2)
    for _ in range(2):
        await edu.do_reviser_btn(Recorder(STU2, "r"), STU2)
        await database.update_field(STU2, "energy", 100)
    edb["t"] += 10 ** 6
    await edu.do_examen_btn(Recorder(STU2, "e"), STU2)
    last = None
    for i in range(2):
        ex = await courses.get_exam(STU2)
        wrong = (_right_choice(ex) + 1) % 4
        await edu.do_reponse(Recorder(STU2, "x"), STU2, wrong)
        last = Recorder(STU2, "edu_suite")
        await edu.do_examen_btn(last, STU2)
    assert "ÉCHEC" in last.text and "0/2" in last.text and "Pour repasser" in last.text
    u = await database.get_user(STU2)
    assert u["diplome"] in ("", None) and u["study_diplome"] == ""
    # réinscription : on repart de zéro (cours et examen effacés)
    await _enroll(STU2)
    assert await courses.seen_lessons(STU2, "Brevet") == [] and await courses.get_exam(STU2) is None


async def test_commands_use_the_same_screens(edb):
    replies = []

    async def reply_text(text, **k):
        replies.append(text)

    msg = SimpleNamespace(reply_text=reply_text)
    await _enroll(STU)
    await edu.do_reviser_btn(edu._MsgQuery(msg), STU)
    assert "COURS 1/" in replies[-1]
    await edu.show_cours_menu(edu._MsgQuery(msg), STU)
    assert "Mes cours" in replies[-1]


async def test_pass_threshold_grows_with_diploma():
    n = len(edu.DIPLOME_ORDER)
    assert courses.needed(5, 0, n) == 3 and courses.needed(5, n - 1, n) == 4
    assert courses.needed(1, 0, n) == 1
    assert courses.mention(10, 10) == "Très Bien" and courses.mention(3, 5) == "Passable"
