import pytest
import pytest_asyncio

import database
import migrations
from gameplay.combat import resolve_combat
from gameplay.missions import reward_summary
from utils.arena_store import accept_and_fund_match, create_match


@pytest_asyncio.fixture
async def gameplay_db(monkeypatch, tmp_path):
    path = str(tmp_path / "combat.db")
    pool = database.SQLiteConnectionPool(path, size=8)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    for uid in (1, 2):
        await database.get_user(uid, f"u{uid}", f"Player {uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 10_000)
    yield


@pytest.mark.asyncio
async def test_combat_service_settles_and_updates_the_same_effects(gameplay_db, monkeypatch):
    monkeypatch.setattr("gameplay.combat.random.randint", lambda low, high: low)
    monkeypatch.setattr("gameplay.combat.random.random", lambda: 1.0)
    match_id = await create_match(1, 2, "combat", 500)
    assert await accept_and_fund_match(match_id, 2)

    result = await resolve_combat(match_id)

    assert result is not None
    assert result.winner_id in (1, 2)
    assert result.pot == 1_000
    assert result.challenger_hp >= 0 and result.target_hp >= 0
    match = await __import__("utils.arena_store", fromlist=["get_match"]).get_match(match_id)
    assert match["status"] == "completed"
    winner = (await database.get_user(result.winner_id))["balance"]
    loser = (await database.get_user(result.loser_id))["balance"]
    assert winner == 10_500
    assert loser == 9_500


@pytest.mark.asyncio
async def test_mission_summary_reads_actual_logged_reward(gameplay_db):
    await database.update_field(1, "balance", 1_000)
    async with database.db_connection() as db:
        await db.execute(
            "INSERT INTO missions(user_id,mission_name,mission_type,progress,target,reward,xp_reward,completed,period,reset_at,completed_at) "
            "VALUES (1,'Combat test','arena_win',1,1,999,999,1,'weekly',0,12345)"
        )
        await db.execute(
            "INSERT INTO mission_log(user_id,mission_name,reward,xp,completed_at) VALUES (1,'Combat test',321,77,12345)"
        )
        await db.commit()

    summary = await reward_summary(1)

    assert summary["completed_count"] == 1
    assert summary["total_coins"] == 321
    assert summary["total_xp"] == 77
    assert summary["missions"][0]["reward"] == 321
