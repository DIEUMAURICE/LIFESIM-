"""Création de personnage simplifiée + groupes non autorisés (le bot ne quitte jamais)."""
from unittest.mock import AsyncMock, MagicMock

from utils import character, groups


def test_character_only_three_fields():
    assert character.STEPS == ["first_name", "last_name", "gender"]
    assert character.next_missing({}) == "first_name"


def test_character_rejects_old_fields():
    assert "story" not in character.FIELD_LABEL and "origin" not in character.FIELD_LABEL


async def test_unauthorized_group_never_leaves(monkeypatch):
    monkeypatch.setattr(groups, "is_authorized", AsyncMock(return_value=False))
    monkeypatch.setattr(groups, "WARN_MIN_INTERVAL", 0)
    ctx = MagicMock(); ctx.bot.send_message = AsyncMock(); ctx.bot.leave_chat = AsyncMock()
    upd = MagicMock(); upd.my_chat_member = None
    upd.effective_chat.type = "supergroup"; upd.effective_chat.id = -100
    upd.effective_message.text = "/start"; upd.effective_user.id = 5
    assert await groups.group_guard(upd, ctx) is False
    assert await groups.group_guard(upd, ctx) is False
    assert ctx.bot.send_message.await_count == 2
    assert "@mauridieu" in ctx.bot.send_message.await_args.args[1]
    ctx.bot.leave_chat.assert_not_awaited()
