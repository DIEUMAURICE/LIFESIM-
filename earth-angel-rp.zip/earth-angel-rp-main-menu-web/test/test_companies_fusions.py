"""test/test_companies_fusions.py — Fusions d'entreprises (proposer, répondre).

Service pur sur une vraie base migrée (`gameplay/companies.py`) + routeur. Couvre en particulier
les deux bugs corrigés à l'extraction : fusion des parts quand un actionnaire détient les deux
entreprises (l'ancien `UPDATE company_shares SET company_id=...` violait la clé primaire), et
notification de refus adressée au PDG émetteur (et non à un company_id).
"""
import asyncio
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
import gameplay.companies as companies_service
from webapp.routers import companies_router
from webapp.server import app


@pytest_asyncio.fixture
async def persistent_companies_db(monkeypatch, tmp_path):
    path = str(tmp_path / "companies-fusions-persistent.db")
    pool = database.SQLiteConnectionPool(path, size=3)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(database, "_db_global_lock", asyncio.Lock())
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    yield path
    await database._DB_POOL.close()


async def _seed_company(company_id, owner_id, *, treasury=100_000, reputation=50, dissolved=0):
    async with database.db_connection() as db:
        await db.execute(
            "INSERT INTO users (user_id, full_name, balance) VALUES (?,?,0) ON CONFLICT(user_id) DO NOTHING",
            (owner_id, f"Joueur {owner_id}"),
        )
        await db.execute(
            "INSERT INTO companies (company_id,name,owner_id,sector,treasury,reputation,level,dissolved,created_at) "
            "VALUES (?,?,?,?,?,?,1,?,?)",
            (company_id, f"Société {company_id}", owner_id, "Tech", treasury, reputation, dissolved, database.now()),
        )
        await db.execute(
            "INSERT INTO company_members (user_id,company_id,poste,salary,base_salary,activity_score,joined_at) "
            "VALUES (?,?,'PDG',0,0,0,?)",
            (owner_id, company_id, database.now()),
        )
        await db.execute("INSERT INTO company_shares (user_id,company_id,shares) VALUES (?,?,100)", (owner_id, company_id))
        await db.commit()


async def _one(sql, params=()):
    async with database.db_connection() as db:
        async with db.execute(sql, params) as cur:
            return await cur.fetchone()


async def _notes(user_id):
    async with database.db_connection() as db:
        async with db.execute("SELECT message FROM notifications WHERE user_id=?", (user_id,)) as cur:
            return [r[0] for r in await cur.fetchall()]


def test_fusion_valuation_matches_the_original_formula():
    assert companies_service.fusion_valuation(100_000, 50) == 100_000 + (100_000 // 10) * 50 // 100


@pytest.mark.asyncio
async def test_propose_fusion_inserts_request_and_notifies_target_owner(persistent_companies_db):
    await _seed_company(10, 1)
    await _seed_company(20, 2)
    result = await companies_service.propose_fusion(10, "Société 10", 20)
    assert result["ok"] is True and result["target_owner_id"] == 2
    assert (await _one("SELECT status, amount FROM fusion_requests WHERE request_id=?", (result["request_id"],))) == ("pending", 100_000)
    assert any("Société 10" in n for n in await _notes(2))


@pytest.mark.asyncio
async def test_propose_fusion_refusals(persistent_companies_db):
    await _seed_company(10, 1)
    await _seed_company(20, 2)
    await _seed_company(30, 3, dissolved=1)
    assert await companies_service.propose_fusion(10, "S", 10) == {"ok": False, "reason": "same_company"}
    assert await companies_service.propose_fusion(10, "S", 99) == {"ok": False, "reason": "target_not_found"}
    assert await companies_service.propose_fusion(10, "S", 30) == {"ok": False, "reason": "target_dissolved"}
    await companies_service.propose_fusion(10, "S", 20)
    assert await companies_service.propose_fusion(20, "S", 10) == {"ok": False, "reason": "already_pending"}


@pytest.mark.asyncio
async def test_respond_fusion_accept_absorbs_target_and_merges_overlapping_shares(persistent_companies_db):
    await _seed_company(10, 1, treasury=1_000_000)
    await _seed_company(20, 2, treasury=10_000, reputation=50)
    # Le PDG 1 détient aussi 40 parts de l'entreprise 20 : l'ancien UPDATE aurait violé la clé primaire.
    async with database.db_connection() as db:
        await db.execute("INSERT INTO company_shares (user_id,company_id,shares) VALUES (1,20,40)")
        await db.commit()
    await companies_service.propose_fusion(10, "Société 10", 20)

    result = await companies_service.respond_fusion(2, 20, True)

    valuation = companies_service.fusion_valuation(10_000, 50)
    assert result["ok"] is True and result["accepted"] is True and result["valuation"] == valuation
    assert (await _one("SELECT treasury FROM companies WHERE company_id=10"))[0] == 1_000_000 - valuation
    assert (await _one("SELECT treasury, dissolved FROM companies WHERE company_id=20")) == (10_000 + valuation, 1)
    assert (await _one("SELECT company_id FROM company_members WHERE user_id=2"))[0] == 10
    assert (await _one("SELECT shares FROM company_shares WHERE user_id=1 AND company_id=10"))[0] == 140
    assert (await _one("SELECT shares FROM company_shares WHERE user_id=2 AND company_id=10"))[0] == 100
    assert (await _one("SELECT COUNT(*) FROM company_shares WHERE company_id=20"))[0] == 0
    assert any("acceptée" in n for n in await _notes(1))


@pytest.mark.asyncio
async def test_respond_fusion_refuse_notifies_the_proposing_owner(persistent_companies_db):
    await _seed_company(10, 1)
    await _seed_company(20, 2)
    await companies_service.propose_fusion(10, "Société 10", 20)
    result = await companies_service.respond_fusion(2, 20, False)
    assert result == {"ok": True, "accepted": False, "target_name": "Société 20"}
    assert any("refusé" in n for n in await _notes(1))
    assert await _notes(10) == []  # l'ancien bug écrivait sous le company_id


@pytest.mark.asyncio
async def test_respond_fusion_insufficient_treasury_marks_refused_without_mutation(persistent_companies_db):
    await _seed_company(10, 1, treasury=10)
    await _seed_company(20, 2, treasury=100_000)
    await companies_service.propose_fusion(10, "Société 10", 20)
    assert await companies_service.respond_fusion(2, 20, True) == {"ok": False, "reason": "insufficient_treasury"}
    assert (await _one("SELECT treasury FROM companies WHERE company_id=10"))[0] == 10
    assert (await _one("SELECT dissolved FROM companies WHERE company_id=20"))[0] == 0
    assert (await _one("SELECT status FROM fusion_requests"))[0] == "refused"


@pytest.mark.asyncio
async def test_respond_fusion_refuses_non_owner_and_missing_request(persistent_companies_db):
    await _seed_company(10, 1)
    await _seed_company(20, 2)
    assert await companies_service.respond_fusion(999, 20, True) == {"ok": False, "reason": "not_owner"}
    assert await companies_service.respond_fusion(2, 20, True) == {"ok": False, "reason": "no_request"}


@pytest.mark.asyncio
async def test_fusion_routes_delegate_and_check_ownership(monkeypatch):
    monkeypatch.setattr(companies_router.database, "get_user_company",
                        AsyncMock(return_value={"company_id": 10, "owner_id": 1, "name": "Acme"}))
    propose = AsyncMock(return_value={"ok": True, "request_id": 3})
    monkeypatch.setattr(companies_router.companies_service, "propose_fusion", propose)
    assert (await companies_router.propose_fusion(companies_router.ProposeFusionIn(target_company_id=20), user_id=1))["request_id"] == 3
    propose.assert_awaited_once_with(10, "Acme", 20)

    with pytest.raises(HTTPException) as exc:
        await companies_router.propose_fusion(companies_router.ProposeFusionIn(target_company_id=20), user_id=9)
    assert exc.value.status_code == 403

    monkeypatch.setattr(companies_router.companies_service, "respond_fusion",
                        AsyncMock(return_value={"ok": False, "reason": "insufficient_treasury"}))
    with pytest.raises(HTTPException) as exc:
        await companies_router.respond_fusion(companies_router.FusionDecisionIn(accept=True), user_id=1)
    assert exc.value.status_code == 422 and "trésorerie" in exc.value.detail


def test_fusion_routes_are_registered_on_the_shared_api():
    paths = {route.path for route in app.routes}
    assert {"/api/companies/fusions", "/api/companies/fusions/propose", "/api/companies/fusions/respond"} <= paths
