# test/test_chain.py — chaîne métiers → entreprises → produits finis, classements
import os
os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")
import pytest
import pytest_asyncio
import database
import migrations
import utils.chain as chain
import config_chain as cc
from database import db_connection, now


async def _boot(monkeypatch, tmp_path):
    path = str(tmp_path / "t.db")
    pool = database.SQLiteConnectionPool(path, size=5)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()


@pytest_asyncio.fixture
async def cdb(monkeypatch, tmp_path):
    await _boot(monkeypatch, tmp_path)
    for uid in (1, 2, 3, 4):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 100_000)
    async with db_connection() as db:
        await db.execute("INSERT INTO companies(name, owner_id, sector, treasury, level, created_at) "
                         "VALUES ('Resto', 2, 'Alimentation', 500000, 1, 0)")
        await db.execute("INSERT INTO company_members(user_id, company_id, poste, joined_at) VALUES (2,1,'PDG',0)")
        await db.commit()
    yield


@pytest.mark.asyncio
async def test_validate():
    assert cc.validate() == []


@pytest.mark.asyncio
async def test_mission_grants_goods_and_sell(cdb):
    r = await chain.record_mission(1, "Ouvrier", 3)
    assert r["units"] > 0
    goods = await chain.user_goods(1)
    assert goods[r["good"]] == r["units"]
    # vendre à une entreprise qui l'utilise
    sec_good = next(g for g in cc.sector_inputs("Alimentation"))
    async with db_connection() as db:
        await chain.inv_add(db, 1, sec_good, 5)
        await db.commit()
    bal = (await database.get_user(1))["balance"]
    ok, msg = await chain.sell_to_company(1, 1, sec_good, 5)
    assert ok, msg
    assert (await database.get_user(1))["balance"] > bal
    assert (await chain.stock_of(1))[sec_good] == 5


@pytest.mark.asyncio
async def test_counter_cap(cdb):
    async with db_connection() as db:
        await chain.inv_add(db, 1, "mat_brut", 100)
        await db.commit()
    ok, _ = await chain.counter_sell(1, "mat_brut", 30)
    assert ok
    ok, _ = await chain.counter_sell(1, "mat_brut", 1)
    assert not ok


@pytest.mark.asyncio
async def test_lines_and_dept(cdb):
    ok, _ = await chain.toggle_line(1, cc.RECIPES_BY_SECTOR["Alimentation"][0])
    assert ok
    ok, _ = await chain.set_member_dept(1, 2, list(cc.sector_depts("Alimentation"))[0])
    assert ok
    assert await chain.get_lines(1)


@pytest.mark.asyncio
async def test_promotion(cdb):
    st = await chain.promotion_status(1, "Ouvrier")
    assert st["next"] == 2 and not st["ok"]


@pytest.mark.asyncio
async def test_production_day(cdb):
    import utils.payroll as prod
    d = list(cc.sector_depts("Alimentation"))
    # activité : appro + cuisine
    await prod.record_activity(1, 40, dept=d[0])
    await prod.record_activity(1, 40, dept=d[1])
    r = await prod.produce_company(1)
    assert r["produced"] > 0, r
    assert r["sold"] > 0 and r["revenue"] > r["cost"]
    st = await chain.get_chain_state(1)
    assert st["xp"] > 0


@pytest.mark.asyncio
async def test_production_needs_activity(cdb):
    import utils.payroll as prod
    r = await prod.produce_company(1)
    assert r["produced"] == 0


@pytest.mark.asyncio
async def test_stock_inputs_used(cdb):
    import utils.payroll as prod
    d = list(cc.sector_depts("Alimentation"))
    async with db_connection() as db:
        await chain._stock_add(db, 1, "recolte", 40)
        await chain._stock_add(db, 1, "transport", 20)
        await chain._stock_add(db, 1, "salle", 20)
        await db.commit()
    await prod.record_activity(1, 60, dept=d[0])
    await prod.record_activity(1, 60, dept=d[1])
    r = await prod.produce_company(1)
    assert r["produced"] > 0
    assert r["cost"] < 12000


# ── Classements : tous les joueurs, ma position ──
@pytest.mark.asyncio
async def test_rankings_all_and_me(cdb):
    import utils.rankings as rk
    for uid in range(10, 40):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", uid * 10)
    p = await rk.get_page("richesse", 1, 10, per_page=15)
    assert p["total"] >= 34 and p["pages"] >= 3
    assert p["me"] and p["me"]["rank"] > 15                    # pas dans le haut : sa position est quand même donnée
    last = await rk.get_page("richesse", p["pages"], 10, per_page=15)
    assert last["rows"][-1]["rank"] == p["total"]              # jusqu'à la fin
    txt = rk.render_page(p)
    assert "Ton rang" in txt
    for key in rk.RANKINGS:                                      # aucun classement ne plante
        page = await rk.get_page(key, 1, 1)
        assert page["pages"] >= 1
        rk.render_page(page)
    assert (await rk.my_position("entreprises", 2))["rank"] == 1
    assert await rk.my_position("entreprises", 1) is None       # pas d'entreprise


@pytest.mark.asyncio
async def test_views_render(cdb):
    import handlers.chain as hc
    import handlers.rankings as hr
    async with db_connection() as db:
        await chain.inv_add(db, 1, "mat_brut", 5)
        await db.commit()
    for coro in (hc.goods_view(1), hc.sell_view(1, "mat_brut"), hc.co_view(2), hc.lines_view(2), hc.team_view(2),
                 hc.bids_view(2), hc.prices_view(2), hc.share_view(2), hc.lvl_view(2), hc.ws_view(1), hc.sv_view(1),
                 hc.promo_view(1), hr.menu_view(1), hr.view(1, "richesse", 1), hr.me_view(1, "richesse")):
        text, markup = await coro
        assert text and len(text) < 4096
        for row in markup.inline_keyboard:
            for b in row:
                assert len(b.callback_data.encode()) <= 64, b.callback_data
    for i in range(len(cc.SECTORS_CHAIN)):
        text, markup = hc.catalog_view(i)
        assert len(text) < 4096


@pytest.mark.asyncio
async def test_wholesale_and_use_goods(cdb):
    await database.update_field(3, "job", chain.MERCHANT_JOB)
    async with db_connection() as db:
        await db.execute("UPDATE companies SET sector='Énergie' WHERE company_id=1")
        await chain._stock_add(db, 1, "carburant", 10)
        await db.commit()
    ok, msg = await chain.buy_wholesale(4, 1, "carburant", 2)            # pas commerçant
    assert not ok
    bal = (await database.get_user(3))["balance"]
    ok, msg = await chain.buy_wholesale(3, 1, "carburant", 2)
    assert ok, msg
    assert (await database.get_user(3))["balance"] < bal
    assert (await chain.user_goods(3))["carburant"] == 2
    assert (await chain.stock_of(1))["carburant"] == 8
    # utilisation : il faut un véhicule actif
    ok, msg = await chain.use_chain_item(3, "Carburant")
    assert not ok and "véhicule" in msg
    async with db_connection() as db:
        cur = await db.execute("INSERT INTO vehicles(user_id, veh_type, fuel, condition) VALUES (3,'Voiture',0,100)")
        vid = cur.lastrowid
        await db.execute("UPDATE users SET active_vehicle_id=? WHERE user_id=3", (vid,))
        await db.commit()
    ok, msg = await chain.use_chain_item(3, "Carburant")
    assert ok, msg
    assert (await chain.user_goods(3)).get("carburant", 0) == 1
    async with db_connection() as db:
        async with db.execute("SELECT fuel FROM vehicles WHERE veh_id=?", (vid,)) as cur:
            assert (await cur.fetchone())[0] == 40


@pytest.mark.asyncio
async def test_service_needs_worker_on_duty(cdb):
    async with db_connection() as db:
        await chain._stock_add(db, 1, "gastro", 3)
        await db.commit()
    ok, msg, w = await chain.perform_service(3, 1, "gastro")
    assert not ok                                                       # personne en service
    async with db_connection() as db:
        await db.execute("UPDATE company_members SET dept='service' WHERE user_id=2")
        await db.execute("INSERT INTO work_duty(user_id, since) VALUES (2, 0)")
        await db.commit()
    await database.update_field(3, "hunger", 10)
    ok, msg, w = await chain.perform_service(3, 1, "gastro")
    assert ok, msg
    assert w == 2 and (await database.get_user(3))["hunger"] > 10
    assert (await chain.stock_of(1))["gastro"] == 2


@pytest.mark.asyncio
async def test_mission_flow_through_minigame_done(cdb):
    import handlers.work as work
    await database.update_field(1, "job", "Ouvrier")

    class Q:
        async def edit_message_text(self, *a, **k):
            self.out = a[0]
    q = Q()
    await work.on_minigame_done(q, 1, 3, 500, "🛠️", 1, "")
    assert "livré" in q.out.lower() or "Livré" in q.out
    prog = await chain.get_job_progress(1, "Ouvrier")
    assert prog["missions"] == 1
    assert (await chain.user_goods(1)).get("mat_brut", 0) > 0


@pytest.mark.asyncio
async def test_callback_dispatch(cdb):
    import handlers.chain as hc
    async with db_connection() as db:
        await chain.inv_add(db, 1, "recolte", 4)
        await db.commit()

    class Q:
        def __init__(self, uid, data):
            self.data, self.from_user, self.out = data, type("U", (), {"id": uid})(), None
        async def answer(self, *a, **k): pass
        async def edit_message_text(self, text, **k): self.out = text

    class Upd:
        def __init__(self, q): self.callback_query = q
    for uid, data in ((1, "ch:sell:recolte"), (1, "ch:s:recolte:1:a"), (2, "ch:ln:gastro"), (2, "ch:bd:recolte:p"),
                      (2, "ch:pr:repas:u"), (2, "ch:sh:50"), (2, "ch:lv:3"), (2, "ch:td:2:cuisine"), (1, "ch:ln:repas"),
                      (1, "ch:cat:3"), (1, "ch:goods")):
        q = Q(uid, data)
        await hc.chain_callback(Upd(q), None)
        assert q.out, data
    assert "Erreur" not in q.out
