# test/test_exam_history.py — historique des examens (service partagé bot/API)
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from unittest.mock import AsyncMock

import pytest_asyncio

import database
import migrations
import gameplay.education as edu
from webapp.routers import education_router as router

UID = 1101


@pytest_asyncio.fixture
async def hdb(monkeypatch, tmp_path):
    path = str(tmp_path / "exam-history.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=3))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    await database.get_user(UID, "u", "Eleve")
    yield


async def test_history_is_newest_first_with_mention_only_on_success(hdb, monkeypatch):
    clock = {"t": 1000}
    monkeypatch.setattr(edu, "now", lambda: clock["t"])
    await edu._record_exam(UID, "Brevet", 3, 10, 6, False)
    clock["t"] = 2000
    await edu._record_exam(UID, "Brevet", 9, 10, 6, True)
    history = await edu.exam_history(UID)
    assert [h["success"] for h in history] == [True, False]
    assert history[0]["mention"] == "Très Bien" and history[1]["mention"] is None
    assert history[1]["needed"] == 6 and history[0]["diploma"] == "Brevet"
    assert await edu.exam_history(UID + 1) == []


async def test_finalize_records_each_exam(hdb, monkeypatch):
    monkeypatch.setattr(edu.courses, "get_exam", AsyncMock(return_value={"score": 2, "total": 10}))
    monkeypatch.setattr(edu.courses, "finish", AsyncMock())
    monkeypatch.setattr(edu, "get_user", AsyncMock(return_value={"study_diplome": "Brevet", "energy": 100, "stress": 0}))
    monkeypatch.setattr(edu, "update_field", AsyncMock())
    monkeypatch.setattr(edu, "increment_field", AsyncMock())
    monkeypatch.setattr(edu, "add_xp", AsyncMock())
    result = await edu.finalize_exam(UID)
    assert result["success"] is False
    history = await edu.exam_history(UID)
    assert len(history) == 1 and history[0]["score"] == 2 and history[0]["success"] is False


async def test_router_delegates(monkeypatch):
    monkeypatch.setattr(router.edu_service, "exam_history", AsyncMock(return_value=[{"diploma": "Bac"}]))
    assert await router.exam_history(uid=5) == {"history": [{"diploma": "Bac"}]}
    router.edu_service.exam_history.assert_awaited_once_with(5)


def test_history_route_registered():
    from webapp.server import app
    assert "/api/education/exam/history" in {r.path for r in app.routes}
