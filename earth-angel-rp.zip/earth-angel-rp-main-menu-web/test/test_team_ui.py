# test/test_team_ui.py — écrans de la hiérarchie et des chats d'équipe + relais des messages
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from types import SimpleNamespace

import pytest
import pytest_asyncio

import database
import migrations
import utils.team as team
import handlers.team as tui
import handlers.ordre as oui
from test.test_ordre_ui import Recorder
from test.test_team_politics import tdb, _faction, _company, EMP, EMP2, PDG, CIV, DGP   # noqa: F401  (fixture)


async def click(uid, data):
    q = Recorder(uid, data)
    upd = SimpleNamespace(callback_query=q, effective_user=q.from_user, effective_message=q.message)
    await tui.tm_callback(upd, SimpleNamespace(bot=SimpleNamespace(), user_data={}))
    return q


async def test_team_screens(tdb):
    await _faction(DGP, "mairie", 3, 40)
    await _faction(EMP, "mairie", 0, 7)
    q = await click(EMP, "tm:home")
    assert "tm:r:faction:0" in q.buttons and "tm:chat" in q.buttons and "tm:r:company:0" not in q.buttons
    q = await click(EMP, "tm:r:faction:0")
    assert "Hiérarchie" in q.text and "activité" not in q.text            # employé : pas d'activité
    assert str(DGP) in q.text and "@" in q.text                           # ID + pseudo visibles
    q = await click(DGP, "tm:r:faction:0")
    assert "activité" in q.text                                           # direction : activité visible
    q = await click(CIV, "tm:home")
    assert "aucune faction" in q.text
    q = await click(EMP, "tm:chat")
    assert "tm:in:f:mairie" in q.buttons and "tm:in:g" in q.buttons
    q = await click(EMP, "tm:in:g")
    assert "Tu es dans le chat" in q.text and "tm:out" in q.buttons
    q = await click(EMP, "tm:mute:g")
    assert "sourdine" in q.text
    q = await click(EMP, "tm:out")
    assert await team.get_channel(EMP) is None
    q = await click(EMP, "tm:in:c:99")                                    # pas d'accès
    assert "❌" in q.text


async def test_relay_delivers_with_name_and_post(tdb):
    await _faction(DGP, "mairie", 3)
    await _faction(EMP, "mairie", 0)
    await team.enter(EMP, "f:mairie")
    delivered, acks = [], []

    async def send_message(to, text, **k):
        delivered.append((to, text))

    async def reply_text(text, **k):
        acks.append(text)

    ctx = SimpleNamespace(bot=SimpleNamespace(send_message=send_message), user_data={})
    upd = SimpleNamespace(effective_user=SimpleNamespace(id=EMP),
                          effective_message=SimpleNamespace(text="Bonjour à tous", reply_text=reply_text))
    try:
        await oui.relay_message_handler(upd, ctx)                          # le relais d'équipe passe par le même handler
        assert False, "doit stopper la propagation"
    except Exception as e:
        assert e.__class__.__name__ in ("ApplicationHandlerStop", "Stop")
    assert len(delivered) == 1 and delivered[0][0] == DGP
    import html
    text = html.unescape(delivered[0][1])                                 # le message est envoyé en HTML (échappé)
    assert "User704" in text and "Agent d'accueil" in text and "Bonjour à tous" in text
    assert acks and "1 membre" in acks[0]
    # un message hors chat n'est pas intercepté
    await team.leave(EMP)
    upd2 = SimpleNamespace(effective_user=SimpleNamespace(id=EMP),
                           effective_message=SimpleNamespace(text="coucou", reply_text=reply_text))
    await oui.relay_message_handler(upd2, ctx)
    assert len(delivered) == 1
