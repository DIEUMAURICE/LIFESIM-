"""test/test_companies_contracts.py — Contrats inter-entreprises (proposer, répondre, négocier).

Couvre `gameplay/companies.py` (service pur, réel via une base migrée — y compris la notification
et le journal, exactement comme le faisait `handlers/company_deals.py`) et
`webapp/routers/companies_router.py` (délégation au même service), comme
`handlers/company_deals.py` les appelle désormais. Les fusions ne sont pas couvertes ici :
elles restent uniquement sur le bot, non extraites dans cette reprise.
"""
import asyncio
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
import gameplay.companies as companies_service
from webapp.routers import companies_router
from webapp.server import app


@pytest_asyncio.fixture
async def persistent_companies_db(monkeypatch, tmp_path):
    """Base réelle (schéma + migrations) pour vérifier que proposer/répondre/négocier écrivent
    bien `contracts`, `companies.treasury`/`reputation` et `notifications`."""
    path = str(tmp_path / "companies-contracts-persistent.db")
    pool = database.SQLiteConnectionPool(path, size=3)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(database, "_db_global_lock", asyncio.Lock())
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    yield path
    await database._DB_POOL.close()


async def _seed_company(company_id: int, owner_id: int, *, treasury: int = 100_000,
                         reputation: int = 50, dissolved: int = 0) -> None:
    async with database.db_connection() as db:
        await db.execute(
            "INSERT INTO users (user_id, full_name, balance) VALUES (?,?,0) "
            "ON CONFLICT(user_id) DO NOTHING",
            (owner_id, f"Joueur {owner_id}"),
        )
        await db.execute(
            "INSERT INTO companies (company_id,name,owner_id,sector,treasury,reputation,level,dissolved,created_at) "
            "VALUES (?,?,?,?,?,?,1,?,?)",
            (company_id, f"Société {company_id}", owner_id, "Tech", treasury, reputation, dissolved, database.now()),
        )
        await db.commit()


async def _treasury(company_id: int) -> int:
    async with database.db_connection() as db:
        async with db.execute("SELECT treasury FROM companies WHERE company_id=?", (company_id,)) as cur:
            return (await cur.fetchone())[0]


async def _reputation(company_id: int) -> int:
    async with database.db_connection() as db:
        async with db.execute("SELECT reputation FROM companies WHERE company_id=?", (company_id,)) as cur:
            return (await cur.fetchone())[0]


async def _notifications_for(user_id: int) -> list[str]:
    async with database.db_connection() as db:
        async with db.execute("SELECT message FROM notifications WHERE user_id=?", (user_id,)) as cur:
            return [r[0] for r in await cur.fetchall()]


# ─────────────────────────── gameplay/companies.py — propose_contract ───────────────────────────


@pytest.mark.asyncio
async def test_propose_contract_inserts_pending_row_and_notifies_target_owner(persistent_companies_db):
    await _seed_company(10, owner_id=1)
    await _seed_company(20, owner_id=2)

    result = await companies_service.propose_contract(10, "Société 10", 20, 5_000, 7, "service")

    assert result["ok"] is True
    assert result["target_owner_id"] == 2
    async with database.db_connection() as db:
        async with db.execute("SELECT status, amount, duration FROM contracts WHERE contract_id=?", (result["contract_id"],)) as cur:
            row = await cur.fetchone()
    assert row == ("pending", 5_000, 7)
    notes = await _notifications_for(2)
    assert any("Société 10" in n for n in notes)


@pytest.mark.asyncio
async def test_propose_contract_refuses_a_second_pending_contract(persistent_companies_db):
    await _seed_company(10, owner_id=1)
    await _seed_company(20, owner_id=2)
    await companies_service.propose_contract(10, "Société 10", 20, 5_000, 7, "service")

    result = await companies_service.propose_contract(10, "Société 10", 20, 1_000, 3, "licence")

    assert result == {"ok": False, "reason": "already_pending"}


@pytest.mark.asyncio
async def test_propose_contract_refuses_a_dissolved_target(persistent_companies_db):
    await _seed_company(10, owner_id=1)
    await _seed_company(20, owner_id=2, dissolved=1)
    result = await companies_service.propose_contract(10, "Société 10", 20, 5_000, 7, "service")
    assert result == {"ok": False, "reason": "target_dissolved"}


@pytest.mark.asyncio
async def test_propose_contract_rejects_invalid_args(persistent_companies_db):
    assert await companies_service.propose_contract(10, "X", 20, 0, 7, "service") == {"ok": False, "reason": "invalid_args"}
    assert await companies_service.propose_contract(10, "X", 20, 5_000, 0, "service") == {"ok": False, "reason": "invalid_args"}
    assert await companies_service.propose_contract(10, "X", 20, 5_000, 7, "bogus") == {"ok": False, "reason": "invalid_args"}
    assert await companies_service.propose_contract(10, "X", 10, 5_000, 7, "service") == {"ok": False, "reason": "same_company"}


# ─────────────────────────── gameplay/companies.py — respond_contract ───────────────────────────


@pytest.mark.asyncio
async def test_respond_contract_accept_transfers_money_and_applies_reputation_bonus(persistent_companies_db):
    await _seed_company(10, owner_id=1, treasury=100_000, reputation=50)
    await _seed_company(20, owner_id=2, treasury=0, reputation=50)
    proposed = await companies_service.propose_contract(10, "Société 10", 20, 5_000, 7, "service")

    result = await companies_service.respond_contract(2, proposed["contract_id"], True)

    assert result["ok"] is True
    assert result["accepted"] is True
    assert result["bonus_reputation"] == 3
    assert await _treasury(10) == 95_000
    assert await _treasury(20) == 5_000
    assert await _reputation(10) == 53
    assert await _reputation(20) == 53
    notes = await _notifications_for(1)
    assert any("accepté" in n for n in notes)


@pytest.mark.asyncio
async def test_respond_contract_refuse_notifies_the_proposing_owner_not_the_company_id(persistent_companies_db):
    """Corrige un bug de l'implémentation d'origine : la notification de refus visait
    `contract["from_company"]` (un company_id) au lieu de l'owner_id du PDG émetteur."""
    await _seed_company(10, owner_id=1)
    await _seed_company(20, owner_id=2)
    proposed = await companies_service.propose_contract(10, "Société 10", 20, 5_000, 7, "service")

    result = await companies_service.respond_contract(2, proposed["contract_id"], False)

    assert result == {"ok": True, "accepted": False, "from_company": 10, "target_name": "Société 20"}
    notes_owner = await _notifications_for(1)  # owner_id du PDG émetteur, pas company_id=10
    assert any("refusé" in n for n in notes_owner)
    notes_wrong = await _notifications_for(10)  # l'ancien bug aurait écrit ici
    assert notes_wrong == []


@pytest.mark.asyncio
async def test_respond_contract_refuses_a_non_target_owner(persistent_companies_db):
    await _seed_company(10, owner_id=1)
    await _seed_company(20, owner_id=2)
    proposed = await companies_service.propose_contract(10, "Société 10", 20, 5_000, 7, "service")
    result = await companies_service.respond_contract(999, proposed["contract_id"], True)
    assert result == {"ok": False, "reason": "not_target_owner"}


@pytest.mark.asyncio
async def test_respond_contract_cancels_on_insufficient_treasury_without_crediting_anything(persistent_companies_db):
    await _seed_company(10, owner_id=1, treasury=100)
    await _seed_company(20, owner_id=2, treasury=0)
    proposed = await companies_service.propose_contract(10, "Société 10", 20, 5_000, 7, "service")

    result = await companies_service.respond_contract(2, proposed["contract_id"], True)

    assert result == {"ok": False, "reason": "insufficient_treasury"}
    assert await _treasury(10) == 100
    assert await _treasury(20) == 0
    async with database.db_connection() as db:
        async with db.execute("SELECT status FROM contracts WHERE contract_id=?", (proposed["contract_id"],)) as cur:
            assert (await cur.fetchone())[0] == "cancelled"


@pytest.mark.asyncio
async def test_respond_contract_not_found_for_an_already_treated_contract(persistent_companies_db):
    await _seed_company(10, owner_id=1)
    await _seed_company(20, owner_id=2)
    proposed = await companies_service.propose_contract(10, "Société 10", 20, 5_000, 7, "service")
    await companies_service.respond_contract(2, proposed["contract_id"], False)

    result = await companies_service.respond_contract(2, proposed["contract_id"], True)
    assert result == {"ok": False, "reason": "not_found"}


# ─────────────────────────── gameplay/companies.py — negotiate_contract ───────────────────────────


@pytest.mark.asyncio
async def test_negotiate_contract_updates_terms_and_notifies_proposing_owner(persistent_companies_db):
    await _seed_company(10, owner_id=1)
    await _seed_company(20, owner_id=2)
    proposed = await companies_service.propose_contract(10, "Société 10", 20, 5_000, 7, "service")

    result = await companies_service.negotiate_contract(2, proposed["contract_id"], 3_000, 10)

    assert result["ok"] is True
    async with database.db_connection() as db:
        async with db.execute(
            "SELECT amount, duration, status FROM contracts WHERE contract_id=?", (proposed["contract_id"],)
        ) as cur:
            row = await cur.fetchone()
    assert row == (3_000, 10, "negotiating")
    notes = await _notifications_for(1)
    assert any("Négociation" in n for n in notes)


@pytest.mark.asyncio
async def test_negotiate_contract_refuses_a_non_target_owner(persistent_companies_db):
    await _seed_company(10, owner_id=1)
    await _seed_company(20, owner_id=2)
    proposed = await companies_service.propose_contract(10, "Société 10", 20, 5_000, 7, "service")
    result = await companies_service.negotiate_contract(999, proposed["contract_id"], 1, 1)
    assert result == {"ok": False, "reason": "not_target_owner"}


@pytest.mark.asyncio
async def test_negotiate_contract_rejects_invalid_args(persistent_companies_db):
    assert await companies_service.negotiate_contract(2, 1, 0, 5) == {"ok": False, "reason": "invalid_args"}
    assert await companies_service.negotiate_contract(2, 1, 5, 0) == {"ok": False, "reason": "invalid_args"}


# ─────────────────────────── webapp/routers/companies_router.py ───────────────────────────


@pytest.mark.asyncio
async def test_contracts_route_lists_for_own_company(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company", AsyncMock(return_value={"company_id": 10}),
    )
    listing = AsyncMock(return_value=[{"contract_id": 1}])
    monkeypatch.setattr(companies_router.companies_service, "list_contracts", listing)

    result = await companies_router.contracts(user_id=1)

    assert result == {"contracts": [{"contract_id": 1}]}
    listing.assert_awaited_once_with(10)


@pytest.mark.asyncio
async def test_propose_contract_route_refuses_a_non_owner(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 1, "name": "Acme"}),
    )
    propose = AsyncMock()
    monkeypatch.setattr(companies_router.companies_service, "propose_contract", propose)

    with pytest.raises(HTTPException) as exc:
        await companies_router.propose_contract(
            companies_router.ProposeContractIn(target_company_id=20, amount=1, duration=1, contract_type="service"),
            user_id=9,
        )
    assert exc.value.status_code == 403
    propose.assert_not_awaited()


@pytest.mark.asyncio
async def test_propose_contract_route_delegates_for_the_owner(monkeypatch):
    monkeypatch.setattr(
        companies_router.database, "get_user_company",
        AsyncMock(return_value={"company_id": 10, "owner_id": 1, "name": "Acme"}),
    )
    propose = AsyncMock(return_value={"ok": True, "contract_id": 5, "target_name": "Beta", "target_owner_id": 2})
    monkeypatch.setattr(companies_router.companies_service, "propose_contract", propose)

    result = await companies_router.propose_contract(
        companies_router.ProposeContractIn(target_company_id=20, amount=5_000, duration=7, contract_type="service"),
        user_id=1,
    )

    assert result["contract_id"] == 5
    propose.assert_awaited_once_with(10, "Acme", 20, 5_000, 7, "service")


@pytest.mark.asyncio
async def test_respond_contract_route_raises_422_with_reason_detail(monkeypatch):
    monkeypatch.setattr(
        companies_router.companies_service, "respond_contract",
        AsyncMock(return_value={"ok": False, "reason": "insufficient_treasury"}),
    )
    with pytest.raises(HTTPException) as exc:
        await companies_router.respond_contract(
            companies_router.ContractDecisionIn(contract_id=1, accept=True), user_id=2,
        )
    assert exc.value.status_code == 422
    assert "trésorerie" in exc.value.detail


@pytest.mark.asyncio
async def test_negotiate_contract_route_raises_403_for_wrong_owner(monkeypatch):
    monkeypatch.setattr(
        companies_router.companies_service, "negotiate_contract",
        AsyncMock(return_value={"ok": False, "reason": "not_target_owner"}),
    )
    with pytest.raises(HTTPException) as exc:
        await companies_router.negotiate_contract(
            companies_router.NegotiateContractIn(contract_id=1, amount=10, duration=5), user_id=9,
        )
    assert exc.value.status_code == 403


def test_companies_contracts_routes_are_registered_on_the_shared_api():
    paths = {route.path for route in app.routes}
    assert "/api/companies/contracts" in paths
    assert "/api/companies/contracts/propose" in paths
    assert "/api/companies/contracts/respond" in paths
    assert "/api/companies/contracts/negotiate" in paths
