import os
os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
import gameplay.garden as garden_service
from database import db_connection, now
from webapp.routers import garden_router

PLAYER, BOT_PLAYER = 7301, 7302


@pytest_asyncio.fixture
async def garden_db(monkeypatch, tmp_path):
    path = str(tmp_path / "garden-parity.db")
    pool = database.SQLiteConnectionPool(path, size=8)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    for uid in (PLAYER, BOT_PLAYER):
        await database.get_user(uid, f"gardener{uid}", f"Gardener {uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 1_000_000)
        await database.update_field(uid, "karma", 0)
    async def allow_free(_uid):
        return None
    monkeypatch.setattr(garden_router, "_free", allow_free)
    from handlers import garden as garden_handler
    monkeypatch.setattr(garden_handler, "get_season_multiplier", AsyncMock(return_value=1.0))
    monkeypatch.setattr(garden_service, "add_coins", AsyncMock())
    monkeypatch.setattr(garden_service, "add_xp", AsyncMock())
    monkeypatch.setattr(garden_service, "increment_field", AsyncMock())
    monkeypatch.setattr(garden_handler, "_grant_recolte", AsyncMock())
    import handlers.missions as missions_handler
    monkeypatch.setattr(missions_handler, "update_mission_progress", AsyncMock())
    yield
    await pool.close()


async def _plant(uid, plant_type, water_count=0, ready=True):
    planted = now() - 1_000_000 if ready else now()
    async with db_connection() as db:
        cur = await db.execute(
            "INSERT INTO garden(user_id,plant_type,planted_at,watered_at,water_count,ready) VALUES (?,?,?,0,?,0)",
            (uid, plant_type, planted, water_count),
        )
        await db.commit()
        return int(cur.lastrowid)


async def test_bot_and_api_batch_harvest_share_value_xp_and_inventory_grants(garden_db, monkeypatch):
    await _plant(PLAYER, "Blé")
    await _plant(PLAYER, "Rose", water_count=2)
    result = await garden_router.harvest_all(PLAYER)
    assert result["total"] == 1_200
    assert result["xp"] == 100
    assert len(result["harvested"]) == 2

    await _plant(BOT_PLAYER, "Blé")
    await _plant(BOT_PLAYER, "Rose", water_count=2)
    import handlers.garden as garden_handler
    monkeypatch.setattr(garden_handler.random, "random", lambda: 1.0)
    reply_text = AsyncMock()
    update = SimpleNamespace(effective_user=SimpleNamespace(id=BOT_PLAYER), message=SimpleNamespace(reply_text=reply_text))
    handler = garden_handler.cmd_recolter
    while hasattr(handler, "__wrapped__"):
        handler = handler.__wrapped__
    await handler(update, SimpleNamespace(args=[]))
    reply_text.assert_awaited_once()
    assert "1.2K €A" in reply_text.await_args.args[0]
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM garden WHERE user_id IN (?,?)", (PLAYER, BOT_PLAYER)) as cur:
            assert (await cur.fetchone())[0] == 0


async def test_batch_harvest_rejects_when_nothing_is_ready(garden_db):
    await _plant(PLAYER, "Blé", ready=False)
    with pytest.raises(HTTPException) as error:
        await garden_router.harvest_all(PLAYER)
    assert error.value.status_code == 409
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM garden WHERE user_id=?", (PLAYER,)) as cur:
            assert (await cur.fetchone())[0] == 1


async def test_batch_harvest_confiscates_illegal_plant_and_applies_shared_jail(garden_db, monkeypatch):
    await _plant(PLAYER, "Blé")
    await _plant(PLAYER, "Cannabis")
    monkeypatch.setattr(garden_service.random, "random", lambda: 0.0)
    result = await garden_router.harvest_all(PLAYER)
    assert result["total"] == 300
    assert result["arrested"] == ["Cannabis"]
    assert result["jail_seconds"] == 7200
    assert (await database.get_user(PLAYER))["prison_until"] >= now()
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM garden WHERE user_id=?", (PLAYER,)) as cur:
            assert (await cur.fetchone())[0] == 0


async def test_garden_maintenance_notifies_once_and_preserves_live_plots(garden_db):
    await _plant(PLAYER, "Blé")
    await _plant(PLAYER, "Rose")
    await _plant(BOT_PLAYER, "Blé", ready=False)
    from handlers.garden import process_garden_maintenance

    assert await process_garden_maintenance() == 2
    async with db_connection() as db:
        async with db.execute("SELECT message FROM notifications WHERE user_id=?", (PLAYER,)) as cur:
            notifications = await cur.fetchall()
        async with db.execute("SELECT COUNT(*) FROM garden WHERE user_id=?", (BOT_PLAYER,)) as cur:
            living_plots = (await cur.fetchone())[0]
    assert len(notifications) == 1
    assert "2 plante(s) morte(s)" in notifications[0][0]
    assert living_plots == 1
    assert await process_garden_maintenance() == 0
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM notifications WHERE user_id=?", (PLAYER,)) as cur:
            assert (await cur.fetchone())[0] == 1
