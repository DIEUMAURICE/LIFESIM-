import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

import asyncio
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
from database import db_connection, now
from gameplay.social_comments import CommentError, create_comment, list_comments
from gameplay.social_collabs import SocialCollabError, collaborations_for_user, create_request, respond_to_request
from webapp.routers import reseau_router
from webapp.routers.reseau_router import (
    CollabCreateIn,
    CollabRespondIn,
    CommentIn,
    collab_create,
    collab_respond,
    comments_create,
    comments_read,
)

AUTHOR, PLAYER, OTHER, WEB_PLAYER = 5101, 5102, 5103, -5104


@pytest_asyncio.fixture
async def social_db(monkeypatch, tmp_path):
    path = str(tmp_path / "social-comments-collabs.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    for uid in (AUTHOR, PLAYER, OTHER, WEB_PLAYER):
        await database.get_user(uid, f"player{abs(uid)}", f"Player {uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 250_000)
    monkeypatch.setattr(reseau_router, "_writing_gate", AsyncMock())
    yield
    await database._DB_POOL.close()


async def _post(author_id=AUTHOR):
    async with db_connection() as db:
        cur = await db.execute(
            "INSERT INTO rp_posts(author_id,platform,text,created_at,likes,comments,deleted) VALUES (?,?,?,?,0,0,0)",
            (author_id, "Instagram", "Publication de test", int(__import__("time").time())),
        )
        await db.commit()
        return int(cur.lastrowid)


async def test_comments_api_and_service_share_limit_counter_and_truncation(social_db, monkeypatch):
    post_id = await _post()
    notify = AsyncMock()
    monkeypatch.setattr("gameplay.social_comments.notify", notify)

    first = await comments_create(post_id, CommentIn(text="x" * 250), PLAYER)
    assert len(first["text"]) == 200
    assert first["comments"] == 1
    second = await create_comment(PLAYER, post_id, "Deuxième commentaire")
    third = await comments_create(post_id, CommentIn(text="Troisième commentaire"), PLAYER)
    assert second["comments"] == 2 and third["comments"] == 3
    with pytest.raises(HTTPException) as error:
        await comments_create(post_id, CommentIn(text="Quatrième commentaire"), PLAYER)
    assert error.value.status_code == 409

    data = await comments_read(post_id, AUTHOR)
    assert data["post"]["comments"] == 3
    assert len(data["comments"]) == 3
    assert data["comments"][0]["text"] == "x" * 200
    assert notify.await_count == 3


async def test_comment_own_post_does_not_notify_and_deleted_post_is_hidden(social_db, monkeypatch):
    notify = AsyncMock()
    monkeypatch.setattr("gameplay.social_comments.notify", notify)
    post_id = await _post(AUTHOR)
    await create_comment(AUTHOR, post_id, "Mon propre commentaire")
    notify.assert_not_awaited()
    async with db_connection() as db:
        await db.execute("UPDATE rp_posts SET deleted=1 WHERE id=?", (post_id,))
        await db.commit()
    with pytest.raises(CommentError, match="Publication introuvable"):
        await list_comments(post_id)
    with pytest.raises(HTTPException) as error:
        await comments_create(post_id, CommentIn(text="Trop tard"), PLAYER)
    assert error.value.status_code == 404


async def test_comment_response_counter_is_global_across_authors(social_db, monkeypatch):
    post_id = await _post()
    monkeypatch.setattr("gameplay.social_comments.notify", AsyncMock())
    first = await create_comment(PLAYER, post_id, "Premier joueur")
    second = await comments_create(post_id, CommentIn(text="Autre joueur"), OTHER)
    assert first["comments"] == 1
    assert second["comments"] == 2
    assert (await list_comments(post_id))["post"]["comments"] == 2


async def test_comment_quota_is_atomic_under_concurrent_requests(social_db, monkeypatch):
    post_id = await _post()
    monkeypatch.setattr("gameplay.social_comments.notify", AsyncMock())
    results = await asyncio.gather(
        *(create_comment(PLAYER, post_id, f"Commentaire {i}") for i in range(8)),
        return_exceptions=True,
    )
    assert sum(not isinstance(result, Exception) for result in results) == 3
    assert sum(isinstance(result, CommentError) for result in results) == 5
    async with db_connection() as db:
        async with db.execute("SELECT comments FROM rp_posts WHERE id=?", (post_id,)) as cur:
            assert (await cur.fetchone())[0] == 3


async def test_collaboration_refusal_is_free_and_web_player_can_receive_request(social_db):
    request = await create_request(PLAYER, WEB_PLAYER, "giveaway")
    assert request["duration_h"] == 24
    assert (await database.get_user(PLAYER))["balance"] == 250_000
    state = await collaborations_for_user(WEB_PLAYER)
    assert state["incoming"][0]["request_id"] == request["request_id"]
    assert state["incoming"][0]["other_id"] == PLAYER

    with pytest.raises(SocialCollabError, match="ne t’est pas destinée"):
        await respond_to_request(request["request_id"], OTHER, "accept")
    result = await respond_to_request(request["request_id"], WEB_PLAYER, "refuse")
    assert result["status"] == "refused"
    assert result["cost_paid"] == 0
    assert (await database.get_user(PLAYER))["balance"] == 250_000
    assert (await database.get_user(PLAYER))["social_followers"] == 0


async def test_collaboration_api_acceptance_charges_proposer_and_rewards_both(social_db):
    created = await collab_create(CollabCreateIn(target=str(WEB_PLAYER), collab_type="cross"), PLAYER)
    assert created["status"] == "pending"
    assert created["cost"] == 50_000
    accepted = await collab_respond(
        CollabRespondIn(request_id=created["request_id"], action="accept"), WEB_PLAYER,
    )
    assert accepted["status"] == "accepted"
    assert accepted["cost_paid"] == 50_000
    assert accepted["followers_earned"] == 100
    assert (await database.get_user(PLAYER))["balance"] == 200_000
    assert (await database.get_user(PLAYER))["social_followers"] == 100
    assert (await database.get_user(WEB_PLAYER))["social_followers"] == 100
    assert (await collaborations_for_user(PLAYER))["active"][0]["other_id"] == WEB_PLAYER


async def test_collaboration_busy_funds_and_duplicate_decision_guards(social_db):
    await database.update_field(PLAYER, "balance", 49_999)
    with pytest.raises(SocialCollabError, match="Solde insuffisant"):
        await create_request(PLAYER, OTHER, "live")
    await database.update_field(PLAYER, "balance", 250_000)
    created = await create_request(PLAYER, OTHER, "live")
    await respond_to_request(created["request_id"], OTHER, "accept")
    with pytest.raises(SocialCollabError, match="collaboration active"):
        await create_request(PLAYER, WEB_PLAYER, "cross")
    with pytest.raises(SocialCollabError, match="déjà traitée"):
        await respond_to_request(created["request_id"], OTHER, "accept")


async def test_pending_collaboration_rechecks_proposer_funds_at_acceptance(social_db):
    created = await create_request(PLAYER, WEB_PLAYER, "live")
    await database.update_field(PLAYER, "balance", 49_999)

    with pytest.raises(SocialCollabError) as error:
        await respond_to_request(created["request_id"], WEB_PLAYER, "accept")

    assert error.value.code == "insufficient_funds"
    assert (await database.get_user(PLAYER))["balance"] == 49_999
    assert (await database.get_user(PLAYER))["social_followers"] == 0
    async with db_connection() as db:
        async with db.execute("SELECT status FROM social_collab_requests WHERE request_id=?", (created["request_id"],)) as cur:
            assert (await cur.fetchone())[0] == "pending"
        async with db.execute("SELECT COUNT(*) FROM social_active_collabs") as cur:
            assert (await cur.fetchone())[0] == 0


async def test_pending_collaboration_rechecks_participant_availability(social_db):
    stale_request = await create_request(PLAYER, WEB_PLAYER, "giveaway")
    competing = await create_request(OTHER, WEB_PLAYER, "cross")
    await respond_to_request(competing["request_id"], WEB_PLAYER, "accept")
    balance_before = (await database.get_user(PLAYER))["balance"]

    with pytest.raises(SocialCollabError) as error:
        await respond_to_request(stale_request["request_id"], WEB_PLAYER, "accept")

    assert error.value.code == "target_busy"
    assert (await database.get_user(PLAYER))["balance"] == balance_before
    assert (await database.get_user(PLAYER))["social_followers"] == 0
    async with db_connection() as db:
        async with db.execute("SELECT status FROM social_collab_requests WHERE request_id=?", (stale_request["request_id"],)) as cur:
            assert (await cur.fetchone())[0] == "pending"
        async with db.execute("SELECT COUNT(*) FROM social_active_collabs") as cur:
            assert (await cur.fetchone())[0] == 1
