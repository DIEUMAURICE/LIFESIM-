"""test/test_companies_hiring.py — Équipe, recrutement, salaires, licenciement (service + routeur)."""
import asyncio
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
import gameplay.hiring as hiring
from webapp.routers import companies_router
from webapp.server import app

OWNER, EMP, MGR, NEW, OTHER_OWNER = 1, 2, 3, 4, 5


@pytest_asyncio.fixture
async def hdb(monkeypatch, tmp_path):
    path = str(tmp_path / "hiring.db")
    pool = database.SQLiteConnectionPool(path, size=3)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(database, "_db_global_lock", asyncio.Lock())
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    async with database.db_connection() as db:
        for uid in (OWNER, EMP, MGR, NEW, OTHER_OWNER):
            await db.execute("INSERT INTO users (user_id, full_name, balance) VALUES (?,?,0)", (uid, f"J{uid}"))
        for cid, name, owner in ((10, "Acme", OWNER), (20, "Beta", OTHER_OWNER)):
            await db.execute(
                "INSERT INTO companies (company_id,name,owner_id,sector,treasury,reputation,level,dissolved,created_at) "
                "VALUES (?,?,?,'Tech',10000,50,1,0,?)", (cid, name, owner, database.now()))
        members = ((OWNER, 10, "PDG", 0, None), (EMP, 10, "Employé", 100, None),
                   (MGR, 10, "Employé", 100, "manager"), (OTHER_OWNER, 20, "PDG", 0, None))
        for uid, cid, poste, salary, role in members:
            await db.execute(
                "INSERT INTO company_members (user_id,company_id,poste,salary,base_salary,activity_score,joined_at) "
                "VALUES (?,?,?,0,?,0,?)", (uid, cid, poste, salary, database.now()))
            if role:
                await db.execute("UPDATE company_members SET role=? WHERE user_id=?", (role, uid))
        await db.commit()
    monkeypatch.setattr(database, "add_notification", AsyncMock())
    yield
    await database._DB_POOL.close()


async def _one(sql, *params):
    async with database.db_connection() as db:
        async with db.execute(sql, params) as cur:
            return await cur.fetchone()


@pytest.mark.asyncio
async def test_apply_then_accept_hires_at_the_given_salary(hdb):
    assert (await hiring.apply(NEW, 10, 500))["ok"]
    assert (await hiring.apply(NEW, 10, 500))["reason"] == "already_pending"
    app_id = (await hiring.pending_applications(10))[0]["app_id"]
    result = await hiring.accept_application(OWNER, app_id, 800)
    assert result["ok"]
    row = await _one("SELECT company_id, poste, base_salary FROM company_members WHERE user_id=?", NEW)
    assert tuple(row) == (10, "Employé", 800)
    assert (await _one("SELECT status FROM company_applications WHERE app_id=?", app_id))[0] == "accepted"
    assert (await hiring.apply(NEW, 20))["reason"] == "already_employed"


@pytest.mark.asyncio
async def test_accept_refuses_a_candidate_already_employed_elsewhere(hdb):
    await hiring.apply(NEW, 10, 100)
    app_id = (await hiring.pending_applications(10))[0]["app_id"]
    async with database.db_connection() as db:
        await db.execute("INSERT INTO company_members (user_id,company_id,poste,base_salary,joined_at) VALUES (?,20,'Employé',50,?)",
                         (NEW, database.now()))
        await db.commit()
    assert (await hiring.accept_application(OWNER, app_id, 100))["reason"] == "already_employed"
    assert (await _one("SELECT company_id FROM company_members WHERE user_id=?", NEW))[0] == 20
    assert (await _one("SELECT status FROM company_applications WHERE app_id=?", app_id))[0] == "pending"


@pytest.mark.asyncio
async def test_only_managers_handle_applications(hdb):
    await hiring.apply(NEW, 10, 100)
    app_id = (await hiring.pending_applications(10))[0]["app_id"]
    assert (await hiring.accept_application(EMP, app_id, 100))["reason"] == "not_manager"
    assert (await hiring.accept_application(OWNER, app_id, -1))["reason"] == "invalid_salary"
    assert (await hiring.refuse_application(MGR, app_id))["ok"]          # un gérant peut refuser
    assert (await hiring.refuse_application(OWNER, 999))["reason"] == "unknown_application"


@pytest.mark.asyncio
async def test_counter_offer_then_candidate_accepts(hdb):
    await hiring.apply(NEW, 10, 100)
    app_id = (await hiring.pending_applications(10))[0]["app_id"]
    assert (await hiring.counter_offer(OWNER, app_id, 300))["ok"]
    assert (await hiring.respond_offer(EMP, "J2", app_id, True))["reason"] == "no_offer"    # pas son offre
    result = await hiring.respond_offer(NEW, "J4", app_id, True)
    assert result["ok"] and result["salary"] == 300
    assert (await _one("SELECT base_salary FROM company_members WHERE user_id=?", NEW))[0] == 300
    mine = await hiring.my_applications(NEW)
    assert mine == []


@pytest.mark.asyncio
async def test_candidate_can_refuse_the_offer(hdb):
    await hiring.apply(NEW, 10, 100)
    app_id = (await hiring.pending_applications(10))[0]["app_id"]
    await hiring.counter_offer(OWNER, app_id, 300)
    assert (await hiring.respond_offer(NEW, "J4", app_id, False))["accepted"] is False
    assert await _one("SELECT 1 FROM company_members WHERE user_id=?", NEW) is None
    assert (await _one("SELECT status FROM company_applications WHERE app_id=?", app_id))[0] == "refused"


@pytest.mark.asyncio
async def test_resign_removes_membership_and_shares_but_not_for_the_owner(hdb):
    async with database.db_connection() as db:
        await db.execute("INSERT INTO company_shares (user_id,company_id,shares) VALUES (?,10,5)", (EMP,))
        await db.commit()
    assert (await hiring.resign(OWNER, "J1"))["reason"] == "is_owner"
    assert (await hiring.resign(NEW, "J4"))["reason"] == "no_company"
    assert (await hiring.resign(EMP, "J2"))["ok"]
    assert await _one("SELECT 1 FROM company_members WHERE user_id=?", EMP) is None
    assert await _one("SELECT 1 FROM company_shares WHERE user_id=?", EMP) is None


@pytest.mark.asyncio
async def test_set_pay_updates_salary_and_poste_only_for_members(hdb):
    assert (await hiring.set_pay(OWNER, EMP, 250, "Chef"))["poste"] == "Chef"
    assert tuple(await _one("SELECT poste, base_salary FROM company_members WHERE user_id=?", EMP)) == ("Chef", 250)
    assert (await hiring.set_pay(OWNER, EMP, 400))["ok"]
    assert tuple(await _one("SELECT poste, base_salary FROM company_members WHERE user_id=?", EMP)) == ("Chef", 400)
    assert (await hiring.set_pay(OWNER, NEW, 100))["reason"] == "target_not_member"
    assert (await hiring.set_pay(MGR, EMP, 100))["reason"] == "not_owner"
    assert (await hiring.set_pay(OWNER, EMP, -5))["reason"] == "invalid_salary"


@pytest.mark.asyncio
async def test_fire_pays_severance_from_treasury_in_one_transaction(hdb):
    result = await hiring.fire(OWNER, EMP)
    assert result == {"ok": True, "target_name": "J2", "severance": 200, "severance_paid": True}
    assert await _one("SELECT 1 FROM company_members WHERE user_id=?", EMP) is None
    assert (await _one("SELECT treasury FROM companies WHERE company_id=10"))[0] == 9800
    assert (await _one("SELECT balance FROM users WHERE user_id=?", EMP))[0] == 200


@pytest.mark.asyncio
async def test_fire_without_enough_treasury_pays_nothing(hdb):
    async with database.db_connection() as db:
        await db.execute("UPDATE companies SET treasury=50 WHERE company_id=10")
        await db.commit()
    result = await hiring.fire(OWNER, EMP)
    assert result["ok"] and result["severance_paid"] is False
    assert (await _one("SELECT treasury FROM companies WHERE company_id=10"))[0] == 50
    assert (await _one("SELECT balance FROM users WHERE user_id=?", EMP))[0] == 0


@pytest.mark.asyncio
async def test_fire_permission_rules(hdb):
    assert (await hiring.fire(EMP, MGR))["reason"] == "not_manager"
    assert (await hiring.fire(OWNER, OWNER))["reason"] == "self"
    assert (await hiring.fire(MGR, OWNER))["reason"] == "owner_only"      # un gérant ne touche ni créateur ni gérant
    assert (await hiring.fire(OWNER, NEW))["reason"] == "target_not_member"
    assert (await hiring.fire(MGR, EMP))["ok"]                              # un gérant peut licencier un employé


@pytest.mark.asyncio
async def test_team_lists_members_with_salaries(hdb):
    names = {m["full_name"]: m["base_salary"] for m in await hiring.team(10)}
    assert names == {"J1": 0, "J2": 100, "J3": 100}


@pytest.mark.asyncio
async def test_router_maps_reasons(monkeypatch):
    monkeypatch.setattr(companies_router.hiring_service, "fire", AsyncMock(return_value={"ok": False, "reason": "not_manager"}))
    with pytest.raises(HTTPException) as exc:
        await companies_router.fire(companies_router.FireIn(target_user_id=2), user_id=9)
    assert exc.value.status_code == 403
    monkeypatch.setattr(companies_router.hiring_service, "set_pay",
                        AsyncMock(return_value={"ok": False, "reason": "target_not_member"}))
    with pytest.raises(HTTPException) as exc:
        await companies_router.set_pay(companies_router.PayIn(target_user_id=2, salary=5), user_id=1)
    assert exc.value.status_code == 422
    monkeypatch.setattr(companies_router.database, "get_company_by_name", AsyncMock(return_value=None))
    with pytest.raises(HTTPException) as exc:
        await companies_router.apply_to_company(companies_router.ApplyIn(company_name="Nope"), user_id=1)
    assert exc.value.status_code == 404


@pytest.mark.asyncio
async def test_router_apply_and_respond_delegate(monkeypatch):
    monkeypatch.setattr(companies_router.database, "get_company_by_name", AsyncMock(return_value={"company_id": 10}))
    apply = AsyncMock(return_value={"ok": True, "company_name": "Acme", "desired_salary": 5})
    monkeypatch.setattr(companies_router.hiring_service, "apply", apply)
    await companies_router.apply_to_company(companies_router.ApplyIn(company_name="Acme", desired_salary=5), user_id=4)
    apply.assert_awaited_once_with(4, 10, 5)
    monkeypatch.setattr(companies_router.database, "get_user", AsyncMock(return_value={"full_name": "Nom"}))
    respond = AsyncMock(return_value={"ok": True, "accepted": True, "salary": 1, "company_id": 10})
    monkeypatch.setattr(companies_router.hiring_service, "respond_offer", respond)
    await companies_router.respond_offer(companies_router.OfferResponseIn(app_id=3, accept=True), user_id=4)
    respond.assert_awaited_once_with(4, "Nom", 3, True)


def test_hiring_routes_are_registered():
    paths = {r.path for r in app.routes}
    assert {"/api/companies/team", "/api/companies/applications", "/api/companies/apply",
            "/api/companies/applications/accept", "/api/companies/applications/negotiate",
            "/api/companies/applications/refuse", "/api/companies/offer/respond",
            "/api/companies/resign", "/api/companies/pay", "/api/companies/fire"} <= paths
