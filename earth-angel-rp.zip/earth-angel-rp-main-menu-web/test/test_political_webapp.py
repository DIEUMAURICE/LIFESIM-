from unittest.mock import AsyncMock

import pytest
from fastapi import HTTPException

from webapp.routers import political_router
from webapp.server import app


@pytest.mark.asyncio
async def test_political_status_projects_office_term_and_journal(monkeypatch):
    monkeypatch.setattr(
        political_router.politics_service, "office_info",
        AsyncMock(return_value={"label": "Président", "kind": "president", "position": "Président", "since": 1_000}),
    )
    monkeypatch.setattr(political_router.politics_service, "term_left", AsyncMock(return_value=86_400))
    monkeypatch.setattr(political_router.politics_service, "registered_count", AsyncMock(return_value=42))
    monkeypatch.setattr(
        political_router.politics_service, "recent_events",
        AsyncMock(return_value=[("election", "Maurice élu Président", 1_234)]),
    )

    status = await political_router.status(user_id=7)

    assert status["office"]["label"] == "Président"
    assert status["term_left_seconds"] == 86_400
    assert status["registered_players"] == 42
    assert status["journal"] == [{"type": "election", "description": "Maurice élu Président", "timestamp": 1_234}]


@pytest.mark.asyncio
async def test_political_status_skips_term_for_a_minister(monkeypatch):
    monkeypatch.setattr(
        political_router.politics_service, "office_info",
        AsyncMock(return_value={"label": "Ministre de Santé", "kind": "minister", "position": "Santé", "since": 500}),
    )
    term_left = AsyncMock(return_value=99_999)
    monkeypatch.setattr(political_router.politics_service, "term_left", term_left)
    monkeypatch.setattr(political_router.politics_service, "registered_count", AsyncMock(return_value=10))
    monkeypatch.setattr(political_router.politics_service, "recent_events", AsyncMock(return_value=[]))

    status = await political_router.status(user_id=8)

    assert status["term_left_seconds"] is None
    term_left.assert_not_awaited()


@pytest.mark.asyncio
async def test_political_status_reports_no_office_for_an_ordinary_player(monkeypatch):
    monkeypatch.setattr(political_router.politics_service, "office_info", AsyncMock(return_value=None))
    monkeypatch.setattr(political_router.politics_service, "registered_count", AsyncMock(return_value=10))
    monkeypatch.setattr(political_router.politics_service, "recent_events", AsyncMock(return_value=[]))

    status = await political_router.status(user_id=-77)

    assert status["office"] is None
    assert status["term_left_seconds"] is None


@pytest.mark.asyncio
async def test_political_motions_delegates_to_the_shared_service(monkeypatch):
    overview = AsyncMock(return_value=[{"motion_id": 1, "target": 9, "status": "pending"}])
    monkeypatch.setattr(political_router.politics_service, "motions_overview", overview)

    result = await political_router.motions(user_id=7)

    assert result == {"motions": [{"motion_id": 1, "target": 9, "status": "pending"}]}
    overview.assert_awaited_once_with()


@pytest.mark.asyncio
async def test_start_motion_uses_check_motion_before_creating_it(monkeypatch):
    check = AsyncMock(return_value=(True, "", {"label": "Président"}))
    create = AsyncMock(return_value=41)
    monkeypatch.setattr(political_router.politics_service, "check_motion", check)
    monkeypatch.setattr(political_router.politics_service, "create_motion", create)

    result = await political_router.start_motion(political_router.MotionTargetIn(target_id=9), user_id=7)

    assert result == {"started": True, "motion_id": 41}
    check.assert_awaited_once_with(7, 9)
    create.assert_awaited_once_with(7, 9)


@pytest.mark.asyncio
async def test_start_motion_raises_422_on_refusal_without_creating_anything(monkeypatch):
    check = AsyncMock(return_value=(False, "Une motion est déjà en cours contre ce joueur.", None))
    create = AsyncMock()
    monkeypatch.setattr(political_router.politics_service, "check_motion", check)
    monkeypatch.setattr(political_router.politics_service, "create_motion", create)

    with pytest.raises(HTTPException) as exc:
        await political_router.start_motion(political_router.MotionTargetIn(target_id=9), user_id=7)

    assert exc.value.status_code == 422
    assert exc.value.detail == "Une motion est déjà en cours contre ce joueur."
    create.assert_not_awaited()


@pytest.mark.asyncio
async def test_sign_motion_delegates_and_reports_refusal(monkeypatch):
    sign = AsyncMock(return_value=(True, "Signature enregistrée (3/5)."))
    monkeypatch.setattr(political_router.politics_service, "sign_motion", sign)

    result = await political_router.sign_motion(political_router.MotionTargetIn(target_id=9), user_id=12)

    assert result == {"signed": True, "message": "Signature enregistrée (3/5)."}
    sign.assert_awaited_once_with(12, 9)

    monkeypatch.setattr(political_router.politics_service, "sign_motion", AsyncMock(return_value=(False, "Tu as déjà signé cette motion.")))
    with pytest.raises(HTTPException) as exc:
        await political_router.sign_motion(political_router.MotionTargetIn(target_id=9), user_id=12)
    assert exc.value.status_code == 422


@pytest.mark.asyncio
async def test_vote_motion_delegates_with_optional_target(monkeypatch):
    vote = AsyncMock(return_value=(True, "Vote enregistré : pour."))
    monkeypatch.setattr(political_router.politics_service, "vote_motion", vote)

    result = await political_router.vote_motion(political_router.MotionVoteIn(choice="pour", target_id=9), user_id=12)

    assert result == {"voted": True, "message": "Vote enregistré : pour."}
    vote.assert_awaited_once_with(12, "pour", 9)


@pytest.mark.asyncio
async def test_vote_motion_raises_422_when_already_voted(monkeypatch):
    monkeypatch.setattr(political_router.politics_service, "vote_motion", AsyncMock(return_value=(False, "Tu as déjà voté.")))
    with pytest.raises(HTTPException) as exc:
        await political_router.vote_motion(political_router.MotionVoteIn(choice="contre", target_id=None), user_id=12)
    assert exc.value.status_code == 422
    assert exc.value.detail == "Tu as déjà voté."


def test_political_routes_are_registered_on_the_shared_api():
    paths = {route.path for route in app.routes}
    assert "/api/political/status" in paths
    assert "/api/political/motions" in paths
    assert "/api/political/motion" in paths
    assert "/api/political/motion/sign" in paths
    assert "/api/political/motion/vote" in paths
