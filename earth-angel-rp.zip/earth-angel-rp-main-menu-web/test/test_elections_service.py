# test/test_elections_service.py — Élections : service partagé bot/API + routes
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
import utils.roles as roles
from config import ELECTION_COST, ELECTION_KARMA_REQUIRED
from gameplay import elections as svc
from webapp.routers import political_router as router

N1, N1B, GL, P1, P2, P3, P4 = 801, 802, 803, 804, 805, 806, 807
ROLES = {N1: "ADMIN_N1", N1B: "ADMIN_N1", GL: "GAME_LEADER"}
RICH = ELECTION_COST["Président"] + 1_000


@pytest_asyncio.fixture
async def edb(monkeypatch, tmp_path):
    path = str(tmp_path / "elections.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()

    async def role_of(uid):
        return ROLES.get(uid, "PLAYER")

    monkeypatch.setattr(roles, "role_of", role_of)
    for uid in (N1, N1B, GL, P1, P2, P3, P4):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", RICH)
        await database.update_field(uid, "karma", ELECTION_KARMA_REQUIRED)
    yield


async def _one(sql, *params):
    async with database.db_connection() as db:
        async with db.execute(sql, params) as cur:
            return await cur.fetchone()


async def test_start_election_debits_and_creates_atomically(edb):
    result = await svc.start_election(N1, "Président", 2)
    assert result["ok"] and result["duration_hours"] == 2
    assert (await _one("SELECT balance FROM users WHERE user_id=?", N1))[0] == RICH - ELECTION_COST["Président"]
    election = await _one("SELECT status, ends_at-started_at FROM elections WHERE id=?", result["election_id"])
    assert tuple(election) == ("open", 7200)


async def test_start_election_refusals_do_not_charge(edb):
    await svc.start_election(N1, "Président")
    assert (await svc.start_election(N1B, "Président"))["reason"] == "already_open"
    assert (await svc.start_election(N1B, "Ministre de la Santé"))["reason"] in ("not_elected_post", "unknown_post")
    await database.update_field(P1, "balance", 10)
    assert (await svc.start_election(P1, "Président"))["reason"] in ("already_open", "insufficient_funds")
    assert (await _one("SELECT balance FROM users WHERE user_id=?", N1B))[0] == RICH
    assert (await _one("SELECT balance FROM users WHERE user_id=?", P1))[0] == 10


async def test_candidacy_needs_politician_karma_and_is_unique(edb):
    eid = (await svc.start_election(N1, "Président"))["election_id"]
    assert (await svc.register_candidate(P1, eid, "x"))["reason"] == "not_politician"
    assert (await svc.register_candidate(N1B, eid, "Mon programme"))["ok"]
    assert (await svc.register_candidate(N1B, eid))["reason"] == "already_candidate"
    await database.update_field(N1, "karma", 0)
    assert (await svc.register_candidate(N1, eid))["reason"] == "karma"
    assert (await svc.register_candidate(N1B, 999))["reason"] in ("no_election", "already_candidate")


async def test_vote_rules(edb):
    eid = (await svc.start_election(N1, "Président"))["election_id"]
    await svc.register_candidate(N1, eid)
    assert (await svc.cast_vote(GL, eid, N1))["reason"] == "not_player"
    assert (await svc.cast_vote(P1, eid, P2))["reason"] == "not_candidate"
    assert (await svc.cast_vote(P1, 999, N1))["reason"] == "no_election"
    assert (await svc.cast_vote(P1, eid, N1))["ok"]
    assert (await svc.cast_vote(P1, eid, N1))["reason"] == "already_voted"
    listing = await svc.list_open_elections()
    assert listing[0]["candidates"][0]["votes"] == 1
    assert (await svc.my_votes(P1)) == {eid: N1}


async def test_tally_elects_winner_and_is_idempotent(edb):
    eid = (await svc.start_election(N1, "Président"))["election_id"]
    for cand in (N1, N1B):
        await svc.register_candidate(cand, eid)
    for voter in (P1, P2, P3):
        await svc.cast_vote(voter, eid, N1)
    await svc.cast_vote(P4, eid, N1B)
    async with database.db_connection() as db:
        await db.execute("UPDATE elections SET ends_at=1 WHERE id=?", (eid,))
        await db.commit()
    out = await svc.tally_election(eid, "Président")
    assert out["outcome"] == "elected" and out["winner_id"] == N1 and out["votes"] == 3
    assert tuple(await _one("SELECT occupant_id FROM political_offices WHERE poste='Président'")) == (N1,)
    assert (await _one("SELECT status FROM elections WHERE id=?", eid))[0] == "closed"
    assert (await _one("SELECT political_post FROM users WHERE user_id=?", N1))[0] == "Président"
    assert (await svc.tally_election(eid, "Président"))["reason"] == "not_open"


async def test_tally_cancels_without_quorum(edb):
    eid = (await svc.start_election(N1, "Président"))["election_id"]
    await svc.register_candidate(N1, eid)
    await svc.cast_vote(P1, eid, N1)
    out = await svc.tally_election(eid, "Président")
    assert out["outcome"] == "cancelled" and "quorum" in out["reason"]
    assert (await _one("SELECT status FROM elections WHERE id=?", eid))[0] == "cancelled"
    assert await _one("SELECT 1 FROM political_offices") is None


def test_helpers():
    assert svc.resolve_poste("président") == "Président"
    assert svc.resolve_poste("nimporte") is None
    assert svc.clamp_duration("abc") == svc.ELECTION_DEFAULT_DURATION_HOURS
    assert svc.clamp_duration("3") == 3


async def test_router_maps_reasons_and_releases_cooldown(monkeypatch):
    monkeypatch.setattr(router, "is_politician", AsyncMock(return_value=True))
    monkeypatch.setattr(router, "free_problem", AsyncMock(return_value=None))
    monkeypatch.setattr(router, "cooldown_problem", AsyncMock(return_value=(None, True)))
    release = AsyncMock()
    monkeypatch.setattr(router, "release_cooldown", release)
    monkeypatch.setattr(router.elections_service, "start_election",
                        AsyncMock(return_value={"ok": False, "reason": "insufficient_funds"}))
    with pytest.raises(HTTPException) as exc:
        await router.start_election(router.ElectionStartIn(poste="Président"), user_id=1)
    assert exc.value.status_code == 422
    release.assert_awaited_once_with(1, "last_election")

    monkeypatch.setattr(router, "cooldown_problem", AsyncMock(return_value=("⏳ <b>Attends</b>", False)))
    with pytest.raises(HTTPException) as exc:
        await router.start_election(router.ElectionStartIn(poste="Président"), user_id=1)
    assert exc.value.status_code == 429 and "<" not in exc.value.detail

    monkeypatch.setattr(router, "is_politician", AsyncMock(return_value=False))
    with pytest.raises(HTTPException) as exc:
        await router.start_election(router.ElectionStartIn(poste="Président"), user_id=1)
    assert exc.value.status_code == 403


async def test_router_vote_and_candidate_delegate(monkeypatch):
    monkeypatch.setattr(router, "free_problem", AsyncMock(return_value=None))
    vote = AsyncMock(return_value={"ok": True, "poste": "Président"})
    monkeypatch.setattr(router.elections_service, "cast_vote", vote)
    assert (await router.vote(router.VoteIn(election_id=1, candidate_id=2), user_id=5))["ok"]
    vote.assert_awaited_once_with(5, 1, 2)
    monkeypatch.setattr(router.elections_service, "register_candidate",
                        AsyncMock(return_value={"ok": False, "reason": "not_politician"}))
    with pytest.raises(HTTPException) as exc:
        await router.candidate(router.CandidateIn(election_id=1), user_id=5)
    assert exc.value.status_code == 403


def test_election_routes_registered():
    from webapp.server import app
    paths = {r.path for r in app.routes}
    assert {"/api/political/elections", "/api/political/elections/start",
            "/api/political/elections/candidate", "/api/political/elections/vote"} <= paths
