# test/test_gametime.py — horloge du jeu : phase accélérée (24 h jeu = 10 h réelles) jusqu'à
# RATE_CHANGE_REAL, puis RECALAGE sur la réalité (temps de jeu = temps réel, UTC+0) pour toujours.
from types import SimpleNamespace

import pytest

from config import GAME_DAY_REAL_SECONDS, GAME_EPOCH_REAL, OLD_GAME_DAY_REAL_SECONDS, RATE_CHANGE_REAL
from utils import gametime
from utils.scheduler import JobSpec

E = GAME_EPOCH_REAL
R = RATE_CHANGE_REAL
R_MIDNIGHT = R   # RATE_CHANGE_REAL est choisi à 00:00 UTC ; depuis le recalage, c'est aussi minuit en jeu.


def _freeze(monkeypatch, real_ts: float):
    monkeypatch.setattr(gametime, "time", SimpleNamespace(time=lambda: real_ts))


def test_old_rate_was_24_game_hours_for_10_real_hours():
    assert OLD_GAME_DAY_REAL_SECONDS == 10 * 3600
    assert gametime.real_to_game(E + 10 * 3600) - E == 24 * 3600


def test_current_rate_is_1_to_1():
    assert GAME_DAY_REAL_SECONDS == 24 * 3600
    assert gametime.real_to_game(R + 24 * 3600) - gametime.real_to_game(R) == 24 * 3600
    assert gametime.real_to_game(R + 3600) - gametime.real_to_game(R) == 3600


def test_clock_is_continuous_at_epoch():
    # Rien ne saute au déploiement : les timestamps déjà en base restent valides.
    assert gametime.real_to_game(E) == E
    assert gametime.real_to_game(E - 5000) < E


def test_rate_change_realigns_on_reality_with_one_deliberate_jump():
    # Contrairement à GAME_EPOCH_REAL, cette jonction saute VOLONTAIREMENT : juste avant R, la
    # phase accélérée avait fait dériver la date de jeu loin devant la réalité ; à partir de R,
    # elle est recalée pile sur la date réelle (UTC+0), pour ne plus jamais en dériver.
    just_before = gametime.real_to_game(R - 1)      # encore sous l'ancien rythme accéléré
    at_r = gametime.real_to_game(R)                  # recalé : temps de jeu = temps réel
    assert at_r == R
    assert just_before > at_r                        # le saut en arrière, une seule fois
    assert gametime.real_to_game(R + 1) == R + 1      # ensuite, alignement parfait et stable


def test_game_now_follows_real_time_before_rate_change(monkeypatch):
    _freeze(monkeypatch, E)
    t0 = gametime.game_now()
    _freeze(monkeypatch, E + 1500)             # 25 min réelles, phase accélérée
    assert gametime.game_now() - t0 == 3600    # = 1 h de jeu


def test_game_now_follows_real_time_after_rate_change(monkeypatch):
    _freeze(monkeypatch, R)
    t0 = gametime.game_now()
    _freeze(monkeypatch, R + 3600)             # 1 h réelle, taux actuel (x1)
    assert gametime.game_now() - t0 == 3600    # = 1 h de jeu, pas 2,4 h


def test_cooldown_in_game_time(monkeypatch):
    # Cooldown de travail = 1 h DE JEU (config.WORK_COOLDOWN) = 1 h réelle au taux actuel.
    from config import WORK_COOLDOWN
    assert WORK_COOLDOWN == 3600
    _freeze(monkeypatch, R)
    last_used = gametime.game_now()
    _freeze(monkeypatch, R + 59 * 60)
    assert gametime.game_now() - last_used < WORK_COOLDOWN
    _freeze(monkeypatch, R + 60 * 60)
    assert gametime.game_now() - last_used >= WORK_COOLDOWN


def test_daily_cooldown_is_24_real_hours(monkeypatch):
    # SEULE exception au temps de jeu : le bonus quotidien se récupère toutes les 24 h RÉELLES.
    from config import DAILY_COOLDOWN
    _freeze(monkeypatch, R)
    last_used = gametime.game_now()
    _freeze(monkeypatch, R + 24 * 3600 - 1)
    assert gametime.game_now() - last_used < DAILY_COOLDOWN
    _freeze(monkeypatch, R + 24 * 3600)
    assert gametime.game_now() - last_used >= DAILY_COOLDOWN
    assert gametime.game_seconds_to_real(DAILY_COOLDOWN) == 24 * 3600


def test_everyone_sees_the_same_date(monkeypatch):
    _freeze(monkeypatch, R + 123_456)
    a, b = gametime.game_datetime(), gametime.game_datetime()
    assert a == b
    assert all(k in a for k in ("year", "month", "day", "hour", "minute", "season"))


def test_game_day_lasts_24_real_hours_now(monkeypatch):
    _freeze(monkeypatch, R)
    d0 = gametime.game_day_number()
    _freeze(monkeypatch, R + 24 * 3600)
    assert gametime.game_day_number() == d0 + 1


def test_calendar_rolls_over_with_game_time():
    # 365 jours de jeu = 365 jours réels au taux actuel : la date avance bien de 1 an.
    y0 = gametime.game_datetime(R)["year"]
    y1 = gametime.game_datetime(gametime.real_to_game(R + 365 * 86400))["year"]
    assert y1 == y0 + 1


def test_seasons_by_month():
    assert gametime.SEASONS_BY_MONTH[1] == "Hiver"
    assert gametime.SEASONS_BY_MONTH[4] == "Printemps"
    assert gametime.SEASONS_BY_MONTH[7] == "Été"
    assert gametime.SEASONS_BY_MONTH[10] == "Automne"


def test_duration_conversions_roundtrip():
    # Taux actuel = 1:1 (1 j de jeu = 24 h réelles).
    assert gametime.game_seconds_to_real(24 * 3600) == 24 * 3600
    assert gametime.game_seconds_to_real(3600) == 3600
    assert gametime.game_seconds_to_real(0) == 0
    assert gametime.game_seconds_to_real(1) == 1          # jamais 0 pour une durée > 0
    assert gametime.real_seconds_to_game(24 * 3600) == 24 * 3600


def test_format_helpers():
    ts = gametime.real_to_game(R_MIDNIGHT + 24 * 3600 + 1500)   # +1 j et +25 min de jeu, taux actuel
    assert gametime.fmt_game_time(ts) == "00:25"
    assert gametime.fmt_game_date(E) == gametime.fmt_game_date(E)
    assert gametime.fmt_game_datetime(ts).count("/") == 2


def test_scheduler_game_time_interval():
    async def noop():
        return None
    real = JobSpec("a", noop, 3600)
    game = JobSpec("b", noop, 3600, game_time=True)
    assert real.real_interval == 3600
    assert game.real_interval == 3600                     # 1 h de jeu = 1 h réelle, taux actuel


def test_next_game_hour_countdown(monkeypatch):
    _freeze(monkeypatch, R_MIDNIGHT)                       # 00:00 heure de jeu
    assert gametime.real_seconds_until_game_hour(1) == 3600


def test_age_follows_calendar_birthdays():
    from datetime import datetime, timezone
    ts = lambda *a: int(datetime(*a, tzinfo=timezone.utc).timestamp())
    born = ts(2026, 10, 11, 12)
    assert gametime.calendar_years_between(born, ts(2027, 10, 11, 11)) == 0
    assert gametime.calendar_years_between(born, ts(2027, 10, 11, 12)) == 1
    assert gametime.calendar_years_between(born, ts(2030, 3, 1)) == 3
    leap = ts(2028, 2, 29)
    assert gametime.calendar_years_between(leap, ts(2029, 2, 28)) == 0
    assert gametime.calendar_years_between(leap, ts(2029, 3, 1)) == 1


def test_calendar_months_and_years():
    from datetime import datetime, timezone
    ts = lambda *a: int(datetime(*a, tzinfo=timezone.utc).timestamp())
    assert gametime.add_game_months(ts(2026, 10, 11, 8), 1) == ts(2026, 11, 11, 8)
    assert gametime.add_game_months(ts(2026, 12, 15), 1) == ts(2027, 1, 15)
    assert gametime.add_game_months(ts(2027, 1, 31), 1) == ts(2027, 2, 28)       # fin de mois
    assert gametime.add_game_months(ts(2028, 1, 31), 1) == ts(2028, 2, 29)       # bissextile
    assert gametime.add_game_months(ts(2026, 1, 15), -1) == ts(2025, 12, 15)
    assert gametime.add_game_years(ts(2026, 10, 11), 30) == ts(2056, 10, 11)
    assert gametime.start_of_next_game_month(ts(2026, 12, 20, 5)) == ts(2027, 1, 1)
