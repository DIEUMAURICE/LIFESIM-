import asyncio
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
from webapp.routers import travel_router, vehicles_router
from webapp.server import app


@pytest_asyncio.fixture
async def persistent_travel_db(monkeypatch, tmp_path):
    """Base réelle (schéma + migrations) pour vérifier de bout en bout que `go()` persiste la
    phase de voyage et que `status()` la relit sans deviner — pas de mocks sur `travel_log`."""
    path = str(tmp_path / "travel-persistent.db")
    pool = database.SQLiteConnectionPool(path, size=3)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(database, "_db_global_lock", asyncio.Lock())
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    yield path
    await database._DB_POOL.close()


@pytest.mark.asyncio
async def test_travel_catalog_shows_active_event_price_and_happiness(monkeypatch):
    monkeypatch.setattr(
        travel_router.database,
        "get_user",
        AsyncMock(return_value={"balance": 25_000, "travel_count": 2, "travel_until": 0}),
    )
    monkeypatch.setattr(travel_router, "_visited", AsyncMock(return_value={"Paris"}))
    monkeypatch.setattr(
        travel_router,
        "_event_effect",
        AsyncMock(return_value={"travel_cost_mult": 2.0, "travel_happiness_mult": 0.5}),
    )

    result = await travel_router.catalog(user_id=8)
    paris = next(d for d in result["destinations"] if d["name"] == "Paris")

    assert paris["cost"] == 20_000
    assert paris["actual_cost"] == 40_000
    assert paris["actual_happiness"] == 7
    assert paris["visited"] is True
    assert paris["affordable"] is False


@pytest.mark.asyncio
async def test_vehicle_catalog_uses_vip_owned_vehicle_limit(monkeypatch):
    monkeypatch.setattr(
        vehicles_router.database,
        "get_user",
        AsyncMock(return_value={"balance": 12_345, "extra_vehicles": 2}),
    )
    monkeypatch.setattr(vehicles_router, "_get_vehicle_rows", AsyncMock(return_value=[{"veh_id": 3}]))
    monkeypatch.setattr(vehicles_router, "vip_max_vehicles", lambda _user, _base: 5)

    result = await vehicles_router.catalog(user_id=9)

    assert result["owned_count"] == 1
    assert result["max_vehicles"] == 5
    assert result["balance"] == 12_345
    assert result["items"]


@pytest.mark.asyncio
async def test_travel_refuses_when_bot_free_status_blocks_action(monkeypatch):
    monkeypatch.setattr(
        travel_router,
        "free_problem",
        AsyncMock(return_value="Tu es en prison."),
    )
    get_user = AsyncMock()
    monkeypatch.setattr(travel_router.database, "get_user", get_user)

    with pytest.raises(HTTPException) as exc:
        await travel_router.go(travel_router.TravelIn(destination="Paris"), user_id=22)

    assert exc.value.status_code == 422
    assert exc.value.detail == "Tu es en prison."
    get_user.assert_not_awaited()


@pytest.mark.asyncio
async def test_travel_status_reads_the_persisted_phase_by_exact_travel_until_match(monkeypatch):
    """Le trajet courant n'est plus deviné depuis une plage de durée plausible : on retrouve
    la ligne de `travel_log` dont le `travel_until` persisté est identique à celui du joueur,
    et `arrival_at` donne directement la fin du trajet (voir `go()` / `handlers/travel.py`)."""
    captured_query = {}

    class Cursor:
        async def __aenter__(self):
            return self

        async def __aexit__(self, *_args):
            return None

        async def fetchone(self):
            return ("Paris", 13_600)  # arrival_at persisté, plus un horodatage de départ à dériver

    class Connection:
        def execute(self, query, params):
            captured_query["query"] = query
            captured_query["params"] = params
            return Cursor()

    class ConnectionContext:
        async def __aenter__(self):
            return Connection()

        async def __aexit__(self, *_args):
            return None

    monkeypatch.setattr(
        travel_router.database,
        "get_user",
        AsyncMock(return_value={"balance": 0, "travel_count": 1, "travel_until": 20_800}),
    )
    monkeypatch.setattr(travel_router.database, "now", lambda: 11_000)
    monkeypatch.setattr(travel_router.database, "db_connection", lambda **_kwargs: ConnectionContext())
    monkeypatch.setattr(travel_router, "travel_time_multiplier", lambda _user: 1.0)

    result = await travel_router.status(user_id=15)

    assert result["current_destination"] == "Paris"
    assert result["remaining_seconds"] == 9_800
    assert result["travel_remaining_seconds"] == 2_600
    assert result["rest_remaining_seconds"] == 7_200
    assert captured_query["params"] == (15, 20_800)  # égalité exacte sur travel_until, pas une plage
    assert "travel_until=?" in captured_query["query"]


@pytest.mark.asyncio
async def test_travel_status_shows_no_current_trip_when_no_log_matches_travel_until(monkeypatch):
    """Si aucune ligne persistée ne correspond exactement (ex. voyage lancé avant la migration
    qui a ajouté `arrival_at`/`travel_until`), on ne doit plus inventer une destination au hasard."""
    class Cursor:
        async def __aenter__(self):
            return self

        async def __aexit__(self, *_args):
            return None

        async def fetchone(self):
            return None

    class Connection:
        def execute(self, *_args):
            return Cursor()

    class ConnectionContext:
        async def __aenter__(self):
            return Connection()

        async def __aexit__(self, *_args):
            return None

    monkeypatch.setattr(
        travel_router.database,
        "get_user",
        AsyncMock(return_value={"balance": 0, "travel_count": 1, "travel_until": 20_800}),
    )
    monkeypatch.setattr(travel_router.database, "now", lambda: 11_000)
    monkeypatch.setattr(travel_router.database, "db_connection", lambda **_kwargs: ConnectionContext())
    monkeypatch.setattr(travel_router, "travel_time_multiplier", lambda _user: 1.0)

    result = await travel_router.status(user_id=15)

    assert result["blocked"] is True
    assert result["current_destination"] is None
    assert result["travel_remaining_seconds"] is None
    assert result["rest_remaining_seconds"] is None


def test_vehicle_and_travel_routes_are_registered():
    paths = {route.path for route in app.routes}
    assert "/api/vehicles/sell" in paths
    assert "/api/vehicles/insure" in paths
    assert "/api/vehicles/buy" in paths
    assert "/api/vehicles/refuel" in paths
    assert "/api/travel/catalog" in paths
    assert "/api/travel/go" in paths


@pytest.mark.asyncio
async def test_travel_go_persists_the_exact_phase_read_back_by_status(persistent_travel_db, monkeypatch):
    """Bout en bout avec une vraie base : `go()` écrit `arrival_at`/`travel_until` dans
    `travel_log`, et `status()` les relit par égalité exacte — aucune estimation."""
    uid = 950
    monkeypatch.setattr(travel_router, "free_problem", AsyncMock(return_value=None))
    monkeypatch.setattr(travel_router, "_event_effect", AsyncMock(return_value={}))
    monkeypatch.setattr(travel_router, "get_active_vehicle", AsyncMock(return_value=None))
    monkeypatch.setattr(travel_router, "travel_time_multiplier", lambda _u: 1.0)
    monkeypatch.setattr(travel_router, "add_xp", AsyncMock())
    monkeypatch.setattr(travel_router, "update_mission_progress", AsyncMock())
    monkeypatch.setattr(travel_router.random, "randint", lambda a, b: 3_600 if (a, b) == (3600, 10800) else a)
    monkeypatch.setattr(travel_router.random, "choices", lambda events, weights=None: [events[3]])  # voyage neutre, sans argent/karma

    result = await travel_router.go(travel_router.TravelIn(destination="Paris"), user_id=uid)

    assert result["destination"] == "Paris"
    assert result["travel_seconds"] == 3_600
    assert result["cooldown_seconds"] == travel_router.TRAVEL_COOLDOWN

    status = await travel_router.status(user_id=uid)
    assert status["blocked"] is True
    assert status["current_destination"] == "Paris"
    # arrival_at = départ + 3 600 s, persisté par `go()` et relu tel quel par `status()`
    # (pas de seconde dérive possible, aucune estimation).
    assert 3_590 <= status["travel_remaining_seconds"] <= 3_600
    assert status["rest_remaining_seconds"] == travel_router.TRAVEL_COOLDOWN
    assert status["travel_until"] == result["travel_until"]


def test_vehicle_resale_price_matches_bot_formula():
    veh_type = next(iter(vehicles_router.VEHICLES))
    base_price = vehicles_router.VEHICLES[veh_type]["price"]
    vehicle = {"veh_type": veh_type, "condition": 37}

    assert vehicles_router._resale_price(vehicle) == int(base_price * 0.6 * 0.37)
