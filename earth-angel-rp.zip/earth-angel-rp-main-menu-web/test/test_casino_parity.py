from unittest.mock import AsyncMock

import pytest
from fastapi import HTTPException

from gameplay import casino as casino_gameplay
from webapp.routers import casino_router
from webapp.server import app


class FixedDeck:
    def shuffle(self, _deck):
        opening = ["2♠", "3♠", "4♠", "5♠", "6♠", "2♥", "4♦", "6♣", "8♠", "10♥"]
        _deck[:] = opening + [card for card in _deck if card not in opening]

    def random(self):
        return 1.0


@pytest.mark.asyncio
async def test_shared_poker_service_preserves_bot_payout_and_effects(monkeypatch):
    balance = {7: 50_000}

    async def change_balance(uid, delta, sink=None):
        balance[uid] += delta

    async def get_user(uid):
        return {"balance": balance[uid]}

    track = AsyncMock()
    xp = AsyncMock()
    loot = AsyncMock(return_value=None)
    monkeypatch.setattr(casino_gameplay.database, "update_balance", change_balance)
    monkeypatch.setattr(casino_gameplay.database, "get_user", get_user)
    # track_casino et add_random_item sont importés à l'appel, donc remplace le module adaptateur.
    import handlers.casino as bot_casino
    monkeypatch.setattr(bot_casino, "track_casino", track)
    monkeypatch.setattr(bot_casino, "add_random_item", loot)
    monkeypatch.setattr(casino_gameplay, "add_xp", xp)
    result = await casino_gameplay.play_video_poker(7, 1_000, rng=FixedDeck())

    assert result["player_name"] == "Quinte flush"
    assert result["outcome"] == "win"
    assert result["multiplier"] == 50
    assert result["gross_payout"] == 50_000
    assert result["net"] == 49_000
    assert result["balance"] == 99_000
    assert len(set(result["player_hand"] + result["dealer_hand"])) == 10
    track.assert_awaited_once_with(7, 1_000, 50_000)
    xp.assert_awaited_once_with(7, 30)
    loot.assert_not_awaited()


@pytest.mark.asyncio
async def test_poker_api_applies_bot_free_and_location_guards(monkeypatch):
    monkeypatch.setattr(casino_router, "free_problem", AsyncMock(return_value="En prison."))
    with pytest.raises(HTTPException) as exc:
        await casino_router.play_poker(casino_router.PokerIn(amount=500), user_id=11)
    assert exc.value.status_code == 422
    assert exc.value.detail == "En prison."

    monkeypatch.setattr(casino_router, "free_problem", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_router, "is_exempt", AsyncMock(return_value=False))
    monkeypatch.setattr(casino_router, "get_position", AsyncMock(return_value={"location": "bank", "in_transit": False}))
    with pytest.raises(HTTPException) as exc:
        await casino_router.play_poker(casino_router.PokerIn(amount=500), user_id=11)
    assert exc.value.status_code == 422
    assert "casino" in exc.value.detail


def test_poker_api_route_is_registered():
    paths = {route.path for route in app.routes}
    assert "/api/casino/poker/play" in paths


def test_poker_hand_rank_keeps_historical_category_only_comparison():
    assert casino_gameplay.poker_hand_rank(["A♠", "2♠", "3♠", "4♠", "5♠"])[0] == 8
    assert casino_gameplay.poker_hand_rank(["A♠", "K♥", "Q♦", "J♣", "9♠"])[0] == 0


@pytest.mark.asyncio
async def test_web_menu_catalog_matches_bot_main_menu(monkeypatch):
    from handlers.hub_data import AREAS, ZONE_INTRO
    from webapp.routers import hub_router

    async def fake_visible(area_id, user_id):
        assert user_id == 77
        if area_id == "vie":
            return [(0, "Vie", [("run", 0, "Se déplacer", "Va dans un lieu.", "Vie")])]
        return []

    monkeypatch.setattr(hub_router, "_visible", fake_visible)
    result = await hub_router.main_menu(user_id=77)
    assert [(area["id"], area["label"]) for area in result["areas"]] == [(a, label) for a, label, _ in AREAS]
    assert result["areas"][0]["description"] == ZONE_INTRO.get("vie", "")
    assert result["areas"][0]["sections"][0]["actions"][0]["function"] == "aller"
    assert result["areas"][0]["action_count"] == 1
    assert "/api/hub/menu" in {route.path for route in app.routes}


class FixedWheelAndRace:
    def randint(self, _low, _high):
        return 1

    def choices(self, population, weights=None):
        return [population[0]]

    def random(self):
        return 1.0


@pytest.mark.asyncio
async def test_roulette_shared_settlement_keeps_red_payout_and_stats(monkeypatch):
    balance = {8: 10_000}

    async def change_balance(uid, delta, sink=None):
        balance[uid] += delta

    async def get_user(uid):
        return {"balance": balance[uid]}

    import handlers.casino as bot_casino
    tracker = AsyncMock()
    monkeypatch.setattr(casino_gameplay.database, "update_balance", change_balance)
    monkeypatch.setattr(casino_gameplay.database, "get_user", get_user)
    monkeypatch.setattr(casino_gameplay, "add_xp", AsyncMock())
    monkeypatch.setattr(bot_casino, "track_casino", tracker)
    monkeypatch.setattr(bot_casino, "add_random_item", AsyncMock(return_value=None))
    result = await casino_gameplay.settle_roulette(8, 500, "rouge", rng=FixedWheelAndRace())
    assert result["number"] == 1 and result["color"] == "red"
    assert result["gross_payout"] == 1_000 and result["net"] == 500
    assert result["balance"] == 10_500
    tracker.assert_awaited_once_with(8, 500, 1_000)


@pytest.mark.asyncio
async def test_pmu_shared_settlement_keeps_weighted_order_and_odds(monkeypatch):
    balance = {9: 1_000}

    async def change_balance(uid, delta, sink=None):
        balance[uid] += delta

    async def get_user(uid):
        return {"balance": balance[uid]}

    import handlers.casino as bot_casino
    tracker = AsyncMock()
    monkeypatch.setattr(casino_gameplay.database, "update_balance", change_balance)
    monkeypatch.setattr(casino_gameplay.database, "get_user", get_user)
    monkeypatch.setattr(bot_casino, "track_casino", tracker)
    monkeypatch.setattr(bot_casino, "add_random_item", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_gameplay, "add_xp", AsyncMock())
    result = await casino_gameplay.settle_pmu(9, 100, 0, rng=FixedWheelAndRace())
    assert result["ranking"] == [0, 1, 2, 3, 4, 5]
    assert result["won"] and result["gross_payout"] == 250
    assert result["balance"] == 1_150
    tracker.assert_awaited_once_with(9, 100, 250)


def test_all_added_casino_routes_are_registered():
    paths = {route.path for route in app.routes}
    assert "/api/casino/poker/play" in paths
    assert "/api/casino/roulette/spin" in paths
    assert "/api/casino/pmu/run" in paths


class FixedBlackjackDraws:
    def __init__(self, values):
        self.values = iter(values)

    def choice(self, _options):
        return next(self.values)

    def random(self):
        return 1.0


@pytest.mark.asyncio
async def test_blackjack_shared_action_uses_common_stand_settlement(monkeypatch):
    balance = {10: 1_900}  # mise initiale de 100 déjà débitée par blackjack_start

    async def change_balance(uid, delta, sink=None):
        balance[uid] += delta

    async def get_user(uid):
        return {"balance": balance[uid]}

    import handlers.casino as bot_casino
    tracker = AsyncMock()
    monkeypatch.setattr(casino_gameplay.database, "update_balance", change_balance)
    monkeypatch.setattr(casino_gameplay.database, "get_user", get_user)
    monkeypatch.setattr(bot_casino, "track_casino", tracker)
    monkeypatch.setattr(bot_casino, "add_random_item", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_gameplay, "add_xp", AsyncMock())
    monkeypatch.setattr(casino_gameplay, "chance_boost_bonus", lambda _u: 0.0)
    game = {"status": "active", "bet": 100, "player_hand": ["10♠", "K♥"], "dealer_hand": ["10♦", "6♣"]}
    result = await casino_gameplay.blackjack_action(10, game, "stand", rng=FixedBlackjackDraws(["K", "♠"]))
    assert result["status"] == "win"
    assert result["gross_payout"] == 200
    assert result["balance"] == 2_100
    assert game["status"] == "win"
    tracker.assert_awaited_once_with(10, 100, 200)


def test_all_advanced_casino_api_routes_are_registered():
    paths = {route.path for route in app.routes}
    expected = {
        "/api/casino/poker/play", "/api/casino/roulette/spin", "/api/casino/pmu/run",
        "/api/casino/blackjack/start", "/api/casino/blackjack/{game_id}/action",
    }
    assert expected <= paths


@pytest.mark.asyncio
async def test_mines_transition_and_cashout_shared_rules(monkeypatch):
    game = {"status": "active", "amount": 100, "mines": {24}, "revealed": set(), "multiplier": 1.0}
    first = casino_gameplay.mines_reveal(game, 2)
    assert first["status"] == "active" and first["multiplier"] == 1.05
    assert casino_gameplay.mines_reveal(game, 24)["status"] == "loss"
    with pytest.raises(ValueError):
        casino_gameplay.mines_reveal(game, 3)


@pytest.mark.asyncio
async def test_crash_tick_uses_shared_step_and_payout(monkeypatch):
    game = {"running": True, "status": "active", "amount": 100, "current_mult": 1.0, "crash_point": 1.2}
    assert casino_gameplay.advance_crash(game) == (1.05, False)
    assert casino_gameplay.advance_crash(game) == (1.1, False)
    assert casino_gameplay.advance_crash(game) == (1.15, False)
    balance = {12: 900}

    async def change_balance(uid, delta, sink=None):
        balance[uid] += delta

    async def get_user(uid):
        return {"balance": balance[uid]}

    import handlers.casino as bot_casino
    monkeypatch.setattr(casino_gameplay.database, "update_balance", change_balance)
    monkeypatch.setattr(casino_gameplay.database, "get_user", get_user)
    monkeypatch.setattr(bot_casino, "track_casino", AsyncMock())
    monkeypatch.setattr(bot_casino, "add_random_item", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_gameplay, "add_xp", AsyncMock())
    monkeypatch.setattr(casino_gameplay, "chance_boost_bonus", lambda _u: 0.0)
    result = await casino_gameplay.settle_crash_cashout(12, game, rng=FixedWheelAndRace())
    assert result["gross_payout"] == 114  # int(100 × 1,15), troncature historique
    assert result["status"] == "cashed_out"
    assert result["balance"] == 1_014


def test_every_casino_game_route_is_registered():
    paths = {route.path for route in app.routes}
    assert {
        "/api/casino/blackjack/start", "/api/casino/blackjack/{game_id}/action",
        "/api/casino/roulette/spin", "/api/casino/pmu/run",
        "/api/casino/mines/start", "/api/casino/mines/{game_id}/action",
        "/api/casino/crash/start", "/api/casino/crash/{game_id}",
        "/api/casino/crash/{game_id}/cashout",
    } <= paths


import asyncio
import pytest_asyncio
import database
import migrations
from gameplay import casino_sessions


@pytest_asyncio.fixture
async def persistent_casino_db(monkeypatch, tmp_path):
    path = str(tmp_path / "casino-persistent.db")
    pool = database.SQLiteConnectionPool(path, size=3)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(database, "_db_global_lock", asyncio.Lock())
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    yield path
    await database._DB_POOL.close()


@pytest.mark.asyncio
async def test_casino_sessions_survive_database_pool_restart(persistent_casino_db, monkeypatch):
    states = {
        "blackjack": {"status": "active", "bet": 500, "player_hand": ["10♠", "9♥"], "dealer_hand": ["10♦", "7♣"]},
        "mines": {"status": "active", "amount": 400, "mines": {2, 7, 11, 18, 23}, "revealed": {0}, "multiplier": 1.05},
        "crash": {"status": "active", "amount": 300, "crash_point": 2.5, "current_mult": 1.1, "started_at": 1_800_000_000.0, "running": True},
    }
    for game_type, state in states.items():
        await casino_sessions.create_session(f"id-{game_type}", 902, game_type, state)

    await database._DB_POOL.close()
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(persistent_casino_db, size=3))
    for game_type, expected in states.items():
        loaded = await casino_sessions.get_session(f"id-{game_type}", 902, game_type)
        assert loaded is not None and loaded["status"] == "active"
        assert loaded["state"] == expected
    assert await casino_sessions.get_session("id-mines", 999, "mines") is None


@pytest.mark.asyncio
async def test_casino_session_compare_and_swap_rejects_duplicate_action(persistent_casino_db):
    await casino_sessions.create_session(
        "one-shot", 903, "blackjack",
        {"status": "active", "bet": 100, "player_hand": ["10♠", "8♥"], "dealer_hand": ["7♣"]},
    )
    first = await casino_sessions.get_session("one-shot", 903, "blackjack")
    concurrent = await casino_sessions.get_session("one-shot", 903, "blackjack")
    assert first and concurrent
    assert await casino_sessions.claim_active_session(first)
    assert not await casino_sessions.claim_active_session(concurrent)
    assert await casino_sessions.save_claimed_session(first, first["state"], "active")
    updated = await casino_sessions.get_session("one-shot", 903, "blackjack")
    assert updated and updated["revision"] == 2 and updated["status"] == "active"
    assert await casino_sessions.claim_active_session(updated)
    assert await casino_sessions.save_claimed_session(updated, updated["state"], "win")
    finished = await casino_sessions.get_session("one-shot", 903, "blackjack")
    assert finished and finished["status"] == "win" and finished["settled_at"] > 0
    assert not await casino_sessions.claim_active_session(finished)


@pytest.mark.asyncio
async def test_blackjack_api_game_reloads_after_pool_restart_and_cannot_pay_twice(persistent_casino_db, monkeypatch):
    uid = 904
    user = await database.get_user(uid)
    before = user["balance"]
    monkeypatch.setattr(casino_router, "free_problem", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_router, "is_exempt", AsyncMock(return_value=True))
    monkeypatch.setattr(casino_router, "is_casino_open", lambda: True)
    import handlers.casino as bot_casino
    monkeypatch.setattr(bot_casino, "track_casino", AsyncMock())
    monkeypatch.setattr(bot_casino, "add_random_item", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_gameplay, "add_xp", AsyncMock())
    monkeypatch.setattr(casino_gameplay, "chance_boost_bonus", lambda _u: 0.0)
    cards = iter(["10♠", "9♥", "10♦", "7♣"])
    monkeypatch.setattr(casino_gameplay, "_blackjack_card", lambda _rng: next(cards))

    started = await casino_router.start_blackjack(casino_router.BlackjackStartIn(amount=200), user_id=uid)
    game_id = started["game_id"]
    assert started["status"] == "active"
    await database._DB_POOL.close()
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(persistent_casino_db, size=3))

    settled = await casino_router.action_blackjack(game_id, casino_router.BlackjackActionIn(action="stand"), user_id=uid)
    assert settled["status"] == "win" and settled["gross_payout"] == 400
    assert (await database.get_user(uid))["balance"] == before + 200
    persisted = await casino_sessions.get_session(game_id, uid, "blackjack")
    assert persisted and persisted["status"] == "win"

    with pytest.raises(HTTPException) as exc:
        await casino_router.action_blackjack(game_id, casino_router.BlackjackActionIn(action="stand"), user_id=uid)
    assert exc.value.status_code == 409
    assert (await database.get_user(uid))["balance"] == before + 200


@pytest.mark.asyncio
async def test_mines_api_session_reloads_and_settles_once_after_restart(persistent_casino_db, monkeypatch):
    uid = 905
    user = await database.get_user(uid)
    before = user["balance"]
    monkeypatch.setattr(casino_router, "free_problem", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_router, "is_exempt", AsyncMock(return_value=True))
    monkeypatch.setattr(casino_router, "cooldown_problem", AsyncMock(return_value=(None, True)))
    monkeypatch.setattr(casino_router, "is_casino_open", lambda: True)
    import handlers.casino as bot_casino
    monkeypatch.setattr(bot_casino, "track_casino", AsyncMock())
    monkeypatch.setattr(bot_casino, "add_random_item", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_gameplay, "add_xp", AsyncMock())
    monkeypatch.setattr(casino_gameplay, "chance_boost_bonus", lambda _u: 0.0)

    started = await casino_router.start_mines(casino_router.MinesStartIn(amount=400), user_id=uid)
    game_id = started["game_id"]
    await database._DB_POOL.close()
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(persistent_casino_db, size=3))
    resumed = await casino_sessions.get_session(game_id, uid, "mines")
    assert resumed and isinstance(resumed["state"]["mines"], set)
    safe_cell = next(index for index in range(25) if index not in resumed["state"]["mines"])
    clicked = await casino_router.action_mines(game_id, casino_router.MinesActionIn(action="click", index=safe_cell), user_id=uid)
    assert clicked["status"] == "active" and clicked["multiplier"] == 1.05
    settled = await casino_router.action_mines(game_id, casino_router.MinesActionIn(action="cashout"), user_id=uid)
    assert settled["status"] == "win" and settled["gross_payout"] == 420
    assert (await database.get_user(uid))["balance"] == before + 20
    persisted = await casino_sessions.get_session(game_id, uid, "mines")
    assert persisted and persisted["status"] == "win"
    with pytest.raises(HTTPException) as exc:
        await casino_router.action_mines(game_id, casino_router.MinesActionIn(action="cashout"), user_id=uid)
    assert exc.value.status_code == 409
    assert (await database.get_user(uid))["balance"] == before + 20


@pytest.mark.asyncio
async def test_crash_api_session_reloads_clock_and_pays_once_after_restart(persistent_casino_db, monkeypatch):
    uid = 906
    user = await database.get_user(uid)
    before = user["balance"]
    monkeypatch.setattr(casino_router, "_check_table_access", AsyncMock())
    monkeypatch.setattr(casino_router, "crash_point_from_roll", lambda _roll: 3.0)
    monkeypatch.setattr(casino_router, "crash_multiplier_at", lambda _started: 1.5)
    monkeypatch.setattr(casino_router.random, "random", lambda: 0.5)
    import handlers.casino as bot_casino
    monkeypatch.setattr(bot_casino, "track_casino", AsyncMock())
    monkeypatch.setattr(bot_casino, "add_random_item", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_gameplay, "add_xp", AsyncMock())
    monkeypatch.setattr(casino_gameplay, "chance_boost_bonus", lambda _u: 0.0)

    started = await casino_router.start_crash(casino_router.CrashStartIn(amount=300), user_id=uid)
    game_id = started["game_id"]
    await database._DB_POOL.close()
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(persistent_casino_db, size=3))
    state = await casino_router.status_crash(game_id, user_id=uid)
    assert state["status"] == "active" and state["multiplier"] == 1.5
    settled = await casino_router.cashout_crash(game_id, user_id=uid)
    assert settled["status"] == "cashed_out" and settled["gross_payout"] == 450
    assert (await database.get_user(uid))["balance"] == before + 150
    persisted = await casino_sessions.get_session(game_id, uid, "crash")
    assert persisted and persisted["status"] == "cashed_out"
    with pytest.raises(HTTPException) as exc:
        await casino_router.cashout_crash(game_id, user_id=uid)
    assert exc.value.status_code == 409
    assert (await database.get_user(uid))["balance"] == before + 150


def test_resolve_roulette_and_pmu_are_pure_functions_with_no_db_calls():
    """`resolve_roulette`/`resolve_pmu` ne touchent plus la base : ce sont les helpers de
    session (`create_session_with_stake` / `save_claimed_session_with_payout`) qui regroupent
    la mise et le gain dans une transaction, voir les tests d'intégration ci-dessous."""
    result = casino_gameplay.resolve_roulette(500, "rouge", rng=FixedWheelAndRace())
    assert result == {"bet_type": "rouge", "number": 1, "color": "red",
                       "bet": 500, "gross_payout": 1_000, "net": 500}
    pmu_result = casino_gameplay.resolve_pmu(100, 0, rng=FixedWheelAndRace())
    assert pmu_result["ranking"] == [0, 1, 2, 3, 4, 5]
    assert pmu_result["won"] is True and pmu_result["gross_payout"] == 250


@pytest.mark.asyncio
async def test_create_session_with_stake_refuses_insufficient_funds_without_mutating_anything(persistent_casino_db):
    """Le débit et la création de session sont dans LA MÊME transaction : un refus pour fonds
    insuffisants ne doit laisser ni mise prélevée, ni session fantôme."""
    uid = 913
    before = (await database.get_user(uid))["balance"]
    with pytest.raises(ValueError):
        await casino_sessions.create_session_with_stake("too-big", uid, "mines", {"amount": before + 1}, before + 1)
    assert (await database.get_user(uid))["balance"] == before
    assert await casino_sessions.get_session("too-big", uid, "mines") is None


@pytest.mark.asyncio
async def test_save_claimed_session_with_payout_credits_once_and_rejects_a_stale_replay(persistent_casino_db):
    """Le crédit du gain et la transition d'état finale sont dans LA MÊME transaction que la
    réservation CAS : un rejeu avec une révision périmée ne doit jamais créditer deux fois."""
    uid = 912
    before = (await database.get_user(uid))["balance"]
    game_id = "payout-check"
    game = {"amount": 200}
    await casino_sessions.create_session_with_stake(game_id, uid, "crash", game, 200)
    session = await casino_sessions.get_session(game_id, uid, "crash")
    assert await casino_sessions.claim_active_session(session)

    saved = await casino_sessions.save_claimed_session_with_payout(session, game, "cashed_out", 500)
    assert saved == {"saved": True, "balance": before - 200 + 500}
    assert (await database.get_user(uid))["balance"] == before - 200 + 500

    replay = await casino_sessions.save_claimed_session_with_payout(session, game, "cashed_out", 500)
    assert replay is None
    assert (await database.get_user(uid))["balance"] == before - 200 + 500


@pytest.mark.asyncio
async def test_stuck_processing_session_is_recovered_without_losing_or_duplicating_the_stake(persistent_casino_db, monkeypatch):
    """Une réservation 'processing' restée bloquée (redémarrage serveur entre la réservation et
    l'enregistrement du résultat) doit être relâchée automatiquement, sans jamais reprélever
    la mise ni empêcher la partie d'être rejouée normalement ensuite."""
    uid = 911
    before = (await database.get_user(uid))["balance"]
    game_id = "stuck-mines"
    game = {"amount": 300, "mines": {24}, "revealed": set(), "multiplier": 1.0, "status": "active"}
    await casino_sessions.create_session_with_stake(game_id, uid, "mines", game, 300)
    session = await casino_sessions.get_session(game_id, uid, "mines")
    assert await casino_sessions.claim_active_session(session)  # passe à 'processing' ; simule le crash juste après

    monkeypatch.setattr(casino_sessions, "PROCESSING_STALE_SECONDS", 0)
    recovered = await casino_sessions.get_session(game_id, uid, "mines")
    assert recovered["status"] == "active"
    # La mise n'a été prélevée qu'une seule fois, à la création de la session.
    assert (await database.get_user(uid))["balance"] == before - 300

    assert await casino_sessions.claim_active_session(recovered)
    saved = await casino_sessions.save_claimed_session_with_payout(recovered, recovered["state"], "loss", 0)
    assert saved is not None
    final = await casino_sessions.get_session(game_id, uid, "mines")
    assert final["status"] == "loss"
    assert (await database.get_user(uid))["balance"] == before - 300


@pytest.mark.asyncio
async def test_roulette_api_resumes_a_predebited_stake_instead_of_charging_twice(persistent_casino_db, monkeypatch):
    """Si une mise Roulette a déjà été débitée (session 'active' ou 'processing' interrompue
    avant résolution), un nouvel appel reprend cette session au lieu d'en créer une seconde."""
    uid = 910
    before = (await database.get_user(uid))["balance"]
    monkeypatch.setattr(casino_router, "free_problem", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_router, "is_exempt", AsyncMock(return_value=True))
    monkeypatch.setattr(casino_router, "is_casino_open", lambda: True)
    monkeypatch.setattr(casino_router, "track_casino", AsyncMock())
    monkeypatch.setattr(casino_router, "add_random_item", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_router, "add_xp", AsyncMock())
    monkeypatch.setattr(casino_router.random, "random", lambda: 1.0)  # jamais de loot, résultat déterministe
    monkeypatch.setattr(casino_gameplay.random, "randint", lambda a, b: 1)  # tirage 1 → rouge

    game_id = "pending-roulette"
    await casino_sessions.create_session_with_stake(game_id, uid, "roulette", {"amount": 500, "bet_type": "rouge"}, 500)
    assert (await database.get_user(uid))["balance"] == before - 500

    result = await casino_router.play_roulette(casino_router.RouletteIn(amount=500, bet_type="rouge"), user_id=uid)
    assert result["number"] == 1 and result["color"] == "red"
    assert result["gross_payout"] == 1_000
    # Reprise de la mise déjà prélevée : pas de second débit.
    assert (await database.get_user(uid))["balance"] == before - 500 + 1_000
    settled = await casino_sessions.get_session(game_id, uid, "roulette")
    assert settled["status"] == "win"

    # La session réglée ne doit plus être reprise : un nouveau pari débite bien une nouvelle mise.
    result2 = await casino_router.play_roulette(casino_router.RouletteIn(amount=500, bet_type="rouge"), user_id=uid)
    assert result2["gross_payout"] == 1_000
    assert (await database.get_user(uid))["balance"] == before - 500 + 1_000 - 500 + 1_000


@pytest.mark.asyncio
async def test_pmu_api_groups_stake_and_payout_in_one_transaction(persistent_casino_db, monkeypatch):
    uid = 914
    before = (await database.get_user(uid))["balance"]
    monkeypatch.setattr(casino_router, "free_problem", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_router, "is_exempt", AsyncMock(return_value=True))
    monkeypatch.setattr(casino_router, "is_casino_open", lambda: True)
    monkeypatch.setattr(casino_router, "track_casino", AsyncMock())
    monkeypatch.setattr(casino_router, "add_random_item", AsyncMock(return_value=None))
    monkeypatch.setattr(casino_router, "add_xp", AsyncMock())
    monkeypatch.setattr(casino_router.random, "random", lambda: 1.0)
    monkeypatch.setattr(casino_gameplay.random, "choices", lambda population, weights=None: [population[0]])

    result = await casino_router.play_pmu(casino_router.PmuIn(amount=100, horse_index=0), user_id=uid)
    assert result["won"] is True and result["gross_payout"] == 250
    assert (await database.get_user(uid))["balance"] == before - 100 + 250
    sessions_for_user = await casino_sessions.find_resumable_session(uid, "pmu")
    assert sessions_for_user is None  # réglée : plus rien à reprendre


@pytest.mark.asyncio
async def test_main_menu_catalog_builds_from_real_bot_visibility(persistent_casino_db, monkeypatch):
    from webapp.routers import hub_router
    await database.get_user(907, "menu-player", "Menu Player")
    monkeypatch.setattr(hub_router, "is_beginner", AsyncMock(return_value=True))
    starter = await hub_router.main_menu(user_id=907)
    assert starter["simple_menu"] is True and len(starter["areas"]) == 5
    assert [action["function"] for action in starter["quick_actions"]] == ["quotidien", "travailler", "tutorial"]
    catalog = await hub_router.main_menu(show_all=True, user_id=907)
    assert len(catalog["areas"]) == 16
    assert catalog["areas"][0]["id"] == "vie"
    assert catalog["areas"][0]["action_count"] > 0
    assert all(isinstance(area["sections"], list) for area in catalog["areas"])
