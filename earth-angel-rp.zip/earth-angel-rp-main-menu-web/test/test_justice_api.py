import pytest
from fastapi import HTTPException
from unittest.mock import AsyncMock

from webapp.routers import crime_router


@pytest.mark.asyncio
async def test_justice_status_projects_only_the_requesting_players_case(monkeypatch):
    monkeypatch.setattr(crime_router.database, "get_user", AsyncMock(return_value={
        "prison_until": 1_400, "karma": 10, "balance": 80_000,
    }))
    monkeypatch.setattr(crime_router, "now", lambda: 1_000)
    monkeypatch.setattr(crime_router.justice_service, "has_judges", AsyncMock(return_value=True))
    monkeypatch.setattr(crime_router.justice_service, "my_file", AsyncMock(return_value={
        "id": 41, "suspect_id": -77, "crime": "Cambriolage", "source": "police",
        "status": "detenu", "bail": 100_000, "plead": 1, "lawyer_id": 0,
        "lawyer_name": None, "judge_id": 999, "verdict": "secret", "created_at": 123,
    }))
    monkeypatch.setattr(crime_router.justice_service, "effective_bail", lambda f: 65_000)
    monkeypatch.setattr(crime_router.justice_service, "list_lawyers", AsyncMock(return_value=[
        {"user_id": 503, "full_name": "Avocate A", "on_duty": 1},
    ]))

    status = await crime_router.justice_status(user_id=-77)

    assert status["in_prison"] is True
    assert status["has_judges"] is True
    assert status["seconds_left"] == 400
    assert status["case"] == {
        "id": 41, "crime": "Cambriolage", "status": "detenu", "bail": 100_000,
        "effective_bail": 65_000, "can_pay_bail": True, "lawyer_id": 0,
        "lawyer_name": None, "plead": 1,
    }
    assert status["available_lawyers"] == [{"user_id": 503, "name": "Avocate A"}]
    assert "suspect_id" not in status["case"]
    assert "judge_id" not in status["case"]
    assert "verdict" not in status["case"]


@pytest.mark.asyncio
@pytest.mark.parametrize("endpoint", [
    crime_router.pay_caution,
    crime_router.go_to_tribunal,
    crime_router.hire_lawyer,
])
async def test_automatic_justice_endpoints_refuse_when_a_judge_exists(monkeypatch, endpoint):
    monkeypatch.setattr(crime_router.justice_service, "has_judges", AsyncMock(return_value=True))
    with pytest.raises(HTTPException) as exc:
        await endpoint(user_id=-77)
    assert exc.value.status_code == 409


@pytest.mark.asyncio
async def test_justice_routes_are_registered_on_the_shared_api():
    from webapp.server import app

    paths = {route.path for route in app.routes}
    assert "/api/justice/status" in paths
    assert "/api/justice/hearing" in paths
    assert "/api/justice/bail" in paths
    assert "/api/justice/hire-lawyer" in paths
    assert "/api/justice/caution" in paths
    assert "/api/justice/tribunal" in paths
    assert "/api/justice/lawyer" in paths


@pytest.mark.asyncio
async def test_judicial_player_actions_use_shared_justice_services(monkeypatch):
    hearing = AsyncMock(return_value=(True, "Audience demandée."))
    bail = AsyncMock(return_value=(True, "Caution payée."))
    lawyer = AsyncMock(return_value=(True, "Avocat engagé."))
    monkeypatch.setattr(crime_router.justice_service, "request_hearing", hearing)
    monkeypatch.setattr(crime_router.justice_service, "pay_bail", bail)
    monkeypatch.setattr(crime_router.justice_service, "hire_lawyer", lawyer)

    assert (await crime_router.request_case_hearing(user_id=-77))["requested"] is True
    assert (await crime_router.pay_judicial_bail(user_id=-77))["paid"] is True
    result = await crime_router.hire_case_lawyer(
        crime_router.HireLawyerIn(lawyer_id=503), user_id=-77
    )
    assert result["hired"] == 503
    hearing.assert_awaited_once_with(-77)
    bail.assert_awaited_once_with(-77)
    lawyer.assert_awaited_once_with(-77, 503)


# ═══════════════════════════════════════════════════════════════════
#     PERSONNEL JUDICIAIRE — juge / avocat
# ═══════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_justice_staff_routes_are_registered_on_the_shared_api():
    from webapp.server import app

    paths = {route.path for route in app.routes}
    assert "/api/justice/staff" in paths
    assert "/api/justice/cases" in paths
    assert "/api/justice/my-clients" in paths
    assert "/api/justice/plead" in paths
    assert "/api/justice/set-bail" in paths
    assert "/api/justice/verdict" in paths
    assert "/api/justice/warrant" in paths


@pytest.mark.asyncio
async def test_justice_staff_status_reports_post_on_duty_and_shared_limits(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "staff", AsyncMock(return_value={
        "post": "juge", "on_duty": 1,
    }))

    status = await crime_router.justice_staff_status(user_id=999)

    assert status == {
        "post": "juge",
        "on_duty": True,
        "limits": {
            "bail_max": crime_router.JUSTICE["bail_max"],
            "fine_max": crime_router.JUSTICE["fine_max"],
            "sentence_max_seconds": crime_router.JUSTICE["sentence_max"],
        },
    }


@pytest.mark.asyncio
async def test_justice_staff_status_reports_no_post_for_an_ordinary_player(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "staff", AsyncMock(return_value=None))

    status = await crime_router.justice_staff_status(user_id=-77)

    assert status["post"] is None
    assert status["on_duty"] is False


@pytest.mark.asyncio
async def test_judge_case_list_projects_file_fields_without_internal_secrets(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "judge_check", AsyncMock(return_value=({"post": "juge"}, "")))
    monkeypatch.setattr(crime_router.justice_service, "effective_bail", lambda f: 42_000)
    list_files = AsyncMock(return_value=[{
        "id": 41, "suspect_id": -77, "suspect_name": "Joueur #77", "crime": "Cambriolage",
        "status": "detenu", "bail": 100_000, "plead": 1, "lawyer_id": 503,
        "lawyer_name": "Avocate A", "jail_secs": 3_600, "created_at": 123,
        "judge_id": 999, "verdict": "secret",
    }])
    monkeypatch.setattr(crime_router.justice_service, "list_files", list_files)

    result = await crime_router.judge_case_list(limit=20, user_id=999)

    assert result["cases"] == [{
        "id": 41, "suspect_id": -77, "suspect_name": "Joueur #77", "crime": "Cambriolage",
        "status": "detenu", "bail": 100_000, "effective_bail": 42_000, "plead": 1,
        "lawyer_id": 503, "lawyer_name": "Avocate A", "jail_secs": 3_600, "created_at": 123,
    }]
    assert "judge_id" not in result["cases"][0]
    assert "verdict" not in result["cases"][0]
    list_files.assert_awaited_once_with(limit=20)


@pytest.mark.asyncio
async def test_judge_case_list_refuses_when_not_a_judge_on_duty(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "judge_check", AsyncMock(return_value=(None, "Tu n'es pas juge en service.")))
    with pytest.raises(HTTPException) as exc:
        await crime_router.judge_case_list(limit=20, user_id=-77)
    assert exc.value.status_code == 403


@pytest.mark.asyncio
async def test_judge_case_list_clamps_limit_between_one_and_fifty(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "judge_check", AsyncMock(return_value=({"post": "juge"}, "")))
    list_files = AsyncMock(return_value=[])
    monkeypatch.setattr(crime_router.justice_service, "list_files", list_files)

    await crime_router.judge_case_list(limit=500, user_id=999)
    list_files.assert_awaited_once_with(limit=50)

    list_files.reset_mock()
    await crime_router.judge_case_list(limit=0, user_id=999)
    list_files.assert_awaited_once_with(limit=1)


@pytest.mark.asyncio
async def test_lawyer_client_list_scopes_files_to_the_requesting_lawyer(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "lawyer_check", AsyncMock(return_value=({"post": "avocat"}, "")))
    monkeypatch.setattr(crime_router.justice_service, "effective_bail", lambda f: 0)
    list_files = AsyncMock(return_value=[])
    monkeypatch.setattr(crime_router.justice_service, "list_files", list_files)

    await crime_router.lawyer_client_list(limit=20, user_id=503)

    list_files.assert_awaited_once_with(limit=20, lawyer_id=503)


@pytest.mark.asyncio
async def test_lawyer_client_list_refuses_when_not_a_lawyer_on_duty(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "lawyer_check", AsyncMock(return_value=(None, "Tu n'es pas avocat en service.")))
    with pytest.raises(HTTPException) as exc:
        await crime_router.lawyer_client_list(limit=20, user_id=-77)
    assert exc.value.status_code == 403


@pytest.mark.asyncio
async def test_lawyer_plead_delegates_to_the_shared_justice_service(monkeypatch):
    plead = AsyncMock(return_value=(True, "Plaidoirie déposée."))
    monkeypatch.setattr(crime_router.justice_service, "plead", plead)

    result = await crime_router.lawyer_plead(crime_router.PleadIn(file_id=41), user_id=503)

    assert result == {"pleaded": True, "message": "Plaidoirie déposée."}
    plead.assert_awaited_once_with(503, 41)


@pytest.mark.asyncio
async def test_lawyer_plead_raises_422_on_service_refusal(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "plead", AsyncMock(return_value=(False, "Dossier déjà plaidé.")))
    with pytest.raises(HTTPException) as exc:
        await crime_router.lawyer_plead(crime_router.PleadIn(file_id=41), user_id=503)
    assert exc.value.status_code == 422
    assert exc.value.detail == "Dossier déjà plaidé."


@pytest.mark.asyncio
async def test_judge_set_bail_allows_a_zero_amount_to_explicitly_deny_bail(monkeypatch):
    set_bail = AsyncMock(return_value=(True, "Caution refusée."))
    monkeypatch.setattr(crime_router.justice_service, "set_bail", set_bail)

    result = await crime_router.judge_set_bail(crime_router.SetBailIn(file_id=41, amount=0), user_id=999)

    assert result == {"set": True, "message": "Caution refusée."}
    set_bail.assert_awaited_once_with(999, 41, 0)


@pytest.mark.asyncio
async def test_judge_set_bail_raises_422_on_service_refusal(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "set_bail", AsyncMock(return_value=(False, "Dossier introuvable.")))
    with pytest.raises(HTTPException) as exc:
        await crime_router.judge_set_bail(crime_router.SetBailIn(file_id=41, amount=50_000), user_id=999)
    assert exc.value.status_code == 422


@pytest.mark.asyncio
@pytest.mark.parametrize("verdict", ["acquit", "amende", "prison"])
async def test_judge_render_verdict_delegates_each_valid_verdict_to_the_shared_service(monkeypatch, verdict):
    judge_file = AsyncMock(return_value=(True, "Verdict rendu."))
    monkeypatch.setattr(crime_router.justice_service, "judge_file", judge_file)

    result = await crime_router.judge_render_verdict(
        crime_router.VerdictIn(file_id=41, verdict=verdict, amount=75_000), user_id=999
    )

    assert result == {"judged": True, "message": "Verdict rendu."}
    judge_file.assert_awaited_once_with(999, 41, verdict, 75_000)


@pytest.mark.asyncio
async def test_judge_render_verdict_rejects_an_unknown_verdict_before_calling_the_service(monkeypatch):
    judge_file = AsyncMock(return_value=(True, "Verdict rendu."))
    monkeypatch.setattr(crime_router.justice_service, "judge_file", judge_file)

    with pytest.raises(HTTPException) as exc:
        await crime_router.judge_render_verdict(
            crime_router.VerdictIn(file_id=41, verdict="banni", amount=0), user_id=999
        )
    assert exc.value.status_code == 400
    judge_file.assert_not_awaited()


@pytest.mark.asyncio
async def test_judge_render_verdict_raises_422_on_service_refusal(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "judge_file", AsyncMock(return_value=(False, "Dossier déjà jugé.")))
    with pytest.raises(HTTPException) as exc:
        await crime_router.judge_render_verdict(
            crime_router.VerdictIn(file_id=41, verdict="amende", amount=10_000), user_id=999
        )
    assert exc.value.status_code == 422


@pytest.mark.asyncio
async def test_judge_issue_warrant_delegates_to_the_shared_justice_service(monkeypatch):
    issue_warrant = AsyncMock(return_value=(True, "Mandat émis."))
    monkeypatch.setattr(crime_router.justice_service, "issue_warrant", issue_warrant)

    result = await crime_router.judge_issue_warrant(
        crime_router.WarrantIn(suspect_id=-42, reason="Fuite après interrogatoire"), user_id=999
    )

    assert result == {"issued": True, "message": "Mandat émis."}
    issue_warrant.assert_awaited_once_with(999, -42, "Fuite après interrogatoire")


@pytest.mark.asyncio
async def test_judge_issue_warrant_rejects_an_empty_reason_before_calling_the_service(monkeypatch):
    issue_warrant = AsyncMock(return_value=(True, "Mandat émis."))
    monkeypatch.setattr(crime_router.justice_service, "issue_warrant", issue_warrant)

    with pytest.raises(HTTPException) as exc:
        await crime_router.judge_issue_warrant(
            crime_router.WarrantIn(suspect_id=-42, reason="   "), user_id=999
        )
    assert exc.value.status_code == 422
    issue_warrant.assert_not_awaited()


@pytest.mark.asyncio
async def test_judge_issue_warrant_truncates_an_overlong_reason_to_eighty_characters(monkeypatch):
    issue_warrant = AsyncMock(return_value=(True, "Mandat émis."))
    monkeypatch.setattr(crime_router.justice_service, "issue_warrant", issue_warrant)
    long_reason = "x" * 120

    await crime_router.judge_issue_warrant(
        crime_router.WarrantIn(suspect_id=-42, reason=long_reason), user_id=999
    )

    issue_warrant.assert_awaited_once_with(999, -42, "x" * 80)


@pytest.mark.asyncio
async def test_judge_issue_warrant_raises_422_on_service_refusal(monkeypatch):
    monkeypatch.setattr(crime_router.justice_service, "issue_warrant", AsyncMock(return_value=(False, "Mandat déjà actif.")))
    with pytest.raises(HTTPException) as exc:
        await crime_router.judge_issue_warrant(
            crime_router.WarrantIn(suspect_id=-42, reason="Récidive"), user_id=999
        )
    assert exc.value.status_code == 422
