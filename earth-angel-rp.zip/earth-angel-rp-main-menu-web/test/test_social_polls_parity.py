import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

import pytest_asyncio
import pytest

import database
import migrations
from database import db_connection, now
from gameplay.social_polls import PollError, close_poll, create_poll, polls_for_user, vote_poll
from webapp.routers.reseau_router import PollCreateIn, PollVoteIn, poll_create, poll_vote

A, B, OUTSIDER = 2101, 2102, 2103


@pytest_asyncio.fixture
async def poll_db(monkeypatch, tmp_path):
    path = str(tmp_path / "social-polls.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    for uid in (A, B, OUTSIDER):
        await database.get_user(uid, f"p{uid}", f"Poll {uid}")
        await database.update_field(uid, "registered", 1)
    yield
    await database._DB_POOL.close()


async def _make_community():
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO social_communities(name,owner_id,created_at) VALUES ('Les Anges',?,?)",
            (A, now()),
        )
        await db.execute(
            "INSERT INTO social_community_members(community_id,user_id,role,joined_at) VALUES (1,?,'owner',?)",
            (A, now()),
        )
        await db.execute(
            "INSERT INTO social_community_members(community_id,user_id,role,joined_at) VALUES (1,?,'member',?)",
            (B, now()),
        )
        await db.commit()


async def test_poll_api_and_service_share_vote_quota_and_reward(poll_db):
    created = await poll_create(PollCreateIn(question="  Quelle activité ?  ", options=["Sortir", "Rester"]), A)
    assert created["community_id"] == 0
    assert "tous les joueurs" in created["message"]

    ballot = await poll_vote(PollVoteIn(poll_id=created["poll_id"], option_index=1), B)
    assert ballot["social_coins_earned"] == 1
    assert (await database.get_user(B))["social_coins"] == 101
    with pytest.raises(PollError, match="déjà voté"):
        await vote_poll(created["poll_id"], B, 0)
    assert (await database.get_user(B))["social_coins"] == 101

    listing = await polls_for_user(B)
    poll = next(p for p in listing["polls"] if p["poll_id"] == created["poll_id"])
    assert poll["question"] == "Quelle activité ?"
    assert poll["my_vote"] == 1
    assert poll["counts"] == [0, 1]


async def test_community_scope_membership_and_authorized_close(poll_db):
    await _make_community()
    created = await create_poll(A, "Quelle couleur ?", ["Bleu", "Or"])
    assert created["community_id"] == 1
    assert created["community_name"] == "Les Anges"

    owner_view = await polls_for_user(A)
    member_view = await polls_for_user(B)
    outsider_view = await polls_for_user(OUTSIDER)
    assert any(p["poll_id"] == created["poll_id"] for p in owner_view["polls"])
    assert any(p["poll_id"] == created["poll_id"] for p in member_view["polls"])
    assert not any(p["poll_id"] == created["poll_id"] for p in outsider_view["polls"])

    with pytest.raises(PollError, match="réservé aux membres"):
        await vote_poll(created["poll_id"], OUTSIDER, 0)
    result = await vote_poll(created["poll_id"], B, 0)
    assert result["social_coins_earned"] == 1
    with pytest.raises(PollError, match="auteur ou le staff"):
        await close_poll(created["poll_id"], B)
    await close_poll(created["poll_id"], A)
    assert await database.get_user(B)  # le membre reste un compte joueur valide


async def test_three_polls_per_game_day_and_option_validation(poll_db):
    for index in range(3):
        await create_poll(A, f"Question {index}", ["Oui", "Non"])
    with pytest.raises(PollError, match="Maximum 3 sondages"):
        await create_poll(A, "Question 4", ["Oui", "Non"])
    with pytest.raises(PollError, match="au moins 2 options"):
        await create_poll(B, "Question invalide", ["Oui"])
    with pytest.raises(PollError, match="n’existe pas"):
        await vote_poll(1, B, 99)


async def test_concurrent_vote_only_credits_one_social_coin(poll_db):
    created = await create_poll(A, "Un seul vote ?", ["Oui", "Non"])
    results = await __import__("asyncio").gather(
        vote_poll(created["poll_id"], B, 0),
        vote_poll(created["poll_id"], B, 1),
        return_exceptions=True,
    )
    assert sum(not isinstance(result, Exception) for result in results) == 1
    assert (await database.get_user(B))["social_coins"] == 101
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM social_poll_votes WHERE poll_id=?", (created["poll_id"],)) as cur:
            assert (await cur.fetchone())[0] == 1
