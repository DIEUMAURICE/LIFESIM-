import pytest
import pytest_asyncio

import database
import migrations
from gameplay.market import add_item, buy_listing, cancel_listing, create_listing, use_item


@pytest_asyncio.fixture
async def market_db(monkeypatch, tmp_path):
    path = str(tmp_path / "market.db")
    pool = database.SQLiteConnectionPool(path, size=8)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()
    for uid, job in ((1, "Commerçant"), (2, "")):
        await database.get_user(uid, f"u{uid}", f"Player {uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "job", job)
        await database.update_field(uid, "balance", 10_000)
    async with database.db_connection() as db:
        await db.execute(
            "INSERT INTO items(item_id,name,type,rarity,value,emoji,effect_type,effect_value,description) "
            "VALUES (9001,'Potion test','consumable','common',0,'🧪','heal',20,'')"
        )
        await db.commit()
    yield


@pytest.mark.asyncio
async def test_market_mutations_share_one_atomic_service(market_db):
    await add_item(1, 9001, 3, "seed")
    listing = await create_listing(1, 9001, 100, 2)
    assert listing["unit_price"] == 100
    bought = await buy_listing(2, listing["listing_id"], 1)
    assert bought["quantity"] == 1 and bought["total"] == 100
    assert (await database.get_user(1))["balance"] == 10_100
    assert (await database.get_user(2))["balance"] == 9_900

    returned = await cancel_listing(1, listing["listing_id"])
    assert returned["quantity_returned"] == 1


@pytest.mark.asyncio
async def test_consumption_updates_effect_and_inventory_once(market_db):
    await add_item(2, 9001, 2, "reward")
    await database.update_field(2, "health", 50)
    result = await use_item(2, 9001, 1)
    assert result["quantity_used"] == 1
    assert result["remaining"] == 1
    assert result["effect"]["health_after"] == 70
    async with database.db_connection() as db:
        async with db.execute("SELECT quantity FROM inventory WHERE user_id=2 AND item_id=9001") as cur:
            assert (await cur.fetchone())[0] == 1
