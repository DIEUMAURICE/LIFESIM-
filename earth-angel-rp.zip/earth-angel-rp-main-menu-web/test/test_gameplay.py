# test/test_gameplay.py — gameplay RP : petits métiers, production, repas, marché des commerçants,
# gangs, loterie, logement obligatoire (une base SQLite temporaire par test)
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

import pytest
import pytest_asyncio

import database
import migrations
import handlers.realestate as housing
import utils.factions as factions
import utils.payroll as prod
from config import (
    MEAL_BITES_BASE,
    GANG_CRIME_CUT, GANG_PAYOUT_RATIO, GANG_ROLE_WEIGHT, HOUSING_EVICT_AFTER, HOUSING_NPC,
    LOTTERY_JACKPOT_BASE, LOTTERY_MAX_TICKETS, LOTTERY_TICKET_COST, MEALS, MEAL_CATEGORIES,
    MEAL_LEGACY, PROPERTIES, PRODUCTION_LEVELS, SECTOR_PRODUCTION, SECTORS, SMALL_JOBS, WORK_COOLDOWN,
)
from handlers import economy as lottery
from handlers import gangs
from handlers import life as meals
from handlers import market as merchants
from utils.cooldowns import claim_cooldown


async def _boot(monkeypatch, tmp_path):
    """Base SQLite temporaire, schéma et migrations à jour."""
    path = str(tmp_path / "t.db")
    pool = database.SQLiteConnectionPool(path, size=5)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()


# ── Petits métiers : cumul, cooldowns, migration ──
SJ_UID = 301


@pytest_asyncio.fixture
async def jobs_db(monkeypatch, tmp_path):
    await _boot(monkeypatch, tmp_path)
    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title, message))

    monkeypatch.setattr(factions, "notify", fake_notify)
    for uid in (SJ_UID, SJ_UID + 1, SJ_UID + 2, SJ_UID + 3):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
    yield sent


@pytest.mark.asyncio
async def test_cumul_cooldowns_independants(jobs_db):
    ok1, _ = await claim_cooldown(SJ_UID, "work_last", WORK_COOLDOWN)
    ok2, _ = await claim_cooldown(SJ_UID, "freelance_last", WORK_COOLDOWN)
    assert ok1 and ok2                                   # le poste n'empêche pas le petit métier
    again, remaining = await claim_cooldown(SJ_UID, "freelance_last", WORK_COOLDOWN)
    assert not again and remaining > 0                   # mais chaque voie garde son repos de 4 h


@pytest.mark.asyncio
async def test_migration_anciens_metiers(jobs_db):
    await database.update_field(SJ_UID, "job", "Médecin")          # qualifié → entreprise/faction
    await database.update_field(SJ_UID + 1, "job", "Développeur")  # renommé
    await database.update_field(SJ_UID + 2, "job", "Livreur")      # petit métier conservé
    assert await factions.migrate_legacy_jobs() == 2
    assert (await database.get_user(SJ_UID))["job"] == ""
    assert (await database.get_user(SJ_UID + 1))["job"] == "Dev freelance"
    assert (await database.get_user(SJ_UID + 2))["job"] == "Livreur"
    assert {n[0] for n in jobs_db} == {SJ_UID, SJ_UID + 1}            # les concernés sont notifiés
    assert await factions.migrate_legacy_jobs() == 0            # idempotent


def test_catalogue_petits_metiers_coherent():
    from utils.minigames import STARTERS
    for name, data in SMALL_JOBS.items():
        assert data["category"] in STARTERS, name               # chaque métier a son mini-jeu
        assert data["min"] <= data["max"], name
    qualifies = {n for n, d in SMALL_JOBS.items() if d["need"]}
    assert {"Comptable", "Dev freelance", "Infirmier"} <= qualifies   # le diplôme reste exigé


# ── Production des entreprises ──
CP_OWNER, CP_EMP = 401, 402
CP_DAY = 10


@pytest_asyncio.fixture
async def prod_db(monkeypatch, tmp_path):
    await _boot(monkeypatch, tmp_path)
    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title))

    monkeypatch.setattr(prod, "notify", fake_notify)
    for uid in (CP_OWNER, CP_EMP):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
    async with database.db_connection() as db:
        await db.execute(
            "INSERT INTO companies(name, owner_id, sector, treasury, created_at) "
            "VALUES ('Test SA', ?, 'Commerce', 100000, 0)", (CP_OWNER,))
        await db.execute(
            "INSERT INTO company_members(user_id, company_id, poste, base_salary, role) "
            "VALUES (?,1,'PDG',0,'owner')", (CP_OWNER,))
        await db.commit()
    yield sent


async def _treasury():
    async with database.db_connection() as db:
        async with db.execute("SELECT treasury FROM companies WHERE company_id=1") as c:
            return (await c.fetchone())[0]


def test_tous_les_secteurs_ont_un_produit_rentable():
    import config_chain as cc
    assert set(SECTORS) <= set(SECTOR_PRODUCTION) and "Éducation" not in SECTORS
    for name, c in SECTOR_PRODUCTION.items():
        assert c["npc_price"] > c["unit_cost"], name       # jamais vendu à perte
    assert set(PRODUCTION_LEVELS) == {1, 2, 3}
    assert cc.validate() == []


async def _team_points(pts):
    """Activité de toutes les équipes du secteur Commerce (suffisante pour une journée pleine)."""
    import config_chain as cc
    for dept in cc.sector_depts("Commerce"):
        await prod.record_activity(1, pts, CP_DAY, dept=dept)


@pytest.mark.asyncio
async def test_production_vend_et_notifie(prod_db):
    await _team_points(200)
    r = await prod.produce_company(1, CP_DAY)
    assert r["produced"] > 0 and r["sold"] > 0
    assert r["revenue"] > r["cost"] > 0                       # intrants du fournisseur national : reste rentable
    assert await _treasury() == 100000 - r["cost"] + r["revenue"]
    assert [n for n in prod_db if n[0] == CP_OWNER]           # le créateur reçoit le bilan


@pytest.mark.asyncio
async def test_idempotent_et_plafond_journalier(prod_db):
    await _team_points(500)
    r1 = await prod.produce_company(1, CP_DAY)
    assert r1["produced"] > 0
    before = await _treasury()
    r2 = await prod.produce_company(1, CP_DAY)                # relance le même jour : plafond atteint
    assert r2["produced"] == 0 and r2["sold"] == 0
    assert await _treasury() == before
    await prod.record_activity(1, 500, CP_DAY + 1)            # le lendemain, la production repart
    await _team_points(500)
    assert (await prod.produce_company(1, CP_DAY + 1))["produced"] > 0


@pytest.mark.asyncio
async def test_tresorerie_insuffisante_bloque_la_production(prod_db):
    async with database.db_connection() as db:
        await db.execute("UPDATE companies SET treasury=500 WHERE company_id=1")
        await db.commit()
    await _team_points(500)
    r = await prod.produce_company(1, CP_DAY)
    assert r["blocked"] > 0 and r["status"] == "blocked"


@pytest.mark.asyncio
async def test_sans_equipe_rien_ne_se_produit(prod_db):
    r = await prod.produce_company(1, CP_DAY)
    assert r["produced"] == 0
    assert await prod.set_level(1, 3) and await prod.get_level(1) == 3
    assert not await prod.set_level(1, 9)


# ── Repas par catégorie et étoiles ──
ML_UID = 501


@pytest_asyncio.fixture
async def meal_db(monkeypatch, tmp_path):
    await _boot(monkeypatch, tmp_path)
    await database.get_user(ML_UID, "u", "User")
    await database.update_field(ML_UID, "registered", 1)
    await database.update_field(ML_UID, "balance", 1_000_000)
    await database.update_field(ML_UID, "hunger", 40)
    yield


def test_catalogue_coherent():
    for key, m in MEALS.items():
        assert m["cat"] in MEAL_CATEGORIES, key
        assert 1 <= m["stars"] <= 5 and m["cost"] > 0 and m["hunger"] > 0, key
    for cat in MEAL_CATEGORIES:
        assert any(m["cat"] == cat for m in MEALS.values()), cat      # aucune catégorie vide
    assert all(v in MEALS for v in MEAL_LEGACY.values())


@pytest.mark.asyncio
async def test_manger_applique_les_effets(meal_db):
    ok, _ = await meals.eat_meal(ML_UID, "burger")
    u = await database.get_user(ML_UID)
    assert ok and u["hunger"] == 40 + MEALS["burger"]["hunger"]
    assert u["balance"] == 1_000_000 - MEALS["burger"]["cost"]


@pytest.mark.asyncio
async def test_ancienne_cle_et_refus(meal_db):
    ok, _ = await meals.eat_meal(ML_UID, "snack")                          # ancienne clé → sandwich
    assert ok
    await database.update_field(ML_UID, "hunger", 98)
    ok, txt = await meals.eat_meal(ML_UID, "etoile")
    assert not ok and "pas faim" in txt                                  # rassasié : rien n'est débité
    assert (await database.get_user(ML_UID))["balance"] == 1_000_000 - MEALS["sandwich"]["cost"]
    await database.update_field(ML_UID, "hunger", 10)
    await database.update_field(ML_UID, "balance", 100)
    ok, txt = await meals.eat_meal(ML_UID, "gastro")
    assert not ok and "insuffisants" in txt


# ── Marché des commerçants ──
MR_SELLER, MR_MERCH = 601, 602
MR_ITEM = 9001


@pytest_asyncio.fixture
async def mdb(monkeypatch, tmp_path):
    await _boot(monkeypatch, tmp_path)
    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title))

    monkeypatch.setattr(merchants, "notify", fake_notify)
    for uid in (MR_SELLER, MR_MERCH):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 10_000)
    await database.update_field(MR_MERCH, "job", "Commerçant")
    async with database.db_connection() as db:
        await db.execute("INSERT INTO items (item_id, name, type, rarity, value, emoji, description) "
                         "VALUES (?, 'Lingot', 'misc', 'common', 0, '🪙', '')", (MR_ITEM,))
        # objet sous séquestre : déjà retiré de l'inventaire du vendeur
        await db.execute("INSERT INTO merchant_offers(seller_id,merchant_id,item_id,quantity,unit_price,status,"
                         "created_at,expires_at) VALUES (?,?,?,2,1000,'pending',0,?)",
                         (MR_SELLER, MR_MERCH, MR_ITEM, 4_000_000_000))
        await db.execute("INSERT INTO merchant_offers(seller_id,merchant_id,item_id,quantity,unit_price,status,"
                         "created_at,expires_at) VALUES (?,?,?,1,500,'pending',0,1)", (MR_SELLER, MR_MERCH, MR_ITEM))
        await db.commit()
    yield sent


async def _qty(uid):
    async with database.db_connection() as db:
        async with db.execute("SELECT COALESCE(SUM(quantity),0) FROM inventory WHERE user_id=? AND item_id=?",
                              (uid, MR_ITEM)) as c:
            return (await c.fetchone())[0]


@pytest.mark.asyncio
async def test_seuls_les_commercants_vendent_au_marche(mdb):
    assert await merchants.can_sell_on_market(MR_MERCH)
    assert not await merchants.can_sell_on_market(MR_SELLER)


@pytest.mark.asyncio
async def test_acceptation_transfere_objet_et_argent(mdb):
    ok, _ = await merchants.resolve_offer(1, MR_MERCH, accept=True)
    assert ok
    assert await _qty(MR_MERCH) == 2
    assert (await database.get_user(MR_MERCH))["balance"] == 8_000
    assert (await database.get_user(MR_SELLER))["balance"] == 12_000
    again, _ = await merchants.resolve_offer(1, MR_MERCH, accept=True)
    assert not again                                          # jamais payée deux fois
    assert MR_SELLER in {n[0] for n in mdb}                      # le vendeur est notifié


@pytest.mark.asyncio
async def test_refus_et_mauvais_commercant(mdb):
    wrong, _ = await merchants.resolve_offer(1, MR_SELLER, accept=True)
    assert not wrong                                          # seul le commerçant visé peut répondre
    ok, _ = await merchants.resolve_offer(1, MR_MERCH, accept=False)
    assert ok and await _qty(MR_SELLER) == 2                     # l'objet revient au vendeur


@pytest.mark.asyncio
async def test_expiration_rend_l_objet(mdb):
    await merchants.expire_merchant_offers()
    assert await _qty(MR_SELLER) == 1                            # seule l'offre #2 (déjà expirée) est rendue
    late, _ = await merchants.resolve_offer(2, MR_MERCH, accept=True)
    assert not late


@pytest.mark.asyncio
async def test_fonds_insuffisants(mdb):
    await database.update_field(MR_MERCH, "balance", 100)
    ok, msg = await merchants.resolve_offer(1, MR_MERCH, accept=True)
    assert not ok and "insuffisants" in msg
    assert await _qty(MR_MERCH) == 0 and (await database.get_user(MR_SELLER))["balance"] == 10_000


# ── Gangs ──
GG_CHEF, GG_SOLDAT, GG_RECRUE, GG_CIVIL = 701, 702, 703, 704


@pytest_asyncio.fixture
async def gdb(monkeypatch, tmp_path):
    await _boot(monkeypatch, tmp_path)
    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title))

    monkeypatch.setattr(gangs, "notify", fake_notify)
    for uid in (GG_CHEF, GG_SOLDAT, GG_RECRUE, GG_CIVIL):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 0)
    async with database.db_connection() as db:
        await db.execute("INSERT INTO gangs(name, founder_id, treasury, reputation, created_at) "
                         "VALUES ('Corbeaux', ?, 100000, 0, 0)", (GG_CHEF,))
        for uid, role in ((GG_CHEF, "Chef"), (GG_SOLDAT, "Soldat"), (GG_RECRUE, "Recrue")):
            await db.execute("INSERT INTO gang_members(gang_id, user_id, role, joined_at) VALUES (1,?,?,0)",
                             (uid, role))
        await db.execute("INSERT INTO gang_applications(gang_id, user_id, status, created_at) "
                         "VALUES (1,?,'pending',0)", (GG_CIVIL,))
        await db.commit()
    yield sent


async def _bal(uid):
    return (await database.get_user(uid))["balance"]


@pytest.mark.asyncio
async def test_partage_selon_la_hierarchie_et_idempotent(gdb):
    r = await gangs.payout_gang(1, day=50)
    pool = int(100_000 * GANG_PAYOUT_RATIO)
    total_w = GANG_ROLE_WEIGHT["Chef"] + GANG_ROLE_WEIGHT["Soldat"] + GANG_ROLE_WEIGHT["Recrue"]
    assert r["status"] == "paid"
    assert await _bal(GG_CHEF) == pool * GANG_ROLE_WEIGHT["Chef"] // total_w
    assert await _bal(GG_CHEF) > await _bal(GG_SOLDAT) > await _bal(GG_RECRUE) > 0
    assert await _bal(GG_CIVIL) == 0                              # hors gang : rien
    assert {n[0] for n in gdb} == {GG_CHEF, GG_SOLDAT, GG_RECRUE}       # chaque membre est notifié
    again = await gangs.payout_gang(1, day=50)
    assert again["status"] == "none"                           # jamais deux fois le même jour
    nxt = await gangs.payout_gang(1, day=51)
    assert nxt["status"] == "paid"                             # le lendemain, nouveau partage


@pytest.mark.asyncio
async def test_pas_de_crime_sans_gang_et_part_du_butin(gdb):
    assert await gangs.require_gang(GG_SOLDAT)
    assert not await gangs.require_gang(GG_CIVIL)
    net = await gangs.split_crime_reward(GG_SOLDAT, 10_000)
    assert net == 10_000 - int(10_000 * GANG_CRIME_CUT)
    async with database.db_connection() as db:
        async with db.execute("SELECT treasury FROM gangs WHERE gang_id=1") as c:
            assert (await c.fetchone())[0] == 100_000 + int(10_000 * GANG_CRIME_CUT)


@pytest.mark.asyncio
async def test_candidature_acceptee_par_l_encadrement_seulement(gdb):
    refused, _ = await gangs.decide_application(1, GG_SOLDAT, accept=True)
    assert not refused                                         # un soldat ne recrute pas
    ok, _ = await gangs.decide_application(1, GG_CHEF, accept=True)
    assert ok and (await gangs.get_gang_membership(GG_CIVIL))["role"] == "Recrue"
    assert GG_CIVIL in {n[0] for n in gdb}                        # le candidat est notifié
    again, _ = await gangs.decide_application(1, GG_CHEF, accept=True)
    assert not again


# ── Loterie ──
LT_A, LT_B, LT_C = 801, 802, 803


@pytest_asyncio.fixture
async def ldb(monkeypatch, tmp_path):
    await _boot(monkeypatch, tmp_path)
    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title))

    async def fake_xp(*a, **k):
        return 0

    monkeypatch.setattr(lottery, "notify", fake_notify)
    import utils.vip
    monkeypatch.setattr(utils.vip, "add_xp", fake_xp)
    for uid in (LT_A, LT_B, LT_C):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 1_000_000)
    yield sent


async def _count():
    async with database.db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM lottery_tickets") as c:
            return (await c.fetchone())[0]


@pytest.mark.asyncio
async def test_achat_debite_et_plafonne(ldb):
    for _ in range(LOTTERY_MAX_TICKETS):
        ok, _ = await lottery.buy_ticket(LT_A)
        assert ok
    ok, msg = await lottery.buy_ticket(LT_A)
    assert not ok and "Maximum" in msg
    assert (await database.get_user(LT_A))["balance"] == 1_000_000 - LOTTERY_MAX_TICKETS * LOTTERY_TICKET_COST
    await database.update_field(LT_B, "balance", 10)
    ok, msg = await lottery.buy_ticket(LT_B)
    assert not ok and "insuffisants" in msg


@pytest.mark.asyncio
async def test_tirage_notifie_tout_le_monde_et_supprime_les_tickets(ldb):
    for uid in (LT_A, LT_B, LT_C):
        await lottery.buy_ticket(uid)
    r = await lottery.process_lottery_draw()
    assert r["status"] == "drawn" and r["winner"] in (LT_A, LT_B, LT_C)
    assert r["prize"] == LOTTERY_JACKPOT_BASE + 3 * (LOTTERY_TICKET_COST // 2)
    assert {n[0] for n in ldb} == {LT_A, LT_B, LT_C}                    # gagnant ET perdants sont notifiés
    assert await _count() == 0                                 # tickets payés supprimés
    winner = await database.get_user(r["winner"])
    assert winner["balance"] == 1_000_000 - LOTTERY_TICKET_COST + r["prize"]
    again = await lottery.process_lottery_draw()
    assert again["status"] == "none"                           # pas de double paiement


@pytest.mark.asyncio
async def test_un_seul_joueur_report_du_tirage(ldb):
    await lottery.buy_ticket(LT_A)
    await lottery.buy_ticket(LT_A)
    r = await lottery.process_lottery_draw()
    assert r["status"] == "postponed" and await _count() == 2   # tickets conservés
    assert (await database.get_user(LT_A))["balance"] == 1_000_000 - 2 * LOTTERY_TICKET_COST


# ── Logement obligatoire ──
HS_OWNER, HS_TENANT, HS_NPC_USER, HS_HOMELESS = 901, 902, 903, 904


@pytest_asyncio.fixture
async def hdb(monkeypatch, tmp_path):
    await _boot(monkeypatch, tmp_path)
    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, message))

    monkeypatch.setattr(housing, "notify", fake_notify)
    for uid in (HS_OWNER, HS_TENANT, HS_NPC_USER, HS_HOMELESS):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 100_000)
    async with database.db_connection() as db:
        # HS_OWNER possède un Studio (pas loué) + un Appartement loué à HS_TENANT
        await db.execute("INSERT INTO properties(user_id, prop_type, purchased_at, condition, rented_to) "
                         "VALUES (?, 'Studio', 0, 100, 0)", (HS_OWNER,))
        await db.execute("INSERT INTO properties(user_id, prop_type, purchased_at, condition, rented_to) "
                         "VALUES (?, 'Appartement', 0, 100, ?)", (HS_OWNER, HS_TENANT))
        await db.execute("INSERT INTO rental_agreements(property_id, owner_id, tenant_id, rent, start_date, status) "
                         "VALUES (2, ?, ?, 3000, 0, 'active')", (HS_OWNER, HS_TENANT))
        await db.execute("INSERT INTO housing_npc(user_id, name, daily_cost, since) VALUES (?, 'Foyer', ?, 0)",
                         (HS_NPC_USER, HOUSING_NPC["Foyer"]["daily"]))
        await db.commit()
    yield sent


async def _bal(uid):
    return (await database.get_user(uid))["balance"]


@pytest.mark.asyncio
async def test_residence_par_priorite(hdb):
    assert (await housing.get_residence(HS_OWNER))["kind"] == "owned"
    assert (await housing.get_residence(HS_TENANT))["kind"] == "rented"
    assert (await housing.get_residence(HS_NPC_USER))["kind"] == "npc"
    assert await housing.get_residence(HS_HOMELESS) is None                # sans domicile


@pytest.mark.asyncio
async def test_frais_preleves_et_toujours_notifies(hdb):
    stats = await housing.run_housing_charges(day=100)
    rent = 3000 // 30
    assert stats["paid"] >= 3 and stats["unpaid"] == 0
    assert await _bal(HS_TENANT) == 100_000 - rent                          # loyer prélevé
    owner_expected = (100_000 + rent
                      - PROPERTIES["Studio"]["maint"] // 30             # charges de son logement
                      - PROPERTIES["Appartement"]["maint"] // 30)       # charges du bien loué
    assert await _bal(HS_OWNER) == owner_expected
    assert await _bal(HS_NPC_USER) == 100_000 - HOUSING_NPC["Foyer"]["daily"]
    assert await _bal(HS_HOMELESS) == 100_000                               # rien à payer
    assert {n[0] for n in hdb} == {HS_OWNER, HS_TENANT, HS_NPC_USER}              # chacun reçoit son récapitulatif
    again = await housing.run_housing_charges(day=100)
    assert again["paid"] == 0 and await _bal(HS_TENANT) == 100_000 - rent   # jamais deux fois le même jour


@pytest.mark.asyncio
async def test_impayes_puis_expulsion(hdb):
    await database.update_field(HS_TENANT, "balance", 0)
    await database.update_field(HS_NPC_USER, "balance", 0)
    for d in range(HOUSING_EVICT_AFTER):
        stats = await housing.run_housing_charges(day=200 + d)
    assert stats["evicted"] >= 2
    assert await housing.get_residence(HS_TENANT) is None                   # location terminée
    assert await housing.get_residence(HS_NPC_USER) is None                 # chambre PNJ perdue
    async with database.db_connection() as db:
        async with db.execute("SELECT rented_to FROM properties WHERE prop_id=2") as c:
            assert (await c.fetchone())[0] == 0                          # le bien est de nouveau libre
    assert any("Expulsé" in n[1] or "expulsé" in n[1] for n in hdb)


class _FakeQuery:
    def __init__(self):
        self.texts = []

    async def edit_message_text(self, text, **kw):
        self.texts.append(text)


@pytest.mark.asyncio
async def test_trajet_restaurant_sans_mini_jeu_chronometre(meal_db):
    """Aller manger = trajet chronométré (comme /aller) : aucun mini-jeu, seul le temps d'arrivée compte."""
    from utils import minigames
    async with database.db_connection() as db:
        await db.execute("INSERT OR IGNORE INTO user_position(user_id, location) VALUES (?, 'maison')", (ML_UID,))
        await db.commit()
    await database.update_field(ML_UID, "energy", 80)
    q = _FakeQuery()
    await meals._go_and_eat(q, ML_UID, "burger", "walk")
    assert minigames.get_state(ML_UID) is None                         # aucun mini-jeu lancé pour le trajet
    from utils.location import get_position
    pos = await get_position(ML_UID)
    assert pos["in_transit"] and pos["travel_to"] == "restaurant" and pos["remaining"] > 0
    assert (await database.get_user(ML_UID))["energy"] < 80            # la marche fatigue, sans score


@pytest.mark.asyncio
async def test_manger_mini_jeu_appuyer_sur_le_plat(meal_db):
    """Au restaurant : le plat est payé une fois, on appuie dessus bouchée par bouchée jusqu'à le finir."""
    async with database.db_connection() as db:
        await db.execute("INSERT OR IGNORE INTO user_position(user_id, location) VALUES (?, 'restaurant')", (ML_UID,))
        await db.execute("UPDATE user_position SET location='restaurant' WHERE user_id=?", (ML_UID,))
        await db.commit()
    await database.update_field(ML_UID, "hunger", 20)
    q = _FakeQuery()
    await meals.meals_callback(q, ML_UID, "manger_eat_burger")
    bites = MEAL_BITES_BASE + MEALS["burger"]["stars"]
    assert ML_UID in meals._EATING and meals._EATING[ML_UID]["left"] == bites
    assert (await database.get_user(ML_UID))["balance"] == 1_000_000 - MEALS["burger"]["cost"]
    for _ in range(bites - 1):
        await meals.meals_callback(q, ML_UID, "manger_bite_burger")
    assert (await database.get_user(ML_UID))["hunger"] == 20             # pas fini : aucun effet
    await meals.meals_callback(q, ML_UID, "manger_bite_burger")          # dernière bouchée
    assert ML_UID not in meals._EATING
    assert (await database.get_user(ML_UID))["hunger"] == 20 + MEALS["burger"]["hunger"]
    await meals.meals_callback(q, ML_UID, "manger_bite_burger")          # clic en trop : rien de plus
    assert (await database.get_user(ML_UID))["hunger"] == 20 + MEALS["burger"]["hunger"]
    assert (await database.get_user(ML_UID))["balance"] == 1_000_000 - MEALS["burger"]["cost"]


@pytest.mark.asyncio
async def test_repas_effets_selon_le_score_du_mini_jeu(meal_db):
    await database.update_field(ML_UID, "hunger", 20)
    ok, err = await meals.pay_meal(ML_UID, "burger")                 # paiement automatique
    assert ok and (await database.get_user(ML_UID))["balance"] == 1_000_000 - MEALS["burger"]["cost"]
    await meals.apply_meal(ML_UID, "burger", 0)                      # repas bâclé : moitié de la faim restaurée
    assert (await database.get_user(ML_UID))["hunger"] == 20 + round(MEALS["burger"]["hunger"] * 0.5)
    await database.update_field(ML_UID, "hunger", 20)
    await meals.apply_meal(ML_UID, "burger", 3)                      # un régal : +25 %
    assert (await database.get_user(ML_UID))["hunger"] == 20 + round(MEALS["burger"]["hunger"] * 1.25)
    await database.update_field(ML_UID, "balance", 10)
    ok, err = await meals.pay_meal(ML_UID, "gastro")
    assert not ok and "insuffisants" in err                          # pas de repas sans argent, rien n'est débité


@pytest.mark.asyncio
async def test_schema_repare_une_base_en_avance_sur_son_schema(monkeypatch, tmp_path):
    """user_version avancé mais table user_position absente : le démarrage recrée la table."""
    await _boot(monkeypatch, tmp_path)
    async with database.db_connection() as db:
        await db.execute("DROP TABLE user_position")
        await db.commit()
    await migrations.run_migrations()
    async with database.db_connection() as db:
        async with db.execute("SELECT name FROM sqlite_master WHERE name='user_position'") as c:
            assert await c.fetchone() is not None


@pytest.mark.asyncio
async def test_trajets_courts_et_taxi(monkeypatch, tmp_path):
    """Les trajets sont en temps de JEU, bornés ; les véhicules vont plus vite ; le taxi est payant et rapide."""
    import utils.location as loc
    from config import TRAVEL_MAX_SECONDS, TRAVEL_MIN_SECONDS, TAXI_BASE_FARE, TAXI_FARE_PER_KM
    await _boot(monkeypatch, tmp_path)
    await database.get_user(7001, "t", "Taxi")
    await database.update_field(7001, "registered", 1)
    await database.update_field(7001, "balance", 50_000)
    await database.update_field(7001, "energy", 100)
    for dest in ("casino", "banque", "aeroport", "quartier_sud"):
        for o in await loc.plan_options(7001, "maison", dest):
            assert TRAVEL_MIN_SECONDS <= o["duration"] <= TRAVEL_MAX_SECONDS, (dest, o["mode"], o["duration"])
    opts = {o["mode"]: o for o in await loc.plan_options(7001, "maison", "aeroport")}   # 14 km
    assert opts["taxi"]["duration"] < opts["walk"]["duration"] == TRAVEL_MAX_SECONDS
    assert opts["taxi"]["money"] == TAXI_BASE_FARE + 14 * TAXI_FARE_PER_KM
    ok, msg = await loc.start_travel(7001, "aeroport", "taxi")
    assert ok and (await database.get_user(7001))["balance"] == 50_000 - opts["taxi"]["money"]
    assert (await database.get_user(7001))["energy"] == 100                              # le taxi ne fatigue pas
    await database.update_field(7001, "balance", 10)
    broke = {o["mode"]: o for o in await loc.plan_options(7001, "aeroport", "maison")}
    assert not broke["taxi"]["ok"]                                                       # pas assez d'argent
