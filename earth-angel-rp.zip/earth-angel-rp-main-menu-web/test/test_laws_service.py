# test/test_laws_service.py — Lois, référendums, constitution : service partagé bot/API + routes
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from fastapi import HTTPException

import database
import migrations
import utils.roles as roles
from config import LAW_PROPOSAL_COST, REFERENDUM_COST
from gameplay import laws as svc
from webapp.routers import political_router as router

PRES, GL, P1, P2, P3, P4 = 901, 902, 903, 904, 905, 906
ROLES = {GL: "GAME_LEADER"}


@pytest_asyncio.fixture
async def ldb(monkeypatch, tmp_path):
    path = str(tmp_path / "laws.db")
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", database.SQLiteConnectionPool(path, size=5))
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()

    async def role_of(uid):
        return ROLES.get(uid, "PLAYER")

    monkeypatch.setattr(roles, "role_of", role_of)
    monkeypatch.setattr(svc, "is_president", AsyncMock(side_effect=lambda uid: uid == PRES))
    monkeypatch.setattr(svc, "minister_of", AsyncMock(return_value=None))
    for uid in (PRES, GL, P1, P2, P3, P4):
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 1_000_000)
    yield


async def _one(sql, *params):
    async with database.db_connection() as db:
        async with db.execute(sql, params) as cur:
            return await cur.fetchone()


async def test_propose_law_charges_and_creates_together(ldb):
    result = await svc.propose_law(P1, "Taxe", "Une taxe", "tax", 5)
    assert result["ok"]
    assert (await _one("SELECT balance FROM users WHERE user_id=?", P1))[0] == 1_000_000 - LAW_PROPOSAL_COST
    row = await _one("SELECT title, status, effect_type, effect_value FROM laws WHERE id=?", result["id"])
    assert tuple(row) == ("Taxe", "voting", "tax", 5)


async def test_refusals_do_not_charge(ldb):
    await database.update_field(P2, "balance", 10)
    assert (await svc.propose_law(P2, "T", "D"))["reason"] == "insufficient_funds"
    assert (await svc.propose_law(P1, " ", "D"))["reason"] == "empty"
    assert (await svc.propose_referendum(P2, "Q ?"))["reason"] == "insufficient_funds"
    assert (await _one("SELECT balance FROM users WHERE user_id=?", P2))[0] == 10
    assert (await _one("SELECT COUNT(*) FROM laws"))[0] == 0 and (await _one("SELECT COUNT(*) FROM referendums"))[0] == 0


async def test_vote_law_counts_once(ldb):
    law = (await svc.propose_law(P1, "Loi", "Desc"))["id"]
    assert await svc.find_law("Loi") == law and await svc.find_law(f"#{law}") == law
    assert (await svc.vote_law(P2, law, 1))["ok"]
    assert (await svc.vote_law(P2, law, -1))["reason"] == "already_voted"
    assert (await svc.vote_law(P3, law, -1))["ok"]
    assert (await svc.vote_law(P3, 999, 1))["reason"] == "not_found"
    assert (await svc.vote_law(P4, law, 0))["reason"] == "bad_choice"
    assert tuple(await _one("SELECT votes_for, votes_against FROM laws WHERE id=?", law)) == (1, 1)
    assert (await svc.my_votes(P2))["laws"] == {law: 1}


async def test_vote_referendum_and_listing(ldb):
    ref = (await svc.propose_referendum(P1, "Question ?"))["id"]
    assert (await _one("SELECT balance FROM users WHERE user_id=?", P1))[0] == 1_000_000 - REFERENDUM_COST
    assert (await svc.vote_referendum(P2, ref, 1))["ok"]
    assert (await svc.vote_referendum(P2, ref, 1))["reason"] == "already_voted"
    listing = await svc.list_referendums()
    assert listing[0]["votes_for"] == 1 and listing[0]["question"] == "Question ?"


async def test_constitution_proposal_rules_and_enactment(ldb):
    assert (await svc.propose_constitution(P1, "Un texte assez long"))["reason"] == "not_government"
    assert (await svc.propose_constitution(PRES, "court"))["reason"] == "too_short"
    ref = (await svc.propose_constitution(PRES, "Nouvelle constitution complète"))["id"]
    row = await _one("SELECT required_majority, payload FROM referendums WHERE id=?", ref)
    assert tuple(row) == (0.6, "constitution:Nouvelle constitution complète")
    async with database.db_connection() as db:
        await db.execute("UPDATE referendums SET voting_ends_at=1, votes_for=7, votes_against=3 WHERE id=?", (ref,))
        await db.commit()
    await svc.close_expired()
    assert (await svc.get_constitution())["text"] == "Nouvelle constitution complète"


async def test_close_expired_applies_majority_and_minimum(ldb):
    async with database.db_connection() as db:
        for title, pour, contre in (("A", 2, 0), ("B", 5, 2), ("C", 2, 5)):
            await db.execute(
                "INSERT INTO laws(title, description, proposer_id, status, votes_for, votes_against, required_majority, "
                "created_at, voting_ends_at) VALUES (?, 'x', ?, 'voting', ?, ?, 0.5, 0, 1)", (title, P1, pour, contre))
        await db.commit()
    notes = await svc.close_expired()
    assert len(notes) == 3 and all(uid == P1 for uid, _ in notes)
    async with database.db_connection() as db:
        async with db.execute("SELECT title, status FROM laws") as cur:
            assert dict(await cur.fetchall()) == {"A": "rejected", "B": "passed", "C": "rejected"}
    assert await svc.close_expired() == []


def test_parse_choice():
    assert svc.parse_choice("Pour") == 1 and svc.parse_choice("contre") == -1 and svc.parse_choice("x") is None


async def test_router_guards_and_delegation(monkeypatch):
    monkeypatch.setattr(router, "can_play", AsyncMock(return_value=False))
    with pytest.raises(HTTPException) as exc:
        await router.propose_law(router.LawIn(title="t", description="d"), user_id=1)
    assert exc.value.status_code == 403
    monkeypatch.setattr(router, "can_play", AsyncMock(return_value=True))
    monkeypatch.setattr(router, "free_problem", AsyncMock(return_value=None))
    propose = AsyncMock(return_value={"ok": False, "reason": "insufficient_funds"})
    monkeypatch.setattr(router.laws_service, "propose_law", propose)
    with pytest.raises(HTTPException) as exc:
        await router.propose_law(router.LawIn(title="t", description="d"), user_id=1)
    assert exc.value.status_code == 422
    vote = AsyncMock(return_value={"ok": True})
    monkeypatch.setattr(router.laws_service, "vote_referendum", vote)
    assert (await router.vote_referendum(router.PollVoteIn(id=3, choice="contre"), user_id=1))["ok"]
    vote.assert_awaited_once_with(1, 3, -1)


async def test_constitution_route_releases_cooldown_on_refusal(monkeypatch):
    monkeypatch.setattr(router, "free_problem", AsyncMock(return_value=None))
    monkeypatch.setattr(router, "cooldown_problem", AsyncMock(return_value=(None, True)))
    release = AsyncMock()
    monkeypatch.setattr(router, "release_cooldown", release)
    monkeypatch.setattr(router.laws_service, "propose_constitution",
                        AsyncMock(return_value={"ok": False, "reason": "not_government"}))
    with pytest.raises(HTTPException) as exc:
        await router.propose_constitution(router.ConstitutionIn(text="x" * 20), user_id=1)
    assert exc.value.status_code == 403
    release.assert_awaited_once_with(1, "last_constitution")


def test_law_routes_registered():
    from webapp.server import app
    paths = {r.path for r in app.routes}
    assert {"/api/political/laws", "/api/political/laws/propose", "/api/political/laws/vote",
            "/api/political/referendums", "/api/political/referendums/propose",
            "/api/political/referendums/vote", "/api/political/constitution",
            "/api/political/constitution/propose"} <= paths
