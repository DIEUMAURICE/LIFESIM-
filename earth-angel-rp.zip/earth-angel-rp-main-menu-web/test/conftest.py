# test/conftest.py
import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock

import aiosqlite
import pytest
import pytest_asyncio

import database


@pytest_asyncio.fixture(autouse=True)
async def close_active_database_pool_after_test():
    """Évite que les workers aiosqlite gardent pytest vivant après le dernier test."""
    yield
    for pool in list(getattr(database, "_ALL_POOLS", [])):
        if hasattr(pool, "close"):
            await pool.close()


@pytest_asyncio.fixture
async def isolated_db(monkeypatch, tmp_path):
    path = str(tmp_path / "concurrency.db")

    # Le pool global a été construit lors de l'import de database.py.
    # Il faut donc le remplacer, pas seulement modifier DB_PATH.
    pool = database.SQLiteConnectionPool(path, size=20)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)

    async with aiosqlite.connect(path) as db:
        await db.execute("PRAGMA journal_mode=WAL")
        await db.execute("PRAGMA busy_timeout=60000")
        await db.executescript(
            """
            CREATE TABLE users (
                user_id INTEGER PRIMARY KEY,
                username TEXT DEFAULT '',
                full_name TEXT DEFAULT '',
                registered INTEGER DEFAULT 1,
                balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0),
                total_spent INTEGER NOT NULL DEFAULT 0,
                total_earned INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE bank_accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                bank_name TEXT NOT NULL,
                balance INTEGER NOT NULL DEFAULT 0 CHECK(balance >= 0),
                loan INTEGER NOT NULL DEFAULT 0,
                loan_due INTEGER NOT NULL DEFAULT 0,
                loan_penalty_applied INTEGER NOT NULL DEFAULT 0,
                opened_at INTEGER NOT NULL DEFAULT 0,
                last_interest INTEGER NOT NULL DEFAULT 0,
                UNIQUE(user_id, bank_name)
            );

            CREATE TABLE items (
                item_id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                emoji TEXT DEFAULT '📦',
                rarity TEXT DEFAULT 'common',
                type TEXT DEFAULT 'consumable',
                effect_type TEXT,
                effect_value INTEGER DEFAULT 0
            );

            CREATE TABLE inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                item_id INTEGER NOT NULL,
                item_type TEXT,
                item_name TEXT,
                quantity INTEGER NOT NULL DEFAULT 1 CHECK(quantity >= 0),
                acquired_at INTEGER NOT NULL DEFAULT 0,
                UNIQUE(user_id, item_id)
            );

            CREATE TABLE market_listings (
                listing_id INTEGER PRIMARY KEY AUTOINCREMENT,
                seller_id INTEGER NOT NULL,
                item_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL CHECK(quantity >= 0),
                price INTEGER NOT NULL CHECK(price > 0),
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'active'
            );

            CREATE TABLE company_products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                price INTEGER NOT NULL,
                sales INTEGER DEFAULT 0,
                revenue INTEGER DEFAULT 0
            );

            CREATE TABLE user_cooldowns (
                user_id INTEGER NOT NULL,
                cooldown_key TEXT NOT NULL,
                last_used INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(user_id, cooldown_key)
            );

            CREATE TABLE arena_matches (
                match_id TEXT PRIMARY KEY,
                challenger_id INTEGER NOT NULL,
                target_id INTEGER NOT NULL,
                game TEXT NOT NULL,
                bet INTEGER NOT NULL CHECK(bet > 0),
                pot INTEGER NOT NULL DEFAULT 0 CHECK(pot >= 0),
                status TEXT NOT NULL DEFAULT 'pending',
                challenger_choice TEXT DEFAULT '',
                target_choice TEXT DEFAULT '',
                winner_id INTEGER DEFAULT 0,
                created_at INTEGER NOT NULL,
                accepted_at INTEGER DEFAULT 0,
                expires_at INTEGER NOT NULL,
                settled_at INTEGER DEFAULT 0,
                result_text TEXT DEFAULT ''
            );
            """
        )
        await db.commit()

    yield path

    # Ferme les connexions rendues au pool.
    while not pool._queue.empty():
        connection = pool._queue.get_nowait()
        await connection.close()
        
        
@pytest_asyncio.fixture
async def db(isolated_db):
    """Alias de `isolated_db` : retourne une connexion ouverte à la base isolée.
    Permet aux tests écrits avec le fixture `db` de fonctionner."""
    conn = await aiosqlite.connect(isolated_db)
    try:
        yield conn
    finally:
        await conn.close()


async def insert_user(path: str, user_id: int, balance: int, name: str = "Test"):
    async with aiosqlite.connect(path) as db:
        await db.execute(
            "INSERT INTO users(user_id,username,full_name,balance) VALUES (?,?,?,?)",
            (user_id, f"user{user_id}", name, balance),
        )
        await db.commit()


async def fetch_one(path: str, sql: str, params=()):
    async with aiosqlite.connect(path) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(sql, params) as cursor:
            row = await cursor.fetchone()
    return dict(row) if row else None


async def fetch_value(path: str, sql: str, params=()):
    row = await fetch_one(path, sql, params)
    if not row:
        return None
    return next(iter(row.values()))


class FakeMessage:
    def __init__(self):
        self.reply_text = AsyncMock()


class FakeUpdate:
    def __init__(self, user_id: int):
        self.effective_user = SimpleNamespace(
            id=user_id,
            username=f"user{user_id}",
            full_name=f"User {user_id}",
        )
        self.message = FakeMessage()
        self.effective_message = self.message
        self.callback_query = None


def unwrap_handler(function):
    while hasattr(function, "__wrapped__"):
        function = function.__wrapped__
    return function
