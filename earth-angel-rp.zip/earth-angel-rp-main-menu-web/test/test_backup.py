# test/test_backup.py
import gzip
import json
from pathlib import Path

import aiosqlite
import pytest


@pytest.mark.asyncio
async def test_backup_archive_is_readable(isolated_db, monkeypatch, tmp_path):
    import utils.backup as backup

    backup_dir = tmp_path / "backups"
    monkeypatch.setattr(backup, "DB_PATH", isolated_db)
    monkeypatch.setattr(backup, "BACKUP_DIR", backup_dir)

    archive = await backup.create_backup()
    manifest = archive.with_suffix(archive.suffix + ".json")

    assert archive.is_file()
    assert manifest.is_file()
    assert json.loads(manifest.read_text())["sha256"] == backup._sha256(archive)

    restored = tmp_path / "restored.db"
    with gzip.open(archive, "rb") as source:
        restored.write_bytes(source.read())

    async with aiosqlite.connect(restored) as db:
        async with db.execute("PRAGMA integrity_check") as cursor:
            row = await cursor.fetchone()
    assert row[0] == "ok"