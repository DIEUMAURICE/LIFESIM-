from unittest.mock import AsyncMock

import pytest
from fastapi import HTTPException

from webapp.routers import life_router


@pytest.mark.asyncio
async def test_gym_refuses_during_bot_cooldown(monkeypatch):
    monkeypatch.setattr(life_router, "free_problem", AsyncMock(return_value=None))
    monkeypatch.setattr(
        life_router,
        "cooldown_problem",
        AsyncMock(return_value=("⏳ Reviens dans 11 h.", False)),
    )
    get_user = AsyncMock()
    monkeypatch.setattr(life_router.database, "get_user", get_user)

    with pytest.raises(HTTPException) as exc:
        await life_router.gym(user_id=123)

    assert exc.value.status_code == 422
    assert "11 h" in exc.value.detail
    life_router.cooldown_problem.assert_awaited_once_with(
        123,
        "gym_last",
        43200,
        "⏳ Tu es fatigué de la salle. Reviens dans {remaining}.",
    )
    get_user.assert_not_awaited()


@pytest.mark.asyncio
async def test_gym_checks_free_status_before_claiming_cooldown(monkeypatch):
    monkeypatch.setattr(
        life_router, "free_problem", AsyncMock(return_value="Tu es en prison.")
    )
    cooldown = AsyncMock()
    monkeypatch.setattr(life_router, "cooldown_problem", cooldown)

    with pytest.raises(HTTPException) as exc:
        await life_router.gym(user_id=123)

    assert exc.value.status_code == 422
    assert exc.value.detail == "Tu es en prison."
    cooldown.assert_not_awaited()
