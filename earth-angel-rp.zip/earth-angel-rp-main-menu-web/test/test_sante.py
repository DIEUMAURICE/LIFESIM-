# test/test_sante.py — Santé publique : direction, postes, chaîne de médicaments, soins, lits, assurance, salaires
import os

os.environ.setdefault("BOT_TOKEN", "x")
os.environ.setdefault("ADMIN_IDS", "1")

import pytest
import pytest_asyncio

import database
import migrations
import utils.factions as factions
import utils.payroll as payroll
import utils.sante as sante
from config import SANTE_POSTS, SANTE_GATHER, MEDICINES, INSURANCE_PLANS, SANTE_CONSULT_COST

LEADER, PDG, DG1, DG2, DOC, AMB, REC, TECH, OPE, PAT, PAT2 = 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211
USERS = (LEADER, PDG, DG1, DG2, DOC, AMB, REC, TECH, OPE, PAT, PAT2)


@pytest_asyncio.fixture
async def sdb(monkeypatch, tmp_path):
    path = str(tmp_path / "sante.db")
    pool = database.SQLiteConnectionPool(path, size=5)
    monkeypatch.setattr(database, "DB_PATH", path)
    monkeypatch.setattr(database, "_DB_POOL", pool)
    monkeypatch.setattr(migrations, "DB_PATH", path)
    await database.init_db()
    await database.run_migrations()
    await migrations.run_migrations()

    sent = []

    async def fake_notify(user_id, title, message, notif_type="info", delay=0):
        sent.append((user_id, title, message))

    clock = {"t": 10 * 86400, "real": 1_000_000}
    for mod in (sante, factions, payroll):
        monkeypatch.setattr(mod, "notify", fake_notify)
    import utils.cooldowns as cooldowns
    for mod in (sante, factions, payroll, cooldowns):
        monkeypatch.setattr(mod, "now", lambda: clock["t"])

    where = {}   # joueur → lieu RP (pour les tests de présence)

    async def fake_position(uid):
        return {"location": where.get(uid, "maison"), "in_transit": False}

    async def fake_exempt(uid):
        return False

    import utils.location as loc
    monkeypatch.setattr(loc, "get_position", fake_position)
    monkeypatch.setattr(loc, "is_exempt", fake_exempt)

    for uid in USERS:
        await database.get_user(uid, f"u{uid}", f"User{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "balance", 1_000_000)
        await database.update_field(uid, "health", 40)
        await database.update_field(uid, "energy", 100)
    yield {"sent": sent, "clock": clock, "where": where}


async def _fill_coffre(amount):
    async with database.db_connection() as db:
        await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES ('sante', 0)")
        await db.execute("UPDATE faction_state SET budget=? WHERE faction='sante'", (amount,))
        await db.commit()


async def _staff(uid, post, hosp="grand", duty=False):
    async with database.db_connection() as db:
        await sante._set_post(db, uid, hosp, post)
        await db.execute("UPDATE sante_staff SET on_duty=? WHERE user_id=?", (1 if duty else 0, uid))
        await db.commit()


async def _stock(kind, item, qty):
    async with database.db_connection() as db:
        await sante._stock_add(db, kind, item, qty)
        await db.commit()


async def _bal(uid):
    return (await database.get_user(uid))["balance"]


async def _health(uid):
    return (await database.get_user(uid))["health"]


# ── Direction ────────────────────────────────────────────────────────────────
async def test_pdg_nomme_par_le_leader_et_remplace(sdb):
    ok, _ = await sante.appoint_pdg(LEADER, PDG)
    assert ok and (await sante.get_staff(PDG))["post"] == "pdg"
    ok, _ = await sante.appoint_pdg(LEADER, DG1)          # remplace le PDG
    assert ok
    assert (await sante.get_staff(DG1))["post"] == "pdg"
    assert (await sante.get_staff(PDG))["post"] == "recolteur"       # ancien PDG : poste de base
    assert (await sante.get_head("grand"))["user_id"] == DG1


async def test_dg_nomme_par_le_pdg_seulement(sdb):
    await sante.appoint_pdg(LEADER, PDG)
    ok, msg = await sante.appoint_dg(DOC, DG1, "sud")                 # un simple joueur
    assert not ok and "PDG" in msg
    ok, _ = await sante.appoint_dg(PDG, DG1, "sud")
    assert ok and (await sante.get_staff(DG1))["post"] == "dg"
    ok, msg = await sante.appoint_dg(PDG, DG2, "grand")               # le grand hôpital a un PDG, pas un DG
    assert not ok
    ok, _ = await sante.appoint_dg(PDG, DG2, "sud")                   # remplacement du DG
    assert ok and (await sante.get_staff(DG1))["post"] == "recolteur"
    ok, _ = await sante.appoint_dg(LEADER, DG1, "aeroport", is_admin=True)   # les admins peuvent aussi
    assert ok


async def test_nomination_refusee_si_deja_employe_ailleurs(sdb):
    async with database.db_connection() as db:
        await db.execute("INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) "
                         "VALUES (?, 'police', 0, 0, 0)", (DG1,))
        await db.commit()
    ok, msg = await sante.appoint_pdg(LEADER, DG1)
    assert not ok and "faction" in msg


async def test_assign_post_dg_limite_a_son_hopital(sdb):
    await sante.appoint_pdg(LEADER, PDG)
    await sante.appoint_dg(PDG, DG1, "sud")
    await _staff(REC, "recolteur", "sud")
    await _staff(AMB, "recolteur", "affaires")
    ok, _ = await sante.assign_post(DG1, REC, "infirmier")
    assert ok and (await sante.get_staff(REC))["post"] == "infirmier"
    ok, msg = await sante.assign_post(DG1, AMB, "infirmier")          # autre hôpital
    assert not ok
    ok, msg = await sante.assign_post(DG1, REC, "infirmier", hospital_id="grand")   # pas de transfert par un DG
    assert not ok
    ok, _ = await sante.assign_post(PDG, AMB, "medecin", hospital_id="sud")         # le PDG affecte où il veut
    assert ok and (await sante.get_staff(AMB))["hospital_id"] == "sud"
    ok, msg = await sante.assign_post(REC, AMB, "chirurgien")         # un employé n'a aucun pouvoir
    assert not ok
    ok, msg = await sante.assign_post(PDG, PAT, "medecin")            # pas membre de la santé
    assert not ok
    ok, msg = await sante.assign_post(PDG, DG1, "medecin")            # on ne rétrograde pas un directeur
    assert not ok
    # le grade de la faction suit le niveau du poste
    async with database.db_connection() as db:
        async with db.execute("SELECT rank FROM faction_members WHERE user_id=?", (AMB,)) as cur:
            assert (await cur.fetchone())[0] == SANTE_POSTS["medecin"]["level"]


async def test_renvoi_hierarchique_et_admin(sdb):
    await sante.appoint_pdg(LEADER, PDG)
    await sante.appoint_dg(PDG, DG1, "sud")
    await _staff(REC, "recolteur", "sud")
    await _staff(AMB, "ambulancier", "grand")
    ok, _ = await sante.dismiss(DG1, AMB)
    assert not ok                                                    # autre hôpital
    ok, _ = await sante.dismiss(DG1, PDG)
    assert not ok                                                    # on ne renvoie pas plus gradé
    ok, _ = await sante.dismiss(DG1, REC, reason="test")
    assert ok and await sante.get_staff(REC) is None
    ok, _ = await sante.dismiss(LEADER, PDG, is_admin=True, reason="triche")
    assert ok and await sante.get_head("grand") is None
    logs = await sante.audit(10)
    assert any(r["action"] == "revocation_admin" for r in logs)


async def test_quitter_la_faction_libere_le_poste(sdb):
    await sante.appoint_pdg(LEADER, PDG)
    assert await factions.leave_faction(PDG)
    assert await sante.get_head("grand") is None and await sante.get_staff(PDG) is None


async def test_ancien_membre_reconcilie_sans_direction(sdb):
    async with database.db_connection() as db:       # ancien « Directeur d'hôpital » (grade 5)
        await db.execute("INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) "
                         "VALUES (?, 'sante', 5, 0, 0)", (DOC,))
        await db.commit()
    st = await sante.get_staff(DOC)
    assert st["post"] != "pdg" and st["role"] != "head"
    m = await factions.get_membership(DOC)
    assert m["rank_name"] == st["post_name"] and m["salary"] == st["salary_h"]


# ── Chaîne de production ─────────────────────────────────────────────────────
async def test_chaine_ressources_labo_industrie_vente(sdb):
    await _staff(REC, "recolteur")
    await _staff(TECH, "technicien")
    await _staff(OPE, "operateur")
    clock = sdb["clock"]
    # rôle respecté
    ok, msg = await sante.gather(TECH, "plantes")
    assert not ok and "poste" in msg
    # récolte (cooldown)
    for res in ("plantes", "mineraux", "eau"):
        ok, msg = await sante.gather(REC, res)
        assert ok, msg
        clock["t"] += SANTE_GATHER["cooldown"] + 1
    ok, msg = await sante.gather(REC, "plantes")
    assert ok
    ok, msg = await sante.gather(REC, "plantes")
    assert not ok and "Repose" in msg
    assert (await database.get_user(REC))["energy"] < 100
    stock = await sante.get_stock()
    assert stock["raw"]["plantes"] >= SANTE_GATHER["yield"][0]
    # laboratoire : il manque des ressources → refus clair ; avec stock → produit
    await _stock("raw", "plantes", 10)
    await _stock("raw", "mineraux", 10)
    await _stock("raw", "eau", 10)
    ok, msg = await sante.industry_make(OPE, "Aspirine")
    assert not ok and "Il manque" in msg                              # pas encore d'extrait
    ok, msg = await sante.lab_make(TECH, "extrait")
    assert ok, msg
    clock["t"] += 10_000
    ok, msg = await sante.lab_make(TECH, "principe")
    assert ok, msg
    # industrie → médicament en vente automatiquement
    ok, msg = await sante.industry_make(OPE, "Aspirine")
    assert ok, msg
    cat = {m["name"]: m for m in await sante.pharmacy_catalog(PAT)}
    assert cat["Aspirine"]["stock"] == 6 and cat["Antibiotiques"]["stock"] == 0


async def test_stock_plafonne(sdb):
    await _staff(TECH, "technicien")
    await _stock("raw", "plantes", 50)
    await _stock("raw", "eau", 50)
    await _stock("inter", "extrait", 299)
    ok, msg = await sante.lab_make(TECH, "extrait")
    assert ok
    assert (await sante.get_stock())["inter"]["extrait"] == 300       # plafond respecté (2 produits → 1 seul gardé)
    sdb["clock"]["t"] += 10_000
    ok, msg = await sante.lab_make(TECH, "extrait")
    assert not ok and "plein" in msg
    assert (await sante.get_stock())["raw"]["plantes"] == 47          # refus : aucune ressource consommée


# ── Médicaments, coffre, assurance ───────────────────────────────────────────
async def test_achat_medicament_remplit_le_coffre(sdb):
    await _fill_coffre(0)
    await _stock("med", "Aspirine", 2)
    before = await _bal(PAT)
    ok, msg = await sante.buy_medicine(PAT, "Aspirine")
    assert ok, msg
    price = MEDICINES["Aspirine"]["price"]
    assert before - await _bal(PAT) == price
    assert await factions.coffre_balance("sante") == price            # tout va au coffre
    assert (await sante.get_stock())["med"]["Aspirine"] == 1
    assert await _health(PAT) == 40 + MEDICINES["Aspirine"]["health"]
    ok, msg = await sante.buy_medicine(PAT, "Aspirine")               # 1 par heure de jeu
    assert not ok and "heure" in msg
    sdb["clock"]["t"] += 3601
    assert (await sante.buy_medicine(PAT, "Aspirine"))[0]


async def test_rupture_et_fonds_insuffisants_ne_consomment_rien(sdb):
    ok, msg = await sante.buy_medicine(PAT, "Antibiotiques")
    assert not ok and "rupture" in msg
    await _stock("med", "Greffe", 1)
    await database.update_field(PAT2, "balance", 10)
    ok, msg = await sante.buy_medicine(PAT2, "Greffe")
    assert not ok and "Fonds" in msg
    assert (await sante.get_stock())["med"]["Greffe"] == 1 and await _bal(PAT2) == 10
    await database.update_field(PAT2, "balance", 10_000_000)          # le cooldown a été rendu : on peut réessayer
    assert (await sante.buy_medicine(PAT2, "Greffe"))[0]


async def test_assurance_reduit_les_couts_et_finance_le_coffre(sdb):
    await _fill_coffre(0)
    ok, _ = await sante.subscribe_insurance(PAT, "standard")
    assert ok and await factions.coffre_balance("sante") == INSURANCE_PLANS["standard"]["cost"]
    await _stock("med", "Antibiotiques", 3)
    before, coffre = await _bal(PAT), await factions.coffre_balance("sante")
    ok, msg = await sante.buy_medicine(PAT, "Antibiotiques")
    assert ok and "assurance" in msg
    paid = int(MEDICINES["Antibiotiques"]["price"] * (1 - INSURANCE_PLANS["standard"]["coverage"]))
    assert before - await _bal(PAT) == paid
    assert await factions.coffre_balance("sante") == coffre + paid     # le coffre ne reçoit que la part du patient
    assert (await sante.get_insurance(PAT))["claims"] == 1
    ok, _ = await sante.subscribe_insurance(PAT2, "vip")
    await database.update_field(PAT2, "balance", 10)
    ok, msg = await sante.subscribe_insurance(PAT2, "vip")
    assert not ok


async def test_assurance_expire_au_bout_d_un_mois(sdb):
    await sante.subscribe_insurance(PAT, "basique")
    assert await sante.get_insurance(PAT)
    sdb["clock"]["t"] += 40 * 86400
    assert await sante.get_insurance(PAT) is None


# ── Salaires par heure de jeu ────────────────────────────────────────────────
async def test_salaire_horaire_par_poste_paye_par_le_coffre(sdb):
    await _staff(REC, "recolteur")
    await _staff(DOC, "medecin")
    await _fill_coffre(100_000)
    b_rec, b_doc = await _bal(REC), await _bal(DOC)
    hour = sante.game_hour()
    res = await sante.run_sante_payroll(hour)
    assert res["status"] == "paid"
    assert await _bal(REC) - b_rec == SANTE_POSTS["recolteur"]["salary_h"]
    assert await _bal(DOC) - b_doc == SANTE_POSTS["medecin"]["salary_h"]      # chaque poste son salaire
    assert await factions.coffre_balance("sante") == 100_000 - SANTE_POSTS["recolteur"]["salary_h"] - SANTE_POSTS["medecin"]["salary_h"]
    again = await sante.run_sante_payroll(hour)                              # même heure : jamais payé deux fois
    assert again["status"] == "none" and await _bal(DOC) - b_doc == SANTE_POSTS["medecin"]["salary_h"]
    await sante.run_sante_payroll(hour + 1)                                  # heure suivante : payé à nouveau
    assert await _bal(DOC) - b_doc == 2 * SANTE_POSTS["medecin"]["salary_h"]


async def test_coffre_insuffisant_paie_proportionnelle(sdb):
    await _staff(REC, "recolteur")
    await _staff(DOC, "medecin")
    total = SANTE_POSTS["recolteur"]["salary_h"] + SANTE_POSTS["medecin"]["salary_h"]
    await _fill_coffre(total // 2)
    b = await _bal(DOC)
    res = await sante.run_sante_payroll(sante.game_hour())
    assert res["status"] == "partial"
    assert await _bal(DOC) - b == int(SANTE_POSTS["medecin"]["salary_h"] * 0.5)
    assert await factions.coffre_balance("sante") <= 1
    assert any("partiel" in m[1].lower() for m in sdb["sent"])


async def test_paie_quotidienne_ignore_la_sante(sdb):
    await _staff(DOC, "medecin")
    await _fill_coffre(500_000)
    b = await _bal(DOC)
    await payroll.run_faction_payroll()
    assert await _bal(DOC) == b                                              # la santé est payée à l'heure, pas à la journée


async def test_salaire_seulement_en_service_si_active(sdb, monkeypatch):
    monkeypatch.setattr(sante, "SANTE_PAY_ONLY_ON_DUTY", True)
    await _staff(DOC, "medecin", duty=True)
    await _staff(AMB, "ambulancier", duty=False)
    await _fill_coffre(100_000)
    b = await _bal(AMB)
    await sante.run_sante_payroll(sante.game_hour())
    assert await _bal(AMB) == b


# ── Soins : ambulance, consultation ──────────────────────────────────────────
async def test_ambulance_gratuite_notifie_les_soignants_en_service(sdb):
    await _staff(AMB, "ambulancier", duty=True)
    await _staff(DOC, "medecin", duty=False)
    before = await _bal(PAT)
    ok, msg = await sante.call_ambulance(PAT)
    assert ok and "1" in msg
    assert any(n[0] == AMB and "ambulance" in n[2].lower() for n in sdb["sent"])
    assert not any(n[0] == DOC for n in sdb["sent"])                         # hors service : pas notifié
    ok, msg = await sante.call_ambulance(PAT)
    assert not ok                                                            # cooldown / appel déjà ouvert
    call = await sante.get_open_call(PAT)
    ok, _ = await sante.take_call(AMB, call["call_id"])
    assert ok
    ok, _ = await sante.take_call(DOC, call["call_id"])
    assert not ok                                                            # déjà pris
    ok, _ = await sante.treat_call(AMB, call["call_id"])
    assert ok
    assert await _health(PAT) == 40 + SANTE_POSTS["ambulancier"]["heal"]
    assert await _bal(PAT) == before                                         # GRATUIT
    ok, _ = await sante.treat_call(AMB, call["call_id"])
    assert not ok                                                            # appel clos


async def test_ambulance_sans_soignant_reste_en_attente_puis_expire(sdb):
    ok, msg = await sante.call_ambulance(PAT)
    assert ok and "aucun soignant" in msg.lower()
    await _staff(AMB, "ambulancier", duty=True)
    calls = await sante.pending_calls_for(AMB)
    assert len(calls) == 1
    sdb["clock"]["t"] += 5000
    assert await sante.expire_calls() == 1
    ok, msg = await sante.take_call(AMB, calls[0]["call_id"])
    assert not ok


async def test_soignant_hors_service_ou_sur_lui_meme_refuse(sdb):
    await _staff(AMB, "ambulancier", duty=False)
    await sante.call_ambulance(PAT)
    call = await sante.get_open_call(PAT)
    ok, msg = await sante.take_call(AMB, call["call_id"])
    assert not ok and "service" in msg
    await _staff(PAT, "infirmier", duty=True)
    await database.update_field(PAT, "health", 30)
    sdb["clock"]["t"] += 5000
    await sante.expire_calls()
    sdb["clock"]["t"] += 4000
    ok, _ = await sante.call_ambulance(PAT)
    assert ok
    mine = await sante.get_open_call(PAT)
    ok, msg = await sante.take_call(PAT, mine["call_id"])
    assert not ok and "toi-même" in msg


async def test_en_bonne_sante_pas_d_ambulance(sdb):
    await database.update_field(PAT, "health", 100)
    ok, msg = await sante.call_ambulance(PAT)
    assert not ok


async def test_consultation_payante_au_coffre_avec_assurance(sdb):
    await _fill_coffre(0)
    await _staff(DOC, "medecin", hosp="sud", duty=True)
    sdb["where"][PAT] = "hopital_sud"
    ok, msg = await sante.request_consult(PAT)
    assert ok
    call = await sante.get_open_call(PAT)
    await sante.take_call(DOC, call["call_id"])
    before = await _bal(PAT)
    ok, _ = await sante.treat_call(DOC, call["call_id"])
    assert ok
    assert before - await _bal(PAT) == SANTE_CONSULT_COST
    assert await factions.coffre_balance("sante") == SANTE_CONSULT_COST
    assert await _health(PAT) > 40 + SANTE_POSTS["medecin"]["heal"] - 1


async def test_consultation_sans_soignant_en_service_ou_hors_hopital(sdb):
    ok, msg = await sante.request_consult(PAT)                               # à la maison
    assert not ok and "hôpital" in msg.lower()
    sdb["where"][PAT] = "hopital"
    ok, msg = await sante.request_consult(PAT)
    assert not ok and "Aucun soignant" in msg
    await _staff(DOC, "medecin", hosp="sud", duty=True)                      # en service mais dans un autre hôpital
    ok, msg = await sante.request_consult(PAT)
    assert not ok


async def test_anti_triche_meme_soignant_meme_patient(sdb):
    await _staff(AMB, "ambulancier", duty=True)
    await database.update_field(PAT, "health", 1)
    ok, _ = await sante.call_ambulance(PAT)
    assert ok
    call = await sante.get_open_call(PAT)
    assert (await sante.take_call(AMB, call["call_id"]))[0]
    for _ in range(2):                                   # déjà 2 soins de ce soignant à ce patient dans l'heure
        await sante.log_event(AMB, "soin", PAT, "test")
    ok, msg = await sante.treat_call(AMB, call["call_id"])
    assert not ok and "assez de soins" in msg
    assert await _health(PAT) == 1                       # rien n'a été soigné
    sdb["clock"]["t"] += 3700                            # la fenêtre d'une heure de jeu est passée
    ok, _ = await sante.treat_call(AMB, call["call_id"])
    assert ok


# ── Lits ─────────────────────────────────────────────────────────────────────
async def test_lit_duree_minimale_et_capacite_partagee(sdb):
    sdb["where"][PAT] = "hopital_sud"
    sdb["where"][PAT2] = "hopital_sud"
    ok, msg = await sante.take_bed(PAT)
    assert ok
    assert (await database.get_user(PAT))["hospital_until"] > sdb["clock"]["t"]    # bloqué pendant le repos
    ok, msg = await sante.leave_bed(PAT)
    assert not ok and "Encore" in msg                                        # moins de 2 min réelles
    sdb["clock"]["t"] += 121
    ok, msg = await sante.leave_bed(PAT)
    assert ok and await _health(PAT) == 90
    assert (await database.get_user(PAT))["hospital_until"] == 0
    assert await sante.get_bed(PAT) is None


async def test_lits_limites_par_hopital(sdb):
    cap = sante.hospital_info("sud")["beds"]
    extra = []
    for i in range(cap + 1):
        uid = 300 + i
        await database.get_user(uid, f"x{uid}", f"X{uid}")
        await database.update_field(uid, "registered", 1)
        await database.update_field(uid, "health", 50)
        sdb["where"][uid] = "hopital_sud"
        extra.append(uid)
    results = [(await sante.take_bed(u))[0] for u in extra]
    assert results.count(True) == cap and results[-1] is False
    assert await sante.bed_status("sud") == (cap, cap)
    ok, msg = await sante.take_bed(extra[0])
    assert not ok and "déjà" in msg
    # un lit se libère → le suivant peut en prendre un
    sdb["clock"]["t"] += 130
    assert (await sante.leave_bed(extra[0]))[0]
    assert (await sante.take_bed(extra[-1]))[0]


async def test_lit_liberation_automatique_et_forcee(sdb):
    sdb["where"][PAT] = "hopital"
    sdb["where"][PAT2] = "hopital"
    await sante.take_bed(PAT)
    await sante.take_bed(PAT2)
    sdb["clock"]["t"] += 700
    assert await sante.release_stale_beds() == 2                              # oublié → libéré (et soigné)
    assert await sante.get_bed(PAT) is None and await _health(PAT) == 90
    await database.update_field(PAT, "health", 40)
    await sante.take_bed(PAT)
    assert await sante.free_beds(user_id=PAT) == 1                            # admin : libération forcée, sans soin
    assert await _health(PAT) == 40 and (await database.get_user(PAT))["hospital_until"] == 0


async def test_partir_sans_soin(sdb):
    sdb["where"][PAT] = "hopital"
    await sante.take_bed(PAT)
    ok, msg = await sante.leave_bed(PAT, force=True)
    assert ok and await _health(PAT) == 40 and await sante.get_bed(PAT) is None


async def test_lit_refuse_hors_hopital_ou_en_pleine_forme(sdb):
    ok, msg = await sante.take_bed(PAT)
    assert not ok and "hôpital" in msg.lower()
    sdb["where"][PAT] = "hopital"
    await database.update_field(PAT, "health", 100)
    ok, msg = await sante.take_bed(PAT)
    assert not ok


# ── Service ──────────────────────────────────────────────────────────────────
async def test_prise_de_service_sur_place_et_roles(sdb):
    await _staff(AMB, "ambulancier", hosp="sud")
    ok, msg = await sante.set_duty(AMB, True)
    assert not ok and "rends-toi" in msg
    sdb["where"][AMB] = "hopital_sud"
    ok, _ = await sante.set_duty(AMB, True)
    assert ok and (await sante.get_staff(AMB))["on_duty"] == 1
    await _staff(REC, "recolteur")
    ok, msg = await sante.set_duty(REC, True)
    assert not ok
    assert (await sante.set_duty(AMB, False))[0]


async def test_menu_equipe_et_apercu_des_hopitaux(sdb):
    await sante.appoint_pdg(LEADER, PDG)
    await _staff(AMB, "ambulancier", hosp="grand", duty=True)
    ov = {h["id"]: h for h in await sante.hospital_overview()}
    assert len(ov) == 5 and ov["grand"]["head"]["user_id"] == PDG and ov["grand"]["on_duty"] == 1
    assert ov["sud"]["head"] is None and ov["sud"]["beds_cap"] == 3
