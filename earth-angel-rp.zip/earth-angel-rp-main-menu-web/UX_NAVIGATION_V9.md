# Earth Angel RP — Navigation UX v9

## Problème corrigé

Les interfaces Web et Mini App ne doivent pas présenter plusieurs systèmes de gameplay complets sur un écran unique. Elles servent désormais de navigation progressive : espace, hub, module, action.

## Structure

1. **Espaces principaux** : Accueil, Économie, Ville, Social, Plus.
2. **Hubs** : cartes de modules avec description courte ; aucune donnée lourde n’est chargée tant que le module n’est pas ouvert.
3. **Écrans dédiés** : une fonctionnalité active à la fois, avec ses données, actions, cooldowns, coûts, restrictions et historique.
4. **Détails et confirmations** : feuilles modales déjà fournies par le noyau partagé, utilisées pour confirmer une action ou afficher ses conséquences.

## Implémentation

- `EA.tab({ hub: true })` marque les espaces qui doivent commencer par un hub.
- `EA.go("espace")` revient au hub et efface le sous-onglet actif.
- `EA.go("espace", "module")` ouvre un écran métier unique.
- Un bouton Retour est affiché sur chaque écran de module.
- Les trois interfaces continuent d’utiliser les mêmes endpoints : bot Telegram, Mini App et application Web.

## Animation 3D légère

L’animation utilise l’asset officiel `/shared/icon.png` comme source. Le conteneur `ea-brand-mark` applique une perspective, une rotation Y/X lente, un balayage lumineux et une ombre de profondeur en CSS. Aucun asset vidéo lourd n’est requis.

- durée : 15 secondes ;
- pas d’audio automatique ;
- désactivation automatique avec `prefers-reduced-motion` ;
- compatible WebView Telegram et navigateur classique ;
- aucune modification de logique serveur.

## Vérifications

- `node --check` validé pour `core.js` et `home.js` ;
- compilation Python du serveur validée ;
- cache front bumpé en v9 ;
- `frontend_version` serveur alignée sur v9.
