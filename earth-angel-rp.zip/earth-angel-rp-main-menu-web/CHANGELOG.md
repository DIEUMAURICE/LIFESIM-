# CHANGELOG : EARTH ANGEL RP (v3)

## Casino avancé — Poker vidéo Bot / Mini App / Web — 2026-11-10

- Extraction des règles de Poker vidéo dans `gameplay/casino.py`; la commande Telegram et la route `/api/casino/poker/play` utilisent le même tirage, classement, payout, XP, statistiques, mission et loot.
- L’API reprend les contrôles bot de joueur libre, présence au casino (sauf exemptions existantes), horaires du jeu, limites de mise et solde; l’écran partagé Mini App/Web peut jouer au Poker sans compte Telegram obligatoire.
- Les catégories et multiplicateurs historiques sont préservés, y compris les égalités au seul rang de catégorie. Le résultat API renvoie les deux mains, le payout brut, le net et le solde courant.
- Tests contractuels ajoutés pour la quinte flush, les effets économiques communs, les gardes de l’API et l’enregistrement de route.
- Périmètre incomplet : blackjack, roulette, crash, mines et PMU restent à intégrer; l’état durable/idempotence des parties et l’atomicité complète des mutations du Poker restent des travaux ouverts.

## Casino avancé — Blackjack, Roulette et PMU — 2026-11-10

- Ajout des résolutions Roulette et PMU dans `gameplay/casino.py`; le bot et l’API partagent le tirage, les cotes, payouts bruts, XP, loot et suivi mission/statistiques.
- Ajout des routes `/api/casino/roulette/spin` et `/api/casino/pmu/run`, de leurs contrôles d’accès communs et des parcours dans l’écran partagé Web/Mini App.
- Extraction du calcul de main, du démarrage et des actions Blackjack; les callbacks Telegram et `/api/casino/blackjack/*` passent désormais par les mêmes règles de hit/stand/double et règlement.
- L’écran partagé permet également de démarrer une partie Blackjack et d’effectuer les actions.
- Limites non fermées : les tours Roulette/PMU du bot ont encore une sélection interactive distincte; les parties API Blackjack sont en mémoire; crash et mines ne sont pas raccordés; l’idempotence et l’atomicité durables restent nécessaires.

## Parité Bot / Mini App / Web — Récolte groupée du jardin — 2026-11-10

- Création de `gameplay/garden.py` pour récolter les parcelles mûres avec les mêmes bonus d’arrosage, saison, récompenses de progression et risques illégaux.
- Le bot (commande et menu callback) et `/api/garden/harvest/all` appellent maintenant cette opération commune; la Mini App et le Web proposent « Tout récolter ».
- Les parcelles confisquées et l’état de prison sont enregistrés dans la mutation groupée; fonds, XP, récolte destinée aux entreprises et mission sont attribués avec les règles du bot.
- Tests ajoutés pour le calcul bot/API, l’absence de plante mûre et l’arrestation/confiscation.
- La maintenance du jardin est maintenant enregistrée dans le scheduler du bot; elle retire par transaction les plantes mortes et persiste une notification groupée par joueur, sans doublon au passage suivant.
- Validation complète après la famille et le jardin : 316 tests passent; compilation Python et syntaxe de tous les scripts JavaScript réussissent. Les deux avertissements FastAPI `on_event` sont préexistants.

## Parité Bot / Mini App / Web — Droits avancés des clans familiaux — 2026-11-10

- Centralisation du transfert de fondateur et de la dissolution dans `gameplay/family.py`.
- Le bot et l’API vérifient les mêmes droits; une cible de transfert doit être membre et seul le fondateur peut transférer ou dissoudre.
- L’écran commun propose le transfert à un membre et demande confirmation avant la dissolution irréversible.
- La suppression du clan, de ses membres et de ses invitations est atomique; la commande Telegram conserve aussi sa confirmation explicite.
- Tests d’intégration étendus aux chemins API et Telegram, aux refus et aux effets de confirmation.

## Parité Bot / Mini App / Web — Adoption familiale — 2026-11-10

- Création de `gameplay/family.py` pour partager les règles d’adoption : âge minimum du parent (25 ans), enfant de moins de 20 ans, limite de cinq enfants, enfant unique et coût de 50 000 €A.
- L’adoption et le débit sont maintenant atomiques, y compris `total_spent`, la comptabilité du Trésor et le snapshot des statistiques.
- Le handler Telegram et la route `/api/family/adopt` appellent le même service; l’écran partagé affiche les enfants et le parent adoptif dans `/tg/` et `/app/`.
- Version de cache du chargeur commun incrémentée pour les deux clients.
- Tests d’intégration famille ajoutés pour les deux adaptateurs, refus, concurrence et plafond.
- Validation complète : 309 tests passent; compilation Python et vérification syntaxique de tous les scripts JavaScript réussissent. Deux avertissements FastAPI préexistants sur `on_event`.

## Parité Bot / Mini App / Web — Commentaires et collaborations — 2026-11-10

- Création de `gameplay/social_comments.py` : lecture partagée des 8 commentaires les plus récents, création atomique, limite existante de 200 caractères et 3 par publication, compteur RP synchronisé et notification à l’auteur.
- Le flow Telegram et les routes `/api/reseau/posts/{post_id}/comments` partagent les mutations; le fil partagé propose la lecture et la saisie dans la Mini App et le Web.
- Création de `gameplay/social_collabs.py` : demandes reçues/envoyées, état actif, ciblage par identifiant (y compris négatif pour les comptes Web) ou @pseudo, acceptation/refus, coût et récompenses partagés.
- Le bot et `/api/reseau/collabs` appliquent les types existants, 50 000 €A débités au proposant à l’acceptation, 24 h de jeu et +100 abonnés à chaque participant; les boutons de décision Telegram sont conservés et les demandes API sont persistées dans l’inbox.
- Ajout de l’onglet Collaborations et de l’expansion des commentaires dans `shared/screens/social.js`; version cache statique incrémentée à 10.
- Validation finale : 304 tests passent; `compileall` et `node --check` sur tous les JavaScript passent. Deux avertissements de dépréciation FastAPI préexistants (`on_event`).
- La correction des acceptations de demandes multiples en attente (pas de nouvelle vérification solde/disponibilité) est documentée séparément et non modifiée dans cette tranche.

## Parité Bot / Mini App / Web — Sondages sociaux — 2026-11-10

- Création de `gameplay/social_polls.py` pour centraliser création, limite de 3 sondages par jour de jeu, durée de 2 jours, portée communautaire, vote unique, récompense (+1 SocialCoin), notifications et clôture.
- Le parcours réseau Telegram et les anciennes commandes de vote/création réutilisent le même service que les routes `/api/reseau/polls`.
- Ajout d’un panneau de sondages dans `shared/screens/social.js`, commun à `/tg/` et `/app/`, avec résultats en direct, création, vote et clôture.
- Ajout de tests contractuels : règles bot/API, limites, votes communautaires, récompenses et vote concurrent.
- Validation finale : 297 tests passent; `compileall` et `node --check` sur tous les JavaScript passent.

## Parité Bot / Mini App / Web — Crime & sécurité des guildes — 2026-11-10

- Centralisation de la dissolution de gang, du remboursement de trésorerie, du hold-up et de la maintenance dans `gameplay/gangs.py`.
- Ajout des routes Web `/api/gangs/dissolve` et `/api/gangs/hold-up`.
- Ajout des boutons correspondants dans l’écran partagé des guildes.
- Conservation des règles de chance, récompense, perte de caisse et réputation existantes.
- Suite complète : 293 tests passés.

## Parité Bot / Mini App / Web — Actions avancées des guildes — 2026-11-10

- Centralisation du changement de rôle, de l’exclusion et du transfert de chef dans `gameplay/gangs.py`.
- Ajout des contrôles hiérarchiques et transactionnels communs aux adaptateurs Telegram et Web.
- Ajout des routes `/api/gangs/role`, `/api/gangs/exclude` et `/api/gangs/transfer`.
- Ajout de la liste des membres et des contrôles de gestion dans l’écran partagé des guildes.
- Notifications communes lors d’un changement de rôle, d’une exclusion ou d’un transfert de chef.
- Suite complète : 292 tests passés.

## Parité Bot / Mini App / Web — Classements, guildes et parrainage — 2026-11-10

- L’API Web des classements utilise désormais le moteur complet partagé `utils/rankings.py` et expose les classements paginés.
- Création de `gameplay/gangs.py` pour centraliser création, candidature, départ, caisse et amélioration des guildes.
- Création de `gameplay/referrals.py` pour partager les récompenses d’arrivée et d’activation entre Telegram et Web.
- Ajout de l’API et de l’écran partagé de parrainage, avec token, statistiques, activation et historique des filleuls.
- Ajout de tests contractuels pour les guildes, classements et parrainage.

## Parité Bot / Mini App / Web — Inventaire, marché et objets — 2026-11-10

- Ajout de `gameplay/market.py`, moteur commun des mutations du marché joueur et de l’inventaire.
- Centralisation de la mise en vente, l’achat, l’annulation d’annonce et l’utilisation des consommables pour le bot, les callbacks et l’API Web.
- Conservation des protections atomiques de stock, solde, annonces et inventaire, avec journalisation commune.
- La boutique Stars Telegram reste séparée et ses achats Web restent bloqués sans moyen de paiement Web.
- Ajout de tests contractuels inventaire/marché et correction de compatibilité avec les fixtures SQLite minimales.

## Parité Bot / Mini App / Web — Combat et quêtes — 2026-11-10

- Ajout du moteur commun `gameplay/combat.py` pour les combats PvP : calcul, settlement atomique, XP, statistiques, loot, quête `arena_win` et notifications.
- Ajout de l’API `/api/arena` et de l’écran partagé `shared/screens/arena.js` pour la Mini App Telegram et l’application Web.
- Les résumés de récompenses des quêtes lisent désormais `mission_log` au lieu de recalculer les boosts courants.
- Suite complète : 287 tests passés.

## Parité Bot / Mini App / Web — Travail — 2026-11-10

- Ajout de `gameplay/work.py`, service métier indépendant de Telegram et FastAPI.
- Le bot et l’API partagent désormais préparation, cooldown, présence, gain, XP, énergie, biens produits, promotion et notification des missions freelance.
- Le mini-jeu Telegram reste interactif; il ne porte plus les mutations économiques.
- Ajout de tests contractuels du service commun; suite complète : 285 tests passés.

## Correctif démarrage API — 2026-11-09

- `webapp/server.py` exécute maintenant les migrations internes et additionnelles avant d’accepter les requêtes.
- Corrige le `500 /api/profile` observé sur Hostrix avec `sqlite3.OperationalError: no such table: characters`.
- La Mini App et l’application Web peuvent démarrer avant le polling Telegram tout en obtenant le même schéma SQLite.
- Les pages et scripts sous `/shared/`, `/tg/` et `/app/` sont maintenant envoyés avec `Cache-Control: no-store` pour que les joueurs reçoivent automatiquement les mises à jour.
- Le réseau social partagé inclut maintenant stories (avec cooldown commun), lives, dons, chat de live et notifications côté Mini App/Web.

## Dette technique : consolidation

- **Matplotlib retiré** (dépendance et code) : `/graphstats` affiche des courbes en texte (sparklines Unicode).
- **Boosts** : Boost XP x2 et Boost €A x2 ne sont plus en vente (pay-to-win). Les boosts déjà actifs vont à leur terme. Le Pack Ultime ne contient plus que Premium 90 j et les boosts de confort (Chance, Jardin, Vitesse).
- **Un seul panneau staff** (`handlers/staff.py`, `utils/staff.py`) : `/admin` (alias `/admin_help`, `/adminpanel`, `/monrole`) ouvre un panneau à boutons par niveau. `/staff_nommer`, `/revoquer` (motif obligatoire), `/staff_promouvoir`, `/recours` (7 jours, Lead Principal). Les anciennes commandes de nomination restent comme alias. `admin_roles.py` ne garde que le nettoyage planifié.
- **Créneaux des admins** (migration 29) : `/creneau`, `/creneaux`, `/presence` (confirmation d'arrivée, retard mesuré), capture automatique du journal, `/passation` (formulaire de fin de créneau envoyé aux Game Leaders), `/passations`, `/presences`, `/audit` (qui a fait quoi à qui). Le journal staff est horodaté en temps réel (`admin_logs.real_ts`).
- **Markdown → HTML** : 173 envois convertis dans le code source (valeurs dynamiques échappées). Il en reste 19, couverts par la conversion à l'exécution (`utils/html_guard.py`).
- **Réseaux fusionnés** (migration 30) : les stories rejoignent `rp_posts` (`kind='story'`, `expires_at`), la table `social_stories` (jamais lue) est supprimée, les stories expirées sont purgées par la maintenance sociale. Les fils et compteurs ne comptent que `kind='post'`.
- **Module entreprises éclaté** : `handlers/companies.py` passe de 3 100 à 1 880 lignes. Nouveaux modules : `utils/company_ops.py` (mouvements d'argent atomiques), `handlers/company_products.py`, `handlers/company_deals.py` (fusions, contrats), `handlers/company_shares.py` (parts, dividendes). Les noms restent importables depuis `handlers.companies`. Les trois commandes de personnalisation de produit partagent un même socle.

## Staff selon la charte GAME FRENCH : motifs, rôles, Lead Influenceurs

- **Motif obligatoire** (`motif_required`, `handlers/admin.py`) sur 50 commandes qui touchent un joueur : sanctions (`/warn`, `/banuser`, `/freezeuser`, `/forceprison`…), corrections de profil, items, économie lourde, `/killuser`, `/deleteuser`. Sans motif, la commande est refusée. Le motif est envoyé TEL QUEL au joueur (message direct + notification) et inscrit au journal. Syntaxe : `/warn @u spam répété`, ou `/addbank @u 5000 | compensation bug` (le « | » isole toujours le motif).
- **Rôles selon la charte** : l'Admin N1 ne sanctionne plus (`/warn` et `/clearwarn` passent Admin N2). Le Lead Studio devient purement technique (niveau consultation, plus `/reloadconfig` et `/fix_inventory`), il ne sanctionne plus et ne touche plus à l'économie. Nouveau rôle **Lead Influenceurs** (`LEAD_INFLUENCEURS_IDS` dans `.env`, ou nomination par le Lead Principal avec `/staff_nommer lead_influenceurs @u`).
- **Droits du Lead Influenceurs** (migration 31, `handlers/campaigns.py`) : `/campagne titre | message` ; le Lead Staff Global la relit avec `/campagnes`, la diffuse avec `/campagne_valider id` ou la refuse avec `/campagne_refuser id motif` (motif envoyé à l'auteur). Une seule campagne diffusée par tranche de 12 h, 3 campagnes en attente maximum.
- **Panneau `/admin` refait** : sections par rôle (support, sanctions, corrections de profil, santé, équipe et créneaux, items, gangs, économie, monde, campagnes, pouvoirs absolus, technique), accessible aussi au Lead Influenceurs.

## Motifs, rôles transverses, derniers envois HTML

- **Motif obligatoire** étendu aux commandes qui visent un joueur : relations, mariages, familles, propriétés, véhicules, embauche forcée, cooldowns, godmode, time travel, spawn, missions, loto, items. Les commandes de gang, de marché, de prix et de diffusion n'ont pas de joueur ciblé et n'en demandent pas.
- **Rôles transverses** (Lead Studio, Lead Influenceurs) : niveau 0. Ils n'ont aucune commande de modération ; le Lead Studio garde ses commandes techniques, et le Lead Influenceurs ses campagnes.
- **Arène** : tous les textes de combat et de paris sont en HTML (plus de `**` affichés en clair).

## Retraits

- **Compétitions supprimées** : module `handlers/competitions.py`, commandes `/competition`, `/competition_join`, `/competition_history`, `/defi` (alias erroné), commandes admin `/comp_start`, `/comp_end`, `/comp_add_score`, cycle automatique, classement « Compétition en cours », notifications de compétition, hooks d'XP/argent/arène/crimes/voyages/réseaux dans les modules concernés.
- **Héritage et réincarnation supprimés** : module `handlers/legacy.py`, commandes `/legacy` et `/reincarnate`, entrées de menu « Héritage » et « Réincarnation », mention dans l'aide.
- Un mort (santé à zéro) n'est plus renvoyé vers `/reincarnate` : il est « à terre » et doit aller à l'hôpital (menu Vie → Hôpital), comme le prévoit déjà le message DOWN_TEXT.
- Migration 28 : suppression des tables `competitions`, `competition_scores`, `competition_participants` (les colonnes `legacy_level` ne sont plus créées ; les bases existantes la gardent sans effet).
- Création de produits supprimée (`cmd_creer_produit`, décision de conception).

## Progression : rééquilibrage

- **Courbe de niveau** : `XP_LEVEL_BASE` passe de 500 à 250 (config.py). Niveau L atteint à (L-1)² × 250 XP. Niveau 10 : 20 250 XP (contre 40 500). Niveau 50 : 600 250 XP (contre 1 200 500). Un joueur monte donc deux fois plus vite, et les paliers de succès (niveaux 10, 25, 50, 100) sont atteints plus tôt. Le réglage se fait en une seule constante.
- **Menu Progression** : rubriques réduites à ce qui concerne la progression (parcours, objectifs, évolution, titres et badges). Les entrées compétition et héritage sont retirées.
- **Parcours** : ne montre plus la compétition ; bouton « Compétition » retiré.
- **Tutoriel, étape multijoueur** : validée par un duel d'arène uniquement.

## Corrections de bugs

- **B1 Markdown** : les messages en Markdown v1 (`**gras**`, pseudos avec `_`) sont convertis en HTML avant envoi (utils/html_guard.py). Plus de `**` affichés.
- **B2 Résultat pierre-papier-ciseaux** : résolu par la conversion ci-dessus ; si Telegram refuse malgré tout le balisage, le message part en texte brut au lieu d'être perdu.
- **B3 Dormir** : bilan de sommeil affiché (même mécanisme que B1).
- **B4 Erreurs silencieuses** : 102 blocs `except … : pass` journalisent désormais l'erreur (utils/swallow.py, niveau DEBUG).
- **B5 Console staff visible** : « Console staff » et « Dossier d'entretien » ne sont plus affichés aux joueurs (handlers/hub.py).
- **B6 Aide** : mention « taper une commande » supprimée ; « Héritage » et « Compétitions » retirées de l'aide.
- **B7 Création de produits** : commande supprimée.
- **B8 Signalements** : « Signalements » et « Signaler un joueur » regroupés dans Crime & sécurité.
- **B9 Unité des salaires** : la nomination dans une faction affiche « /h de jeu » pour les factions payées à l'heure (santé, police, armée, justice) et « /jour » pour les autres.
- **B10 Import Telegram** : `SimpleUpdateProcessor` est importé de façon défensive ; si la version installée ne le fournit pas, le bot démarre avec le traitement par défaut au lieu de planter.
- **Nouveau** : `handlers/tresor.py` utilisait `TAX_FACTOR_STEP` sans l'importer : l'écran des impôts plantait.

## Non traité dans cette version

- Fusion du Réseau RP et des réseaux sociaux (fonctionnalité, prévue dans la feuille de route).
- Nettoyage des dossiers `tools/`, `scripts/` et `test/` (à trier avec le mainteneur).
- Vérification de `SimpleUpdateProcessor` avec la version fixée dans requirements.txt (à faire à l'installation).
- Les tests pytest n'ont pas été exécutés (environnement sans Telegram) ; certains tests de `test/test_html_guard.py` supposent l'ancien comportement du Markdown.

## Mise à jour finale

- `test/test_html_guard.py` : tests alignés sur le nouveau comportement (Markdown converti, repli en texte brut) ; 12 tests passent.
- `tools/check_hub.py` : simule un joueur pour le rendu du menu ; le contrôle du menu passe (238 actions, 16 zones, 85 pages).
- `tools/check_forms.py`, `check_help.py`, `smoke_forms.py`, `smoke_flow.py` : passent.
- Fusion Réseau RP / réseaux sociaux : non réalisée au niveau des données (`rp_posts` et tables `social_*` coexistent). Le menu les regroupe déjà dans une seule zone.

## Itération monétisation et qualité

- **Boutique Stars** : retrait de la vente des articles qui donnent directement de l'argent, de l'XP ou du prestige (Sac d'€A, Parchemin XP, Pierre de Prestige, Packs Premiers Pas, Découverte, Entrepreneur, Prestige). Liste `STARS_RETIRED_ITEMS` dans config.py, appliquée à la vente, à la facture et à la pré-validation. Les articles déjà achetés restent utilisables.
- **Abonnements** : bonus réduits. VIP : +10 % revenus, -15 % cooldowns, +5 % casino, +10 % followers, -5 % impôts. Premium : +25 % revenus, -30 % cooldowns, +10 % casino, +25 % followers, -15 % impôts. Textes et docstrings alignés.
- **Packs restants** : Ultime (Premium 90 j + boosts temporaires) ; boosts temporaires conservés (à revoir si l'on veut limiter le pay-to-win).
- **Outils** : `tools/check_names.py` détecte les noms non définis (ce qui a révélé le bug de l'écran des impôts). Intégration continue `.github/workflows/ci.yml` : compilation, noms, formulaires, aide, menu, smoke tests, puis pytest.
- Le guide « Premiers pas » (5 étapes) existe déjà dans le centre d'aide : aucun doublon ajouté.

## Webapp — moteur de publication unique (2026-11-08)
- handlers/social.py : run_post() = moteur unique de publication (bot + application web) ; _execute_post() ne fait plus que l affichage Telegram.
- utils/decorators.py : free_problem() et cooldown_problem() extraites de @require_free / @cooldown (comportement du bot inchange) pour que l application applique exactement les memes regles.
- utils/reseau_rules.py : POST_COOLDOWN_KEY / POST_COOLDOWN_SECONDS partages (delai de 2 h de jeu commun bot + application).
- webapp/routers/reseau_router.py : fil, explorer, likes, abonnements, publication.


## Casino avancé — sept modes accessibles depuis Bot / Mini App / Web — 2026-11-10

- Ajout de parcours Web/Mini App pour slots, Poker vidéo, Blackjack, Roulette, Mines, Crash et PMU via l’écran partagé `webapp/static/shared/screens/casino.js`.
- Extraction des résolutions Blackjack, Roulette, Mines, Crash et PMU dans `gameplay/casino.py`; les handlers Telegram concernés appellent maintenant ces règles partagées.
- Ajout des routes API interactives pour Blackjack, Mines et Crash, et des résolutions Roulette et PMU; les paiements API débitent désormais aussi les mises initiales.
- Vérifications : 328 tests passent après correction du débit initial Roulette/PMU; compilations Python et JavaScript réussies. Les parties d’API à états restent en mémoire et Roulette/PMU n’imitent pas encore les étapes intermédiaires du bot.


## Persistance des sessions casino API — 2026-11-12

La migration DB v33 crée `casino_game_sessions` avec l’identifiant de partie, son propriétaire, son type, son état JSON, son statut, un compteur de révision et les horodatages. Blackjack, Mines et Crash chargent désormais leurs états depuis SQLite à chaque action; le Crash reconstitue son multiplicateur depuis l’heure de départ, sans dépendre d’une tâche vivante en RAM. Les mutations actives passent par une réservation compare-and-swap `active → processing`, puis sauvegardent le nouvel état ou le résultat terminal, ce qui rejette les actions concurrentes et les doubles encaissements. Des tests recréent le pool SQLite entre démarrage et reprise, et vérifient qu’un second règlement ne crédite pas le joueur une seconde fois; la suite complète passe avec 333 tests.

Limite connue : un arrêt brutal après réservation mais avant la finalisation laisse la session en `processing`; elle n’est pas automatiquement rejouée afin d’éviter un double paiement. La transaction atomique unique couvrant à la fois le portefeuille, XP/statistiques/loot et l’état final, ainsi que la persistance des sessions Telegram Mines/Crash, reste à faire.


## Menu principal Mini App / Web — 2026-11-12

Ajout d’un onglet d’entrée « Menu » commun aux deux clients, organisé comme le menu principal Telegram : zones, rubriques et actions chargées à la demande depuis `/api/hub/menu`, qui réutilise le catalogue et les règles de visibilité du bot. Les nouveaux personnages voient les cinq zones essentielles, les raccourcis quotidiens et le bouton de déverrouillage des 16 zones, comme dans le bot. Les actions raccordées ouvrent leur écran jouable correspondant; les zones ou actions encore absentes de l’application restent explicitement identifiées comme telles. Le raccourci Profil donne également accès au Parrainage existant.

## Justice détenu — Mini App/Web — 2026-11-12
- L’écran partagé Rue & justice présente le dossier personnel, son état, la peine restante, la caution fixée après réduction éventuelle, les avocats en service et le suivi d’audience.
- Ajout d’API détenu pour demander une audience, payer une caution décidée par le juge et engager un avocat; ces actions réutilisent `utils.justice` et n’exposent que le dossier du joueur authentifié.
- Les anciennes routes automatiques caution/tribunal/avocat renvoient désormais un refus explicite dès qu’un juge est en poste, comme le parcours Telegram. Le système automatique reste disponible en son absence.
- Les transitions d’audience, l’affectation d’avocat et le paiement de caution sont maintenant protégés par transaction/réservation afin qu’un double clic ou deux requêtes concurrentes ne créent pas de doubles effets.
- Tests ciblés : couverture des routes, projection privée du dossier, refus en présence d’un juge et non-duplication des actions concurrentes; les outils de juge/avocat, mandats, signalements et actions avancées restent à implémenter.


## Éducation — Mini App/Web — 2026-11-12
- `gameplay/education.py` (nouveau) : service métier partagé pour l'inscription aux diplômes, la révision, l'examen par
  questions, sa correction finale et l'achat de niveaux de compétence. Le bot appelait jusqu'ici ces règles directement
  dans `handlers/education.py` (et une seconde fois, dupliquées, dans la commande texte `/etudier`) ; les deux chemins
  appellent maintenant le même service, avec un débit atomique (`BEGIN IMMEDIATE`) pour l'inscription et l'achat de
  compétence.
- `webapp/routers/education_router.py` (nouveau) : `/api/education/home`, `/enroll`, `/revise`, `/courses`, `/exam`,
  `/exam/answer`, `/exam/finish`, `/skill/upgrade` — mêmes refus (fonds insuffisants, diplôme déjà obtenu, ordre imposé,
  formation déjà en cours, pas assez d'énergie, examen non accessible, cours non révisé) que le bot, traduits en codes
  HTTP explicites.
- `webapp/static/shared/screens/education.js` (nouveau), chargé par la Mini App et le Web, onglet « Carrière » (Économie) :
  Formations, Compétences, Mes cours, Examen — avec le même flux en deux temps (verdict puis correction finale) que le
  bot pour la dernière question.
- Le menu principal partagé (`menu.js`) relie désormais la carte Carrière et les actions etudes/etudier/reviser/cours/
  examen/formation/competences vers ce nouvel écran au lieu de les laisser marquées comme non disponibles.
- Limite connue : les tentatives d'examen abandonnées en cours de route ne sont pas purgées par une tâche de maintenance
  dédiée (elles sont simplement remplacées à la prochaine inscription) ; aucun test contractuel n'a encore été ajouté
  pour ce module (pytest indisponible dans cet environnement).
