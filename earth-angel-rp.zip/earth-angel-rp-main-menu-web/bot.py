"""
bot.py — LIFESIM ULTRA V2 — GAME FRENCH
═══════════════════════════════════════════════════════════════════════
Point d'entrée principal avec hiérarchie admin complète.
"""
import asyncio
import logging
import random
import aiosqlite
import time

from telegram import Update
from telegram.ext import (
    Application, ApplicationHandlerStop,
    CommandHandler, MessageHandler,
    CallbackQueryHandler, filters, TypeHandler,
    ContextTypes, PreCheckoutQueryHandler,
)

from config import (
    BOT_TOKEN, ADMIN_IDS, MAX_CONCURRENT_UPDATES,
    WEBHOOK_URL, WEBHOOK_PORT, WEBHOOK_LISTEN, WEBHOOK_SECRET,
)
from database import db_connection, init_db, DB_PATH, now, run_migrations as run_db_migrations, prune_old_history
from migrations import run_migrations as run_extra_migrations
from utils.error_handler import error_handler
from utils.ratelimit import rate_limit_middleware, cleanup_rate_limits
from utils.groups import group_guard
from handlers.groups_admin import cmd_autoriser_groupe, cmd_retirer_groupe, cmd_groupes_autorises
from utils.user_locks import run_serialized_per_user
from utils.cooldowns import clear_expired_cooldowns
from utils.job_guard import guarded, guarded_monthly
from utils.scheduler import JobSpec, ResilientScheduler
from utils.backup import backup_job
from utils.bot_registry import set_bot, get_bot
from types import SimpleNamespace

# --- Imports pour les fonctionnalités économiques ---
from handlers.missions import update_mission_progress
from handlers.multiplayer import _bump_relation

# ─── Handlers existants ─────────────────────────────────────────────
from utils.minigames import minigame_callback
from handlers.general import cmd_annuler
from handlers.general import (
    cmd_start, cmd_aide, cmd_menu, cmd_nouveautes, menu_callback,
    cmd_guide, cmd_unknown_command, cmd_about,
    dev_callback, creator_callback,
    cmd_shop, shop_callback, cmd_parrainage, fun_callback,
)
from handlers.shop_stars import cmd_vip
from handlers.boutique import (
    cmd_boutique, sh_callback, star_redirect, precheckout, successful_payment, run_shop_recovery,
)   # 🛍️ boutique v2
from handlers.phone import (
    cmd_phone, phone_callback, cmd_phone_event, cmd_phone_msg,
    cmd_phone_status, add_random_calendar_events,
    handle_phone_input,
    process_phone_maintenance,   # ⭐ NOUVEAU (Étape D.1)
)
from handlers.profile import (
    cmd_profil, cmd_stats, cmd_badges, cmd_bio, cmd_setlocation,
    cmd_niveau, cmd_inventaire, cmd_titres, cmd_karma_view, cmd_topxp,
    cmd_historiquetitres, profile_callback,
)
from handlers.education import (
    cmd_etudes, cmd_etudier, cmd_examen, cmd_reviser, cmd_formation, cmd_cours,
    cmd_competences, education_callback,
)
from handlers.places import cmd_aller, cmd_position, places_callback
from handlers.factions import (
    cmd_factions, cmd_faction, cmd_faction_postuler, cmd_faction_candidatures,
    cmd_faction_accepter, cmd_faction_refuser, faction_cand_callback, cmd_faction_quitter, cmd_faction_nommer,
    cmd_faction_chef, cmd_role,
)
from handlers.work import cmd_promouvoir, work_pick_callback
from handlers.chain import chain_callback
from handlers.rankings import rk_callback
from handlers.realestate import logement_callback, run_housing_charges
from handlers.gangs import (
    gang_join_callback, run_gang_payout,
)
from handlers.market import merchant_offer_callback, expire_merchant_offers
from utils.payroll import run_payroll, run_hourly_production
from handlers.work import run_duty_tick
from utils.factions import migrate_gov_companies, migrate_legacy_jobs
from utils.location import resolve_arrivals
from handlers.economy import (
    cmd_quotidien, cmd_travailler, cmd_metier, cmd_promotion,
    cmd_compte, cmd_payer, cmd_don, cmd_impots, cmd_richesse,
    cmd_dormir, cmd_manger, cmd_loterie, cmd_acheterticket,
    cmd_mestickets, cmd_tirage, economy_callback, lottery_callback
)
from handlers.bank import (
    cmd_banques, cmd_ouvrir, cmd_depot, cmd_retrait, cmd_soldebanque,
    cmd_pret, cmd_rembourser, cmd_mescomptes, process_bank_interests,
)
from handlers.realestate import (
    cmd_proprietes, cmd_acheter_bien, cmd_hypotheque, cmd_mesbiens,
    cmd_vendre_bien, cmd_entretenir,
    cmd_proposer_location, cmd_meslocations, cmd_quitter_logement,
    rental_callback,
)
from handlers.sante import (
    cmd_medecin, cmd_hopital, cmd_medicaments, cmd_assurance, cmd_ambulance, cmd_poste_sante,
    cmd_nommer_dg, cmd_sante_poste, cmd_sante_renvoyer, hop_callback,
)
from handlers.coffre_admin import cmd_coffre, cmd_coffre_ajouter, cmd_coffre_retirer
from handlers.sante_admin import cmd_nommer_pdg, cmd_revoquer_pdg, cmd_sante_audit, cmd_sante_lits
from utils.sante import run_sante_payroll, sante_maintenance
from handlers.ordre import (
    cmd_ordre, cmd_papiers, cmd_signaler, cmd_antihack, cmd_ordre_audit, cmd_crimes_joueurs, ord_callback,
    relay_message_handler,
)
from utils.ordre import run_ordre_payroll, ordre_maintenance
from handlers.health import (
    cmd_sante, cmd_gym,
)
from handlers.crime import (
    cmd_crimes, cmd_commettre, cmd_caution, cmd_tribunal, cmd_avocat,
    cmd_gang, cmd_creergand, cmd_rejoindregang, cmd_quittergang,
    cmd_ganginfo, cmd_gangactions, cmd_gangcaisse, cmd_transfertchef,
    cmd_ganghold, cmd_gangupgrade, cmd_gangclassement, cmd_dissoudregang,
    crime_callback,
)
from handlers.casino import (
    cmd_slots, cmd_blackjack, cmd_roulette, cmd_crash, cmd_poker,
    cmd_mines, cmd_pmu, cmd_casino,
    bj_callback, crash_callback,
    slots_callback, roulette_callback, mines_callback, pmu_callback,
    roulette_number_input,
    casino_menu_callback,
    cleanup_casino_games,   # ✅ Fix #3 : purge des parties abandonnées
)
from handlers.investments import (
    cmd_marche, cmd_acheteraction, cmd_vendreaction, cmd_portefeuille,
    cmd_historique, fluctuate_market,
    investments_callback,
)
from handlers.family import (
    cmd_mariage, cmd_acceptermariage, cmd_divorce as cmd_family_divorce,
    cmd_arbre, cmd_famille,
    cmd_ami, cmd_retirerami, cmd_mesamis, cmd_leaderboard, cmd_adopter, cmd_creer_famille,
    cmd_inviterfamille, cmd_rejoindrefamille, cmd_quitterfamille,
    cmd_transfertclan, cmd_dissoudrefamille,
)
from handlers.travel import (
    cmd_destinations, cmd_voyager, cmd_monstimbre, travel_callback,
)

# ── Vehicles (fusion vehicle.py + vehicles.py — Étape A.2) ────────
from handlers.vehicles import (
    # Catalogue / achat / gestion texte
    cmd_vehicules_liste, cmd_acheter_vehicule, cmd_mes_vehicules,
    cmd_reparer_vehicule, cmd_assurer_vehicule, cmd_vendre_vehicule,
    cmd_vehicule_info,
    # Garage interactif
    cmd_garage, cmd_repair_vehicle, cmd_refuel,
    cmd_garage_select, cmd_garage_repair, cmd_garage_refuel,
    # Maintenance & UI
    process_vehicles_maintenance,
    vehicles_menu_callback,
)
# ── Luxury (commandes VIP) ──────────────────────────────────────────
from handlers.luxury import (
    cmd_luxe, cmd_acheter_luxe, cmd_prestige,
    cmd_classementprestige, cmd_prestigelog,
    cmd_acces_vip, cmd_lieux_vip,
)
from handlers.arena import (
    cmd_defier, cmd_defis, cmd_classement_arene, cmd_parier,
    challenge_callback, rps_callback, coinflip_callback,
    quiz_answer_callback, expire_arena_matches,
)
from handlers.garden import (
    cmd_jardin, cmd_planter, cmd_arroser, cmd_recolter, cmd_vendrecolte,
    garden_callback, process_garden_maintenance,
)
from handlers.companies import (
    cmd_boites, cmd_infoboite, cmd_employes, cmd_postuler, cmd_demissionner,
    cmd_monentreprise, cmd_candidatures, cmd_accepter, cmd_refuser,
    cmd_nommer as cmd_nommer_entreprise, cmd_licencier, cmd_creerboite,
    cmd_dissoudreboite,
    cmd_depotboite, cmd_versersalaires, cmd_logsboite,
    cmd_classement_boites, cmd_parts, cmd_acheterparts, cmd_vendreparts,
    cmd_dividendes, cmd_emplois, cmd_inviter, cmd_repondre_invitation,
    cmd_transfert_entreprise,
    cmd_setsalaire, cmd_negocier, cmd_repondre_offre,
    cmd_rd, cmd_setoverhead, cmd_produits, cmd_setprix,
    cmd_auditboite,
    cmd_annonce, cmd_proposer_contrat, cmd_former, cmd_prime,
    cmd_repondre_contrat,
    company_page_callback,
    process_company_maintenance, cmd_retirerboite, cmd_renommer_entreprise,
    cmd_changer_secteur,
    cmd_donner_produit,
    cmd_supprimer_produit, cmd_retirer_produit,
    cmd_proposer_fusion, cmd_repondre_fusion, cmd_negocier_contrat,
    companies_callback,
)
# ── Social (nouvelle version ultime) ───────────────────────────────
from handlers.social import (
    cmd_plateformes, cmd_poster, cmd_story, cmd_live, cmd_donner_live,
    cmd_sondage, cmd_vote, cmd_analytiques, cmd_creer_communaute,
    cmd_inviter_communaute, cmd_communaute, cmd_rejoindre_communaute,
    cmd_partager, cmd_lancer_tendance,
    cmd_utiliser_tendance, cmd_socialcoins, cmd_donner_socialcoins,
    cmd_collab, cmd_vendre_followers, cmd_noter_social,
    cmd_classement_social, cmd_resultats_sondage,
    cmd_mesabonnes, collab_callback_handler, buy_followers_callback,
    process_social_maintenance, process_social_revenue,
    social_callback, handle_social_input,
)
# ── Political (nouveau système complet) ────────────────────────────
from handlers.political import (
    cmd_constitution, cmd_modifierconstitution,
    cmd_lancerelection, cmd_candidater, cmd_voter, cmd_depouiller,
    cmd_proposerloi, cmd_voterloi,
    cmd_nommer as cmd_nommer_politique, cmd_ministres, cmd_revoquer_ministre, cmd_lois, cmd_journal,
    cmd_referendum, cmd_votereferendum,
    cmd_destituer, cmd_signer, cmd_vote_destitution,
    cmd_monposte, cmd_demissionnerposte, cmd_postes,
    political_maintenance, cmd_candidats, cmd_elections,
    political_menu_callback,
)
from handlers.weapons import cmd_noir, cmd_armes, cmd_armurerie, wp_callback
from handlers.justice import cmd_justice, jus_callback
from handlers.team import cmd_hierarchie, cmd_chat, tm_callback
from handlers.reseau import rs_callback            # 🌐 réseau RP entre joueurs
from handlers.annuaire import an_callback          # 🗺️ annuaire des entreprises, gangs, communautés, partis, factions
from handlers.tresor import td_callback            # 🏛️ trésor public (Administration)
from handlers.personnage import pc_callback        # 🪪 personnage : identité RP et avatar
from handlers.reglement import rg_callback         # 📜 règlement RP, esprits, entretien des chefs
from handlers.controle import gc_callback          # 🛠️ console du staff
from handlers.missions import (
    cmd_missions, cmd_missions_completed,
    missions_callback,
)
from handlers.events import cmd_evenements, cmd_eventinfo
from handlers.admin import *  # noqa: F401,F403
from config import ADMIN_IDS
from handlers.achievements import cmd_achievements, cmd_achievements_check
from handlers.notifications import (
    cmd_notifications, cmd_notifications_history, cmd_notifications_clear,
    cmd_broadcast_notify, cmd_notify_user, cmd_notifications_stats,
    process_notifications, clear_old_notifications, wait_for_notifications,
    notifications_callback,
)
from handlers.reporting import (
    cmd_report, cmd_report_user, cmd_myreports,
    cmd_reports_list, cmd_report_handle, cmd_reports_stats,
    report_callback,
    reporting_menu_callback,
)
from handlers.life import cmd_vie, vie_callback
# ── Jobs planifiés auparavant jamais branchés ──────────────────────
from handlers.economy import process_daily_tax, process_lottery_draw
from handlers.crime import process_gang_maintenance
from handlers.education import process_education_maintenance
from handlers.events import process_expired_events, trigger_random_event
from handlers.luxury import process_prestige_decay
from handlers.realestate import process_realestate_maintenance, cmd_propriete_info
from handlers.travel import process_travel_maintenance
from handlers.progression import (
    cmd_tutorial, tutorial_callback,
    cmd_graphstats,
    progression_callback,
)
# ─── Market (pour cargobonus) ────────────────────────────────────────
from handlers.market import (
    cmd_market, cmd_sellitem, cmd_buyitem, cmd_cancelitem,
    cmd_useitem, cmd_myitems, cmd_cargobonus,
    market_page_callback, clean_expired_listings,
    market_callback,
)

# ─── MODULE MULTIJOUEUR ────────────────────────────────────────────────
from handlers.multiplayer import (
    cmd_cadeau, cmd_salutations, cmd_echange,
    cmd_relations, cmd_classements, trade_callback, init_mp_tables,
    process_multiplayer_maintenance,
    multiplayer_callback,
)

# ═══════════════════════════════════════════════════════════════════════════
#              ⭐ HIÉRARCHIE ADMIN — Gestion des rôles (GAME FRENCH)
# ═══════════════════════════════════════════════════════════════════════════
from handlers.staff import register as register_staff, stf_callback
from handlers.campaigns import register as register_campaigns   # 🛡️ panneau staff unique
from handlers.controle import process_admin_roles_cleanup
from utils.staff import shift_tick

# ═══════════════════════════════════════════════════════════════════════════
#         💳 PAIEMENTS & TRANSACTIONS (NOUVEAU — Traçabilité)
# ═══════════════════════════════════════════════════════════════════════════
from handlers.payments import (
    cmd_transactions,
    cmd_transaction_info,
    cmd_balance_stats,
    cmd_admin_action_log,
    cmd_game_logs,
    cmd_stars_revenue,
    transactions_callback,
    balance_stats_callback,
    stars_revenue_callback,
)
from utils.helpers import escape_html
# ─── LOGGING ───────────────────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s — %(name)s — %(levelname)s — %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ─── Instance globale du scheduler ─────────────────────────────────────
scheduler = ResilientScheduler()

# ═══════════════════════════════════════════════════════════════════════════
#           ⚠️ ÉTAPE D.2 : Parties casino perdues au redémarrage
# ═══════════════════════════════════════════════════════════════════════════
async def refund_lost_casino_games():
    """⚠️ Note : les parties actives (casino, quiz arène) sont perdues au redémarrage.
    Comme les mises ont été débitées à l'initiation et qu'on ne peut pas
    savoir si le joueur allait gagner, on ne rembourse PAS automatiquement.
    Ce hook sert juste à logger le problème pour investigation.
    (Le remboursement des matchs d'arène est géré par `expire_arena_matches`.)"""
    logger.warning(
        "♻️ Redémarrage : les parties casino en cours sont perdues. "
        "Les mises déjà débitées ne sont PAS remboursées automatiquement."
    )

# ═══════════════════════════════════════════════════════════════════════════
#              GESTION DES SAISIES : ÉCONOMIE
# ═══════════════════════════════════════════════════════════════════════════
async def resolve_target(target: str) -> int | None:
    """Résout un ID ou un @username en ID utilisateur (ID d'abord)."""
    from utils.user_lookup import resolve_id
    return await resolve_id(target)

async def handle_economy_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Capture les réponses des utilisateurs pour les paiements/dons/dépôts/etc."""
    if not update.effective_user or not update.message or not update.message.text:
        return

    user_id = update.effective_user.id
    text = update.message.text.strip()
    from database import get_user, transfer_money, increment_field, add_life_journal
    from utils.helpers import fmt
    from handlers.bank import cmd_pret, cmd_rembourser
    from handlers.investments import cmd_acheteraction, cmd_vendreaction

    # (paiement / don / dépôt / retrait → utils/input_flow + handlers/economy_flows)

    # --- Gestion PRÊT ---
    if context.user_data.get('awaiting_loan_amount'):
        try:
            amount = int(text)
            context.user_data['pending_loan'] = amount
            context.user_data['awaiting_loan_amount'] = False
            await update.message.reply_text(
                f"💳 <b>Prêt de {escape_html(fmt(amount))}</b>\n\n"
                f"Réponds maintenant avec le nom de la banque.",
                parse_mode="HTML"
            )
            context.user_data['awaiting_loan_bank'] = True
        except ValueError:
            await update.message.reply_text("❌ Montant invalide.")
        return

    if context.user_data.get('awaiting_loan_bank'):
        bank_name = text.strip()
        amount = context.user_data.get('pending_loan', 0)
        if amount <= 0:
            await update.message.reply_text("❌ Aucun montant en attente.")
            return
        fake_user = SimpleNamespace(
            id=user_id,
            username=update.effective_user.username or '',
            full_name=update.effective_user.full_name or 'Joueur',
            first_name=update.effective_user.full_name or 'Joueur',
            last_name='',
            name=update.effective_user.full_name or 'Joueur',
        )
        fake_update = SimpleNamespace(
            effective_user=fake_user,
            message=update.message,
            callback_query=None,
            effective_message=update.message,
        )
        fake_context = SimpleNamespace(args=[str(amount), bank_name])
        await cmd_pret(fake_update, fake_context)
        context.user_data.pop('pending_loan', None)
        context.user_data.pop('awaiting_loan_bank', None)
        return

    # --- Gestion REMBOURSEMENT ---
    if context.user_data.get('awaiting_repayment_amount'):
        try:
            amount = int(text)
            bank_name = context.user_data.get('pending_repayment_bank', '')
            if not bank_name:
                await update.message.reply_text("❌ Aucune banque sélectionnée.")
                return
            fake_user = SimpleNamespace(
                id=user_id,
                username=update.effective_user.username or '',
                full_name=update.effective_user.full_name or 'Joueur',
                first_name=update.effective_user.full_name or 'Joueur',
                last_name='',
                name=update.effective_user.full_name or 'Joueur',
            )
            fake_update = SimpleNamespace(
                effective_user=fake_user,
                message=update.message,
                callback_query=None,
                effective_message=update.message,
            )
            fake_context = SimpleNamespace(args=[str(amount), bank_name])
            await cmd_rembourser(fake_update, fake_context)
            context.user_data.pop('pending_repayment_bank', None)
            context.user_data.pop('awaiting_repayment_amount', None)
        except ValueError:
            await update.message.reply_text("❌ Montant invalide.")
        return

    # --- Gestion ACHAT D'ACTIONS personnalisé ---
    if context.user_data.get('awaiting_marche_buy'):
        asset_name = context.user_data.get('awaiting_marche_buy')
        try:
            qty = int(text)
            if qty <= 0:
                raise ValueError
        except ValueError:
            await update.message.reply_text("❌ Quantité invalide.")
            return
        fake_user = SimpleNamespace(
            id=user_id,
            username=update.effective_user.username or '',
            full_name=update.effective_user.full_name or 'Joueur',
            first_name=update.effective_user.full_name or 'Joueur',
            last_name='',
            name=update.effective_user.full_name or 'Joueur',
        )
        fake_update = SimpleNamespace(
            effective_user=fake_user,
            message=update.message,
            callback_query=None,
            effective_message=update.message,
        )
        fake_context = SimpleNamespace(args=[asset_name, str(qty)])
        await cmd_acheteraction(fake_update, fake_context)
        context.user_data.pop('awaiting_marche_buy', None)
        return

    # --- Gestion VENTE D'ACTIONS personnalisée ---
    if context.user_data.get('awaiting_marche_sell'):
        asset_name = context.user_data.get('awaiting_marche_sell')
        try:
            qty = int(text)
            if qty <= 0:
                raise ValueError
        except ValueError:
            await update.message.reply_text("❌ Quantité invalide.")
            return
        fake_user = SimpleNamespace(
            id=user_id,
            username=update.effective_user.username or '',
            full_name=update.effective_user.full_name or 'Joueur',
            first_name=update.effective_user.full_name or 'Joueur',
            last_name='',
            name=update.effective_user.full_name or 'Joueur',
        )
        fake_update = SimpleNamespace(
            effective_user=fake_user,
            message=update.message,
            callback_query=None,
            effective_message=update.message,
        )
        fake_context = SimpleNamespace(args=[asset_name, str(qty)])
        await cmd_vendreaction(fake_update, fake_context)
        context.user_data.pop('awaiting_marche_sell', None)
        return

    # --- Gestion PROPOSITION DE LOCATION : étape 1 (locataire) ---
    if context.user_data.get('awaiting_rental_target'):
        target = text.strip()
        target_id = await resolve_target(target)
        if not target_id:
            await update.message.reply_text("❌ Utilisateur invalide. Vérifie le @username ou l'ID.")
            return
        if target_id == user_id:
            await update.message.reply_text("❌ Tu ne peux pas te louer ta propre propriété.")
            return

        target_user = await get_user(target_id)
        if not target_user or not target_user.get('registered'):
            await update.message.reply_text("❌ Ce joueur n'est pas enregistré.")
            return

        context.user_data['awaiting_rental_target'] = False
        context.user_data['pending_rental_target_id'] = target_id
        context.user_data['awaiting_rental_amount'] = True

        await update.message.reply_text(
            f"👤 Locataire : <b>{target_user['full_name']}</b>\n\n"
            f"<b>Étape 2/2</b> : Envoie le <b>loyer mensuel</b> (ex: 5000).\n"
            f"<i>(ou appuie sur Annuler)</i>",
            parse_mode="HTML"
        )
        return

    # --- Gestion PROPOSITION DE LOCATION : étape 2 (loyer) ---
    if context.user_data.get('awaiting_rental_amount'):
        try:
            rent = int(text)
            if rent <= 0:
                raise ValueError
        except ValueError:
            await update.message.reply_text("❌ Montant invalide. Envoie un nombre entier positif.")
            return

        prop_index = context.user_data.get('pending_rental_property_index')
        target_id = context.user_data.get('pending_rental_target_id')

        if prop_index is None or target_id is None:
            await update.message.reply_text("❌ Session expirée. Recommence.")
            for k in ('awaiting_rental_amount', 'pending_rental_property_index', 'pending_rental_target_id'):
                context.user_data.pop(k, None)
            return

        context.user_data.pop('awaiting_rental_amount', None)
        context.user_data.pop('pending_rental_property_index', None)
        context.user_data.pop('pending_rental_target_id', None)

        fake_user = SimpleNamespace(
            id=user_id,
            username=update.effective_user.username or '',
            full_name=update.effective_user.full_name or 'Joueur',
            first_name=update.effective_user.full_name or 'Joueur',
            last_name='',
            name=update.effective_user.full_name or 'Joueur',
        )
        fake_update = SimpleNamespace(
            effective_user=fake_user,
            message=update.message,
            callback_query=None,
            effective_message=update.message,
        )
        fake_context = SimpleNamespace(args=[str(prop_index + 1), str(target_id), str(rent)])

        from handlers.realestate import cmd_proposer_location
        await cmd_proposer_location(fake_update, fake_context)
        return

    return

async def noop_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Bouton purement décoratif (ex. « 2/5 ») : on acquitte juste le clic."""
    await update.callback_query.answer()

# ─── Garde globale de rate limit ──────────────────────────────────────
async def global_update_guard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # 🔒 Groupes : le bot ne répond que dans les groupes autorisés (voir utils/groups.py)
    if not await group_guard(update, context):
        raise ApplicationHandlerStop
    if not await rate_limit_middleware(update, context):
        raise ApplicationHandlerStop

# ─── Callbacks pour le cycle de vie de l'application ──────────────────
BOT_COMMANDS = [
    # Une seule commande visible : tout le reste passe par le menu boutons.
    ('start', "🎮 Earth Angel RP"),
]


async def _random_world_event_job() -> None:
    """Déclenche un événement mondial aléatoire et notifie les joueurs actifs."""
    cutoff = now() - 7 * 86400       # actifs dans la semaine
    async with db_connection() as db:
        async with db.execute(
            "SELECT user_id FROM users WHERE last_seen > ? AND registered=1 LIMIT 500",
            (cutoff,)
        ) as cur:
            rows = await cur.fetchall()
    user_ids = [r[0] for r in rows]
    if user_ids:
        await trigger_random_event(get_bot(), user_ids)


async def on_application_start(application: Application) -> None:
    """Démarre le scheduler avec tous les jobs périodiques."""
    set_bot(application.bot)

    # 📋 Liste des commandes affichée dans Telegram (bouton « Menu » / « / »)
    try:
        from telegram import BotCommand
        await application.bot.set_my_commands([BotCommand(c, d) for c, d in BOT_COMMANDS])
    except Exception:
        logger.warning("Impossible d'enregistrer la liste des commandes Telegram", exc_info=True)

    # ⭐ ÉTAPE D.2 : log des parties casino/quiz perdues au redémarrage
    await refund_lost_casino_games()

    await init_db()
    await run_db_migrations()      # migrations internes (database.py)
    await run_extra_migrations()   # migrations additionnelles (migrations.py)
    from utils.shop import seed as seed_shop
    await seed_shop()              # 🛍️ catalogue de la boutique (n'écrase jamais les réglages du staff)
    await init_mp_tables()
    from utils import state_settings
    await state_settings.refresh()           # coefficient d'impôt réglé par le gouvernement
    n_conv = await migrate_gov_companies()   # secteurs d'État → factions (idempotent)
    if n_conv:
        logger.info('🏛️ %s entreprise(s) d\'État converties en factions.', n_conv)
    n_jobs = await migrate_legacy_jobs()     # métiers qualifiés → entreprises/factions (idempotent)
    if n_jobs:
        logger.info('💼 %s ancien(s) métier(s) converti(s).', n_jobs)
    logger.info("✅ Base de données initialisée (avec tables MP, véhicules 2.0, admin_roles, transactions, phone_status).")

    _bot = application.bot

    async def _notifications_job():
        # Attend un signal « nouvelle notification » (≤ 3 s sinon, pour les notifications différées
        # ou insérées sans signal), puis envoie tout de suite. Avant : 1 passage par minute.
        await wait_for_notifications(3.0)
        await process_notifications(_bot)

    scheduler.start([
        JobSpec("bank_interests", process_bank_interests, 3600, 300),
        JobSpec("market_cleanup", clean_expired_listings, 900, 120),
        JobSpec("merchant_offers_expiry", expire_merchant_offers, 900, 150),
        JobSpec("multiplayer_maintenance", process_multiplayer_maintenance, 300, 120),
        JobSpec("political_maintenance", political_maintenance, 300, 180),
        JobSpec("company_maintenance", process_company_maintenance, 1800, 300),
        JobSpec("garden_maintenance", process_garden_maintenance, 900, 120),
        JobSpec("social_maintenance", process_social_maintenance, 600, 180),
        JobSpec("social_revenue", process_social_revenue, 3600, 300, game_time=True),   # 1/24 du revenu/jour par heure DE JEU
        JobSpec("vehicle_maintenance", process_vehicles_maintenance, 1800, 180, game_time=True),
        JobSpec("phone_maintenance", process_phone_maintenance, 3600, 180),   # ⭐ ÉTAPE D.1
        JobSpec("market_fluctuation", fluctuate_market, 900, 180, game_time=True),
        JobSpec("daily_payroll", guarded("daily_payroll", 86400, run_payroll), 600, 600),   # salaires auto (fin de jour de jeu)
        JobSpec("shop_recovery", run_shop_recovery, 300, 120),          # 🛍️ reprise / remboursement des commandes en suspens
        JobSpec("duty_tick", run_duty_tick, 600, 300, game_time=True),   # ⏱️ activité créditée en continu pendant le service
        JobSpec("company_hourly_production", run_hourly_production, 900, 600, game_time=True),   # 🏭 production PAR HEURE de jeu (idempotente)
        JobSpec("sante_hourly_payroll", run_sante_payroll, 900, 300, game_time=True),       # santé : salaire PAR HEURE de jeu (idempotent)
        JobSpec("sante_maintenance", sante_maintenance, 120, 60),                           # appels expirés, lits libérés
        JobSpec("ordre_hourly_payroll", run_ordre_payroll, 900, 300, game_time=True),       # police & armée : salaire PAR HEURE de jeu (idempotent)
        JobSpec("ordre_maintenance", ordre_maintenance, 30, 30),                            # enquêtes ouvertes, menottes/interrogatoires expirés
        JobSpec("travel_arrivals", resolve_arrivals, 30, 60, game_time=True),   # arrivées des trajets RP
        JobSpec("notifications", _notifications_job, 1, 150),   # réactif : voir _notifications_job
        JobSpec("notification_cleanup", clear_old_notifications, 86400, 300),
        JobSpec("rate_limit_cleanup", cleanup_rate_limits, 600, 30),
        JobSpec("cooldown_cleanup", clear_expired_cooldowns, 86400, 120),
        JobSpec("history_prune", guarded("history_prune", 86400, prune_old_history), 3600, 900),
        JobSpec("arena_expiry", expire_arena_matches, 60, 60),
        JobSpec("casino_cleanup", cleanup_casino_games, 600, 60),   # ✅ Fix #3
        JobSpec("database_backup", backup_job, interval=6 * 3600, timeout=900, run_immediately=True),
        JobSpec("admin_roles_cleanup", process_admin_roles_cleanup, 86400, 300),
        JobSpec("staff_shift_tick", shift_tick, 60, 60),   # créneaux admins : début, fin, absences

        # ── Jobs auparavant jamais planifiés ───────────────────────────────
        # Légers, sans effet sur l'équilibrage :
        JobSpec("expired_events", process_expired_events, 600, 60),
        JobSpec("travel_maintenance", process_travel_maintenance, 3600, 60),
        JobSpec("calendar_events", add_random_calendar_events, 6 * 3600, 60, game_time=True),   # idempotent par jour
        # Lents : garde persistant (survit aux redémarrages), tick toutes les 15 min.
        # ⚠️ Impact économique : commente la ligne pour désactiver un job.
        JobSpec("lottery_draw", guarded("lottery_draw", 86400, process_lottery_draw), 900, 300),
        JobSpec("daily_tax", guarded("daily_tax", 86400, process_daily_tax), 900, 600),
        JobSpec("housing_charges", guarded("housing_charges", 86400, run_housing_charges), 700, 300),   # loyers et charges notifiés
        JobSpec("gang_payout", guarded("gang_payout", 86400, run_gang_payout), 800, 300),   # partage du coffre (avant les frais)
        JobSpec("gang_upkeep", guarded("gang_upkeep", 86400, process_gang_maintenance), 900, 300),
        JobSpec("realestate_upkeep", guarded("realestate_upkeep", 86400, process_realestate_maintenance), 900, 600),
        JobSpec("education_cleanup", guarded("education_cleanup", 86400, process_education_maintenance), 900, 120),
        JobSpec("prestige_decay", guarded_monthly("prestige_decay", process_prestige_decay), 3600, 120),   # 1×/mois civil de jeu

        # ── Événements mondiaux aléatoires ─────────────────────────────────
        # Toutes les 4 h de jeu (≈ 1h40 réelles) : choisit et notifie un événement.
        # Lancés automatiquement ; les événements spéciaux restent manuels (Lead Staff Global).
        JobSpec("random_world_event", guarded("random_world_event", 14400, _random_world_event_job), 900, 600, game_time=True),
    ])
    logger.info("✅ Scheduler démarré avec tous les jobs périodiques.")

async def on_application_stop(application: Application) -> None:
    """Arrête proprement le scheduler et fait une sauvegarde finale."""
    try:
        await asyncio.wait_for(backup_job(), timeout=900)
    except Exception:
        logger.exception("Sauvegarde finale impossible")
    await scheduler.stop()
    logger.info("✅ Application arrêtée proprement.")

# ─── TRAITEMENT CONCURRENT DES MISES À JOUR ────────────────────────────
try:
    from telegram.ext import SimpleUpdateProcessor as _SimpleUpdateProcessor
except ImportError:   # version de python-telegram-bot sans ce traitement : on garde le traitement par défaut
    _SimpleUpdateProcessor = None

if _SimpleUpdateProcessor is not None:
    class PerUserUpdateProcessor(_SimpleUpdateProcessor):
        """Joueurs différents en parallèle, messages d'un même joueur en série."""

        async def do_process_update(self, update, coroutine) -> None:
            user = getattr(update, "effective_user", None)
            await run_serialized_per_user(user.id if user else None, coroutine)
else:
    PerUserUpdateProcessor = None

# ─── CONSTRUCTION DE L'APPLICATION ─────────────────────────────────────
def _make_rate_limiter():
    """Limiteur d'appels Telegram (≈30 msg/s global, 1 msg/s par chat, 20/min par groupe).

    Sans lui, un pic provoque des erreurs 429 non gérées dans les handlers. Avec lui, les appels
    sont mis en file et réessayés automatiquement. Nécessite : pip install "python-telegram-bot[rate-limiter]"
    """
    try:
        from telegram.ext import AIORateLimiter
        return AIORateLimiter(
            overall_max_rate=28, overall_time_period=1,      # marge sous les 30/s
            group_max_rate=18, group_time_period=60,         # marge sous les 20/min
            max_retries=3,                                   # réessais auto sur RetryAfter
        )
    except (ImportError, RuntimeError):
        logger.warning("⚠️ AIORateLimiter indisponible (installe python-telegram-bot[rate-limiter]) : "
                       "pas de limitation des appels Telegram.")
        return None

def _strip_player_commands(app) -> None:
    """Le jeu se joue aux boutons : on ne garde comme commandes que /start et celles du staff.

    Les fonctions `cmd_*` restent la logique métier (appelées par les boutons et les formulaires) ;
    seule leur exposition en commande Telegram disparaît.
    """
    from utils.staff_commands import KEEP_COMMANDS
    removed = 0
    for group, handlers in list(app.handlers.items()):
        for h in list(handlers):
            if isinstance(h, CommandHandler) and not (set(h.commands) & KEEP_COMMANDS):
                app.remove_handler(h, group)
                removed += 1
    logger.info("🔘 %s commandes joueur retirées : le jeu se joue aux boutons (reste /start + staff).", removed)


def build_app() -> Application:
    from utils.error_handler import install_photo_safe_edit
    install_photo_safe_edit()   # boutons sous une photo (/start) : pas de crash « no text in the message »
    from utils.html_guard import install_html_guard
    install_html_guard()        # messages avec <b>…</b> sans parse_mode : passés en HTML automatiquement
    builder = (
        Application.builder()
        .token(BOT_TOKEN)
        .concurrent_updates(PerUserUpdateProcessor(MAX_CONCURRENT_UPDATES) if PerUserUpdateProcessor else MAX_CONCURRENT_UPDATES)
        # Une connexion HTTP par update concurrent (+ marge), sinon « pool timeout » sous charge.
        .connection_pool_size(MAX_CONCURRENT_UPDATES * 2)
        .pool_timeout(15)
        .post_init(on_application_start)
        .post_shutdown(on_application_stop)
    )
    _limiter = _make_rate_limiter()
    if _limiter is not None:
        builder = builder.rate_limiter(_limiter)
    app = builder.build()

    # ── Garde globale (rate limit) ─────────────────────────────────
    app.add_handler(TypeHandler(Update, global_update_guard), group=-100)
    # ── Mini-jeux de métier (Vitesse, Mémoire, etc.) ────────────────
    app.add_handler(CallbackQueryHandler(hop_callback, pattern=r"^hop:"))       # 🏥 Santé publique
    app.add_handler(CallbackQueryHandler(tm_callback, pattern=r"^tm:"))         # 👥💬 équipe
    app.add_handler(CallbackQueryHandler(rs_callback, pattern=r"^rs:"))         # 🌐 réseau RP
    app.add_handler(CallbackQueryHandler(an_callback, pattern=r"^an:"))         # 🗺️ annuaire
    app.add_handler(CallbackQueryHandler(td_callback, pattern=r"^td:"))         # 🏛️ trésor public
    app.add_handler(CallbackQueryHandler(pc_callback, pattern=r"^pc:"))         # 🪪 personnage
    app.add_handler(CallbackQueryHandler(rg_callback, pattern=r"^rg:"))         # 📜 règlement RP
    app.add_handler(CallbackQueryHandler(gc_callback, pattern=r"^gc:"))         # 🛠️ console staff
    app.add_handler(CallbackQueryHandler(wp_callback, pattern=r"^wp:"))         # 🔫 armes
    app.add_handler(CallbackQueryHandler(jus_callback, pattern=r"^jus:"))       # ⚖️ justice
    app.add_handler(CallbackQueryHandler(ord_callback, pattern=r"^ord:"))       # 🚓 Ordre public (police & armée)
    app.add_handler(CallbackQueryHandler(minigame_callback, pattern=r"^mg_"))
    # ── Choix « service au poste / petit métier » du /travailler ────
    app.add_handler(CallbackQueryHandler(rk_callback, pattern=r"^rk:"))             # 🏆 tous les classements
    app.add_handler(CallbackQueryHandler(chain_callback, pattern=r"^ch:"))          # 🏭 chaîne métiers → entreprises
    app.add_handler(CallbackQueryHandler(work_pick_callback, pattern=r"^work_pick_"))
    app.add_handler(CallbackQueryHandler(merchant_offer_callback, pattern=r"^mvente_"))
    app.add_handler(CallbackQueryHandler(gang_join_callback, pattern=r"^gjoin_"))
    app.add_handler(CallbackQueryHandler(logement_callback, pattern=r"^logement_"))
    app.add_handler(CallbackQueryHandler(lottery_callback, pattern=r"^lot_"))

    # ═══════════════════════════════════════════════════════════════
    #  ⚠️ ORDRE IMPORTANT : les callbacks spécifiques AVANT les génériques
    # ═══════════════════════════════════════════════════════════════

    # ── Callbacks interactifs ─────────────────────────────────────
    app.add_handler(CallbackQueryHandler(education_callback, pattern=r"^edu_"))
    app.add_handler(CallbackQueryHandler(garden_callback, pattern=r"^garden_"))
    app.add_handler(CallbackQueryHandler(profile_callback, pattern=r"^prof_"))
    app.add_handler(CallbackQueryHandler(crime_callback, pattern=r"^crime_"))
    app.add_handler(CallbackQueryHandler(travel_callback, pattern=r"^travel_"))
    app.add_handler(CallbackQueryHandler(places_callback, pattern=r"^loc_"))
    app.add_handler(CallbackQueryHandler(fun_callback, pattern=r"^fun_"))
    app.add_handler(CallbackQueryHandler(missions_callback, pattern=r"^miss_"))
    app.add_handler(CallbackQueryHandler(notifications_callback, pattern=r"^notif_"))
    app.add_handler(CallbackQueryHandler(market_callback, pattern=r"^market_(?!page_)"))
    app.add_handler(CallbackQueryHandler(multiplayer_callback, pattern=r"^mp_"))
    app.add_handler(CallbackQueryHandler(progression_callback, pattern=r"^prog_"))
    app.add_handler(CallbackQueryHandler(
        reporting_menu_callback,
        pattern=r"^(report_menu|report_my_list)$"
    ))
    app.add_handler(CallbackQueryHandler(casino_menu_callback, pattern=r"^cas_"))
    app.add_handler(CallbackQueryHandler(companies_callback, pattern=r"^comp_"))
    app.add_handler(CallbackQueryHandler(vehicles_menu_callback, pattern=r"^veh_"))
    app.add_handler(CallbackQueryHandler(political_menu_callback, pattern=r"^pol_"))

    # Callbacks filtres
    app.add_handler(CallbackQueryHandler(transactions_callback, pattern=r"^tx_filter_"))
    app.add_handler(CallbackQueryHandler(balance_stats_callback, pattern=r"^bal_filter_"))
    app.add_handler(CallbackQueryHandler(stars_revenue_callback, pattern=r"^rev_filter_"))

    # ── Menu principal ────────────────────────────────────────────
    app.add_handler(CallbackQueryHandler(menu_callback, pattern=r"^menu_"))

    # ── General ─────────────────────────────────────────────────────
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("aide", cmd_aide))
    app.add_handler(CommandHandler("help", cmd_aide))
    app.add_handler(CommandHandler("guide", cmd_guide))
    app.add_handler(CommandHandler("menu", cmd_menu))
    app.add_handler(CommandHandler("parrainage", cmd_parrainage))
    app.add_handler(CommandHandler("nouveautes", cmd_nouveautes))
    app.add_handler(CommandHandler("vie", cmd_vie))
    app.add_handler(CommandHandler("shop", cmd_shop))
    app.add_handler(CallbackQueryHandler(shop_callback, pattern=r"^shop_"))
    app.add_handler(CallbackQueryHandler(tutorial_callback, pattern=r"^tutorial_"))
    app.add_handler(CommandHandler("about", cmd_about))
    app.add_handler(CallbackQueryHandler(dev_callback, pattern="^dev_info$"))
    app.add_handler(CallbackQueryHandler(creator_callback, pattern="^creator_info$"))

    # ── Boutique Étoiles ──────────────────────────────────────────
    app.add_handler(CommandHandler("vip", cmd_vip))
    app.add_handler(CommandHandler("boutique", cmd_boutique))
    app.add_handler(CallbackQueryHandler(sh_callback, pattern=r"^sh:"))                  # 🛍️ boutique v2
    app.add_handler(CallbackQueryHandler(star_redirect, pattern=r"^(star_|starbuy:)"))   # anciens boutons → nouvelle boutique
    app.add_handler(PreCheckoutQueryHandler(precheckout))
    app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment))

    # ── Paiements, Transactions & Logs ────────────────────────────
    app.add_handler(CommandHandler("transactions", cmd_transactions))
    app.add_handler(CommandHandler("transaction_info", cmd_transaction_info))
    app.add_handler(CommandHandler("balance_stats", cmd_balance_stats))
    app.add_handler(CommandHandler("admin_action_log", cmd_admin_action_log))
    app.add_handler(CommandHandler("game_logs", cmd_game_logs))
    app.add_handler(CommandHandler("stars_revenue", cmd_stars_revenue))

    # ── Phone ───────────────────────────────────────────────────────
    app.add_handler(CommandHandler("phone", cmd_phone))
    app.add_handler(CommandHandler("phone_event", cmd_phone_event))
    app.add_handler(CommandHandler("phone_msg", cmd_phone_msg))
    app.add_handler(CallbackQueryHandler(phone_callback, pattern=r"^phone_"))
    app.add_handler(CommandHandler("status", cmd_phone_status))

    # ── Profile ─────────────────────────────────────────────────────
    app.add_handler(CommandHandler("profil", cmd_profil))
    app.add_handler(CommandHandler("me", cmd_profil))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CommandHandler("badges", cmd_badges))
    app.add_handler(CommandHandler("bio", cmd_bio))
    app.add_handler(CommandHandler("lieu", cmd_setlocation))
    app.add_handler(CommandHandler("niveau", cmd_niveau))
    app.add_handler(CommandHandler("inventaire", cmd_inventaire))
    app.add_handler(CommandHandler("titres", cmd_titres))
    app.add_handler(CommandHandler("karma", cmd_karma_view))
    app.add_handler(CommandHandler("topxp", cmd_topxp))
    app.add_handler(CommandHandler("historiquetitres", cmd_historiquetitres))

    # ── Education ───────────────────────────────────────────────────
    for c, h in [
        ("etudes", cmd_etudes), ("etudier", cmd_etudier),
        ("examen", cmd_examen), ("reviser", cmd_reviser), ("cours", cmd_cours),
        ("formation", cmd_formation), ("competences", cmd_competences)
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── Economy ─────────────────────────────────────────────────────
    eco_cmds = {
        "quotidien": cmd_quotidien, "daily": cmd_quotidien,
        "travailler": cmd_travailler, "work": cmd_travailler,
        "metier": cmd_metier,
        "compte": cmd_compte, "acc": cmd_compte,
        "impots": cmd_impots, "richesse": cmd_richesse, "richlist": cmd_richesse,
        "dormir": cmd_dormir, "manger": cmd_manger,
        "loterie": cmd_loterie, "loto": cmd_loterie,
        "acheterticket": cmd_acheterticket,
        "mestickets": cmd_mestickets, "tirage": cmd_tirage,
        "promotion": cmd_promotion,
    }
    for c, h in eco_cmds.items():
        app.add_handler(CommandHandler(c, h))

    # ── Bank ────────────────────────────────────────────────────────
    bank_cmds = {
        "banques": cmd_banques, "banks": cmd_banques, "ouvrir": cmd_ouvrir,
        "openbank": cmd_ouvrir,
        "soldebanque": cmd_soldebanque, "pret": cmd_pret,
        "rembourser": cmd_rembourser, "mescomptes": cmd_mescomptes,
    }
    for c, h in bank_cmds.items():
        app.add_handler(CommandHandler(c, h))

    # ── Real Estate ─────────────────────────────────────────────────
    re_cmds = {
        "proprietes": cmd_proprietes, "acheter": cmd_acheter_bien,
        "hypotheque": cmd_hypotheque, "mesbiens": cmd_mesbiens,
        "vendre": cmd_vendre_bien,
        "entretenir": cmd_entretenir,
        "propriete_info": cmd_propriete_info,
        "proposer_location": cmd_proposer_location,
        "meslocations": cmd_meslocations,
        "quitter_logement": cmd_quitter_logement,
    }
    for c, h in re_cmds.items():
        app.add_handler(CommandHandler(c, h))

    # ── Health ──────────────────────────────────────────────────────
    health_cmds = {
        "sante": cmd_sante, "medecin": cmd_medecin, "hopital": cmd_hopital,
        "gym": cmd_gym, "medicaments": cmd_medicaments, "assurance": cmd_assurance,
        "ambulance": cmd_ambulance, "poste_sante": cmd_poste_sante,
        "nommer_pdg": cmd_nommer_pdg, "revoquer_pdg": cmd_revoquer_pdg, "nommer_dg": cmd_nommer_dg, "sante_poste": cmd_sante_poste,
        "sante_renvoyer": cmd_sante_renvoyer, "sante_audit": cmd_sante_audit, "sante_lits": cmd_sante_lits,
        "coffre": cmd_coffre, "coffre_ajouter": cmd_coffre_ajouter, "coffre_retirer": cmd_coffre_retirer,
    }
    app.add_handler(CommandHandler("hierarchie", cmd_hierarchie))     # 👥 annuaire de la faction / entreprise
    app.add_handler(CommandHandler("chat", cmd_chat))                 # 💬 chats d'équipe
    ordre_cmds = {
        "ordre": cmd_ordre, "papiers": cmd_papiers, "signaler": cmd_signaler,
        "antihack": cmd_antihack, "ordre_audit": cmd_ordre_audit, "crimesjoueurs": cmd_crimes_joueurs,
    }
    for c, h in ordre_cmds.items():
        app.add_handler(CommandHandler(c, h))
    for c, h in health_cmds.items():
        app.add_handler(CommandHandler(c, h))

    # ── Crime ───────────────────────────────────────────────────────
    crime_cmds = {
        "crimes": cmd_crimes, "commettre": cmd_commettre, "caution": cmd_caution,
        "tribunal": cmd_tribunal, "juge": cmd_tribunal, "avocat": cmd_avocat,
        "gang": cmd_gang,





    }
    for c, h in crime_cmds.items():
        app.add_handler(CommandHandler(c, h))

    # ── Casino ──────────────────────────────────────────────────────
    casino_cmds = {
        "slots": cmd_slots, "blackjack": cmd_blackjack,
        "roulette": cmd_roulette, "crash": cmd_crash,
        "poker": cmd_poker, "mines": cmd_mines, "pmu": cmd_pmu,
    }
    for c, h in casino_cmds.items():
        app.add_handler(CommandHandler(c, h))
    app.add_handler(CallbackQueryHandler(bj_callback, pattern=r"^bj_"))
    app.add_handler(CallbackQueryHandler(crash_callback, pattern=r"^crash_cashout:"))
    app.add_handler(CallbackQueryHandler(slots_callback, pattern=r"^slots_spin:"))
    app.add_handler(CallbackQueryHandler(roulette_callback, pattern=r"^roulette_"))
    app.add_handler(CallbackQueryHandler(mines_callback, pattern=r"^mines_"))
    app.add_handler(CallbackQueryHandler(pmu_callback, pattern=r"^pmu_"))
    for _c, _h in {
        "factions": cmd_factions, "faction": cmd_faction, "faction_postuler": cmd_faction_postuler,
        "faction_candidatures": cmd_faction_candidatures, "faction_accepter": cmd_faction_accepter,
        "faction_refuser": cmd_faction_refuser, "faction_quitter": cmd_faction_quitter,
        "faction_nommer": cmd_faction_nommer, "faction_chef": cmd_faction_chef,
        "role": cmd_role, "promouvoir": cmd_promouvoir,
            }.items():
        app.add_handler(CommandHandler(_c, _h))
    app.add_handler(CommandHandler("aller", cmd_aller))
    app.add_handler(CommandHandler("position", cmd_position))
    app.add_handler(CommandHandler("ou", cmd_position))
    app.add_handler(CommandHandler("casino", cmd_casino))

    # ── Investments ────────────────────────────────────────────────
    inv_cmds = {
        "marche": cmd_marche,
        "acheteraction": cmd_acheteraction, "buy": cmd_acheteraction,
        "vendreaction": cmd_vendreaction, "sell": cmd_vendreaction,
        "portefeuille": cmd_portefeuille, "portfolio": cmd_portefeuille,
        "historique": cmd_historique,
    }
    for c, h in inv_cmds.items():
        app.add_handler(CommandHandler(c, h))

    # ── Family ──────────────────────────────────────────────────────
    fam_cmds = {
        "mariage": cmd_mariage, "marry": cmd_mariage,
        "acceptermariage": cmd_acceptermariage, "divorce": cmd_family_divorce,
        "arbre": cmd_arbre, "tree": cmd_arbre, "famille": cmd_famille,
        "creerfamille": cmd_creer_famille, "ami": cmd_ami, "friend": cmd_ami, "retirerami": cmd_retirerami,
        "mesamis": cmd_mesamis, "leaderboard": cmd_leaderboard,
        "adopter": cmd_adopter, "inviterfamille": cmd_inviterfamille,
        "rejoindrefamille": cmd_rejoindrefamille,
        "quitterfamille": cmd_quitterfamille,
        "transfertclan": cmd_transfertclan,
        "dissoudrefamille": cmd_dissoudrefamille,
    }
    for c, h in fam_cmds.items():
        app.add_handler(CommandHandler(c, h))

    # ── Travel ──────────────────────────────────────────────────────
    for c, h in [
        ("destinations", cmd_destinations), ("voyager", cmd_voyager),
        ("monstimbre", cmd_monstimbre)
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── Vehicles (catalogue + gestion texte) ───────────────────────
    for c, h in [
        ("vehicules", cmd_vehicules_liste), ("acheterv", cmd_acheter_vehicule),
        ("mesvehicules", cmd_mes_vehicules), ("reparer", cmd_reparer_vehicule),
        ("assurerv", cmd_assurer_vehicule), ("vendrevehicule", cmd_vendre_vehicule),
        ("vehicule_info", cmd_vehicule_info)
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── Vehicles 2.0 (garage interactif) ───────────────────────────
    app.add_handler(CommandHandler("garage", cmd_garage))
    app.add_handler(CommandHandler("repair", cmd_repair_vehicle))
    app.add_handler(CommandHandler("refuel", cmd_refuel))
    app.add_handler(CallbackQueryHandler(cmd_garage_select, pattern=r"^garage_select_"))
    app.add_handler(CallbackQueryHandler(cmd_garage_repair, pattern=r"^garage_repair_"))
    app.add_handler(CallbackQueryHandler(cmd_garage_refuel, pattern=r"^garage_refuel_"))

    # ── Luxury (VIP) ──────────────────────────────────────────────────
    for c, h in [
        ("luxe", cmd_luxe), ("acheterLuxe", cmd_acheter_luxe),
        ("prestige", cmd_prestige), ("classementprestige", cmd_classementprestige),
        ("prestigelog", cmd_prestigelog)
    ]:
        app.add_handler(CommandHandler(c, h))

    app.add_handler(CommandHandler("acces_vip", cmd_acces_vip))
    app.add_handler(CommandHandler("lieux_vip", cmd_lieux_vip))
    app.add_handler(CommandHandler("cargobonus", cmd_cargobonus))

    # ── Arena ───────────────────────────────────────────────────────
    for c, h in [
        ("defier", cmd_defier), ("defis", cmd_defis),
        ("classementarene", cmd_classement_arene),
        ("parier", cmd_parier), ("combat", cmd_defier),
        ("arena", cmd_defier)
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── Garden ──────────────────────────────────────────────────────
    for c, h in [
        ("jardin", cmd_jardin), ("planter", cmd_planter),
        ("arroser", cmd_arroser), ("recolter", cmd_recolter),
        ("vendrecolte", cmd_vendrecolte)
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── Companies ───────────────────────────────────────────────────
    comp_cmds = {
        "monentreprise": cmd_monentreprise,
        "nommer": cmd_nommer_entreprise,
        "logsboite": cmd_logsboite, "classement": cmd_classement_boites,
        "negocier": cmd_negocier,
        "repondre_offre": cmd_repondre_offre,
        "auditboite": cmd_auditboite,
        "proposer_contrat": cmd_proposer_contrat,
        "repondre_invitation": cmd_repondre_invitation,
        "repondre_contrat": cmd_repondre_contrat,
    }
    for c, h in comp_cmds.items():
        app.add_handler(CommandHandler(c, h))
    app.add_handler(CommandHandler("transfert_entreprise", cmd_transfert_entreprise))
    app.add_handler(CommandHandler("donner_produit", cmd_donner_produit))
    app.add_handler(CommandHandler("retirer_produit", cmd_retirer_produit))
    app.add_handler(CommandHandler("proposer_fusion", cmd_proposer_fusion))
    app.add_handler(CommandHandler("repondre_fusion", cmd_repondre_fusion))
    app.add_handler(CommandHandler("negocier_contrat", cmd_negocier_contrat))

    # ── Social ───────────────────────────────────────────────────────
    social_commands = [
        ("plateformes", cmd_plateformes),
        ("poster", cmd_poster),
        ("story", cmd_story),
        ("live", cmd_live),
        ("donner_live", cmd_donner_live),
        ("sondage", cmd_sondage),
        ("vote", cmd_vote),
        ("analytiques", cmd_analytiques),
        ("creer_communaute", cmd_creer_communaute),
        ("inviter_communaute", cmd_inviter_communaute),
        ("communaute", cmd_communaute),
        ("rejoindre_communaute", cmd_rejoindre_communaute),
        ("partager", cmd_partager),
        ("lancer_tendance", cmd_lancer_tendance),
        ("utiliser_tendance", cmd_utiliser_tendance),
        ("socialcoins", cmd_socialcoins),
        ("donner_socialcoins", cmd_donner_socialcoins),
        ("collab", cmd_collab),
        ("vendre_followers", cmd_vendre_followers),
        ("noter", cmd_noter_social),
        ("classement_social", cmd_classement_social),
        ("mesabonnes", cmd_mesabonnes),
    ]
    for cmd, handler in social_commands:
        app.add_handler(CommandHandler(cmd, handler))
    app.add_handler(CommandHandler("resultats_sondage", cmd_resultats_sondage))
    app.add_handler(CallbackQueryHandler(social_callback, pattern=r"^social_"))

    # ── Political ───────────────────────────────────────────────────
    political_commands = [
        ("constitution", cmd_constitution),
        ("modifierconstitution", cmd_modifierconstitution),
        ("lancerelection", cmd_lancerelection),
        ("candidater", cmd_candidater),
        ("voter", cmd_voter),
        ("depouiller", cmd_depouiller),
        ("proposerloi", cmd_proposerloi),
        ("voterloi", cmd_voterloi),
        ("nommerposte", cmd_nommer_politique),
        ("ministres", cmd_ministres),
        ("revoquerministre", cmd_revoquer_ministre),
        ("lois", cmd_lois),
        ("journal", cmd_journal),
        ("referendum", cmd_referendum),
        ("votereferendum", cmd_votereferendum),
        ("destituer", cmd_destituer),
        ("signer", cmd_signer),
        ("vote_destitution", cmd_vote_destitution),
        ("monposte", cmd_monposte),
        ("demissionnerposte", cmd_demissionnerposte),
        ("postes", cmd_postes),
        ("candidats", cmd_candidats),
        ("elections", cmd_elections),
    ]
    for cmd, handler in political_commands:
        app.add_handler(CommandHandler(cmd, handler))

    # ── Black Market ────────────────────────────────────────────────
    # Marché noir = ARMES uniquement ; hacks seulement sur les joueurs (/crimesjoueurs) ; une seule défense (/antihack)
    for c, h in [
        ("noir", cmd_noir), ("armes", cmd_armes), ("armurerie", cmd_armurerie), ("justice", cmd_justice),
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── Missions / Events ───────────────────────────────────────────
    for c, h in [
        ("missions", cmd_missions), ("missions_completed", cmd_missions_completed),
        ("evenements", cmd_evenements), ("eventinfo", cmd_eventinfo)
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── Achievements ────────────────────────────────────────────────
    for c, h in [
        ("achievements", cmd_achievements),
        ("achievements_check", cmd_achievements_check),
        ("succes", cmd_achievements)
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── Progression avancée ────────────────────────────────────────
    for c, h in [
        ("tutorial", cmd_tutorial),
        ("graphstats", cmd_graphstats),
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── Notifications ───────────────────────────────────────────────
    for c, h in [
        ("notifications", cmd_notifications),
        ("notifications_history", cmd_notifications_history),
        ("notifications_clear", cmd_notifications_clear),
        ("notif", cmd_notifications),
        ("broadcast_notify", cmd_broadcast_notify),
        ("notify_user", cmd_notify_user),
        ("notifications_stats", cmd_notifications_stats)
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── Reporting ───────────────────────────────────────────────────
    for c, h in [
        ("report", cmd_report), ("report_user", cmd_report_user),
        ("myreports", cmd_myreports), ("signalement", cmd_report),
        ("reports_list", cmd_reports_list),
        ("report_handle", cmd_report_handle),
        ("reports_stats", cmd_reports_stats)
    ]:
        app.add_handler(CommandHandler(c, h))

    # ── MULTIJOUEUR ─────────────────────────────────────────────────
    app.add_handler(CommandHandler("cadeau", cmd_cadeau))
    app.add_handler(CommandHandler("salutations", cmd_salutations))
    app.add_handler(CommandHandler("salut", cmd_salutations))
    app.add_handler(CommandHandler("echange", cmd_echange))
    app.add_handler(CommandHandler("trade", cmd_echange))
    app.add_handler(CommandHandler("relations", cmd_relations))
    app.add_handler(CommandHandler("classements", cmd_classements))
    app.add_handler(CommandHandler("tops", cmd_classements))
    app.add_handler(CallbackQueryHandler(trade_callback, pattern=r"^trade_"))

    # ── Admin ───────────────────────────────────────────────────────
    admin_cmds = {
        "addmoney": cmd_addmoney, "removemoney": cmd_removemoney,
        "setmoney": cmd_setmoney, "givemoney": cmd_addmoney,
        "cleardebt": cmd_cleardebt, "setbank": cmd_setbank,
        "resetuser": cmd_resetuser, "banuser": cmd_banuser,
        "unbanuser": cmd_unbanuser, "warn": cmd_warn,
        "clearwarn": cmd_clearwarn, "freezeuser": cmd_freezeuser,
        "unfreezeuser": cmd_unfreezeuser, "setjob": cmd_setjob,
        "setage": cmd_setage, "setkarma": cmd_setkarma,
        "setdiplome": cmd_setdiplome, "setprestige": cmd_setprestige,
        "sethp": cmd_sethp, "setenergy": cmd_setenergy,
        "sethappiness": cmd_sethappiness, "sethunger": cmd_sethunger,
        "setstress": cmd_setstress, "setxp": cmd_setxp,
        "setskill": cmd_setskill, "giveitem": cmd_giveitem,
        "userinfo": cmd_userinfo, "userstats": cmd_userstats,
        "topstats": cmd_topstats,
        "deletecompany": cmd_deletecompany, "listcompanies": cmd_listcompanies,
        "forcehire": cmd_forcehire, "crashmarket": cmd_crashmarket,
        "boommarket": cmd_boommarket, "resetmarket": cmd_resetmarket,
        "setprice": cmd_setprice, "createevent": cmd_createevent,
        "endevent": cmd_endevent, "lotowin": cmd_lotowin,
        "broadcast": cmd_broadcast, "announce": cmd_announce,
        "globalstats": cmd_botstats, "serverstats": cmd_botstats,
        "maintenance": cmd_maintenance, "godmode": cmd_godmode,
        "forceprison": cmd_forceprison, "freeprison": cmd_freeprison,
        "adminlogs": cmd_adminlogs, "resetcooldown": cmd_resetcooldown,
        "clearinventory": cmd_clearinventory, "setproperty": cmd_setproperty,
        "givebadge": cmd_givebadge, "reloadconfig": cmd_reloadconfig,
        "killuser": cmd_killuser, "timetravel": cmd_timetravel,
        "spawn": cmd_spawn,
        "mission_force": cmd_mission_force,
        "resetmissions": cmd_resetmissions,
        "setstock": cmd_setstock,
        "resetworld": cmd_resetworld,
    }
    for c, h in admin_cmds.items():
        app.add_handler(CommandHandler(c, h))

    # Commandes admin supplémentaires
    app.add_handler(CommandHandler("listusers", cmd_listusers))
    app.add_handler(CommandHandler("playerhistory", cmd_playerhistory))
    app.add_handler(CommandHandler("deleteuser", cmd_deleteuser))
    app.add_handler(CommandHandler("addbank", cmd_addbank))
    app.add_handler(CommandHandler("rembank", cmd_rembank))
    app.add_handler(CommandHandler("addprestige", cmd_addprestige))
    app.add_handler(CommandHandler("remprestige", cmd_remprestige))
    app.add_handler(CommandHandler("addxp", cmd_addxp))
    app.add_handler(CommandHandler("remxp", cmd_remxp))
    app.add_handler(CommandHandler("setlevel", cmd_setlevel))
    app.add_handler(CommandHandler("addkarma", cmd_addkarma))
    app.add_handler(CommandHandler("remkarma", cmd_remkarma))
    app.add_handler(CommandHandler("addsocialcoins", cmd_addsocialcoins))
    app.add_handler(CommandHandler("remsocialcoins", cmd_remsocialcoins))
    app.add_handler(CommandHandler("setsocialcoins", cmd_setsocialcoins))
    app.add_handler(CommandHandler("setlocation", cmd_setlocation))
    app.add_handler(CommandHandler("setbio", cmd_setbio))
    app.add_handler(CommandHandler("setcolor", cmd_setcolor))
    app.add_handler(CommandHandler("sethospital", cmd_sethospital))
    app.add_handler(CommandHandler("settravel", cmd_settravel))
    app.add_handler(CommandHandler("setitem", cmd_setitem))
    app.add_handler(CommandHandler("takeitem", cmd_takeitem))
    app.add_handler(CommandHandler("giveallitems", cmd_giveallitems))
    app.add_handler(CommandHandler("listitems", cmd_listitems))
    app.add_handler(CommandHandler("setpropertycond", cmd_setpropertycond))
    app.add_handler(CommandHandler("setvehicle", cmd_setvehicle))
    app.add_handler(CommandHandler("setvehiclecond", cmd_setvehiclecond))
    app.add_handler(CommandHandler("setluxury", cmd_setluxury))
    app.add_handler(CommandHandler("setblackmarket", cmd_setblackmarket))
    app.add_handler(CommandHandler("setrelation", cmd_setrelation))
    app.add_handler(CommandHandler("setmarriage", cmd_setmarriage))
    app.add_handler(CommandHandler("admin_divorce", cmd_admin_divorce))
    app.add_handler(CommandHandler("setfamily", cmd_setfamily))
    app.add_handler(CommandHandler("removefamily", cmd_removefamily))
    app.add_handler(CommandHandler("setcompanytreasury", cmd_setcompanytreasury))
    app.add_handler(CommandHandler("setcompanyreputation", cmd_setcompanyreputation))
    app.add_handler(CommandHandler("setcompanylevel", cmd_setcompanylevel))
    app.add_handler(CommandHandler("addcompanytreasury", cmd_addcompanytreasury))
    app.add_handler(CommandHandler("gang_create_admin", cmd_gang_create_admin))
    app.add_handler(CommandHandler("gang_delete", cmd_gang_delete))
    app.add_handler(CommandHandler("gang_add", cmd_gang_add))
    app.add_handler(CommandHandler("gang_remove", cmd_gang_remove))
    app.add_handler(CommandHandler("gang_set_treasury", cmd_gang_set_treasury))
    app.add_handler(CommandHandler("gang_set_reputation", cmd_gang_set_reputation))
    app.add_handler(CommandHandler("removetreasury", cmd_removetreasury))
    app.add_handler(CommandHandler("fix_inventory", cmd_fix_inventory))

    # ═══════════════ 🛡️ STAFF : panneau unique, nominations, service, carrière ═══════════════
    register_staff(app)
    register_campaigns(app)   # 📣 droits du Lead Influenceurs (campagnes validées par le Lead Staff Global)

    # ─── 🔒 GROUPES AUTORISÉS ───
    app.add_handler(CommandHandler("autoriser_groupe", cmd_autoriser_groupe))
    app.add_handler(CommandHandler("retirer_groupe", cmd_retirer_groupe))
    app.add_handler(CommandHandler("groupes_autorises", cmd_groupes_autorises))

    # ── Marché joueur (items) ──────────────────────────────────────
    app.add_handler(CommandHandler("market", cmd_market))
    app.add_handler(CommandHandler("sellitem", cmd_sellitem))
    app.add_handler(CommandHandler("buyitem", cmd_buyitem))
    app.add_handler(CommandHandler("cancelitem", cmd_cancelitem))
    app.add_handler(CommandHandler("useitem", cmd_useitem))
    app.add_handler(CommandHandler("myitems", cmd_myitems))
    app.add_handler(CallbackQueryHandler(market_page_callback, pattern=r"^market_page_"))
    app.add_handler(CommandHandler("annuler", cmd_annuler))
    app.add_handler(CommandHandler("cancel", cmd_annuler))

    # ── Callbacks divers ────────────────────────────────────────────
    app.add_handler(CallbackQueryHandler(report_callback, pattern=r"^(report_|admin_report)"))
    app.add_handler(CallbackQueryHandler(challenge_callback, pattern=r"^challenge_"))
    app.add_handler(CallbackQueryHandler(rps_callback, pattern=r"^rps\|"))
    app.add_handler(CallbackQueryHandler(coinflip_callback, pattern=r"^coinflip\|"))
    app.add_handler(CallbackQueryHandler(company_page_callback, pattern=r"^company_page_"))
    app.add_handler(CallbackQueryHandler(rental_callback, pattern=r"^rent_"))
    app.add_handler(CallbackQueryHandler(quiz_answer_callback, pattern=r"^quiz_answer\|"))
    # ✅ Boutons « page X/Y » : acquitter le clic (sinon le spinner tourne)
    app.add_handler(CallbackQueryHandler(noop_callback, pattern=r"^noop$"))
    app.add_handler(CallbackQueryHandler(collab_callback_handler, pattern=r"^collab_(accept|refuse)_"))
    app.add_handler(CallbackQueryHandler(buy_followers_callback, pattern=r"^(buy|refuse)_followers_"))

    # ── Callbacks menus interactifs ────────────────────────────────
    app.add_handler(CallbackQueryHandler(vie_callback, pattern=r"^(vie_|manger_|medicaments_|hopital_)"))
    app.add_handler(CallbackQueryHandler(
        economy_callback,
        pattern=r"^(eco_|payer_|don_|banque_|loterie_|metier_|depot_|retrait_|pret_|rembourser_)"
    ))
    app.add_handler(CallbackQueryHandler(investments_callback, pattern=r"^(invest_|marche_|immobilier_)"))

    # ── Catch-all commande inconnue ────────────────────────────────
    app.add_handler(MessageHandler(filters.COMMAND, cmd_unknown_command))

    # ── Gestionnaire d'erreur global ──────────────────────────────
    app.add_error_handler(error_handler)

    # ═══════════════════════════════════════════════════════════════
    #           GESTION DES SAISIES TEXTE (ÉTAPE D.4 — réordonné)
    # ═══════════════════════════════════════════════════════════════
    # Priorité : téléphone (5) > social (10) > roulette (20) > économie (50)
    # Les handlers dans un groupe SUPÉRIEUR s'exécutent APRÈS, donc :
    #   - Téléphone traite en premier (état prioritaire)
    #   - Social ensuite
    #   - Roulette ensuite
    #   - Économie en dernier (bas de pile, capture les restes)

    # Groupe -1 : saisie guidée par boutons (bloque les groupes suivants si une saisie est en attente)
    import handlers.economy_flows  # noqa: F401  (enregistre les @flow)
    from utils.input_flow import flow_message_handler, flow_cancel_callback
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, relay_message_handler),    # 🚓 interrogatoire / entretien relayés
        group=-2,
    )
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, flow_message_handler),
        group=-1,
    )
    app.add_handler(CallbackQueryHandler(flow_cancel_callback, pattern=r"^flow_cancel$"))
    import handlers.forms_companies  # noqa: F401  (formulaires entreprises)
    import handlers.forms_crime  # noqa: F401  (formulaires gangs)
    import handlers.market_flows  # noqa: F401  (formulaires marché)
    import utils.auto_forms  # noqa: F401  (formulaires générés pour toutes les actions à saisie)
    from utils.forms import forms_callback
    app.add_handler(CallbackQueryHandler(forms_callback, pattern=r"^f[mp]:"))
    from handlers.hub import hub_callback
    app.add_handler(CallbackQueryHandler(hub_callback, pattern=r"^(hubr?|hs):"))
    app.add_handler(CallbackQueryHandler(faction_cand_callback, pattern=r"^fcand:"))   # ✅ / ❌ des candidatures
    from handlers.help_center import help_callback
    app.add_handler(CallbackQueryHandler(help_callback, pattern=r"^help:"))

    # Groupe 5 : Téléphone
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, handle_phone_input),
        group=5,
    )

    # Groupe 10 : Réseaux sociaux
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, handle_social_input),
        group=10,
    )

    # Groupe 20 : Roulette
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, roulette_number_input),
        group=20,
    )

    # Groupe 50 : Économie (bas de pile)
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, handle_economy_input),
        group=50,
    )

    _strip_player_commands(app)
    return app

# ═══════════════════════════════════════════════════════════════════════════
#                          MAIN
# ═══════════════════════════════════════════════════════════════════════════
def main():
    app = build_app()
    logger.info("🤖 EARTH ANGEL RP démarré ! Prêt à recevoir des messages.")
    if WEBHOOK_URL:
        logger.info("🌐 Mode webhook : %s (port %s)", WEBHOOK_URL, WEBHOOK_PORT)
        app.run_webhook(
            listen=WEBHOOK_LISTEN,
            port=WEBHOOK_PORT,
            url_path=BOT_TOKEN,
            webhook_url=f"{WEBHOOK_URL}/{BOT_TOKEN}",
            secret_token=WEBHOOK_SECRET or None,
            drop_pending_updates=True,
            allowed_updates=Update.ALL_TYPES,   # indispensable : my_chat_member (bot ajouté à un groupe)
        )
    else:
        app.run_polling(drop_pending_updates=True, allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
