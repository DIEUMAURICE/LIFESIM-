# Parité Bot / Mini App Telegram / application Web

## Décision d’architecture

La Mini App Telegram et l’application Web restent deux parcours distincts, conformément à la demande :

- **Mini App Telegram** : `/tg/`, connexion par `Telegram.WebApp.initData`, identifiant Telegram existant.
- **Application Web** : `/app/`, connexion indépendante par Google, compte de jeu distinct (ID négatif).
- **Gameplay commun** : API FastAPI `/api/...`, même base de données et mêmes règles serveur autant que possible. Les vues spécifiques à une plateforme doivent rester limitées à l’authentification et aux capacités propres à Telegram (par exemple les paiements Stars) ; elles ne doivent pas créer une économie parallèle.

Les deux interfaces chargent les mêmes écrans dans `webapp/static/shared/`. Une fonctionnalité ne doit être considérée comme « à parité » que si ses règles essentielles, ses données et ses conséquences sur la progression sont cohérentes avec le bot, et si le parcours web et Mini App permettent tous deux de l’utiliser.

## État confirmé dans l’archive v9

**API et écrans communs déjà présents** : création de personnage, profil/hub, travail, banque, classements, casino (machines à sous), crime/justice partielle, entreprises (partielle), immobilier (partiel), réseau social, lieux/déplacements, santé, missions, marché, boutique, chaîne, vie quotidienne, téléphone/paramètres, notifications et outils staff limités. Les routes `auth`, `profile`, `rankings`, `notifications` et `phone` ne sont pas toutes des écrans dédiés, mais certains de leurs usages sont accessibles par les écrans communs/Plus.

**Raccordement réalisé dans cette reprise** : la cloche commune ouvre désormais les nouvelles notifications et l’historique sur les deux clients. Les notifications sont échappées avant affichage ; la consultation utilise le comportement existant de l’API, qui marque la file comme délivrée afin d’éviter une double livraison via le bot. La section « Plus » affiche également les cinq notifications récentes.

**Premier correctif de parité implémenté** : `POST /api/life/gym` applique maintenant le même contrôle d’accès « joueur libre » et le cooldown atomique de 12 h que la commande bot. Le statut API et l’écran partagé indiquent le délai restant et désactivent l’action durant ce délai. En cas d’erreur technique après réservation, le cooldown est libéré. Deux tests ciblés vérifient le refus durant le cooldown et le contrôle prison avant réservation. Cela corrige un contournement connu; ce n’est pas encore la parité de toute la boucle de vie.

**Deuxième incrément implémenté** : l’écran Marché partagé permet maintenant de choisir une quantité jusqu’au stock de l’annonce, affiche le prix unitaire et recalcule le total estimé avant confirmation. L’achat passe par la route existante `/api/market/buy`, qui garde la validation transactionnelle du stock et du solde ; les deux clients utilisent donc le même parcours et la même source de vérité.

**Véhicules — parcours étendu** : le showroom/garage et l’API `/api/vehicles` couvrent désormais catalogue, achat, sélection du véhicule actif, réparation, assurance, plein et revente. La vente réutilise la reprise du bot (`60 % × état`), retire le prestige correspondant et efface l’actif s’il s’agit du véhicule vendu. Les mutations d’achat, réparation, assurance, carburant et revente sont transactionnelles. L’entretien périodique reste piloté automatiquement par le bot et certains parcours avancés sont encore à comparer : parité complète non atteinte.

**Voyages touristiques — parcours enrichi** : l’API `/api/travel` et l’écran partagé distinguent toujours le voyage du déplacement local `/api/places`. Le statut présente le blocage total, et peut estimer la destination, le trajet restant et le repos à partir de `travel_log.timestamp` et `travel_until`. Le schéma ne stocke pas séparément les phases : les sous-durées restent donc des estimations, avec un affichage générique si les données ne permettent pas de les reconstituer sûrement. Départ transactionnel, prix/bonheur événementiels, XP, mission et bonus vitesse sont raccordés.

**Écarts connus à fermer avant de considérer le monde comme paritaire** : les modules bot ne sont pas tous exposés par l’API et/ou une interface commune. Les types avancés de véhicules et l’entretien périodique restent à confirmer. L’état voyage n’a pas de phase dédiée persistée par le modèle : trajet/repos affichés sont estimés, et n’équivalent pas à un suivi d’arrivée/résolution distinct. Gangs, mariage/famille, politique, éducation, jardin et beaucoup d’autres systèmes demeurent absents ou partiels. Les noms de modules seuls ne sont pas une preuve de parité : un router peut réutiliser plusieurs handlers et un écran peut appeler plusieurs routes. Les routes staff existantes ne remplacent pas le gameplay joueur.

Un inventaire automatique des noms de fichiers ne constitue donc pas une preuve de parité. La portée fonctionnelle d’un module doit être vérifiée dans son code avant de le marquer terminé.

## Ordre de travail recommandé

1. **Établir la source de vérité** : pour chaque boucle de gameplay, identifier les commandes/handlers bot, règles, cooldowns, coûts, récompenses, contrôles d’accès et effets sur les données ; associer les routers et écrans déjà existants.
2. **Fermer les parcours joueur manquants** : prioriser les systèmes qui créent ou modifient des ressources communes (personnage, santé, activité, économie, inventaire, propriétés, transport, crime/justice, social/multijoueur), en réutilisant les fonctions de règles du bot quand elles sont indépendantes de Telegram.
3. **Garder les identités propres** : ne jamais imposer un compte Telegram à l’utilisateur Web ; préserver les ID négatifs des comptes web et l’authentification Google. Ne jamais faire confiance à un `user_id` envoyé par le navigateur : l’identité vient du JWT vérifié côté serveur.
4. **Traiter les différences externes explicitement** : les capacités dépendant de Telegram (paiement Stars, accès au profil Telegram, notifications Telegram) doivent avoir un parcours Web équivalent lorsque possible ou une explication/solution de remplacement, sans bloquer les utilisateurs Web sur une inscription Telegram.
5. **N’agrandir le jeu qu’après** : compléter le gameplay déjà existant dans les deux parcours avant d’ajouter de nouvelles boucles qui augmenteraient encore l’écart.

## Règle de validation de parité

Pour une fonctionnalité, consigner les parcours Bot, Mini App et Web côte à côte. Une différence est acceptable uniquement si elle découle d’une contrainte de plateforme identifiée et si le joueur conserve une façon équitable d’obtenir les mêmes résultats de jeu. Aucun système ne doit être déclaré complet sur la seule base d’une route HTTP ou d’un bouton visible.

## Audit de reprise — archive v12

La reprise confirme que l’architecture de base est correcte : `/tg/` et `/app/` chargent les mêmes scripts `shared/screens/*.js`, appellent les mêmes routes `/api/...` et partagent la même base. Le manifeste `/manus-routes.json` déclare maintenant explicitement les routes publiques réellement servies.

Les écarts visibles ne sont donc pas des divergences entre la Mini App et le Web, mais des modules encore absents des deux clients : stories/lives avancés, famille, gangs, politique, éducation, jardin, casino hors slots, justice complète et plusieurs boucles d’entreprise. Ils doivent être implémentés une seule fois côté API puis branchés dans l’écran partagé.

La boutique reste volontairement différente uniquement pour la contrainte de paiement : les Étoiles Telegram sont disponibles dans la Mini App, tandis que le Web peut consulter le catalogue mais bloque l’achat tant qu’un moyen de paiement Web n’a pas été choisi et sécurisé. Il ne faut pas simuler ou contourner ce paiement, ni donner au Web une monnaie parallèle.

La liste opérationnelle est maintenue dans `TODO.md`. Aucun de ces modules manquants ne doit être déclaré paritaire sur la seule présence d’un bouton ou d’une route vide.

### Modules fermés dans la reprise suivante

Le parcours Famille & mariage dispose maintenant d’une API et d’un écran partagé pour l’état du mariage, les demandes, l’acceptation, le divorce, la création de clan, les invitations, l’adhésion et la sortie. Les coûts et contrôles d’âge/liberté reprennent ceux du bot.

L’adoption est maintenant branchée sur `gameplay/family.py` par le bot et `/api/family/adopt`; `/tg/` et `/app/` affichent le même arbre parents/enfants. Le service applique le contrôle d’âge (parent d’au moins 25 ans, enfant de moins de 20 ans), la limite de cinq enfants, l’unicité de l’enfant adopté et le débit de 50 000 €A dans la même transaction avec la comptabilité du Trésor.

Le fondateur peut transférer le leadership à un membre du clan ou dissoudre le clan depuis Telegram et l’écran partagé. Les deux parcours appellent `gameplay/family.py`; la dissolution supprime le clan, ses membres et ses invitations en une transaction. La Mini App et le Web demandent confirmation pour cette action irréversible.

Le parcours Gangs dispose d’un annuaire partagé, de la création, des candidatures, de l’acceptation par l’encadrement, de la sortie, des dépôts/retraits de caisse et de l’amélioration de réputation. Les rôles et les coûts sont lus depuis la configuration commune.

Le Jardin dispose d’un écran et d’une API partagés pour les parcelles, la plantation, l’arrosage avec cooldown, la croissance saisonnière et la récolte avec récompenses, production d’intrant et risque des plantes illégales.

### Mise à jour — Sondages sociaux


### Mise à jour — Commentaires et collaborations

Les commentaires sont centralisés dans `gameplay/social_comments.py` et appelés par le flux Telegram et `/api/reseau/posts/{post_id}/comments`. Les limites historiques (200 caractères, 3 par joueur et publication), l’incrément du compteur, le fil des 8 derniers commentaires et la notification de l’auteur sont conservés; le quota est maintenant atomique sous concurrence. Le fil partagé permet de lire et d’écrire les commentaires dans la Mini App et l’application Web.

Les collaborations sont centralisées dans `gameplay/social_collabs.py`; `/api/reseau/collabs` permet d’afficher les demandes reçues/envoyées et les collaborations actives, de créer une demande et de l’accepter ou la refuser. Les types (`live`, `giveaway`, `cross`), le coût de 50 000 €A payé par le proposant uniquement à l’acceptation, la durée de 24 heures de jeu et la récompense de +100 abonnés à chacun sont conservés. À l’acceptation, le service revalide sous transaction le solde du proposant et la disponibilité des deux participants; une demande devenue invalide reste pending sans débit ni récompense. L’onglet Collaborations du script social commun sert `/tg/` et `/app/`, et les notifications Web sont persistées; Telegram conserve ses messages avec boutons natifs.

Plusieurs demandes en attente peuvent toujours coexister; c’est sans danger pour le débit et les récompenses, car l’acceptation ne peut activer une collaboration si l’un des participants est déjà engagé ou si le proposant n’a plus le solde requis. Le module social complet conserve d’autres parcours non couverts, qui restent à vérifier séparément.
