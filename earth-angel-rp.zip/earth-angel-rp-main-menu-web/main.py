"""main.py — Point d'entrée UNIQUE qui lance le bot Telegram ET l'API/mini app/app web
   dans le même processus Python.

Pourquoi ce fichier : sur un hébergeur qui ne propose qu'UN SEUL slot/processus par compte
(ex: Hostrix, Render "free", Railway "hobby"...), on ne peut pas lancer `bot.py` et
`webapp/server.py` séparément. Ce fichier les fait tourner ensemble, dans la même boucle
asyncio, dans le même process — donc dans le même slot.

Si un jour tu passes sur un VPS classique avec plusieurs process possibles (voir
DEPLOIEMENT_WEBAPP.md), tu peux continuer à utiliser `bot.py` et `webapp/server.py`
séparément si tu préfères (plus simple à superviser/redémarrer indépendamment) — ce fichier
n'est qu'une option supplémentaire, rien n'a été retiré.

Démarrage :  python3 main.py
"""
from __future__ import annotations

import asyncio
import logging

import uvicorn
from telegram import Update

from bot import build_app
from config import WEBAPP_LISTEN, WEBAPP_PORT
from webapp.server import app as fastapi_app

logger = logging.getLogger("main")
logging.basicConfig(level=logging.INFO)


async def run_telegram_bot(tg_app):
    """Démarre le bot en polling (mode webhook non géré ici, voir bot.py pour ce cas)."""
    await tg_app.initialize()
    await tg_app.start()
    await tg_app.updater.start_polling(drop_pending_updates=True, allowed_updates=Update.ALL_TYPES)
    logger.info("🤖 Bot Telegram démarré (polling).")
    try:
        await asyncio.Event().wait()   # tourne indéfiniment
    finally:
        await tg_app.updater.stop()
        await tg_app.stop()
        await tg_app.shutdown()


async def run_webapp():
    """Démarre l'API + mini app + app web (uvicorn), sur le port fourni par l'hébergeur."""
    config = uvicorn.Config(fastapi_app, host=WEBAPP_LISTEN, port=WEBAPP_PORT, log_level="info")
    server = uvicorn.Server(config)
    logger.info("🌐 API + mini app + app web démarrées sur %s:%s", WEBAPP_LISTEN, WEBAPP_PORT)
    await server.serve()


async def main():
    tg_app = build_app()
    # Les deux tournent en parallèle dans la même boucle asyncio. Si l'un des deux plante,
    # on arrête tout plutôt que de continuer à moitié (plus simple à superviser/redémarrer).
    await asyncio.gather(run_telegram_bot(tg_app), run_webapp())


if __name__ == "__main__":
    asyncio.run(main())
