# Plan — convergence des règles Bot / Mini App / Web

> Objectif produit au-delà de ce plan : voir `VISION_V10_GATEWAY_ET_UX.md` (bot = porte d'entrée, Mini App/Web = le jeu, ambition UX/UI).

## Décision

Conserver le backend Python/FastAPI et la base SQLite de l’archive pendant la phase de convergence. Conserver les deux interfaces partagées existantes. Ne pas lancer de migration Node.js/React avant la stabilisation des contrats métier.

## Architecture cible progressive

```text
Bot Telegram ───────┐
Mini App Telegram ──┼──> gameplay/<module> ──> database.py / outbox / journal
Application Web ────┘          │
                         règles, transaction,
                         cooldown, récompenses,
                         notifications
```

Les handlers Telegram et les routeurs FastAPI deviennent des adaptateurs : ils convertissent l’entrée/sortie propre à leur plateforme, mais ne recalculent plus les règles du jeu.

## Vague 1 : travail

Créer un service métier complet pour l’action de travail, puis connecter :

- `handlers/work.py` pour les commandes et callbacks Telegram;
- `webapp/routers/work_router.py` pour l’API commune;
- les écrans partagés existants, sans logique économique côté navigateur.

Le service devra centraliser le job sélectionné, présence/localisation, statut libre, cooldown effectif VIP/Premium, grande commande, énergie, salaire, XP, mission, chaîne de production, historique et notifications. Chaque mutation doit être protégée par la sérialisation par joueur et une transaction cohérente.

## Tests contractuels

Ajouter des tests qui initialisent le même joueur et vérifient :

- succès bot/service/API;
- absence de job;
- prison/hôpital ou présence invalide;
- cooldown actif;
- énergie insuffisante;
- mêmes débits, gains, XP, cooldowns, journaux et notifications;
- libération du cooldown en cas d’échec technique.

Les tests ne doivent pas dépendre de Telegram réel ni d’un navigateur réel.

## Vague suivante

Répliquer le même modèle, dans cet ordre : gym/vie, crime/justice, marché/inventaire, jardin, famille/gangs, puis casino avancé et éducation/politique. Chaque module sera déclaré fermé seulement après comparaison bot/API et tests d’effets de bord.

## Frontend

Garder les écrans JavaScript partagés actuels pendant la convergence. Une migration vers React pourra ensuite reprendre les contrats JSON et ne devra changer ni les règles, ni les coûts, ni les résultats. Les capacités propres à Telegram (Stars, initData, notifications Telegram) resteront derrière un adaptateur explicite.

## Contraintes d’exploitation

Ne pas modifier la base de production pendant les tests. Utiliser une base de test isolée. Conserver la règle `REQUIRE_EXISTING_DB=1` en production et ne jamais inclure SQLite ou les sauvegardes dans l’archive de code.
