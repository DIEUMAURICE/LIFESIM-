# Mini app Telegram + Application Web — Earth Angel RP

## Ce qui a été construit (MVP)

Un seul nouveau composant : `webapp/`, un serveur **FastAPI** qui expose :

- une **API JSON** (`/api/...`) utilisée à la fois par la mini app Telegram et par
  l'application web — mêmes données, même base SQLite (`life_sim.db`) que le bot ;
- la **mini app Telegram** (fichiers statiques, `/tg/`) ;
- l'**application web** pour les joueurs sans Telegram (fichiers statiques, `/app/`).

Le bot (`bot.py`) n'est pas modifié dans son fonctionnement : il continue de tourner tel
quel. `webapp/server.py` est un **deuxième processus Python**, indépendant, qui ouvre sa
propre connexion à la même base (SQLite en mode WAL : plusieurs process peuvent lire/écrire
en même temps sans se marcher dessus — c'était déjà configuré dans `database.py`).

### Identifiants joueurs (IMPORTANT)

- Un joueur Telegram garde exactement son ID Telegram habituel (toujours positif).
- Un joueur web (connexion Google, pas de compte Telegram) reçoit un **ID négatif**, généré
  une seule fois et stocké dans une nouvelle table `web_accounts`. Comme les ID Telegram sont
  toujours positifs, il ne peut jamais y avoir de collision — les deux populations de joueurs
  cohabitent dans la même table `users`, avec les mêmes règles de jeu.
- La création de personnage (`utils/character.py`) était déjà écrite sans aucune dépendance à
  Telegram (l'auteur du bot l'avait prévu : voir le commentaire en tête de ce fichier) — la
  mini app et l'app web l'utilisent telle quelle, donc le même écran de création, pour tout
  le monde.

### Portée actuelle (interfaces partagées Web + Mini App)

Les deux clients partagent désormais le même noyau, la même API JSON et les écrans de
`webapp/static/shared/screens/`. Les écrans couvrent notamment personnage/profil, travail,
banque, classement, santé/vie, déplacements locaux, voyages touristiques, showroom/garage,
marché/inventaire, boutique, entreprises (partiel), immobilier (partiel), casino (slots),
crime/justice (partiel), réseau social, missions, chaîne, notifications et outils staff limités.

Le parcours véhicules comprend le catalogue, l’achat, l’activation, l’assurance, la réparation,
le plein et la revente. Le parcours voyage comprend destinations, départ, état/cooldown,
effets événementiels et carnet. L’affichage des phases trajet/repos est une estimation déduite
du journal et de `travel_until` : le modèle ne stocke pas l’heure d’arrivée séparément. Ces
parcours sont des intégrations progressives et **ne constituent pas une parité complète** avec
toutes les commandes/menus du bot. Restent notamment à comparer précisément les véhicules
avancés, l’entretien automatisé, justice complète, gangs/familles/factions, politique,
éducation, jardin, arène et plusieurs boucles d’entreprise et de voyage. La liste d’écarts suivie se trouve dans
`PARITE_BOT_MINIAPP_WEB.md`.

Pour tout nouveau module, vérifier d’abord le handler bot, ses restrictions, coûts, cooldowns,
horloge, tâches périodiques, progressions et effets de bord. Ajouter une API FastAPI qui dérive
l’identité du JWT (jamais d’un identifiant fourni par le navigateur) et un écran partagé. Les
spécificités Telegram doivent rester dans l’adaptateur Telegram ; l’app Web doit conserver son
authentification indépendante par Google.

---

## 1. Variables d'environnement à ajouter (`.env`)

```env
# Session commune mini app + web (OBLIGATOIRE, à générer une seule fois) :
JWT_SECRET=<générer avec: python3 -c "import secrets;print(secrets.token_hex(32))">

# Connexion Google pour l'app web — à créer dans Google Cloud Console > APIs & Services
# > Identifiants > Créer des identifiants > ID client OAuth > type "Application Web".
# Redirect URI autorisé à déclarer côté Google :  https://TON_DOMAINE/api/auth/google/callback
GOOGLE_CLIENT_ID=xxxxxxxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=xxxxxxxx

# URLs publiques (derrière nginx, voir plus bas) :
PUBLIC_API_BASE_URL=https://TON_DOMAINE/api
WEB_BASE_URL=https://TON_DOMAINE/app
WEBAPP_CORS_ORIGINS=https://TON_DOMAINE

# Écoute locale du serveur webapp (nginx fait reverse-proxy dessus) :
WEBAPP_LISTEN=127.0.0.1
WEBAPP_PORT=8000

# Persistance SQL — OBLIGATOIRE en production : chemin situé sur un volume persistant
DATA_DIR=/var/lib/earthangel-rp
DB_PATH=/var/lib/earthangel-rp/life_sim.db
BACKUP_DIR=/var/lib/earthangel-rp/backups
REQUIRE_EXISTING_DB=1
```

`BOT_TOKEN` (déjà existant dans ton `.env`) est réutilisé tel quel pour vérifier les
`initData` de la mini app — rien à changer de ce côté.

### Persistance SQL — point critique

`life_sim.db` ne doit jamais être conservée dans l’arborescence du code déployé sur un
hébergeur dont le filesystem est éphémère. Un redeploy remplace alors le dossier de travail
et une nouvelle base vide peut être créée par `CREATE TABLE IF NOT EXISTS`. Le chemin doit
pointer vers un disque persistant ou un volume monté, par exemple `/var/lib/earthangel-rp`.

`REQUIRE_EXISTING_DB=1` fait échouer le démarrage si le fichier SQL est absent, trop petit,
illisible, incomplet ou invalide. C’est volontaire : mieux vaut un service qui refuse de
démarrer qu’un jeu qui démarre sur une base neuve en donnant l’impression que les données ont
été supprimées. Pour un hébergeur sans volume persistant, il faut utiliser une base externe
(PostgreSQL recommandé) ou migrer vers un plan qui fournit un stockage persistant ; une simple
variable d’environnement ne rend pas le filesystem durable.

Avant chaque redeploy, vérifier que `DB_PATH` et `BACKUP_DIR` sont sur le même volume persistant,
que le dernier fichier `life_sim-*.db.gz` existe et que la sauvegarde est récupérable. Ne jamais
inclure `life_sim.db` dans une nouvelle archive de code comme mécanisme de sauvegarde.

### Créer l’archive de code

Utiliser l’empaqueteur fourni, et non une compression manuelle du dossier :

```bash
python3 scripts/package_deploy.py /tmp/earth-angel-rp-deploy.zip
```

Cette commande exclut systématiquement les bases `*.db`, les fichiers SQLite `-wal`/`-shm`,
les sauvegardes, les secrets `.env`, les caches Python et les logs. La base reste uniquement
sur le volume de données du serveur.

En développement, une base peut être créée automatiquement avec `APP_ENV=development`. En
production, `APP_ENV=production` active le refus de créer une base neuve ; le serveur attend
que `DB_PATH` pointe déjà vers une base existante et valide sur le volume persistant.

## 2. Installer les nouvelles dépendances

```bash
pip install -r requirements.txt --break-system-packages
```

(ajoute `fastapi`, `uvicorn`, `pyjwt`, `httpx` — tout le reste est inchangé)

## 3bis. Hébergeur à un seul slot (ex: Hostrix, Render/Railway "free") — `main.py`

Si ton hébergeur ne te laisse lancer **qu'un seul processus**, n'utilise pas `bot.py` et
`webapp/server.py` séparément : lance **`main.py`** à la place. Il démarre le bot Telegram
ET l'API/mini app/app web ensemble, dans le même processus.

- **Commande de démarrage** (champ "Démarrer" / "Start command") : `python3 main.py`
- Variable `PORT` : fournie automatiquement par l'hébergeur (ex: Hostrix) — ne rien changer,
  `config.py` la lit toute seule.
- Toutes les autres variables d'environnement (section 1 ci-dessus) restent identiques :
  `BOT_TOKEN`, `JWT_SECRET`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`,
  `PUBLIC_API_BASE_URL`, `WEB_BASE_URL`, `WEBAPP_CORS_ORIGINS` — à renseigner dans l'onglet
  "Variables d'environnement" de ton hébergeur (pas besoin de fichier `.env` séparé s'il en
  propose un directement dans son interface).
- Mini app Telegram → `https://TON-SOUS-DOMAINE.hostrix.site/tg/`
- Application web → `https://TON-SOUS-DOMAINE.hostrix.site/app/`
- API → `https://TON-SOUS-DOMAINE.hostrix.site/api/...`

Tu peux ignorer les sections 3, 4 et 5 ci-dessous (systemd + nginx) : c'est la méthode pour
un VPS classique avec plusieurs process possibles, pas pour un hébergeur à un seul slot.

## 3. Lancer les 2 processus sur le même serveur (VPS classique, plusieurs slots possibles)

Deux processus distincts, l'un à côté de l'autre, sur le même serveur :

```bash
# Processus 1 : le bot (inchangé)
python3 bot.py

# Processus 2 : l'API + les 2 interfaces
uvicorn webapp.server:app --host 127.0.0.1 --port 8000
```

### systemd (recommandé en production)

`/etc/systemd/system/earthangel-bot.service` :
```ini
[Unit]
Description=Earth Angel RP - Bot Telegram
After=network.target

[Service]
WorkingDirectory=/opt/earthangel-rp
ExecStart=/opt/earthangel-rp/.venv/bin/python3 bot.py
Restart=always
RestartSec=5
EnvironmentFile=/opt/earthangel-rp/.env

[Install]
WantedBy=multi-user.target
```

`/etc/systemd/system/earthangel-webapp.service` :
```ini
[Unit]
Description=Earth Angel RP - Mini app + App web (API)
After=network.target

[Service]
WorkingDirectory=/opt/earthangel-rp
ExecStart=/opt/earthangel-rp/.venv/bin/uvicorn webapp.server:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=5
EnvironmentFile=/opt/earthangel-rp/.env

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now earthangel-bot earthangel-webapp
sudo systemctl status earthangel-bot earthangel-webapp
```

(adapte `/opt/earthangel-rp` et le chemin du venv à ton serveur)

## 4. nginx — exposer tout sur un seul domaine

```nginx
server {
    listen 443 ssl http2;
    server_name TON_DOMAINE;

    ssl_certificate     /etc/letsencrypt/live/TON_DOMAINE/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/TON_DOMAINE/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

server {
    listen 80;
    server_name TON_DOMAINE;
    return 301 https://$host$request_uri;
}
```

(`certbot --nginx -d TON_DOMAINE` pour le certificat HTTPS — **obligatoire** : Telegram
n'autorise les mini apps qu'en HTTPS)

## 5. Déclarer la mini app auprès de BotFather

Dans la conversation avec **@BotFather** :
1. `/mybots` → choisis ton bot → **Bot Settings** → **Menu Button** → **Configure Menu Button**.
2. Donne l'URL : `https://TON_DOMAINE/tg/`
3. (optionnel) `/newapp` pour aussi déclarer une vraie "Mini App" listée sur le profil du bot,
   avec la même URL.

## 6. Vérifier

- `https://TON_DOMAINE/api/health` → `{"status":"ok"}`
- `https://TON_DOMAINE/app/` → écran "Se connecter avec Google"
- Dans Telegram : bouton Menu du bot → la mini app s'ouvre et connecte automatiquement le
  joueur (même personnage, même argent que `/profil` dans le bot).

---

## Architecture du front (depuis la vague 1)

Le front partagé n'est plus un seul `game.js` : il est découpé en un noyau + un fichier par écran.

```
webapp/static/shared/
  core.js              session, API, navigation, barre du bas, helpers (toast, feuilles, confirmations)
  screens/
    character.js       création du personnage
    home.js            onglet Accueil
    work.js bank.js companies.js realestate.js   onglet Économie
    casino.js crime.js                           onglet Ville
    social.js                                    onglet Social
    admin.js more.js                             onglet Plus (blocs)
```

### Ajouter un module de jeu (ex : santé)

1. **Back** : `webapp/routers/sante_router.py` (réutilise `database.py` / `utils/*.py`), puis
   `app.include_router(...)` dans `webapp/server.py`.
2. **Front** : créer `webapp/static/shared/screens/sante.js` :

```js
(() => {
  EA.sub({
    tab: "jeux", id: "sante", icon: "heart", label: "Santé", order: 30,
    async render(ctx) {            // ctx = { profile, user }
      const d = await EA.api("/sante/status");
      return `<div class="ea-card">...<button class="ea-btn" id="soigner">Se soigner</button></div>`;
    },
    bind() {
      EA.act(document.getElementById("soigner"), async () => {   // anti double-clic + toast d'erreur auto
        await EA.post("/sante/heal");
        EA.refresh();
      });
    },
  });
})();
```
3. Ajouter `"sante"` à la liste `SCREENS` en haut de `core.js`. C'est tout : mini app Telegram
   et app web l'affichent automatiquement.

Outils disponibles : `EA.api / EA.post`, `EA.toast`, `EA.confirm(msg)`, `EA.promptInt(titre)`,
`EA.act(btn, fn)`, `EA.onAll(selecteur, fn)`, `EA.esc(texte)` (**toujours** échapper les textes
venant des joueurs), `EA.go(onglet, sous-onglet)`, `EA.refresh()`, `EA.plusBlock(...)` pour un bloc
dans « Plus », `EA.tab(...)` pour un nouvel onglet.

Test de fumée du front (navigateur headless + API simulée) : `node tools/smoke_front.js`
(nécessite Playwright).
