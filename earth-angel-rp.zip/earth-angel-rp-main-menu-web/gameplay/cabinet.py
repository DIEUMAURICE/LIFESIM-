"""gameplay/cabinet.py — Gouvernement : liste, nomination et révocation des ministres.

Service partagé par `handlers/political.py` (bot) et `webapp/routers/political_router.py`.
Les écritures d'état restent dans `utils/roles.py` (`install_minister`, `remove_minister`),
déjà testées ; ce module ajoute les contrôles (Président en exercice, ministère valide, nommé
éligible), la notification du concerné et l'entrée du journal officiel — une seule fois pour les
deux clients.
"""
from __future__ import annotations

import aiosqlite

import database
from config import CABINET_POSITIONS, MINISTRIES
from utils import politics
from utils.roles import can_play, install_minister, is_president, remove_minister


def resolve_position(text: str) -> str | None:
    wanted = (text or "").strip().lower()
    return next((p for p in CABINET_POSITIONS if p.lower() == wanted), None)


async def government() -> dict:
    """Président en exercice et titulaires de chaque ministère."""
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT po.occupant_id AS user_id, u.full_name FROM political_offices po "
            "JOIN users u ON u.user_id=po.occupant_id WHERE po.poste='Président'"
        ) as cur:
            pres = await cur.fetchone()
        async with db.execute(
            "SELECT c.position, c.occupant_id, u.full_name FROM cabinet_positions c "
            "LEFT JOIN users u ON u.user_id=c.occupant_id"
        ) as cur:
            held = {r["position"]: (r["occupant_id"], r["full_name"]) for r in await cur.fetchall()}
    return {
        "president": {"user_id": pres["user_id"], "name": pres["full_name"]} if pres else None,
        "ministries": [
            {"position": pos, "emoji": info["emoji"], "power": info["power"],
             "occupant_id": held.get(pos, (None, None))[0], "occupant_name": held.get(pos, (None, None))[1]}
            for pos, info in MINISTRIES.items()
        ],
    }


async def appoint(actor_id: int, target_id: int, position: str) -> dict:
    """Le Président nomme `target_id` ministre de `position`."""
    if position not in MINISTRIES:
        return {"ok": False, "reason": "unknown_position"}
    if not await can_play(actor_id):
        return {"ok": False, "reason": "not_player"}
    if not await is_president(actor_id):
        return {"ok": False, "reason": "not_president"}
    if not await can_play(target_id):
        return {"ok": False, "reason": "target_not_player"}
    ok, message = await install_minister(actor_id, target_id, position)
    if not ok:
        return {"ok": False, "reason": "refused", "message": message}
    try:
        await database.add_notification(
            target_id, f"🏛️ Tu es nommé(e) ministre : {position} — {MINISTRIES[position]['power']}.")
    except Exception:
        pass
    await politics.log_event(
        "nomination", f"{await politics.display_name(target_id)} nommé ministre de {position}", target_id)
    return {"ok": True, "position": position, "label": message}


async def dismiss(actor_id: int, position: str) -> dict:
    """Le Président retire le ministère à son titulaire (qui reste directeur de l'Administration)."""
    if position not in MINISTRIES:
        return {"ok": False, "reason": "unknown_position"}
    if not await can_play(actor_id):
        return {"ok": False, "reason": "not_player"}
    if not await is_president(actor_id):
        return {"ok": False, "reason": "not_president"}
    old = await remove_minister(position)
    if old is None:
        return {"ok": False, "reason": "vacant"}
    try:
        await database.add_notification(
            old, f"🏛️ Le Président t'a retiré le ministère {position}. Tu restes directeur de l'Administration.")
    except Exception:
        pass
    await politics.log_event(
        "nomination", f"Ministère {position} retiré à {await politics.display_name(old)}", old)
    return {"ok": True, "position": position, "former_id": old}
