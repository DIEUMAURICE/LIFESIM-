"""Règles métier du casino appelables par Telegram et l’API Web/Mini App."""
from __future__ import annotations

import random

import database
from utils.vip import add_xp, chance_boost_bonus

POKER_MULTIPLIERS = {8: 50, 7: 25, 6: 10, 5: 6, 4: 4, 3: 3, 2: 2, 1: 1, 0: 0}


def poker_hand_rank(hand: list[str]) -> tuple[int, str]:
    """Renvoie le rang historique du bot; les kickers ne départagent pas les mains."""
    rank_vals = {"2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8,
                 "9": 9, "10": 10, "J": 11, "Q": 12, "K": 13, "A": 14}
    vals = sorted([rank_vals.get(c[:-1], 0) for c in hand], reverse=True)
    flush = len({c[-1] for c in hand}) == 1
    if vals == [14, 5, 4, 3, 2]:
        straight = True
        vals = [5, 4, 3, 2, 1]
    else:
        straight = vals == list(range(vals[0], vals[0] - 5, -1))
    counts = sorted([vals.count(v) for v in set(vals)], reverse=True)
    if flush and straight:
        return 8, "Quinte flush"
    if counts[0] == 4:
        return 7, "Carré"
    if counts[:2] == [3, 2]:
        return 6, "Full House"
    if flush:
        return 5, "Couleur"
    if straight:
        return 4, "Suite"
    if counts[0] == 3:
        return 3, "Brelan"
    if counts[:2] == [2, 2]:
        return 2, "Double paire"
    if counts[0] == 2:
        return 1, "Paire"
    return 0, "Hauteur"


async def play_video_poker(user_id: int, amount: int, *, rng=random) -> dict:
    """Distribue et règle une partie de Poker vidéo avec les effets historiques du bot.

    Le contrôle d’accès, la présence, les horaires et la validation de mise sont assurés
    par l’adaptateur avant l’appel. La fonction retourne un résultat canonique commun.
    """
    # Imports différés : handlers.casino adapte aussi ce service sans cycle à l'import.
    from handlers.casino import add_random_item, track_casino

    ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
    suits = ["♠", "♥", "♦", "♣"]
    deck = [rank + suit for rank in ranks for suit in suits]
    rng.shuffle(deck)
    player_hand, dealer_hand = deck[:5], deck[5:10]
    player_rank, player_name = poker_hand_rank(player_hand)
    dealer_rank, dealer_name = poker_hand_rank(dealer_hand)

    if player_rank > dealer_rank:
        multiplier = POKER_MULTIPLIERS[player_rank]
        gross_payout = int(amount * multiplier)
        await database.update_balance(user_id, gross_payout - amount)
        await add_xp(user_id, 30)
        outcome = "win"
    elif player_rank == dealer_rank:
        multiplier = 1
        gross_payout = amount
        await database.update_balance(user_id, 0)
        outcome = "push"
    else:
        multiplier = 0
        gross_payout = 0
        await database.update_balance(user_id, -amount, sink="casino")
        outcome = "loss"

    await track_casino(user_id, amount, gross_payout)
    loot = None
    if gross_payout > amount:
        user = await database.get_user(user_id)
        if rng.random() < 0.3 + chance_boost_bonus(user):
            loot = await add_random_item(user_id, "rare", "legendary")
    final_user = await database.get_user(user_id)
    return {
        "player_hand": player_hand,
        "dealer_hand": dealer_hand,
        "player_rank": player_rank,
        "player_name": player_name,
        "dealer_rank": dealer_rank,
        "dealer_name": dealer_name,
        "outcome": outcome,
        "multiplier": multiplier,
        "bet": amount,
        "gross_payout": gross_payout,
        "net": gross_payout - amount,
        "loot": loot,
        "balance": final_user["balance"],
    }


ROULETTE_RED = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}
PMU_HORSES = [
    {"name": "Éclair Noir", "odds": 2.5, "emoji": "🐴", "weight": 30},
    {"name": "Tonnerre", "odds": 4.0, "emoji": "🐎", "weight": 20},
    {"name": "Vent du Nord", "odds": 6.0, "emoji": "🏇", "weight": 15},
    {"name": "Galaxie", "odds": 10.0, "emoji": "⭐", "weight": 15},
    {"name": "Fantôme", "odds": 15.0, "emoji": "👻", "weight": 12},
    {"name": "Miracle", "odds": 25.0, "emoji": "🎯", "weight": 8},
]


def roulette_payout(amount: int, bet_type: str, spin: int) -> int:
    """Payout brut historique Roulette (mise incluse), sur un résultat 0–36."""
    normalized = bet_type.replace("_", "-")
    if normalized in ("rouge", "red"):
        return amount * 2 if spin in ROULETTE_RED else 0
    if normalized in ("noir", "black"):
        return amount * 2 if spin not in ROULETTE_RED and spin != 0 else 0
    if normalized in ("pair", "even"):
        return amount * 2 if spin != 0 and spin % 2 == 0 else 0
    if normalized in ("impair", "odd"):
        return amount * 2 if spin % 2 == 1 else 0
    if normalized == "1-18":
        return amount * 2 if 1 <= spin <= 18 else 0
    if normalized == "19-36":
        return amount * 2 if 19 <= spin <= 36 else 0
    if normalized == "1-12":
        return amount * 3 if 1 <= spin <= 12 else 0
    if normalized == "13-24":
        return amount * 3 if 13 <= spin <= 24 else 0
    if normalized == "25-36":
        return amount * 3 if 25 <= spin <= 36 else 0
    if normalized.startswith("number:"):
        try:
            chosen = int(normalized.split(":", 1)[1])
        except ValueError:
            return 0
        return amount * 36 if chosen == spin else 0
    return 0


def resolve_roulette(amount: int, bet_type: str, *, rng=random) -> dict:
    """Tirage et calcul du gain Roulette, sans aucun effet de base de données.

    Fonction pure réutilisée par `settle_roulette` (bot, mise déjà débitée en mémoire) et par
    l'API Web (mise débitée et gain crédité dans la même transaction que la session, voir
    `gameplay/casino_sessions.save_claimed_session_with_payout`)."""
    spin = rng.randint(0, 36)
    gross_payout = roulette_payout(amount, bet_type, spin)
    return {
        "bet_type": bet_type,
        "number": spin,
        "color": "red" if spin in ROULETTE_RED else ("black" if spin else "green"),
        "bet": amount,
        "gross_payout": gross_payout,
        "net": gross_payout - amount,
    }


async def settle_roulette(user_id: int, amount: int, bet_type: str, *, stake_predebited: bool = False, rng=random) -> dict:
    from handlers.casino import add_random_item, track_casino
    if not stake_predebited:
        await database.update_balance(user_id, -amount, sink="casino")
    result = resolve_roulette(amount, bet_type, rng=rng)
    gross_payout = result["gross_payout"]
    if gross_payout:
        await database.update_balance(user_id, gross_payout)
        await add_xp(user_id, 25)
    await track_casino(user_id, amount, gross_payout)
    loot = None
    if gross_payout:
        user = await database.get_user(user_id)
        if rng.random() < 0.15 + chance_boost_bonus(user):
            loot = await add_random_item(user_id, "common", "rare")
    result["loot"] = loot
    result["balance"] = (await database.get_user(user_id))["balance"]
    return result


def resolve_pmu(amount: int, chosen_index: int, *, rng=random) -> dict:
    """Course et calcul du gain PMU, sans aucun effet de base de données (voir `resolve_roulette`)."""
    if not 0 <= chosen_index < len(PMU_HORSES):
        raise ValueError("Cheval invalide.")
    remaining = list(range(len(PMU_HORSES)))
    ranking = []
    while remaining:
        weights = [PMU_HORSES[i]["weight"] for i in remaining]
        picked = rng.choices(remaining, weights=weights)[0]
        ranking.append(picked)
        remaining.remove(picked)
    won = ranking[0] == chosen_index
    gross_payout = int(amount * PMU_HORSES[chosen_index]["odds"]) if won else 0
    return {
        "horses": PMU_HORSES,
        "ranking": ranking,
        "chosen_index": chosen_index,
        "winner_index": ranking[0],
        "won": won,
        "bet": amount,
        "gross_payout": gross_payout,
        "net": gross_payout - amount,
    }


async def settle_pmu(user_id: int, amount: int, chosen_index: int, *, stake_predebited: bool = False, rng=random) -> dict:
    from handlers.casino import add_random_item, track_casino
    if not 0 <= chosen_index < len(PMU_HORSES):
        raise ValueError("Cheval invalide.")
    if not stake_predebited:
        await database.update_balance(user_id, -amount, sink="casino")
    result = resolve_pmu(amount, chosen_index, rng=rng)
    gross_payout = result["gross_payout"]
    loot = None
    if result["won"]:
        await database.update_balance(user_id, gross_payout)
        await add_xp(user_id, 40)
        user = await database.get_user(user_id)
        if rng.random() < 0.2 + chance_boost_bonus(user):
            loot = await add_random_item(user_id, "common", "epic")
    await track_casino(user_id, amount, gross_payout)
    result["loot"] = loot
    result["balance"] = (await database.get_user(user_id))["balance"]
    return result


def blackjack_hand_value(hand: list[str]) -> int:
    total, aces = 0, 0
    for current in hand:
        rank = current[:-1]
        if rank in ("J", "Q", "K"):
            total += 10
        elif rank == "A":
            total += 11
            aces += 1
        else:
            total += int(rank)
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total


def _blackjack_card(rng) -> str:
    return rng.choice(["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]) + rng.choice(["♠", "♥", "♦", "♣"])


async def blackjack_start(user_id: int, amount: int, *, rng=random) -> dict:
    """Débite et démarre le Blackjack avec les règles et paiements historiques."""
    from handlers.casino import add_random_item, track_casino
    player = [_blackjack_card(rng), _blackjack_card(rng)]
    dealer = [_blackjack_card(rng), _blackjack_card(rng)]
    if blackjack_hand_value(player) == 21:
        await database.update_balance(user_id, -amount, sink="casino")
        payout = int(amount * 1.5)
        await database.update_balance(user_id, payout)
        await add_xp(user_id, 50)
        await track_casino(user_id, amount, payout)
        user = await database.get_user(user_id)
        loot = await add_random_item(user_id, "rare", "legendary") if rng.random() < 0.3 + chance_boost_bonus(user) else None
        return {"status": "blackjack", "player_hand": player, "dealer_hand": dealer[:1], "bet": amount,
                "gross_payout": payout, "net": payout - amount, "loot": loot,
                "balance": (await database.get_user(user_id))["balance"]}
    await database.update_balance(user_id, -amount, sink="casino")
    return {"status": "active", "player_hand": player, "dealer_hand": dealer,
            "bet": amount, "gross_payout": 0, "net": -amount, "loot": None}


async def blackjack_action(user_id: int, game: dict, action: str, *, rng=random) -> dict:
    """Applique hit/stand/double sur l’état fourni par le dépôt de sessions; état terminal consommé."""
    from handlers.casino import add_random_item, track_casino
    if game.get("status") != "active":
        raise ValueError("Partie Blackjack terminée.")
    if action not in {"hit", "stand", "double"}:
        raise ValueError("Action Blackjack invalide.")
    amount = game["bet"]
    player = game["player_hand"]
    dealer = game["dealer_hand"]
    if action == "hit":
        player.append(_blackjack_card(rng))
        value = blackjack_hand_value(player)
        if value > 21:
            game["status"] = "bust"
            return {"status": "bust", "player_hand": player, "dealer_hand": dealer,
                    "bet": amount, "gross_payout": 0, "net": -amount,
                    "balance": (await database.get_user(user_id))["balance"]}
        return {"status": "active", "player_hand": player, "dealer_hand": dealer,
                "bet": amount, "gross_payout": 0, "net": -amount}
    if action == "double":
        user = await database.get_user(user_id)
        if user["balance"] < amount:
            raise ValueError("Fonds insuffisants pour doubler !")
        await database.update_balance(user_id, -amount, sink="casino")
        amount *= 2
        game["bet"] = amount
        player.append(_blackjack_card(rng))
    while blackjack_hand_value(dealer) < 17:
        dealer.append(_blackjack_card(rng))
    player_value, dealer_value = blackjack_hand_value(player), blackjack_hand_value(dealer)
    if player_value > 21:
        outcome, payout = "loss", 0
    elif dealer_value > 21 or player_value > dealer_value:
        outcome, payout = "win", amount * 2
        await database.update_balance(user_id, payout)
        await add_xp(user_id, 50)
    elif player_value == dealer_value:
        outcome, payout = "push", amount
        await database.update_balance(user_id, payout)
    else:
        outcome, payout = "loss", 0
    await track_casino(user_id, amount, payout)
    loot = None
    if payout > 0:
        user = await database.get_user(user_id)
        if rng.random() < 0.25 + chance_boost_bonus(user):
            loot = await add_random_item(user_id, "common", "epic")
    game["status"] = outcome
    return {"status": outcome, "player_hand": player, "dealer_hand": dealer,
            "bet": amount, "gross_payout": payout, "net": payout - amount,
            "loot": loot, "player_value": player_value, "dealer_value": dealer_value,
            "balance": (await database.get_user(user_id))["balance"]}


MINES_MAX_BET = 200_000


def mines_reveal(game: dict, index: int) -> dict:
    """Transition de plateau Mines, sans effets de présentation Telegram."""
    if game.get("status") != "active":
        raise ValueError("Partie Mines terminée.")
    if not isinstance(index, int) or not 0 <= index < 25:
        raise ValueError("Case invalide.")
    revealed = game["revealed"]
    if index in revealed:
        raise ValueError("Case déjà révélée.")
    revealed.add(index)
    if index in game["mines"]:
        game["status"] = "loss"
        return {"status": "loss", "index": index, "multiplier": game["multiplier"]}
    game["multiplier"] = round(game["multiplier"] + 0.05, 2)
    return {"status": "active", "index": index, "multiplier": game["multiplier"]}


async def mines_cashout(user_id: int, game: dict, *, rng=random) -> dict:
    from handlers.casino import add_random_item, track_casino
    if game.get("status") != "active":
        raise ValueError("Partie Mines terminée.")
    amount = game["amount"]
    payout = int(amount * game["multiplier"])
    await database.update_balance(user_id, payout)
    await add_xp(user_id, 30)
    await track_casino(user_id, amount, payout)
    loot = None
    if payout > amount:
        user = await database.get_user(user_id)
        if rng.random() < 0.1 + chance_boost_bonus(user):
            loot = await add_random_item(user_id, "common", "rare")
    game["status"] = "win"
    return {"status": "win", "bet": amount, "multiplier": game["multiplier"],
            "gross_payout": payout, "net": payout - amount, "loot": loot,
            "balance": (await database.get_user(user_id))["balance"]}


async def mines_lost(user_id: int, game: dict) -> dict:
    from handlers.casino import track_casino
    if game.get("status") != "loss":
        raise ValueError("La partie Mines n’est pas perdue.")
    await track_casino(user_id, game["amount"], 0)
    return {"status": "loss", "bet": game["amount"], "gross_payout": 0,
            "balance": (await database.get_user(user_id))["balance"]}


def mines_layout(*, rng=random) -> set[int]:
    return set(rng.sample(range(25), 5))


def crash_point_from_roll(roll: float) -> float:
    return round(min(100.0, max(1.0, 0.92 / max(roll, 1e-9))), 2)


def advance_crash(game: dict) -> tuple[float, bool]:
    """Un tick historique du bot : +0,05× par 0,15 seconde."""
    game["current_mult"] = round(game["current_mult"] + 0.05, 2)
    crashed = game["current_mult"] >= game["crash_point"]
    if crashed:
        game["running"] = False
        game["status"] = "crashed"
    return game["current_mult"], crashed


async def settle_crash_cashout(user_id: int, game: dict, *, rng=random) -> dict:
    from handlers.casino import add_random_item, track_casino
    if not game.get("running") or game["current_mult"] >= game["crash_point"]:
        raise ValueError("Le jeu a déjà crashé !")
    game["running"] = False
    game["status"] = "cashed_out"
    amount = game["amount"]
    payout = int(amount * game["current_mult"])
    await database.update_balance(user_id, payout)
    await add_xp(user_id, 40)
    await track_casino(user_id, amount, payout)
    loot = None
    if payout > amount:
        user = await database.get_user(user_id)
        if rng.random() < 0.2 + chance_boost_bonus(user):
            loot = await add_random_item(user_id, "rare", "legendary")
    return {"status": "cashed_out", "bet": amount, "multiplier": game["current_mult"],
            "gross_payout": payout, "net": payout - amount, "loot": loot,
            "balance": (await database.get_user(user_id))["balance"]}


def crash_multiplier_at(started_at: float, at_time: float | None = None) -> float:
    """Retourne le multiplicateur découlant des ticks serveur de 0,15 s depuis le départ."""
    import time as _time
    elapsed = max(0.0, (_time.time() if at_time is None else at_time) - float(started_at))
    ticks = int(elapsed / 0.15)
    return round(1.0 + 0.05 * ticks, 2)
