"""Mutations métier communes des gangs pour Telegram et Web."""
from __future__ import annotations

import aiosqlite
import random

from config import GANG_MANAGE_ROLES, GANG_RECRUIT_ROLES, GANG_ROLES
from database import db_connection, get_user, now, update_balance
from utils.notify import notify

CREATE_COST = 50_000
UPGRADE_COST = 100_000


class GangError(Exception):
    pass


ROLE_NAMES = [role for role, _ in GANG_ROLES]


def role_rank(role: str) -> int:
    return ROLE_NAMES.index(role) if role in ROLE_NAMES else len(ROLE_NAMES)


async def membership(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT g.gang_id,g.name,g.treasury,g.reputation,gm.user_id,gm.role FROM gang_members gm "
            "JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (user_id,)
        ) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def create_gang(user_id: int, name: str) -> dict:
    name = " ".join(name.split())
    if len(name) < 2 or len(name) > 40:
        raise GangError("Le nom doit contenir entre 2 et 40 caractères.")
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)) as cur:
            user = await cur.fetchone()
        if not user or user["balance"] < CREATE_COST:
            await db.rollback(); raise GangError(f"Créer un gang coûte {CREATE_COST:,} €A.")
        async with db.execute("SELECT 1 FROM gang_members WHERE user_id=?", (user_id,)) as cur:
            if await cur.fetchone():
                await db.rollback(); raise GangError("Tu es déjà dans un gang.")
        async with db.execute("SELECT 1 FROM gangs WHERE LOWER(name)=LOWER(?)", (name,)) as cur:
            if await cur.fetchone():
                await db.rollback(); raise GangError("Ce nom de gang est déjà pris.")
        await db.execute("INSERT INTO gangs(name,founder_id,treasury,reputation,created_at) VALUES (?,?,0,0,?)", (name, user_id, now()))
        gang_id = (await (await db.execute("SELECT last_insert_rowid()")).fetchone())[0]
        await db.execute("INSERT INTO gang_members(gang_id,user_id,role,joined_at) VALUES (?,?,'Chef',?)", (gang_id, user_id, now()))
        debit = await db.execute("UPDATE users SET balance=balance-?,total_spent=total_spent+? WHERE user_id=? AND balance>=?", (CREATE_COST, CREATE_COST, user_id, CREATE_COST))
        if debit.rowcount != 1:
            await db.rollback(); raise GangError("Fonds insuffisants.")
        await db.commit()
    return {"gang_id": gang_id, "name": name, "cost": CREATE_COST}


async def apply_to_gang(user_id: int, gang_id: int) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT 1 FROM gang_members WHERE user_id=?", (user_id,)) as cur:
            already_member = await cur.fetchone()
        if already_member:
            await db.rollback(); raise GangError("Tu es déjà dans un gang.")
        async with db.execute("SELECT gang_id,name FROM gangs WHERE gang_id=?", (gang_id,)) as cur:
            gang = await cur.fetchone()
        if not gang:
            await db.rollback(); raise GangError("Gang introuvable.")
        placeholders = ",".join("?" * len(GANG_RECRUIT_ROLES))
        async with db.execute(f"SELECT user_id FROM gang_members WHERE gang_id=? AND role IN ({placeholders})", (gang_id, *GANG_RECRUIT_ROLES)) as cur:
            recruiters = [r[0] for r in await cur.fetchall()]
        if not recruiters:
            await db.execute("INSERT INTO gang_members(gang_id,user_id,role,joined_at) VALUES (?,?,'Recrue',?)", (gang_id, user_id, now()))
            await db.commit()
            return {"status": "joined", "gang_id": gang_id, "name": gang["name"]}
        cur = await db.execute("INSERT OR IGNORE INTO gang_applications(gang_id,user_id,status,created_at) VALUES (?,?,'pending',?)", (gang_id, user_id, now()))
        await db.commit()
        if not cur.rowcount:
            raise GangError("Ta candidature est déjà en attente.")
    for recruiter in recruiters:
        await notify(recruiter, "🔫 Candidature", f"Un joueur veut rejoindre le gang <b>{gang['name']}</b>.", "info")
    return {"status": "pending", "gang_id": gang_id, "name": gang["name"], "recruiters": recruiters}


async def leave_gang(user_id: int) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT g.gang_id,g.name,gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (user_id,)) as cur:
            me = await cur.fetchone()
        if not me:
            await db.rollback(); raise GangError("Tu n'es dans aucun gang.")
        async with db.execute("SELECT COUNT(*) FROM gang_members WHERE gang_id=?", (me["gang_id"],)) as cur:
            count = (await cur.fetchone())[0]
        if me["role"] == "Chef" and count > 1:
            await db.rollback(); raise GangError("Le chef doit transférer ou dissoudre le gang.")
        await db.execute("DELETE FROM gang_members WHERE gang_id=? AND user_id=?", (me["gang_id"], user_id))
        dissolved = count == 1
        if dissolved:
            await db.execute("DELETE FROM gangs WHERE gang_id=?", (me["gang_id"],))
        await db.commit()
    return {"gang_id": me["gang_id"], "name": me["name"], "dissolved": dissolved}


async def deposit(user_id: int, amount: int) -> dict:
    if amount <= 0: raise GangError("Montant invalide.")
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT g.gang_id FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (user_id,)) as cur:
            me = await cur.fetchone()
        if not me: await db.rollback(); raise GangError("Tu n'es dans aucun gang.")
        debit = await db.execute("UPDATE users SET balance=balance-?,total_spent=total_spent+? WHERE user_id=? AND balance>=?", (amount, amount, user_id, amount))
        if debit.rowcount != 1: await db.rollback(); raise GangError("Fonds insuffisants.")
        await db.execute("UPDATE gangs SET treasury=treasury+? WHERE gang_id=?", (amount, me["gang_id"]))
        await db.commit()
    return {"gang_id": me["gang_id"], "amount": amount}


async def withdraw(user_id: int, amount: int) -> dict:
    if amount <= 0: raise GangError("Montant invalide.")
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT g.gang_id,g.treasury,gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (user_id,)) as cur:
            me = await cur.fetchone()
        if not me or me["role"] != "Chef": await db.rollback(); raise GangError("Seul le chef peut retirer.")
        if amount > me["treasury"]: await db.rollback(); raise GangError("Caisse insuffisante.")
        await db.execute("UPDATE gangs SET treasury=treasury-? WHERE gang_id=?", (amount, me["gang_id"]))
        await db.execute("UPDATE users SET balance=balance+?,total_earned=total_earned+? WHERE user_id=?", (amount, amount, user_id))
        await db.commit()
    return {"gang_id": me["gang_id"], "amount": amount}


async def upgrade(user_id: int) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT g.gang_id,g.name,g.treasury,g.reputation,gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (user_id,)) as cur:
            me = await cur.fetchone()
        if not me or me["role"] not in GANG_MANAGE_ROLES: await db.rollback(); raise GangError("Réservé à l'encadrement.")
        if me["treasury"] < UPGRADE_COST: await db.rollback(); raise GangError("Caisse insuffisante.")
        new_rep = min(100, me["reputation"] + 10)
        await db.execute("UPDATE gangs SET treasury=treasury-?,reputation=? WHERE gang_id=? AND treasury>=?", (UPGRADE_COST, new_rep, me["gang_id"], UPGRADE_COST))
        await db.commit()
    return {"gang_id": me["gang_id"], "name": me["name"], "old_reputation": me["reputation"], "reputation": new_rep, "cost": UPGRADE_COST}


async def change_role(actor_id: int, target_id: int, new_role: str) -> dict:
    if new_role not in ROLE_NAMES or new_role == "Chef":
        raise GangError("Poste invalide : le poste Chef se transfère séparément.")
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT g.gang_id,g.name,gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (actor_id,)) as cur:
            actor = await cur.fetchone()
        async with db.execute("SELECT user_id,role FROM gang_members WHERE user_id=?", (target_id,)) as cur:
            target = await cur.fetchone()
        if not actor or actor["role"] not in GANG_MANAGE_ROLES:
            await db.rollback(); raise GangError("Réservé au Chef et au Bras droit.")
        if not target or target_id == actor_id:
            await db.rollback(); raise GangError("Ce joueur n'est pas un autre membre de ton gang.")
        async with db.execute("SELECT gang_id FROM gang_members WHERE user_id=?", (target_id,)) as cur:
            target_gang = await cur.fetchone()
        if not target_gang or target_gang["gang_id"] != actor["gang_id"]:
            await db.rollback(); raise GangError("Ce joueur n'est pas un autre membre de ton gang.")
        if role_rank(new_role) <= role_rank(actor["role"]) or role_rank(target["role"]) <= role_rank(actor["role"]):
            await db.rollback(); raise GangError("Tu ne peux gérer que des postes strictement inférieurs au tien.")
        await db.execute("UPDATE gang_members SET role=? WHERE gang_id=? AND user_id=?", (new_role, actor["gang_id"], target_id))
        await db.commit()
    await notify(target_id, "🎖️ Changement de poste", f"Dans <b>{actor['name']}</b>, ton poste est maintenant <b>{new_role}</b>.", "achievement")
    return {"gang_id": actor["gang_id"], "target_id": target_id, "role": new_role}


async def exclude_member(actor_id: int, target_id: int) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT g.gang_id,g.name,gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (actor_id,)) as cur:
            actor = await cur.fetchone()
        async with db.execute("SELECT role FROM gang_members WHERE user_id=?", (target_id,)) as cur:
            target = await cur.fetchone()
        if not actor or actor["role"] not in GANG_MANAGE_ROLES:
            await db.rollback(); raise GangError("Réservé au Chef et au Bras droit.")
        if not target or target_id == actor_id or role_rank(target["role"]) <= role_rank(actor["role"]):
            await db.rollback(); raise GangError("Tu ne peux exclure qu'un membre de rang inférieur.")
        async with db.execute("SELECT gang_id FROM gang_members WHERE user_id=?", (target_id,)) as cur:
            target_gang = await cur.fetchone()
        if not target_gang or target_gang["gang_id"] != actor["gang_id"]:
            await db.rollback(); raise GangError("Ce joueur n'est pas membre de ton gang.")
        await db.execute("DELETE FROM gang_members WHERE gang_id=? AND user_id=?", (actor["gang_id"], target_id))
        await db.commit()
    await notify(target_id, "🚪 Exclusion", f"Tu as été exclu(e) du gang <b>{actor['name']}</b>.", "warning")
    return {"gang_id": actor["gang_id"], "target_id": target_id}


async def transfer_chief(actor_id: int, target_id: int) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT g.gang_id,g.name,gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (actor_id,)) as cur:
            actor = await cur.fetchone()
        async with db.execute("SELECT role FROM gang_members WHERE user_id=?", (target_id,)) as cur:
            target = await cur.fetchone()
        if not actor or actor["role"] != "Chef":
            await db.rollback(); raise GangError("Seul le chef peut transférer le gang.")
        if not target or target_id == actor_id:
            await db.rollback(); raise GangError("Le nouveau chef doit être un membre du gang.")
        async with db.execute("SELECT gang_id FROM gang_members WHERE user_id=?", (target_id,)) as cur:
            target_gang = await cur.fetchone()
        if not target_gang or target_gang["gang_id"] != actor["gang_id"]:
            await db.rollback(); raise GangError("Le nouveau chef doit être un membre du gang.")
        await db.execute("UPDATE gang_members SET role='Bras droit' WHERE gang_id=? AND user_id=?", (actor["gang_id"], actor_id))
        await db.execute("UPDATE gang_members SET role='Chef' WHERE gang_id=? AND user_id=?", (actor["gang_id"], target_id))
        await db.execute("UPDATE gangs SET founder_id=? WHERE gang_id=?", (target_id, actor["gang_id"]))
        await db.commit()
    await notify(target_id, "👑 Nouveau chef", f"Tu es maintenant chef du gang <b>{actor['name']}</b>.", "achievement")
    return {"gang_id": actor["gang_id"], "target_id": target_id}


async def dissolve_gang(actor_id: int) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT g.gang_id,g.name,g.treasury,gm.role FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (actor_id,)) as cur:
            gang = await cur.fetchone()
        if not gang or gang["role"] != "Chef":
            await db.rollback(); raise GangError("Seul le chef peut dissoudre le gang.")
        await db.execute("DELETE FROM gang_members WHERE gang_id=?", (gang["gang_id"],))
        await db.execute("DELETE FROM gangs WHERE gang_id=?", (gang["gang_id"],))
        if gang["treasury"]:
            await db.execute("UPDATE users SET balance=balance+?,total_earned=total_earned+? WHERE user_id=?", (gang["treasury"], gang["treasury"], actor_id))
        await db.commit()
    return {"gang_id": gang["gang_id"], "name": gang["name"], "refunded": gang["treasury"] or 0}


async def hold_up(user_id: int) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT g.gang_id,g.name,g.treasury,g.reputation FROM gang_members gm JOIN gangs g ON g.gang_id=gm.gang_id WHERE gm.user_id=?", (user_id,)) as cur:
            gang = await cur.fetchone()
        if not gang:
            await db.rollback(); raise GangError("Tu n'es dans aucun gang.")
        members = (await (await db.execute("SELECT COUNT(*) FROM gang_members WHERE gang_id=?", (gang["gang_id"],))).fetchone())[0]
        chance = min(0.95, 0.3 + gang["reputation"] / 200)
        if random.random() > chance:
            loss = int(gang["treasury"] * 0.1) if gang["treasury"] > 0 else 0
            await db.execute("UPDATE gangs SET reputation=MAX(0,reputation-10),treasury=treasury-? WHERE gang_id=?", (loss, gang["gang_id"]))
            await db.commit()
            return {"success": False, "gang_id": gang["gang_id"], "name": gang["name"], "reputation_change": -10, "treasury_change": -loss, "members": members}
        reward = random.randint(50_000, 200_000)
        rep_gain = random.randint(5, 15)
        await db.execute("UPDATE gangs SET treasury=treasury+?,reputation=MIN(100,reputation+?) WHERE gang_id=?", (reward, rep_gain, gang["gang_id"]))
        await db.commit()
    return {"success": True, "gang_id": gang["gang_id"], "name": gang["name"], "reward": reward, "reputation_change": rep_gain, "members": members}


async def maintenance() -> dict:
    async with db_connection() as db:
        low = await db.execute("UPDATE gangs SET reputation=MAX(0,reputation-5) WHERE NOT (treasury>0 AND CAST(treasury*0.05 AS INTEGER)>0)")
        charged = await db.execute("UPDATE gangs SET treasury=treasury-CAST(treasury*0.05 AS INTEGER) WHERE treasury>0 AND CAST(treasury*0.05 AS INTEGER)>0")
        await db.commit()
    return {"reputation_penalties": low.rowcount, "gangs_charged": charged.rowcount}
