"""Règles métier communes des missions freelance.

Ce module ne dépend ni de Telegram ni de FastAPI. Les adaptateurs fournissent seulement
l'entrée utilisateur et rendent le résultat dans leur interface.
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from config import SHIFT_ENERGY, SMALL_JOBS, SMALL_JOB_PLACE, WORK_COOLDOWN
from config_chain import GRANDE_COMMANDE, GRANDE_COMMANDE_RANK, good_label, job_rank_mult
from database import get_user, now, update_balance, update_field
from handlers.missions import update_mission_progress
from utils.chain import get_job_progress, promotion_status, record_mission
from utils.cooldowns import claim_cooldown, release_cooldown
from utils.decorators import get_user_role_async
from utils.gamerules import faucet
from utils.location import is_exempt, presence_error
from utils.notify import notify
from utils.vip import add_xp, effective_cooldown

KEY = "freelance_last"
SCORE_MULT = {0: 0.0, 1: 0.7, 2: 1.0, 3: 1.5}
NO_JOB_TEXT = (
    "💼 Tu n'as pas de métier.\n"
    "🛠️ Choisis-en un : menu Carrière → Mon métier → « Choisir un métier »."
)


class WorkError(Exception):
    """Erreur métier présentable par un adaptateur."""

    def __init__(self, message: str, status: int = 422):
        super().__init__(message)
        self.message = message
        self.status = status


@dataclass
class WorkPreparation:
    user_id: int
    job_name: str
    rank: int
    big: bool
    base_gain: int
    cooldown_seconds: int


def _vital_problem(u: dict) -> str | None:
    if u.get("energy", 100) < 20:
        return "😴 Tu es épuisé(e) ! Repose-toi avant de retravailler."
    if u.get("hunger", 100) < 12:
        return "🍽️ Tu es trop affamé(e) pour travailler. Mange d'abord."
    if u.get("health", 100) < 15:
        return "🏥 Ton état est trop critique pour travailler. Soigne-toi d'abord."
    return None


async def prepare(user_id: int, *, big: bool = False) -> WorkPreparation:
    """Valide une mission, réserve son cooldown et calcule le gain de base une seule fois."""
    from utils import minigames

    u = await get_user(user_id)
    name = u.get("job", "") or ""
    job = SMALL_JOBS.get(name)
    if not job:
        raise WorkError(NO_JOB_TEXT)
    problem = _vital_problem(u)
    if problem:
        raise WorkError(problem)

    prog = await get_job_progress(user_id, name)
    rank = prog["rank"]
    if big and rank < GRANDE_COMMANDE_RANK:
        raise WorkError("🔒 Les grandes commandes s'ouvrent au rang Confirmé.", 403)
    if big and u.get("energy", 100) < 50:
        raise WorkError("😴 Une grande commande demande au moins 50 % d'énergie.")
    if job.get("need"):
        from handlers.work import _dip_rank
        if _dip_rank(u.get("diplome") or "") < _dip_rank(job["need"]):
            raise WorkError(f"🔒 Le métier « {name} » nécessite le diplôme {job['need']}.", 403)
    if not minigames.STARTERS.get(job["category"]):
        raise WorkError(f"⏳ Mini-jeu {job['category']} pas encore disponible.")

    place = SMALL_JOB_PLACE.get(name, "travail")
    if not await is_exempt(user_id):
        error = await presence_error(user_id, (place,))
        if error:
            raise WorkError(error)

    multiplier = GRANDE_COMMANDE["cooldown"] if big else 1.0
    role = await get_user_role_async(user_id)
    exempt = role != "PLAYER" or u.get("god_mode")
    cooldown_seconds = int(effective_cooldown(u, WORK_COOLDOWN, work=True) * multiplier)
    claimed = exempt
    if not exempt:
        claimed, remaining = await claim_cooldown(user_id, KEY, cooldown_seconds)
        if not claimed:
            raise WorkError(f"⏳ Tu es fatigué(e) ! Reviens dans {remaining} secondes.")

    try:
        pay_multiplier = job_rank_mult(rank)["pay"] * (GRANDE_COMMANDE["pay"] if big else 1.0)
        base_gain = int(random.randint(job["min"], job["max"]) * pay_multiplier)
        return WorkPreparation(user_id, name, rank, big, base_gain, cooldown_seconds)
    except Exception:
        if claimed and not exempt:
            await release_cooldown(user_id, KEY)
        raise


async def resolve(preparation: WorkPreparation, score: int) -> dict:
    """Applique une mission terminée avec le score final 0..3."""
    from utils import minigames

    score = max(0, min(3, int(score)))
    user_id = preparation.user_id
    try:
        gain = await faucet("work", int(preparation.base_gain * SCORE_MULT[score]))
        if gain > 0:
            await update_balance(user_id, gain)

        xp = 30 + score * 10
        await add_xp(user_id, xp)
        await update_mission_progress(user_id, "work", 1)

        u = await get_user(user_id)
        e_mult = job_rank_mult(preparation.rank)["energy"] * (
            GRANDE_COMMANDE["energy"] if preparation.big else 1.0
        )
        cost = max(1, int(random.randint(*SHIFT_ENERGY) * e_mult))
        energy_left = max(0, u.get("energy", 100) - cost)
        await update_field(user_id, "energy", energy_left)
        await update_field(user_id, "work_last", now())

        result = await record_mission(user_id, preparation.job_name, score, preparation.big)
        promotion = await promotion_status(user_id, preparation.job_name)
        goods = None
        if result["units"] and result["good"]:
            goods = {"key": result["good"], "label": good_label(result["good"]), "units": result["units"]}

        await notify(
            user_id,
            "🛠️ Mission freelance",
            f"Ton repos est terminé : tu peux reprendre une mission de {preparation.job_name}.",
            "info",
            delay=preparation.cooldown_seconds,
        )
        return {
            "success": True,
            "job": preparation.job_name,
            "big": preparation.big,
            "rank": preparation.rank,
            "score": score,
            "score_label": minigames.SCORE_LABEL[score],
            "gain": gain,
            "xp": xp,
            "energy_cost": cost,
            "energy_left": energy_left,
            "goods": goods,
            "promotion_available": bool(promotion["next"] and promotion["ok"]),
        }
    except Exception:
        await release_cooldown(user_id, KEY)
        raise
