"""Persistance et transitions atomiques des sessions de Blackjack, Mines et Crash."""
from __future__ import annotations

import json
import time
from typing import Any

import database

SESSION_TYPES = {"blackjack", "mines", "crash", "roulette", "pmu"}
TERMINAL_STATUSES = {"win", "loss", "push", "blackjack", "bust", "crashed", "cashed_out"}

# Une action réservée (passage à 'processing') qui n'a pas été réglée après ce délai est
# considérée comme interrompue (redémarrage serveur entre la réservation et l'enregistrement
# du résultat) : aucun effet économique n'a encore eu lieu à ce stade (voir
# `create_session_with_stake` / `save_claimed_session_with_payout` ci-dessous, qui regroupent
# toujours la mise ou le gain avec la transition d'état dans la même transaction), donc la
# reprise se contente de relâcher la réservation pour permettre un nouvel essai.
PROCESSING_STALE_SECONDS = 30


def _encode_state(game_type: str, state: dict[str, Any]) -> str:
    serializable = dict(state)
    if game_type == "mines":
        serializable["mines"] = sorted(serializable["mines"])
        serializable["revealed"] = sorted(serializable["revealed"])
    return json.dumps(serializable, ensure_ascii=False, separators=(",", ":"))


def _decode(row) -> dict[str, Any]:
    game_type = row["game_type"]
    state = json.loads(row["state_json"])
    if game_type == "mines":
        state["mines"] = set(state.get("mines", []))
        state["revealed"] = set(state.get("revealed", []))
    return {
        "game_id": row["game_id"], "user_id": int(row["user_id"]),
        "game_type": game_type, "status": row["status"], "revision": int(row["revision"]),
        "created_at": int(row["created_at"]), "updated_at": int(row["updated_at"]),
        "settled_at": int(row["settled_at"]), "state": state,
    }


async def create_session(game_id: str, user_id: int, game_type: str, state: dict[str, Any]) -> None:
    if game_type not in SESSION_TYPES:
        raise ValueError("Type de partie non pris en charge.")
    now = int(time.time())
    async with database.db_connection() as db:
        await db.execute(
            "INSERT INTO casino_game_sessions "
            "(game_id,user_id,game_type,status,state_json,revision,created_at,updated_at,settled_at) "
            "VALUES (?,?,?,'active',?,0,?,?,0)",
            (game_id, int(user_id), game_type, _encode_state(game_type, state), now, now),
        )
        await db.commit()


async def get_session(game_id: str, user_id: int, game_type: str | None = None) -> dict[str, Any] | None:
    async with database.db_connection() as db:
        if game_type is None:
            async with db.execute(
                "SELECT * FROM casino_game_sessions WHERE game_id=? AND user_id=?",
                (game_id, int(user_id)),
            ) as cur:
                row = await cur.fetchone()
        else:
            async with db.execute(
                "SELECT * FROM casino_game_sessions WHERE game_id=? AND user_id=? AND game_type=?",
                (game_id, int(user_id), game_type),
            ) as cur:
                row = await cur.fetchone()
        session = _decode(row) if row else None
    if session is not None:
        session = await recover_stuck_session(session) or session
    return session


async def find_resumable_session(user_id: int, game_type: str) -> dict[str, Any] | None:
    """Session active ou en cours de traitement la plus récente pour ce joueur/mode.

    Utilisée par les modes à un seul clic (Roulette, PMU) pour reprendre une mise déjà
    prélevée plutôt que d'en débiter une seconde si la résolution a été interrompue."""
    if game_type not in SESSION_TYPES:
        raise ValueError("Type de partie non pris en charge.")
    async with database.db_connection() as db:
        async with db.execute(
            "SELECT * FROM casino_game_sessions WHERE user_id=? AND game_type=? "
            "AND status IN ('active','processing') ORDER BY created_at DESC LIMIT 1",
            (int(user_id), game_type),
        ) as cur:
            row = await cur.fetchone()
    session = _decode(row) if row else None
    if session is not None:
        session = await recover_stuck_session(session) or session
    return session


async def create_session_with_stake(
    game_id: str, user_id: int, game_type: str, state: dict[str, Any], stake: int,
    *, sink: str | None = "casino",
) -> int:
    """Débite la mise et crée la session dans UNE SEULE transaction (plus de fenêtre où la
    mise serait débitée sans que la partie n'existe, ou l'inverse)."""
    if game_type not in SESSION_TYPES:
        raise ValueError("Type de partie non pris en charge.")
    if stake <= 0:
        raise ValueError("La mise doit être positive.")
    now = int(time.time())
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT balance FROM users WHERE user_id=?", (int(user_id),)) as cur:
            row = await cur.fetchone()
        if not row or row[0] < stake:
            await db.rollback()
            raise ValueError("Fonds insuffisants.")
        await db.execute(
            "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=?",
            (stake, stake, int(user_id)),
        )
        if sink:
            from utils.treasury import collect
            await collect(db, stake, sink)
        await db.execute(
            "INSERT INTO casino_game_sessions "
            "(game_id,user_id,game_type,status,state_json,revision,created_at,updated_at,settled_at) "
            "VALUES (?,?,?,'active',?,0,?,?,0)",
            (game_id, int(user_id), game_type, _encode_state(game_type, state), now, now),
        )
        await database.snapshot_user_core_stats(int(user_id), db)
        await db.commit()
    return int(row[0]) - stake


async def save_claimed_session_with_payout(
    session: dict[str, Any], state: dict[str, Any], status: str, payout: int = 0,
) -> dict[str, Any] | None:
    """Enregistre l'état final ET crédite le gain (s'il y en a un) dans la même transaction
    que la transition CAS 'processing' → état final, pour qu'un redémarrage serveur ne puisse
    jamais séparer le résultat de la partie de son effet économique."""
    if status != "active" and status not in TERMINAL_STATUSES:
        raise ValueError("Statut final de partie invalide.")
    now = int(time.time())
    settled_at = now if status in TERMINAL_STATUSES else 0
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute(
            "UPDATE casino_game_sessions SET state_json=?,status=?,revision=revision+1,updated_at=?,settled_at=? "
            "WHERE game_id=? AND user_id=? AND game_type=? AND status='processing' AND revision=?",
            (_encode_state(session["game_type"], state), status, now, settled_at,
             session["game_id"], session["user_id"], session["game_type"], session["revision"] + 1),
        )
        if cur.rowcount != 1:
            await db.rollback()
            return None
        if payout:
            await db.execute(
                "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                (payout, payout, session["user_id"]),
            )
            await database.snapshot_user_core_stats(session["user_id"], db)
        await db.commit()
    balance = None
    if payout:
        user = await database.get_user(session["user_id"])
        balance = user["balance"] if user else None
    return {"saved": True, "balance": balance}


async def recover_stuck_session(session: dict[str, Any]) -> dict[str, Any] | None:
    """Relâche une réservation 'processing' restée bloquée (redémarrage serveur entre la
    réservation et l'enregistrement du résultat). Aucun effet économique n'a eu lieu à ce
    stade — voir le commentaire sur `PROCESSING_STALE_SECONDS` — donc revenir à 'active'
    est toujours sûr et permet simplement de rejouer l'action."""
    if session["status"] != "processing":
        return None
    if int(time.time()) - session["updated_at"] < PROCESSING_STALE_SECONDS:
        return None
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute(
            "UPDATE casino_game_sessions SET status='active', revision=revision+1, updated_at=? "
            "WHERE game_id=? AND user_id=? AND game_type=? AND status='processing' AND revision=?",
            (int(time.time()), session["game_id"], session["user_id"], session["game_type"], session["revision"]),
        )
        recovered = cur.rowcount == 1
        await db.commit()
    if not recovered:
        return None
    return await get_session(session["game_id"], session["user_id"], session["game_type"])


async def claim_active_session(session: dict[str, Any]) -> bool:
    """Réserve une seule action pour la révision lue; rejoue la requête après redémarrage sans état RAM."""
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute(
            "UPDATE casino_game_sessions SET status='processing', revision=revision+1, updated_at=? "
            "WHERE game_id=? AND user_id=? AND game_type=? AND status='active' AND revision=?",
            (int(time.time()), session["game_id"], session["user_id"], session["game_type"], session["revision"]),
        )
        claimed = cur.rowcount == 1
        await db.commit()
        return claimed


async def save_claimed_session(
    session: dict[str, Any], state: dict[str, Any], status: str,
) -> bool:
    if status != "active" and status not in TERMINAL_STATUSES:
        raise ValueError("Statut final de partie invalide.")
    now = int(time.time())
    settled_at = now if status in TERMINAL_STATUSES else 0
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute(
            "UPDATE casino_game_sessions SET state_json=?,status=?,revision=revision+1,updated_at=?,settled_at=? "
            "WHERE game_id=? AND user_id=? AND game_type=? AND status='processing' AND revision=?",
            (_encode_state(session["game_type"], state), status, now, settled_at,
             session["game_id"], session["user_id"], session["game_type"], session["revision"] + 1),
        )
        saved = cur.rowcount == 1
        await db.commit()
        return saved


async def list_active_sessions(game_type: str) -> list[dict[str, Any]]:
    if game_type not in SESSION_TYPES:
        raise ValueError("Type de partie non pris en charge.")
    async with database.db_connection() as db:
        async with db.execute(
            "SELECT * FROM casino_game_sessions WHERE game_type=? AND status='active' ORDER BY created_at",
            (game_type,),
        ) as cur:
            rows = await cur.fetchall()
    return [_decode(row) for row in rows]
