"""Règles et persistance partagées des commentaires du Réseau RP."""
from __future__ import annotations

import html
import time

import aiosqlite
from database import db_connection
from utils.notify import notify
from utils.reseau_rules import COMMENT_MAX, COMMENTS_PER_POST


class CommentError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _real_ts() -> int:
    # Le bot existant horodate les commentaires en temps réel, contrairement au temps de jeu.
    return int(time.time())


async def list_comments(post_id: int) -> dict:
    async with db_connection() as db:
        async with db.execute(
            "SELECT id,author_id,platform,text,comments FROM rp_posts WHERE id=? AND deleted=0",
            (post_id,),
        ) as cur:
            post = await cur.fetchone()
        if not post:
            raise CommentError("not_found", "Publication introuvable.")
        async with db.execute(
            """SELECT c.id,c.user_id,c.text,c.created_at,
                      COALESCE(NULLIF(u.full_name,''),u.username,'') AS author
               FROM rp_comments c LEFT JOIN users u ON u.user_id=c.user_id
               WHERE c.post_id=? AND c.deleted=0
               ORDER BY c.created_at DESC,c.id DESC LIMIT 8""",
            (post_id,),
        ) as cur:
            rows = await cur.fetchall()
    comments = [{
        "id": int(row["id"]),
        "user_id": int(row["user_id"]),
        "author": row["author"] or f"Joueur {row['user_id']}",
        "text": row["text"],
        "created_at": int(row["created_at"]),
    } for row in reversed(rows)]
    return {
        "post": {
            "id": int(post["id"]),
            "author_id": int(post["author_id"]),
            "platform": post["platform"],
            "text": post["text"],
            "comments": int(post["comments"] or 0),
        },
        "comments": comments,
        "max_length": COMMENT_MAX,
        "max_per_player": COMMENTS_PER_POST,
    }


async def create_comment(user_id: int, post_id: int, text: str) -> dict:
    body = str(text or "").strip()[:COMMENT_MAX]
    if not body:
        raise CommentError("empty", "Écris un commentaire avant de l’envoyer.")
    author_id = None
    comment_id = None
    created_at = _real_ts()
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute(
            "SELECT author_id FROM rp_posts WHERE id=? AND deleted=0", (post_id,),
        ) as cur:
            post = await cur.fetchone()
        if not post:
            await db.rollback()
            raise CommentError("not_found", "Publication introuvable.")
        async with db.execute(
            "SELECT COUNT(*) FROM rp_comments WHERE post_id=? AND user_id=? AND deleted=0",
            (post_id, user_id),
        ) as cur:
            count = int((await cur.fetchone())[0])
        if count >= COMMENTS_PER_POST:
            await db.rollback()
            raise CommentError("limit", f"Maximum {COMMENTS_PER_POST} commentaires par publication.")
        cur = await db.execute(
            "INSERT INTO rp_comments (post_id,user_id,text,created_at) VALUES (?,?,?,?)",
            (post_id, user_id, body, created_at),
        )
        comment_id = int(cur.lastrowid)
        author_id = int(post[0])
        await db.execute("UPDATE rp_posts SET comments=comments+1 WHERE id=?", (post_id,))
        async with db.execute("SELECT comments FROM rp_posts WHERE id=?", (post_id,)) as cur:
            total_comments = int((await cur.fetchone())[0])
        async with db.execute(
            "SELECT COALESCE(NULLIF(full_name,''),username,'') FROM users WHERE user_id=?",
            (user_id,),
        ) as cur:
            row = await cur.fetchone()
        display_name = (row[0] if row else None) or f"Joueur {user_id}"
        await db.commit()
    if author_id != user_id:
        await notify(
            author_id,
            "💬 Nouveau commentaire",
            f"<b>{html.escape(display_name)}</b> : {html.escape(body[:150])}",
            "social",
        )
    return {
        "id": comment_id,
        "post_id": post_id,
        "user_id": user_id,
        "author": display_name,
        "text": body,
        "created_at": created_at,
        "comments": total_comments,
        "message": "Commentaire publié.",
    }
