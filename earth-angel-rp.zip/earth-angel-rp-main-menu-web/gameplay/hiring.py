"""gameplay/hiring.py — Équipe, recrutement, salaires, licenciement, démission.

Service partagé par `handlers/companies.py` (bot) et `webapp/routers/companies_router.py`.
Chaque fonction renvoie `{"ok": bool, "reason": ...}`. Les écritures d'état se font sous une seule
transaction `BEGIN IMMEDIATE` ; notifications et journal d'entreprise (qui commitent seuls) sont
envoyés après le commit.

Corrections vs l'ancien code des handlers :
 • l'acceptation d'une candidature (ou d'une contre-offre) refuse un candidat déjà employé ailleurs —
   avant, `INSERT OR REPLACE` sur l'index unique `company_members(user_id)` l'arrachait en silence à
   son entreprise actuelle ;
 • le licenciement retire l'employé, ses parts, débite la trésorerie et verse l'indemnité dans la
   même transaction (avant : l'indemnité était créditée après coup, hors transaction) ;
 • promotion / changement de salaire refusent une cible qui n'est pas dans l'entreprise (avant :
   `UPDATE` sans effet mais notification et journal quand même).
"""
from __future__ import annotations

import aiosqlite
from html import escape

import database
from utils.company_roles import can_manage, get_role


def _fmt(n) -> str:
    return f"{int(n):,}".replace(",", " ")


async def _notify(user_id: int | None, message: str) -> None:
    if not user_id:
        return
    try:
        await database.add_notification(user_id, message)
    except Exception:
        pass


async def team(company_id: int) -> list[dict]:
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT u.user_id, u.full_name, cm.poste, cm.base_salary, cm.activity_score, cm.joined_at "
            "FROM company_members cm JOIN users u ON u.user_id=cm.user_id "
            "WHERE cm.company_id=? ORDER BY cm.activity_score DESC", (company_id,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def pending_applications(company_id: int) -> list[dict]:
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT ca.app_id, u.user_id, u.full_name, u.diplome, u.karma, ca.desired_salary, ca.applied_at "
            "FROM company_applications ca JOIN users u ON u.user_id=ca.user_id "
            "WHERE ca.company_id=? AND ca.status='pending' ORDER BY ca.applied_at", (company_id,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def my_applications(user_id: int) -> list[dict]:
    """Candidatures de l'utilisateur en cours (en attente ou contre-offre à traiter)."""
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT ca.app_id, ca.company_id, c.name AS company_name, ca.status, ca.desired_salary, ca.applied_at "
            "FROM company_applications ca JOIN companies c ON c.company_id=ca.company_id "
            "WHERE ca.user_id=? AND ca.status IN ('pending','negotiating') AND c.dissolved=0 "
            "ORDER BY ca.applied_at DESC", (user_id,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def apply(user_id: int, company_id: int, desired_salary: int = 0) -> dict:
    if desired_salary < 0:
        return {"ok": False, "reason": "invalid_salary"}
    from utils.factions import get_membership
    if await get_membership(user_id):
        return {"ok": False, "reason": "state_employee"}
    if await database.get_user_company(user_id):
        return {"ok": False, "reason": "already_employed"}
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT name FROM companies WHERE company_id=? AND dissolved=0", (company_id,)) as cur:
                company = await cur.fetchone()
            if not company:
                await db.rollback()
                return {"ok": False, "reason": "unknown_company"}
            async with db.execute(
                "SELECT 1 FROM company_applications WHERE user_id=? AND company_id=? AND status='pending'",
                (user_id, company_id),
            ) as cur:
                if await cur.fetchone():
                    await db.rollback()
                    return {"ok": False, "reason": "already_pending"}
            await db.execute(
                "INSERT INTO company_applications (user_id, company_id, desired_salary, applied_at) VALUES (?,?,?,?)",
                (user_id, company_id, desired_salary, database.now()))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return {"ok": True, "company_name": company[0], "desired_salary": desired_salary}


async def _hire(db, app_user_id: int, company_id: int, salary: int) -> str | None:
    """Insère l'employé ; renvoie une raison de refus s'il est déjà pris (État ou autre entreprise)."""
    async with db.execute("SELECT 1 FROM faction_members WHERE user_id=?", (app_user_id,)) as cur:
        if await cur.fetchone():
            return "state_employee"
    async with db.execute(
        "SELECT 1 FROM company_members WHERE user_id=? AND company_id<>?", (app_user_id, company_id)
    ) as cur:
        if await cur.fetchone():
            return "already_employed"
    await db.execute(
        "INSERT OR REPLACE INTO company_members (user_id, company_id, poste, base_salary, joined_at, activity_score) "
        "VALUES (?,?,?,?,?,0)", (app_user_id, company_id, "Employé", salary, database.now()))
    return None


async def accept_application(actor_id: int, app_id: int, salary: int) -> dict:
    company = await database.get_user_company(actor_id)
    if not company or not await can_manage(actor_id, company):
        return {"ok": False, "reason": "not_manager"}
    if salary < 0:
        return {"ok": False, "reason": "invalid_salary"}
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT * FROM company_applications WHERE app_id=? AND company_id=? AND status='pending'",
                (app_id, company["company_id"]),
            ) as cur:
                app = await cur.fetchone()
            if not app:
                await db.rollback()
                return {"ok": False, "reason": "unknown_application"}
            refusal = await _hire(db, app["user_id"], company["company_id"], salary)
            if refusal:
                await db.rollback()
                return {"ok": False, "reason": refusal}
            await db.execute("UPDATE company_applications SET status='accepted' WHERE app_id=?", (app_id,))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    candidate = await database.get_user(app["user_id"])
    await database.log_company_action(company["company_id"], "recrutement", actor_id,
                                      f"{candidate['full_name']} salaire {_fmt(salary)}")
    await _notify(app["user_id"],
                  f"🎉 Votre candidature pour <b>{escape(str(company['name']))}</b> a été acceptée ! "
                  f"Salaire : {_fmt(salary)}. Ouvre le 🎮 Menu principal pour voir votre poste.")
    return {"ok": True, "app_id": app_id, "salary": salary, "candidate_id": app["user_id"]}


async def counter_offer(actor_id: int, app_id: int, salary: int) -> dict:
    company = await database.get_user_company(actor_id)
    if not company or not await can_manage(actor_id, company):
        return {"ok": False, "reason": "not_manager"}
    if salary < 0:
        return {"ok": False, "reason": "invalid_salary"}
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT user_id FROM company_applications WHERE app_id=? AND company_id=? AND status='pending'",
                (app_id, company["company_id"]),
            ) as cur:
                app = await cur.fetchone()
            if not app:
                await db.rollback()
                return {"ok": False, "reason": "unknown_application"}
            await db.execute(
                "UPDATE company_applications SET desired_salary=?, status='negotiating' WHERE app_id=?", (salary, app_id))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await _notify(app[0], f"🏢 <b>{escape(str(company['name']))}</b> vous propose un salaire de {_fmt(salary)}. "
                          "Ouvrez cette action depuis 🎮 Menu → 🏢 Entreprises.")
    return {"ok": True, "app_id": app_id, "salary": salary}


async def respond_offer(user_id: int, full_name: str, app_id: int, accept: bool) -> dict:
    """Le candidat répond à la contre-offre de l'entreprise."""
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT company_id, desired_salary, status FROM company_applications WHERE app_id=? AND user_id=?",
                (app_id, user_id),
            ) as cur:
                app = await cur.fetchone()
            if not app or app[2] != "negotiating":
                await db.rollback()
                return {"ok": False, "reason": "no_offer"}
            company_id, salary = app[0], app[1]
            async with db.execute("SELECT owner_id FROM companies WHERE company_id=?", (company_id,)) as cur:
                owner = await cur.fetchone()
            if accept:
                refusal = await _hire(db, user_id, company_id, salary)
                if refusal:
                    await db.rollback()
                    return {"ok": False, "reason": refusal}
                await db.execute("UPDATE company_applications SET status='accepted' WHERE app_id=?", (app_id,))
            else:
                await db.execute("UPDATE company_applications SET status='refused' WHERE app_id=?", (app_id,))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    owner_id = owner[0] if owner else None
    if accept:
        await database.log_company_action(company_id, "recrutement", user_id, f"{full_name} salaire {_fmt(salary)}")
        await _notify(owner_id, f"📢 {full_name} a accepté votre offre pour un salaire de {_fmt(salary)}.")
    else:
        await _notify(owner_id, f"📢 {full_name} a refusé votre offre.")
    return {"ok": True, "accepted": accept, "salary": salary, "company_id": company_id}


async def refuse_application(actor_id: int, app_id: int) -> dict:
    company = await database.get_user_company(actor_id)
    if not company or not await can_manage(actor_id, company):
        return {"ok": False, "reason": "not_manager"}
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT user_id FROM company_applications WHERE app_id=? AND company_id=?",
                (app_id, company["company_id"]),
            ) as cur:
                app = await cur.fetchone()
            if not app:
                await db.rollback()
                return {"ok": False, "reason": "unknown_application"}
            await db.execute(
                "UPDATE company_applications SET status='refused' WHERE app_id=? AND company_id=?",
                (app_id, company["company_id"]))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await _notify(app[0], f"❌ Votre candidature pour <b>{escape(str(company['name']))}</b> a été refusée.")
    return {"ok": True, "app_id": app_id}


async def resign(user_id: int, full_name: str) -> dict:
    company = await database.get_user_company(user_id)
    if not company:
        return {"ok": False, "reason": "no_company"}
    if company["owner_id"] == user_id:
        return {"ok": False, "reason": "is_owner"}
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await db.execute("DELETE FROM company_members WHERE user_id=? AND company_id=?",
                             (user_id, company["company_id"]))
            await db.execute("DELETE FROM company_shares WHERE user_id=? AND company_id=?",
                             (user_id, company["company_id"]))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await _notify(company["owner_id"], f"📢 {full_name} a démissionné de <b>{escape(str(company['name']))}</b>.")
    await database.log_company_action(company["company_id"], "démission", user_id, full_name)
    return {"ok": True, "company_name": company["name"]}


async def set_pay(owner_id: int, target_id: int, salary: int, poste: str | None = None) -> dict:
    """PDG : change le salaire (et le poste, si fourni) d'un employé de son entreprise."""
    company = await database.get_user_company(owner_id)
    if not company or company["owner_id"] != owner_id:
        return {"ok": False, "reason": "not_owner"}
    if salary < 0:
        return {"ok": False, "reason": "invalid_salary"}
    poste = (poste or "").strip()[:60] or None
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            if poste:
                cur = await db.execute(
                    "UPDATE company_members SET poste=?, base_salary=? WHERE user_id=? AND company_id=?",
                    (poste, salary, target_id, company["company_id"]))
            else:
                cur = await db.execute(
                    "UPDATE company_members SET base_salary=? WHERE user_id=? AND company_id=?",
                    (salary, target_id, company["company_id"]))
            if cur.rowcount != 1:
                await db.rollback()
                return {"ok": False, "reason": "target_not_member"}
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    target = await database.get_user(target_id)
    name = target["full_name"] if target else str(target_id)
    if poste:
        await database.log_company_action(company["company_id"], "promotion", owner_id,
                                          f"{name} → {poste} ({_fmt(salary)})")
        await _notify(target_id, f"👔 Félicitations ! Vous êtes promu(e) **{poste}** avec un salaire de "
                                 f"{_fmt(salary)} dans <b>{escape(str(company['name']))}</b>.")
    else:
        await database.log_company_action(company["company_id"], "ajustement_salaire", owner_id,
                                          f"{name} → {_fmt(salary)}")
        await _notify(target_id, f"💰 Votre salaire chez <b>{escape(str(company['name']))}</b> a été modifié : "
                                 f"{_fmt(salary)}/paie.")
    return {"ok": True, "target_name": name, "salary": salary, "poste": poste}


async def fire(actor_id: int, target_id: int) -> dict:
    company = await database.get_user_company(actor_id)
    if not company or not await can_manage(actor_id, company):
        return {"ok": False, "reason": "not_manager"}
    if target_id == actor_id:
        return {"ok": False, "reason": "self"}
    if await get_role(actor_id, company) != "owner" and await get_role(target_id, company) != "employe":
        return {"ok": False, "reason": "owner_only"}
    cid = company["company_id"]
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT base_salary FROM company_members WHERE user_id=? AND company_id=?", (target_id, cid)
            ) as cur:
                emp = await cur.fetchone()
            if not emp:
                await db.rollback()
                return {"ok": False, "reason": "target_not_member"}
            severance = emp[0] * 2
            async with db.execute("SELECT treasury FROM companies WHERE company_id=?", (cid,)) as cur:
                treasury = (await cur.fetchone())[0]
            can_pay = treasury >= severance
            await db.execute("DELETE FROM company_members WHERE user_id=? AND company_id=?", (target_id, cid))
            await db.execute("DELETE FROM company_shares WHERE user_id=? AND company_id=?", (target_id, cid))
            if can_pay and severance:
                await db.execute("UPDATE companies SET treasury=treasury-? WHERE company_id=?", (severance, cid))
                await db.execute(
                    "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                    (severance, severance, target_id))
                await database.snapshot_user_core_stats(target_id, db)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    target = await database.get_user(target_id)
    name = target["full_name"] if target else str(target_id)
    if can_pay:
        await _notify(target_id, f"⚠️ Vous avez été licencié(e) de <b>{escape(str(company['name']))}</b>. "
                                 f"Indemnités : {_fmt(severance)}.")
    else:
        await _notify(target_id, f"⚠️ Vous avez été licencié(e) de <b>{escape(str(company['name']))}</b> "
                                 "sans indemnités (trésorerie insuffisante).")
    await database.log_company_action(cid, "licenciement", actor_id, name)
    return {"ok": True, "target_name": name, "severance": severance, "severance_paid": can_pay}
