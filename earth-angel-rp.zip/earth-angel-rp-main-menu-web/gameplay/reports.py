"""gameplay/reports.py — Signalements (bugs, idées, exploits, harcèlement, joueurs signalés).

Service partagé par `handlers/reporting.py` (bot) et `webapp/routers/reports_router.py`
(Mini App / Web). Types, statuts, anti-spam (cooldown 5 min hors staff, 1 h par cible), saisie
minimale et traitement staff sont décidés ici, une seule fois.
"""
from __future__ import annotations

import aiosqlite

from database import add_notification, db_connection, get_user, now
from utils.cooldowns import claim_cooldown
from utils.decorators import get_user_role_async

REPORT_TYPES = {
    "bug": {"name": "Bug / Erreur", "emoji": "🐛", "priority": 1,
            "auto_response": "Merci d'avoir signalé ce bug ! Notre équipe va l'examiner."},
    "suggestion": {"name": "Suggestion / Idée", "emoji": "💡", "priority": 2,
                   "auto_response": "Merci pour ta suggestion ! Nous l'étudions avec attention."},
    "exploit": {"name": "Exploit / Triche", "emoji": "⚠️", "priority": 0,
                "auto_response": "Merci d'avoir signalé cet exploit. Une enquête va être menée."},
    "harassment": {"name": "Harcèlement / Toxicité", "emoji": "🚫", "priority": 0,
                   "auto_response": "Nous prenons ce signalement très au sérieux. Des mesures seront prises."},
    "other": {"name": "Autre", "emoji": "📝", "priority": 2, "auto_response": "Merci pour ton retour !"},
}
REPORT_COOLDOWN_KEY = "report_cooldown"
REPORT_COOLDOWN = 300            # 5 min entre deux signalements (staff exempté)
TARGET_COOLDOWN = 3600           # 1 h entre deux signalements contre la même cible
MIN_LEN = 5
MAX_LEN = 1000

STATUS_EMOJI = {"pending": "⏳", "in_progress": "🔨", "resolved": "✅", "rejected": "❌"}
STATUS_LABEL = {
    "pending": "⏳ remis en attente",
    "in_progress": "🔨 en cours de traitement",
    "resolved": "✅ résolu",
    "rejected": "❌ rejeté",
}
# codes courts pour les boutons staff (le callback_data Telegram est limité à 64 caractères)
STATUS_CODE = {"pe": "pending", "ip": "in_progress", "ok": "resolved", "no": "rejected"}


# ─── Accès base ──────────────────────────────────────────────────────────────────────────────────
async def add_report(user_id: int, report_type: str, message: str, target_id: int = None):
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO reports (user_id, report_type, message, target_id, status, created_at) "
            "VALUES (?, ?, ?, ?, 'pending', ?)", (user_id, report_type, message, target_id, now()))
        await db.commit()


async def get_reports(status: str = "pending", limit: int = 50) -> list:
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT r.*, u.full_name as reporter_name FROM reports r JOIN users u ON u.user_id = r.user_id "
            "WHERE r.status = ? ORDER BY r.created_at ASC LIMIT ?", (status, limit)
        ) as cur:
            return [dict(row) for row in await cur.fetchall()]


async def get_user_reports(user_id: int, limit: int = 20) -> list:
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM reports WHERE user_id = ? ORDER BY created_at DESC LIMIT ?", (user_id, limit)
        ) as cur:
            return [dict(row) for row in await cur.fetchall()]


async def has_recent_target_report(user_id: int, target_id: int, seconds: int = TARGET_COOLDOWN) -> bool:
    async with db_connection() as db:
        async with db.execute(
            "SELECT 1 FROM reports WHERE user_id = ? AND target_id = ? AND created_at >= ? LIMIT 1",
            (user_id, target_id, now() - seconds)
        ) as cur:
            return await cur.fetchone() is not None


async def update_report_status(report_id: int, status: str, admin_response: str = None):
    async with db_connection() as db:
        await db.execute(
            "UPDATE reports SET status = ?, admin_response = ?, resolved_at = ? WHERE id = ?",
            (status, admin_response, now(), report_id))
        await db.commit()


async def get_report_stats() -> dict:
    async with db_connection() as db:
        stats = {}
        for status in ["pending", "in_progress", "resolved", "rejected"]:
            async with db.execute("SELECT COUNT(*) FROM reports WHERE status = ?", (status,)) as cur:
                stats[status] = (await cur.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM reports WHERE created_at > ?", (now() - 86400 * 7,)) as cur:
            stats["last_7_days"] = (await cur.fetchone())[0]
        async with db.execute(
            "SELECT report_type, COUNT(*) FROM reports GROUP BY report_type ORDER BY COUNT(*) DESC"
        ) as cur:
            stats["by_type"] = {row[0]: row[1] for row in await cur.fetchall()}
        return stats


# ─── Règles ──────────────────────────────────────────────────────────────────────────────────────
async def is_staff(user_id: int) -> bool:
    u = await get_user(user_id)
    return (await get_user_role_async(user_id)) != "PLAYER" or bool(u.get("god_mode"))


def classify_player_report(reason: str) -> str:
    """Signalement d'un joueur : harcèlement si le texte le dit, sinon exploit/triche."""
    return "harassment" if any(w in reason.lower() for w in ("harcè", "harce", "insulte", "menace")) else "exploit"


async def claim(user_id: int) -> tuple[bool, int]:
    """Cooldown atomique entre deux signalements (le staff en est exempté)."""
    if await is_staff(user_id):
        return True, 0
    return await claim_cooldown(user_id, REPORT_COOLDOWN_KEY, REPORT_COOLDOWN)


async def check_target(user_id: int, target_id: int) -> str | None:
    """Raison de refus pour un signalement contre `target_id`, sinon None."""
    if target_id == user_id:
        return "self_target"
    if await has_recent_target_report(user_id, target_id):
        return "recent_target"
    return None


async def submit(user_id: int, report_type: str | None, message: str, target_id: int | None = None) -> dict:
    """Enregistre un signalement (général, ou contre un joueur si `target_id`)."""
    message = (message or "").strip()[:MAX_LEN]
    if len(message) < MIN_LEN:
        return {"ok": False, "reason": "too_short", "min": MIN_LEN}
    if target_id is not None:
        async with db_connection() as db:
            async with db.execute("SELECT 1 FROM users WHERE user_id=?", (target_id,)) as cur:
                if not await cur.fetchone():
                    return {"ok": False, "reason": "unknown_target"}
        refusal = await check_target(user_id, target_id)
        if refusal:
            return {"ok": False, "reason": refusal}
        report_type = classify_player_report(message)
    elif report_type not in REPORT_TYPES:
        report_type = "other"
    ok, remaining = await claim(user_id)
    if not ok:
        return {"ok": False, "reason": "cooldown", "remaining": remaining}
    await add_report(user_id, report_type, message, target_id)
    return {"ok": True, "report_type": report_type, "auto_response": REPORT_TYPES[report_type]["auto_response"]}


async def set_status(report_id: int, status: str, response: str | None = None) -> int | None:
    """Traite un signalement (staff) et notifie son auteur. Renvoie l'id de l'auteur, None si introuvable."""
    if status not in STATUS_LABEL:
        raise ValueError("statut invalide")
    async with db_connection() as db:
        async with db.execute("SELECT user_id FROM reports WHERE id = ?", (report_id,)) as cur:
            report = await cur.fetchone()
    if not report:
        return None
    reporter_id = report[0]
    await update_report_status(report_id, status, response)
    message = f"📢 Signalement #{report_id} : {STATUS_LABEL[status]}"
    if response:
        message += f" — {response[:80]}"
    try:
        await add_notification(reporter_id, message)
    except Exception:
        pass
    return reporter_id
