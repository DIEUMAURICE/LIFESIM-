"""Règles métier partagées pour l'arbre familial."""
from __future__ import annotations

from database import db_connection, now, snapshot_user_core_stats

ADOPTION_COST = 50_000
MAX_ADOPTED_CHILDREN = 5
MIN_PARENT_AGE = 25
MAX_CHILD_AGE_EXCLUSIVE = 20


class FamilyError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


async def adopt_child(parent_id: int, child_id: int) -> dict:
    """Adopte un joueur mineur, en débitant le coût dans la même transaction."""
    if int(parent_id) == int(child_id):
        raise FamilyError("self_adoption", "Tu ne peux pas t'adopter toi-même.")

    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute(
            "SELECT user_id,registered,COALESCE(age,0),COALESCE(balance,0),"
            "COALESCE(NULLIF(full_name,''),username,'') FROM users WHERE user_id=?",
            (int(parent_id),),
        ) as cur:
            parent = await cur.fetchone()
        async with db.execute(
            "SELECT user_id,registered,COALESCE(age,0),COALESCE(NULLIF(full_name,''),username,'') "
            "FROM users WHERE user_id=?",
            (int(child_id),),
        ) as cur:
            child = await cur.fetchone()

        if not parent or not parent[1]:
            await db.rollback()
            raise FamilyError("parent_missing", "Compte parent introuvable.")
        if not child or not child[1]:
            await db.rollback()
            raise FamilyError("child_missing", "Joueur cible introuvable.")
        if int(parent[2] or 0) < MIN_PARENT_AGE:
            await db.rollback()
            raise FamilyError("parent_too_young", "Tu dois avoir au moins 25 ans pour adopter.")
        if int(child[2] or 0) >= MAX_CHILD_AGE_EXCLUSIVE:
            await db.rollback()
            raise FamilyError("child_too_old", "Tu ne peux adopter qu'un mineur (moins de 20 ans).")
        if int(parent[3] or 0) < ADOPTION_COST:
            await db.rollback()
            raise FamilyError("insufficient_funds", f"L'adoption coûte {ADOPTION_COST:,} €A.")

        async with db.execute("SELECT 1 FROM adoptions WHERE child_id=?", (int(child_id),)) as cur:
            if await cur.fetchone():
                await db.rollback()
                raise FamilyError("already_adopted", "Ce joueur a déjà été adopté.")
        async with db.execute("SELECT COUNT(*) FROM adoptions WHERE parent_id=?", (int(parent_id),)) as cur:
            count = int((await cur.fetchone())[0])
        if count >= MAX_ADOPTED_CHILDREN:
            await db.rollback()
            raise FamilyError("limit_reached", "Tu ne peux adopter que 5 enfants maximum.")

        debit = await db.execute(
            "UPDATE users SET balance=balance-?,total_spent=total_spent+? "
            "WHERE user_id=? AND registered=1 AND balance>=?",
            (ADOPTION_COST, ADOPTION_COST, int(parent_id), ADOPTION_COST),
        )
        if debit.rowcount != 1:
            await db.rollback()
            raise FamilyError("insufficient_funds", f"L'adoption coûte {ADOPTION_COST:,} €A.")
        await db.execute(
            "INSERT INTO adoptions (parent_id,child_id,adopted_at) VALUES (?,?,?)",
            (int(parent_id), int(child_id), now()),
        )
        from utils.treasury import collect
        await collect(db, ADOPTION_COST, "etat_civil")
        await snapshot_user_core_stats(int(parent_id), db)
        await db.commit()

    return {
        "parent_id": int(parent_id),
        "parent_name": parent[4] or f"Joueur {parent_id}",
        "child_id": int(child_id),
        "child_name": child[3] or f"Joueur {child_id}",
        "cost_paid": ADOPTION_COST,
        "adopted_at": now(),
    }


async def adoptions_for_user(user_id: int) -> dict:
    async with db_connection() as db:
        async with db.execute(
            "SELECT a.child_id,u.full_name,u.username,u.age,a.adopted_at "
            "FROM adoptions a LEFT JOIN users u ON u.user_id=a.child_id "
            "WHERE a.parent_id=? ORDER BY a.adopted_at,a.id",
            (int(user_id),),
        ) as cur:
            children = await cur.fetchall()
        async with db.execute(
            "SELECT a.parent_id,u.full_name,u.username,u.age,a.adopted_at "
            "FROM adoptions a LEFT JOIN users u ON u.user_id=a.parent_id "
            "WHERE a.child_id=? ORDER BY a.adopted_at LIMIT 1",
            (int(user_id),),
        ) as cur:
            parent = await cur.fetchone()
    return {
        "children": [
            {"user_id": int(row[0]), "name": row[1] or row[2] or f"Joueur {row[0]}",
             "age": int(row[3] or 0), "adopted_at": int(row[4] or 0)}
            for row in children
        ],
        "parent": (
            {"user_id": int(parent[0]), "name": parent[1] or parent[2] or f"Joueur {parent[0]}",
             "age": int(parent[3] or 0), "adopted_at": int(parent[4] or 0)}
            if parent else None
        ),
        "cost": ADOPTION_COST,
        "max_children": MAX_ADOPTED_CHILDREN,
    }


async def transfer_family_founder(actor_id: int, target_id: int) -> dict:
    if int(actor_id) == int(target_id):
        raise FamilyError("self_transfer", "Tu ne peux pas te transférer à toi-même.")
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute(
            "SELECT family_id,name FROM family WHERE founder_id=?", (int(actor_id),)
        ) as cur:
            family = await cur.fetchone()
        if not family:
            await db.rollback()
            raise FamilyError("not_founder", "Tu n'es pas le fondateur d'un clan.")
        async with db.execute(
            "SELECT 1 FROM family_members WHERE family_id=? AND user_id=?",
            (int(family[0]), int(target_id)),
        ) as cur:
            is_member = await cur.fetchone()
        if not is_member:
            await db.rollback()
            raise FamilyError("target_not_member", "Le joueur cible n'est pas membre de ton clan.")
        await db.execute("UPDATE family SET founder_id=? WHERE family_id=?", (int(target_id), int(family[0])))
        await db.execute(
            "UPDATE family_members SET role='Fondateur' WHERE family_id=? AND user_id=?",
            (int(family[0]), int(target_id)),
        )
        await db.execute(
            "UPDATE family_members SET role='Ex-fondateur' WHERE family_id=? AND user_id=?",
            (int(family[0]), int(actor_id)),
        )
        await db.commit()
    return {"family_id": int(family[0]), "family_name": family[1], "founder_id": int(target_id), "former_founder_id": int(actor_id)}


async def dissolve_family(actor_id: int) -> dict:
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute(
            "SELECT family_id,name FROM family WHERE founder_id=?", (int(actor_id),)
        ) as cur:
            family = await cur.fetchone()
        if not family:
            await db.rollback()
            raise FamilyError("not_founder", "Tu n'es pas le fondateur d'un clan.")
        await db.execute("DELETE FROM family_invites WHERE family_id=?", (int(family[0]),))
        await db.execute("DELETE FROM family_members WHERE family_id=?", (int(family[0]),))
        await db.execute("DELETE FROM family WHERE family_id=?", (int(family[0]),))
        await db.commit()
    return {"family_id": int(family[0]), "family_name": family[1], "dissolved": True}
