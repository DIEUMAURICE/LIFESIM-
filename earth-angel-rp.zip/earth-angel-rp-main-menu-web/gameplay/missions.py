"""Lectures métier communes des missions et de leurs récompenses."""
from __future__ import annotations

import aiosqlite

from database import db_connection


async def reward_summary(user_id: int) -> dict:
    """Retourne les montants effectivement versés, sans recalculer les boosts actuels."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT mission_name, period, completed_at FROM missions "
            "WHERE user_id=? AND completed=1 ORDER BY completed_at DESC",
            (user_id,),
        ) as cur:
            completed = [dict(row) for row in await cur.fetchall()]
        entries: list[dict] = []
        for mission in completed:
            async with db.execute(
                "SELECT reward, xp FROM mission_log WHERE user_id=? AND mission_name=? AND completed_at=? "
                "ORDER BY id DESC LIMIT 1",
                (user_id, mission["mission_name"], mission["completed_at"]),
            ) as cur:
                row = await cur.fetchone()
            if row:
                entries.append({
                    "name": mission["mission_name"],
                    "period": mission["period"],
                    "reward": int(row["reward"]),
                    "xp": int(row["xp"]),
                    "completed_at": mission["completed_at"],
                })
    return {
        "completed_count": len(entries),
        "total_coins": sum(item["reward"] for item in entries),
        "total_xp": sum(item["xp"] for item in entries),
        "missions": entries,
    }
