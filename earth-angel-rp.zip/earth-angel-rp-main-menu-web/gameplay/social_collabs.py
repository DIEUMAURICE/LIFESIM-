"""Règles métier partagées des collaborations du Réseau social."""
from __future__ import annotations

from config import SOCIAL_COLLAB_COST
from database import add_notification, db_connection, now

COLLAB_TYPES = {
    "live": "Live commun",
    "giveaway": "Giveaway",
    "cross": "Cross-promo",
}
COLLAB_DURATION_HOURS = 24
FOLLOWER_REWARD = 100


class SocialCollabError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _display_name(row, fallback_id: int) -> str:
    if row:
        return row[0] or f"Joueur {fallback_id}"
    return f"Joueur {fallback_id}"


async def _registered_player(db, user_id: int):
    async with db.execute(
        "SELECT user_id,COALESCE(NULLIF(full_name,''),username,'') AS display_name,balance "
        "FROM users WHERE user_id=? AND registered=1",
        (user_id,),
    ) as cur:
        return await cur.fetchone()


async def resolve_target(target: str | int, requester_id: int) -> dict:
    """Résout un @username ou un ID signé (les comptes Web ont un ID négatif)."""
    value = str(target or "").strip()
    if not value:
        raise SocialCollabError("target_missing", "Indique l’identifiant ou le @pseudo du joueur.")
    candidate = value.lstrip("@").strip()
    async with db_connection() as db:
        row = None
        if candidate:
            async with db.execute(
                "SELECT user_id,COALESCE(NULLIF(full_name,''),username,'') AS display_name "
                "FROM users WHERE username=? AND registered=1 LIMIT 1",
                (candidate,),
            ) as cur:
                row = await cur.fetchone()
        if row is None:
            try:
                target_id = int(candidate)
            except (TypeError, ValueError):
                target_id = None
            if target_id is not None:
                async with db.execute(
                    "SELECT user_id,COALESCE(NULLIF(full_name,''),username,'') AS display_name "
                    "FROM users WHERE user_id=? AND registered=1",
                    (target_id,),
                ) as cur:
                    row = await cur.fetchone()
    if not row:
        raise SocialCollabError("target_missing", "Joueur introuvable.")
    target_id = int(row[0])
    if target_id == requester_id:
        raise SocialCollabError("self_target", "Tu ne peux pas collaborer avec toi-même.")
    return {"user_id": target_id, "name": _display_name(row[1:2], target_id)}


async def _active_for(db, user_id: int, current: int):
    async with db.execute(
        """SELECT id,from_id,to_id,collab_type,expires_at
           FROM social_active_collabs
           WHERE expires_at>? AND (from_id=? OR to_id=?)
           ORDER BY expires_at DESC LIMIT 1""",
        (current, user_id, user_id),
    ) as cur:
        row = await cur.fetchone()
    return row


async def create_request(from_id: int, target: str | int, collab_type: str,
                         duration_h: int = COLLAB_DURATION_HOURS,
                         notify_target: bool = True) -> dict:
    if collab_type not in COLLAB_TYPES:
        raise SocialCollabError("invalid_type", "Type inconnu. Choisis live, giveaway ou cross.")
    if int(duration_h) <= 0:
        raise SocialCollabError("invalid_duration", "La durée doit être positive.")
    target_player = await resolve_target(target, from_id)
    to_id = target_player["user_id"]
    current = now()
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        requester = await _registered_player(db, from_id)
        if not requester:
            await db.rollback()
            raise SocialCollabError("requester_missing", "Compte joueur introuvable.")
        if int(requester["balance"] or 0) < SOCIAL_COLLAB_COST:
            await db.rollback()
            raise SocialCollabError("insufficient_funds", f"Solde insuffisant. Besoin de {SOCIAL_COLLAB_COST:,} €A.")
        active = await _active_for(db, from_id, current)
        if active:
            await db.rollback()
            raise SocialCollabError("requester_busy", "Tu as déjà une collaboration active. Attends sa fin.")
        active_target = await _active_for(db, to_id, current)
        if active_target:
            await db.rollback()
            raise SocialCollabError("target_busy", "Ce joueur a déjà une collaboration active.")
        cur = await db.execute(
            "INSERT INTO social_collab_requests (from_id,to_id,collab_type,duration_h,created_at) "
            "VALUES (?,?,?,?,?)",
            (from_id, to_id, collab_type, int(duration_h), current),
        )
        request_id = int(cur.lastrowid)
        requester_name = _display_name(requester[1:2], from_id)
        await db.commit()
    # Une notification persistée donne au joueur Web une voie d’accès à la demande;
    # Telegram conserve aussi son DM natif avec boutons Accepter/Refuser.
    if notify_target:
        await add_notification(
            to_id,
            f"🤝 Collaboration proposée par {requester_name} ({COLLAB_TYPES[collab_type]}, "
            f"{int(duration_h)} h). Ouvre Social → Collaborations pour répondre.",
        )
    return {
        "request_id": request_id,
        "from_id": from_id,
        "to_id": to_id,
        "target_name": target_player["name"],
        "requester_name": requester_name,
        "collab_type": collab_type,
        "type_label": COLLAB_TYPES[collab_type],
        "duration_h": int(duration_h),
        "cost": SOCIAL_COLLAB_COST,
        "status": "pending",
    }


async def collaborations_for_user(user_id: int) -> dict:
    current = now()
    async with db_connection() as db:
        async with db.execute(
            """SELECT c.id,c.from_id,c.to_id,c.collab_type,c.expires_at,
                      COALESCE(NULLIF(a.full_name,''),a.username,'') AS from_name,
                      COALESCE(NULLIF(b.full_name,''),b.username,'') AS to_name
               FROM social_active_collabs c
               LEFT JOIN users a ON a.user_id=c.from_id
               LEFT JOIN users b ON b.user_id=c.to_id
               WHERE c.expires_at>? AND (c.from_id=? OR c.to_id=?)
               ORDER BY c.expires_at DESC LIMIT 5""",
            (current, user_id, user_id),
        ) as cur:
            active_rows = await cur.fetchall()
        async with db.execute(
            """SELECT r.request_id,r.from_id,r.to_id,r.collab_type,r.duration_h,r.created_at,
                      COALESCE(NULLIF(a.full_name,''),a.username,'') AS from_name,
                      COALESCE(NULLIF(b.full_name,''),b.username,'') AS to_name
               FROM social_collab_requests r
               LEFT JOIN users a ON a.user_id=r.from_id
               LEFT JOIN users b ON b.user_id=r.to_id
               WHERE r.status='pending' AND (r.from_id=? OR r.to_id=?)
               ORDER BY r.created_at DESC,r.request_id DESC LIMIT 30""",
            (user_id, user_id),
        ) as cur:
            requests = await cur.fetchall()
        async with db.execute(
            """SELECT user_id,COALESCE(NULLIF(full_name,''),username,'') AS display_name
               FROM users WHERE registered=1 AND user_id<>?
               ORDER BY social_followers DESC,user_id LIMIT 40""",
            (user_id,),
        ) as cur:
            players = await cur.fetchall()
    active = [{
        "id": int(row["id"]),
        "from_id": int(row["from_id"]),
        "to_id": int(row["to_id"]),
        "other_id": int(row["to_id"] if int(row["from_id"]) == user_id else row["from_id"]),
        "other_name": _display_name(
            (row["to_name"] or "",) if int(row["from_id"]) == user_id else (row["from_name"] or "",),
            int(row["to_id"] if int(row["from_id"]) == user_id else row["from_id"]),
        ),
        "collab_type": row["collab_type"],
        "type_label": COLLAB_TYPES.get(row["collab_type"], row["collab_type"]),
        "expires_at": int(row["expires_at"]),
        "seconds_left": max(0, int(row["expires_at"]) - current),
    } for row in active_rows]
    incoming, outgoing = [], []
    for row in requests:
        is_incoming = int(row["to_id"]) == user_id
        other_id = int(row["from_id"] if is_incoming else row["to_id"])
        other_name = _display_name(
            (row["from_name"] or "",) if is_incoming else (row["to_name"] or "",),
            other_id,
        )
        item = {
            "request_id": int(row["request_id"]),
            "from_id": int(row["from_id"]),
            "to_id": int(row["to_id"]),
            "other_id": other_id,
            "other_name": other_name,
            "collab_type": row["collab_type"],
            "type_label": COLLAB_TYPES.get(row["collab_type"], row["collab_type"]),
            "duration_h": int(row["duration_h"]),
            "created_at": int(row["created_at"]),
        }
        (incoming if is_incoming else outgoing).append(item)
    return {
        "active": active,
        "incoming": incoming,
        "outgoing": outgoing,
        "players": [{"user_id": int(row["user_id"]),
                     "name": _display_name((row["display_name"],), int(row["user_id"]))}
                    for row in players],
        "cost": SOCIAL_COLLAB_COST,
        "duration_h": COLLAB_DURATION_HOURS,
        "types": [{"id": key, "label": label} for key, label in COLLAB_TYPES.items()],
    }


async def respond_to_request(request_id: int, actor_id: int, action: str,
                             notify_requester: bool = True) -> dict:
    if action not in ("accept", "refuse"):
        raise SocialCollabError("invalid_action", "Action inconnue.")
    current = now()
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute(
            "SELECT from_id,to_id,collab_type,duration_h,status "
            "FROM social_collab_requests WHERE request_id=?",
            (request_id,),
        ) as cur:
            request = await cur.fetchone()
        if not request:
            await db.rollback()
            raise SocialCollabError("not_found", "Demande introuvable.")
        from_id, to_id, collab_type, duration_h, status = request
        if int(to_id) != actor_id:
            await db.rollback()
            raise SocialCollabError("forbidden", "Cette demande ne t’est pas destinée.")
        if status != "pending":
            await db.rollback()
            raise SocialCollabError("processed", f"Demande déjà traitée ({status}).")
        if action == "accept":
            # Une demande peut rester en attente pendant qu'un participant démarre
            # une autre collaboration ou que le proposant dépense son solde.
            # Revalider sous BEGIN IMMEDIATE évite les doubles réservations et débits.
            requester = await _registered_player(db, int(from_id))
            if not requester:
                await db.rollback()
                raise SocialCollabError("requester_missing", "Le demandeur n’a plus de compte joueur actif.")
            if int(requester["balance"] or 0) < SOCIAL_COLLAB_COST:
                await db.rollback()
                raise SocialCollabError("insufficient_funds", "Le demandeur n’a plus les fonds nécessaires pour cette collaboration.")
            if await _active_for(db, int(from_id), current):
                await db.rollback()
                raise SocialCollabError("requester_busy", "Le demandeur a déjà une collaboration active.")
            if await _active_for(db, int(to_id), current):
                await db.rollback()
                raise SocialCollabError("target_busy", "Tu as déjà une collaboration active.")
            expires_at = current + int(duration_h) * 3600
            await db.execute(
                "INSERT INTO social_active_collabs (from_id,to_id,collab_type,expires_at) VALUES (?,?,?,?)",
                (int(from_id), int(to_id), collab_type, expires_at),
            )
            # Conserve le comportement historique : seul le demandeur paie à
            # l’acceptation. Le garde SQL protège aussi contre un solde modifié.
            debit = await db.execute(
                "UPDATE users SET balance=balance-? WHERE user_id=? AND balance>=?",
                (SOCIAL_COLLAB_COST, int(from_id), SOCIAL_COLLAB_COST),
            )
            if debit.rowcount != 1:
                await db.rollback()
                raise SocialCollabError("insufficient_funds", "Le demandeur n’a plus les fonds nécessaires pour cette collaboration.")
            for participant in (int(from_id), int(to_id)):
                await db.execute(
                    """INSERT INTO social_media
                       (user_id,platform,followers,posts,revenue_per_day,last_post)
                       VALUES (?, 'collab', ?, 0, 0, 0)
                       ON CONFLICT(user_id,platform) DO UPDATE
                       SET followers=social_media.followers+excluded.followers""",
                    (participant, FOLLOWER_REWARD),
                )
                await db.execute(
                    "UPDATE users SET social_followers=COALESCE(social_followers,0)+? WHERE user_id=?",
                    (FOLLOWER_REWARD, participant),
                )
            new_status = "accepted"
        else:
            expires_at = 0
            new_status = "refused"
        await db.execute(
            "UPDATE social_collab_requests SET status=? WHERE request_id=? AND status='pending'",
            (new_status, request_id),
        )
        async with db.execute(
            "SELECT COALESCE(NULLIF(full_name,''),username,'') FROM users WHERE user_id=?",
            (actor_id,),
        ) as cur:
            actor_row = await cur.fetchone()
        actor_name = _display_name(actor_row, actor_id)
        await db.commit()
    label = COLLAB_TYPES.get(collab_type, collab_type)
    if notify_requester:
        if action == "accept":
            await add_notification(
                int(from_id),
                f"🤝 {actor_name} a accepté ta collaboration ({label}, {int(duration_h)} h). "
                f"Vous avez chacun gagné +{FOLLOWER_REWARD} abonnés.",
            )
        else:
            await add_notification(int(from_id), f"❌ {actor_name} a refusé ta collaboration ({label}).")
    return {
        "request_id": request_id,
        "from_id": int(from_id),
        "to_id": int(to_id),
        "collab_type": collab_type,
        "type_label": label,
        "duration_h": int(duration_h),
        "status": new_status,
        "expires_at": expires_at,
        "followers_earned": FOLLOWER_REWARD if action == "accept" else 0,
        "cost_paid": SOCIAL_COLLAB_COST if action == "accept" else 0,
    }
