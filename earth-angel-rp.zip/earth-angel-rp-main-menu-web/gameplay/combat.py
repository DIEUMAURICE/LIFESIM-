"""Moteur de combat PvP commun au bot Telegram et aux clients Web."""
from __future__ import annotations

import random
from dataclasses import dataclass

import aiosqlite

from database import db_connection, get_skill, get_user, now
from handlers.missions import update_mission_progress
from utils.arena_store import get_match, settle_winner
from utils.helpers import get_level
from utils.notify import notify
from utils.vip import add_xp


@dataclass
class CombatResult:
    match_id: str
    winner_id: int
    loser_id: int
    challenger_id: int
    target_id: int
    challenger_name: str
    target_name: str
    challenger_hp: int
    target_hp: int
    logs: list[str]
    pot: int
    loot: str | None = None

    def as_dict(self) -> dict:
        return {
            "match_id": self.match_id,
            "winner_id": self.winner_id,
            "loser_id": self.loser_id,
            "challenger_id": self.challenger_id,
            "target_id": self.target_id,
            "challenger_name": self.challenger_name,
            "target_name": self.target_name,
            "challenger_hp": self.challenger_hp,
            "target_hp": self.target_hp,
            "logs": self.logs,
            "pot": self.pot,
            "loot": self.loot,
        }


async def _add_random_item(user_id: int, min_rarity: str = "common", max_rarity: str = "epic") -> str | None:
    rarity_order = ["common", "rare", "epic", "legendary"]
    min_idx = rarity_order.index(min_rarity)
    max_idx = rarity_order.index(max_rarity)
    chosen = random.choice(rarity_order[min_idx:max_idx + 1])
    async with db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT item_id,name,emoji,rarity FROM items WHERE rarity=? ORDER BY RANDOM() LIMIT 1",
            (chosen,),
        ) as cur:
            item = await cur.fetchone()
        if not item:
            return None
        await db.execute(
            "INSERT INTO inventory(user_id,item_id,item_type,item_name,quantity,acquired_at) VALUES (?,?,?,?,1,?) "
            "ON CONFLICT(user_id,item_id) DO UPDATE SET quantity=quantity+1",
            (user_id, item["item_id"], "loot", item["name"], now()),
        )
        await db.commit()
    return f"{item['emoji']} {item['name']} ({item['rarity']})"


async def resolve_combat(match_id: str) -> CombatResult | None:
    """Résout et crédite un combat une seule fois.

    Le financement et le settlement restent atomiques dans ``arena_store``. Cette fonction
    porte uniquement les règles de combat et les effets communs (statistiques, XP, loot,
    mission et notification), jamais le rendu Telegram/Web.
    """
    match = await get_match(match_id)
    if not match or match.get("status") != "active" or match.get("game") != "combat":
        return None

    challenger = await get_user(match["challenger_id"])
    target = await get_user(match["target_id"])
    c_force = await get_skill(match["challenger_id"], "Force") or 0
    t_force = await get_skill(match["target_id"], "Force") or 0
    c_agi = await get_skill(match["challenger_id"], "Agilité") or 0
    t_agi = await get_skill(match["target_id"], "Agilité") or 0
    c_end = await get_skill(match["challenger_id"], "Endurance") or 0
    t_end = await get_skill(match["target_id"], "Endurance") or 0

    c_power = random.randint(40, 100) + c_force * 5 + c_agi * 3 + c_end * 2 + get_level(challenger.get("xp", 0)) * 3
    t_power = random.randint(40, 100) + t_force * 5 + t_agi * 3 + t_end * 2 + get_level(target.get("xp", 0)) * 3
    c_hp, t_hp = 100, 100
    logs: list[str] = []
    for rd in range(1, 4):
        c_dmg = random.randint(10, max(10, c_power // 3))
        t_dmg = random.randint(10, max(10, t_power // 3))
        t_hp -= c_dmg
        c_hp -= t_dmg
        logs.append(f"• Round {rd} : {challenger.get('full_name', 'Joueur')} inflige {c_dmg}, subit {t_dmg}")
        if c_hp <= 0 or t_hp <= 0:
            break

    winner_id = match["challenger_id"] if c_hp > t_hp else match["target_id"]
    loser_id = match["target_id"] if winner_id == match["challenger_id"] else match["challenger_id"]
    settled = await settle_winner(match_id, winner_id, {"game": "combat", "winner_id": winner_id})
    if not settled:
        return None

    async with db_connection() as db:
        await db.execute("UPDATE users SET arena_wins=COALESCE(arena_wins,0)+1 WHERE user_id=?", (winner_id,))
        await db.execute("UPDATE users SET arena_losses=COALESCE(arena_losses,0)+1 WHERE user_id=?", (loser_id,))
        await db.commit()
    await add_xp(winner_id, 100)
    await add_xp(loser_id, 50)
    await update_mission_progress(winner_id, "arena_win", 1)

    loot = await _add_random_item(winner_id) if random.random() < 0.2 else None
    pot = int(match["pot"])
    result = CombatResult(
        match_id=match_id,
        winner_id=winner_id,
        loser_id=loser_id,
        challenger_id=match["challenger_id"],
        target_id=match["target_id"],
        challenger_name=challenger.get("full_name") or "Joueur",
        target_name=target.get("full_name") or "Joueur",
        challenger_hp=max(0, int(c_hp)),
        target_hp=max(0, int(t_hp)),
        logs=logs,
        pot=pot,
        loot=loot,
    )
    winner_name = result.challenger_name if winner_id == result.challenger_id else result.target_name
    loot_note = f" Item gagné : {loot}." if loot else ""
    await notify(winner_id, "⚔️ Combat remporté", f"Tu remportes le combat et +{pot} €A.{loot_note}", "reward")
    await notify(loser_id, "⚔️ Combat terminé", "Tu as perdu le combat. Tu reçois +50 XP.", "info")
    return result
