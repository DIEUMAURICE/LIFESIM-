"""Opérations métier partagées du jardin."""
from __future__ import annotations

import random

from config import PLANTS
from database import db_connection, now, increment_field, update_field
from utils.vip import add_coins, add_xp

ARREST_JAIL_SECONDS = 7200


class GardenError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


async def harvest_all_ready(user_id: int) -> dict:
    """Récolte toutes les parcelles mûres sous une seule réservation SQL."""
    # Les helpers historiques portent la configuration de saison et les récoltes
    # destinées à la chaîne de production; ils ne dépendent pas de Telegram.
    from handlers.garden import get_season_multiplier, _grant_recolte
    from handlers.missions import update_mission_progress

    season = await get_season_multiplier(user_id)
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT karma FROM users WHERE user_id=? AND registered=1", (user_id,)) as cur:
            user = await cur.fetchone()
        if not user:
            await db.rollback()
            raise GardenError("player_missing", "Compte joueur introuvable.")
        async with db.execute(
            "SELECT plot_id,plant_type,planted_at,water_count FROM garden WHERE user_id=? ORDER BY plot_id",
            (user_id,),
        ) as cur:
            plots = await cur.fetchall()
        current = now()
        ready = []
        for plot in plots:
            data = PLANTS.get(plot[1], {})
            grow_time = int(data.get("grow_time", 0) / season)
            if current >= int(plot[2]) + grow_time:
                ready.append(plot)
        if not ready:
            await db.rollback()
            raise GardenError("none_ready", "Aucune plante prête à récolter.")

        harvested, arrested, remove_ids, total = [], [], [], 0
        karma = int(user[0] or 0)
        for plot_id, plant_type, planted_at, water_count in ready:
            data = PLANTS.get(plant_type, {})
            if data.get("illegal"):
                risk = max(0.05, min(0.4, 0.2 - karma / 5000))
                if random.random() < risk:
                    arrested.append(plant_type)
                    remove_ids.append(int(plot_id))
                    continue
            water_needed = max(1, int(data.get("water_needed", 1)))
            water_bonus = min(1.5, 1.0 + (int(water_count or 0) / water_needed) * 0.5)
            value = int(data.get("value", 0) * water_bonus * season)
            harvested.append({"plot_id": int(plot_id), "plant_type": plant_type,
                              "value": value, "emoji": data.get("emoji", "🌿")})
            total += value
            remove_ids.append(int(plot_id))

        for plot_id in remove_ids:
            await db.execute("DELETE FROM garden WHERE plot_id=? AND user_id=?", (plot_id, user_id))
        if arrested:
            await db.execute(
                "UPDATE users SET prison_until=? WHERE user_id=?",
                (current + ARREST_JAIL_SECONDS, user_id),
            )
        await db.commit()

    if total > 0:
        await add_coins(user_id, total)
        await increment_field(user_id, "plants_grown", len(harvested))
        await _grant_recolte(user_id, len(harvested))
        await add_xp(user_id, len(harvested) * 50)
        await update_mission_progress(user_id, "harvest", 1)
    return {
        "harvested": harvested,
        "arrested": arrested,
        "total": total,
        "xp": len(harvested) * 50,
        "jail_seconds": ARREST_JAIL_SECONDS if arrested else 0,
    }
