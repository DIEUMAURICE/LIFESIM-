"""gameplay/elections.py — Élections : lancement, candidature, vote, dépouillement.

Service pur partagé par `handlers/political.py` (bot) et `webapp/routers/political_router.py`
(Mini App / Web). Chaque fonction renvoie `{"ok": bool, "reason": ...}` ; le handler traduit en
message Telegram, le routeur en erreur HTTP.

Atomicité : le lancement d'une élection (débit du coût + création) et le dépouillement (clôture +
attribution du poste) s'exécutent sous une seule transaction `BEGIN IMMEDIATE`, comme dans
`gameplay/companies.py`. Avant extraction, le coût était débité avant l'insertion de l'élection :
un échec entre les deux faisait perdre l'argent sans élection.
"""
from __future__ import annotations

import aiosqlite

import database
from config import (
    ELECTED_POSTS, ELECTION_COST, ELECTION_DEFAULT_DURATION_HOURS,
    ELECTION_KARMA_REQUIRED, ELECTION_MAX_DURATION_HOURS, POLITICAL_POSTS,
)
from utils import politics
from utils.roles import can_play, install_president, is_politician


def resolve_poste(text: str) -> str | None:
    """Nom de poste insensible à la casse -> forme canonique, ou None."""
    wanted = (text or "").strip().lower()
    return next((p for p in POLITICAL_POSTS if p.lower() == wanted), None)


def clamp_duration(hours) -> int:
    """Durée valide (1..max) sinon durée par défaut — même règle que le parsing historique du bot."""
    try:
        value = int(float(hours))
    except (TypeError, ValueError):
        return ELECTION_DEFAULT_DURATION_HOURS
    return value if 1 <= value <= ELECTION_MAX_DURATION_HOURS else ELECTION_DEFAULT_DURATION_HOURS


async def list_open_elections() -> list[dict]:
    """Élections ouvertes (non expirées) avec candidats, programmes et nombre de voix."""
    now = database.now()
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, poste, started_by, started_at, ends_at FROM elections "
            "WHERE status='open' AND ends_at>? ORDER BY ends_at ASC", (now,)
        ) as cur:
            elections = [dict(r) for r in await cur.fetchall()]
        for election in elections:
            async with db.execute(
                "SELECT c.user_id, c.program, u.full_name, "
                "(SELECT COUNT(*) FROM votes v WHERE v.election_id=c.election_id AND v.candidate_id=c.user_id) AS votes "
                "FROM candidates c LEFT JOIN users u ON u.user_id=c.user_id "
                "WHERE c.election_id=? ORDER BY votes DESC, u.full_name", (election["id"],)
            ) as cur:
                election["candidates"] = [dict(r) for r in await cur.fetchall()]
    return elections


async def my_votes(user_id: int) -> dict[int, int]:
    """election_id -> candidate_id pour les élections où l'utilisateur a déjà voté."""
    async with database.db_connection() as db:
        async with db.execute(
            "SELECT v.election_id, v.candidate_id FROM votes v "
            "JOIN elections e ON e.id=v.election_id WHERE v.voter_id=? AND e.status='open'", (user_id,)
        ) as cur:
            return {row[0]: row[1] for row in await cur.fetchall()}


async def start_election(user_id: int, poste: str, duration_hours=None) -> dict:
    """Lance une élection : coût débité et élection créée dans la même transaction."""
    if poste not in POLITICAL_POSTS:
        return {"ok": False, "reason": "unknown_post"}
    if poste not in ELECTED_POSTS:
        return {"ok": False, "reason": "not_elected_post"}
    hours = clamp_duration(duration_hours) if duration_hours is not None else ELECTION_DEFAULT_DURATION_HOURS
    cost = ELECTION_COST[poste]
    now = database.now()
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT 1 FROM elections WHERE poste=? AND status='open' AND ends_at>?", (poste, now)
            ) as cur:
                if await cur.fetchone():
                    await db.rollback()
                    return {"ok": False, "reason": "already_open"}
            async with db.execute("SELECT balance, karma FROM users WHERE user_id=?", (user_id,)) as cur:
                row = await cur.fetchone()
            if not row:
                await db.rollback()
                return {"ok": False, "reason": "unknown_user"}
            if row[0] < cost:
                await db.rollback()
                return {"ok": False, "reason": "insufficient_funds", "cost": cost}
            if (row[1] or 0) < ELECTION_KARMA_REQUIRED:
                await db.rollback()
                return {"ok": False, "reason": "karma", "required": ELECTION_KARMA_REQUIRED}
            await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=?",
                (cost, cost, user_id),
            )
            from utils.treasury import collect
            await collect(db, cost, "politique")
            cur = await db.execute(
                "INSERT INTO elections (poste, started_by, started_at, ends_at, status) VALUES (?,?,?,?,?)",
                (poste, user_id, now, now + hours * 3600, "open"),
            )
            election_id = cur.lastrowid
            await database.snapshot_user_core_stats(user_id, db)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return {"ok": True, "election_id": election_id, "poste": poste, "cost": cost, "duration_hours": hours}


async def find_open_election(election_id: int | None = None, poste: str | None = None) -> dict | None:
    """Élection ouverte par id, par poste, ou la plus récente (comportement historique de /candidater)."""
    now = database.now()
    sql = "SELECT id, poste, ends_at FROM elections WHERE status='open' AND ends_at>?"
    params: list = [now]
    if election_id is not None:
        sql += " AND id=?"
        params.append(election_id)
    elif poste is not None:
        sql += " AND LOWER(poste)=LOWER(?)"
        params.append(poste)
    sql += " ORDER BY started_at DESC LIMIT 1"
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(sql, params) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def register_candidate(user_id: int, election_id: int, program: str = "") -> dict:
    """Candidature : réservée aux Admins N1 (rôle politique), karma requis, une seule par élection."""
    if not await is_politician(user_id):
        return {"ok": False, "reason": "not_politician"}
    program = (program or "").strip()[:500] or "Aucun programme"
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT poste FROM elections WHERE id=? AND status='open' AND ends_at>?",
                (election_id, database.now()),
            ) as cur:
                election = await cur.fetchone()
            if not election:
                await db.rollback()
                return {"ok": False, "reason": "no_election"}
            async with db.execute(
                "SELECT 1 FROM candidates WHERE election_id=? AND user_id=?", (election_id, user_id)
            ) as cur:
                if await cur.fetchone():
                    await db.rollback()
                    return {"ok": False, "reason": "already_candidate"}
            async with db.execute("SELECT karma FROM users WHERE user_id=?", (user_id,)) as cur:
                row = await cur.fetchone()
            if not row or (row[0] or 0) < ELECTION_KARMA_REQUIRED:
                await db.rollback()
                return {"ok": False, "reason": "karma", "required": ELECTION_KARMA_REQUIRED}
            await db.execute(
                "INSERT INTO candidates (election_id, user_id, program) VALUES (?,?,?)",
                (election_id, user_id, program),
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return {"ok": True, "poste": election[0], "election_id": election_id}


async def cast_vote(user_id: int, election_id: int, candidate_id: int) -> dict:
    """Vote : joueurs et Admins N1 uniquement, un vote par élection, pour un candidat inscrit."""
    if not await can_play(user_id):
        return {"ok": False, "reason": "not_player"}
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT poste FROM elections WHERE id=? AND status='open' AND ends_at>?",
                (election_id, database.now()),
            ) as cur:
                election = await cur.fetchone()
            if not election:
                await db.rollback()
                return {"ok": False, "reason": "no_election"}
            async with db.execute(
                "SELECT 1 FROM votes WHERE election_id=? AND voter_id=?", (election_id, user_id)
            ) as cur:
                if await cur.fetchone():
                    await db.rollback()
                    return {"ok": False, "reason": "already_voted"}
            async with db.execute(
                "SELECT 1 FROM candidates WHERE election_id=? AND user_id=?", (election_id, candidate_id)
            ) as cur:
                if not await cur.fetchone():
                    await db.rollback()
                    return {"ok": False, "reason": "not_candidate"}
            await db.execute(
                "INSERT INTO votes (election_id, voter_id, candidate_id, voted_at) VALUES (?,?,?,?)",
                (election_id, user_id, candidate_id, database.now()),
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return {"ok": True, "poste": election[0]}


async def tally_election(election_id: int, poste: str) -> dict:
    """Dépouille une élection terminée et attribue le poste.

    • Quorum : 20 % des inscrits, borné entre 3 et 50 votes.
    • Égalité en tête ou quorum manqué : élection annulée, candidats prévenus.
    • Idempotent : une élection déjà clôturée n'est pas dépouillée deux fois.
    La clôture et l'attribution du poste sont écrites sous une seule transaction.
    """
    quorum_needed = politics.election_quorum(await politics.registered_count())
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT status FROM elections WHERE id=?", (election_id,)) as cur:
                row = await cur.fetchone()
            if not row or row["status"] != "open":
                await db.rollback()
                return {"ok": False, "reason": "not_open"}
            async with db.execute(
                "SELECT candidate_id, COUNT(*) AS votes FROM votes WHERE election_id=? "
                "GROUP BY candidate_id ORDER BY votes DESC", (election_id,)
            ) as cur:
                results = await cur.fetchall()
            async with db.execute("SELECT user_id FROM candidates WHERE election_id=?", (election_id,)) as cur:
                candidates = [r["user_id"] for r in await cur.fetchall()]
            total_votes = sum(r["votes"] for r in results)
            cancel_reason = None
            if not results or total_votes < quorum_needed:
                cancel_reason = f"quorum non atteint ({total_votes}/{quorum_needed} votes)"
            elif len(results) > 1 and results[0]["votes"] == results[1]["votes"]:
                cancel_reason = f"égalité parfaite ({results[0]['votes']} voix chacun)"
            if cancel_reason:
                await db.execute("UPDATE elections SET status='cancelled' WHERE id=?", (election_id,))
                await db.commit()
            else:
                winner_id = results[0]["candidate_id"]
                winner_votes = results[0]["votes"]
                now = database.now()
                await db.execute("DELETE FROM political_offices WHERE poste=?", (poste,))
                await db.execute(
                    "INSERT INTO political_offices (poste, occupant_id, elected_at, election_id, last_activity) "
                    "VALUES (?,?,?,?,?)", (poste, winner_id, now, election_id, now))
                await db.execute("UPDATE elections SET status='closed' WHERE id=?", (election_id,))
                await db.execute("UPDATE users SET political_post=?, prestige=prestige+50 WHERE user_id=?",
                                 (poste, winner_id))
                await database.snapshot_user_core_stats(winner_id, db)
                await db.commit()
        except Exception:
            await db.rollback()
            raise

    if cancel_reason:
        await politics.log_event("election", f"Élection {poste} annulée : {cancel_reason}")
        for uid in candidates:
            try:
                await database.add_notification(
                    uid, f"🗳️ L'élection pour {poste} est annulée : {cancel_reason}. "
                         "Une nouvelle élection peut être lancée.")
            except Exception:
                pass
        return {"ok": True, "outcome": "cancelled", "reason": cancel_reason}

    if poste == "Président":
        try:
            await install_president(winner_id)  # prend la tête de l'Administration
        except Exception:
            import logging
            logging.getLogger(__name__).exception("Installation du président impossible")
    name = await politics.display_name(winner_id)
    await politics.log_event("election", f"{name} élu {poste} avec {winner_votes} voix sur {total_votes}", winner_id)
    try:
        await database.add_notification(winner_id, f"🏆 Tu as remporté l'élection pour {poste} avec {winner_votes} voix !")
        for uid in candidates:
            if uid != winner_id:
                await database.add_notification(
                    uid, f"🗳️ {name} remporte l'élection pour {poste} ({winner_votes} voix sur {total_votes}).")
    except Exception:
        pass
    return {"ok": True, "outcome": "elected", "winner_id": winner_id, "votes": winner_votes, "total": total_votes}
