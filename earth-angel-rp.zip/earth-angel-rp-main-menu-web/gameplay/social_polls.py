"""Règles communes des sondages du Réseau RP (bot Telegram, Mini App et Web)."""
from __future__ import annotations

import json
import logging

import aiosqlite
from database import db_connection, now
from utils.notify import notify

logger = logging.getLogger(__name__)
POLL_DURATION = 2 * 86400  # deux jours de jeu
MAX_POLLS_PER_DAY = 3
POLL_MILESTONES = (5, 10, 25, 50, 100)
MAX_OPTIONS = 4


class PollError(ValueError):
    """Refus métier explicite d'une opération sur un sondage."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _options(raw_options) -> list[str]:
    if not isinstance(raw_options, (list, tuple)):
        raise PollError("invalid_options", "Les options doivent être une liste de 2 à 4 choix.")
    cleaned = [str(option).strip()[:40] for option in raw_options if str(option).strip()]
    cleaned = cleaned[:MAX_OPTIONS]
    if len(cleaned) < 2:
        raise PollError("invalid_options", "Un sondage doit proposer au moins 2 options.")
    return cleaned


async def _community(db, user_id: int):
    async with db.execute(
        """SELECT c.community_id, c.name, m.role
           FROM social_community_members m
           JOIN social_communities c ON c.community_id=m.community_id
           WHERE m.user_id=? AND c.disbanded=0
           ORDER BY c.community_id LIMIT 1""",
        (user_id,),
    ) as cur:
        return await cur.fetchone()


async def create_poll(user_id: int, question: str, options) -> dict:
    question = " ".join(str(question or "").split())[:120]
    if not question:
        raise PollError("invalid_question", "La question du sondage est obligatoire.")
    choices = _options(options)
    current = now()
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        community = await _community(db, user_id)
        community_id = int(community[0]) if community and community[2] in ("owner", "admin") else 0
        async with db.execute(
            "SELECT COUNT(*) FROM social_polls WHERE user_id=? AND created_at>?",
            (user_id, current - 86400),
        ) as cur:
            count = int((await cur.fetchone())[0])
        if count >= MAX_POLLS_PER_DAY:
            await db.rollback()
            raise PollError("daily_limit", "Maximum 3 sondages par jour de jeu.")
        cur = await db.execute(
            """INSERT INTO social_polls
               (user_id, question, options, created_at, community_id, closes_at)
               VALUES (?,?,?,?,?,?)""",
            (user_id, question, json.dumps(choices, ensure_ascii=False), current,
             community_id, current + POLL_DURATION),
        )
        poll_id = int(cur.lastrowid)
        recipients = []
        community_name = ""
        if community_id:
            community_name = str(community[1])
            async with db.execute(
                "SELECT user_id FROM social_community_members "
                "WHERE community_id=? AND user_id!=? LIMIT 40",
                (community_id, user_id),
            ) as cur:
                recipients = [int(row[0]) for row in await cur.fetchall()]
        await db.commit()

    # Les notifications sont des effets annexes : elles ne doivent pas annuler la création.
    for recipient in recipients:
        await notify(recipient, f"🗳️ Nouveau sondage — {community_name}", question[:100], "social")
    return {
        "poll_id": poll_id,
        "question": question,
        "options": choices,
        "community_id": community_id,
        "community_name": community_name or None,
        "closes_at": current + POLL_DURATION,
    }


async def polls_for_user(user_id: int, staff: bool = False) -> dict:
    current = now()
    async with db_connection() as db:
        community = await _community(db, user_id)
        community_id = int(community[0]) if community else -1
        async with db.execute(
            """SELECT p.poll_id,p.user_id,p.question,p.options,p.created_at,p.active,
                      p.community_id,p.closes_at,
                      (SELECT COUNT(*) FROM social_poll_votes v WHERE v.poll_id=p.poll_id) AS vote_count,
                      (SELECT option_index FROM social_poll_votes v
                       WHERE v.poll_id=p.poll_id AND v.user_id=?) AS my_vote,
                      COALESCE(NULLIF(u.full_name,''),u.username,'') AS author
               FROM social_polls p LEFT JOIN users u ON u.user_id=p.user_id
               WHERE p.active=1 AND (p.closes_at=0 OR p.closes_at>?)
                 AND (p.community_id=0 OR p.community_id=?)
               ORDER BY (p.community_id=?) DESC,p.poll_id DESC LIMIT 30""",
            (user_id, current, community_id, community_id),
        ) as cur:
            rows = await cur.fetchall()
        vote_counts = {}
        if rows:
            poll_ids = [int(row["poll_id"]) for row in rows]
            placeholders = ",".join("?" for _ in poll_ids)
            async with db.execute(
                f"SELECT poll_id,option_index,COUNT(*) FROM social_poll_votes "
                f"WHERE poll_id IN ({placeholders}) GROUP BY poll_id,option_index",
                poll_ids,
            ) as cur:
                for poll_id, option_index, count in await cur.fetchall():
                    vote_counts.setdefault(int(poll_id), {})[int(option_index)] = int(count)
    result = []
    for row in rows:
        try:
            options = json.loads(row["options"] or "[]")
            if not isinstance(options, list):
                options = []
        except (TypeError, ValueError):
            options = []
        counts = [0] * len(options)
        for idx, count in vote_counts.get(int(row["poll_id"]), {}).items():
            if 0 <= idx < len(counts):
                counts[idx] = count
        total = int(row["vote_count"] or 0)
        closes_at = int(row["closes_at"] or 0)
        closed = not bool(row["active"]) or bool(closes_at and closes_at <= current)
        result.append({
            "poll_id": int(row["poll_id"]),
            "user_id": int(row["user_id"]),
            "author": row["author"] or f"Joueur {row['user_id']}",
            "question": row["question"],
            "options": options,
            "counts": counts,
            "vote_count": total,
            "my_vote": int(row["my_vote"]) if row["my_vote"] is not None else None,
            "community_id": int(row["community_id"] or 0),
            "community_name": str(community[1]) if community and int(row["community_id"] or 0) == community_id else None,
            "created_at": int(row["created_at"]),
            "closes_at": closes_at,
            "seconds_left": max(0, closes_at - current) if closes_at else None,
            "closed": closed,
            "mine": int(row["user_id"]) == user_id,
            "can_close": int(row["user_id"]) == user_id or bool(staff),
        })
    return {
        "polls": result,
        "community": ({"community_id": int(community[0]), "name": str(community[1]), "role": str(community[2])}
                      if community else None),
    }


async def vote_poll(poll_id: int, user_id: int, option_index: int) -> dict:
    current = now()
    author_id = 0
    question = ""
    total = 0
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute(
            "SELECT user_id,question,options,active,community_id,closes_at "
            "FROM social_polls WHERE poll_id=?", (poll_id,),
        ) as cur:
            poll = await cur.fetchone()
        if not poll:
            await db.rollback()
            raise PollError("not_found", "Sondage introuvable.")
        try:
            options = json.loads(poll[2] or "[]")
        except (TypeError, ValueError):
            options = []
        if not poll[3] or (int(poll[5] or 0) and int(poll[5]) <= current):
            await db.rollback()
            raise PollError("closed", "Ce sondage est clos.")
        if not (0 <= int(option_index) < len(options)):
            await db.rollback()
            raise PollError("invalid_option", "Cette option n’existe pas.")
        if int(poll[4] or 0):
            async with db.execute(
                "SELECT 1 FROM social_community_members WHERE community_id=? AND user_id=?",
                (int(poll[4]), user_id),
            ) as cur:
                member = await cur.fetchone()
            if not member:
                await db.rollback()
                raise PollError("community_only", "Ce sondage est réservé aux membres de la communauté.")
        async with db.execute(
            "SELECT 1 FROM social_poll_votes WHERE poll_id=? AND user_id=?", (poll_id, user_id),
        ) as cur:
            if await cur.fetchone():
                await db.rollback()
                raise PollError("already_voted", "Tu as déjà voté à ce sondage.")
        try:
            await db.execute(
                "INSERT INTO social_poll_votes (poll_id,user_id,option_index) VALUES (?,?,?)",
                (poll_id, user_id, int(option_index)),
            )
        except aiosqlite.IntegrityError:
            await db.rollback()
            raise PollError("already_voted", "Tu as déjà voté à ce sondage.")
        credit = await db.execute(
            "UPDATE users SET social_coins=COALESCE(social_coins,0)+1 WHERE user_id=?", (user_id,),
        )
        if credit.rowcount == 0:
            await db.rollback()
            raise PollError("player_missing", "Joueur introuvable.")
        async with db.execute("SELECT COUNT(*) FROM social_poll_votes WHERE poll_id=?", (poll_id,)) as cur:
            total = int((await cur.fetchone())[0])
        author_id, question = int(poll[0]), str(poll[1])
        await db.commit()
    if total in POLL_MILESTONES and author_id != user_id:
        await notify(author_id, "🗳️ Ton sondage mobilise",
                     f"« {question[:60]} » a déjà {total} votes.", "social")
    return {"ok": True, "poll_id": poll_id, "option_index": int(option_index),
            "vote_count": total, "social_coins_earned": 1}


async def close_poll(poll_id: int, user_id: int, staff: bool = False) -> dict:
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute(
            "SELECT user_id,active FROM social_polls WHERE poll_id=?", (poll_id,),
        ) as cur:
            poll = await cur.fetchone()
        if not poll:
            await db.rollback()
            raise PollError("not_found", "Sondage introuvable.")
        if int(poll[0]) != user_id and not staff:
            await db.rollback()
            raise PollError("forbidden", "Seul l’auteur ou le staff peut clôturer ce sondage.")
        if not poll[1]:
            await db.rollback()
            raise PollError("closed", "Ce sondage est déjà clos.")
        await db.execute("UPDATE social_polls SET active=0 WHERE poll_id=?", (poll_id,))
        await db.commit()
    return {"ok": True, "poll_id": poll_id, "closed": True}
