"""gameplay/laws.py — Lois, référendums et constitution.

Service pur partagé par `handlers/political.py` (bot) et `webapp/routers/political_router.py`.
Chaque fonction renvoie `{"ok": bool, "reason": ...}`. Débit + création d'une proposition, et
enregistrement d'un vote + incrément du compteur, s'exécutent chacun sous une seule transaction
`BEGIN IMMEDIATE` (avant : coût débité avant l'insertion, vote et compteur dans des écritures
séparées côté handler).
"""
from __future__ import annotations

import aiosqlite

import database
from config import (
    DEFAULT_CONSTITUTION, LAW_DEFAULT_MAJORITY, LAW_PROPOSAL_COST, LAW_VOTE_DURATION,
    POLL_MIN_VOTES, REFERENDUM_COST, REFERENDUM_DURATION,
)
from utils import politics
from utils.roles import is_president, minister_of

CONSTITUTION_MAJORITY = 0.6
CONSTITUTION_MIN_LENGTH = 10
CONSTITUTION_MAX_LENGTH = 1500
CONSTITUTION_COOLDOWN = 7 * 86400


def parse_choice(text: str) -> int | None:
    """« pour » -> 1, « contre » -> -1, sinon None."""
    return {"pour": 1, "contre": -1}.get((text or "").strip().lower())


# ─── Lectures ────────────────────────────────────────────────────────────────────────────────────
async def list_laws() -> dict:
    now = database.now()
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, title, description, votes_for, votes_against, voting_ends_at, required_majority "
            "FROM laws WHERE status='voting' AND voting_ends_at>? ORDER BY created_at DESC", (now,)
        ) as cur:
            voting = [dict(r) for r in await cur.fetchall()]
        async with db.execute(
            "SELECT id, title, description, votes_for, votes_against, enacted_at FROM laws "
            "WHERE status='passed' ORDER BY enacted_at DESC, id DESC LIMIT 20"
        ) as cur:
            passed = [dict(r) for r in await cur.fetchall()]
    return {"voting": voting, "passed": passed}


async def list_referendums() -> list[dict]:
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, question, votes_for, votes_against, voting_ends_at, required_majority FROM referendums "
            "WHERE status='open' AND voting_ends_at>? ORDER BY created_at DESC", (database.now(),)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def my_votes(user_id: int) -> dict:
    """{"laws": {id: ±1}, "referendums": {id: ±1}} pour les scrutins ouverts."""
    async with database.db_connection() as db:
        async with db.execute(
            "SELECT lv.law_id, lv.vote FROM law_votes lv JOIN laws l ON l.id=lv.law_id "
            "WHERE lv.user_id=? AND l.status='voting'", (user_id,)
        ) as cur:
            laws = {r[0]: r[1] for r in await cur.fetchall()}
        async with db.execute(
            "SELECT rv.referendum_id, rv.vote FROM referendum_votes rv JOIN referendums r ON r.id=rv.referendum_id "
            "WHERE rv.user_id=? AND r.status='open'", (user_id,)
        ) as cur:
            refs = {r[0]: r[1] for r in await cur.fetchall()}
    return {"laws": laws, "referendums": refs}


async def get_constitution() -> dict:
    async with database.db_connection() as db:
        async with db.execute("SELECT text, amended_at, amended_by FROM constitution WHERE id=1") as cur:
            row = await cur.fetchone()
    if not row:
        return {"text": DEFAULT_CONSTITUTION, "amended_at": None, "amended_by": None}
    return {"text": row[0], "amended_at": row[1], "amended_by": row[2]}


async def find_law(title_or_id: str) -> int | None:
    """Loi en vote retrouvée par numéro (« 12 », « #12 ») ou par titre exact."""
    now = database.now()
    token = (title_or_id or "").strip()
    async with database.db_connection() as db:
        if token.lstrip("#").isdigit():
            sql, args = "SELECT id FROM laws WHERE id=? AND status='voting' AND voting_ends_at>?", (int(token.lstrip("#")), now)
        else:
            sql, args = "SELECT id FROM laws WHERE title=? AND status='voting' AND voting_ends_at>?", (token, now)
        async with db.execute(sql, args) as cur:
            row = await cur.fetchone()
    return row[0] if row else None


# ─── Écritures ───────────────────────────────────────────────────────────────────────────────────
async def _charge_and_insert(user_id: int, cost: int, insert_sql: str, params: tuple) -> dict:
    """Débite `cost` (versé au Trésor public) et insère la ligne dans la même transaction."""
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            debit = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
                (cost, cost, user_id, cost))
            if debit.rowcount != 1:
                await db.rollback()
                return {"ok": False, "reason": "insufficient_funds", "cost": cost}
            from utils.treasury import collect
            await collect(db, cost, "politique")
            cur = await db.execute(insert_sql, params)
            await database.snapshot_user_core_stats(user_id, db)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return {"ok": True, "id": cur.lastrowid, "cost": cost}


async def propose_law(user_id: int, title: str, description: str,
                      effect_type: str | None = None, effect_value: int | None = None) -> dict:
    title, description = (title or "").strip()[:120], (description or "").strip()[:1000]
    if not title or not description:
        return {"ok": False, "reason": "empty"}
    now = database.now()
    result = await _charge_and_insert(
        user_id, LAW_PROPOSAL_COST,
        "INSERT INTO laws (title, description, proposer_id, effect_type, effect_value, status, created_at, "
        "voting_ends_at, required_majority) VALUES (?,?,?,?,?,?,?,?,?)",
        (title, description, user_id, effect_type, effect_value, "voting", now, now + LAW_VOTE_DURATION,
         LAW_DEFAULT_MAJORITY))
    if result["ok"]:
        result.update(title=title, description=description, majority=LAW_DEFAULT_MAJORITY)
    return result


async def propose_referendum(user_id: int, question: str) -> dict:
    question = (question or "").strip()[:500]
    if not question:
        return {"ok": False, "reason": "empty"}
    now = database.now()
    result = await _charge_and_insert(
        user_id, REFERENDUM_COST,
        "INSERT INTO referendums (question, proposer_id, created_at, voting_ends_at, status) VALUES (?,?,?,?,?)",
        (question, user_id, now, now + REFERENDUM_DURATION, "open"))
    if result["ok"]:
        result["question"] = question
    return result


async def propose_constitution(user_id: int, text: str) -> dict:
    """Modification de la constitution : référendum à 60 % ; texte complet gardé en `payload`."""
    text = (text or "").strip()
    if len(text) < CONSTITUTION_MIN_LENGTH:
        return {"ok": False, "reason": "too_short"}
    if not (await is_president(user_id) or await minister_of(user_id)):
        return {"ok": False, "reason": "not_government"}
    text = text[:CONSTITUTION_MAX_LENGTH]
    now = database.now()
    async with database.db_connection() as db:
        cur = await db.execute(
            "INSERT INTO referendums (question, proposer_id, created_at, voting_ends_at, required_majority, payload) "
            "VALUES (?,?,?,?,?,?)",
            (f"Modifier la constitution : {text[:200]}", user_id, now, now + REFERENDUM_DURATION,
             CONSTITUTION_MAJORITY, "constitution:" + text))
        await db.commit()
    await politics.log_event("referendum", "Référendum constitutionnel ouvert", user_id)
    return {"ok": True, "id": cur.lastrowid}


async def _vote(table: str, votes_table: str, key: str, status_ok: str, row_id: int, user_id: int, choice: int) -> dict:
    if choice not in (1, -1):
        return {"ok": False, "reason": "bad_choice"}
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                f"SELECT 1 FROM {table} WHERE id=? AND status=? AND voting_ends_at>?",
                (row_id, status_ok, database.now()),
            ) as cur:
                if not await cur.fetchone():
                    await db.rollback()
                    return {"ok": False, "reason": "not_found"}
            async with db.execute(
                f"SELECT 1 FROM {votes_table} WHERE {key}=? AND user_id=?", (row_id, user_id)
            ) as cur:
                if await cur.fetchone():
                    await db.rollback()
                    return {"ok": False, "reason": "already_voted"}
            await db.execute(
                f"INSERT INTO {votes_table} ({key}, user_id, vote, voted_at) VALUES (?,?,?,?)",
                (row_id, user_id, choice, database.now()))
            column = "votes_for" if choice == 1 else "votes_against"
            await db.execute(f"UPDATE {table} SET {column}={column}+1 WHERE id=?", (row_id,))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return {"ok": True}


async def vote_law(user_id: int, law_id: int, choice: int) -> dict:
    return await _vote("laws", "law_votes", "law_id", "voting", law_id, user_id, choice)


async def vote_referendum(user_id: int, referendum_id: int, choice: int) -> dict:
    return await _vote("referendums", "referendum_votes", "referendum_id", "open", referendum_id, user_id, choice)


# ─── Clôture automatique ─────────────────────────────────────────────────────────────────────────
async def _enact_referendum_payload(db, proposer_id: int, payload: str) -> None:
    """Référendum accepté : applique son effet (aujourd'hui : remplacement du texte de la constitution)."""
    if payload.startswith("constitution:"):
        text = payload[len("constitution:"):].strip()
        if text:
            await db.execute(
                "INSERT INTO constitution (id, text, amended_by, amended_at) VALUES (1,?,?,?) "
                "ON CONFLICT(id) DO UPDATE SET text=excluded.text, amended_by=excluded.amended_by, "
                "amended_at=excluded.amended_at", (text, proposer_id, database.now()))


async def close_expired() -> list[tuple[int, str]]:
    """Clôture lois et référendums échus (majorité requise + POLL_MIN_VOTES). Renvoie les notifications à envoyer."""
    now_ts = database.now()
    notes: list[tuple[int, str]] = []
    events: list[tuple[str, str, int]] = []
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT id, title, proposer_id, votes_for, votes_against, required_majority FROM laws "
                "WHERE status='voting' AND voting_ends_at<=?", (now_ts,)
            ) as cur:
                expired_laws = await cur.fetchall()
            for law_id, title, proposer, v_for, v_against, majority in expired_laws:
                total = v_for + v_against
                if total >= POLL_MIN_VOTES and (v_for / total) >= majority:
                    await db.execute("UPDATE laws SET status='passed', enacted_at=? WHERE id=?", (now_ts, law_id))
                    notes.append((proposer, f"📜 Ta loi « {title} » est adoptée ({v_for} pour, {v_against} contre) : elle entre en vigueur."))
                    events.append(("loi", f"Loi adoptée : {title} ({v_for} pour, {v_against} contre)", proposer))
                else:
                    await db.execute("UPDATE laws SET status='rejected' WHERE id=?", (law_id,))
                    notes.append((proposer, f"📜 Ta loi « {title} » est rejetée ({v_for} pour, {v_against} contre, {POLL_MIN_VOTES} votes minimum)."))
            async with db.execute(
                "SELECT id, question, proposer_id, votes_for, votes_against, required_majority, payload FROM referendums "
                "WHERE status='open' AND voting_ends_at<=?", (now_ts,)
            ) as cur:
                expired_refs = await cur.fetchall()
            for ref_id, question, proposer, v_for, v_against, majority, payload in expired_refs:
                total = v_for + v_against
                if total >= POLL_MIN_VOTES and (v_for / total) >= majority:
                    await db.execute("UPDATE referendums SET status='accepted' WHERE id=?", (ref_id,))
                    await _enact_referendum_payload(db, proposer, payload or "")
                    notes.append((proposer, f"📢 Référendum accepté ({v_for} pour, {v_against} contre) : {question[:80]}"))
                    events.append(("referendum", f"Référendum accepté : {question[:120]}", proposer))
                else:
                    await db.execute("UPDATE referendums SET status='rejected' WHERE id=?", (ref_id,))
                    notes.append((proposer, f"📢 Référendum rejeté ({v_for} pour, {v_against} contre) : {question[:80]}"))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    for event_type, description, uid in events:
        await politics.log_event(event_type, description, uid)
    return notes
