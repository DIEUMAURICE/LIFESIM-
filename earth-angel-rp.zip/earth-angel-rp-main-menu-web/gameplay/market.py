"""Règles communes de l'inventaire et du marché joueur.

Les adaptateurs Telegram et Web ne font que valider leurs entrées et présenter le résultat.
Toutes les mutations sensibles sont sérialisées dans ce module.
"""
from __future__ import annotations

import aiosqlite

from database import add_life_journal, db_connection, get_user, now, update_balance, update_field
from utils.vip import add_xp


class MarketError(Exception):
    pass


async def _journal(user_id: int, category: str, text: str) -> None:
    try:
        await add_life_journal(user_id, category, text, severity="success")
    except aiosqlite.OperationalError as exc:
        # Certaines fixtures historiques ne créent pas encore life_journal.
        if "no such table: life_journal" not in str(exc):
            raise


async def get_item_quantity(user_id: int, item_id: int) -> int:
    async with db_connection() as db:
        async with db.execute("SELECT quantity FROM inventory WHERE user_id=? AND item_id=?", (user_id, item_id)) as cur:
            row = await cur.fetchone()
    return int(row[0]) if row else 0


async def ensure_item_exists(item_id: int) -> bool:
    async with db_connection() as db:
        async with db.execute("SELECT item_id FROM items WHERE item_id=?", (item_id,)) as cur:
            if await cur.fetchone():
                return True
        async with db.execute("SELECT item_name FROM inventory WHERE item_id=? LIMIT 1", (item_id,)) as cur:
            row = await cur.fetchone()
        name = row[0] if row else f"Item #{item_id}"
        await db.execute(
            "INSERT INTO items(item_id,name,type,rarity,value,emoji,description) VALUES (?,?,'unknown','common',0,'📦',?)",
            (item_id, name, "Item récupéré automatiquement"),
        )
        await db.commit()
    return True


async def add_item(user_id: int, item_id: int, quantity: int, source: str = "market") -> None:
    if quantity <= 0:
        raise MarketError("La quantité doit être positive.")
    await ensure_item_exists(item_id)
    async with db_connection() as db:
        async with db.execute("SELECT name FROM items WHERE item_id=?", (item_id,)) as cur:
            row = await cur.fetchone()
        name = row[0] if row else f"Item #{item_id}"
        await db.execute(
            "INSERT INTO inventory(user_id,item_id,item_type,item_name,quantity,acquired_at) VALUES (?,?,?,?,?,?) "
            "ON CONFLICT(user_id,item_id) DO UPDATE SET quantity=inventory.quantity+excluded.quantity",
            (user_id, item_id, source, name, quantity, now()),
        )
        await db.commit()


async def remove_item(user_id: int, item_id: int, quantity: int = 1) -> bool:
    if quantity <= 0:
        return False
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute(
            "UPDATE inventory SET quantity=quantity-? WHERE user_id=? AND item_id=? AND quantity>=?",
            (quantity, user_id, item_id, quantity),
        )
        if cur.rowcount != 1:
            await db.rollback()
            return False
        await db.execute("DELETE FROM inventory WHERE user_id=? AND item_id=? AND quantity=0", (user_id, item_id))
        await db.commit()
    return True


async def _cargo_price(user_id: int, base_price: int) -> tuple[int, float, int]:
    from handlers.vehicles import get_active_vehicle, get_vehicle_stats
    vehicle = await get_active_vehicle(user_id)
    cargo = 0
    if vehicle:
        stats = await get_vehicle_stats(vehicle["veh_type"])
        cargo = vehicle.get("cargo", 0) or stats.get("cargo", 0)
        if not vehicle.get("cargo") and stats.get("cargo", 0):
            async with db_connection() as db:
                await db.execute("UPDATE vehicles SET cargo=? WHERE veh_id=?", (cargo, vehicle["veh_id"]))
                await db.commit()
    multiplier = min(1.20, 1 + cargo / 500)
    return int(base_price * multiplier), multiplier, cargo


async def cargo_bonus(user_id: int) -> dict:
    _price, multiplier, cargo = await _cargo_price(user_id, 100)
    from handlers.vehicles import get_active_vehicle
    vehicle = await get_active_vehicle(user_id)
    return {
        "has_vehicle": vehicle is not None,
        "vehicle_name": vehicle.get("veh_type", "Véhicule") if vehicle else None,
        "cargo": cargo,
        "bonus_pct": int((multiplier - 1) * 100),
        "multiplier": round(multiplier, 2),
    }


async def create_listing(seller_id: int, item_id: int, price: int, quantity: int) -> dict:
    if item_id <= 0 or price <= 0 or quantity <= 0:
        raise MarketError("❌ Arguments invalides.")
    final_price, cargo_mult, cargo = await _cargo_price(seller_id, price)
    await ensure_item_exists(item_id)
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT name,emoji FROM items WHERE item_id=?", (item_id,)) as cur:
            item = await cur.fetchone()
        if not item:
            await db.rollback()
            raise MarketError("❌ Item introuvable.")
        reserve = await db.execute(
            "UPDATE inventory SET quantity=quantity-? WHERE user_id=? AND item_id=? AND quantity>=?",
            (quantity, seller_id, item_id, quantity),
        )
        if reserve.rowcount != 1:
            await db.rollback()
            raise MarketError("❌ Stock insuffisant.")
        await db.execute("DELETE FROM inventory WHERE user_id=? AND item_id=? AND quantity=0", (seller_id, item_id))
        cur = await db.execute(
            "INSERT INTO market_listings(seller_id,item_id,quantity,price,created_at,expires_at,status) VALUES (?,?,?,?,?,?,'active')",
            (seller_id, item_id, quantity, final_price, now(), now() + 7 * 86400),
        )
        listing_id = cur.lastrowid
        await db.commit()
    return {"listing_id": listing_id, "item_id": item_id, "name": item["name"], "emoji": item["emoji"],
            "quantity": quantity, "unit_price": final_price, "cargo_bonus_pct": int((cargo_mult - 1) * 100), "cargo": cargo}


async def cancel_listing(seller_id: int, listing_id: int) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute(
            "SELECT ml.*,i.name FROM market_listings ml JOIN items i ON i.item_id=ml.item_id "
            "WHERE ml.listing_id=? AND ml.seller_id=? AND ml.status='active'", (listing_id, seller_id)
        ) as cur:
            listing = await cur.fetchone()
        if not listing:
            await db.rollback()
            raise MarketError("❌ Annonce introuvable ou déjà traitée.")
        claimed = await db.execute(
            "UPDATE market_listings SET status='cancelled',quantity=0 WHERE listing_id=? AND status='active'", (listing_id,)
        )
        if claimed.rowcount != 1:
            await db.rollback()
            raise MarketError("❌ Annonce déjà traitée.")
        await db.execute(
            "INSERT INTO inventory(user_id,item_id,item_type,item_name,quantity,acquired_at) VALUES (?,?,?,?,?,?) "
            "ON CONFLICT(user_id,item_id) DO UPDATE SET quantity=inventory.quantity+excluded.quantity",
            (seller_id, listing["item_id"], "market_return", listing["name"], listing["quantity"], now()),
        )
        await db.commit()
    return {"listing_id": listing_id, "quantity_returned": listing["quantity"]}


async def buy_listing(buyer_id: int, listing_id: int, quantity: int = 1) -> dict:
    if listing_id <= 0 or quantity <= 0:
        raise MarketError("❌ Arguments invalides.")
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute(
            "SELECT ml.*,i.name,i.emoji,i.rarity FROM market_listings ml JOIN items i ON i.item_id=ml.item_id "
            "WHERE ml.listing_id=? AND ml.status='active' AND ml.expires_at>?", (listing_id, now())
        ) as cur:
            listing = await cur.fetchone()
        if not listing:
            await db.rollback(); raise MarketError("❌ Annonce indisponible.")
        if listing["seller_id"] == buyer_id:
            await db.rollback(); raise MarketError("❌ Tu ne peux pas acheter ta propre annonce.")
        if listing["quantity"] < quantity:
            await db.rollback(); raise MarketError("❌ Quantité insuffisante dans l'annonce.")
        total = listing["price"] * quantity
        debit = await db.execute(
            "UPDATE users SET balance=balance-?,total_spent=total_spent+? WHERE user_id=? AND balance>=?",
            (total, total, buyer_id, total),
        )
        if debit.rowcount != 1:
            await db.rollback(); raise MarketError("❌ Fonds insuffisants.")
        await db.execute("UPDATE users SET balance=balance+?,total_earned=total_earned+? WHERE user_id=?",
                         (total, total, listing["seller_id"]))
        remaining = listing["quantity"] - quantity
        if remaining == 0:
            claim = await db.execute("UPDATE market_listings SET quantity=0,status='sold' WHERE listing_id=? AND status='active' AND quantity=?",
                                     (listing_id, listing["quantity"]))
        else:
            claim = await db.execute("UPDATE market_listings SET quantity=? WHERE listing_id=? AND status='active' AND quantity=?",
                                     (remaining, listing_id, listing["quantity"]))
        if claim.rowcount != 1:
            await db.rollback(); raise MarketError("❌ Annonce modifiée pendant l'achat.")
        await db.execute(
            "INSERT INTO inventory(user_id,item_id,item_type,item_name,quantity,acquired_at) VALUES (?,?,?,?,?,?) "
            "ON CONFLICT(user_id,item_id) DO UPDATE SET quantity=inventory.quantity+excluded.quantity",
            (buyer_id, listing["item_id"], "market", listing["name"], quantity, now()),
        )
        try:
            await db.execute(
                "UPDATE company_products SET sales=sales+?,revenue=revenue+? WHERE name=? "
                "AND company_id IN (SELECT company_id FROM company_members WHERE user_id=?)",
                (quantity, total, listing["name"], listing["seller_id"]),
            )
        except aiosqlite.OperationalError as exc:
            if "no such table: company_members" not in str(exc):
                await db.rollback(); raise
        await db.commit()
    await _journal(buyer_id, "market", f"Achat de {quantity}x {listing['name']} pour {total}")
    return {"item_id": listing["item_id"], "name": listing["name"], "emoji": listing["emoji"], "rarity": listing["rarity"],
            "quantity": quantity, "total": total, "seller_id": listing["seller_id"]}


async def use_item(user_id: int, item_id: int, quantity: int = 1) -> dict:
    if quantity <= 0:
        raise MarketError("❌ Arguments invalides.")
    await ensure_item_exists(item_id)
    u = await get_user(user_id)
    current = await get_item_quantity(user_id, item_id)
    if current < quantity:
        raise MarketError(f"❌ Tu ne possèdes que {current} exemplaire(s) de cet item.")
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT name,emoji,rarity,type,effect_type,effect_value FROM items WHERE item_id=?", (item_id,)) as cur:
            item = await cur.fetchone()
    if not item:
        raise MarketError("❌ Item introuvable.")
    if item["type"] != "consumable":
        raise MarketError(f"❌ {item['emoji']} {item['name']} n'est pas consommable.")
    value = item["effect_value"] * quantity
    effect = {"type": item["effect_type"]}
    if item["effect_type"] == "heal":
        after = min(100, u["health"] + value); await update_field(user_id, "health", after); effect.update(health_before=u["health"], health_after=after, message=f"❤️ Santé : {u['health']} → {after}")
    elif item["effect_type"] == "energy":
        after = min(100, u["energy"] + value); await update_field(user_id, "energy", after); effect.update(energy_before=u["energy"], energy_after=after, message=f"⚡ Énergie : {u['energy']} → {after}")
    elif item["effect_type"] == "xp":
        await add_xp(user_id, value); effect.update(xp=value, message=f"✨ +{value} XP")
    elif item["effect_type"] == "money":
        await update_balance(user_id, value); effect.update(money=value, message=f"💰 +{value} coins")
    elif item["effect_type"] == "buff":
        happy = min(100, u["happiness"] + value); stress = max(0, u["stress"] - value // 2)
        await update_field(user_id, "happiness", happy); await update_field(user_id, "stress", stress)
        effect.update(happiness_gain=value, stress_loss=value // 2, message=f"✨ Bonheur +{value}, Stress -{value // 2}")
    elif item["effect_type"] == "chain":
        from utils.chain import use_chain_item
        done, messages = 0, []
        for _ in range(quantity):
            ok, message = await use_chain_item(user_id, item["name"])
            if not ok:
                if not done: raise MarketError(message)
                break
            done += 1; messages = [message]
        await _journal(user_id, "item", f"Utilisation de {done}x {item['emoji']} {item['name']}")
        effect["chain_message"] = messages[0] if messages else ""
        effect["message"] = effect["chain_message"]
        return {"item_id": item_id, "name": item["name"], "emoji": item["emoji"], "quantity_used": done,
                "remaining": current, "effect": effect}
    else:
        raise MarketError(f"❌ Effet '{item['effect_type']}' non implémenté pour le moment.")
    if not await remove_item(user_id, item_id, quantity):
        raise MarketError("❌ L'inventaire a changé pendant l'utilisation.")
    await _journal(user_id, "item", f"Utilisation de {quantity}x {item['emoji']} {item['name']}")
    return {"item_id": item_id, "name": item["name"], "emoji": item["emoji"], "quantity_used": quantity,
            "remaining": current - quantity, "effect": effect}
