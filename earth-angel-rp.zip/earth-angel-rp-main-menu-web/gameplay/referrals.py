"""Cycle de parrainage commun à Telegram et Web."""
from __future__ import annotations
import aiosqlite
from database import add_life_journal, db_connection, get_user, now, update_balance
from utils.helpers import fmt
from utils.notify import notify

JOIN_REFERRER, JOIN_REFERRED, JOIN_COINS = 15_000, 7_500, 15
ACT_REFERRER, ACT_REFERRED, ACT_COINS = 40_000, 20_000, 30

class ReferralError(Exception):
    pass

async def start_referral(referred_id: int, referrer_id: int) -> dict:
    if referred_id == referrer_id: raise ReferralError("Un joueur ne peut pas se parrainer lui-même.")
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT referred_by FROM users WHERE user_id=?", (referred_id,)) as cur: current = await cur.fetchone()
        async with db.execute("SELECT user_id,full_name,registered FROM users WHERE user_id=?", (referrer_id,)) as cur: ref = await cur.fetchone()
        if not current or current["referred_by"]: await db.rollback(); raise ReferralError("Parrainage déjà renseigné.")
        if not ref or not ref["registered"]: await db.rollback(); raise ReferralError("Parrain introuvable.")
        await db.execute("UPDATE users SET referred_by=? WHERE user_id=?", (referrer_id, referred_id))
        await db.execute("INSERT OR IGNORE INTO referrals(referrer_id,referred_id,created_at,starter_rewarded,activated_at) VALUES(?,?,?,?,0)", (referrer_id, referred_id, now(), 1))
        await db.execute("UPDATE users SET referral_count=referral_count+1,social_coins=COALESCE(social_coins,0)+?,referral_rewards=referral_rewards+? WHERE user_id=?", (JOIN_COINS, JOIN_REFERRER, referrer_id))
        await db.execute("UPDATE users SET social_coins=COALESCE(social_coins,0)+?,referral_rewards=referral_rewards+? WHERE user_id=?", (JOIN_COINS, JOIN_REFERRED, referred_id))
        await db.commit()
    await update_balance(referrer_id, JOIN_REFERRER)
    await update_balance(referred_id, JOIN_REFERRED)
    await add_life_journal(referred_id, "parrainage", f"🤝 Parrainage : {fmt(JOIN_REFERRED)} + {JOIN_COINS} SocialCoins.", severity="success")
    await add_life_journal(referrer_id, "parrainage", f"👥 Nouveau filleul : {fmt(JOIN_REFERRER)} + {JOIN_COINS} SocialCoins.", severity="success")
    await notify(referrer_id, "🎉 Nouveau filleul !", f"Un joueur vient de rejoindre le jeu. Récompense : {fmt(JOIN_REFERRER)} + {JOIN_COINS} SocialCoins", "success")
    return {"referrer_id": referrer_id, "referrer_name": ref["full_name"] or f"Joueur {referrer_id}", "cash": JOIN_REFERRED, "coins": JOIN_COINS}

async def process_activation(referred_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        async with db.execute("SELECT r.referrer_id,u.level,u.total_earned,u.full_name FROM referrals r JOIN users u ON u.user_id=r.referred_id WHERE r.referred_id=? AND r.activated_at=0", (referred_id,)) as cur: row = await cur.fetchone()
        if not row or row["level"] < 3 or row["total_earned"] < 25_000:
            await db.rollback(); return None
        await db.execute("UPDATE referrals SET activated_at=? WHERE referred_id=? AND activated_at=0", (now(), referred_id))
        await db.execute("UPDATE users SET referral_activated=1,social_coins=COALESCE(social_coins,0)+?,referral_rewards=referral_rewards+? WHERE user_id=?", (ACT_COINS, ACT_REFERRED, referred_id))
        await db.execute("UPDATE users SET social_coins=COALESCE(social_coins,0)+?,referral_rewards=referral_rewards+? WHERE user_id=?", (ACT_COINS, ACT_REFERRER, row["referrer_id"]))
        await db.commit()
    await update_balance(referred_id, ACT_REFERRED)
    await update_balance(row["referrer_id"], ACT_REFERRER)
    await add_life_journal(referred_id, "parrainage", f"🎁 Activation : {fmt(ACT_REFERRED)} + {ACT_COINS} SocialCoins.", severity="success")
    await add_life_journal(row["referrer_id"], "parrainage", f"👥 Filleul activé : {fmt(ACT_REFERRER)} + {ACT_COINS} SocialCoins.", severity="success")
    await notify(row["referrer_id"], "🎉 Filleul activé !", f"{row['full_name']} a atteint le niveau d’activation. Récompense : {fmt(ACT_REFERRER)} + {ACT_COINS} SocialCoins", "success")
    return {"referrer_id": row["referrer_id"], "cash": ACT_REFERRED, "coins": ACT_COINS}

async def summary(user_id: int) -> dict:
    user = await get_user(user_id)
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT COUNT(*) total,COALESCE(SUM(CASE WHEN activated_at>0 THEN 1 ELSE 0 END),0) activated FROM referrals WHERE referrer_id=?", (user_id,)) as cur: stats = await cur.fetchone()
        async with db.execute("SELECT u.full_name,u.level,r.created_at,r.activated_at FROM referrals r JOIN users u ON u.user_id=r.referred_id WHERE r.referrer_id=? ORDER BY r.created_at DESC LIMIT 8", (user_id,)) as cur: rows = [dict(r) for r in await cur.fetchall()]
    return {"link_token": f"ref_{user_id}", "total": stats["total"] or 0, "activated": stats["activated"] or 0, "pending": (stats["total"] or 0) - (stats["activated"] or 0), "rewards": user.get("referral_rewards", 0), "rows": rows, "rewards_config": {"join_referrer": JOIN_REFERRER, "join_referred": JOIN_REFERRED, "activation_referrer": ACT_REFERRER, "activation_referred": ACT_REFERRED, "coins_join": JOIN_COINS, "coins_activation": ACT_COINS}}
