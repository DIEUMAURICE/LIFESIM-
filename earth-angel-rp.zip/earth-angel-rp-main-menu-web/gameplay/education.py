"""gameplay/education.py — Règles métier partagées des études, compétences et examens.

Un seul endroit décide : coût d'inscription, diplôme suivant imposé, décompte énergie/stress,
révision (cours tiré), examen (questions sur les cours révisés), correction et récompenses, et
l'achat de niveaux de compétence. Le bot (`handlers/education.py`) et l'API (`webapp/routers/
education_router.py`) appellent ces fonctions : aucune des deux ne doit recalculer ces règles.
"""
from __future__ import annotations

from config import (
    DIPLOMES, DIPLOME_COSTS, DIPLOME_STUDY_TIME, DIPLOME_PASS_RATE, DIPLOME_SALARY_BONUS,
    SKILLS, SKILL_LEVEL_COST,
    DIPLOMES_EXTENDED, DIPLOME_COSTS_EXTENDED, DIPLOME_STUDY_TIME_EXTENDED,
    DIPLOME_PASS_RATE_EXTENDED, DIPLOME_SALARY_BONUS_EXTENDED, JOBS,
)
from database import db_connection, get_user, get_all_skills, increment_field, now, update_balance, update_field, upgrade_skill
from utils import courses
from utils.vip import add_xp

# Fusion des listes/dictionnaires de base et étendus : même ordre que le bot (handlers/education.py).
ALL_DIPLOMES = list(dict.fromkeys(DIPLOMES_EXTENDED + DIPLOMES))
ALL_COSTS = {**DIPLOME_COSTS, **DIPLOME_COSTS_EXTENDED}
ALL_STUDY_TIME = {**DIPLOME_STUDY_TIME, **DIPLOME_STUDY_TIME_EXTENDED}
ALL_PASS_RATE = {**DIPLOME_PASS_RATE, **DIPLOME_PASS_RATE_EXTENDED}
ALL_SALARY_BONUS = {**DIPLOME_SALARY_BONUS, **DIPLOME_SALARY_BONUS_EXTENDED}
DIPLOME_ORDER = ALL_DIPLOMES

DIPLOME_XP_GAIN = {
    "Brevet": 500, "Bac": 1000, "BTS": 1500, "Licence": 3000,
    "Master": 6000, "MBA": 10000, "Doctorat": 20000, "Habilitation": 50000,
    "École de commerce": 15000, "Grande École": 25000, "Doctorat honoris causa": 75000,
}
ENROLL_ENERGY_COST = 20
ENROLL_STRESS_GAIN = 15
REVISE_ENERGY_COST = 15
REVISE_STRESS_GAIN = 8
REVISE_MIN_ENERGY = 15
PASS_ENERGY_COST = 30
FAIL_ENERGY_COST = 10
FAIL_STRESS_GAIN = 30


class EducationError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def next_diplome(current: str) -> str | None:
    if not current:
        return DIPLOME_ORDER[0]
    if current in DIPLOME_ORDER:
        idx = DIPLOME_ORDER.index(current)
        if idx + 1 < len(DIPLOME_ORDER):
            return DIPLOME_ORDER[idx + 1]
    return None


def diplome_view(dip: str, current: str) -> dict:
    """Vue en lecture seule d'un diplôme (catalogue) : même statut que le menu du bot."""
    next_d = next_diplome(current)
    obtained = bool(current and dip in DIPLOME_ORDER and DIPLOME_ORDER.index(dip) <= DIPLOME_ORDER.index(current))
    return {
        "name": dip, "cost": ALL_COSTS[dip], "duration": ALL_STUDY_TIME[dip],
        "pass_rate": ALL_PASS_RATE[dip], "salary_bonus": ALL_SALARY_BONUS[dip],
        "obtained": obtained, "is_next": dip == next_d and not obtained,
        "locked": not obtained and dip != next_d,
    }


async def enroll(user_id: int, dip_index: int) -> dict:
    """Inscription à une formation : même ordre imposé, coût, décompte vital que le bot."""
    if dip_index < 0 or dip_index >= len(DIPLOME_ORDER):
        raise EducationError("invalid_diploma", "Diplôme invalide.")
    dip = DIPLOME_ORDER[dip_index]
    u = await get_user(user_id)
    current = u.get("diplome", "")
    next_d = next_diplome(current)
    if dip != next_d:
        if current and DIPLOME_ORDER.index(dip) <= DIPLOME_ORDER.index(current):
            raise EducationError("already_obtained", "Tu as déjà ce diplôme ou supérieur.")
        raise EducationError("wrong_order", f"Tu dois d'abord obtenir {next_d}.")
    cost = ALL_COSTS[dip]
    if (u.get("balance") or 0) < cost:
        raise EducationError("insufficient_funds", f"L'inscription coûte {cost:,} €A.")
    study_dip = u.get("study_diplome") or ""
    if study_dip and u.get("study_start", 0) > 0:
        rem = (u["study_start"] + ALL_STUDY_TIME.get(study_dip, 0)) - now()
        if rem > 0:
            raise EducationError("already_enrolled", f"Tu étudies déjà pour {study_dip}.")

    # Débit atomique (même garantie que les autres services : pas de double inscription payée).
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        debit = await db.execute(
            "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
            (cost, cost, user_id, cost),
        )
        if debit.rowcount != 1:
            await db.rollback()
            raise EducationError("insufficient_funds", f"L'inscription coûte {cost:,} €A.")
        await db.execute(
            "UPDATE users SET study_start=?, study_diplome=?, study_effort=1.0, study_revisions=0,"
            " energy=MAX(0, energy-?), stress=MIN(100, stress+?) WHERE user_id=?",
            (now(), dip, ENROLL_ENERGY_COST, ENROLL_STRESS_GAIN, user_id),
        )
        from utils.treasury import collect
        await collect(db, cost, "etudes")
        await db.commit()
    await courses.reset(user_id, dip)
    return {"diploma": dip, "cost": cost, "duration": ALL_STUDY_TIME[dip], "pass_rate": ALL_PASS_RATE[dip]}


async def revise(user_id: int) -> dict:
    """Révision : tire le prochain cours de la formation en cours, débite énergie/stress."""
    u = await get_user(user_id)
    dip = u.get("study_diplome", "")
    if not dip:
        raise EducationError("not_enrolled", "Tu n'es inscrit à aucune formation.")
    rev_count = u.get("study_revisions", 0)
    if rev_count >= courses.MAX_REVISIONS:
        raise EducationError("max_revisions", f"Tu as déjà révisé le maximum ({courses.MAX_REVISIONS} cours).")
    if u.get("energy", 100) < REVISE_MIN_ENERGY:
        raise EducationError("too_tired", "Trop fatigué(e) pour réviser. Repose-toi d'abord.")

    idx = DIPLOME_ORDER.index(dip) if dip in DIPLOME_ORDER else 0
    lesson = await courses.next_lesson(user_id, dip, idx, len(DIPLOME_ORDER))
    new_revisions = rev_count + 1
    new_energy = max(0, u.get("energy", 100) - REVISE_ENERGY_COST)
    new_stress = min(100, u.get("stress", 0) + REVISE_STRESS_GAIN)
    await update_field(user_id, "study_revisions", new_revisions)
    await update_field(user_id, "energy", new_energy)
    await update_field(user_id, "stress", new_stress)
    rem = max(0, ALL_STUDY_TIME.get(dip, 0) - (now() - u.get("study_start", 0)))
    return {"lesson": lesson, "revisions": new_revisions, "max_revisions": courses.MAX_REVISIONS,
            "energy": new_energy, "stress": new_stress, "remaining_seconds": rem, "exam_ready": rem <= 0}


async def my_courses(user_id: int) -> list[dict]:
    lib = await courses.library(user_id)
    out = []
    for lid, dip in lib:
        les = courses.lesson(lid)
        if les:
            out.append({"lesson_id": lid, "diploma": dip, **les})
    return out


async def start_or_continue_exam(user_id: int) -> dict:
    """Renvoie la question courante ; démarre l'examen si besoin (même refus que le bot)."""
    u = await get_user(user_id)
    dip = u.get("study_diplome", "")
    if not dip:
        raise EducationError("not_enrolled", "Tu n'es inscrit à aucune formation.")
    study_time = ALL_STUDY_TIME.get(dip, 0)
    elapsed = now() - u.get("study_start", 0)
    ex = await courses.get_exam(user_id)
    if elapsed < study_time and not ex:
        raise EducationError("too_early", f"Pas encore prêt : {study_time - elapsed} secondes restantes.")
    idx = DIPLOME_ORDER.index(dip) if dip in DIPLOME_ORDER else 0
    if not ex or ex["diplome"] != dip:
        if not await courses.seen_lessons(user_id, dip):
            raise EducationError("no_lessons", "Révise au moins un cours avant de passer l'examen.")
        ex = await courses.start_exam(user_id, dip, idx, len(DIPLOME_ORDER))
    if ex["pos"] >= ex["total"]:
        return await finalize_exam(user_id)
    q = ex["questions"][ex["pos"]]
    return {"finished": False, "diploma": dip, "pos": ex["pos"], "total": ex["total"],
            "needed": courses.needed(ex["total"], idx, len(DIPLOME_ORDER)),
            "question": q["q"], "choices": q["choices"], "score": ex["score"]}


async def answer_exam(user_id: int, choice: int) -> dict:
    ex = await courses.get_exam(user_id)
    if not ex:
        raise EducationError("no_exam", "Aucun examen en cours.")
    res = await courses.answer(user_id, choice)
    if not res.get("ok"):
        raise EducationError("invalid_answer", "Réponse invalide.")
    # NB : on ne corrige pas tout de suite même sur la dernière question — comme le bot, l'écran
    # affiche d'abord le verdict de CETTE réponse ; la correction finale est un appel séparé
    # (déclenché par le bouton "Voir mon résultat" / l'équivalent application), via finalize_exam().
    return {"correct": res["correct"], "right_answer": res["right"], "why": res.get("why", ""),
            "score": res["score"], "total": res["total"], "finished": res["finished"]}


async def _record_exam(user_id: int, diploma: str, score: int, total: int, needed: int, success: bool) -> None:
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO exam_history (user_id, diploma, score, total, needed, success, taken_at) VALUES (?,?,?,?,?,?,?)",
            (user_id, diploma, score, total, needed, 1 if success else 0, now()))
        await db.commit()


async def exam_history(user_id: int, limit: int = 20) -> list[dict]:
    """Derniers examens corrigés (du plus récent au plus ancien), avec mention si réussi."""
    async with db_connection() as db:
        async with db.execute(
            "SELECT diploma, score, total, needed, success, taken_at FROM exam_history "
            "WHERE user_id=? ORDER BY taken_at DESC, id DESC LIMIT ?", (user_id, max(1, min(int(limit), 100)))
        ) as cur:
            rows = await cur.fetchall()
    return [{"diploma": r[0], "score": r[1], "total": r[2], "needed": r[3], "success": bool(r[4]),
             "taken_at": r[5], "mention": courses.mention(r[1], r[2]) if r[4] else None} for r in rows]


async def finalize_exam(user_id: int) -> dict:
    """Corrige l'examen et applique les récompenses/conséquences, dans tous les cas."""
    ex = await courses.get_exam(user_id)
    u = await get_user(user_id)
    dip = u.get("study_diplome", "")
    if not ex or not dip:
        raise EducationError("no_exam", "Aucun examen à corriger.")
    idx = DIPLOME_ORDER.index(dip) if dip in DIPLOME_ORDER else 0
    need = courses.needed(ex["total"], idx, len(DIPLOME_ORDER))
    score, total = ex["score"], ex["total"]
    success = score >= need
    await courses.finish(user_id)
    await _record_exam(user_id, dip, score, total, need, success)
    await update_field(user_id, "study_start", 0)
    await update_field(user_id, "study_diplome", "")
    await update_field(user_id, "study_effort", 1.0)
    await update_field(user_id, "study_revisions", 0)

    if success:
        await update_field(user_id, "diplome", dip)
        xp_gain = DIPLOME_XP_GAIN.get(dip, 500)
        await add_xp(user_id, xp_gain)
        await increment_field(user_id, "prestige", 10)
        await increment_field(user_id, "missions_done")
        await update_field(user_id, "energy", max(0, u.get("energy", 100) - PASS_ENERGY_COST))
        jobs = [j for j, v in JOBS.items() if v.get("need") == dip]
        return {"finished": True, "success": True, "diploma": dip, "score": score, "total": total,
                "mention": courses.mention(score, total), "xp_gain": xp_gain, "prestige_gain": 10,
                "salary_bonus": ALL_SALARY_BONUS[dip], "jobs_unlocked": jobs}

    await update_field(user_id, "stress", min(100, u.get("stress", 0) + FAIL_STRESS_GAIN))
    await update_field(user_id, "energy", max(0, u.get("energy", 100) - FAIL_ENERGY_COST))
    cost_retry = max(1, ALL_COSTS[dip] // 3)
    return {"finished": True, "success": False, "diploma": dip, "score": score, "total": total,
            "needed": need, "stress_gain": FAIL_STRESS_GAIN, "retry_cost": cost_retry}


async def upgrade_skill_level(user_id: int, skill_index: int) -> dict:
    """Achat d'un niveau de compétence : même coût croissant, même plafond 100, même XP."""
    if skill_index < 0 or skill_index >= len(SKILLS):
        raise EducationError("invalid_skill", "Compétence invalide.")
    skill = SKILLS[skill_index]
    u = await get_user(user_id)
    skills = await get_all_skills(user_id)
    current_lvl = skills.get(skill, 0)
    if current_lvl >= 100:
        raise EducationError("max_level", f"Niveau maximum déjà atteint pour {skill}.")
    cost = SKILL_LEVEL_COST * (current_lvl + 1)
    if (u.get("balance") or 0) < cost:
        raise EducationError("insufficient_funds", f"L'amélioration coûte {cost:,} €A.")

    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        debit = await db.execute(
            "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
            (cost, cost, user_id, cost),
        )
        if debit.rowcount != 1:
            await db.rollback()
            raise EducationError("insufficient_funds", f"L'amélioration coûte {cost:,} €A.")
        await db.execute(
            "INSERT INTO skills (user_id, skill_name, level) VALUES (?,?,1) "
            "ON CONFLICT(user_id, skill_name) DO UPDATE SET level=level+1",
            (user_id, skill),
        )
        from utils.treasury import collect
        await collect(db, cost, "etudes")
        await db.commit()
    new_level = current_lvl + 1
    await add_xp(user_id, 200)
    return {"skill": skill, "level": new_level, "cost": cost, "xp_gain": 200,
            "next_cost": SKILL_LEVEL_COST * (new_level + 1)}
