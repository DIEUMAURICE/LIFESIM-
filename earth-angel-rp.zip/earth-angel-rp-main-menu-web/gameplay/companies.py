"""gameplay/companies.py — Règles métier des entreprises partagées entre le bot et l'API.

Couvre le catalogue de produits (liste, prix, suppression, retrait d'inventaire), les
parts/capital (valorisation, achat, vente, dividendes) et les contrats inter-entreprises
(proposer, répondre, négocier), extraits respectivement de `handlers/company_products.py`,
`handlers/company_shares.py` et `handlers/company_deals.py` pour que
`webapp/routers/companies_router.py` appelle exactement les mêmes règles sans rien recalculer.
Les fusions (`cmd_proposer_fusion`/`cmd_repondre_fusion`, toujours dans
`handlers/company_deals.py`) restent pour l'instant uniquement sur le bot — prochaine
extraction, voir TODO.md.

Les fonctions de parts corrigent au passage une faiblesse transactionnelle du code d'origine :
l'achat/vente de parts et le versement de dividendes combinaient plusieurs écritures (solde
joueur, trésorerie, table des parts) dans des blocs de connexion séparés, avec un
`update_balance` qui commit en dehors de la transaction mutant les parts. Ici, chaque opération
écrit en SQL brut sous une seule transaction `BEGIN IMMEDIATE`/commit (même convention que
`gameplay/casino_sessions.py`), pour qu'un redémarrage entre les deux écritures ne puisse plus
créditer/débiter sans l'effet correspondant sur les parts, ni l'inverse.
"""
from __future__ import annotations

import aiosqlite

import database
from utils.company_ops import CONTRACT_TYPES, get_user_shares

MAX_SHARE_PRICE = 10_000_000_000
MAX_SHARE_TOTAL = 9_000_000_000_000_000


async def list_products(user_id: int, company_id: int) -> list[dict]:
    """Catalogue d'une entreprise, avec le stock de l'appelant (prix, ventes, CA, effet, stock)."""
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """
            SELECT cp.name, cp.price, cp.sales, cp.revenue,
                   COALESCE(SUM(i2.quantity), 0) AS stock,
                   i.effect_type, i.effect_value, i.emoji, i.description
            FROM company_products cp
            LEFT JOIN items i ON i.name = cp.name
            LEFT JOIN inventory i2 ON i2.item_id = i.item_id AND i2.user_id = ?
            WHERE cp.company_id=?
            GROUP BY cp.id, cp.name, cp.price, cp.sales, cp.revenue, i.effect_type, i.effect_value, i.emoji, i.description
            ORDER BY cp.revenue DESC, cp.sales DESC, cp.name ASC
            """,
            (user_id, company_id),
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def set_product_price(company_id: int, name: str, new_price: int) -> bool:
    """Modifie le prix conseillé (table `items` + `company_products`). False si le produit n'existe pas."""
    if new_price < 0:
        raise ValueError("Prix invalide.")
    async with database.db_connection() as db:
        async with db.execute("SELECT item_id FROM items WHERE name=?", (name,)) as cur:
            row = await cur.fetchone()
        if not row:
            return False
        await db.execute("UPDATE items SET value=? WHERE item_id=?", (new_price, row[0]))
        await db.execute(
            "UPDATE company_products SET price=? WHERE company_id=? AND name=?",
            (new_price, company_id, name),
        )
        await db.commit()
    return True


async def delete_product(company_id: int, owner_id: int, name: str) -> bool:
    """Supprime définitivement le produit (catalogue, table `items`, inventaire du PDG).
    False si le produit n'existe pas dans le catalogue de cette entreprise."""
    async with database.db_connection() as db:
        async with db.execute(
            "SELECT id FROM company_products WHERE company_id=? AND name=?", (company_id, name)
        ) as cur:
            if not await cur.fetchone():
                return False
        await db.execute("DELETE FROM company_products WHERE company_id=? AND name=?", (company_id, name))
        await db.execute("DELETE FROM items WHERE name=?", (name,))
        await db.execute(
            "DELETE FROM inventory WHERE user_id=? AND item_name=? AND item_type='product'",
            (owner_id, name),
        )
        await db.commit()
    return True


async def withdraw_product(owner_id: int, item_id: int, quantity: int) -> tuple[bool, str, str | None]:
    """Retire `quantity` exemplaires de l'inventaire du PDG (perte, pas une vente).
    → (ok, message, nom du produit retiré ou None en cas d'échec)."""
    from utils.company_ops import _remove_item_from_inventory
    if quantity <= 0:
        return False, "Quantité invalide.", None
    async with database.db_connection() as db:
        async with db.execute(
            "SELECT item_name, quantity FROM inventory WHERE user_id=? AND item_id=?", (owner_id, item_id)
        ) as cur:
            row = await cur.fetchone()
        if not row or row[1] < quantity:
            have = row[1] if row else 0
            return False, f"Quantité insuffisante. Tu en possèdes {have}.", None
        name = row[0]
        if not await _remove_item_from_inventory(owner_id, item_id, quantity, db):
            return False, "Erreur lors du retrait.", None
        await db.commit()
    return True, f"Retiré {quantity} exemplaire(s) de {name} (perte).", name


# ─────────────────────────── Parts / capital ───────────────────────────


def _raw_share_price(treasury: int, reputation: int, rd_level: int = 0) -> int:
    return max(10, (treasury // 1000) * (50 + reputation) // 50 + rd_level * 100)


def share_price(treasury: int, reputation: int, rd_level: int = 0) -> int:
    """Valeur d'une part, plafonnée à `MAX_SHARE_PRICE` (même formule que `cmd_parts`)."""
    return min(_raw_share_price(treasury, reputation, rd_level), MAX_SHARE_PRICE)


async def shareholders(company_id: int) -> list[dict]:
    """Actionnaires d'une entreprise (nom, user_id, parts), triés par détention décroissante."""
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT u.full_name, cs.user_id, cs.shares FROM company_shares cs "
            "JOIN users u ON u.user_id=cs.user_id WHERE cs.company_id=? ORDER BY cs.shares DESC",
            (company_id,),
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def buy_shares(user_id: int, company_id: int, treasury: int, reputation: int, rd_level: int,
                      quantity: int) -> dict:
    """Achète `quantity` parts au prix courant de l'entreprise. Débite l'acheteur et crédite la
    trésorerie dans une seule transaction. Retourne {"ok": False, "reason": ...} en cas de refus
    ("invalid_quantity", "total_too_large", "insufficient_funds" — avec le coût calculé pour
    l'affichage), ou {"ok": True, "price_per_share", "total_cost", "capped", "shares_owned"}."""
    if quantity <= 0:
        return {"ok": False, "reason": "invalid_quantity"}
    raw_price = _raw_share_price(treasury, reputation, rd_level)
    price_per_share = min(raw_price, MAX_SHARE_PRICE)
    capped = raw_price > MAX_SHARE_PRICE
    total_cost = quantity * price_per_share
    if total_cost > MAX_SHARE_TOTAL:
        return {"ok": False, "reason": "total_too_large", "total_cost": total_cost, "capped": capped}
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            debit = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
                (total_cost, total_cost, user_id, total_cost),
            )
            if debit.rowcount != 1:
                await db.rollback()
                return {"ok": False, "reason": "insufficient_funds", "total_cost": total_cost, "capped": capped}
            await db.execute(
                "INSERT INTO company_shares (user_id, company_id, shares) VALUES (?,?,?) "
                "ON CONFLICT(user_id, company_id) DO UPDATE SET shares = shares + ?",
                (user_id, company_id, quantity, quantity),
            )
            await db.execute(
                "UPDATE companies SET treasury = treasury + ? WHERE company_id=?", (total_cost, company_id)
            )
            await database.snapshot_user_core_stats(user_id, db)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    new_shares = await get_user_shares(user_id, company_id)
    return {
        "ok": True, "price_per_share": price_per_share, "total_cost": total_cost,
        "capped": capped, "shares_owned": new_shares,
    }


async def sell_shares(user_id: int, company_id: int, treasury: int, reputation: int, rd_level: int,
                       quantity: int) -> dict:
    """Vend `quantity` parts au prix courant. Décrémente/supprime la ligne de parts et crédite le
    vendeur dans une seule transaction. Retourne {"ok": False, "reason": ...} ("invalid_quantity",
    "no_shares", "not_enough_shares" — avec "current_shares", "total_too_large"), ou
    {"ok": True, "price_per_share", "total_value", "capped", "shares_remaining"}."""
    if quantity <= 0:
        return {"ok": False, "reason": "invalid_quantity"}
    current = await get_user_shares(user_id, company_id)
    if current == 0:
        return {"ok": False, "reason": "no_shares"}
    if quantity > current:
        return {"ok": False, "reason": "not_enough_shares", "current_shares": current}
    raw_price = _raw_share_price(treasury, reputation, rd_level)
    price_per_share = min(raw_price, MAX_SHARE_PRICE)
    capped = raw_price > MAX_SHARE_PRICE
    total_value = quantity * price_per_share
    if total_value > MAX_SHARE_TOTAL:
        return {"ok": False, "reason": "total_too_large", "total_value": total_value, "capped": capped}
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            if quantity == current:
                await db.execute(
                    "DELETE FROM company_shares WHERE user_id=? AND company_id=?", (user_id, company_id)
                )
            else:
                upd = await db.execute(
                    "UPDATE company_shares SET shares = shares - ? WHERE user_id=? AND company_id=? AND shares >= ?",
                    (quantity, user_id, company_id, quantity),
                )
                if upd.rowcount != 1:
                    await db.rollback()
                    return {"ok": False, "reason": "not_enough_shares", "current_shares": current}
            await db.execute(
                "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                (total_value, total_value, user_id),
            )
            await database.snapshot_user_core_stats(user_id, db)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    remaining = current - quantity
    return {
        "ok": True, "price_per_share": price_per_share, "total_value": total_value,
        "capped": capped, "shares_remaining": remaining,
    }


async def distribute_dividends(company_id: int, treasury: int, percent: int) -> dict:
    """Verse `percent`% de la trésorerie aux actionnaires au prorata de leurs parts, puis débite
    la trésorerie — le tout dans une seule transaction (contrairement à l'implémentation
    précédente : boucle de crédits individuels puis débit séparé, sans garantie d'atomicité
    globale). Retourne {"ok": False, "reason": "treasury_too_low" | "no_shares_outstanding"}, ou
    {"ok": True, "percent", "dividend_total", "shareholder_count", "payouts": [(user_id, amount)]}."""
    percent = max(0, min(100, percent))
    dividend_total = int(treasury * percent / 100)
    if dividend_total < 1000:
        return {"ok": False, "reason": "treasury_too_low", "percent": percent}
    holders = [h for h in await shareholders(company_id) if h["shares"] > 0]
    total_shares = sum(h["shares"] for h in holders)
    if total_shares == 0:
        return {"ok": False, "reason": "no_shares_outstanding"}
    payouts = []
    for h in holders:
        amount = int(dividend_total * h["shares"] / total_shares)
        if amount > 0:
            payouts.append((h["user_id"], amount))
    async with database.db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            debit = await db.execute(
                "UPDATE companies SET treasury = treasury - ? WHERE company_id=? AND treasury >= ?",
                (dividend_total, company_id, dividend_total),
            )
            if debit.rowcount != 1:
                await db.rollback()
                return {"ok": False, "reason": "treasury_too_low", "percent": percent}
            for uid, amount in payouts:
                await db.execute(
                    "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                    (amount, amount, uid),
                )
                await database.snapshot_user_core_stats(uid, db)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return {
        "ok": True, "percent": percent, "dividend_total": dividend_total,
        "shareholder_count": len(holders), "payouts": payouts,
    }


# ─────────────────────────── Contrats inter-entreprises ───────────────────────────

_CONTRACT_REPUTATION_BONUS = {"service": 3, "fourniture": 2, "partenariat": 5, "licence": 4}


async def list_contracts(company_id: int) -> list[dict]:
    """Contrats en attente ou en négociation impliquant cette entreprise (envoyés et reçus)."""
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT c.*, fc.name AS from_name, tc.name AS to_name FROM contracts c "
            "JOIN companies fc ON fc.company_id = c.from_company "
            "JOIN companies tc ON tc.company_id = c.to_company "
            "WHERE (c.from_company=? OR c.to_company=?) AND c.status IN ('pending','negotiating') "
            "ORDER BY c.proposed_at DESC",
            (company_id, company_id),
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def propose_contract(from_company_id: int, from_company_name: str, to_company_id: int, amount: int,
                            duration: int, contract_type: str) -> dict:
    """Propose un contrat de `from_company_id` vers `to_company_id`, et notifie le PDG cible.
    Retourne {"ok": False, "reason": ...} ("invalid_args", "same_company", "target_not_found",
    "target_dissolved", "already_pending") ou
    {"ok": True, "contract_id", "target_name", "target_owner_id"}."""
    if amount <= 0 or duration <= 0 or contract_type not in CONTRACT_TYPES:
        return {"ok": False, "reason": "invalid_args"}
    if from_company_id == to_company_id:
        return {"ok": False, "reason": "same_company"}
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT company_id, name, owner_id, dissolved FROM companies WHERE company_id=?", (to_company_id,)
        ) as cur:
            target = await cur.fetchone()
        if not target:
            return {"ok": False, "reason": "target_not_found"}
        if target["dissolved"]:
            return {"ok": False, "reason": "target_dissolved"}
        async with db.execute(
            "SELECT contract_id FROM contracts WHERE "
            "(from_company=? AND to_company=? OR from_company=? AND to_company=?) AND status='pending'",
            (from_company_id, to_company_id, to_company_id, from_company_id),
        ) as cur:
            if await cur.fetchone():
                return {"ok": False, "reason": "already_pending"}
        cur = await db.execute(
            "INSERT INTO contracts (from_company, to_company, amount, duration, contract_type, status, proposed_at) "
            "VALUES (?,?,?,?,?,'pending',?)",
            (from_company_id, to_company_id, amount, duration, contract_type, database.now()),
        )
        contract_id = cur.lastrowid
        await db.commit()
    await database.add_notification(
        target["owner_id"],
        f"📄 Nouveau contrat proposé par **{from_company_name}** : {amount} pour {duration} jours, "
        f"type {contract_type}. Répondez depuis 🎮 Menu → 🏢 Entreprises.",
    )
    return {"ok": True, "contract_id": contract_id, "target_name": target["name"], "target_owner_id": target["owner_id"]}


async def respond_contract(user_id: int, contract_id: int, accept: bool) -> dict:
    """Le PDG de l'entreprise cible accepte ou refuse un contrat en attente, puis notifie le
    PDG émetteur. En cas d'acceptation : transfère le montant, applique le bonus de réputation
    selon le type, et marque le contrat « accepted » avec sa date de fin — dans la même
    transaction que le transfert (l'implémentation d'origine le faisait déjà dans un seul bloc,
    non modifié ici). Au passage, corrige un bug de l'implémentation d'origine qui notifiait
    `contract["from_company"]` (un `company_id`) à la place de l'`owner_id` du PDG émetteur lors
    d'un refus — la notification n'atteignait jamais le bon joueur. Retourne
    {"ok": False, "reason": ...} ("not_found", "not_target_owner", "source_dissolved",
    "insufficient_treasury") ou {"ok": True, "accepted": bool, ...détails}."""
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM contracts WHERE contract_id=?", (contract_id,)) as cur:
            contract = await cur.fetchone()
        if not contract or contract["status"] != "pending":
            return {"ok": False, "reason": "not_found"}
        async with db.execute(
            "SELECT company_id, name, owner_id FROM companies WHERE company_id=?", (contract["to_company"],)
        ) as cur:
            target_company = await cur.fetchone()
        if not target_company or target_company["owner_id"] != user_id:
            return {"ok": False, "reason": "not_target_owner"}
        async with db.execute(
            "SELECT company_id, name, owner_id, dissolved, treasury FROM companies WHERE company_id=?",
            (contract["from_company"],),
        ) as cur:
            from_comp = await cur.fetchone()

        if not accept:
            await db.execute("UPDATE contracts SET status='refused' WHERE contract_id=?", (contract_id,))
            await db.commit()
            if from_comp:
                await database.add_notification(
                    from_comp["owner_id"], f"❌ {target_company['name']} a refusé votre contrat."
                )
            return {
                "ok": True, "accepted": False,
                "from_company": contract["from_company"], "target_name": target_company["name"],
            }

        if not from_comp or from_comp["dissolved"]:
            return {"ok": False, "reason": "source_dissolved"}
        if from_comp["treasury"] < contract["amount"]:
            await db.execute("UPDATE contracts SET status='cancelled' WHERE contract_id=?", (contract_id,))
            await db.commit()
            return {"ok": False, "reason": "insufficient_treasury"}

        await db.execute(
            "UPDATE companies SET treasury=treasury-? WHERE company_id=?", (contract["amount"], from_comp["company_id"])
        )
        await db.execute(
            "UPDATE companies SET treasury=treasury+? WHERE company_id=?",
            (contract["amount"], target_company["company_id"]),
        )
        bonus_reputation = _CONTRACT_REPUTATION_BONUS.get(contract["contract_type"], 0)
        if bonus_reputation:
            await db.execute(
                "UPDATE companies SET reputation=MIN(100, reputation+?) WHERE company_id=?",
                (bonus_reputation, from_comp["company_id"]),
            )
            await db.execute(
                "UPDATE companies SET reputation=MIN(100, reputation+?) WHERE company_id=?",
                (bonus_reputation, target_company["company_id"]),
            )
        end_date = database.now() + contract["duration"] * 86400
        await db.execute(
            "UPDATE contracts SET status='accepted', accepted_at=?, end_date=? WHERE contract_id=?",
            (database.now(), end_date, contract_id),
        )
        await db.commit()
    await database.log_company_action(
        from_comp["company_id"], "contrat_accepte", user_id, f"avec {target_company['name']} ({contract['amount']})"
    )
    await database.log_company_action(
        target_company["company_id"], "contrat_accepte", user_id, f"avec {from_comp['name']} ({contract['amount']})"
    )
    await database.add_notification(from_comp["owner_id"], f"✅ Le contrat avec {target_company['name']} a été accepté.")
    return {
        "ok": True, "accepted": True, "amount": contract["amount"], "duration": contract["duration"],
        "contract_type": contract["contract_type"], "bonus_reputation": bonus_reputation,
        "from_company": from_comp["company_id"], "from_company_name": from_comp["name"],
        "target_company": target_company["company_id"], "target_name": target_company["name"],
    }


async def negotiate_contract(user_id: int, contract_id: int, new_amount: int, new_duration: int) -> dict:
    """Le PDG de l'entreprise cible propose une contre-offre sur un contrat en attente, et
    notifie le PDG émetteur (même correctif d'`owner_id` que `respond_contract`). Retourne
    {"ok": False, "reason": ...} ("invalid_args", "not_found", "not_target_owner") ou
    {"ok": True, "from_company", "target_name"}."""
    if new_amount <= 0 or new_duration <= 0:
        return {"ok": False, "reason": "invalid_args"}
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM contracts WHERE contract_id=?", (contract_id,)) as cur:
            contract = await cur.fetchone()
        if not contract or contract["status"] != "pending":
            return {"ok": False, "reason": "not_found"}
        async with db.execute(
            "SELECT company_id, name, owner_id FROM companies WHERE company_id=?", (contract["to_company"],)
        ) as cur:
            target_company = await cur.fetchone()
        if not target_company or target_company["owner_id"] != user_id:
            return {"ok": False, "reason": "not_target_owner"}
        async with db.execute(
            "SELECT owner_id FROM companies WHERE company_id=?", (contract["from_company"],)
        ) as cur:
            from_owner = await cur.fetchone()
        await db.execute(
            "UPDATE contracts SET amount=?, duration=?, status='negotiating', proposed_at=? WHERE contract_id=?",
            (new_amount, new_duration, database.now(), contract_id),
        )
        await db.commit()
    if from_owner:
        await database.add_notification(
            from_owner["owner_id"],
            f"📝 Négociation pour le contrat #{contract_id} : {target_company['name']} propose "
            f"{new_amount} pour {new_duration} jours. Ouvrez cette action depuis 🎮 Menu → 🏢 Entreprises.",
        )
    return {"ok": True, "from_company": contract["from_company"], "target_name": target_company["name"]}


# ─────────────────────────── Fusions ───────────────────────────


def fusion_valuation(treasury: int, reputation: int) -> int:
    """Valorisation simplifiée de l'entreprise absorbée (même formule que l'implémentation d'origine)."""
    return treasury + (treasury // 10) * reputation // 100


async def list_fusions(company_id: int) -> list[dict]:
    """Demandes de fusion en attente impliquant cette entreprise (envoyées et reçues)."""
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT f.*, fc.name AS from_name, tc.name AS to_name FROM fusion_requests f "
            "JOIN companies fc ON fc.company_id = f.from_company "
            "JOIN companies tc ON tc.company_id = f.to_company "
            "WHERE (f.from_company=? OR f.to_company=?) AND f.status='pending' ORDER BY f.created_at DESC",
            (company_id, company_id),
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def propose_fusion(from_company_id: int, from_company_name: str, to_company_id: int) -> dict:
    """L'entreprise émettrice propose d'absorber `to_company_id` ; notifie le PDG cible.
    Retourne {"ok": False, "reason": "same_company" | "target_not_found" | "target_dissolved" |
    "already_pending"} ou {"ok": True, "request_id", "target_name", "target_owner_id"}."""
    if from_company_id == to_company_id:
        return {"ok": False, "reason": "same_company"}
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT company_id, name, owner_id, dissolved FROM companies WHERE company_id=?", (to_company_id,)
        ) as cur:
            target = await cur.fetchone()
        if not target:
            return {"ok": False, "reason": "target_not_found"}
        if target["dissolved"]:
            return {"ok": False, "reason": "target_dissolved"}
        async with db.execute(
            "SELECT request_id FROM fusion_requests WHERE "
            "(from_company=? AND to_company=? OR from_company=? AND to_company=?) AND status='pending'",
            (from_company_id, to_company_id, to_company_id, from_company_id),
        ) as cur:
            if await cur.fetchone():
                return {"ok": False, "reason": "already_pending"}
        async with db.execute("SELECT treasury FROM companies WHERE company_id=?", (from_company_id,)) as cur:
            row = await cur.fetchone()
        cur = await db.execute(
            "INSERT INTO fusion_requests (from_company, to_company, amount, status, created_at) VALUES (?,?,?,?,?)",
            (from_company_id, to_company_id, row["treasury"] if row else 0, "pending", database.now()),
        )
        request_id = cur.lastrowid
        await db.commit()
    await database.add_notification(
        target["owner_id"],
        f"🏢 **{from_company_name}** souhaite fusionner avec votre entreprise. "
        f"Répondez depuis 🎮 Menu → 🏢 Entreprises.",
    )
    return {"ok": True, "request_id": request_id, "target_name": target["name"], "target_owner_id": target["owner_id"]}


async def respond_fusion(user_id: int, company_id: int, accept: bool) -> dict:
    """Le PDG de `company_id` (cible) répond à la demande de fusion en attente. À l'acceptation,
    l'émettrice absorbe la cible : paiement de la valorisation, transfert des employés, fusion
    des parts, dissolution — sous une seule transaction. Corrige au passage deux bugs de
    l'implémentation d'origine : (1) `UPDATE company_shares SET company_id=...` violait la clé
    primaire (user_id, company_id) dès qu'un actionnaire détenait des parts des deux entreprises
    (les parts sont maintenant additionnées) ; (2) la notification de refus visait un
    `company_id` au lieu de l'`owner_id` émetteur. Retourne {"ok": False, "reason":
    "not_owner" | "no_request" | "source_dissolved" | "insufficient_treasury"} ou
    {"ok": True, "accepted": bool, ...}."""
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT company_id, name, owner_id, treasury, reputation, dissolved FROM companies WHERE company_id=?",
                (company_id,),
            ) as cur:
                to_comp = await cur.fetchone()
            if not to_comp or to_comp["dissolved"] or to_comp["owner_id"] != user_id:
                await db.rollback()
                return {"ok": False, "reason": "not_owner"}
            async with db.execute(
                "SELECT * FROM fusion_requests WHERE to_company=? AND status='pending'", (company_id,)
            ) as cur:
                req = await cur.fetchone()
            if not req:
                await db.rollback()
                return {"ok": False, "reason": "no_request"}
            async with db.execute(
                "SELECT company_id, name, owner_id, treasury, dissolved FROM companies WHERE company_id=?",
                (req["from_company"],),
            ) as cur:
                from_comp = await cur.fetchone()

            if not accept:
                await db.execute(
                    "UPDATE fusion_requests SET status='refused', responded_at=? WHERE request_id=?",
                    (database.now(), req["request_id"]),
                )
                await db.commit()
                if from_comp:
                    await database.add_notification(
                        from_comp["owner_id"], f"❌ {to_comp['name']} a refusé votre demande de fusion."
                    )
                return {"ok": True, "accepted": False, "target_name": to_comp["name"]}

            if not from_comp or from_comp["dissolved"]:
                await db.rollback()
                return {"ok": False, "reason": "source_dissolved"}
            valuation = fusion_valuation(to_comp["treasury"], to_comp["reputation"])
            if from_comp["treasury"] < valuation:
                await db.execute(
                    "UPDATE fusion_requests SET status='refused' WHERE request_id=?", (req["request_id"],)
                )
                await db.commit()
                return {"ok": False, "reason": "insufficient_treasury"}

            fid, tid = from_comp["company_id"], to_comp["company_id"]
            await db.execute("UPDATE companies SET treasury=treasury-? WHERE company_id=?", (valuation, fid))
            await db.execute("UPDATE companies SET treasury=treasury+? WHERE company_id=?", (valuation, tid))
            await db.execute("UPDATE company_members SET company_id=? WHERE company_id=?", (fid, tid))
            await db.execute(
                "INSERT INTO company_shares (user_id, company_id, shares) "
                "SELECT user_id, ?, shares FROM company_shares WHERE company_id=? "
                "ON CONFLICT(user_id, company_id) DO UPDATE SET shares = shares + excluded.shares",
                (fid, tid),
            )
            await db.execute("DELETE FROM company_shares WHERE company_id=?", (tid,))
            await db.execute("UPDATE companies SET dissolved=1 WHERE company_id=?", (tid,))
            await db.execute(
                "UPDATE fusion_requests SET status='accepted', responded_at=? WHERE request_id=?",
                (database.now(), req["request_id"]),
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await database.log_company_action(fid, "fusion_accept", user_id, f"avec {to_comp['name']}")
    await database.add_notification(from_comp["owner_id"], f"✅ La fusion avec {to_comp['name']} a été acceptée.")
    return {
        "ok": True, "accepted": True, "valuation": valuation,
        "from_company_name": from_comp["name"], "target_name": to_comp["name"],
    }


# ─────────────────────────── Transfert de PDG ───────────────────────────


async def transfer_ownership(user_id: int, company_id: int, target_id: int) -> dict:
    """Le PDG transfère l'entreprise à un employé : `owner_id` et les deux postes (« Ex-PDG » /
    « PDG ») changent sous une seule transaction. Retourne {"ok": False, "reason": "not_owner" |
    "same_user" | "target_not_member"} ou {"ok": True, "company_name"}."""
    if target_id == user_id:
        return {"ok": False, "reason": "same_user"}
    async with database.db_connection() as db:
        db.row_factory = aiosqlite.Row
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT name, owner_id, dissolved FROM companies WHERE company_id=?", (company_id,)
            ) as cur:
                company = await cur.fetchone()
            if not company or company["dissolved"] or company["owner_id"] != user_id:
                await db.rollback()
                return {"ok": False, "reason": "not_owner"}
            async with db.execute(
                "SELECT 1 FROM company_members WHERE company_id=? AND user_id=?", (company_id, target_id)
            ) as cur:
                if not await cur.fetchone():
                    await db.rollback()
                    return {"ok": False, "reason": "target_not_member"}
            await db.execute("UPDATE companies SET owner_id=? WHERE company_id=?", (target_id, company_id))
            await db.execute(
                "UPDATE company_members SET poste='Ex-PDG' WHERE user_id=? AND company_id=?", (user_id, company_id)
            )
            await db.execute(
                "UPDATE company_members SET poste='PDG' WHERE user_id=? AND company_id=?", (target_id, company_id)
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await database.log_company_action(company_id, "transfert_pdg", user_id, f"vers {target_id}")
    return {"ok": True, "company_name": company["name"]}
