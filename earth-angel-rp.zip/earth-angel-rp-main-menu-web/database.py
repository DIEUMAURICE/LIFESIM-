# database.py — GAME FRENCH — Version complète avec hiérarchie admin
from utils.swallow import swallowed
import aiosqlite
import asyncio
import time
import logging
import sqlite3
from contextlib import asynccontextmanager
from pathlib import Path
from config import (
    DB_PATH, STARTING_BALANCE, PLANTS, ASSETS, DB_VERSION, SOCIAL_COIN_STARTING_BALANCE,
    SQLITE_POOL_SIZE,
    STAT_SNAPSHOT_MIN_INTERVAL, STAT_HISTORY_RETENTION_DAYS, JOURNAL_RETENTION_DAYS,
    REQUIRE_EXISTING_DB, CONFIGURED_DB_PATH,
)

from utils.gametime import game_now, real_now

logger = logging.getLogger(__name__)

DB_TIMEOUT = 60.0
POOL_PING_IDLE = 30.0   # secondes d'inactivité avant de re-tester une connexion du pool
DB_POOL_SIZE = SQLITE_POOL_SIZE
_ALL_POOLS = []


def now():
    """Temps de JEU (24 h de jeu = 10 h réelles), commun à tous les joueurs. Voir utils/gametime.py."""
    return game_now()


async def _configure_connection(db: aiosqlite.Connection):
    # Certains PRAGMA (journal_mode, busy_timeout, wal_autocheckpoint) renvoient une ligne : on la
    # consomme et on ferme le curseur. Sinon, sous Python ≥ 3.11, le prochain commit() peut échouer
    # avec « cannot commit transaction - SQL statements in progress ».
    for pragma in (
        "PRAGMA journal_mode=WAL",
        f"PRAGMA busy_timeout={int(DB_TIMEOUT * 1000)}",
        "PRAGMA cache_size=10000",
        "PRAGMA synchronous=NORMAL",
        "PRAGMA temp_store=MEMORY",
        "PRAGMA wal_autocheckpoint=1000",
    ):
        async with db.execute(pragma) as cur:
            await cur.fetchall()


# ═══════════════════════════════════════════════════════════════════════════
#                          POOL DE CONNEXIONS SQLITE
# ═══════════════════════════════════════════════════════════════════════════

class SQLiteConnectionPool:
    """
    Pool de connexions SQLite avec recyclage des connexions mortes.

    Un 'disk I/O error' empoisonne une connexion définitivement : le pool
    la détecte et la remplace au lieu de la réutiliser (ce qui provoquerait
    des erreurs en cascade du type 'no such table: users').
    """

    def __init__(self, db_path: str, size: int = DB_POOL_SIZE):
        self.db_path = db_path
        self.size = size
        self._queue: asyncio.LifoQueue[aiosqlite.Connection] = asyncio.LifoQueue()
        self._created = 0
        self._lock = asyncio.Lock()
        self._connections = set()
        _ALL_POOLS.append(self)

    async def _create_connection(self) -> aiosqlite.Connection:
        db = await aiosqlite.connect(self.db_path, timeout=DB_TIMEOUT)
        await _configure_connection(db)
        return db

    async def _create_or_wait(self) -> aiosqlite.Connection:
        async with self._lock:
            if self._created < self.size:
                db = await self._create_connection()
                self._created += 1
                self._connections.add(db)
                return db
        return await self._queue.get()

    async def acquire(self) -> aiosqlite.Connection:
        try:
            db = self._queue.get_nowait()
        except asyncio.QueueEmpty:
            return await self._create_or_wait()

        # 🔍 Ping léger SEULEMENT si la connexion est restée inactive (sinon c'est un aller-retour
        # inutile à chaque requête). Les erreurs graves en cours d'usage sont déjà gérées
        # par db_connection (mise au rebut).
        if time.monotonic() - getattr(db, "_last_used", 0.0) > POOL_PING_IDLE:
            try:
                async with db.execute("SELECT 1"):
                    pass
            except Exception:
                logger.warning("♻️ Connexion morte détectée dans le pool, recyclage.")
                await self.discard(db)
                return await self._create_or_wait()
        return db

    async def release(self, db: aiosqlite.Connection):
        try:
            if getattr(db, "in_transaction", True):   # rien à annuler → pas d'aller-retour inutile
                await db.rollback()
        except Exception:
            # Le rollback a échoué → la connexion est définitivement cassée
            logger.warning("♻️ Rollback impossible, mise au rebut de la connexion.")
            await self.discard(db)
            return
        db.row_factory = None
        db._last_used = time.monotonic()
        self._queue.put_nowait(db)

    async def discard(self, db: aiosqlite.Connection):
        """Jette une connexion cassée (disk I/O error, malformed, etc.)."""
        try:
            await db.close()
        except Exception:
            swallowed('database.py')
        async with self._lock:
            self._created = max(0, self._created - 1)
        self._connections.discard(db)

    async def close(self):
        """Ferme toutes les connexions rendues au pool lors d’un arrêt propre."""
        connections = list(self._connections)
        for db in connections:
            try:
                await db.close()
            except Exception:
                logger.debug("Fermeture d’une connexion SQLite déjà arrêtée", exc_info=True)
        self._connections.clear()
        self._created = 0


_DB_POOL = SQLiteConnectionPool(DB_PATH)


# ═══════════════════════════════════════════════════════════════════════════
#              🔒 SÉRIALISATION GLOBALE DES ACCÈS SQLITE
# ═══════════════════════════════════════════════════════════════════════════
# Toutes les opérations passent une par une. Un task qui est déjà "dans la DB"
# ne redemande pas le lock : il réutilise SA connexion. Cela élimine à la fois :
#   • les conflits inter-tasks ("database is locked")
#   • les transactions imbriquées qui se bloquent mutuellement
#
# Règle importante : ne JAMAIS faire un `await` Telegram (send_message, etc.)
# À L'INTÉRIEUR d'un bloc `async with db_connection()`, sinon tous les autres
# accès à la DB attendent la fin de l'appel réseau.
# ═══════════════════════════════════════════════════════════════════════════

_db_global_lock = asyncio.Lock()
_task_db: dict[asyncio.Task, aiosqlite.Connection] = {}


def _lock_for_current_loop() -> asyncio.Lock:
    """Retourne le lock de la boucle courante, notamment pour pytest asyncio."""
    global _db_global_lock
    loop = asyncio.get_running_loop()
    bound_loop = getattr(_db_global_lock, "_loop", None)
    if bound_loop is not None and bound_loop is not loop:
        # Un lock asyncio ne doit pas être réutilisé par une autre boucle.
        # En production il n’y a qu’une boucle ; les tests recréent volontairement
        # plusieurs boucles et remplacent déjà les pools de connexions.
        _db_global_lock = asyncio.Lock()
    return _db_global_lock


@asynccontextmanager
async def db_connection(row_factory=None):
    """
    Fournit une connexion SQLite SERIALISÉE.

    • Un seul task peut utiliser la DB à la fois.
    • Les appels imbriqués (helper dans un handler, etc.) réutilisent
      la MÊME connexion — pas de verrou concurrent, pas de blocage.
    • Le lock global est relâché à la sortie du context manager le plus externe.
    """
    current = asyncio.current_task()
    if current is None:
        raise RuntimeError("db_connection nécessite un contexte asyncio")

    # ─── Cas 1 : appel imbriqué dans le même task → réutilisation ───
    existing = _task_db.get(current)
    if existing is not None:
        prev_factory = existing.row_factory
        if row_factory is not None:
            existing.row_factory = row_factory
        try:
            yield existing
        finally:
            existing.row_factory = prev_factory
        return

    # ─── Cas 2 : appel racine → acquérir le lock global ───
    async with _lock_for_current_loop():
        db = await _DB_POOL.acquire()
        # Par défaut aiosqlite.Row : indexable comme un tuple ET convertible via dict(row)
        db.row_factory = row_factory or aiosqlite.Row
        _task_db[current] = db
        broken = False
        try:
            yield db
        except Exception as e:
            err = str(e).lower()
            # Erreurs qui signent une connexion morte → on la jette
            if ("disk i/o error" in err
                    or "malformed" in err
                    or "database disk image is malformed" in err):
                logger.warning("♻️ Erreur SQLite grave (%s), mise au rebut.", e)
                broken = True
            raise
        finally:
            # `finally` (et non `else`) : la connexion DOIT revenir au pool même si
            # la tâche est annulée (timeout d'un job, arrêt du bot, DeferredReply).
            # Sans ça, chaque annulation fuyait une connexion et, après
            # SQLITE_POOL_SIZE fuites, plus aucune requête ne passait.
            _task_db.pop(current, None)
            if broken:
                await asyncio.shield(_DB_POOL.discard(db))
            else:
                await asyncio.shield(_DB_POOL.release(db))


# ═══════════════════════════════════════════════════════════════════════════
#              📖 LECTURES HORS VERROU GLOBAL (WAL = lecteurs en parallèle)
# ═══════════════════════════════════════════════════════════════════════════
# En mode WAL, des lecteurs ne bloquent pas l'écrivain (et inversement). `db_read()` ouvre une
# connexion en LECTURE SEULE (PRAGMA query_only) qui n'attend PAS `_db_global_lock` : les
# classements, profils, listes… ne font plus la queue derrière les écritures.
#
# Règles :
#   • uniquement pour des fonctions purement lecture (query_only refuse toute écriture) ;
#   • appelée depuis un task qui tient déjà une connexion db_connection(), elle réutilise CETTE
#     connexion (on voit donc ses propres écritures non commitées, comme avant) ;
#   • sinon on voit l'état committé au moment de la requête (c'est ce que voyait déjà un
#     appel autonome à db_connection()).

READ_POOL_SIZE = 4


class _ReadPool(SQLiteConnectionPool):
    async def _create_connection(self) -> aiosqlite.Connection:
        db = await aiosqlite.connect(self.db_path, timeout=DB_TIMEOUT)
        await _configure_connection(db)
        await db.execute("PRAGMA query_only=ON")
        return db


_READ_POOL: "_ReadPool | None" = None
_read_sem: "asyncio.Semaphore | None" = None
_read_loop = None


def _read_pool():
    """Pool de lecture, recréé si la base visée (tests) ou la boucle asyncio a changé."""
    global _READ_POOL, _read_sem, _read_loop
    loop = asyncio.get_running_loop()
    if _READ_POOL is None or _READ_POOL.db_path != _DB_POOL.db_path or _read_loop is not loop:
        _READ_POOL = _ReadPool(_DB_POOL.db_path, READ_POOL_SIZE)
        _read_sem = asyncio.Semaphore(READ_POOL_SIZE)   # jamais plus de lecteurs que de connexions
        _read_loop = loop
    return _READ_POOL, _read_sem


@asynccontextmanager
async def db_read(row_factory=None):
    current = asyncio.current_task()
    existing = _task_db.get(current) if current is not None else None
    if existing is not None:                      # déjà « dans la DB » : même connexion
        prev_factory = existing.row_factory
        if row_factory is not None:
            existing.row_factory = row_factory
        try:
            yield existing
        finally:
            existing.row_factory = prev_factory
        return

    pool, sem = _read_pool()
    async with sem:
        db = await pool.acquire()
        db.row_factory = row_factory or aiosqlite.Row
        broken = False
        try:
            yield db
        except Exception as e:
            err = str(e).lower()
            if "disk i/o error" in err or "malformed" in err:
                logger.warning("♻️ Erreur SQLite grave en lecture (%s), mise au rebut.", e)
                broken = True
            raise
        finally:
            if broken:
                await asyncio.shield(pool.discard(db))
            else:
                await asyncio.shield(pool.release(db))


class DeferredReply(BaseException):
    """Réponse Telegram à envoyer APRÈS la fermeture de la connexion.

    Usage dans un handler (au lieu de `await msg.reply_text(...); return`
    à l'intérieur d'un bloc DB) :

        try:
            async with db_connection() as db:
                ...
                if manque_argent:
                    raise DeferredReply(update.message.reply_text, "❌ Fonds insuffisants.")
        except DeferredReply as d:
            return await d.send()

    La connexion (et le verrou global) est libérée AVANT l'appel réseau, donc
    un Telegram lent ne bloque plus les autres joueurs. Hérite de BaseException
    pour ne pas être avalée par un `except Exception` placé dans le bloc.
    """

    def __init__(self, func, *args, _ret=None, **kwargs):
        super().__init__()
        self.func = func
        self.args_ = args
        self.kwargs_ = kwargs
        self.ret = _ret

    async def send(self):
        await self.func(*self.args_, **self.kwargs_)
        return self.ret


class Outbox:
    """File d'envois Telegram, vidée À LA SORTIE du bloc (donc après la fermeture de la DB).

        async with Outbox() as out:
            async with db_connection() as db:
                ...
                out.add(update.message.reply_text, "✅ Fait !")
                return            # la réponse part quand même, connexion déjà libérée

    • sortie normale ou `return` → les messages en file sont envoyés dans l'ordre ;
    • exception ou annulation → rien n'est envoyé (la transaction a échoué).
    """

    def __init__(self):
        self._calls = []

    def add(self, func, *args, **kwargs):
        self._calls.append((func, args, kwargs))

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        if exc_type is not None:
            self._calls.clear()
            return False
        calls, self._calls = self._calls, []
        for func, args, kwargs in calls:
            try:
                await func(*args, **kwargs)
            except Exception:
                logger.exception("Outbox : envoi Telegram échoué")
        return False


# ═══════════════════════════════════════════════════════════════════════════
#                          ARGENT ATOMIQUE
# ═══════════════════════════════════════════════════════════════════════════



async def debit_balance(user_id: int, amount: int) -> bool:
    if amount <= 0:
        raise ValueError("Le montant à débiter doit être positif")
    async with db_connection() as db:
        cur = await db.execute(
            "UPDATE users SET balance = balance - ? "
            "WHERE user_id = ? AND balance >= ?",
            (amount, user_id, amount),
        )
        await db.commit()
        return cur.rowcount > 0


async def credit_balance(user_id: int, amount: int) -> None:
    if amount <= 0:
        raise ValueError("Le montant à créditer doit être positif")
    async with db_connection() as db:
        await db.execute(
            "UPDATE users SET balance = balance + ? WHERE user_id = ?",
            (amount, user_id),
        )
        await db.commit()


async def transfer_money(from_id: int, to_id: int, amount: int, tax: int = 0) -> bool:
    if amount <= 0:
        raise ValueError("Le montant à transférer doit être positif")
    if tax < 0 or tax >= amount:
        raise ValueError("Taxe invalide")
    async with db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            cur = await db.execute(
                "UPDATE users SET balance = balance - ? "
                "WHERE user_id = ? AND balance >= ?",
                (amount, from_id, amount),
            )
            if cur.rowcount == 0:
                await db.rollback()
                return False
            credit = await db.execute(
                "UPDATE users SET balance = balance + ? WHERE user_id = ?",
                (amount - tax, to_id),
            )
            if credit.rowcount == 0:
                await db.rollback()
                return False
            await db.commit()
            return True
        except Exception:
            await db.rollback()
            raise


# ═══════════════════════════════════════════════════════════════════════════
#                          MIGRATIONS
# ═══════════════════════════════════════════════════════════════════════════

MIGRATIONS = [
    # (1, ["ALTER TABLE users ADD COLUMN vip_until INTEGER DEFAULT 0"]),
]


async def run_migrations():
    async with aiosqlite.connect(DB_PATH, timeout=DB_TIMEOUT) as db:
        await _configure_connection(db)
        async with db.execute("PRAGMA user_version") as cur:
            row = await cur.fetchone()
        current = row[0] if row else 0
        target = max((v for v, _ in MIGRATIONS), default=0)
        if current >= target:
            logger.info("✅ DB à jour (version %s).", current)
            return
        for version, statements in sorted(MIGRATIONS, key=lambda m: m[0]):
            if version <= current:
                continue
            logger.info("🔄 Migration vers la version %s...", version)
            try:
                await db.execute("BEGIN")
                for sql in statements:
                    await db.execute(sql)
                await db.execute(f"PRAGMA user_version = {version}")
                await db.commit()
                logger.info("✅ Migration %s appliquée.", version)
            except Exception:
                await db.rollback()
                logger.exception("❌ Échec de la migration %s, annulée.", version)
                raise


# ═══════════════════════════════════════════════════════════════════════════
#                          CHAMPS AUTORISÉS (users)
# ═══════════════════════════════════════════════════════════════════════════

ALLOWED_FIELDS = {
    "username", "balance", "xp", "level", "karma", "prestige", "health",
    "energy", "happiness", "hunger", "stress", "age", "diplome", "job",
    "job_xp", "job_level", "location", "bio", "profile_pic", "profile_color",
    "prison_until", "hospital_until", "travel_until", "warnings", "banned",
    "god_mode", "defense_level", "last_life_tick", "lifestyle_score",
    "study_revisions", "study_effort", "study_diplome", "study_start",
    "plant_cooldown", "harvest_cooldown", "water_cooldown", "last_event_day",
    "study_cooldown", "revision_cooldown", "formation_cooldown",
    "last_seen", "work_last", "daily_last", "charity_given", "sleep_last",
    "casino_total_bet", "casino_total_win", "last_crime", "social_followers",
    "lottery_wins",
    "registered", "arena_wins", "arena_losses", "user_id", "crimes_done", "crimes_success",
    "created_at", "political_post", "hack_attempts",
    "medecin_last", "gym_last", "medicaments_last", "hospital_last", "doctor_last", "hopital_last",
    "assurance_subscribe", "insure_vehicle",
    "total_earned", "total_spent",
    "missions_done",
    "travel_count",
    "plants_grown",
    "last_hold",
    "luxury_buy",
    "buy_property", "mortgage", "rent_property", "sell_property", "maintain_property",
    "propose_rental",
    "buy_vehicle", "repair_vehicle", "sell_vehicle",
    "post_cooldown", "collab_cooldown",
    "vote_cooldown",
    "buy_cooldown", "sell_cooldown",
    "report_cooldown",
    "parier_cooldown",
    "story_cooldown", "live_cooldown", "social_rating_cooldown",
    "create_community_cooldown", "share_cooldown", "trend_cooldown",
    "poll_cooldown", "use_cooldown", "don_cooldown", "casino_last",
    "social_rating", "social_coins",
    "referred_by", "referral_count", "referral_rewards", "referral_activated",
    "last_election", "last_motion", "last_constitution", "last_hack",
    "phone_theme", "phone_ringtone",
    "active_vehicle_id",
    "frozen_until",
    # ─── Abonnements VIP / Premium & boutique Étoiles ───
    "vip_until", "premium_until",
    "boost_xp2_until", "boost_coins2_until", "boost_chance_until",
    "boost_jardin_until", "boost_vitesse_until",
    "extra_inventory_slots", "extra_garden_plots", "extra_properties",
    "extra_vehicles", "extra_work_cd_reduction", "extra_casino_spins",
    "profile_title", "profile_badge", "signature_emoji",
    "crime_shield_charges",
}


# ═══════════════════════════════════════════════════════════════════════════
#                          INITIALISATION DE LA BASE
# ═══════════════════════════════════════════════════════════════════════════

async def init_db():
    # Les tests et les outils de migration peuvent remplacer DB_PATH par une base
    # temporaire. Le refus de bootstrap ne concerne que le chemin production réellement configuré.
    is_configured_database = Path(DB_PATH).resolve() == Path(CONFIGURED_DB_PATH).resolve()
    if REQUIRE_EXISTING_DB and is_configured_database:
        path = Path(DB_PATH)
        if not path.is_file() or path.stat().st_size < 4096:
            raise RuntimeError(
                f"Base de production absente ou vide : {path}. "
                "Refus de créer une nouvelle base ; vérifie le volume persistant ou restaure une sauvegarde."
            )
        try:
            with sqlite3.connect(str(path), timeout=DB_TIMEOUT) as check_db:
                integrity = check_db.execute("PRAGMA integrity_check").fetchone()
                has_users = check_db.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name='users'"
                ).fetchone()
        except sqlite3.Error as exc:
            raise RuntimeError(f"Base de production illisible : {path}") from exc
        if not integrity or integrity[0] != "ok" or not has_users:
            raise RuntimeError(
                f"Base de production invalide ou incomplète : {path}. "
                "Refus de démarrer pour éviter une initialisation destructive."
            )
    async with aiosqlite.connect(DB_PATH, timeout=DB_TIMEOUT) as db:
        await _configure_connection(db)

        # ─────────────── Table users ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id     INTEGER PRIMARY KEY,
            username    TEXT DEFAULT '',
            full_name   TEXT DEFAULT '',
            balance     INTEGER DEFAULT 0 CHECK (balance >= 0),
            xp          INTEGER DEFAULT 0,
            level       INTEGER DEFAULT 1,
            karma       INTEGER DEFAULT 0,
            prestige    INTEGER DEFAULT 0,
            health      INTEGER DEFAULT 100,
            energy      INTEGER DEFAULT 100,
            happiness   INTEGER DEFAULT 100,
            hunger      INTEGER DEFAULT 100,
            stress      INTEGER DEFAULT 0,
            age         INTEGER DEFAULT 18,
            diplome     TEXT DEFAULT '',
            job         TEXT DEFAULT '',
            job_xp      INTEGER DEFAULT 0,
            job_level   INTEGER DEFAULT 1,
            daily_last  INTEGER DEFAULT 0,
            work_last   INTEGER DEFAULT 0,
            study_start INTEGER DEFAULT 0,
            study_diplome TEXT DEFAULT '',
            study_effort  REAL DEFAULT 1.0,
            study_revisions INTEGER DEFAULT 0,
            prison_until INTEGER DEFAULT 0,
            hospital_until INTEGER DEFAULT 0,
            travel_until INTEGER DEFAULT 0,
            frozen_until INTEGER DEFAULT 0,
            profile_color TEXT DEFAULT '🔵',
            profile_pic   TEXT DEFAULT '',
            bio           TEXT DEFAULT '',
            location      TEXT DEFAULT '',
            registered    INTEGER DEFAULT 0,
            created_at    INTEGER DEFAULT 0,
            last_seen     INTEGER DEFAULT 0,
            warnings      INTEGER DEFAULT 0,
            banned        INTEGER DEFAULT 0,
            god_mode      INTEGER DEFAULT 0,
            total_earned  INTEGER DEFAULT 0,
            total_spent   INTEGER DEFAULT 0,
            crimes_done   INTEGER DEFAULT 0,
            crimes_success INTEGER DEFAULT 0,
            missions_done INTEGER DEFAULT 0,
            arena_wins    INTEGER DEFAULT 0,
            arena_losses  INTEGER DEFAULT 0,
            travel_count  INTEGER DEFAULT 0,
            lottery_wins  INTEGER DEFAULT 0,
            casino_total_bet INTEGER DEFAULT 0,
            casino_total_win INTEGER DEFAULT 0,
            plants_grown  INTEGER DEFAULT 0,
            hack_attempts INTEGER DEFAULT 0,
            social_followers INTEGER DEFAULT 0,
            political_post TEXT DEFAULT '',
            influence_score INTEGER DEFAULT 0,
            charity_given INTEGER DEFAULT 0,
            insured       INTEGER DEFAULT 0,
            insurance_last INTEGER DEFAULT 0,
            defense_level INTEGER DEFAULT 0,
            last_crime    INTEGER DEFAULT 0,
            sleep_last    INTEGER DEFAULT 0,
            last_hack     INTEGER DEFAULT 0,
            last_life_tick INTEGER DEFAULT 0,
            lifestyle_score INTEGER DEFAULT 50,
            db_version    INTEGER DEFAULT 0,
            last_event_day INTEGER DEFAULT 0,
            referred_by INTEGER DEFAULT 0,
            referral_count INTEGER DEFAULT 0,
            referral_rewards INTEGER DEFAULT 0,
            referral_activated INTEGER DEFAULT 0,
            phone_theme   TEXT DEFAULT 'dark',
            phone_ringtone TEXT DEFAULT 'classic',
            active_vehicle_id INTEGER DEFAULT 0,
            social_rating INTEGER DEFAULT 0,
            social_coins  INTEGER DEFAULT 100
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_balance ON users(balance DESC)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_xp ON users(xp DESC)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_last_seen ON users(last_seen)")
        # Montée en charge : recherche par @username + index PARTIELS (seuls les joueurs
        # concernés sont indexés) pour les tâches planifiées d'expiration.
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_travel ON users(travel_until) WHERE travel_until > 0")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_hospital ON users(hospital_until) WHERE hospital_until > 0")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_prison ON users(prison_until) WHERE prison_until > 0")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_users_study ON users(study_start) WHERE study_start > 0")

        # ─────────────── Table bank_accounts ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS bank_accounts (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            bank_name   TEXT,
            balance     INTEGER DEFAULT 0,
            loan        INTEGER DEFAULT 0,
            loan_due    INTEGER DEFAULT 0,
            loan_penalty_applied INTEGER DEFAULT 0,
            opened_at   INTEGER,
            last_interest INTEGER DEFAULT 0,
            UNIQUE(user_id, bank_name)
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_bank_user ON bank_accounts(user_id)")

        # ─────────────── Comptes web (mini-app / site, joueurs non-Telegram) ───────────────
        # Les joueurs Telegram utilisent directement leur user_id Telegram (toujours positif).
        # Les joueurs web se connectent via Google ; on leur réserve des user_id NÉGATIFS
        # (jamais utilisés par Telegram) générés de façon atomique par web_account_seq.
        await db.execute("""
        CREATE TABLE IF NOT EXISTS web_account_seq (
            seq INTEGER PRIMARY KEY AUTOINCREMENT
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS web_accounts (
            google_sub  TEXT PRIMARY KEY,
            user_id     INTEGER UNIQUE NOT NULL,
            email       TEXT DEFAULT '',
            created_at  INTEGER DEFAULT 0,
            last_login  INTEGER DEFAULT 0
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_web_accounts_user ON web_accounts(user_id)")

        # ─────────────── Table properties ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS properties (
            prop_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            prop_type   TEXT,
            name        TEXT DEFAULT '',
            rented_to   INTEGER DEFAULT 0,
            rented_at   INTEGER DEFAULT 0,
            purchased_at INTEGER,
            condition   INTEGER DEFAULT 100,
            mortgage    INTEGER DEFAULT 0,
            mortgage_due INTEGER DEFAULT 0,
            last_maintenance INTEGER DEFAULT 0
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_properties_user ON properties(user_id)")

        # ─────────────── Table rental_proposals ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS rental_proposals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            property_id INTEGER NOT NULL,
            owner_id INTEGER NOT NULL,
            tenant_id INTEGER NOT NULL,
            rent INTEGER NOT NULL,
            proposed_at INTEGER NOT NULL,
            status TEXT DEFAULT 'pending'
        )""")

        # ─────────────── Table rental_agreements ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS rental_agreements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            property_id INTEGER NOT NULL,
            owner_id INTEGER NOT NULL,
            tenant_id INTEGER NOT NULL,
            rent INTEGER NOT NULL,
            start_date INTEGER NOT NULL,
            end_date INTEGER DEFAULT 0,
            status TEXT DEFAULT 'active'
        )""")

        # ─────────────── Table vehicles ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS vehicles (
            veh_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            veh_type    TEXT,
            condition   INTEGER DEFAULT 100,
            insured     INTEGER DEFAULT 0,
            purchased_at INTEGER,
            last_maintenance INTEGER DEFAULT 0,
            speed       INTEGER DEFAULT 0,
            cargo       INTEGER DEFAULT 0,
            luxury      INTEGER DEFAULT 0,
            fuel        INTEGER DEFAULT 0
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_vehicles_user ON vehicles(user_id)")

        # ─────────────── Table skills ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS skills (
            user_id     INTEGER,
            skill_name  TEXT,
            level       INTEGER DEFAULT 0,
            PRIMARY KEY (user_id, skill_name)
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_skills_user ON skills(user_id)")

        # ─────────────── Table garden ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS garden (
            plot_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            plant_type  TEXT,
            planted_at  INTEGER,
            watered_at  INTEGER DEFAULT 0,
            water_count INTEGER DEFAULT 0,
            ready       INTEGER DEFAULT 0
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_garden_user ON garden(user_id)")

        # ─────────────── Table investments ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS investments (
            inv_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            asset_name  TEXT,
            quantity    REAL DEFAULT 0,
            avg_price   REAL DEFAULT 0,
            bought_at   INTEGER
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_investments_user ON investments(user_id)")

        # ─────────────── Table market_prices ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS market_prices (
            asset_name  TEXT PRIMARY KEY,
            price       REAL,
            updated_at  INTEGER
        )""")

        # ─────────────── Table companies ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS companies (
            company_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT UNIQUE,
            owner_id    INTEGER,
            sector      TEXT,
            treasury    INTEGER DEFAULT 0,
            reputation  INTEGER DEFAULT 50,
            level       INTEGER DEFAULT 1,
            dissolved   INTEGER DEFAULT 0,
            created_at  INTEGER,
            rd_level    INTEGER DEFAULT 0,
            overhead    INTEGER DEFAULT 1000
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS company_members (
            user_id     INTEGER,
            company_id  INTEGER,
            poste       TEXT DEFAULT 'Employé',
            salary      INTEGER DEFAULT 0,
            base_salary INTEGER DEFAULT 0,
            activity_score INTEGER DEFAULT 0,
            joined_at   INTEGER,
            PRIMARY KEY (user_id, company_id)
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_company_members_user ON company_members(user_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_company_members_company ON company_members(company_id)")
        await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_company_member_user ON company_members(user_id)")

        await db.execute("""
        CREATE TABLE IF NOT EXISTS company_applications (
            app_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            company_id  INTEGER,
            status      TEXT DEFAULT 'pending',
            desired_salary INTEGER DEFAULT 0,
            applied_at  INTEGER
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS company_logs (
            log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id  INTEGER,
            action      TEXT,
            actor_id    INTEGER,
            details     TEXT,
            timestamp   INTEGER
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS company_shares (
            user_id     INTEGER,
            company_id  INTEGER,
            shares      INTEGER DEFAULT 0,
            PRIMARY KEY (user_id, company_id)
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_company_shares_company ON company_shares(company_id)")

        await db.execute("""
        CREATE TABLE IF NOT EXISTS company_contracts (
            contract_id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_company INTEGER NOT NULL,
            to_company   INTEGER NOT NULL,
            amount       INTEGER NOT NULL,
            duration     INTEGER NOT NULL,
            status       TEXT DEFAULT 'pending',
            proposed_at  INTEGER NOT NULL
        )""")

        await db.execute("""
        CREATE TABLE IF NOT EXISTS contracts (
            contract_id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_company INTEGER NOT NULL,
            to_company INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            duration INTEGER NOT NULL,
            contract_type TEXT DEFAULT 'service',
            status TEXT DEFAULT 'pending',
            proposed_at INTEGER NOT NULL,
            accepted_at INTEGER DEFAULT 0,
            end_date INTEGER DEFAULT 0
        )""")

        await db.execute("""
        CREATE TABLE IF NOT EXISTS company_products (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id  INTEGER NOT NULL,
            name        TEXT NOT NULL,
            price       INTEGER NOT NULL,
            sales       INTEGER DEFAULT 0,
            revenue     INTEGER DEFAULT 0
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS company_ads (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id  INTEGER NOT NULL,
            poste       TEXT NOT NULL,
            salary      INTEGER NOT NULL,
            created_at  INTEGER NOT NULL
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS company_invitations (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            company_id  INTEGER NOT NULL,
            poste       TEXT NOT NULL,
            salary      INTEGER NOT NULL,
            invited_by  INTEGER NOT NULL,
            invited_at  INTEGER NOT NULL,
            status      TEXT DEFAULT 'pending',
            UNIQUE(user_id, company_id)
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_invitations_user ON company_invitations(user_id, status)")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS sector_events (
            event_id    INTEGER PRIMARY KEY AUTOINCREMENT,
            sector      TEXT NOT NULL,
            description TEXT NOT NULL,
            event_date  INTEGER NOT NULL
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_sector_events_date ON sector_events(event_date DESC)")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS fusion_requests (
            request_id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_company INTEGER NOT NULL,
            to_company INTEGER NOT NULL,
            amount INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending',
            created_at INTEGER NOT NULL,
            responded_at INTEGER DEFAULT 0
        )""")

        # ─────────────── Table family ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS family (
            family_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT DEFAULT '',
            founder_id  INTEGER,
            created_at  INTEGER
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS family_members (
            user_id     INTEGER PRIMARY KEY,
            family_id   INTEGER,
            role        TEXT DEFAULT 'Membre',
            joined_at   INTEGER
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS family_invites (
            family_id   INTEGER NOT NULL,
            invited_id  INTEGER NOT NULL,
            invited_by  INTEGER NOT NULL,
            created_at  INTEGER NOT NULL,
            PRIMARY KEY (family_id, invited_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS marriages (
            user_id     INTEGER PRIMARY KEY,
            partner_id  INTEGER,
            married_at  INTEGER,
            status      TEXT DEFAULT 'active',
            divorced_at INTEGER DEFAULT 0
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS marriage_requests (
            from_id     INTEGER,
            to_id       INTEGER,
            created_at  INTEGER,
            PRIMARY KEY (from_id, to_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS friendships (
            user_id     INTEGER,
            friend_id   INTEGER,
            since       INTEGER,
            PRIMARY KEY (user_id, friend_id)
        )""")

        # ─────────────── Table inventory (avec correction de contrainte) ───────────────
        cursor = await db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='inventory'"
        )
        table_exists = await cursor.fetchone()

        if table_exists:
            cursor = await db.execute("PRAGMA index_list('inventory')")
            indexes = await cursor.fetchall()
            bad_constraint = False
            for idx in indexes:
                idx_name = idx[1]
                is_unique = bool(idx[2])
                if idx_name == 'idx_inventory_item':
                    bad_constraint = True
                    break
                if is_unique:
                    async with db.execute(f"PRAGMA index_info('{idx_name}')") as ic:
                        cols = [r[2] for r in await ic.fetchall()]
                    if cols != ['user_id', 'item_id']:
                        bad_constraint = True
                        break
            if bad_constraint:
                logger.warning("🔄 Correction de la table inventory...")
                await db.execute("PRAGMA foreign_keys=OFF")
                await db.execute("""
                    CREATE TABLE inventory_new (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        item_id INTEGER,
                        item_type TEXT,
                        item_name TEXT,
                        quantity INTEGER DEFAULT 1,
                        acquired_at INTEGER,
                        UNIQUE(user_id, item_id)
                    )
                """)
                await db.execute("""
                    INSERT OR REPLACE INTO inventory_new (user_id, item_id, item_type, item_name, quantity, acquired_at)
                    SELECT user_id, item_id, item_type, item_name, SUM(quantity), MIN(acquired_at)
                    FROM inventory
                    GROUP BY user_id, item_id
                """)
                await db.execute("DROP TABLE inventory")
                await db.execute("ALTER TABLE inventory_new RENAME TO inventory")
                await db.execute("PRAGMA foreign_keys=ON")
                logger.info("✅ Table inventory corrigée.")
            else:
                await db.execute("CREATE INDEX IF NOT EXISTS idx_inventory_user ON inventory(user_id)")
                await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_inventory_user_item ON inventory(user_id, item_id)")
        else:
            await db.execute("""
                CREATE TABLE inventory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    item_id INTEGER,
                    item_type TEXT,
                    item_name TEXT,
                    quantity INTEGER DEFAULT 1,
                    acquired_at INTEGER,
                    UNIQUE(user_id, item_id)
                )
            """)

        # ─────────────── Table items ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS items (
            item_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT NOT NULL UNIQUE,
            type        TEXT NOT NULL,
            rarity      TEXT DEFAULT 'common',
            value       INTEGER DEFAULT 0,
            effect_type TEXT,
            effect_value INTEGER DEFAULT 0,
            emoji       TEXT DEFAULT '📦',
            description TEXT
        )""")

        # ─────────────── Table market_listings ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS market_listings (
            listing_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id   INTEGER NOT NULL,
            item_id     INTEGER NOT NULL,
            quantity    INTEGER NOT NULL DEFAULT 1,
            price       INTEGER NOT NULL,
            created_at  INTEGER NOT NULL,
            expires_at  INTEGER NOT NULL,
            status      TEXT DEFAULT 'active'
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_market_listings ON market_listings(status, item_id, price)")

        # ─────────────── Table auction_listings ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS auction_listings (
            listing_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id   INTEGER,
            item_name   TEXT,
            item_type   TEXT,
            start_price INTEGER,
            current_bid INTEGER DEFAULT 0,
            highest_bidder INTEGER DEFAULT 0,
            ends_at     INTEGER,
            status      TEXT DEFAULT 'active'
        )""")

        # ─────────────── Table crime_log ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS crime_log (
            log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            crime_type  TEXT,
            success     INTEGER,
            reward      INTEGER DEFAULT 0,
            jail_time   INTEGER DEFAULT 0,
            timestamp   INTEGER
        )""")

        # ─────────────── Table travel_log ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS travel_log (
            log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            destination TEXT,
            cost        INTEGER,
            timestamp   INTEGER
        )""")

        # ─────────────── Table missions ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS missions (
            user_id     INTEGER,
            mission_name TEXT,
            mission_type TEXT,
            progress    INTEGER DEFAULT 0,
            target      INTEGER,
            reward      INTEGER,
            xp_reward   INTEGER,
            completed   INTEGER DEFAULT 0,
            completed_at INTEGER DEFAULT 0,
            period      TEXT DEFAULT 'daily',
            reset_at    INTEGER,
            PRIMARY KEY (user_id, mission_name, period)
        )""")

        # ─────────────── Table politics (legacy) ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS politics (
            user_id     INTEGER PRIMARY KEY,
            post        TEXT DEFAULT '',
            votes       INTEGER DEFAULT 0,
            approval    INTEGER DEFAULT 50,
            mandate_end INTEGER DEFAULT 0,
            campaign_fund INTEGER DEFAULT 0,
            last_decree INTEGER DEFAULT 0
        )""")

        # ─────────────── Table social_media ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_media (
            user_id     INTEGER,
            platform    TEXT,
            followers   INTEGER DEFAULT 0,
            posts       INTEGER DEFAULT 0,
            revenue_per_day INTEGER DEFAULT 0,
            last_post   INTEGER DEFAULT 0,
            PRIMARY KEY (user_id, platform)
        )""")

        # ─────────────── Table blackmarket_log ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS blackmarket_log (
            log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            item_name   TEXT,
            price       INTEGER,
            success     INTEGER,
            timestamp   INTEGER
        )""")

        # ─────────────── Table world_events ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS world_events (
            event_id    INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT,
            effect      TEXT,
            severity    REAL,
            started_at  INTEGER,
            ends_at     INTEGER,
            active      INTEGER DEFAULT 1
        )""")

        # ─────────────── Table lottery_tickets ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS lottery_tickets (
            ticket_id   INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            draw_id     INTEGER,
            numbers     TEXT,
            won         INTEGER DEFAULT 0,
            purchased_at INTEGER
        )""")

        # ─────────────── Table lottery_draws ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS lottery_draws (
            draw_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            jackpot     INTEGER DEFAULT 10000000,
            winning_numbers TEXT DEFAULT '',
            drawn_at    INTEGER DEFAULT 0,
            winner_id   INTEGER DEFAULT 0
        )""")

        # ─────────────── Table hack_log ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS hack_log (
            log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            hacker_id   INTEGER,
            target_type TEXT,
            success     INTEGER,
            reward      INTEGER DEFAULT 0,
            timestamp   INTEGER
        )""")

        # ─────────────── Table pvp_challenges ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS pvp_challenges (
            challenge_id INTEGER PRIMARY KEY AUTOINCREMENT,
            challenger_id INTEGER,
            target_id    INTEGER,
            bet          INTEGER DEFAULT 0,
            mode         TEXT DEFAULT '1v1',
            status       TEXT DEFAULT 'pending',
            created_at   INTEGER
        )""")

        # ─────────────── Table insurance ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS insurance (
            user_id     INTEGER PRIMARY KEY,
            type        TEXT DEFAULT 'basic',
            premium     INTEGER DEFAULT 0,
            coverage    INTEGER DEFAULT 0,
            since       INTEGER DEFAULT 0,
            claims      INTEGER DEFAULT 0
        )""")

        # ─────────────── Table admin_logs ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS admin_logs (
            log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id    INTEGER,
            action      TEXT,
            target_id   INTEGER,
            details     TEXT,
            timestamp   INTEGER
        )""")

        # ═══════════════════════════════════════════════════════════════
        # ⭐ Table transaction_log (paiements, achats, refs)
        # ═══════════════════════════════════════════════════════════════
        await db.execute("""
        CREATE TABLE IF NOT EXISTS transaction_log (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            reference_id     TEXT NOT NULL UNIQUE,
            user_id          INTEGER NOT NULL,
            timestamp        INTEGER NOT NULL,
            amount           INTEGER NOT NULL,
            description      TEXT NOT NULL,
            transaction_type TEXT NOT NULL,
            metadata         TEXT DEFAULT '',
            status           TEXT DEFAULT 'completed'
        )""")
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_transaction_user "
            "ON transaction_log(user_id, timestamp DESC)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_transaction_ref "
            "ON transaction_log(reference_id)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_transaction_time "
            "ON transaction_log(timestamp DESC)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_transaction_type "
            "ON transaction_log(transaction_type, timestamp DESC)"
        )

        # ═══════════════════════════════════════════════════════════════
        # ⭐ Table admin_roles (hiérarchie GAME FRENCH)
        # ═══════════════════════════════════════════════════════════════
        await db.execute("""
        CREATE TABLE IF NOT EXISTS admin_roles (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            role        TEXT NOT NULL,
            assigned_by INTEGER NOT NULL,
            assigned_at INTEGER NOT NULL,
            revoked_by  INTEGER DEFAULT 0,
            revoked_at  INTEGER DEFAULT 0,
            notes       TEXT DEFAULT ''
        )""")
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_admin_roles_user "
            "ON admin_roles(user_id, revoked_at)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_admin_roles_role "
            "ON admin_roles(role, revoked_at)"
        )

        # ─────────────── Table price_history ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS price_history (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_name  TEXT,
            price       REAL,
            recorded_at INTEGER,
            UNIQUE(asset_name, recorded_at)
        )""")

        # ─────────────── Table gangs ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS gangs (
            gang_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT UNIQUE,
            founder_id  INTEGER,
            treasury    INTEGER DEFAULT 0,
            reputation  INTEGER DEFAULT 0,
            created_at  INTEGER,
            last_hold   INTEGER DEFAULT 0
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS gang_members (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            gang_id     INTEGER,
            user_id     INTEGER UNIQUE,
            role        TEXT DEFAULT 'Membre',
            joined_at   INTEGER
        )""")

        # ─────────────── Table adoptions ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS adoptions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            parent_id   INTEGER,
            child_id    INTEGER UNIQUE,
            adopted_at  INTEGER
        )""")

        # ─────────────── Table casino_log ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS casino_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            game        TEXT,
            bet         INTEGER DEFAULT 0,
            profit      INTEGER DEFAULT 0,
            played_at   INTEGER
        )""")

        # ─────────────── Table bank_loans ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS bank_loans (
            loan_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            amount      INTEGER,
            interest    REAL DEFAULT 0.05,
            repaid      INTEGER DEFAULT 0,
            created_at  INTEGER,
            repaid_at   INTEGER DEFAULT 0
        )""")

        # ─────────────── Table user_badges ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS user_badges (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            badge       TEXT,
            earned_at   INTEGER
        )""")

        # ─────────────── Table title_history ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS title_history (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            old_title   TEXT,
            new_title   TEXT,
            changed_at  INTEGER
        )""")

        # ─────────────── Table plants ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS plants (
            plant_type  TEXT PRIMARY KEY,
            grow_time   INTEGER,
            value       INTEGER,
            water_needed INTEGER,
            illegal     INTEGER DEFAULT 0
        )""")

        # ─────────────── Table mission_log ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS mission_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            mission_name TEXT,
            reward      INTEGER,
            xp          INTEGER,
            completed_at INTEGER
        )""")

        # ─────────────── Table social_log ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            revenue     INTEGER,
            timestamp   INTEGER
        )""")

        # ─────────────── Table user_cooldowns ───────────────
        await db.execute(
            "CREATE TABLE IF NOT EXISTS user_cooldowns ("
            "user_id INTEGER NOT NULL,"
            "cooldown_key TEXT NOT NULL,"
            "last_used INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY (user_id, cooldown_key)"
            ")"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_user_cooldowns_last_used "
            "ON user_cooldowns(last_used)"
        )

        # ─────────────── Table user_achievements ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS user_achievements (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL,
            achievement_id  TEXT NOT NULL,
            unlocked_at     INTEGER NOT NULL,
            UNIQUE(user_id, achievement_id)
        )""")

        # ─────────────── Table tutorial_progress ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS tutorial_progress (
            user_id       INTEGER PRIMARY KEY,
            step_index    INTEGER DEFAULT 0,
            completed     INTEGER DEFAULT 0,
            claimed_step  INTEGER DEFAULT -1,
            updated_at    INTEGER NOT NULL
        )""")

        # ─────────────── Table user_stat_history ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS user_stat_history (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            stat_name    TEXT NOT NULL,
            stat_value   REAL NOT NULL,
            recorded_at  INTEGER NOT NULL
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_user_stat_history ON user_stat_history(user_id, stat_name, recorded_at DESC)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_user_stat_history_time ON user_stat_history(recorded_at)")

        # ─────────────── Table notifications ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            title       TEXT NOT NULL,
            message     TEXT NOT NULL,
            type        TEXT DEFAULT 'info',
            delay       INTEGER DEFAULT 0,
            created_at  INTEGER NOT NULL,
            sent        INTEGER DEFAULT 0,
            sent_at     INTEGER DEFAULT 0
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, sent)")
        # Le job d'envoi cherche « sent = 0 » toutes les quelques secondes : sans cet index, il
        # parcourait toute la table (30 jours d'historique) en bloquant le verrou global de la base.
        await db.execute("CREATE INDEX IF NOT EXISTS idx_notifications_pending ON notifications(sent, created_at)")

        # ─────────────── Table life_journal ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS life_journal (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            category    TEXT NOT NULL,
            summary     TEXT NOT NULL,
            severity    TEXT DEFAULT 'info',
            created_at  INTEGER NOT NULL
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_life_journal_user ON life_journal(user_id, created_at DESC)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_life_journal_time ON life_journal(created_at)")

        # ─────────────── Table reports ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS reports (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL,
            report_type     TEXT NOT NULL,
            message         TEXT NOT NULL,
            target_id       INTEGER,
            status          TEXT DEFAULT 'pending',
            admin_response  TEXT,
            created_at      INTEGER NOT NULL,
            resolved_at     INTEGER DEFAULT 0
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_reports_target_time ON reports(target_id, user_id, created_at)")

        # ─────────────── Table mp_trades ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS mp_trades (
            trade_id    INTEGER PRIMARY KEY AUTOINCREMENT,
            from_id     INTEGER NOT NULL,
            to_id       INTEGER NOT NULL,
            offer_money INTEGER DEFAULT 0,
            offer_items TEXT DEFAULT '',
            request_money INTEGER DEFAULT 0,
            request_items TEXT DEFAULT '',
            status      TEXT DEFAULT 'pending',
            created_at  INTEGER NOT NULL,
            expires_at  INTEGER NOT NULL
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_trades_status ON mp_trades(status, expires_at)")

        # ─────────────── Table game_calendar ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS game_calendar (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT,
            created_at INTEGER NOT NULL,
            user_id INTEGER DEFAULT 0
        )
        """)
        await db.execute("CREATE INDEX IF NOT EXISTS idx_calendar_date ON game_calendar(date)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_calendar_user ON game_calendar(user_id)")

        # ─────────────── Table phone_messages ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS phone_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_id INTEGER NOT NULL,
            to_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            read INTEGER DEFAULT 0
        )""")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_phone_messages_to ON phone_messages(to_id, read, created_at)")

        # ⭐ NOUVEAU (Étape D.1) : Table phone_status (statuts VoidGram persistants)
        await db.execute("""
        CREATE TABLE IF NOT EXISTS phone_status (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            text        TEXT NOT NULL,
            created_at  INTEGER NOT NULL
        )""")
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_phone_status_created "
            "ON phone_status(created_at DESC)"
        )

        # ─────────────── Index supplémentaires ───────────────
        await db.execute("CREATE INDEX IF NOT EXISTS idx_company_products ON company_products(company_id)")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_contracts_to ON company_contracts(to_company, status)")

        # ─────────────── MIGRATIONS COLONNES (users) ───────────────
        for col, col_type in [
            ("parier_cooldown", "INTEGER DEFAULT 0"),
            ("job_level", "INTEGER DEFAULT 1"),
            ("last_life_tick", "INTEGER DEFAULT 0"),
            ("lifestyle_score", "INTEGER DEFAULT 50"),
            ("last_event_day", "INTEGER DEFAULT 0"),
            ("plant_cooldown", "INTEGER DEFAULT 0"),
            ("harvest_cooldown", "INTEGER DEFAULT 0"),
            ("water_cooldown", "INTEGER DEFAULT 0"),
            ("study_cooldown", "INTEGER DEFAULT 0"),
            ("revision_cooldown", "INTEGER DEFAULT 0"),
            ("formation_cooldown", "INTEGER DEFAULT 0"),
            ("buy_property", "INTEGER DEFAULT 0"),
            ("mortgage", "INTEGER DEFAULT 0"),
            ("rent_property", "INTEGER DEFAULT 0"),
            ("sell_property", "INTEGER DEFAULT 0"),
            ("maintain_property", "INTEGER DEFAULT 0"),
            ("medecin_last", "INTEGER DEFAULT 0"),
            ("gym_last", "INTEGER DEFAULT 0"),
            ("medicaments_last", "INTEGER DEFAULT 0"),
            ("hospital_last", "INTEGER DEFAULT 0"),
            ("doctor_last", "INTEGER DEFAULT 0"),
            ("hopital_last", "INTEGER DEFAULT 0"),
            ("assurance_subscribe", "INTEGER DEFAULT 0"),
            ("insure_vehicle", "INTEGER DEFAULT 0"),
            ("buy_cooldown", "INTEGER DEFAULT 0"),
            ("sell_cooldown", "INTEGER DEFAULT 0"),
            ("post_cooldown", "INTEGER DEFAULT 0"),
            ("collab_cooldown", "INTEGER DEFAULT 0"),
            ("vote_cooldown", "INTEGER DEFAULT 0"),
            ("report_cooldown", "INTEGER DEFAULT 0"),
            ("luxury_buy", "INTEGER DEFAULT 0"),
            ("buy_vehicle", "INTEGER DEFAULT 0"),
            ("repair_vehicle", "INTEGER DEFAULT 0"),
            ("sell_vehicle", "INTEGER DEFAULT 0"),
            ("propose_rental", "INTEGER DEFAULT 0"),
            ("last_hold", "INTEGER DEFAULT 0"),
            ("story_cooldown", "INTEGER DEFAULT 0"),
            ("live_cooldown", "INTEGER DEFAULT 0"),
            ("social_rating_cooldown", "INTEGER DEFAULT 0"),
            ("create_community_cooldown", "INTEGER DEFAULT 0"),
            ("share_cooldown", "INTEGER DEFAULT 0"),
            ("trend_cooldown", "INTEGER DEFAULT 0"),
            ("poll_cooldown", "INTEGER DEFAULT 0"),
            ("use_cooldown", "INTEGER DEFAULT 0"),
            ("don_cooldown", "INTEGER DEFAULT 0"),
            ("casino_last", "INTEGER DEFAULT 0"),
            ("last_election", "INTEGER DEFAULT 0"),
            ("last_motion", "INTEGER DEFAULT 0"),
            ("last_constitution", "INTEGER DEFAULT 0"),
            ("phone_theme", "TEXT DEFAULT 'dark'"),
            ("phone_ringtone", "TEXT DEFAULT 'classic'"),
            ("active_vehicle_id", "INTEGER DEFAULT 0"),
            ("social_rating", "INTEGER DEFAULT 0"),
            ("social_coins", "INTEGER DEFAULT 100"),
            ("referred_by", "INTEGER DEFAULT 0"),
            ("referral_count", "INTEGER DEFAULT 0"),
            ("referral_rewards", "INTEGER DEFAULT 0"),
            ("referral_activated", "INTEGER DEFAULT 0"),
            ("db_version", "INTEGER DEFAULT 0"),
            ("frozen_until", "INTEGER DEFAULT 0"),
            ("insured", "INTEGER DEFAULT 0"),
            ("insurance_last", "INTEGER DEFAULT 0"),
        ]:
            try:
                await db.execute(f"ALTER TABLE users ADD COLUMN {col} {col_type}")
            except aiosqlite.OperationalError:
                swallowed('database.py')

        # ─────────────── MIGRATIONS COLONNES (companies) ───────────────
        for table, column, col_type in [
            ("companies", "rd_level", "INTEGER DEFAULT 0"),
            ("companies", "overhead", "INTEGER DEFAULT 1000"),
            ("company_members", "base_salary", "INTEGER DEFAULT 0"),
            ("company_applications", "desired_salary", "INTEGER DEFAULT 0"),
        ]:
            try:
                await db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type}")
            except aiosqlite.OperationalError:
                swallowed('database.py')

        try:
            await db.execute("UPDATE company_members SET base_salary = salary WHERE base_salary = 0 AND salary > 0")
        except aiosqlite.OperationalError:
            swallowed('database.py')

        # ─────────────── MIGRATIONS COLONNES (contracts) ───────────────
        for col, col_type in [
            ("accepted_at", "INTEGER DEFAULT 0"),
            ("end_date", "INTEGER DEFAULT 0"),
        ]:
            try:
                await db.execute(f"ALTER TABLE contracts ADD COLUMN {col} {col_type}")
            except aiosqlite.OperationalError:
                swallowed('database.py')

        # ─────────────── MIGRATIONS COLONNES (properties, vehicles) ───────────────
        for table in ["properties", "vehicles"]:
            try:
                await db.execute(f"ALTER TABLE {table} ADD COLUMN last_maintenance INTEGER DEFAULT 0")
            except aiosqlite.OperationalError:
                swallowed('database.py')

        # ─────────────── MIGRATIONS COLONNES (vehicles 2.0) ───────────────
        for col in ["speed", "cargo", "luxury", "fuel"]:
            try:
                await db.execute(f"ALTER TABLE vehicles ADD COLUMN {col} INTEGER DEFAULT 0")
            except aiosqlite.OperationalError:
                swallowed('database.py')

        # ═══════════════════════════════════════════════════════════════
        #              INITIALISATION DES DONNÉES DE BASE
        # ═══════════════════════════════════════════════════════════════

        for a in ASSETS:
            await db.execute(
                "INSERT OR IGNORE INTO market_prices (asset_name, price, updated_at) VALUES (?,?,?)",
                (a["name"], a["price"], now())
            )

        async with db.execute("SELECT COUNT(*) FROM lottery_draws") as cur:
            count = (await cur.fetchone())[0]
        if count == 0:
            await db.execute(
                "INSERT INTO lottery_draws (jackpot, drawn_at) VALUES (?,0)",
                (10_000_000,)
            )

        for plant, data in PLANTS.items():
            await db.execute("""
                INSERT INTO plants(plant_type, grow_time, value, water_needed, illegal)
                VALUES(?,?,?,?,?)
                ON CONFLICT(plant_type) DO UPDATE SET
                    grow_time=excluded.grow_time,
                    value=excluded.value,
                    water_needed=excluded.water_needed,
                    illegal=excluded.illegal
            """, (plant, data["grow_time"], data["value"], data["water_needed"], 1 if data.get("illegal") else 0))

        base_items = [
            ("Potion de soin", "consumable", "common", 500, "heal", 20, "💊", "Restaure 20% de santé"),
            ("Potion d'énergie", "consumable", "common", 300, "energy", 20, "🔋", "Reste 20% d'énergie"),
            ("Parchemin d'XP", "consumable", "rare", 2000, "xp", 100, "📜", "Donne 100 XP"),
            ("Petit coffre", "key", "common", 1000, "money", 5000, "🎁", "Contient 5000 coins"),
            ("Épée rouillée", "weapon", "common", 1500, "damage", 5, "⚔️", "+5 dégâts"),
            ("Bouclier en bois", "armor", "common", 1200, "defense", 5, "🛡️", "+5 défense"),
            ("Amulette de chance", "cosmetic", "epic", 50000, "luck", 5, "🍀", "+5% chance"),
            ("Parchemin de téléportation", "consumable", "rare", 8000, "travel", 1, "🌀", "Téléportation"),
        ]
        for name, typ, rarity, value, effect_type, effect_val, emoji, desc in base_items:
            await db.execute("""
                INSERT OR IGNORE INTO items (name, type, rarity, value, effect_type, effect_value, emoji, description)
                VALUES (?,?,?,?,?,?,?,?)
            """, (name, typ, rarity, value, effect_type, effect_val, emoji, desc))

        # ─────────────── MODULE SOCIAL AVANCÉ ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            platform TEXT,
            action_type TEXT,
            gain INTEGER DEFAULT 0,
            timestamp INTEGER NOT NULL
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_lives (
            live_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            platform TEXT,
            started_at INTEGER,
            ends_at INTEGER,
            active INTEGER DEFAULT 1
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_polls (
            poll_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            question TEXT NOT NULL,
            options TEXT,
            created_at INTEGER NOT NULL,
            active INTEGER DEFAULT 1
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_poll_votes (
            poll_id INTEGER,
            user_id INTEGER,
            option_index INTEGER,
            PRIMARY KEY (poll_id, user_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_communities (
            community_id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            owner_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            disbanded INTEGER DEFAULT 0
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_community_members (
            community_id INTEGER,
            user_id INTEGER,
            role TEXT DEFAULT 'member',
            joined_at INTEGER,
            PRIMARY KEY (community_id, user_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_community_invites (
            invite_id INTEGER PRIMARY KEY AUTOINCREMENT,
            community_id INTEGER,
            invited_id INTEGER,
            inviter_id INTEGER,
            created_at INTEGER,
            status TEXT DEFAULT 'pending'
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_trends (
            trend_id INTEGER PRIMARY KEY AUTOINCREMENT,
            hashtag TEXT NOT NULL,
            creator_id INTEGER,
            multiplier REAL DEFAULT 1.5,
            expires_at INTEGER NOT NULL,
            active INTEGER DEFAULT 1
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_user_trends (
            user_id INTEGER,
            hashtag TEXT,
            multiplier REAL,
            used INTEGER DEFAULT 0,
            PRIMARY KEY (user_id, hashtag)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_follower_offers (
            offer_id INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id INTEGER,
            buyer_id INTEGER,
            quantity INTEGER,
            price INTEGER,
            status TEXT DEFAULT 'pending',
            created_at INTEGER
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_collab_requests (
            request_id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_id INTEGER,
            to_id INTEGER,
            collab_type TEXT,
            duration_h INTEGER,
            status TEXT DEFAULT 'pending',
            created_at INTEGER
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_active_collabs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_id INTEGER,
            to_id INTEGER,
            collab_type TEXT,
            expires_at INTEGER
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_reputation (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            rater_id INTEGER NOT NULL,
            delta INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            UNIQUE(user_id, rater_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS social_engagement_boosts (
            user_id INTEGER,
            platform TEXT,
            multiplier REAL,
            expires_at INTEGER,
            PRIMARY KEY (user_id, platform)
        )""")

        # ─────────────── PARRAINAGE ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS referrals (
            referrer_id INTEGER NOT NULL,
            referred_id INTEGER PRIMARY KEY,
            created_at INTEGER NOT NULL,
            starter_rewarded INTEGER DEFAULT 0,
            activated_at INTEGER DEFAULT 0
        )""")

        # ─────────────── POLITIQUE AVANCÉE ───────────────
        await db.execute("""
        CREATE TABLE IF NOT EXISTS elections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            poste TEXT NOT NULL,
            started_by INTEGER NOT NULL,
            started_at INTEGER NOT NULL,
            ends_at INTEGER NOT NULL,
            status TEXT DEFAULT 'open',
            quorum INTEGER DEFAULT 0,
            description TEXT DEFAULT ''
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS candidates (
            election_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            program TEXT,
            party_id INTEGER,
            PRIMARY KEY (election_id, user_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS votes (
            election_id INTEGER NOT NULL,
            voter_id INTEGER NOT NULL,
            candidate_id INTEGER NOT NULL,
            voted_at INTEGER NOT NULL,
            PRIMARY KEY (election_id, voter_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS political_offices (
            poste TEXT PRIMARY KEY,
            occupant_id INTEGER,
            elected_at INTEGER,
            election_id INTEGER,
            last_activity INTEGER DEFAULT 0
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS parties (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            ideology TEXT,
            leader_id INTEGER NOT NULL,
            treasury INTEGER DEFAULT 0,
            created_at INTEGER NOT NULL,
            disbanded INTEGER DEFAULT 0
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS party_members (
            party_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            role TEXT DEFAULT 'member',
            joined_at INTEGER NOT NULL,
            PRIMARY KEY (party_id, user_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS party_invites (
            invite_id INTEGER PRIMARY KEY AUTOINCREMENT,
            party_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            invited_by INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            status TEXT DEFAULT 'pending'
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS constitution (
            id INTEGER PRIMARY KEY CHECK (id=1),
            text TEXT NOT NULL,
            amended_by INTEGER,
            amended_at INTEGER NOT NULL
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS laws (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            proposer_id INTEGER NOT NULL,
            effect_type TEXT,
            effect_value INTEGER,
            status TEXT DEFAULT 'proposed',
            votes_for INTEGER DEFAULT 0,
            votes_against INTEGER DEFAULT 0,
            required_majority REAL DEFAULT 0.5,
            created_at INTEGER NOT NULL,
            voting_ends_at INTEGER,
            enacted_at INTEGER
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS law_votes (
            law_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            vote INTEGER NOT NULL,
            voted_at INTEGER NOT NULL,
            PRIMARY KEY (law_id, user_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS cabinet_positions (
            position TEXT PRIMARY KEY,
            occupant_id INTEGER,
            appointed_by INTEGER,
            appointed_at INTEGER,
            FOREIGN KEY(occupant_id) REFERENCES users(user_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS referendums (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT NOT NULL,
            proposer_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL,
            voting_ends_at INTEGER NOT NULL,
            votes_for INTEGER DEFAULT 0,
            votes_against INTEGER DEFAULT 0,
            status TEXT DEFAULT 'open',
            required_majority REAL DEFAULT 0.5
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS referendum_votes (
            referendum_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            vote INTEGER NOT NULL,
            voted_at INTEGER NOT NULL,
            PRIMARY KEY (referendum_id, user_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS motions (
            motion_id INTEGER PRIMARY KEY AUTOINCREMENT,
            target_id INTEGER NOT NULL,
            initiated_by INTEGER NOT NULL,
            initiated_at INTEGER NOT NULL,
            ends_at INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            signatures_needed INTEGER DEFAULT 0,
            signatures INTEGER DEFAULT 0
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS motion_signatures (
            motion_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            signed_at INTEGER NOT NULL,
            PRIMARY KEY (motion_id, user_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS motion_votes (
            motion_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            vote TEXT NOT NULL,
            voted_at INTEGER NOT NULL,
            PRIMARY KEY (motion_id, user_id)
        )""")
        await db.execute("""
        CREATE TABLE IF NOT EXISTS political_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            description TEXT NOT NULL,
            involved_user_id INTEGER,
            timestamp INTEGER NOT NULL
        )""")

        async with db.execute("SELECT COUNT(*) FROM constitution") as cur:
            if (await cur.fetchone())[0] == 0:
                await db.execute(
                    "INSERT INTO constitution (id, text, amended_by, amended_at) VALUES (1, ?, 0, ?)",
                    ("Le pouvoir émane des joueurs. Les élections sont libres. Les lois sont votées par tous.", now())
                )

        await db.execute("UPDATE users SET db_version = ? WHERE db_version = 0", (DB_VERSION,))

        await db.commit()
        logger.info("✅ Base de données initialisée (hiérarchie admin + toutes les tables).")

        await migrate_vehicle_stats()


# ═══════════════════════════════════════════════════════════════════════════
#                    FONCTIONS UTILITAIRES DE BASE
# ═══════════════════════════════════════════════════════════════════════════

async def _record_stat_snapshot_with_db(db, user_id: int, stat_name: str, stat_value, recorded_at: int | None = None):
    await db.execute(
        "INSERT INTO user_stat_history (user_id, stat_name, stat_value, recorded_at) VALUES (?,?,?,?)",
        (user_id, stat_name, float(stat_value), recorded_at or now())
    )


async def record_user_stat_snapshot(user_id: int, stat_name: str, stat_value):
    async with db_connection() as db:
        await _record_stat_snapshot_with_db(db, user_id, stat_name, stat_value)
        await db.commit()


_snapshot_last: dict[int, int] = {}


def _snapshot_due(user_id: int) -> bool:
    """Au plus un point d'historique par joueur et par STAT_SNAPSHOT_MIN_INTERVAL secondes."""
    if STAT_SNAPSHOT_MIN_INTERVAL <= 0:
        return True
    t = now()
    if t - _snapshot_last.get(user_id, 0) < STAT_SNAPSHOT_MIN_INTERVAL:
        return False
    if len(_snapshot_last) > 500_000:      # évite une croissance sans fin en mémoire
        limit = t - STAT_SNAPSHOT_MIN_INTERVAL
        for uid in [u for u, ts in _snapshot_last.items() if ts < limit]:
            del _snapshot_last[uid]
    _snapshot_last[user_id] = t
    return True


async def snapshot_user_core_stats(user_id: int, db=None, _checked: bool = False):
    if not _checked and not _snapshot_due(user_id):
        return
    owns_connection = db is None
    if owns_connection:
        async with db_connection(row_factory=aiosqlite.Row) as conn:
            await snapshot_user_core_stats(user_id, conn, _checked=True)
            await conn.commit()
        return

    previous_row_factory = db.row_factory
    db.row_factory = aiosqlite.Row
    try:
        async with db.execute("SELECT balance, xp, prestige FROM users WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
        if not row:
            return
        timestamp = now()
        await _record_stat_snapshot_with_db(db, user_id, "balance", row["balance"], timestamp)
        await _record_stat_snapshot_with_db(db, user_id, "xp", row["xp"], timestamp)
        await _record_stat_snapshot_with_db(db, user_id, "prestige", row["prestige"], timestamp)
    finally:
        db.row_factory = previous_row_factory


PRUNE_BATCH = 5000


async def prune_old_history() -> None:
    """Purge par lots l'historique ancien (stats > STAT_HISTORY_RETENTION_DAYS, journal > JOURNAL_RETENTION_DAYS)."""
    t = now()
    plan = (
        ("user_stat_history", "recorded_at", t - STAT_HISTORY_RETENTION_DAYS * 86400),
        ("life_journal", "created_at", t - JOURNAL_RETENTION_DAYS * 86400),
    )
    for table, column, cutoff in plan:
        total = 0
        while True:
            async with db_connection() as db:
                cur = await db.execute(
                    f"DELETE FROM {table} WHERE rowid IN "
                    f"(SELECT rowid FROM {table} WHERE {column} < ? LIMIT ?)",
                    (cutoff, PRUNE_BATCH),
                )
                n = max(0, cur.rowcount)
                await db.commit()
            total += n
            if n < PRUNE_BATCH:
                break
            await asyncio.sleep(0)     # laisse passer les autres tâches entre deux lots
        if total:
            logger.info("🧹 %s : %s lignes anciennes purgées.", table, total)


async def get_user(user_id: int, username: str = "", full_name: str = "") -> dict:
    """Chemin rapide SANS verrou global : joueur existant dont pseudo/nom n'ont pas changé.
    Inscription et mise à jour du pseudo passent par `_get_user_rw` (inchangé)."""
    async with db_read(row_factory=aiosqlite.Row) as rdb:
        async with rdb.execute("SELECT * FROM users WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
    if row is not None:
        u = dict(row)
        if not ((username and u["username"] != username)
                or (full_name and u.get("full_name") != full_name)):
            return u
    return await _get_user_rw(user_id, username, full_name)


async def _get_user_rw(user_id: int, username: str = "", full_name: str = "") -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM users WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
        if row:
            u = dict(row)
            fields = []
            values = []
            if username and u["username"] != username:
                fields.append("username=?")
                values.append(username)
            if full_name and u.get("full_name") != full_name:
                fields.append("full_name=?")
                values.append(full_name)
            if fields:
                fields.append("last_seen=?")
                values.append(now())
                values.append(user_id)
                await db.execute(f"UPDATE users SET {', '.join(fields)} WHERE user_id=?", values)
                await db.commit()
            return u
        await db.execute("""
            INSERT INTO users (user_id, username, full_name, balance, registered, created_at, last_seen, last_life_tick, lifestyle_score, db_version, social_coins)
            VALUES (?,?,?,?,0,?,?,?,50,?,?)
        """, (user_id, username, full_name, STARTING_BALANCE, now(), now(), now(), DB_VERSION, SOCIAL_COIN_STARTING_BALANCE))
        await snapshot_user_core_stats(user_id, db)
        await db.commit()
        async with db.execute("SELECT * FROM users WHERE user_id=?", (user_id,)) as cur:
            return dict(await cur.fetchone())


async def update_balance(user_id: int, amount: int, sink: str | None = None):
    """Crédite / débite un joueur. `sink` (dépense envers le jeu, pas envers un joueur) : la somme dépensée
    est versée au Trésor public de l'Administration (voir utils/treasury.py), dans la même transaction."""
    for attempt in range(3):
        try:
            async with db_connection() as db:
                if amount > 0:
                    await db.execute(
                        "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                        (amount, amount, user_id)
                    )
                else:
                    async with db.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)) as cur:
                        row = await cur.fetchone()
                        if row and row[0] + amount < 0:
                            raise ValueError("Solde insuffisant")
                    await db.execute(
                        "UPDATE users SET balance=balance+?, total_spent=total_spent+? WHERE user_id=?",
                        (amount, -amount, user_id)
                    )
                    if sink:
                        from utils.treasury import collect
                        await collect(db, -amount, sink)
                await snapshot_user_core_stats(user_id, db)
                await db.commit()
            return
        except aiosqlite.OperationalError as e:
            if "database is locked" in str(e) and attempt < 2:
                await asyncio.sleep(0.2 * (attempt + 1))
                continue
            raise


async def update_field(user_id: int, field: str, value):
    if field not in ALLOWED_FIELDS:
        raise ValueError(f"Champ non autorisé : {field}")
    async with db_connection() as db:
        await db.execute(f"UPDATE users SET {field}=? WHERE user_id=?", (value, user_id))
        if field in {"balance", "xp", "prestige"}:
            await snapshot_user_core_stats(user_id, db)
        await db.commit()


async def increment_field(user_id: int, field: str, amount=1):
    if field not in ALLOWED_FIELDS:
        raise ValueError(f"Champ non autorisé : {field}")
    async with db_connection() as db:
        if field in {"health", "energy", "hunger", "happiness"} and amount < 0:
            # 🛡️ God mode : les stats vitales ne baissent jamais
            await db.execute(f"UPDATE users SET {field}={field}+? WHERE user_id=? AND COALESCE(god_mode,0)=0",
                             (amount, user_id))
        else:
            await db.execute(f"UPDATE users SET {field}={field}+? WHERE user_id=?", (amount, user_id))
        if field in {"balance", "xp", "prestige"}:
            await snapshot_user_core_stats(user_id, db)
        await db.commit()


# ═══════════════════════════════════════════════════════════════════════════
#                    BOUTIQUE ÉTOILES (Telegram Stars / XTR)
# ═══════════════════════════════════════════════════════════════════════════

async def log_star_purchase(user_id: int, item_id: str, stars_amount: int,
                             charge_id: str, payload: str) -> bool:
    async with db_connection() as db:
        async with db.execute(
            "SELECT 1 FROM star_purchases WHERE charge_id=?", (charge_id,)
        ) as cur:
            if await cur.fetchone():
                return False
        await db.execute(
            "INSERT INTO star_purchases "
            "(user_id, item_id, stars_amount, charge_id, payload, created_at) "
            "VALUES (?,?,?,?,?,?)",
            (user_id, item_id, stars_amount, charge_id, payload, real_now()),
        )
        await db.commit()
        return True


async def grant_subscription(user_id: int, tier: str, days: int) -> int:
    field = "premium_until" if tier == "premium" else "vip_until"
    async with db_connection() as db:
        async with db.execute(
            f"SELECT {field} FROM users WHERE user_id=?", (user_id,)
        ) as cur:
            row = await cur.fetchone()
        current = row[0] if row and row[0] else 0
        base = max(current, real_now())          # abonnement payant = jours RÉELS
        new_until = base + days * 86400
        await db.execute(f"UPDATE users SET {field}=? WHERE user_id=?", (new_until, user_id))
        await db.commit()
        return new_until


async def extend_boost(user_id: int, field: str, days: int) -> int:
    async with db_connection() as db:
        async with db.execute(
            f"SELECT {field} FROM users WHERE user_id=?", (user_id,)
        ) as cur:
            row = await cur.fetchone()
        current = row[0] if row and row[0] else 0
        base = max(current, real_now())          # abonnement payant = jours RÉELS
        new_until = base + days * 86400
        await db.execute(f"UPDATE users SET {field}=? WHERE user_id=?", (new_until, user_id))
        await db.commit()
        return new_until


async def add_stack(user_id: int, field: str, amount: int, max_total: int) -> int:
    async with db_connection() as db:
        async with db.execute(
            f"SELECT {field} FROM users WHERE user_id=?", (user_id,)
        ) as cur:
            row = await cur.fetchone()
        current = row[0] if row and row[0] else 0
        new_total = min(max_total, current + amount)
        await db.execute(f"UPDATE users SET {field}=? WHERE user_id=?", (new_total, user_id))
        await db.commit()
        return new_total


# ═══════════════════════════════════════════════════════════════════════════
#         ⭐ add_life_journal — accepte une connexion existante
# ═══════════════════════════════════════════════════════════════════════════

async def add_life_journal(
    user_id: int,
    category: str,
    summary: str,
    severity: str = 'info',
    db: aiosqlite.Connection | None = None,
):
    """
    Ajoute une entrée au journal de vie.

    ⚠️ IMPORTANT :
      - Si `db` est fourni, l'INSERT est exécuté sur CETTE connexion, SANS commit.
        C'est à l'appelant de gérer la transaction (et donc le commit).
        → Évite les 'database is locked' quand on est déjà dans une transaction.

      - Si `db` est None, ouvre sa propre connexion via le pool et commit immédiatement.
    """
    sql = (
        "INSERT INTO life_journal (user_id, category, summary, severity, created_at) "
        "VALUES (?,?,?,?,?)"
    )
    params = (user_id, category, summary, severity, now())

    if db is not None:
        # Écriture dans la transaction courante de l'appelant
        await db.execute(sql, params)
        return

    # Connexion indépendante (cas général : appel hors transaction)
    async with db_connection() as db_conn:
        await db_conn.execute(sql, params)
        await db_conn.commit()


async def get_life_journal(user_id: int, limit: int = 10) -> list:
    async with db_read(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM life_journal WHERE user_id=? ORDER BY created_at DESC, id DESC LIMIT ?",
            (user_id, limit)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_top_rich(limit=10) -> list:
    from utils.staff_scope import excluded_sql      # staff N2+ : jamais dans un classement
    async with db_read(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT user_id, full_name, username, balance FROM users WHERE " + excluded_sql("user_id")
            + " ORDER BY balance DESC LIMIT ?",
            (limit,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_or_create_web_account(google_sub: str, email: str = "") -> dict:
    """Retrouve (ou crée) le compte web lié à un identifiant Google (`sub`).

    Retourne {"user_id": ..., "email": ..., "created": bool}. L'ID attribué à un nouveau
    compte est NÉGATIF et garanti unique (compteur AUTOINCREMENT dédié) : il ne peut jamais
    entrer en collision avec un user_id Telegram (toujours positif)."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT user_id, email FROM web_accounts WHERE google_sub=?", (google_sub,)
        ) as cur:
            row = await cur.fetchone()
        if row:
            await db.execute(
                "UPDATE web_accounts SET last_login=?, email=COALESCE(NULLIF(?,''), email) WHERE google_sub=?",
                (now(), email, google_sub),
            )
            await db.commit()
            return {"user_id": row["user_id"], "email": row["email"] or email, "created": False}

        cur = await db.execute("INSERT INTO web_account_seq DEFAULT VALUES")
        new_user_id = -cur.lastrowid
        await db.execute(
            "INSERT INTO web_accounts (google_sub, user_id, email, created_at, last_login) VALUES (?,?,?,?,?)",
            (google_sub, new_user_id, email, now(), now()),
        )
        await db.commit()
        return {"user_id": new_user_id, "email": email, "created": True}


async def get_bank_account(user_id: int, bank_name: str = None) -> dict | None:
    async with db_read(row_factory=aiosqlite.Row) as db:
        if bank_name:
            async with db.execute(
                "SELECT * FROM bank_accounts WHERE user_id=? AND bank_name=?", (user_id, bank_name)
            ) as cur:
                row = await cur.fetchone()
        else:
            async with db.execute(
                "SELECT * FROM bank_accounts WHERE user_id=? ORDER BY balance DESC LIMIT 1", (user_id,)
            ) as cur:
                row = await cur.fetchone()
        return dict(row) if row else None


async def get_all_bank_accounts(user_id: int) -> list:
    async with db_read(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM bank_accounts WHERE user_id=?", (user_id,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_user_company(user_id: int) -> dict | None:
    async with db_read(row_factory=aiosqlite.Row) as db:
        async with db.execute("""
            SELECT c.*, cm.poste, cm.base_salary, cm.activity_score, cm.joined_at as member_since
            FROM company_members cm JOIN companies c ON c.company_id=cm.company_id
            WHERE cm.user_id=? AND c.dissolved=0
        """, (user_id,)) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None


async def get_company_by_name(name: str) -> dict | None:
    async with db_read(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM companies WHERE LOWER(name)=LOWER(?) AND dissolved=0", (name,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None


async def get_company_by_id(company_id: int) -> dict | None:
    async with db_read(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM companies WHERE company_id=?", (company_id,)) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None


async def get_all_companies(sector=None) -> list:
    async with db_read(row_factory=aiosqlite.Row) as db:
        if sector:
            async with db.execute(
                "SELECT * FROM companies WHERE dissolved=0 AND sector=? ORDER BY treasury DESC",
                (sector,)
            ) as cur:
                return [dict(r) for r in await cur.fetchall()]
        async with db.execute(
            "SELECT * FROM companies WHERE dissolved=0 ORDER BY treasury DESC"
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def log_company_action(company_id: int, action: str, actor_id: int, details: str = ""):
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO company_logs (company_id, action, actor_id, details, timestamp) VALUES (?,?,?,?,?)",
            (company_id, action, actor_id, details, now())
        )
        await db.commit()


async def get_skill(user_id: int, skill_name: str) -> int:
    async with db_connection() as db:
        async with db.execute(
            "SELECT level FROM skills WHERE user_id=? AND skill_name=?", (user_id, skill_name)
        ) as cur:
            row = await cur.fetchone()
        return row[0] if row else 0


async def upgrade_skill(user_id: int, skill_name: str):
    current = await get_skill(user_id, skill_name)
    async with db_connection() as db:
        await db.execute("""
            INSERT INTO skills (user_id, skill_name, level) VALUES (?,?,1)
            ON CONFLICT(user_id, skill_name) DO UPDATE SET level=level+1
        """, (user_id, skill_name))
        await db.commit()
    return current + 1


async def get_all_skills(user_id: int) -> dict:
    async with db_connection() as db:
        async with db.execute(
            "SELECT skill_name, level FROM skills WHERE user_id=?", (user_id,)
        ) as cur:
            rows = await cur.fetchall()
        return {r[0]: r[1] for r in rows}


async def get_properties(user_id: int) -> list:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM properties WHERE user_id=? ORDER BY prop_id", (user_id,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_vehicles(user_id: int) -> list:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM vehicles WHERE user_id=?", (user_id,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_portfolio(user_id: int) -> list:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM investments WHERE user_id=? AND quantity>0", (user_id,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_market_price(asset_name: str) -> float:
    async with db_connection() as db:
        async with db.execute(
            "SELECT price FROM market_prices WHERE asset_name=?", (asset_name,)
        ) as cur:
            row = await cur.fetchone()
        return row[0] if row else 0.0


async def update_market_price(asset_name: str, price: float):
    async with db_connection() as db:
        await db.execute(
            "UPDATE market_prices SET price=?, updated_at=? WHERE asset_name=?",
            (price, now(), asset_name)
        )
        await db.commit()


async def get_active_event() -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM world_events WHERE active=1 AND ends_at>? ORDER BY started_at DESC LIMIT 1",
            (now(),)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None


async def get_marriage(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM marriages WHERE user_id=? AND status='active'", (user_id,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None


async def get_inventory(user_id: int) -> list:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM inventory WHERE user_id=?", (user_id,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def add_notification(user_id: int, message: str):
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO notifications (user_id, title, message, created_at) VALUES (?, 'Notification', ?, ?)",
            (user_id, message, now())
        )
        await db.commit()


async def get_garden(user_id: int) -> list:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM garden WHERE user_id=?", (user_id,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def log_admin(admin_id: int, action: str, target_id: int, details: str = ""):
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO admin_logs (admin_id, action, target_id, details, timestamp, real_ts) VALUES (?,?,?,?,?,?)",
            (admin_id, action, target_id, details, now(), int(time.time()))
        )
        await db.commit()


# ═══════════════════════════════════════════════════════════════════════════
#        ⭐ NOUVELLES FONCTIONS — HIÉRARCHIE ADMIN (GAME FRENCH)
# ═══════════════════════════════════════════════════════════════════════════

async def get_active_admin_role(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM admin_roles "
            "WHERE user_id = ? AND revoked_at = 0 "
            "ORDER BY assigned_at DESC LIMIT 1",
            (user_id,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None


async def assign_admin_role(
    actor_id: int,
    target_id: int,
    role: str,
    notes: str = "",
) -> int:
    async with db_connection() as db:
        await db.execute(
            "UPDATE admin_roles SET revoked_at = ?, revoked_by = ? "
            "WHERE user_id = ? AND revoked_at = 0",
            (now(), actor_id, target_id)
        )
        cur = await db.execute(
            "INSERT INTO admin_roles "
            "(user_id, role, assigned_by, assigned_at, revoked_at, notes) "
            "VALUES (?, ?, ?, ?, 0, ?)",
            (target_id, role, actor_id, now(), notes)
        )
        await db.commit()
        return cur.lastrowid


async def revoke_admin_role(actor_id: int, target_id: int) -> str | None:
    role = await get_active_admin_role(target_id)
    if not role:
        return None
    async with db_connection() as db:
        await db.execute(
            "UPDATE admin_roles SET revoked_at = ?, revoked_by = ? "
            "WHERE user_id = ? AND revoked_at = 0",
            (now(), actor_id, target_id)
        )
        await db.commit()
    return role["role"]


async def list_admin_roles(include_revoked: bool = False) -> list:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        if include_revoked:
            query = """
                SELECT ar.*, u.full_name, u.username
                FROM admin_roles ar
                LEFT JOIN users u ON u.user_id = ar.user_id
                ORDER BY ar.assigned_at DESC
            """
        else:
            query = """
                SELECT ar.*, u.full_name, u.username
                FROM admin_roles ar
                LEFT JOIN users u ON u.user_id = ar.user_id
                WHERE ar.revoked_at = 0
                ORDER BY ar.role, ar.assigned_at DESC
            """
        async with db.execute(query) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_admin_role_history(user_id: int) -> list:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM admin_roles WHERE user_id = ? "
            "ORDER BY assigned_at DESC",
            (user_id,)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def log_admin_action(
    actor_id: int,
    action: str,
    target_id: int = 0,
    details: str = "",
):
    await log_admin(actor_id, action, target_id, details)


# ═══════════════════════════════════════════════════════════════════════════
#        ⭐ NOUVELLES FONCTIONS — TRANSACTIONS (paiements)
# ═══════════════════════════════════════════════════════════════════════════

async def get_transaction(reference_id: str) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM transaction_log WHERE reference_id = ?",
            (reference_id,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None


async def get_user_transactions(user_id: int, limit: int = 50) -> list:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM transaction_log WHERE user_id = ? "
            "ORDER BY timestamp DESC LIMIT ?",
            (user_id, limit)
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_all_transactions(
    start_ts: int = 0,
    end_ts: int = 0,
    transaction_type: str = None,
    limit: int = 100,
) -> list:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        query = "SELECT * FROM transaction_log WHERE 1=1"
        params = []
        if start_ts > 0:
            query += " AND timestamp >= ?"
            params.append(start_ts)
        if end_ts > 0:
            query += " AND timestamp <= ?"
            params.append(end_ts)
        if transaction_type:
            query += " AND transaction_type = ?"
            params.append(transaction_type)
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        async with db.execute(query, params) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_transaction_stats(start_ts: int = 0, end_ts: int = 0) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        query = """
            SELECT 
                COUNT(*) AS total_count,
                SUM(CASE WHEN amount < 0 THEN amount ELSE 0 END) AS total_spent,
                SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) AS total_gained,
                COUNT(DISTINCT user_id) AS unique_users
            FROM transaction_log
            WHERE 1=1
        """
        params = []
        if start_ts > 0:
            query += " AND timestamp >= ?"
            params.append(start_ts)
        if end_ts > 0:
            query += " AND timestamp <= ?"
            params.append(end_ts)
        async with db.execute(query, params) as cur:
            row = await cur.fetchone()
        return dict(row) if row else {}


# ═══════════════════════════════════════════════════════════════════════════
#                    FONCTIONS POUR LE SCHEDULER
# ═══════════════════════════════════════════════════════════════════════════

async def record_price_history():
    from config import ASSETS
    async with db_connection() as db:
        for asset in ASSETS:
            price = await get_market_price(asset["name"])
            await db.execute(
                "INSERT INTO price_history (asset_name, price, recorded_at) VALUES (?, ?, ?)",
                (asset["name"], price, now()),
            )
        await db.commit()


async def collect_rents():
    async with db_connection() as db:
        async with db.execute("""
            SELECT ra.id, ra.owner_id, ra.tenant_id, ra.rent, p.prop_id
            FROM rental_agreements ra
            JOIN properties p ON p.prop_id = ra.property_id
            WHERE ra.status = 'active'
        """) as cur:
            rentals = await cur.fetchall()
        for agreement_id, owner_id, tenant_id, rent, prop_id in rentals:
            async with db.execute("SELECT balance FROM users WHERE user_id=?", (tenant_id,)) as cur2:
                tenant_balance = (await cur2.fetchone())[0]
            if tenant_balance >= rent:
                await db.execute("UPDATE users SET balance = balance - ? WHERE user_id=?", (rent, tenant_id))
                await db.execute("UPDATE users SET balance = balance + ? WHERE user_id=?", (rent, owner_id))
            else:
                await db.execute(
                    "UPDATE rental_agreements SET status = 'expelled', end_date = ? WHERE id = ?",
                    (now(), agreement_id)
                )
                await db.execute("UPDATE properties SET rented_to = 0 WHERE prop_id = ?", (prop_id,))
                await add_notification(tenant_id, f"🏠 Tu as été expulsé du logement #{prop_id} (loyer impayé).")
                await add_notification(owner_id, f"🏠 Ton locataire a été expulsé du bien #{prop_id} (loyer impayé).")
        await db.commit()


async def degrade_vehicles():
    async with db_connection() as db:
        await db.execute("UPDATE vehicles SET condition = MAX(0, condition - 2)")
        await db.commit()


async def get_all_users_count() -> int:
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM users WHERE registered=1") as cur:
            return (await cur.fetchone())[0] or 0


async def migrate_vehicle_stats():
    from config import VEHICLES
    async with aiosqlite.connect(DB_PATH, timeout=DB_TIMEOUT) as db:
        cursor = await db.execute("PRAGMA table_info(vehicles)")
        columns = [row[1] for row in await cursor.fetchall()]

        for col in ["speed", "cargo", "luxury", "fuel"]:
            if col not in columns:
                try:
                    await db.execute(f"ALTER TABLE vehicles ADD COLUMN {col} INTEGER DEFAULT 0")
                    logger.info(f"✅ Colonne {col} ajoutée à vehicles")
                except aiosqlite.OperationalError:
                    swallowed('database.py')

        async with db.execute("SELECT veh_id, veh_type FROM vehicles") as cur:
            vehicles = await cur.fetchall()

        for veh_id, veh_type in vehicles:
            veh_data = VEHICLES.get(veh_type, {})
            if veh_data:
                await db.execute("""
                    UPDATE vehicles
                    SET speed = COALESCE(NULLIF(speed, 0), ?),
                        cargo = COALESCE(NULLIF(cargo, 0), ?),
                        luxury = COALESCE(NULLIF(luxury, 0), ?),
                        fuel = COALESCE(NULLIF(fuel, 0), ?)
                    WHERE veh_id = ?
                """, (
                    veh_data.get("speed", 0),
                    veh_data.get("cargo", 0),
                    veh_data.get("luxury", 0),
                    veh_data.get("fuel_capacity", 0),
                    veh_id
                ))

        await db.commit()
        if vehicles:
            logger.info(f"✅ {len(vehicles)} véhicules mis à jour avec leurs statistiques")


async def cleanup_old_admin_roles(days: int = 365):
    cutoff = now() - (days * 86400)
    async with db_connection() as db:
        await db.execute(
            "DELETE FROM admin_roles WHERE revoked_at > 0 AND revoked_at < ?",
            (cutoff,)
        )
        await db.commit()


# ═══════════════════════════════════════════════════════════════════════════
#                    EXPORTS
# ═══════════════════════════════════════════════════════════════════════════

__all__ = [
    # Base
    "now", "db_connection", "init_db", "run_migrations",
    # Argent atomique
    "debit_balance", "credit_balance", "transfer_money",
    # Users
    "get_user", "update_balance", "update_field", "increment_field",
    "add_life_journal", "get_life_journal",
    "get_top_rich", "get_all_users_count",
    "snapshot_user_core_stats", "record_user_stat_snapshot",
    # Banque
    "get_bank_account", "get_all_bank_accounts",
    # Entreprises
    "get_user_company", "get_company_by_name", "get_company_by_id",
    "get_all_companies", "log_company_action",
    # Skills
    "get_skill", "upgrade_skill", "get_all_skills",
    # Patrimoine
    "get_properties", "get_vehicles", "get_portfolio",
    # Marché
    "get_market_price", "update_market_price",
    "record_price_history",
    # Divers
    "get_active_event", "get_marriage", "get_inventory",
    "add_notification", "get_garden", "log_admin",
    "collect_rents", "degrade_vehicles",
    "migrate_vehicle_stats",
    # ⭐ Hiérarchie admin
    "get_active_admin_role",
    "assign_admin_role",
    "revoke_admin_role",
    "list_admin_roles",
    "get_admin_role_history",
    "log_admin_action",
    "cleanup_old_admin_roles",
    # ⭐ Transactions
    "get_transaction",
    "get_user_transactions",
    "get_all_transactions",
    "get_transaction_stats",
]
