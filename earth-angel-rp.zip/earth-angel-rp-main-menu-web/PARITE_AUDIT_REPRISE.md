# Audit de reprise — parité Bot / Mini App / Web

Date : 2026-11-10

## Résumé

L’archive contient un backend Python/FastAPI, un bot Telegram Python et deux interfaces statiques qui chargent les mêmes écrans JavaScript partagés. La Mini App (`/tg/`) et l’application Web (`/app/`) appellent la même API et la même base SQLite. Cette partie respecte déjà l’objectif de cohérence des interfaces.

Le principal écart restant est architectural : le bot exécute encore de nombreuses mutations dans ses handlers Telegram alors que plusieurs routeurs FastAPI reproduisent partiellement ces règles. Réutiliser une fonction isolée (`add_xp`, `cooldown_problem`, `eat_meal`, etc.) ne suffit pas à prouver que le coût, le tirage aléatoire, le cooldown, les restrictions, l’historique et les notifications sont identiques pour les trois clients.

## Constats vérifiés

- Identité Telegram : `initData` signé, ID Telegram positif.
- Identité Web : compte Google mappé vers un ID négatif, puis JWT commun.
- API Mini App/Web : dépendance `current_user_id`/`get_active_user_id`; l’identité n’est pas prise depuis un `user_id` librement envoyé par le navigateur pour les actions du joueur.
- Frontend : les deux clients chargent `webapp/static/shared/screens/*.js`.
- Persistance : bot et API utilisent la même base SQLite avec les mêmes tables métier.
- Modules déjà exposés par l’API : profil, travail, banque, marché, véhicules, voyages, santé/vie, missions, réseau social, famille, gangs, jardin et plusieurs autres.
- Syntaxe : `python3 -m compileall -q .` réussi; `node --check` réussi sur les scripts JavaScript inspectés.
- Tests : non exécutables dans l’environnement actuel, car `pytest` n’est pas installé.

## Risques de divergence

1. **Règles métier dupliquées dans les routeurs** : certains routeurs calculent directement coûts, récompenses et écritures SQL au lieu d’appeler une opération métier commune.
2. **Bot encore plus complet que l’API** : casino avancé, éducation, politique, arène, armes et plusieurs parcours entreprise/social ne sont pas tous accessibles aux deux interfaces.
3. **Transactions hétérogènes** : plusieurs opérations font plusieurs écritures successives; une erreur au milieu peut produire des conséquences différentes selon le point d’entrée.
4. **Cooldowns et horloge** : certaines fonctions utilisent le registre atomique `user_cooldowns`, d’autres des colonnes historiques; il faut une décision par action et la partager avec le bot.
5. **Notifications/historique** : l’API possède déjà une lecture commune, mais chaque nouvelle mutation doit publier les mêmes événements et journaliser les mêmes effets.
6. **Différences de plateforme** : les paiements Telegram Stars restent propres à Telegram; le Web doit rester bloqué ou disposer d’un paiement Web équitable, sans monnaie parallèle.

## Recommandation technique

Ne pas migrer maintenant le backend vers Node.js/React. Le dépôt fourni n’a ni `package.json`, ni frontend React, ni backend Node; une migration immédiate réécrirait les règles avant qu’elles soient centralisées. Étape recommandée :

1. créer une couche `gameplay/` Python indépendante de Telegram et FastAPI;
2. y déplacer une opération complète à la fois : préconditions, réservation de cooldown, coût, hasard, récompense, XP, journal, notifications et transaction;
3. faire appeler cette opération par le handler bot et par le routeur API;
4. ajouter un test contractuel exécuté avec le même état initial pour les trois adaptateurs;
5. seulement ensuite migrer éventuellement le frontend statique vers React, sans changer les contrats API;
6. ne considérer Node.js qu’après stabilisation des contrats et si une migration d’infrastructure est réellement nécessaire.

## Premier périmètre conseillé

Commencer par `travail`, car il existe dans le bot et l’API, il combine cooldown effectif/VIP, présence, coût d’énergie, salaire, XP, mission et promotion, et il représente bien le risque de divergence. Le même modèle pourra ensuite être appliqué à gym, crime, marché, jardin, famille/gangs puis casino avancé.

## État de la vague 1 — Travail

La vague 1 est implémentée dans `gameplay/work.py`. Le bot Telegram et le routeur API appellent désormais le même service pour préparer et résoudre une mission. Le service centralise le cooldown, la présence, le métier/diplôme, la grande commande, le gain de base, le score, le faucet staff, le gain, l’XP, l’énergie, la production de biens, la promotion et la notification différée.

Le mini-jeu Telegram conserve son interface interactive; il ne conserve plus la logique de mutation. L’application Web utilise un score aléatoire lorsque son interface ne présente pas le mini-jeu, mais passe par la même résolution et les mêmes multiplicateurs. Un adaptateur de compatibilité couvre les anciens callbacks Telegram encore présents dans des messages historiques.

Validation : `285 passed`, compilation Python réussie et vérification syntaxique JavaScript réussie. Les deux avertissements FastAPI concernent `on_event`, déjà utilisé ailleurs dans l’application.

## État de la vague 2 — Combat et quêtes

Le combat PvP est maintenant résolu par `gameplay/combat.py`, appelé par le handler Telegram et par les nouvelles routes `/api/arena`. Le moteur commun porte le calcul Force/Agilité/Endurance/niveau, les rounds, le settlement atomique, les victoires/défaites, l’XP, le loot, la progression `arena_win` et les notifications. Un écran `shared/screens/arena.js` est chargé par les deux clients.

La progression des quêtes continuait déjà à passer par `handlers.missions.update_mission_progress`. Le résumé Telegram/Web utilise maintenant `gameplay/missions.py` et lit `mission_log`, donc les montants réellement versés restent exacts même si les boosts du joueur changent après l’accomplissement.

Validation vague 2 : `287 passed`, compilation Python réussie et vérification syntaxique JavaScript réussie.

## État de la vague 3 — Inventaire, marché et objets

Les mutations du marché joueur et de l’inventaire sont centralisées dans `gameplay/market.py`. Le bot Telegram, ses callbacks, l’API Web et l’écran partagé Marché utilisent désormais les mêmes opérations pour mettre en vente, acheter, annuler une annonce et utiliser un consommable. Les contrôles de stock, les débits/crédits, le bonus cargo, les produits d’entreprise, les effets d’objet, la suppression d’inventaire et les journaux sont exécutés par ce service commun.

La boutique Stars Telegram reste volontairement séparée : elle dépend du paiement XTR Telegram et l’achat Web est explicitement bloqué tant qu’aucun moyen de paiement Web n’est configuré. Elle partage néanmoins déjà son catalogue et sa logique de livraison via `utils/shop.py`.

Validation finale vague 3 : `289 passed`, compilation Python réussie et vérification syntaxique JavaScript réussie. Les deux avertissements restent les avertissements FastAPI existants concernant `on_event`.

## État de la vague 4 — Classements, guildes et parrainage

Les classements Web utilisent maintenant `utils/rankings.py`, le même registre et le même calcul de rang que Telegram. L’API expose le menu complet, chaque classement paginé et conserve la compatibilité de l’ancien endpoint `/api/rankings/rich`.

Les mutations de guilde sont centralisées dans `gameplay/gangs.py` : création, candidature, départ/dissolution, dépôt, retrait et amélioration. Les contrôles de rôle, de solde, de caisse et de concurrence sont exécutés dans ce service par le bot et l’API Web.

Le parrainage est centralisé dans `gameplay/referrals.py`. Le bot et l’API partagent l’enregistrement d’un token, les récompenses d’arrivée, l’activation niveau 3 / 25 000 €A, les SocialCoins, les journaux et les notifications. L’écran partagé Parrainage est chargé par la Mini App Telegram et l’application Web.

Validation finale vague 4 : `291 passed`, compilation Python réussie et vérification syntaxique JavaScript réussie. Les deux avertissements restent les avertissements FastAPI existants concernant `on_event`.

## Complément vague 4 — Actions avancées des guildes

`gameplay/gangs.py` centralise également le changement de rôle, l’exclusion d’un membre et le transfert du poste de chef. Les contrôles de hiérarchie sont identiques dans Telegram et Web : seuls le Chef et le Bras droit gèrent les rangs inférieurs, un membre ne peut pas se gérer lui-même, et seul le Chef peut transférer la direction. Chaque mutation est transactionnelle et produit une notification au membre concerné.

L’API expose `/api/gangs/role`, `/api/gangs/exclude` et `/api/gangs/transfer`. L’écran partagé des guildes affiche les membres et les actions de gestion selon le rôle courant.

Validation du complément : `292 passed`, compilation Python réussie et vérification syntaxique JavaScript réussie.

## Vague suivante — Crime & sécurité liés aux guildes

Les actions restantes liées aux gangs sont désormais communes au bot et au Web : dissolution avec remboursement de la trésorerie, hold-up avec calcul de chance/récompense/réputation et maintenance des caisses. L’API expose `/api/gangs/dissolve` et `/api/gangs/hold-up`; l’écran partagé propose les boutons correspondants au Chef et aux membres.

Validation : `293 passed`, compilation Python réussie et vérification syntaxique JavaScript réussie. Les deux avertissements restent les avertissements FastAPI existants concernant `on_event`.

## Critère de fin d’un module

Un module n’est fermé que lorsque :

- le bot, `/tg/` et `/app/` appellent le même service métier;
- les restrictions sont identiques;
- le coût est débité une seule fois et dans la même transaction;
- le cooldown est réservé et libéré selon le même protocole;
- le tirage et la récompense sont produits par le même code;
- XP, argent, inventaire, statistiques et historique sont identiques;
- les notifications/outbox sont identiques;
- les tests couvrent succès, refus, cooldown, fonds insuffisants et erreur transactionnelle.

## Complément — Sondages sociaux

`gameplay/social_polls.py` devient la source de vérité pour créer, lister, voter et clôturer les sondages. Le bot Telegram, ses commandes de compatibilité et les routes FastAPI partagent la limite de trois créations par jour de jeu, la durée de deux jours de jeu, la portée publique ou communautaire, la règle d’un vote par joueur, la récompense de +1 SocialCoin, les notifications de jalon et les droits de clôture. Les routes `/api/reseau/polls` servent la Mini App et l’application Web, qui chargent le nouvel onglet Sondages du script partagé `shared/screens/social.js`.

Validation sondages : 297 tests passent sur l’état antérieur; validation de cette vague ci-dessous.

## Complément — Commentaires et collaborations

`gameplay/social_comments.py` porte maintenant l’écriture et la lecture des commentaires. Les routes `/api/reseau/posts/{post_id}/comments` et le flow Telegram utilisent les mêmes limites de 200 caractères et 3 commentaires par joueur/post, incrément du compteur et notification de l’auteur. La sélection des 8 plus récents correspond à Telegram; la vérification du quota est transactionnelle et couverte sous concurrence.

`gameplay/social_collabs.py` centralise l’état, les demandes, leur réponse et les effets communs. Le bot et `/api/reseau/collabs` partagent les types live/giveaway/cross, le débit historique de 50 000 €A à l’acceptation, la durée de 24 heures de jeu et +100 abonnés pour chaque participant. Les IDs Web négatifs sont résolus comme cibles; le service s’assure que seule la cible répond. Les notifications Web sont ajoutées à l’inbox; les DM Telegram conservent leurs boutons et sont émis par l’adaptateur du bot.

Les demandes en attente peuvent toujours coexister, mais l’acceptation revalide maintenant, sous `BEGIN IMMEDIATE`, le compte et le solde du proposant ainsi que l’absence de collaboration active pour les deux participants. Si l’une de ces conditions a changé, l’acceptation est refusée sans débit, récompense ni activation, et la demande reste en attente. Cette règle est appliquée par le service partagé aux adaptateurs Telegram et API; les demandes n’ont toujours pas de cooldown ni d’expiration, comme dans le bot.

Validation de reprise : 306 tests passent, dont deux nouveaux tests couvrant le solde devenu insuffisant et le participant déjà engagé; compilation Python et vérification syntaxique de tous les scripts JavaScript réussissent. Les deux seuls avertissements restent les avertissements FastAPI existants sur `on_event`.

## Complément — Adoption familiale

`gameplay/family.py` centralise désormais l’adoption, appelée par `handlers/family.py` et `/api/family/adopt`. Les critères bot/API sont communs : parent âgé d’au moins 25 ans, enfant de moins de 20 ans, enfant inscrit et non déjà adopté, maximum de cinq enfants et coût de 50 000 €A. Relation, débit, `total_spent`, comptabilisation au Trésor et snapshot des statistiques sont écrits dans une transaction unique. La Mini App et le Web chargent l’écran partagé de l’arbre familial. Les tests couvrent la parité des deux adaptateurs, les refus, les doublons concurrents et le plafond. Validation de la reprise complète : 309 tests passent; compilation Python et syntaxe JS réussissent.

Le même service centralise maintenant le transfert du leadership et la dissolution : seul le fondateur peut agir, la cible du transfert doit être membre, les deux identités de rôle sont mises à jour ensemble et la dissolution supprime membres/invitations/clan de manière transactionnelle. Telegram conserve sa commande de confirmation; les clients Web/Mini App ont une confirmation UI avant l’appel API. Les tests exercent les adaptateurs Telegram et API, les refus d’autorisation et l’absence d’effet avant confirmation.

## Complément — Personnel judiciaire (juge / avocat)

Le volet détenu de la Justice était déjà fermé (dossier, audience, caution, avocat). Il manquait le
côté personnel : `utils/justice.py` portait déjà `judge_check`, `lawyer_check`, `list_files`,
`set_bail`, `judge_file`, `issue_warrant` et `plead` — un service pur, déjà partagé par
`handlers/justice.py`, mais non exposé par l'API. `webapp/routers/crime_router.py` ajoute
`/api/justice/staff`, `/api/justice/cases`, `/api/justice/my-clients`, `/api/justice/set-bail`,
`/api/justice/verdict`, `/api/justice/warrant` et `/api/justice/plead`, qui appellent ce même
service sans recalculer de règle : mêmes contrôles de poste/service, mêmes plafonds
(`config.JUSTICE` : caution max, amende max, peine max), même transaction, mêmes notifications.

L'écran partagé `shared/screens/crime.js` affiche désormais, sous la liste des crimes ou l'état de
prison du joueur, un panneau réservé au personnel en service : liste des dossiers ouverts et
mandat d'arrêt pour le juge, liste des clients et plaidoirie pour l'avocat. Un joueur qui n'est ni
juge ni avocat en service ne voit aucune différence. `/tg/` et `/app/` chargent le même script, donc
les deux clients ont exactement les mêmes outils.

Reste ouvert : les signalements (`handlers/reporting.py`) sont un module distinct, non couvert par
cette reprise, et le recours en appel d'un verdict n'existe pas côté bot non plus.

`test/test_justice_api.py` couvre les sept nouvelles routes : enregistrement des chemins sur l'API
partagée, délégation exacte vers `utils/justice.py` (arguments reçus par `assert_awaited_once_with`),
caution à 0 (refus explicite, distinct de l'absence de valeur), verdict invalide rejeté avant tout
appel au service, motif de mandat vide rejeté et motif tronqué à 80 caractères, et refus HTTP 403
quand `judge_check`/`lawyer_check` renvoient une erreur (poste absent ou hors service).

## Complément — Casino avancé : transactions regroupées et reprise des parties interrompues

Trois lacunes étaient explicitement listées dans `TODO.md` : Roulette/PMU ne reproduisaient pas
les étapes intermédiaires du bot (mise puis résolution), les effets économiques n'étaient pas
regroupés dans une seule transaction, et une action restée en statut `processing` après un
redémarrage serveur n'avait aucune reprise explicite.

`gameplay/casino_sessions.py` gagne trois fonctions : `create_session_with_stake` (débite la
mise et crée la session dans UNE transaction `BEGIN IMMEDIATE`/`COMMIT`), `save_claimed_session_with_payout`
(enregistre l'état final ET crédite le gain dans la même transaction que la transition CAS
`processing` → état final) et `recover_stuck_session` (relâche automatiquement, après
`PROCESSING_STALE_SECONDS`, une réservation `processing` restée bloquée — sans risque, puisqu'aucun
effet économique n'a encore eu lieu à ce stade des deux fonctions précédentes). `get_session`
appelle désormais systématiquement `recover_stuck_session`, ce qui bénéficie à Blackjack, Mines
et Crash sans aucune modification de leur logique de jeu.

Roulette et PMU rejoignent `casino_game_sessions` : `gameplay/casino.py` expose `resolve_roulette`
et `resolve_pmu`, des fonctions pures (aucun appel base de données) réutilisées à la fois par
`settle_roulette`/`settle_pmu` (bot, mise déjà débitée en mémoire, inchangés) et par
`webapp/routers/casino_router.py` (API), où la mise est débitée via
`create_session_with_stake` et le gain crédité via `save_claimed_session_with_payout`. Une mise
déjà prélevée mais non réglée (`find_resumable_session`) est reprise au lieu d'être débitée une
seconde fois; une session déjà réglée (statut final) n'est jamais reprise. `start_mines` et
`start_crash` utilisent aussi `create_session_with_stake` pour le même bénéfice.

Reste ouvert : les parcours Telegram Mines/Crash restent en mémoire (RAM), non persistés — hors
périmètre, le bot devenant une porte d'entrée (`VISION_V10_GATEWAY_ET_UX.md`); le début de partie
Blackjack (`blackjack_start`, partagé avec le bot) reste un débit puis une création de session en
deux opérations séparées, pour ne pas changer son comportement côté bot.

`test/test_casino_parity.py` couvre : les fonctions pures `resolve_roulette`/`resolve_pmu`;
l'atomicité d'un refus pour fonds insuffisants (aucune mutation, ni débit ni session fantôme);
le crédit unique d'un gain et le refus d'un rejeu à révision périmée; la reprise d'une session
bloquée en `processing` sans perte ni double prélèvement de la mise; la reprise d'une mise
Roulette déjà débitée plutôt qu'un second débit, avec non-reprise d'une session déjà réglée; et
PMU de bout en bout via l'API avec débit + crédit regroupés.

## Complément — Politique : destitution et mandat présidentiel

`utils/politics.py` était déjà un service pur (quorum, majorité selon le poste visé, immunité
après prise de fonctions, cooldown après une motion échouée, clôture et application du résultat)
séparé des commandes Telegram, comme `utils/justice.py` pour la Justice — mais rien n'était
exposé côté Mini App/Web.

`webapp/routers/political_router.py` ajoute `/api/political/status`, `/api/political/motions`,
`/api/political/motion` (lance une motion après revalidation par `check_motion`, qui ne produit
aucun effet de bord avant la création), `/api/political/motion/sign` et `/api/political/motion/vote`,
qui appellent tous `utils/politics.py` sans recalculer de règle. L'écran partagé `political.js`
(onglet Social) affiche le poste occupé, le mandat présidentiel restant, le journal officiel et
les motions en cours, avec les mêmes actions (signer, voter) que le bot.

Reste ouvert : contrairement à la destitution, les élections (candidature, vote, dépouillement),
les lois, les référendums et les nominations ministérielles ne sont pas extraits dans un service
pur — `handlers/political.py` (1 294 lignes) les porte directement, mêlés à la présentation
Telegram. Les exposer côté Mini App/Web demandera d'abord cette extraction, une reprise à part
entière plutôt qu'un ajout de routes.

`test/test_political_webapp.py` couvre : projection du statut (poste, mandat seulement pour un
Président, journal), aucun mandat pour un ministre ou un joueur ordinaire, délégation exacte vers
`utils/politics.py` pour lancer/signer/voter une motion (arguments vérifiés par
`assert_awaited_once_with`), refus avant toute création quand `check_motion` échoue, et
l'enregistrement des cinq routes sur l'API partagée.

## Complément — Phases de voyage persistées (trajet / repos)

`webapp/routers/travel_router.py::status()` devinait la phase de voyage courante (trajet ou
repos) en relisant la dernière ligne de `travel_log` et en vérifiant qu'une durée dérivée
(`travel_until - started - TRAVEL_COOLDOWN`) tombait dans une plage plausible (`0 < duration <=
10800`). C'était une heuristique, pas une donnée : un cas limite (plusieurs lignes la même
seconde, `travel_until` modifié par un autre mécanisme) pouvait associer le mauvais voyage ou n'en
trouver aucun sans que ce soit détectable.

Migration 34 ajoute deux colonnes à `travel_log` : `arrival_at` (fin du trajet) et `travel_until`
(fin du repos, identique à `users.travel_until` au moment du départ). `handlers/travel.py` (bot,
ses deux points d'entrée commande/callback) et `webapp/routers/travel_router.py::go` (API)
calculent désormais un seul `now()` partagé entre l'écriture de `users.travel_until` et celle du
journal — élimine aussi une dérive possible d'une poignée de secondes entre deux appels `now()`
séparés qui existait déjà avant cette reprise, dans le bot comme dans l'API. `status()` retrouve
la ligne par égalité exacte (`WHERE travel_until=?`) au lieu d'une plage plausible; sans
correspondance (voyage lancé avant la migration), aucun détail de phase n'est affiché plutôt que
d'inventer une destination.

Reste ouvert : un voyage en cours au moment du déploiement de cette migration n'aura pas de
détail de phase tant qu'il n'est pas terminé (donnée absente, pas erronée) — comportement attendu
pour toute colonne ajoutée a posteriori.

`test/test_vehicles_travel_webapp.py` couvre : la lecture par égalité exacte sur `travel_until`
(avec vérification de la requête SQL elle-même); l'absence de correspondance (aucune destination
inventée); et un aller-retour complet `go()` → `status()` sur une vraie base migrée (fixture
`persistent_travel_db`), confirmant que la valeur persistée par le départ est bien celle relue
par le statut.

## Complément — Récolte groupée du jardin

`gameplay/garden.py` porte maintenant la récolte de toutes les parcelles mûres; la commande Telegram, le callback du menu jardin et `POST /api/garden/harvest/all` utilisent le même calcul. Sont communs : bonus d’arrosage/saison, confisqués illégaux et mise en prison, argent, XP, intrant d’entreprise et progression de mission. L’écran partagé Mini App/Web affiche le nombre de parcelles mûres et une action Tout récolter. La tâche `garden_maintenance` du scheduler retire les plantes mortes et ajoute une notification persistée, regroupée par joueur, dans la même transaction. Les tests ciblés couvrent parité, parcelles immatures, arrestation et maintenance idempotente.

## Complément — Entreprises : catalogue de produits

Contrairement à Justice, Ordre ou la destitution/mandat de Politique, les entreprises n'avaient
aucun service pur séparé de Telegram : `handlers/company_products.py` et
`handlers/company_shares.py` portaient leurs requêtes SQL et leurs règles (formule de valeur de
part, plafonds, preuve de propriété) directement dans les fonctions de commande, mêlées aux
appels `update.message.reply_text`. Exposer ces règles à l'API sans les dupliquer exigeait donc
une extraction, pas seulement un nouveau routeur.

Cette reprise extrait uniquement le catalogue de produits dans `gameplay/companies.py` :
`list_products` (catalogue + stock de l'appelant), `set_product_price`, `delete_product` et
`withdraw_product`, avec exactement les mêmes requêtes et le même ordre de vérifications que les
anciennes commandes `/produits`, `/setprix`, `/supprimer_produit` et `/retirer_produit`.
`handlers/company_products.py` délègue maintenant à ce service au lieu de recalculer les règles;
les textes et l'ordre des contrôles d'accès Telegram (owner strict pour la lecture, créateur ou
gérant pour les mutations) restent inchangés. `webapp/routers/companies_router.py` ajoute
`GET /api/companies/products`, `POST /api/companies/products/price`, `/products/delete` et
`/products/withdraw`, avec les mêmes contrôles d'accès via `utils/company_roles.can_manage`;
l'écran partagé `companies.js` affiche désormais, pour le PDG propriétaire, le catalogue avec
prix modifiable et suppression.

Reste ouvert, et volontairement non traité dans cette reprise :
- ~~Personnalisation de produit~~ — supprimée (décision produit : les produits ne se créent que
  par le travail des employés avec les matériaux ; `/renommer_produit`, `/emoji_produit`,
  `/desc_produit` et `_edit_own_product` retirés du bot).
- ~~Transfert de PDG~~ — livré (voir ci-dessous).

`test/test_companies_products.py` couvre le service pur sur une vraie base migrée (lecture du
stock par appelant propriétaire vs. tiers, mise à jour du prix dans les deux tables, suppression
des trois tables liées, retrait d'inventaire et refus si quantité insuffisante ou nulle) ainsi
que la délégation et les contrôles d'accès du routeur (403 pour un non-PDG en lecture, pour un
non-gérant en écriture; 404/422 relayés depuis le service; enregistrement des routes).

## Complément — Entreprises : parts, capital et dividendes

Comme pour les produits, `handlers/company_shares.py` mêlait directement ses requêtes SQL et ses
règles (formule de valeur de part, plafonds, preuve de propriété) aux appels
`update.message.reply_text`, sans service pur séparable. Au-delà de la simple extraction, deux
de ses commandes avaient une vraie faiblesse transactionnelle : `cmd_vendreparts` décrémentait
les parts du vendeur dans un bloc de connexion, puis créditait son solde avec `update_balance`
dans un second bloc entièrement séparé ; `cmd_dividendes` créditait chaque actionnaire un par un
avec `update_balance` (un commit par actionnaire), puis débitait la trésorerie de l'entreprise
dans un troisième bloc séparé. Dans les deux cas, un redémarrage serveur entre ces écritures
pouvait créditer un joueur sans l'effet correspondant sur les parts ou la trésorerie, ou
l'inverse — la même classe de bug que celle corrigée pour le Casino plus tôt dans cette reprise.

`gameplay/companies.py` ajoute `share_price` (formule plafonnée à `MAX_SHARE_PRICE`, identique
à celle de `cmd_parts`), `shareholders`, puis `buy_shares`, `sell_shares` et
`distribute_dividends`, chacune en SQL brut sous une seule transaction `BEGIN IMMEDIATE`/commit
(même convention que `gameplay/casino_sessions.py` et `webapp/routers/companies_router.py::create_company`) :
plus aucune de ces trois opérations ne peut laisser l'argent désynchronisé des parts ou de la
trésorerie, quel que soit le moment d'un redémarrage. `handlers/company_shares.py` délègue
désormais à ce service ; les textes et l'ordre des vérifications (nombre invalide, parts
insuffisantes, plafonnement du prix, coût total excessif, fonds insuffisants) restent identiques
à l'implémentation d'origine. `webapp/routers/companies_router.py` ajoute `GET
/api/companies/shares` (valorisation + liste des actionnaires), `POST /shares/buy`,
`/shares/sell` et `POST /dividends` (PDG uniquement) ; l'écran `companies.js` affiche cette
valorisation pour tout membre, avec les actions acheter/vendre, et le bouton dividendes pour le
PDG.

Scope volontairement réduit à sa propre entreprise : contrairement au bot, qui permet de cibler
une entreprise tierce par son nom (`/acheterparts "Nom" N`), l'API n'expose que l'achat/vente de
parts de l'entreprise dont l'appelant est déjà membre — le cas d'usage courant côté Mini
App/Web (l'écran affiche sa propre entreprise) ; le ciblage par nom reste disponible sur le bot
et n'est pas perdu.

`test/test_companies_shares.py` couvre la formule de prix et son plafond ; sur une vraie base
migrée : achat et vente atomiques avec vérification des soldes réels (`users.balance`,
`companies.treasury`, `company_shares`), suppression de la ligne de parts en cas de vente
totale, refus (fonds insuffisants, parts insuffisantes, pas actionnaire) sans aucune mutation,
dividendes répartis au prorata avec débit de trésorerie unique, refus si trésorerie trop faible
ou aucune part en circulation ; ainsi que la délégation et les contrôles d'accès du routeur
(403 pour un non-PDG sur les dividendes, messages d'erreur relayés depuis le service,
enregistrement des routes).

## Complément — Entreprises : contrats inter-entreprises

Dernière brique de `handlers/company_deals.py` extraite cette reprise : les contrats (proposer,
répondre, négocier). Les fusions (`cmd_proposer_fusion`/`cmd_repondre_fusion`), dans le même
fichier, restent volontairement sur le bot — elles n'étaient pas nommées dans le TODO d'origine
(« produits, contrats, parts et dividendes ») et touchent à un périmètre plus large (absorption
d'une entreprise entière, transfert d'employés et de parts) que je préfère traiter dans une
reprise dédiée plutôt que d'élargir celle-ci.

`gameplay/companies.py` ajoute `list_contracts`, `propose_contract`, `respond_contract` et
`negotiate_contract`, extraits de `cmd_proposer_contrat`/`cmd_repondre_contrat`/
`cmd_negocier_contrat`. Chacune garde exactement le même ordre de vérifications et les mêmes
transferts que l'implémentation d'origine (celle-ci écrivait déjà ses mutations dans un seul
bloc de connexion par commande, donc pas de faiblesse transactionnelle à corriger ici,
contrairement aux parts). En revanche, l'extraction a mis au jour un vrai bug fonctionnel dans
les notifications : `cmd_repondre_contrat` (branche refus) et `cmd_negocier_contrat` appelaient
`add_notification(contract["from_company"], ...)` — `from_company` est un `company_id`, pas un
`user_id`, alors que `add_notification` attend un `user_id`. Le PDG émetteur ne recevait donc
jamais la notification de refus ou de contre-offre (la ligne était insérée en base avec un
mauvais destinataire, sans erreur visible). Les nouvelles fonctions notifient
`from_comp["owner_id"]` — le test `test_respond_contract_refuse_notifies_the_proposing_owner_not_the_company_id`
vérifie explicitement que la notification atteint le bon joueur et qu'elle n'est plus écrite
sous l'ancien (mauvais) destinataire.

`handlers/company_deals.py` délègue désormais à ce service pour les trois commandes contrat ;
les textes de réponse Telegram restent identiques. `webapp/routers/companies_router.py` ajoute
`GET /api/companies/contracts` (contrats en attente/négociation de sa propre entreprise),
`POST /contracts/propose` (PDG uniquement), `/contracts/respond` et `/contracts/negotiate` ;
l'écran `companies.js` liste les contrats (sens de la flèche, montant, durée, type, statut) avec
accepter/refuser/négocier pour ceux reçus, et un formulaire de proposition avec sélection de la
cible dans le marché des entreprises.

`test/test_companies_contracts.py` couvre, sur une vraie base migrée : insertion et notification
à la proposition, refus d'un second contrat en attente entre les deux mêmes entreprises, refus
si la cible est dissoute ou si les arguments sont invalides ; acceptation avec transfert de
trésorerie et bonus de réputation vérifiés en base, annulation sans aucune mutation si la
trésorerie émettrice est insuffisante, refus « déjà traité » après une première réponse ;
négociation avec mise à jour des termes et notification ; ainsi que la délégation et les
contrôles d'accès du routeur (403 pour un non-PDG qui propose ou qui négocie à la place du bon
PDG, 422 avec le message relayé depuis le service, enregistrement des routes).

## Complément — Entreprises : fusions

Les fusions, laissées sur le bot à l'étape précédente, sont extraites à leur tour dans
`gameplay/companies.py` (`fusion_valuation`, `list_fusions`, `propose_fusion`, `respond_fusion`) ;
`handlers/company_deals.py` n'a plus aucune requête SQL propre et délègue pour les fusions comme
pour les contrats. L'API ajoute `GET /api/companies/fusions`, `POST /fusions/propose` et
`/fusions/respond` (PDG uniquement, l'entreprise cible étant celle de l'appelant), et `companies.js`
un panneau Fusions (demandes envoyées/reçues, accepter/refuser, proposer).

Deux bugs de l'implémentation d'origine sont corrigés à l'extraction : (1) à l'acceptation,
`UPDATE company_shares SET company_id=<émettrice> WHERE company_id=<cible>` violait la clé primaire
(user_id, company_id) dès qu'un même joueur détenait des parts des deux entreprises — la fusion
échouait en erreur ; les parts sont désormais additionnées puis les lignes de la cible supprimées,
dans une seule transaction `BEGIN IMMEDIATE` avec le paiement de la valorisation, le transfert des
employés et la dissolution ; (2) la notification de refus visait `req["from_company"]` (un
`company_id`) au lieu de l'`owner_id` du PDG émetteur.

`test/test_companies_fusions.py` : proposition et refus (même entreprise, introuvable, dissoute,
déjà en attente), acceptation avec fusion de parts chevauchantes vérifiée en base, refus avec
notification au bon destinataire, trésorerie insuffisante sans mutation, accès non-PDG/sans demande,
délégation et contrôles du routeur. Reste ouvert côté Entreprises : transfert de PDG, embauche/salaires/R&D (hors périmètre du TODO d'origine).

## Complément — Entreprises : transfert de PDG

`cmd_transfert_entreprise` délègue à `gameplay/companies.transfer_ownership` : changement de
`owner_id` et des deux postes (« Ex-PDG » / « PDG ») sous une seule transaction, refus sans
mutation (même joueur, cible non employée, appelant non PDG), entrée `transfert_pdg` dans le
journal de l'entreprise. L'API ajoute `POST /api/companies/transfer`, l'écran un bloc « Direction ».
Tests : `test/test_companies_transfer.py`. Le périmètre Entreprises du TODO d'origine (produits,
contrats, parts, dividendes) est clos, avec en plus fusions et transfert ; restent hors périmètre
embauche, salaires et R&D.

## Complément — Politique : élections

Extraction de `gameplay/elections.py` depuis `handlers/political.py` (lancement, candidature, vote,
dépouillement). Le bot et l'API (`/api/political/elections*`, bloc « Élections » de `political.js`)
appellent la même logique ; `auto_depouiller` n'est plus qu'un wrapper conservé pour la maintenance
et les tests existants. Correctifs au passage : débit du coût et création de l'élection dans une
seule transaction ; attribution du poste, prestige et clôture dans une seule transaction.
Tests : `test/test_elections_service.py` (pytest non exécuté dans le bac à sable sans réseau).
Restent ouverts : lois, référendums, nominations/révocations de ministres, constitution.

## Complément — Politique : lois, référendums, constitution

`gameplay/laws.py` remplace la logique qui vivait dans `handlers/political.py` (proposition, vote,
clôture automatique, référendum constitutionnel). Correctifs : coût débité et ligne créée dans la
même transaction ; vote et compteur incrémentés ensemble. API et écran `political.js` ajoutés.
Tests : `test/test_laws_service.py` (pytest non exécuté dans le bac à sable). Reste ouvert :
nominations/révocations de ministres.

## Complément — Politique : gouvernement

`gameplay/cabinet.py` (liste, nomination, révocation) enveloppe `install_minister`/`remove_minister`
(`utils/roles.py`) avec les contrôles, la notification et le journal, une seule fois pour le bot et
l'API (`/api/political/government*`, bloc « Gouvernement »). Tests : `test/test_cabinet_service.py`
(pytest non exécuté dans le bac à sable). Politique : élections, lois, référendums, constitution,
destitution et gouvernement sont tous partagés ; les partis politiques n'ont aucune logique côté bot (tables seules) : rien à porter.

## Complément — Études : historique des examens

Migration 35 (table `exam_history`), écriture dans `gameplay/education.finalize_exam` (une ligne par examen
corrigé, réussite ou échec), lecture `exam_history()`, route `GET /api/education/exam/history`, liste dans
l'onglet Examen de `education.js`. Seuls les examens corrigés après cette migration apparaissent (pas de
reconstitution du passé). Tests : `test/test_exam_history.py`. La reprise d'examen reste sans test dédié.

## Complément — Signalements

`gameplay/reports.py` porte types, statuts, règles (longueur, cooldown, cible) et traitement staff ;
`handlers/reporting.py` ne garde que les écrans Telegram et ré-exporte les noms existants. API
`/api/reports*`, écran `reports.js`. Trouvé en chemin : `political.js` (livré aux passes précédentes)
n'était pas listé dans `SCREENS` de `core.js` et ne se chargeait donc pas ; corrigé. Tests :
`test/test_reports_service.py` (pytest non exécuté dans le bac à sable).

## Complément — Entreprises : parts d'une entreprise tierce

`company_name` optionnel sur `/api/companies/shares/buy|sell` (même règle que le bot : nom ⇒ entreprise
active de ce nom, sinon celle de l'appelant ; 404 si introuvable) et `GET /shares/quote`. Le service
atomique est inchangé. Écran : boutons 📈/📉 par entreprise du marché. Tests ajoutés à
`test/test_companies_shares.py` (pytest non exécuté dans le bac à sable).

## Complément — Entreprises : équipe, recrutement, salaires

`gameplay/hiring.py` porte candidature, recrutement (acceptation directe ou contre-offre), démission,
salaire/promotion et licenciement ; `handlers/companies.py` ne garde que les messages Telegram. API
`/api/companies/team|applications|apply|…|fire`, écran « Équipe » dans `companies.js`. Trois corrections
de comportement au passage (candidat déjà employé, licenciement atomique, cible hors entreprise).
Tests : `test/test_companies_hiring.py` (pytest non exécuté dans le bac à sable). Non couverts :
R&D, prime, formation, invitations, annonces, trésorerie, renommage, changement de secteur.


## Lot du 21/11
Personnage simplifié, exclusion du staff N2+, bot qui reste dans les groupes non autorisés, nomination PDG/DG par mention. Tests écrits (test_staff_scope, test_character_groups) mais non exécutés (pytest indisponible dans le bac à sable).

Résolution des cibles : ID d'abord puis @pseudo via `utils/user_lookup.py` ; test_user_lookup.py écrit, non exécuté.
