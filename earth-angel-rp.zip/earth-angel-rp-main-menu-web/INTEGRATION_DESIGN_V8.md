# Intégration du design Earth Angel RP — v9

## Architecture conservée

Le serveur FastAPI reste unique. `/app/` et `/tg/` continuent de consommer `/api/*`, tandis que `webapp/static/shared/` porte le noyau, les styles et les écrans communs.

## Modifications

- `webapp/static/shared/screens/home.js` : nouvel accueil responsive avec hero, état du personnage, raccourcis, profil, statistiques, karma et fil d’activité. Les données viennent toujours de `/profile`, `/work/status` et `/phone/home`.
- `webapp/static/shared/style.css` : tokens et composants du design validé, responsive mobile/desktop, sidebar desktop et navigation basse.
- `webapp/static/shared/core.js` : sidebar desktop générée à partir des mêmes onglets que la navigation mobile ; aucun doublon de logique métier.
- `webapp/static/shared/core.js` : bouton sonore partagé, désactivé par défaut, mémorisé localement et activé uniquement après une action utilisateur.
- `webapp/static/shared/style.css` : état actif du bouton sonore, micro-animation et respect de `prefers-reduced-motion`.
- `webapp/static/shared/core.js` : hubs de navigation pour Économie, Ville et Social, avec écran métier dédié et bouton Retour.
- `webapp/static/shared/style.css` : cartes de hub, hiérarchie d’écran et animation 3D légère du logo officiel.
- `webapp/static/web/index.html` et `webapp/static/telegram/index.html` : version d’assets v9.
- `webapp/server.py` : `frontend_version` alignée sur v9.

## Contrats préservés

- Authentification Google côté web.
- Authentification `Telegram.WebApp.initData` côté Mini App.
- Même token API, mêmes routes et mêmes écrans partagés.
- Aucun coût, gain, cooldown, transaction ou règle de jeu exécuté côté client.
- Les sons sont générés localement via Web Audio ; aucun son automatique et aucun appel serveur supplémentaire.

## Vérifications

- Syntaxe JavaScript validée avec `node --check` pour `core.js` et `home.js`.
- Compilation Python du module serveur validée.
- Assets critiques présents : `banner.jpg`, `icon.png`, shells web et Telegram.
- Les tests `pytest` n’ont pas pu être lancés dans l’environnement courant car la commande `pytest` n’est pas installée.
