import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")

# ── Mini App Telegram + Application Web (webapp/) ─────────────────────────
# JWT de session émis par l'API pour la mini app ET le site web (même secret, même format
# de jeton des deux côtés : c'est ce qui permet aux deux interfaces de parler à la même API).
JWT_SECRET = os.getenv("JWT_SECRET", "")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_DAYS = int(os.getenv("JWT_EXPIRE_DAYS", "30"))

# Connexion Google (site web uniquement — la mini app s'authentifie via Telegram initData).
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET", "")

# URL publique de l'API (derrière le reverse proxy, ex: https://game.mondomaine.com/api) :
# sert de redirect_uri pour Google et de base pour les liens de la mini app Telegram.
PUBLIC_API_BASE_URL = os.getenv("PUBLIC_API_BASE_URL", "http://localhost:8000/api").rstrip("/")
# URL publique du site web (après connexion Google, redirection ici).
WEB_BASE_URL = os.getenv("WEB_BASE_URL", "http://localhost:8000/app").rstrip("/")
# Hôte/port d'écoute du serveur webapp (derrière nginx en prod).
WEBAPP_LISTEN = os.getenv("WEBAPP_LISTEN", "0.0.0.0")
# Certains hébergeurs (ex: Hostrix, Render, Railway...) imposent leur propre port via la
# variable d'environnement PORT : on la prend en priorité si elle est présente, sinon on
# retombe sur WEBAPP_PORT (utile en local / VPS classique derrière nginx).
WEBAPP_PORT = int(os.getenv("PORT", os.getenv("WEBAPP_PORT", "8000")))
# Origines autorisées en CORS pour l'API (séparées par des virgules).
WEBAPP_CORS_ORIGINS = [o.strip() for o in os.getenv("WEBAPP_CORS_ORIGINS", "*").split(",") if o.strip()]

# ── Déploiement / montée en charge ────────────────────────────────────────
# Nombre de mises à jour Telegram traitées en parallèle (joueurs différents).
MAX_CONCURRENT_UPDATES = int(os.getenv("MAX_CONCURRENT_UPDATES", "64"))

# Historique des stats (graphiques /graphique) : au plus 1 point par joueur toutes les
# STAT_SNAPSHOT_MIN_INTERVAL secondes (0 = comportement d'origine : 3 lignes à CHAQUE mouvement
# d'argent), conservé STAT_HISTORY_RETENTION_DAYS jours (les graphiques vont jusqu'à 180 j).
STAT_SNAPSHOT_MIN_INTERVAL = int(os.getenv("STAT_SNAPSHOT_MIN_INTERVAL", str(6 * 3600)))
STAT_HISTORY_RETENTION_DAYS = int(os.getenv("STAT_HISTORY_RETENTION_DAYS", "180"))
JOURNAL_RETENTION_DAYS = int(os.getenv("JOURNAL_RETENTION_DAYS", "90"))
# Mode webhook (recommandé en production). Laisser WEBHOOK_URL vide = polling.
WEBHOOK_URL = os.getenv("WEBHOOK_URL", "").rstrip("/")      # ex: https://bot.mondomaine.com
WEBHOOK_PORT = int(os.getenv("WEBHOOK_PORT", "8443"))
WEBHOOK_LISTEN = os.getenv("WEBHOOK_LISTEN", "0.0.0.0")
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "")           # jeton secret de vérification

# ✅ Fix #10 : renommé en LEGACY_ADMIN_IDS pour éviter l'écrasement.
#    Ce sera fusionné avec la hiérarchie admin définie plus bas.
LEGACY_ADMIN_IDS = (
    list(map(int, os.getenv("ADMIN_IDS", "").split(",")))
    if os.getenv("ADMIN_IDS") else []
)

PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("DATA_DIR", str(PROJECT_ROOT))).expanduser().resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)
APP_ENV = os.getenv("APP_ENV", "development").strip().lower()
# En production, définir DB_PATH vers un volume persistant (ex: /var/lib/earthangel-rp/life_sim.db).
# Le fallback absolu conserve le comportement local tout en évitant les bases différentes selon le cwd.
DB_PATH = str(Path(os.getenv("DB_PATH", str(DATA_DIR / "life_sim.db"))).expanduser().resolve())
Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
CONFIGURED_DB_PATH = DB_PATH
_require_db = os.getenv("REQUIRE_EXISTING_DB")
REQUIRE_EXISTING_DB = (
    (_require_db if _require_db is not None else ("1" if APP_ENV in {"production", "prod", "staging"} else "0"))
    .strip().lower() in {"1", "true", "yes", "on"}
)
DB_VERSION = 2
SQLITE_POOL_SIZE = 5

# ─── Economy ──────────────────────────────────────────────────────────────────
DAILY_MIN = 1_500
DAILY_MAX = 3_000
# WORK_COOLDOWN (1 h de jeu) et DAILY_COOLDOWN (24 h réelles, seule exception) sont définis plus bas (après l'horloge du jeu).
STARTING_BALANCE = 10_000

WEALTH_TAX_BRACKETS = [
    (1_000_000, 0.01),
    (10_000_000, 0.02),
    (100_000_000, 0.03),
]

# Impôt sur la fortune (prélevé chaque jour = taux mensuel / 30), sur wallet + dépôts bancaires.
# (plafond de richesse jusqu'ici contourné en cachant l'argent en banque)
# Format : (seuil_max_exclu, taux_mensuel_en_%). Une fortune sous le premier seuil ne paie rien.
WEALTH_TAX_MONTHLY_BRACKETS = [
    (100_000, 0),
    (500_000, 2),
    (2_000_000, 5),
    (10_000_000, 10),
    (50_000_000, 15),
    (float("inf"), 25),
]

# ─── Abonnements VIP / Premium (Telegram Stars — XTR) ─────────────
STARS_SUBSCRIPTIONS = {
    "vip_7": {
        "label": "🥉 VIP — 7 jours",
        "tier": "vip",
        "days": 7,
        "stars": 70,
        "desc": "Abonnement VIP pendant 7 jours : +10% de revenus, -15% sur les cooldowns, +5% de gains au casino, +10% de followers, -5% d'impôts.",
    },
    "vip_15": {
        "label": "🎖 VIP — 15 jours",
        "tier": "vip",
        "days": 15,
        "stars": 130,
        "desc": "Abonnement VIP pendant 15 jours : +10% de revenus, -15% sur les cooldowns, +5% de gains au casino, +10% de followers, -5% d'impôts. Économie de 10 ⭐ vs 2×7j.",
        "tag": "💰 ÉCONOMIE",
    },
    "premium_15": {
        "label": "👑 PREMIUM — 15 jours",
        "tier": "premium",
        "days": 15,
        "stars": 300,
        "desc": "Abonnement PREMIUM pendant 15 jours : +25% de revenus, -30% sur les cooldowns, +10% de gains au casino, +25% de followers, -15% d'impôts. Le tier le plus puissant du jeu.",
        "tag": "⭐ POPULAIRE",
    },
    "premium_30": {
        "label": "👑 PREMIUM — 30 jours",
        "tier": "premium",
        "days": 30,
        "stars": 550,
        "desc": "Abonnement PREMIUM pendant 30 jours : +25% de revenus, -30% sur les cooldowns, +10% de gains au casino, +25% de followers, -15% d'impôts. Le tier le plus puissant du jeu. Économie de 50 ⭐ vs 2×15j.",
        "tag": "💎 MEILLEUR RAPPORT",
    },
}

VIP_TIER_BONUSES = {
    "vip":     {"income_mult": 1.10, "cooldown_mult": 0.85, "casino_bonus": 0.05,
                "tax_reduction": 0.05, "social_bonus": 0.10},
    "premium": {"income_mult": 1.25, "cooldown_mult": 0.70, "casino_bonus": 0.10,
                "tax_reduction": 0.15, "social_bonus": 0.25},
    "none":    {"income_mult": 1.00, "cooldown_mult": 1.00, "casino_bonus": 0.00,
                "tax_reduction": 0.00, "social_bonus": 0.00},
}

# ─── Boutique en Étoiles ──────────────────────────────────────────
STARS_SHOP = {
    # ═══════════════════════════════════════════════════════════════
    # Catégorie 1 — Boosts temporaires (7 jours, cumulables)
    # ═══════════════════════════════════════════════════════════════
    "boost_xp2": {
        "cat": 1, "stars": 50,
        "label": "⚡ Boost XP x2 (7 jours)",
        "short_desc": "x2 XP sur TOUTES les actions",
        "desc": "Double TOUS les gains d'XP pendant 7 jours : travail, missions, crimes, casino, jardin, voyages, arena, études… Toutes les sources d'XP sont concernées.",
        "type": "boost", "field": "boost_xp2_until", "days": 7,
    },
    "boost_coins2": {
        "cat": 1, "stars": 50,
        "label": "💰 Boost €A x2 (7 jours)",
        "short_desc": "x2 €A sur toutes les récompenses",
        "desc": "Double TOUS les revenus d'argent pendant 7 jours : salaires, récompenses de missions, gains de crimes, récoltes de jardin, ventes au casino, etc.",
        "type": "boost", "field": "boost_coins2_until", "days": 7,
        "tag": "⭐ POPULAIRE",
    },
    "boost_chance": {
        "cat": 1, "stars": 70,
        "label": "🎲 Boost Chance +15% (7 jours)",
        "short_desc": "+15% succès crimes, hacks, casino",
        "desc": "Augmente de +15% tes chances de réussite aux crimes, aux hacks informatiques, aux jeux de casino (slots, blackjack, roulette, mines, PMU) et réduit les risques d'arrestation au marché noir.",
        "type": "boost", "field": "boost_chance_until", "days": 7,
    },
    "boost_jardin": {
        "cat": 1, "stars": 40,
        "label": "🌱 Boost Jardin x3 (7 jours)",
        "short_desc": "x3 vitesse et valeur du jardin",
        "desc": "Les plantes poussent 3× plus vite dans ton jardin pendant 7 jours. Le multiplicateur s'applique à toutes les parcelles plantées.",
        "type": "boost", "field": "boost_jardin_until", "days": 7,
    },
    "boost_vitesse": {
        "cat": 1, "stars": 35,
        "label": "🏍️ Boost Vitesse -50% (7 jours)",
        "short_desc": "-50% durée de voyage",
        "desc": "Réduit de moitié la durée de TOUS les voyages pendant 7 jours, quelle que soit la destination. Cumulable avec le bonus de vitesse des véhicules.",
        "type": "boost", "field": "boost_vitesse_until", "days": 7,
    },

    # ═══════════════════════════════════════════════════════════════
    # Catégorie 2 — Améliorations permanentes cumulables
    # ═══════════════════════════════════════════════════════════════
    "jardin5": {
        "cat": 2, "stars": 120,
        "label": "🌱 +5 parcelles de jardin",
        "short_desc": "+5 parcelles (max +15)",
        "desc": "Ajoute définitivement 5 parcelles à ton jardin (limite de base : 10). Cumulable jusqu'à 3 fois (max +15 parcelles, soit 25 au total).",
        "type": "stack", "field": "extra_garden_plots", "amount": 5, "max_stack": 3,
    },
    "propriete5": {
        "cat": 2, "stars": 180,
        "label": "🏘️ +5 propriétés max",
        "short_desc": "+5 propriétés (max +15)",
        "desc": "Augmente définitivement ta limite de propriétés immobilières de 5. Cumulable jusqu'à 3 fois (max +15 propriétés, soit 35 au total).",
        "type": "stack", "field": "extra_properties", "amount": 5, "max_stack": 3,
    },
    "vehicule3": {
        "cat": 2, "stars": 150,
        "label": "🚗 +3 véhicules max",
        "short_desc": "+3 véhicules (max +9)",
        "desc": "Augmente définitivement la limite de véhicules dans ton garage de 3. Cumulable jusqu'à 3 fois (max +9 véhicules, soit 19 au total).",
        "type": "stack", "field": "extra_vehicles", "amount": 3, "max_stack": 3,
    },
    "cd_travail": {
        "cat": 2, "stars": 250,
        "label": "⚡ -15 min cooldown travail",
        "short_desc": "-15 min entre deux travails (max -30 min)",
        "desc": "Réduit définitivement le cooldown entre deux missions de travail de 15 minutes de jeu. Cumulable 2× (max -30 min). Le cooldown de base est de 1 h de jeu : il peut donc descendre à 30 min.",
        "type": "stack", "field": "extra_work_cd_reduction", "amount": 900, "max_stack": 2,
    },
    "assurance_crime": {
        "cat": 2, "stars": 90,
        "label": "🛡️ Assurance anti-arrestation",
        "short_desc": "Annule la prison au prochain crime raté",
        "desc": "Achète 1 charge de protection. Si un crime échoue alors que tu as une charge active, tu repars en fuite au lieu d'aller en prison (la charge est consommée automatiquement, le butin reste perdu). Cumulable jusqu'à 5 charges en réserve.",
        "type": "stack", "field": "crime_shield_charges", "amount": 1, "max_stack": 5,
    },

    # ═══════════════════════════════════════════════════════════════
    # Catégorie 3 — Consommables instantanés
    # ═══════════════════════════════════════════════════════════════
    "soin_complet": {
        "cat": 3, "stars": 25,
        "label": "❤️ Soin complet",
        "short_desc": "Santé à 100% maintenant",
        "desc": "Restaure immédiatement ta santé à 100%. Effet instantané.",
        "type": "consumable", "effect": "heal_full",
    },
    "energie_pleine": {
        "cat": 3, "stars": 25,
        "label": "⚡ Énergie complète",
        "short_desc": "Énergie à 100% maintenant",
        "desc": "Restaure immédiatement ton énergie à 100%. Effet instantané.",
        "type": "consumable", "effect": "energy_full",
    },
    "bonheur_max": {
        "cat": 3, "stars": 25,
        "label": "😊 Bonheur max",
        "short_desc": "Bonheur à 100% maintenant",
        "desc": "Restaure immédiatement ton bonheur à 100%. Effet instantané.",
        "type": "consumable", "effect": "happiness_full",
    },
    "anti_stress": {
        "cat": 3, "stars": 15,
        "label": "😰 Anti-stress",
        "short_desc": "Stress à 0% maintenant",
        "desc": "Remet immédiatement ton stress à zéro. Effet instantané.",
        "type": "consumable", "effect": "stress_zero",
    },
    "parchemin_xp": {
        "cat": 3, "stars": 40,
        "label": "📜 Parchemin XP légendaire",
        "short_desc": "+2 500 XP immédiat",
        "desc": "Donne immédiatement +2 500 XP. Cumulable avec ton boost XP actif (donc +5 000 XP si boost actif).",
        "type": "consumable", "effect": "xp", "amount": 2500,
    },
    "sac_coins": {
        "cat": 3, "stars": 100,
        "label": "💰 Sac d'€A",
        "short_desc": "+500 000 €A immédiat",
        "desc": "Donne immédiatement +500 000 €A sur ton solde.",
        "type": "consumable", "effect": "coins", "amount": 500_000,
    },
    "pierre_prestige": {
        "cat": 3, "stars": 75,
        "label": "👑 Pierre de Prestige",
        "short_desc": "+50 prestige immédiat",
        "desc": "Donne immédiatement +50 points de prestige. Le prestige influence ton rang visible dans le classement et débloque certains privilèges.",
        "type": "consumable", "effect": "prestige", "amount": 50,
    },
    "ticket_loterie": {
        "cat": 3, "stars": 60,
        "label": "🎫 Ticket de loterie garanti",
        "short_desc": "1 ticket pour le prochain tirage",
        "desc": "Ajoute 1 ticket valide pour le prochain tirage de la loterie. Le jackpot peut atteindre plusieurs millions. Tirage quotidien automatique.",
        "type": "consumable", "effect": "lottery_ticket",
    },
    "carte_liberte": {
        "cat": 3, "stars": 45,
        "label": "🔓 Carte Sortie de Prison",
        "short_desc": "Libération immédiate et garantie",
        "desc": "Te sort instantanément de prison, sans attendre et sans payer de caution. Contrairement à l'avocat ou au tribunal (qui peuvent échouer ou aggraver ta peine), l'effet est garanti à 100%. Inutile si tu n'es pas incarcéré.",
        "type": "consumable", "effect": "prison_clear",
        "tag": "✅ GARANTI",
    },
    "diplome_express": {
        "cat": 3, "stars": 55,
        "label": "⏩ Diplôme Express",
        "short_desc": "Termine instantanément une formation en cours",
        "desc": "Si tu es en cours d'étude pour un diplôme, fait passer le temps restant à zéro : tu peux passer l'examen tout de suite au lieu d'attendre. Ne change pas tes chances de réussite — juste le temps d'attente. Inutile si aucune formation n'est en cours.",
        "type": "consumable", "effect": "diplome_skip",
    },

    # ═══════════════════════════════════════════════════════════════
    # Catégorie 4 — Cosmétiques
    # ═══════════════════════════════════════════════════════════════
    "couleur_animee": {
        "cat": 4, "stars": 60,
        "label": "🌈 Couleur de profil animée",
        "short_desc": "Emoji 🌈 devant ton nom",
        "desc": "Affiche un emoji arc-en-ciel 🌈 devant ton nom dans le menu, /me et le menu principal au lieu de l'emoji par défaut 🔵.",
        "type": "cosmetic", "field": "profile_color", "value": "🌈 animée",
    },
    "titre_perso": {
        "cat": 4, "stars": 100,
        "label": "🏷️ Titre personnalisé",
        "short_desc": "Titre '⭐ Étoile' visible partout",
        "desc": "Affiche le titre '⭐ Étoile' à côté de ton nom dans le menu, le menu principal et les classements. Un signe distinctif immédiatement visible.",
        "type": "cosmetic", "field": "profile_title", "value": "⭐ Étoile",
    },
    "badge_perso": {
        "cat": 4, "stars": 80,
        "label": "🖼️ Badge personnalisé",
        "short_desc": "Badge 🖼️ exclusif sur ton profil",
        "desc": "Ajoute un badge 🖼️ exclusif dans ta liste de badges et sur ton profil. Visible par tous les joueurs.",
        "type": "cosmetic", "field": "profile_badge", "value": "🖼️",
    },
    "emoji_signature": {
        "cat": 4, "stars": 25,
        "label": "🎭 Emoji signature",
        "short_desc": "Signature ✨ en bas de profil",
        "desc": "Affiche ✨ comme signature sur ton profil, sous ta bio. Un petit détail qui te démarque.",
        "type": "cosmetic", "field": "signature_emoji", "value": "✨",
    },

    # ═══════════════════════════════════════════════════════════════
    # Catégorie 5 — Packs avantageux
    # ═══════════════════════════════════════════════════════════════
    "pack_starter": {
        "cat": 5, "stars": 20,
        "label": "🚀 Pack Premiers Pas",
        "short_desc": "100K €A + soin complet + 500 XP",
        "desc": "Le moyen le moins cher de prendre de l'avance : 100 000 €A immédiats + Santé/Énergie/Bonheur remis à 100% + 500 XP bonus. Pensé pour découvrir la boutique sans se ruiner.",
        "type": "pack", "effect": "pack_starter",
        "tag": "🆕 DÉCOUVERTE",
    },
    "pack_decouverte": {
        "cat": 5, "stars": 130,
        "label": "🎁 Pack Découverte",
        "short_desc": "3 boosts (7j) + 50K €A",
        "desc": "Comprend : Boost XP x2 (7j) + Boost €A x2 (7j) + Boost Chance +15% (7j) + 50 000 €A bonus. Valeur individuelle : ~170 ⭐, tu économises 40 ⭐.",
        "type": "pack", "effect": "pack_decouverte",
        "tag": "🔥 MEILLEUR DÉBUT",
    },
    "pack_entrepreneur": {
        "cat": 5, "stars": 150,
        "label": "💎 Pack Entrepreneur",
        "short_desc": "Boost €A x2 (7j) + 600K €A",
        "desc": "Comprend : Boost €A x2 pendant 7 jours + 600 000 €A versés immédiatement sur ton solde. Parfait pour lancer une entreprise.",
        "type": "pack", "effect": "pack_entrepreneur",
    },
    "pack_prestige": {
        "cat": 5, "stars": 500,
        "label": "👑 Pack Prestige",
        "short_desc": "Premium 30j + 5000 Prestige",
        "desc": "Comprend : Abonnement PREMIUM 30 jours + 5 000 Prestige + titre exclusif '👑 Prestige'. Valeur individuelle : ~625 ⭐, tu économises 125 ⭐.",
        "type": "pack", "effect": "pack_prestige",
    },
    "pack_ultime": {
        "cat": 5, "stars": 1000,
        "label": "⭐ Pack Ultime",
        "short_desc": "Premium 90j + boosts confort 90j",
        "desc": "Comprend : Abonnement PREMIUM 90 jours + boosts de confort (Chance +15%, Jardin x3, Vitesse -50%) actifs pendant 90 jours. Le pack le plus complet.",
        "type": "pack", "effect": "pack_ultime",
        "tag": "💎 VALEUR MAX",
    },
}

# ⭐ Offres mises en avant sur la page d'accueil de la boutique (dans cet ordre).
STARS_SHOP_CATEGORIES = {
    1: "🎯 Boosts temporaires",
    2: "💎 Améliorations & protections",
    3: "🎁 Consommables utiles",
    4: "🎨 Cosmétiques",
    5: "💼 Packs avantageux",
}

# ⭐ Offres mises en avant sur la page d'accueil de la boutique (dans cet ordre).
STARS_FEATURED_OFFERS = ["carte_liberte", "assurance_crime", "pack_ultime", "boost_vitesse"]

# Articles retirés de la vente : ils donnaient directement de l'argent, de l'XP ou du prestige
# (avantage immédiat acheté, déséquilibre entre joueurs payants et gratuits). Les articles déjà achetés
# restent utilisables. Les remettre en vente demande une décision du Lead Principal.
# Boosts x2 d'XP et de €A : retirés (multiplicateur de progression acheté = pay-to-win). Les boosts déjà actifs
# vont à leur terme ; on ne garde en vente que des confort/risque (Chance, Jardin, Vitesse).
STARS_RETIRED_ITEMS = {"sac_coins", "parchemin_xp", "pierre_prestige", "pack_starter",
                       "pack_decouverte", "pack_entrepreneur", "pack_prestige",
                       "boost_xp2", "boost_coins2",
                       "boost_chance", "boost_jardin", "pack_ultime"}

# ─── Education ─────────────────────────────────────────────────────
DIPLOMES = ["Brevet", "Bac", "BTS", "Licence", "Master", "MBA", "Doctorat", "Habilitation"]
DIPLOME_COSTS = {
    "Brevet":         5_000,
    "Bac":           15_000,
    "BTS":           30_000,
    "Licence":       80_000,
    "Master":       250_000,
    "MBA":        1_000_000,
    "Doctorat":   3_000_000,
    "Habilitation":10_000_000,
}
DIPLOME_STUDY_TIME = {
    "Brevet":       3600,
    "Bac":          7200,
    "BTS":          7200,
    "Licence":     14400,
    "Master":      21600,
    "MBA":         28800,
    "Doctorat":    43200,
    "Habilitation":86400,
}
DIPLOME_PASS_RATE = {
    "Brevet":      0.85,
    "Bac":         0.75,
    "BTS":         0.70,
    "Licence":     0.65,
    "Master":      0.55,
    "MBA":         0.45,
    "Doctorat":    0.35,
    "Habilitation":0.20,
}
DIPLOME_SALARY_BONUS = {
    "Brevet":      1.05,
    "Bac":         1.10,
    "BTS":         1.20,
    "Licence":     1.35,
    "Master":      1.55,
    "MBA":         2.00,
    "Doctorat":    2.50,
    "Habilitation":3.50,
}

DIPLOMES_EXTENDED = [
    "Brevet", "Bac", "BTS", "Licence", "Master",
    "École de commerce", "Grande École", "MBA", "Doctorat", "Habilitation", "Doctorat honoris causa"
]
DIPLOME_COSTS_EXTENDED = {
    "École de commerce":         2_000_000,
    "Grande École":              5_000_000,
    "Doctorat honoris causa":   20_000_000,
}
DIPLOME_STUDY_TIME_EXTENDED = {
    "École de commerce":         43200,
    "Grande École":              86400,
    "Doctorat honoris causa":   172800,
}
DIPLOME_PASS_RATE_EXTENDED = {
    "École de commerce":         0.55,
    "Grande École":              0.45,
    "Doctorat honoris causa":    0.10,
}
DIPLOME_SALARY_BONUS_EXTENDED = {
    "École de commerce":         2.20,
    "Grande École":              2.80,
    "Doctorat honoris causa":    4.00,
}

# ─── Jobs ─────────────────────────────────────────────────────────
JOBS = {
    "Livreur":       {"min": 600,   "max": 2_400,   "xp": 30,  "need": None,      "sector": "Commerce"},
    "Serveur":       {"min": 750,   "max": 2_700,   "xp": 35,  "need": None,      "sector": "Commerce"},
    "Ouvrier":       {"min": 900,   "max": 3_000,   "xp": 40,  "need": None,      "sector": "Industrie"},
    "Caissier":      {"min": 600,   "max": 2_250,   "xp": 25,  "need": None,      "sector": "Commerce"},
    "Agent secu":    {"min": 1_050, "max": 3_600,   "xp": 45,  "need": "Brevet",  "sector": "Sécurité"},
    "Technicien":    {"min": 1_500, "max": 5_400,   "xp": 60,  "need": "BTS",     "sector": "Industrie"},
    "Infirmier":     {"min": 1_800, "max": 6_000,   "xp": 70,  "need": "BTS",     "sector": "Santé"},
    "Comptable":     {"min": 2_400, "max": 8_400,   "xp": 80,  "need": "Licence", "sector": "Finance"},
    "Développeur":   {"min": 3_600, "max": 13_500,  "xp": 100, "need": "Licence", "sector": "Tech"},
    "Ingénieur":     {"min": 4_500, "max": 16_500,  "xp": 110, "need": "Master",  "sector": "Industrie"},
    "Avocat":        {"min": 6_000, "max": 24_000,  "xp": 130, "need": "Master",  "sector": "Juridique"},
    "Médecin":       {"min": 7_500, "max": 30_000,  "xp": 150, "need": "Doctorat","sector": "Santé"},
    "Manager":       {"min": 5_400, "max": 21_000,  "xp": 120, "need": "MBA",     "sector": "Management"},
    "Directeur":     {"min": 9_000, "max": 33_000,  "xp": 200, "need": "MBA",     "sector": "Management"},
    "Chercheur":     {"min": 9_000, "max": 36_000,  "xp": 180, "need": "Doctorat","sector": "Science"},
    "Professeur":    {"min": 6_000, "max": 18_000,  "xp": 140, "need": "Master",  "sector": "Éducation"},
    "Architecte":    {"min": 6_600, "max": 25_500,  "xp": 145, "need": "Master",  "sector": "Construction"},
    "Pilote":        {"min": 10_500,"max": 39_000,  "xp": 160, "need": "Master",  "sector": "Aviation"},
    "PDG":           {"min": 20_000,"max": 75_000, "xp": 500, "need": "MBA",     "sector": "Management"},
    "Influenceur":   {"min": 1_000, "max": 15_000,  "xp": 80,  "need": None,      "sector": "Médias"},
    "Artiste":       {"min": 200,   "max": 12_000,  "xp": 70,  "need": None,      "sector": "Arts"},
    "Footballeur":   {"min": 900,   "max": 21_000, "xp":200,  "need": None,      "sector": "Sport"},
    "Hackeur":       {"min": 4_500, "max": 30_000,  "xp": 170, "need": "Licence", "sector": "Tech"},
}

EVOLUTIVE_JOBS = {
    "Développeur": [
        {"name": "Développeur Junior",     "min": 3_600, "max": 7_500, "xp": 100, "need": "Licence", "sector": "Tech", "level_req": 1},
        {"name": "Développeur Confirmé",   "min": 7_500, "max": 13_500, "xp": 150, "need": "Licence", "sector": "Tech", "level_req": 2},
        {"name": "Lead Developer",         "min": 13_500,"max": 24_000, "xp": 200, "need": "Master",  "sector": "Tech", "level_req": 3},
        {"name": "CTO",                    "min": 24_000,"max": 45_000, "xp": 300, "need": "MBA",     "sector": "Tech", "level_req": 4},
    ],
    "Manager": [
        {"name": "Assistant Manager",      "min": 5_400, "max": 10_500, "xp": 120, "need": "Licence", "sector": "Management", "level_req": 1},
        {"name": "Manager",               "min": 10_500,"max": 21_000, "xp": 150, "need": "Master",  "sector": "Management", "level_req": 2},
        {"name": "Senior Manager",        "min": 21_000,"max": 36_000, "xp": 200, "need": "MBA",     "sector": "Management", "level_req": 3},
        {"name": "Directeur Général",     "min": 36_000,"max": 75_000, "xp": 300, "need": "MBA",     "sector": "Management", "level_req": 4},
    ],
}

# ─── Skills ───────────────────────────────────────────────────────
SKILLS = [
    "Charisme", "Intelligence", "Force", "Agilité",
    "Négociation", "Leadership", "Créativité", "Technique",
    "Endurance", "Discrétion",
]
SKILL_LEVEL_COST = 5_000

# Courbe de niveau : il faut (niveau - 1)² × XP_LEVEL_BASE XP pour atteindre un niveau.
XP_LEVEL_BASE = 500

# ─── Real Estate ──────────────────────────────────────────────────
PROPERTIES = {
    "Studio":       {"price": 150_000,    "rent": 1_500,    "maint": 600,    "emoji": "🏠"},
    "Appartement":  {"price": 450_000,    "rent": 4_500,    "maint": 1_500,  "emoji": "🏢"},
    "Maison":       {"price": 1_200_000,  "rent": 12_000,   "maint": 3_600,  "emoji": "🏡"},
    "Villa":        {"price": 4_500_000,  "rent": 45_000,   "maint": 12_000, "emoji": "🏖️"},
    "Château":      {"price": 24_000_000, "rent": 240_000,  "maint": 60_000, "emoji": "🏰"},
    "Gratte-ciel":  {"price": 150_000_000,"rent": 1_500_000,"maint": 360_000,"emoji": "🏙️"},
    "Île privée":   {"price": 1_500_000_000,"rent":15_000_000,"maint":3_000_000,"emoji":"🏝️"},
}

# ─── Vehicles ─────────────────────────────────────────────────────
VEHICLES = {
    "Vélo":          {"price": 500,       "maint": 50,    "emoji": "🚲", "status": 1, "speed": 10,  "cargo": 5,  "luxury": 0,  "fuel_capacity": 0},
    "Scooter":       {"price": 3_000,     "maint": 200,   "emoji": "🛵", "status": 2, "speed": 30,  "cargo": 15, "luxury": 10, "fuel_capacity": 5},
    "Voiture":       {"price": 15_000,    "maint": 800,   "emoji": "🚗", "status": 3, "speed": 50,  "cargo": 40, "luxury": 30, "fuel_capacity": 40},
    "SUV":           {"price": 40_000,    "maint": 1_500, "emoji": "🚙", "status": 4, "speed": 45,  "cargo": 70, "luxury": 40, "fuel_capacity": 60},
    "Sport":         {"price": 120_000,   "maint": 4_000, "emoji": "🏎️", "status": 5, "speed": 85,  "cargo": 20, "luxury": 80, "fuel_capacity": 50},
    "Limousine":     {"price": 300_000,   "maint": 8_000, "emoji": "🚘", "status": 6, "speed": 60,  "cargo": 50, "luxury": 90, "fuel_capacity": 60},
    "Moto sport":    {"price": 25_000,    "maint": 1_200, "emoji": "🏍️", "status": 4, "speed": 80,  "cargo": 10, "luxury": 50, "fuel_capacity": 15},
    "Yacht":         {"price": 2_000_000, "maint": 50_000,"emoji": "⛵", "status": 7, "speed": 20,  "cargo": 100, "luxury": 95, "fuel_capacity": 200},
    "Jet privé":     {"price": 30_000_000,"maint": 500_000,"emoji": "✈️", "status": 8, "speed": 100, "cargo": 80, "luxury": 100, "fuel_capacity": 500},
    "Hélicoptère":   {"price": 5_000_000, "maint": 100_000,"emoji": "🚁", "status": 7, "speed": 90,  "cargo": 50, "luxury": 70, "fuel_capacity": 100},
}

# ─── Luxury Items ─────────────────────────────────────────────────
LUXURY_ITEMS = {
    "Montre Rolex":     {"price": 50_000,    "prestige": 5,  "emoji": "⌚"},
    "Sac Hermès":       {"price": 30_000,    "prestige": 4,  "emoji": "👜"},
    "Collier diamant":  {"price": 200_000,   "prestige": 8,  "emoji": "💎"},
    "Costume Armani":   {"price": 15_000,    "prestige": 3,  "emoji": "👔"},
    "Caviar royal":     {"price": 5_000,     "prestige": 2,  "emoji": "🍾"},
    "Tableau d'art":    {"price": 500_000,   "prestige": 12, "emoji": "🖼️"},
    "Jet ski":          {"price": 25_000,    "prestige": 3,  "emoji": "🛥️"},
    "Pool house":       {"price": 1_000_000, "prestige": 15, "emoji": "🏊"},
    "Cheval de course": {"price": 3_000_000, "prestige": 20, "emoji": "🐎"},
    "Sous-marin perso": {"price": 50_000_000,"prestige":50,  "emoji": "🤿"},
}

# ─── Health ───────────────────────────────────────────────────────
MEDICINES = {
    "Aspirine":       {"price": 200,    "health": 10, "emoji": "💊"},
    "Antibiotiques":  {"price": 2_000,  "health": 30, "emoji": "💉"},
    "Chirurgie":      {"price": 50_000, "health": 80, "emoji": "🏥"},
    "Greffe":         {"price": 500_000,"health": 100,"emoji": "❤️"},
}
GYM_COST = 500
GYM_ENERGY_BONUS = 20
DOCTOR_BASE = 5_000

# ─── Travel ───────────────────────────────────────────────────────
DESTINATIONS = {
    "Paris":          {"cost": 20_000,   "happiness": 15, "xp": 50,  "emoji": "🗼"},
    "New York":       {"cost": 50_000,   "happiness": 20, "xp": 80,  "emoji": "🗽"},
    "Tokyo":          {"cost": 60_000,   "happiness": 22, "xp": 90,  "emoji": "⛩️"},
    "Dubai":          {"cost": 80_000,   "happiness": 25, "xp": 100, "emoji": "🏙️"},
    "Maldives":       {"cost": 150_000,  "happiness": 35, "xp": 120, "emoji": "🏝️"},
    "Monaco":         {"cost": 300_000,  "happiness": 40, "xp": 150, "emoji": "🎰"},
    "Espace":         {"cost": 50_000_000,"happiness":100,"xp": 1000,"emoji": "🚀"},
}

# ─── Crime ────────────────────────────────────────────────────────
CRIMES = {
    "Pickpocket":     {"reward": (300, 1_500),    "jail": 1800,  "success": 0.70, "karma": -5},
    "Vol à l'étalage":{"reward": (600, 2_400),    "jail": 3600,  "success": 0.65, "karma": -8},
    "Cambriolage":    {"reward": (3_000, 15_000),   "jail": 7200,  "success": 0.55, "karma": -15},
    "Arnaque":        {"reward": (6_000, 30_000),  "jail": 10800, "success": 0.50, "karma": -20},
    "Braquage":       {"reward": (15_000, 90_000),  "jail": 21600, "success": 0.40, "karma": -30},
    "Trafic drogue":  {"reward": (30_000, 150_000), "jail": 43200, "success": 0.35, "karma": -40},
    "Cybercriminalité":{"reward": (60_000, 300_000),"jail": 86400, "success": 0.30, "karma": -50},
    "Hold-up banque": {"reward": (150_000, 600_000),"jail":172800, "success": 0.20, "karma": -80},
}
CRIME_COOLDOWN = 1800   # 30 min (avant : 60 s)
BAIL_COST_RATIO = 0.5
LAWYER_COST = 50_000

# ─── Casino ───────────────────────────────────────────────────────
CASINO_MIN_BET = 100
CASINO_MAX_BET = 250_000          # avant : 10 000 000
CASINO_VIP_BONUS_CAP = 0.01      # le bonus VIP casino ne dépasse jamais 1 % de la mise
ROULETTE_NUMBERS = list(range(0, 37))

# ─── Investments ──────────────────────────────────────────────────
ASSETS = [
    {"name": "TechCorp",     "price": 1_000,    "volatility": 0.18, "sector": "Tech",     "emoji": "💻"},
    {"name": "CryptoX",      "price": 5_000,    "volatility": 0.40, "sector": "Crypto",   "emoji": "₿"},
    {"name": "Or virtuel",   "price": 50_000,   "volatility": 0.06, "sector": "Matières", "emoji": "🥇"},
    {"name": "PétroCorp",    "price": 2_500,    "volatility": 0.14, "sector": "Énergie",  "emoji": "🛢️"},
    {"name": "PharmaCo",     "price": 8_000,    "volatility": 0.12, "sector": "Santé",    "emoji": "💊"},
    {"name": "ImmoCorp",     "price": 15_000,   "volatility": 0.08, "sector": "Immo",     "emoji": "🏢"},
    {"name": "AutoMakers",   "price": 3_000,    "volatility": 0.20, "sector": "Auto",     "emoji": "🚗"},
    {"name": "FoodChain",    "price": 1_500,    "volatility": 0.09, "sector": "Alim",     "emoji": "🍔"},
    {"name": "EnergiVerte",  "price": 4_500,    "volatility": 0.22, "sector": "Énergie",  "emoji": "⚡"},
    {"name": "LuxuryBrand",  "price": 25_000,   "volatility": 0.11, "sector": "Luxe",     "emoji": "👑"},
    {"name": "MoonCoin",     "price": 100,      "volatility": 0.80, "sector": "Crypto",   "emoji": "🌙"},
    {"name": "DefenseCo",    "price": 12_000,   "volatility": 0.07, "sector": "Défense",  "emoji": "🛡️"},
]

# ─── Banks ────────────────────────────────────────────────────────
BANKS = [
    # interest = taux PAR JOUR (≈ 3,7 % → 11,6 % par an). Avant : 1 % à 8 % par jour.
    {"name": "Banque Populaire",   "interest": 0.00010, "min": 1_000,       "loan_max": 10_000},
    {"name": "Crédit National",    "interest": 0.00015, "min": 10_000,      "loan_max": 100_000},
    {"name": "Banque Privée",      "interest": 0.00020, "min": 500_000,     "loan_max": 2_000_000},
    {"name": "Banque Élite",       "interest": 0.00025, "min": 5_000_000,   "loan_max": 20_000_000},
    {"name": "Banque des Dieux",   "interest": 0.00030, "min": 250_000_000, "loan_max": 200_000_000},
]

# ─── Garden ───────────────────────────────────────────────────────
PLANTS = {
    "Blé":          {"grow_time": 1800,  "value": 300,     "emoji": "🌾", "water_needed": 1},
    "Rose":         {"grow_time": 3600,  "value": 600,     "emoji": "🌹", "water_needed": 2},
    "Tomate":       {"grow_time": 5400,  "value": 900,     "emoji": "🍅", "water_needed": 2},
    "Fraise":       {"grow_time": 7200,  "value": 1_500,   "emoji": "🍓", "water_needed": 3},
    "Tournesol":    {"grow_time": 10800, "value": 2_000,   "emoji": "🌻", "water_needed": 2},
    "Cannabis":     {"grow_time": 21600, "value": 10_000,  "emoji": "🌿", "water_needed": 4, "illegal": True},
    "Cactus":       {"grow_time": 86400, "value": 15_000,  "emoji": "🌵", "water_needed": 1},
    "Bambou":       {"grow_time": 43200, "value": 8_000,   "emoji": "🎋", "water_needed": 3},
    "Truffe":       {"grow_time": 172800,"value": 100_000, "emoji": "🍄", "water_needed": 5},
    "Orchidée bleue":{"grow_time":259200,"value":500_000,  "emoji": "🌺", "water_needed": 6},
}

# ─── Sectors ──────────────────────────────────────────────────────
SECTORS = [
    "Technologie", "Finance", "Commerce", "Industrie",
    "Médias", "Immobilier", "Énergie",
    "Alimentation", "Sport", "Arts", "Luxe",
]   # « Éducation » n'est plus un secteur d'entreprise (anciennes entreprises → Commerce, voir config_chain)
# Anciens secteurs désormais gérés par l'État (factions gouvernementales) :
# les entreprises existantes de ces secteurs sont converties au démarrage (utils/factions.py).
GOV_SECTOR_TO_FACTION = {"Santé": "sante", "Défense": "armee", "Juridique": "justice"}

# ─── Company Ranks ────────────────────────────────────────────────
COMPANY_RANKS = ["Stagiaire", "Assistant", "Employé", "Senior", "Responsable", "Manager", "Directeur", "PDG"]
COMPANY_CREATION_COST = 5_000_000   # avant : 100 000 000 (inatteignable avec l'impôt sur la fortune)
COMPANY_SALARY_MAP = {
    "Stagiaire":   500,    "Assistant":  2_000,  "Employé":     5_000,
    "Senior":     12_000,  "Responsable":25_000, "Manager":    50_000,
    "Directeur": 100_000,  "PDG":       250_000,
}

# ─── Social ───────────────────────────────────────────────────────
SOCIAL_PLATFORMS = ["YouTube", "Instagram", "TikTok", "Twitter", "Twitch", "Podcast"]

# ─── Political ────────────────────────────────────────────────────
# Un seul poste élu : le Président. Il dirige l'Administration et nomme les MINISTRES (voir MINISTRIES).
POLITICAL_POSTS = ["Président"]
ELECTION_COST = {
    "Président":       100_000_000,
}


# ─── Titles / Prestige ────────────────────────────────────────────
TITLES = [
    {"min": 0, "title": "🧸 Nouveau-né"},
    {"min": 10_000, "title": "👶 Citoyen"},
    {"min": 100_000, "title": "🏘️ Propriétaire"},
    {"min": 500_000, "title": "💼 Investisseur"},
    {"min": 1_000_000, "title": "💰 Millionnaire"},
    {"min": 10_000_000, "title": "🦁 Lion"},
    {"min": 50_000_000, "title": "👑 Roi"},
    {"min": 100_000_000, "title": "💎 Légende"},
    {"min": 1_000_000_000, "title": "⭐ Dieu"},
]

PRESTIGE_RANKS = [
    {"min": 0,   "name": "🥚 Inconnu"},
    {"min": 10,  "name": "🌱 Bourgeois"},
    {"min": 50,  "name": "💼 Notable"},
    {"min": 150, "name": "🎩 Aristocrate"},
    {"min": 300, "name": "💎 Élite"},
    {"min": 600, "name": "👑 Noblesse"},
    {"min": 1000,"name": "⭐ Légende"},
]

# ─── VIP Lieux ────────────────────────────────────────────────────
VIP_LUXE_REQUIRED = 70
VIP_LIEUX = [
    "🥂 Lounge privé du Casino Royal",
    "🏝️ Plage privée du Yacht Club",
    "🎭 Balcon VIP de l'Opéra",
    "🍾 Salon privé du Ritz",
    "🎰 Salle de jeux exclusive",
    "🚁 Héliport privé",
    "⛵ Marina VIP",
    "🏛️ Galerie d'art privée",
]

# ─── Badges ───────────────────────────────────────────────────────
BADGES = [
    "Millionnaire", "Milliardaire", "Docteur", "MBA", "Guerrier", "Champion",
    "Voyageur", "Globe-trotter", "Influenceur", "Criminel", "Saint", "Démon",
    "Philanthrope", "Fermier", "Accompli", "Prestigieux", "Légendaire", "Survivant",
    "Globe-trotter", "Collector", "Boss", "Hacker", "Politicien", "Chef d'entreprise",
]

# ─── Events ───────────────────────────────────────────────────────
WORLD_EVENTS = [
    {"name": "Crash boursier",       "effect": "market_crash",    "severity": 0.4},
    {"name": "Boom économique",       "effect": "market_boom",     "severity": 0.3},
    {"name": "Pandémie mondiale",     "effect": "health_crisis",   "severity": 0.5},
    {"name": "Révolution tech",       "effect": "tech_boom",       "severity": 0.25},
    {"name": "Guerre commerciale",    "effect": "trade_war",       "severity": 0.3},
    {"name": "Élections mondiales",   "effect": "political_shift", "severity": 0.2},
    {"name": "Catastrophe naturelle", "effect": "disaster",        "severity": 0.6},
    {"name": "Découverte énergie",    "effect": "energy_shift",    "severity": 0.35},
    {"name": "Crise immobilière",     "effect": "realestate_crash","severity": 0.45},
    {"name": "Festival mondial",      "effect": "happiness_boost", "severity": 0.1},
]

# ─── Missions ─────────────────────────────────────────────────────
DAILY_MISSIONS = [
    {"name": "Travailler 3 fois",          "type": "work",       "target": 3,          "reward": 750,     "xp": 200},
    {"name": "Gagner 30K en jeux",         "type": "casino_win", "target": 30_000,     "reward": 2_250,     "xp": 300},
    {"name": "Payer qqun",                 "type": "pay",        "target": 1,          "reward": 150,      "xp": 100},
    {"name": "Planter 3 plantes",          "type": "plant",      "target": 3,          "reward": 450,      "xp": 150},
    {"name": "Investir en bourse",         "type": "invest",     "target": 1,          "reward": 1_125,     "xp": 250},
    {"name": "Se connecter",               "type": "login",      "target": 1,          "reward": 100,      "xp": 50},
    {"name": "Commettre un crime",         "type": "crime",      "target": 1,          "reward": 750,     "xp": 200},
    {"name": "Voyager",                    "type": "travel",     "target": 1,          "reward": 1_500,     "xp": 400},
    {"name": "Récolter des plantes",       "type": "harvest",    "target": 2,          "reward": 375,      "xp": 120},
    {"name": "Dépenser 150K en luxe",      "type": "luxury",     "target": 150_000,    "reward": 3_000,     "xp": 500},
    {"name": "📦 Livraison légère",        "type": "delivery",   "target": 1,          "reward": 1_000,     "xp": 200,  "cargo_required": 0},
    {"name": "📦 Livraison lourde",        "type": "delivery",   "target": 1,          "reward": 2_500,     "xp": 500,  "cargo_required": 50},
    {"name": "📦 Livraison massive",       "type": "delivery",   "target": 1,          "reward": 5_000,    "xp": 1000, "cargo_required": 80},
]

WEEKLY_MISSIONS = [
    {"name": "Atteindre 300K de solde",    "type": "balance",    "target": 300_000,    "reward": 15_000,   "xp": 1000},
    {"name": "Gagner 5 combats d'arène",   "type": "arena_win",  "target": 5,          "reward": 22_500,   "xp": 1500},
    {"name": "Monter de niveau d'études",  "type": "diploma",    "target": 1,          "reward": 9_000,    "xp": 800},
    {"name": "Recruter 3 employés",        "type": "hire",       "target": 3,          "reward": 30_000,   "xp": 2000},
    {"name": "Voyager 3 fois",             "type": "travel",     "target": 3,          "reward": 24_000,   "xp": 1800},
    {"name": "📦 10 livraisons",           "type": "delivery",   "target": 10,         "reward": 50_000,   "xp": 2000, "cargo_required": 30},
]

# ─── Black Market ─────────────────────────────────────────────────
BLACK_MARKET_ITEMS = {
    "Faux passeport":     {"price": 200_000,   "risk": 0.30, "karma": -25, "emoji": "📄"},
    "Arme illégale":      {"price": 500_000,   "risk": 0.40, "karma": -40, "emoji": "🔫"},
    "Dossier volé":       {"price": 100_000,   "risk": 0.25, "karma": -20, "emoji": "📂"},
    "Carte blanche":      {"price": 1_000_000, "risk": 0.15, "karma": -10, "emoji": "💳"},
    "Hack gouvernemental":{"price": 5_000_000, "risk": 0.50, "karma": -60, "emoji": "💻"},
    "Formule secrète":    {"price": 3_000_000, "risk": 0.35, "karma": -30, "emoji": "🧪"},
    "Relique volée":      {"price": 800_000,   "risk": 0.30, "karma": -25, "emoji": "🏺"},
    "Organes":            {"price": 2_000_000, "risk": 0.60, "karma": -80, "emoji": "🫀"},
}


# ─── Cities ───────────────────────────────────────────────────────
CITIES = {
    "Paris": {
        "realestate_mult": 1.5,
        "vehicle_mult": 1.2,
        "salary_mult": 1.3,
        "market_mult": 1.1,
        "crime_mult": 0.8,
        "emoji": "🗼"
    },
    "New York": {
        "realestate_mult": 1.8,
        "vehicle_mult": 1.3,
        "salary_mult": 1.5,
        "market_mult": 1.2,
        "crime_mult": 0.9,
        "emoji": "🗽"
    },
    "Dubai": {
        "realestate_mult": 2.0,
        "vehicle_mult": 1.5,
        "salary_mult": 1.7,
        "market_mult": 1.3,
        "crime_mult": 0.7,
        "emoji": "🏙️"
    },
    "Campagne": {
        "realestate_mult": 0.6,
        "vehicle_mult": 0.8,
        "salary_mult": 0.7,
        "market_mult": 0.9,
        "crime_mult": 1.2,
        "emoji": "🌾"
    },
}

SEASON_EFFECTS = {
    "Printemps": {"garden_mult": 1.2, "happiness_gain": 2, "crime_mult": 1.0},
    "Été":       {"garden_mult": 1.5, "happiness_gain": 5, "crime_mult": 1.1},
    "Automne":   {"garden_mult": 0.8, "happiness_gain": 0, "crime_mult": 0.9},
    "Hiver":     {"garden_mult": 0.5, "happiness_gain": -5, "crime_mult": 0.8},
}

LOTTERY_TICKET_COST = 10_000
LOTTERY_JACKPOT_BASE = 10_000_000
START_PHOTO_PATH = "20260806_001214.png"

# ─── Social avancé ────────────────────────────────────────────────
SOCIAL_COLLAB_COST = 50_000
SOCIAL_TRANSFER_TAX = 0.10
SOCIAL_TREND_COST = 5_000
SOCIAL_TREND_DURATION = 86400
SOCIAL_TREND_MULTIPLIER = 1.5
SOCIAL_STORY_DURATION = 86400
SOCIAL_MIN_FOLLOWERS_FOR_LIVE = 5_000
FOLLOW_BONUS_FOLLOWERS        = 10    # abonnés sociaux gagnés quand un joueur RP vous suit
SOCIAL_LIVE_COST_PER_HOUR     = 1_000  # €A par heure de live
SOCIAL_LIVE_COST_COINS        = 50     # SocialCoins requis pour lancer un live (en plus des €A et des abonnés)
SOCIAL_LIVE_CHAT_COOLDOWN     = 60     # secondes entre deux messages de l'émetteur dans le chat du live
SOCIAL_LIVE_CHAT_MAX_LEN      = 500    # longueur max d'un message de chat live
SOCIAL_COIN_NAME = "SocialCoin"
SOCIAL_COIN_STARTING_BALANCE = 100

# ─── Politique avancée ────────────────────────────────────────────
# ── Politique : réservée aux ADMINS N1 (candidats, président) ─────────────────────────
# Les joueurs votent ; le président élu dirige l'Administration et nomme les MINISTRES (grades de l'Administration)
# (un joueur ou un Admin N1, à lui de décider). Les Admins N2+, Game Leaders et Leads n'interviennent pas dans la
# politique ni les élections (ils administrent) ; le reste du jeu leur reste ouvert.
POLITICAL_ROLES = ("ADMIN_N1",)                 # peuvent se présenter, lancer une élection
PLAYABLE_ROLES = ("PLAYER", "ADMIN_N1")         # seuls rôles qui participent à la POLITIQUE / aux ÉLECTIONS (vote, candidature, cabinet)
ELECTED_POSTS = ("Président",)                  # seul poste élu ; les ministres sont nommés par le président
PRESIDENT_FACTION = "mairie"                    # faction « Administration » dirigée par le président élu
ELECTION_KARMA_REQUIRED = 100
ELECTION_QUORUM = 0.20
ELECTION_COOLDOWN = 7 * 86400
ELECTION_DEFAULT_DURATION_HOURS = 24
ELECTION_MAX_DURATION_HOURS = 72
LAW_PROPOSAL_COST = 50_000
LAW_VOTE_DURATION = 48 * 3600
LAW_DEFAULT_MAJORITY = 0.5
REFERENDUM_COST = 100_000
REFERENDUM_DURATION = 72 * 3600
MOTION_SIGNATURES_NEEDED = 5
MOTION_VOTE_DURATION = 48 * 3600
MOTION_MAJORITY = 0.5
MOTION_COOLDOWN = 3 * 86400
# ── Gouvernement : chaque ministre est un GRADE de l'Administration (faction « mairie ») et dirige une faction.
#   faction = faction d'État que le ministre dirige (nomme son chef, lui verse des dotations du Trésor).
#   « Économie » ne dirige pas de faction : il fixe l'impôt sur la fortune et finance l'Administration elle-même.
MINISTRIES = {
    "Intérieur": {"faction": "police",  "emoji": "🚓", "power": "nomme le DG de la Police et lui verse des dotations"},
    "Défense":   {"faction": "armee",   "emoji": "🎖️", "power": "nomme le DG de l'Armée et lui verse des dotations"},
    "Justice":   {"faction": "justice", "emoji": "⚖️", "power": "nomme les juges et verse des dotations à la Justice"},
    "Santé":     {"faction": "sante",   "emoji": "🏥", "power": "nomme le PDG de la Santé publique et lui verse des dotations"},
    "Économie":  {"faction": "mairie",  "emoji": "💰", "power": "fixe l'impôt sur la fortune et finance l'Administration"},
}
CABINET_POSITIONS = list(MINISTRIES)
# Grades de l'Administration (index dans GOV_FACTIONS["mairie"]["ranks"])
ADMIN_RANK_DIRECTOR = 3
ADMIN_RANK_MINISTER = 5
ADMIN_RANK_PRESIDENT = 6
# ── Règles politiques : quorums, mandat, destitution ──────────────────────────────────────────
# Quorum d'une élection = ELECTION_QUORUM × joueurs inscrits, borné entre MIN et MAX (les comptes dormants ne bloquent pas le vote).
ELECTION_QUORUM_MIN_VOTES = 3
ELECTION_QUORUM_MAX_VOTES = 50
POLL_MIN_VOTES = 3                # lois et référendums : votes minimum pour être valables
PRESIDENT_TERM = 30 * 86400       # mandat du Président : 30 jours de jeu, puis nouvelle élection
# Destitution (Président ou ministre)
MOTION_COST = 50_000              # coût pour lancer une motion (versé au Trésor) : évite le harcèlement
MOTION_SIGNATURE_DURATION = 48 * 3600   # délai pour réunir les signatures, sinon la motion expire
MOTION_IMMUNITY = 2 * 86400       # un nouveau Président / ministre est protégé pendant 2 jours de jeu
MOTION_TARGET_COOLDOWN = 7 * 86400      # après une motion rejetée/expirée, pas de nouvelle motion contre lui pendant 7 jours
MOTION_QUORUM = 0.10              # votes minimum = 10 % des joueurs inscrits…
MOTION_MIN_VOTES = 5              # …au moins 5…
MOTION_MAX_VOTES = 50             # …au plus 50
MOTION_MAJORITY_PRESIDENT = 0.6   # destituer le Président demande 60 % ; un ministre : MOTION_MAJORITY (50 %)
# Impôt sur la fortune : le Ministre de l'Économie (ou le Président) règle un coefficient sur le barème.
TAX_FACTOR_MIN = 0.5
TAX_FACTOR_MAX = 1.5
TAX_FACTOR_STEP = 0.25
TAX_FACTOR_COOLDOWN = 86400      # 1 jour de jeu entre deux changements
DEFAULT_CONSTITUTION = "Le pouvoir émane des joueurs. Les élections sont libres. Les lois sont votées par tous."

# ─── Horloge du jeu (UNE SEULE pour tous les joueurs) ─────────────────────────
# Depuis le 08/11/2026 00:00 UTC : 1 jour de jeu = 24 h réelles (UTC+0) — le temps de jeu
# suit exactement le temps réel. Avant cette date, le jeu a connu une phase accélérée
# (24 h de jeu = 10 h réelles, x2,4) ; cette ancienne vitesse reste figée dans
# OLD_GAME_DAY_REAL_SECONDS pour que les dates et cooldowns déjà en base restent valides
# (voir RATE_CHANGE_REAL plus bas et utils/gametime.py — aucune migration, aucun saut).
# Tout ce qui touche au jeu (cooldowns, durées, prison, pousse, élections, date, saison…) est
# exprimé en SECONDES DE JEU : 3600 = 1 h de jeu, 86400 = 1 jour de jeu.
# Voir utils/gametime.py (game_now(), real_now(), game_datetime()…).
OLD_GAME_DAY_REAL_SECONDS = 10 * 3600       # ⚠️ figé pour toujours : vitesse d'AVANT le 08/11/2026
GAME_DAY_REAL_SECONDS = int(os.getenv("GAME_DAY_REAL_SECONDS", str(24 * 3600)))
TIME_MULTIPLIER = 86400 / GAME_DAY_REAL_SECONDS            # = 1 (1 s réelle = 1 s de jeu)

# ── Cooldowns « travailler » et « bonus quotidien » ──────────────────────────────────────────
# • TRAVAILLER (et missions freelance) : 1 h DE JEU avant de reprendre. Temps de jeu pur.
#   (= 25 min réelles pendant la phase accélérée ; = 1 h réelle depuis le 08/11/2026.)
# • BONUS QUOTIDIEN : SEULE exception du jeu — il se récupère toutes les 24 h RÉELLES (et non 24 h de jeu).
#   Comme tous les cooldowns sont stockés sur l'horloge du jeu, on l'écrit en secondes réelles puis on le
#   convertit en secondes de jeu avec le taux ACTUEL (TIME_MULTIPLIER).
WORK_COOLDOWN = 3600                  # travailler : 1 h de jeu
DAILY_COOLDOWN_REAL = 24 * 3600       # bonus quotidien : 24 heures RÉELLES
DAILY_COOLDOWN = int(round(DAILY_COOLDOWN_REAL * TIME_MULTIPLIER))   # = 24 h réelles, en secondes de JEU
# Point d'ancrage (timestamp UNIX réel) où l'horloge de jeu coïncide avec l'horloge réelle.
# Avant ce point rien ne change ; après, le temps de jeu s'écoule 2,4× plus vite (phase accélérée).
# ⚠️ NE PLUS JAMAIS CHANGER après la mise en ligne : ça décalerait toutes les dates et cooldowns.
# Défaut = 11/10/2026 00:00 UTC. Pour un NOUVEAU serveur, mets la date de lancement.
GAME_EPOCH_REAL = int(os.getenv("GAME_EPOCH_REAL", "1791676800"))
# Deuxième point d'ancrage : fin de la phase accélérée, retour à 1 jour = 24 h réelles (UTC+0).
# Avant ce point : vitesse OLD_GAME_DAY_REAL_SECONDS (x2,4). À partir de ce point : la date de jeu
# est RECALÉE sur la date réelle (temps de jeu = temps réel, exactement, pour toujours après) —
# sans ça, la phase accélérée aurait laissé la date de jeu dériver loin devant la vraie date.
# ⚠️ Cela provoque UN SEUL saut, une seule fois, pile à cet instant (cooldowns/dates en cours dans
# cette fenêtre peuvent être repoussés) — c'est voulu, pour repartir sur une base 100 % réelle.
# ⚠️ NE PLUS JAMAIS CHANGER après la mise en ligne, pour la même raison que GAME_EPOCH_REAL.
# Défaut = 08/11/2026 00:00 UTC.
RATE_CHANGE_REAL = int(os.getenv("RATE_CHANGE_REAL", "1794096000"))

# ─── Casino horaire ───────────────────────────────────────────────
CASINO_OPEN_HOUR = 17
CASINO_CLOSE_HOUR = 5

PRODUCT_EFFECTS = {
    "heal":    {"base_cost": 2000000,   "desc": "Restaure de la santé"},
    "energy":  {"base_cost": 1500000,   "desc": "Restaure de l'énergie"},
    "xp":      {"base_cost": 3000000,   "desc": "Donne de l'XP"},
    "money":   {"base_cost": 2500000,   "desc": "Donne de l'argent"},
    "buff":    {"base_cost": 5000000,   "desc": "Boost temporaire (stat) : à définir"},
}

# ═══════════════════════════════════════════════════════════════════════════
#                    HIÉRARCHIE : DIEUX (Leads) ET DEMI-DIEUX (Admins)
# ═══════════════════════════════════════════════════════════════════════════

def _parse_ids(env_var: str) -> list[int]:
    raw = os.getenv(env_var, "")
    if not raw:
        return []
    ids = []
    for x in raw.split(","):
        x = x.strip()
        if x.isdigit():
            ids.append(int(x))
    return ids


LEAD_PRINCIPAL_IDS: list[int] = _parse_ids("LEAD_PRINCIPAL_IDS")
LEAD_STUDIO_IDS: list[int] = _parse_ids("LEAD_STUDIO_IDS")
LEAD_INFLUENCEURS_IDS: list[int] = _parse_ids("LEAD_INFLUENCEURS_IDS")
LEAD_STAFF_GLOBAL_IDS: list[int] = _parse_ids("LEAD_STAFF_GLOBAL_IDS")
GAME_LEADER_IDS: list[int] = _parse_ids("GAME_LEADER_IDS")
ADMIN_N2_IDS: list[int] = _parse_ids("ADMIN_N2_IDS")
ADMIN_N1_IDS: list[int] = _parse_ids("ADMIN_N1_IDS")

# ✅ Fix #10 : fusion avec LEGACY_ADMIN_IDS (issu de la var ADMIN_IDS du .env)
ADMIN_IDS: list[int] = list(set(
    LEAD_PRINCIPAL_IDS +
    LEAD_STUDIO_IDS +
    LEAD_INFLUENCEURS_IDS +
    LEAD_STAFF_GLOBAL_IDS +
    GAME_LEADER_IDS +
    ADMIN_N2_IDS +
    ADMIN_N1_IDS +
    LEGACY_ADMIN_IDS
))

ROLE_LABELS: dict[str, str] = {
    "LEAD_PRINCIPAL":    "👑 Dieu Suprême (Lead Principal)",
    "LEAD_STUDIO":       "⚒️ Dieu Forgeron (Lead Studio)",
    "LEAD_INFLUENCEURS": "📣 Messager des Foules (Lead Influenceurs)",
    "LEAD_STAFF_GLOBAL": "🌟 Dieu Gardien (Lead Staff)",
    "GAME_LEADER":       "⚖️ Dieu de l'Ordre (Game Leader)",
    "ADMIN_N2":          "🔱 Demi-dieu Juge (Admin N2)",
    "ADMIN_N1":          "🕊️ Demi-dieu Messager (Admin N1)",
    "PLAYER":            "👤 Mortel",
}

ROLE_HIERARCHY: list[str] = [
    "PLAYER",
    "ADMIN_N1",
    "ADMIN_N2",
    "GAME_LEADER",
    "LEAD_STAFF_GLOBAL",
    "LEAD_STUDIO",
    "LEAD_PRINCIPAL",
]


# Rôles TRANSVERSES (charte GAME FRENCH) : ils ne commandent pas le staff et n'ont aucun pouvoir de sanction.
#   • Lead Studio      : technique ; niveau 0 (aucune commande de modération), seulement ses commandes techniques.
#   • Lead Influenceurs: droits spécifiques limités à son cadre (campagnes) ; niveau joueur partout ailleurs.
TRANSVERSE_ROLES = ("LEAD_STUDIO", "LEAD_INFLUENCEURS")
_TRANSVERSE_LEVEL = {"LEAD_STUDIO": 0, "LEAD_INFLUENCEURS": 0}   # niveau 0 : aucune commande staff, sauf celles de leur section


def role_level(role: str) -> int:
    if role in _TRANSVERSE_LEVEL:
        return _TRANSVERSE_LEVEL[role]
    try:
        return ROLE_HIERARCHY.index(role)
    except ValueError:
        return 0


def can_manage_role(actor_role: str, target_role: str) -> bool:
    if actor_role in TRANSVERSE_ROLES:
        return False
    if actor_role == "LEAD_PRINCIPAL":
        return target_role != "LEAD_PRINCIPAL"
    if actor_role == "LEAD_STAFF_GLOBAL":
        return target_role in ("GAME_LEADER", "ADMIN_N2", "ADMIN_N1")
    if actor_role == "GAME_LEADER":
        return target_role in ("ADMIN_N2", "ADMIN_N1")
    return False

# ── Staff (d'après le document GAME FRENCH — seule la partie « en jeu ») ──────────────────
CAMPAIGN_MAX_PENDING = 3      # campagnes en attente de validation par auteur
CAMPAIGN_MIN_GAP_HOURS = 12   # délai minimum entre deux campagnes diffusées
STAFF_APPEAL_DAYS = 7     # recours auprès du Lead Principal après une révocation (jours RÉELS)
STAFF_TIMEZONE = "Europe/Paris"   # fuseau des créneaux des admins (temps RÉEL, pas l'horloge de jeu)
# Créneaux des Admins N1/N2 (6 h chacun) : lettre -> (heure de début, heure de fin, libellé)
STAFF_SLOTS: dict[str, tuple[int, int, str]] = {
    "A": (6, 12, "Matin"), "B": (12, 18, "Après-midi"), "C": (18, 24, "Soirée"), "D": (0, 6, "Nuit"),
}

# ── Identité du jeu (point unique pour renommer le jeu) ──────────────────
GAME_NAME = "EARTH ANGEL RP"

# ── Monnaie du jeu ───────────────────────────────────────────────────────
# 1 €A = 1 FCFA. Tous les prix du jeu sont pensés à l'échelle du FCFA.
CURRENCY_SYMBOL = "€A"

# ── Liens officiels (modifie-les ici : ils sont utilisés partout) ─────────
BOT_LINK = "https://t.me/EARTHANGELRPBOT"
GROUP_LINK = "https://t.me/EARTHANGELRP"
UPDATES_LINK = "https://t.me/GameFrench"
SUPPORT_LINK = "https://t.me/GameFrenchSupport"
DEV_LINK = "https://t.me/GameFrench"          # Studio = Studio de Game French
CREATOR_LINK = "https://t.me/GameFrench"
GROUP_AUTH_CONTACT = "@mauridieu"                 # à contacter pour faire autoriser un groupe
# Groupes autorisés dès le départ (IDs séparés par des virgules, ex : -1001234567890). Les autres se gèrent
# avec /autoriser_groupe et /retirer_groupe.
ALLOWED_GROUP_IDS: list[int] = [int(x) for x in os.getenv("ALLOWED_GROUP_IDS", "").replace(" ", "").split(",") if x.lstrip("-").isdigit()]

# ── Univers RP : EARTH ANGEL ──────────────────────────────────────────────
GAME_TAGLINE = "Le Blanc et le Noir : qui remportera la partie ?"

# Histoire (HTML Telegram). Une seule source : start, aide et pages d'univers l'utilisent.
GAME_LORE = (
    "Depuis la nuit des temps, deux faces se répondent comme un reflet dans le miroir : "
    "<b>le Bien et le Mal</b>.\n\n"
    "Les <b>Anges Célestes</b> et les <b>Anges Démoniaques</b> se livrent une guerre sans fin. "
    "Des démons se répandent et s'élèvent au rang des célestes ; des célestes trahissent, "
    "abandonnent la lumière et chutent chez les démoniaques. Aucun camp n'est jamais acquis.\n\n"
    "Cette guerre n'a pas épargné le cœur des hommes : <b>nous, les humains</b>, portons "
    "ces deux faces en nous. La bataille a fini par descendre sur Terre.\n\n"
    "Qui saura consumer son prochain, remporter la victoire, puis bâtir et faire vivre son propre "
    "monde ? Tout ressemble à une partie d'échecs — <b>le Blanc et le Noir</b>. Qui l'emportera ?\n\n"
    "C'est ici que tu apparais : dans le monde d'<b>EARTH ANGEL</b>.\n"
    "Les vainqueurs domineront et deviendront des anges, pour poursuivre la bataille "
    "au <b>Ciel des Cieux</b>, où tous repartent à égalité."
)

# Les 3 phases du RP : (icône, titre, description, disponible ?)
GAME_PHASES = [
    ("🧍", "Phase 1 — L'Humain",
     "Tu apparais sur Terre en simple mortel. Tu bâtis ta vie, ta fortune et ta réputation.", True),
    ("😇", "Phase 2 — L'Élu",
     "Un tournoi désigne les élus. Un ange veille alors sur toi et te donne des pouvoirs : "
     "des avantages que les autres mortels n'ont pas.", False),
    ("👼", "Phase 3 — L'Ange",
     "Un second tournoi te fait devenir ange à ton tour, avec de nouveaux avantages, "
     "pour continuer la bataille au Ciel des Cieux.", False),
]

# Hiérarchie divine (affichée dans l'aide)
GAME_PANTHEON = (
    "🌟 <b>Les Dieux</b> (Leads) : ils gouvernent le monde et nomment les demi-dieux.\n"
    "🔱 <b>Les Demi-dieux</b> (Admins) : ils veillent sur les mortels, jugent et guident."
)


# ─── Monde RP : lieux et déplacements ────────────────────────────────────────
# Chaque lieu appartient à une zone ; la distance (km) dépend des zones.
# Les durées de trajet sont en SECONDES DE JEU (voir HORLOGE_DU_JEU.md).
LOCATIONS = {
    "maison":       {"name": "Domicile",          "emoji": "🏠", "zone": "residentiel"},
    "travail":      {"name": "Lieu de travail",   "emoji": "🏢", "zone": "affaires"},
    "casino":       {"name": "Casino",            "emoji": "🎰", "zone": "centre"},
    "banque":       {"name": "Banque",            "emoji": "🏦", "zone": "affaires"},
    "marche":       {"name": "Marché",            "emoji": "🛒", "zone": "centre"},
    "hopital":      {"name": "Grand hôpital",     "emoji": "🏥", "zone": "centre"},
    "hopital_residences": {"name": "Hôpital des Résidences", "emoji": "🏥", "zone": "residentiel"},
    "hopital_affaires":   {"name": "Hôpital des Affaires",   "emoji": "🏥", "zone": "affaires"},
    "hopital_sud":        {"name": "Hôpital du Sud",         "emoji": "🏥", "zone": "sud"},
    "hopital_aeroport":   {"name": "Hôpital de l'Aéroport",  "emoji": "🏥", "zone": "periphe"},
    "mairie":       {"name": "Mairie",            "emoji": "🏛️", "zone": "centre"},
    "commissariat": {"name": "Commissariat central", "emoji": "🚓", "zone": "centre"},
    "commissariat_residences": {"name": "Poste de police des Résidences", "emoji": "🚓", "zone": "residentiel"},
    "commissariat_affaires":   {"name": "Poste de police des Affaires",   "emoji": "🚓", "zone": "affaires"},
    "commissariat_sud":        {"name": "Poste de police du Sud",         "emoji": "🚓", "zone": "sud"},
    "commissariat_aeroport":   {"name": "Poste de police de l'Aéroport",  "emoji": "🚓", "zone": "periphe"},
    "tribunal":     {"name": "Palais de justice", "emoji": "⚖️", "zone": "centre"},
    "qg_armee":     {"name": "Quartier général de l'armée", "emoji": "🎖️", "zone": "centre"},
    "caserne_residences": {"name": "Caserne des Résidences", "emoji": "🎖️", "zone": "residentiel"},
    "caserne_affaires":   {"name": "Caserne des Affaires",   "emoji": "🎖️", "zone": "affaires"},
    "caserne_sud":        {"name": "Caserne du Sud",         "emoji": "🎖️", "zone": "sud"},
    "caserne_aeroport":   {"name": "Caserne de l'Aéroport",  "emoji": "🎖️", "zone": "periphe"},
    "quartier_sud": {"name": "Quartier sud",      "emoji": "🌆", "zone": "sud"},
    "aeroport":     {"name": "Aéroport",          "emoji": "✈️", "zone": "periphe"},
    "restaurant":   {"name": "Restaurant",        "emoji": "🍽️", "zone": "centre"},
}
START_LOCATION = "maison"

# Distance en km entre zones (symétrique). Même zone = SAME_ZONE_KM.
SAME_ZONE_KM = 0.6
ZONE_DISTANCES_KM = {
    ("residentiel", "affaires"): 4,
    ("residentiel", "centre"):   3,
    ("residentiel", "sud"):      6,
    ("residentiel", "periphe"):  14,
    ("affaires",    "centre"):   2,
    ("affaires",    "sud"):      7,
    ("affaires",    "periphe"):  12,
    ("centre",      "sud"):      5,
    ("centre",      "periphe"):  11,
    ("sud",         "periphe"):  10,
}
WALK_SPEED_KMH = 5
WALK_ENERGY_PER_KM = 1.0          # énergie perdue par km à pied
VEHICLE_FUEL_PER_KM = 0.25        # carburant consommé par km (véhicules à moteur)
VEHICLE_WEAR_PER_KM = 0.15        # usure (condition) par km
VEHICLE_MIN_CONDITION = 10        # en dessous : le véhicule ne démarre plus
# Véhicules utilisables en ville (pas de yacht / jet / hélico pour aller au casino).
LAND_VEHICLES = ("Vélo", "Scooter", "Voiture", "SUV", "Sport", "Limousine", "Moto sport")


# ─── Santé publique : hôpitaux, postes, chaîne de médicaments, assurances ────
# Tout ce bloc est modifiable à la main. Les durées sont en SECONDES DE JEU (3600 = 1 h de jeu),
# y compris les lits (SANTE_BED_*).
SANTE_FACTION = "sante"
SANTE_GRAND = "grand"                     # id du grand hôpital (dirigé par le PDG)
SANTE_HOSPITALS = {
    "grand":      {"name": "Grand hôpital",          "location": "hopital",            "kind": "grand", "beds": 10},
    "residences": {"name": "Hôpital des Résidences", "location": "hopital_residences", "kind": "petit", "beds": 3},
    "affaires":   {"name": "Hôpital des Affaires",   "location": "hopital_affaires",   "kind": "petit", "beds": 3},
    "sud":        {"name": "Hôpital du Sud",         "location": "hopital_sud",        "kind": "petit", "beds": 3},
    "aeroport":   {"name": "Hôpital de l'Aéroport",  "location": "hopital_aeroport",   "kind": "petit", "beds": 3},
}
# Postes : level = hiérarchie ; salary_h = salaire PAR HEURE DE JEU (payé par le coffre de la faction) ;
# role = ce que le poste peut faire : gather (récolte) · lab (laboratoire) · industry (industrie) ·
# care (soins/ambulance) · head (direction : DG d'un petit hôpital, PDG du grand).
SANTE_POSTS = {
    "recolteur":   {"name": "Récolteur de ressources",  "emoji": "🌿", "level": 0, "salary_h": 250,   "role": "gather",   "heal": 0},
    "ambulancier": {"name": "Ambulancier",              "emoji": "🚑", "level": 1, "salary_h": 350,   "role": "care",     "heal": 20},
    "technicien":  {"name": "Technicien de laboratoire", "emoji": "🧪", "level": 1, "salary_h": 400,   "role": "lab",      "heal": 0},
    "operateur":   {"name": "Opérateur industriel",     "emoji": "🏭", "level": 1, "salary_h": 400,   "role": "industry", "heal": 0},
    "infirmier":   {"name": "Infirmier",                "emoji": "🩺", "level": 2, "salary_h": 500,   "role": "care",     "heal": 30},
    "medecin":     {"name": "Médecin",                  "emoji": "👨‍⚕️", "level": 3, "salary_h": 900,   "role": "care",     "heal": 45},
    "chirurgien":  {"name": "Chirurgien",               "emoji": "🥼", "level": 4, "salary_h": 1_400, "role": "care",     "heal": 60},
    "dg":          {"name": "Directeur général (DG)",   "emoji": "👔", "level": 5, "salary_h": 2_200, "role": "head",     "heal": 30},
    "pdg":         {"name": "PDG",                      "emoji": "👑", "level": 6, "salary_h": 3_200, "role": "head",     "heal": 30},
}
SANTE_HEAD_LEVEL = 5                       # niveau minimal pour recruter / promouvoir / renvoyer
SANTE_ASSIGNABLE = tuple(k for k, v in SANTE_POSTS.items() if v["role"] != "head")
# Anciens grades de la faction (0..5) → poste (migration sans perte ; jamais de direction automatique)
SANTE_LEGACY_RANK_TO_POST = {0: "recolteur", 1: "infirmier", 2: "medecin", 3: "chirurgien", 4: "chirurgien", 5: "chirurgien"}
SANTE_PAY_ONLY_ON_DUTY = False             # True : seuls les employés EN SERVICE touchent leur salaire horaire

# Ressources → laboratoire → industrie → médicaments en vente
SANTE_RAW = {"plantes": ("Plantes médicinales", "🌿"), "mineraux": ("Minéraux", "🪨"), "eau": ("Eau pure", "💧")}
SANTE_INTER = {"extrait": ("Extrait végétal", "🧴"), "principe": ("Principe actif", "⚗️")}
SANTE_GATHER = {"cooldown": 1200, "energy": 10, "yield": (5, 9)}          # par récolte
SANTE_LAB_COOLDOWN = 900
SANTE_INDUSTRY_COOLDOWN = 900
SANTE_LAB_RECIPES = {   # intrants → produits intermédiaires
    "extrait":  {"in": {"plantes": 3, "eau": 1},  "out": 2},
    "principe": {"in": {"mineraux": 3, "eau": 1}, "out": 2},
}
SANTE_MED_RECIPES = {   # intermédiaires → médicaments (mis en vente automatiquement)
    "Aspirine":      {"in": {"extrait": 1},                 "out": 6},
    "Antibiotiques": {"in": {"extrait": 1, "principe": 1},  "out": 4},
    "Chirurgie":     {"in": {"extrait": 2, "principe": 3},  "out": 1},
    "Greffe":        {"in": {"extrait": 4, "principe": 6},  "out": 1},
}
SANTE_STOCK_CAPS = {"raw": 500, "inter": 300, "med": 200}

# Soins
SANTE_AMBULANCE_COOLDOWN = 3600            # un appel gratuit par heure de jeu et par joueur
SANTE_CALL_TTL = 1800                      # un appel non pris expire après 30 min de jeu
SANTE_CONSULT_COST = DOCTOR_BASE           # consultation à l'hôpital (avant assurance) → coffre
SANTE_CONSULT_BONUS = 10                   # soin supplémentaire quand on est soigné sur place
SANTE_PAIR_LIMIT = (2, 3600)               # anti-triche : max 2 soins du même soignant au même patient / heure de jeu
SANTE_BED_MIN = 120                        # il faut rester AU MOINS 2 min DE JEU sur le lit pour guérir
SANTE_BED_MAX = 600                        # au bout de 10 min DE JEU le lit est libéré automatiquement
SANTE_BED_HEAL = {"health": 50, "energy": 30, "stress": -20}

# Assurances : réduisent le prix des médicaments et des consultations (1 mois de jeu)
INSURANCE_PLANS = {
    "basique":  {"cost": 5_000,     "coverage": 0.3, "claims_limit": 3,  "emoji": "🔵"},
    "standard": {"cost": 20_000,    "coverage": 0.5, "claims_limit": 5,  "emoji": "🟡"},
    "premium":  {"cost": 100_000,   "coverage": 0.7, "claims_limit": 10, "emoji": "🟢"},
    "vip":      {"cost": 1_000_000, "coverage": 0.9, "claims_limit": 20, "emoji": "💎"},
}


def _sante_ranks() -> list[tuple[str, int]]:
    """Grades génériques de la faction (un par niveau) — le détail vient du poste (SANTE_POSTS)."""
    out = []
    for lvl in sorted({p["level"] for p in SANTE_POSTS.values()}):
        first = next(p for p in SANTE_POSTS.values() if p["level"] == lvl)
        out.append((first["name"], first["salary_h"]))
    return out


# ─── Ordre public : Police & Armée ───────────────────────────────────────────
# Même mécanique que la Santé publique : 5 postes (1 central + 4 de quartier), un coffre de faction,
# salaires PAR HEURE DE JEU. Tout est modifiable ici. TOUTES les durées sont en secondes de JEU
# (neutralisation, menottes, fuite, interrogatoire, prison…), comme le reste du jeu.
ORDRE_FACTIONS = ("police", "armee", "justice")
ORDRE_STATIONS = {
    "police": {
        "central":    {"name": "Commissariat central",            "location": "commissariat",            "kind": "central"},
        "residences": {"name": "Poste de police des Résidences",  "location": "commissariat_residences", "kind": "poste"},
        "affaires":   {"name": "Poste de police des Affaires",    "location": "commissariat_affaires",   "kind": "poste"},
        "sud":        {"name": "Poste de police du Sud",          "location": "commissariat_sud",        "kind": "poste"},
        "aeroport":   {"name": "Poste de police de l'Aéroport",   "location": "commissariat_aeroport",   "kind": "poste"},
    },
    "armee": {
        "central":    {"name": "Quartier général",                "location": "qg_armee",                "kind": "central"},
        "residences": {"name": "Caserne des Résidences",          "location": "caserne_residences",      "kind": "poste"},
        "affaires":   {"name": "Caserne des Affaires",            "location": "caserne_affaires",        "kind": "poste"},
        "sud":        {"name": "Caserne du Sud",                  "location": "caserne_sud",             "kind": "poste"},
        "aeroport":   {"name": "Caserne de l'Aéroport",           "location": "caserne_aeroport",        "kind": "poste"},
    },
    "justice": {
        "central":    {"name": "Palais de justice",               "location": "tribunal",                "kind": "central"},
    },
}
# role : base (consulte) · patrol (liste des joueurs, neutraliser, menotter, interroger) ·
#        enquete (patrol + mini-jeu d'enquête) · head (direction : chef de poste, DG)
ORDRE_POSTS = {
    "police": {
        "cadet":      {"name": "Cadet",                       "emoji": "🎓", "level": 0, "salary_h": 350,   "role": "base"},
        "agent":      {"name": "Agent",                       "emoji": "👮", "level": 1, "salary_h": 500,   "role": "patrol"},
        "sergent":    {"name": "Sergent",                     "emoji": "🎖️", "level": 2, "salary_h": 700,   "role": "patrol"},
        "enqueteur":  {"name": "Enquêteur",                   "emoji": "🕵️", "level": 2, "salary_h": 750,   "role": "enquete"},
        "lieutenant": {"name": "Lieutenant",                  "emoji": "⭐", "level": 3, "salary_h": 1_000, "role": "patrol"},
        "capitaine":  {"name": "Capitaine enquêteur",         "emoji": "🔎", "level": 4, "salary_h": 1_300, "role": "enquete"},
        "chef":       {"name": "Commandant de poste",         "emoji": "🛡️", "level": 5, "salary_h": 1_800, "role": "head"},
        "dg":         {"name": "Directeur général (DG)",      "emoji": "👔", "level": 6, "salary_h": 2_800, "role": "head"},
    },
    "armee": {
        "recrue":     {"name": "Recrue",                      "emoji": "🪖", "level": 0, "salary_h": 350,   "role": "base"},
        "soldat":     {"name": "Soldat",                      "emoji": "🎖️", "level": 1, "salary_h": 500,   "role": "patrol"},
        "caporal":    {"name": "Caporal",                     "emoji": "🎖️", "level": 2, "salary_h": 650,   "role": "patrol"},
        "armurier":   {"name": "Armurier",                    "emoji": "🛠️", "level": 2, "salary_h": 750,   "role": "arms"},
        "sergent":    {"name": "Sergent",                     "emoji": "⭐", "level": 3, "salary_h": 800,   "role": "patrol"},
        "lieutenant": {"name": "Lieutenant",                  "emoji": "🌟", "level": 4, "salary_h": 1_100, "role": "patrol"},
        "chef":       {"name": "Commandant de caserne",       "emoji": "🛡️", "level": 5, "salary_h": 1_800, "role": "head"},
        "dg":         {"name": "Directeur général (DG)",      "emoji": "👔", "level": 6, "salary_h": 2_800, "role": "head"},
    },
}
ORDRE_POSTS["justice"] = {
    # Justice : 2 postes seulement. Le juge (nommé par le Game Leader) recrute les avocats, juge, fixe les cautions.
    "avocat": {"name": "Avocat",  "emoji": "👨‍⚖️", "level": 0, "salary_h": 700,   "role": "lawyer"},
    "juge":   {"name": "Juge",    "emoji": "⚖️",  "level": 1, "salary_h": 2_200, "role": "head"},
}
ORDRE_BASE_POST = {"police": "cadet", "armee": "recrue", "justice": "avocat"}       # poste d'entrée
ORDRE_CENTRAL_HEAD = {"police": "dg", "armee": "dg", "justice": "juge"}             # direction du lieu central
ORDRE_MULTI_HEAD = ("justice",)            # plusieurs juges possibles (pas de remplacement à la nomination)
ORDRE_DG_POST = "dg"                                           # nommé par le Game Leader (ou plus)
ORDRE_CHIEF_POST = "chef"                                      # un par poste secondaire, nommé par le DG
ORDRE_HEAD_LEVEL = 5                                           # niveau minimal pour recruter / promouvoir / renvoyer
ORDRE_POWER_LEVEL = 1                                          # niveau minimal pour neutraliser / menotter / interroger
ORDRE_PAY_ONLY_ON_DUTY = False
ORDRE_LEGACY_RANK_TO_POST = {
    "justice": {0: "avocat", 1: "avocat", 2: "avocat", 3: "avocat", 4: "avocat", 5: "avocat"},  # anciens grades (0..5) → poste, sans direction automatique
    "police": {0: "cadet", 1: "agent", 2: "sergent", 3: "lieutenant", 4: "lieutenant", 5: "lieutenant"},
    "armee":  {0: "recrue", 1: "soldat", 2: "caporal", 3: "sergent", 4: "lieutenant", 5: "lieutenant"},
}

# Paramètres de jeu (équilibrage décidé ici)
ORDRE = {
    # Fuite après un crime réussi CONTRE LE BOT : l'enquête n'est possible qu'après ce délai (secondes de jeu)
    "flee_delay": 600, "hide_delay": 1200, "hide_cooldown": 1800, "hide_chance": 0.5,
    # Pouvoirs (secondes de jeu)
    "stun_seconds": 30, "stun_cooldown_target": 120,
    "cuffs_max": 3, "cuffs_seconds": 600, "interro_seconds": 600, "army_decision_seconds": 30,
    "army_exec_cash_loss": 0.25,            # part de l'argent liquide perdue si l'armée exécute
    # Prison (secondes de jeu) : maximum absolu 60 min
    "jail_max": 3600, "jail_bot": (900, 1800), "jail_player": (1800, 3600), "jail_report": (900, 1800),
    "jail_choices": (900, 1800, 2700, 3600),
    # Signalements
    "report_daily_max": 3, "report_ttl": 86400, "report_false_karma": -3,
    # Mini-jeu d'enquête : mémoriser une séquence puis la reproduire (très difficile)
    "mg_len": 8, "mg_show": 8, "mg_attempts": 2, "mg_symbols": ("🔴", "🟢", "🔵", "🟡", "🟣", "🟠"),
    "mg_good_karma": 100, "mg_good_karma_extra": 2, "mg_recidivist_crimes": 10, "mg_recidivist_less": 1,
    # Anti-doublon : une même victime ne peut pas subir 2 crimes en moins de ce délai (secondes de jeu)
    "victim_protect": 3600,
    "work_book_events": 8, "interview_seconds": 900,
}

# ─── Justice : dossiers judiciaires, caution, procès, avocats ───────────────
JUSTICE = {
    "sentence_max": 10_800,      # peine maximale d'un juge (secondes de JEU = 3 h)
    "bail_max": 500_000, "fine_max": 300_000,
    "lawyer_fee": 8_000,         # honoraires versés à l'avocat choisi
    "plead_base": 0.50, "plead_per_intelligence": 0.03, "plead_reduction": 0.35,   # plaidoirie réussie : -35 % sur peine / caution
    "plead_skill": "Intelligence",
    "warrant_ttl": 86_400,
}

# ─── Armes : marché noir (munitions limitées), chambres d'armes de l'armée et de la police ───
WEAPONS = {
    "pistolet":        {"name": "Pistolet",           "emoji": "🔫", "price": 25_000,  "mag": 12, "ammo_price": 250,
                        "bonus": 0.08, "per_use": 1, "firearm": True,  "market": True,  "craft": 9_000},
    "fusil_pompe":     {"name": "Fusil à pompe",      "emoji": "🔫", "price": 60_000,  "mag": 8,  "ammo_price": 700,
                        "bonus": 0.12, "per_use": 2, "firearm": True,  "market": True,  "craft": 22_000},
    "fusil_assaut":    {"name": "Fusil d'assaut",     "emoji": "🔫", "price": 150_000, "mag": 30, "ammo_price": 500,
                        "bonus": 0.18, "per_use": 3, "firearm": True,  "market": True,  "craft": 55_000},
    "fusil_precision": {"name": "Fusil de précision", "emoji": "🎯", "price": 300_000, "mag": 5,  "ammo_price": 2_500,
                        "bonus": 0.25, "per_use": 1, "firearm": True,  "market": True,  "craft": 110_000},
    "taser":           {"name": "Taser",              "emoji": "⚡", "price": 0,       "mag": 6,  "ammo_price": 0,
                        "bonus": 0.0,  "per_use": 1, "firearm": False, "market": False, "craft": 4_000},
}
WEAPON_REQUIRED_CRIMES = ("Braquage", "Hold-up banque")   # crimes sur le bot qui exigent une arme à feu équipée
WEAPON_MAX_MAGS = 4              # un joueur porte au plus 4 chargeurs de munitions par arme
WEAPON_RIPOSTE = 0.10            # une victime armée (avec munitions) réduit de 10 pts les chances du criminel
WEAPON_STUN_MULT = 1.5           # un agent armé neutralise 50 % plus longtemps (consomme 1 munition)
ARMS = {"craft_cooldown": 120, "ammo_craft_ratio": 0.15, "max_stock": 200}   # coût d'un chargeur = 15 % du prix de craft
ARMS_CRAFT_ROLES = ("arms", "head")      # armée : armuriers + direction
ARMS_DELIVER_ROLES = ("arms", "head")    # livrent à la police

# Crimes contre des JOUEURS (réservés aux membres d'un gang, comme les crimes contre le bot)
ORDRE_PLAYER_CRIMES = {
    "vol":     {"name": "Vol à la tire",      "emoji": "🧤", "success": 0.55, "pct": (0.05, 0.15), "cap": 60_000,
                "karma": -10, "jail_idx": 0.2, "source": "cash",  "need": None},
    "hack":    {"name": "Piratage bancaire",  "emoji": "💻", "success": 0.35, "pct": (0.04, 0.10), "cap": 250_000,
                "karma": -15, "jail_idx": 0.6, "source": "bank",  "need": ("Technique", 2)},
    "meurtre": {"name": "Attaque mortelle",   "emoji": "🗡️", "success": 0.25, "pct": (0.0, 0.0),   "cap": 0,
                "karma": -60, "jail_idx": 1.0, "source": "none",  "need": None},
}
# Défense anti-piratage UNIQUE (durée en jours de jeu ; bloque les hacks sur le joueur)
ANTI_HACK_PLANS = {
    "pare_feu": {"name": "Pare-feu anti-piratage", "emoji": "🛡️", "cost": 80_000, "reduction": 1.0, "days": 7},
}
ANTI_HACK_DAY_GAME_SECONDS = 86400


def _ordre_ranks(faction: str) -> list[tuple[str, int]]:
    """Grades génériques de la faction (un par niveau) — le détail vient du poste (ORDRE_POSTS)."""
    posts = ORDRE_POSTS[faction]
    out = []
    for lvl in sorted({p["level"] for p in posts.values()}):
        first = next(p for p in posts.values() if p["level"] == lvl)
        out.append((first["name"], first["salary_h"]))
    return out


# ─── Factions gouvernementales ───────────────────────────────────────────────
# ranks : du plus bas au plus haut ; salary = versé chaque jour de jeu depuis le budget de la faction.
# auto_cap : rang max atteignable par promotion automatique (compétences) ; au-delà : nomination par le chef.
GOV_FACTIONS = {
    "police":  {"name": "Police",           "emoji": "🚓", "location": "commissariat", "daily_budget": 150_000,
                "hourly": True,   # salaires PAR HEURE DE JEU (utils/ordre.py) ; postes dans ORDRE_POSTS
                "ranks": _ordre_ranks("police"), "auto_cap": -1},
    "sante":   {"name": "Santé publique",   "emoji": "🏥", "location": "hopital", "daily_budget": 80_000,
                "hourly": True,   # salaires PAR HEURE DE JEU (utils/sante.py) ; postes dans SANTE_POSTS
                "ranks": _sante_ranks(), "auto_cap": -1},
    "justice": {"name": "Justice",          "emoji": "⚖️", "location": "tribunal", "daily_budget": 120_000,
                "hourly": True,   # salaires PAR HEURE DE JEU (utils/ordre.py) ; postes dans ORDRE_POSTS
                "ranks": _ordre_ranks("justice"), "auto_cap": -1},
    "mairie":  {"name": "Administration",   "emoji": "🏛️", "location": "mairie", "daily_budget": 100_000,
                "ranks": [("Agent d'accueil", 1_800), ("Secrétaire", 3_200), ("Chef de bureau", 7_000),
                          ("Directeur", 14_000), ("Secrétaire général", 24_000),
                          ("Ministre", 27_000),       # nommé par le Président (voir MINISTRIES, utils/roles.py)
                          ("Président", 30_000)],     # élu du peuple (voir utils/roles.py)
                "auto_cap": 2},
    "armee":   {"name": "Armée",            "emoji": "🎖️", "location": "qg_armee", "daily_budget": 130_000,
                "hourly": True,   # salaires PAR HEURE DE JEU (utils/ordre.py) ; postes dans ORDRE_POSTS
                "ranks": _ordre_ranks("armee"), "auto_cap": -1},
}
# Exigences pour monter d'un cran : activité + compétences (dominantes).
# Clé = index du rang visé dans la faction (≥1).
# Au-delà de la table : dernière ligne × (1 + 0.5 par cran).
PROMOTION_REQUIREMENTS = {
    1: {"activity": 3,   "skills": {"Discrétion": 1}},
    2: {"activity": 10,  "skills": {"Intelligence": 2, "Endurance": 2}},
    3: {"activity": 20,  "skills": {"Intelligence": 4, "Leadership": 3}},
    4: {"activity": 40,  "skills": {"Leadership": 5, "Négociation": 4}},
    5: {"activity": 70,  "skills": {"Leadership": 7, "Négociation": 6}},
}
# Entreprises : exigences pour monter d'un cran dans COMPANY_RANKS
COMPANY_PROMOTION_REQUIREMENTS = {
    1: {"activity": 2,   "skills": {}},
    2: {"activity": 6,   "skills": {"Technique": 2}},
    3: {"activity": 15,  "skills": {"Technique": 3, "Négociation": 2}},
    4: {"activity": 30,  "skills": {"Leadership": 3, "Négociation": 3}},
    5: {"activity": 55,  "skills": {"Leadership": 5, "Intelligence": 4}},
    6: {"activity": 90,  "skills": {"Leadership": 7, "Négociation": 6}},
}
# Service au poste (/travailler) : coût en énergie, XP de base ; plus de gain d'argent direct :
# l'argent vient uniquement du SALAIRE automatique.
SHIFT_ENERGY = (15, 25)
SHIFT_BASE_XP = 30
# Plus de « service au poste » à lancer : /travailler ne concerne que le MÉTIER (petit métier freelance).
# Un salarié d'entreprise ou de faction gagne de l'ACTIVITÉ en étant « EN SERVICE » sur son lieu de travail :
# c'est le temps RÉEL passé en service qui détermine l'activité (promotions + production de l'entreprise).
# 👉 Pour régler le rythme, change ces deux valeurs :
ACTIVITY_MINUTES_PER_POINT = 10           # 1 point d'activité toutes les 10 minutes DE JEU en service
DUTY_MAX_SECONDS = 4 * 3600               # une session de service compte au maximum 4 h DE JEU (anti-oubli)
# Part du budget journalier d'une faction financée par une dotation de base quand l'État
# (impôt sur la fortune collecté) ne suffit pas. 0 = uniquement les impôts ; 1 = budget toujours plein.
GOV_MINT_RATIO = 0.5

# ═══════════════════════════════════════════════════════════════════
#  PETITS MÉTIERS — freelance, autonomes, hors entreprise
#  Chacun est associé à une CATÉGORIE de mini-jeu (utils/minigames.py)
# ═══════════════════════════════════════════════════════════════════
SMALL_JOBS = {
    "Livreur":      {"category": "vitesse",    "emoji": "🛵", "min": 600,   "max": 2_400,  "xp": 30,  "need": None},
    "Serveur":      {"category": "memoire",    "emoji": "🍽️", "min": 750,   "max": 2_700,  "xp": 35,  "need": None},
    "Caissier":     {"category": "precision",  "emoji": "🧾", "min": 600,   "max": 2_250,  "xp": 25,  "need": None},
    "Ouvrier":      {"category": "rythme",     "emoji": "🏗️", "min": 900,   "max": 3_000,  "xp": 40,  "need": None},
    "Artiste":      {"category": "creativite", "emoji": "🎤", "min": 200,   "max": 12_000, "xp": 70,  "need": None},
    "Influenceur":  {"category": "charisme",   "emoji": "📸", "min": 1_000, "max": 15_000, "xp": 80,  "need": None},
    "Footballeur":  {"category": "timing",     "emoji": "⚽", "min": 900,   "max": 21_000, "xp": 200, "need": None},
    "Commerçant":   {"category": "charisme",    "emoji": "🛍️", "min": 800,   "max": 3_500,  "xp": 45,  "need": None},   # seul métier autorisé à vendre sur le marché
    "Agent secu":   {"category": "reflexe",    "emoji": "🔧", "min": 1_050, "max": 3_600,  "xp": 45,  "need": "Brevet"},
    "Technicien":   {"category": "logique",    "emoji": "🔬", "min": 1_500, "max": 5_400,  "xp": 60,  "need": "BTS"},
    "Infirmier":    {"category": "memoire",    "emoji": "💊", "min": 1_800, "max": 6_000,  "xp": 70,  "need": "BTS"},
    "Comptable":    {"category": "logique",    "emoji": "📊", "min": 2_400, "max": 8_400,  "xp": 80,  "need": "Licence"},
    "Dev freelance":{"category": "logique",    "emoji": "💻", "min": 3_600, "max": 13_500, "xp": 100, "need": "Licence"},
}

# Compétence qui bonifie le score du mini-jeu (+0 / +1 / +2)
MINIGAME_SKILL = {
    "vitesse":    "Agilité",
    "memoire":    "Intelligence",
    "precision":  "Agilité",
    "rythme":     "Endurance",
    "creativite": "Créativité",
    "charisme":   "Charisme",
    "timing":     "Agilité",
    "reflexe":    "Discrétion",
    "logique":    "Intelligence",
}


# ═══════════════════════════════════════════════════════════════════
#  PRODUCTION DES ENTREPRISES (utils/payroll.py)
#  Chaque jour de jeu : activité de l'équipe × per_activity = unités produites
#  (coût unit_cost débité de la trésorerie). Le stock est vendu automatiquement
#  au « marché national » (PNJ) à npc_price, dans la limite de npc_cap unités/jour.
# ═══════════════════════════════════════════════════════════════════
# Données complètes de la chaîne (recettes, équipes, stades…) : voir config_chain.py.
# SECTOR_PRODUCTION n'est plus qu'un RÉSUMÉ de la 1re recette de chaque secteur (anciens écrans / tests).
from config_chain import (          # noqa: E402,F401
    RECIPES, RECIPES_BY_SECTOR, SECTOR_TEAMS, STAGES, INTRANTS, npc_price as _chain_price,
    unit_cost_ref as _chain_cost,
)
SECTOR_PRODUCTION = {
    sec: {"product": RECIPES[keys[0]]["name"], "unit_cost": int(_chain_cost(keys[0])),
          "npc_price": _chain_price(keys[0]), "per_activity": 1, "npc_cap": RECIPES[keys[0]]["base_cap"]}
    for sec, keys in RECIPES_BY_SECTOR.items()
}

# Niveau de production choisi par la direction (/production 1|2|3)
PRODUCTION_LEVELS = {
    1: {"name": "Prudente",   "units": 0.7, "cost": 0.8},
    2: {"name": "Normale",    "units": 1.0, "cost": 1.0},
    3: {"name": "Agressive",  "units": 1.4, "cost": 1.3},
}


# ═══════════════════════════════════════════════════════════════════
#  NOURRITURE — repas par catégorie et par étoiles (handlers/life.py)
#  Effets en points de jauge (0–100) : hunger = faim restaurée, energy, health,
#  stress (négatif = apaisant), happiness. Les effets reflètent le type de repas.
# ═══════════════════════════════════════════════════════════════════
MEAL_CATEGORIES = {
    "rapide":   {"emoji": "🍔", "name": "Restauration rapide", "desc": "Pas cher, rassasie vite, mais pas très sain."},
    "maison":   {"emoji": "🍲", "name": "Cuisine du quotidien", "desc": "Le bon équilibre du quotidien."},
    "sain":     {"emoji": "🥗", "name": "Diététique", "desc": "Léger, bon pour la santé et la forme."},
    "gastro":   {"emoji": "🍾", "name": "Restaurants", "desc": "Cher, mais rassasie et fait plaisir."},
}
MEALS = {
    # ── Restauration rapide ──
    "sandwich":   {"cat": "rapide", "stars": 1, "emoji": "🥪", "name": "Sandwich de rue",       "cost": 500,     "hunger": 15,  "energy": 5,  "health": 0,  "stress": 1,   "happiness": 1},
    "burger":     {"cat": "rapide", "stars": 2, "emoji": "🍔", "name": "Burger-frites",         "cost": 1_200,   "hunger": 25,  "energy": 8,  "health": -1, "stress": 0,   "happiness": 3},
    "menu_xxl":   {"cat": "rapide", "stars": 3, "emoji": "🍟", "name": "Menu XXL",              "cost": 2_000,   "hunger": 35,  "energy": 10, "health": -2, "stress": 2,   "happiness": 4},
    # ── Cuisine du quotidien ──
    "plat_jour":  {"cat": "maison", "stars": 1, "emoji": "🍛", "name": "Plat du jour",          "cost": 2_000,   "hunger": 35,  "energy": 15, "health": 0,  "stress": -2,  "happiness": 0},
    "repas":      {"cat": "maison", "stars": 2, "emoji": "🍽️", "name": "Repas complet",         "cost": 3_500,   "hunger": 45,  "energy": 20, "health": 1,  "stress": -4,  "happiness": 1},
    "familial":   {"cat": "maison", "stars": 3, "emoji": "🍗", "name": "Repas familial",        "cost": 5_500,   "hunger": 55,  "energy": 25, "health": 2,  "stress": -6,  "happiness": 4},
    # ── Diététique ──
    "salade":     {"cat": "sain",   "stars": 1, "emoji": "🥗", "name": "Salade composée",       "cost": 3_000,   "hunger": 25,  "energy": 15, "health": 2,  "stress": 0,   "happiness": 0},
    "bol":        {"cat": "sain",   "stars": 2, "emoji": "🥣", "name": "Bol vitalité",          "cost": 6_000,   "hunger": 35,  "energy": 25, "health": 4,  "stress": -3,  "happiness": 1},
    "nutri":      {"cat": "sain",   "stars": 3, "emoji": "🥦", "name": "Menu nutritionniste",   "cost": 12_000,  "hunger": 45,  "energy": 35, "health": 8,  "stress": -5,  "happiness": 2},
    # ── Restaurants ──
    "brasserie":  {"cat": "gastro", "stars": 3, "emoji": "🍷", "name": "Brasserie",             "cost": 15_000,  "hunger": 80,  "energy": 30, "health": 0,  "stress": -6,  "happiness": 8},
    "gastro":     {"cat": "gastro", "stars": 4, "emoji": "🍾", "name": "Restaurant gastronomique", "cost": 35_000, "hunger": 100, "energy": 40, "health": 1, "stress": -8,  "happiness": 12},
    "etoile":     {"cat": "gastro", "stars": 5, "emoji": "⭐", "name": "Restaurant étoilé",     "cost": 350_000, "hunger": 100, "energy": 60, "health": 2,  "stress": -15, "happiness": 30},
}
# Anciennes clés (anciens boutons / habitudes) → nouveaux repas
MEAL_LEGACY = {"snack": "sandwich", "repas": "repas", "gastro": "gastro", "etoile": "etoile"}
NOT_HUNGRY_AT = 95   # au-delà, le joueur « n'a pas faim »


# ═══════════════════════════════════════════════════════════════════
#  GANGS — hiérarchie, partage du coffre, crimes réservés aux membres (handlers/gangs.py)
#  Chaque jour de jeu, GANG_PAYOUT_RATIO du coffre est partagé entre les membres au prorata
#  du poids de leur poste. Le reste reste dans le coffre (améliorations, frais du gang).
# ═══════════════════════════════════════════════════════════════════
GANG_ROLES = [            # du plus haut au plus bas : (poste, poids dans le partage)
    ("Chef", 5),
    ("Bras droit", 4),
    ("Lieutenant", 3),
    ("Soldat", 2),
    ("Recrue", 1),
]
GANG_ROLE_WEIGHT = dict(GANG_ROLES)
GANG_RECRUIT_ROLES = ("Chef", "Bras droit", "Lieutenant")   # acceptent les candidatures
GANG_MANAGE_ROLES = ("Chef", "Bras droit")                  # nomment, excluent
GANG_PAYOUT_RATIO = 0.70
GANG_CRIME_CUT = 0.25     # part du butin d'un crime versée au coffre du gang


# ═══════════════════════════════════════════════════════════════════
#  LOTERIE (handlers/economy.py) : tirage au sort d'un ticket parmi tous ceux vendus
# ═══════════════════════════════════════════════════════════════════
LOTTERY_MAX_TICKETS = 5     # tickets max par joueur et par tirage (anti-rachat du jackpot)
LOTTERY_MIN_PLAYERS = 2     # il faut au moins 2 joueurs différents pour qu'un tirage ait lieu


# ═══════════════════════════════════════════════════════════════════
#  LOGEMENT OBLIGATOIRE (handlers/realestate.py)
#  Tout joueur doit avoir un logement : bien possédé, location à un joueur ou chambre PNJ.
#  Les frais sont prélevés chaque jour de jeu et TOUJOURS notifiés.
# ═══════════════════════════════════════════════════════════════════
HOUSING_DAYS_PER_MONTH = 30          # loyers et charges sont affichés au mois, prélevés par jour de jeu
HOUSING_EVICT_AFTER = 3              # jours d'impayés avant expulsion (location / chambre PNJ)
HOUSING_REQUIRED_FOR_JOBS = True     # sans logement : pas de service en entreprise/faction
HOUSING_NPC = {                      # logements « publics » : toujours disponibles, jamais bloquant
    "Foyer":         {"daily": 400,   "emoji": "🛏️", "sleep": 0.85, "desc": "Lit en dortoir. Simple, pas cher."},
    "Studio meublé": {"daily": 1_500, "emoji": "🏠", "sleep": 1.0,  "desc": "Un vrai chez-soi, meublé."},
}
HOMELESS_SLEEP_MULT = 0.5            # dormir dehors : repos divisé par deux, santé et stress en pâtissent


# Lieu où s'exerce chaque petit métier (clé de LOCATIONS) — par défaut « travail ». Il faut y être (voir /aller).
SMALL_JOB_PLACE = {
    "Livreur": "marche", "Serveur": "marche", "Caissier": "marche", "Commerçant": "marche",
    "Infirmier": "hopital", "Agent secu": "commissariat", "Comptable": "maison", "Dev freelance": "maison",
}

# ── Manger = aller au restaurant (trajet chronométré, SANS mini-jeu : seul le temps d'arrivée compte) ──
MEAL_PLACE = "restaurant"

# ── Consommer le repas = mini-jeu : on appuie sur le plat jusqu'à le finir (le paiement est automatique à l'arrivée) ──
MEAL_BITES_BASE = 3                                    # bouchées = MEAL_BITES_BASE + étoiles du plat
MEAL_SCORE_MULT = {0: 0.5, 1: 0.8, 2: 1.0, 3: 1.25}    # appliqué aux effets positifs ; la malbouffe garde ses effets négatifs
MEAL_SCORE_LABEL = {0: "🤢 Repas bâclé", 1: "😐 Repas moyen", 2: "😋 Bon repas", 3: "🤩 Un régal"}
MEAL_FINISH_SCORE = 2                                  # repas terminé = « Bon repas » (effets normaux)

# ── Durée des trajets : jamais plus de 2 minutes RÉELLES ; les véhicules vont plus vite, le taxi est payant et rapide ──
# Durées de trajet en secondes DE JEU (affichées telles quelles aux joueurs).
TRAVEL_GAME_SEC_PER_HOUR = 360     # 1 h de trajet « logique » (km ÷ vitesse) = 6 min de jeu
TRAVEL_MIN_SECONDS = 60            # un trajet dure au moins 1 min de jeu
TRAVEL_MAX_SECONDS = 300           # …et au plus 5 min de jeu, même à pied jusqu'à l'aéroport
TAXI_SPEED_KMH = 60
TAXI_BASE_FARE = 500               # prise en charge (€A)
TAXI_FARE_PER_KM = 300             # + par km
