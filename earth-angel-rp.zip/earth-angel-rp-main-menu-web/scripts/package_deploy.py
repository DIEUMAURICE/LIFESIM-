#!/usr/bin/env python3
"""Crée une archive de code sans base SQL ni données runtime."""
from __future__ import annotations

import argparse
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_NAMES = {".git", "__pycache__", ".pytest_cache", "backups"}
EXCLUDED_SUFFIXES = {".db", ".db-wal", ".db-shm", ".log"}
EXCLUDED_FILES = {".env"}


def excluded(path: Path, output: Path) -> bool:
    if path.resolve() == output.resolve():
        return True
    relative = path.relative_to(ROOT)
    if any(part in EXCLUDED_NAMES for part in relative.parts):
        return True
    if path.name in EXCLUDED_FILES:
        return True
    if any(path.name.endswith(suffix) for suffix in EXCLUDED_SUFFIXES):
        return True
    return False


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", nargs="?", help="Archive ZIP à créer")
    args = parser.parse_args()
    output = Path(args.output).expanduser().resolve() if args.output else ROOT.parent / "earth-angel-rp-deploy.zip"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.unlink(missing_ok=True)

    files = [p for p in ROOT.rglob("*") if p.is_file() and not excluded(p, output)]
    with ZipFile(output, "w", ZIP_DEFLATED) as archive:
        for path in sorted(files):
            archive.write(path, Path(ROOT.name) / path.relative_to(ROOT))

    print(f"Archive créée : {output}")
    print(f"Fichiers inclus : {len(files)}")
    print("Bases SQL/runtime exclues : *.db, *.db-wal, *.db-shm, backups/, .env")


if __name__ == "__main__":
    main()
