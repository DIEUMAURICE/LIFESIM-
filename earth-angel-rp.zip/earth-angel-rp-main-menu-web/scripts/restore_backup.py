# scripts/restore_backup.py
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
import shutil
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = Path(os.getenv("DB_PATH", str(ROOT / "life_sim.db"))).expanduser().resolve()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_manifest(archive: Path) -> None:
    manifest = archive.with_suffix(archive.suffix + ".json")
    if not manifest.is_file():
        raise RuntimeError(f"Manifeste absent : {manifest}")

    data = json.loads(manifest.read_text(encoding="utf-8"))
    expected = data.get("sha256")
    actual = sha256(archive)
    if not expected or actual != expected:
        raise RuntimeError(
            f"Checksum invalide. Attendu={expected}, obtenu={actual}"
        )


def verify_sqlite(path: Path) -> None:
    connection = sqlite3.connect(str(path))
    try:
        row = connection.execute("PRAGMA integrity_check").fetchone()
    finally:
        connection.close()
    if not row or row[0] != "ok":
        detail = row[0] if row else "aucun résultat"
        raise RuntimeError(f"Base restaurée invalide : {detail}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", help="Chemin du fichier .db.gz")
    parser.add_argument("--database", default=str(DEFAULT_DB))
    parser.add_argument(
        "--confirm",
        action="store_true",
        help="Confirme que le bot est arrêté et autorise le remplacement",
    )
    args = parser.parse_args()

    if not args.confirm:
        print("ERREUR : arrête le bot puis ajoute --confirm.")
        raise SystemExit(2)

    archive = Path(args.archive).resolve()
    database = Path(args.database).resolve()
    if not archive.is_file() or not archive.name.endswith(".db.gz"):
        raise FileNotFoundError(f"Archive invalide : {archive}")

    verify_manifest(archive)
    database.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(dir=database.parent) as temp_dir:
        candidate = Path(temp_dir) / "restored.db"
        with gzip.open(archive, "rb") as source:
            with candidate.open("wb") as target:
                shutil.copyfileobj(source, target)

        verify_sqlite(candidate)

        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        safety_copy = database.with_name(
            f"{database.name}.before-restore-{timestamp}"
        )
        if database.exists():
            shutil.copy2(database, safety_copy)
            print(f"Sauvegarde de sécurité : {safety_copy}")

        # Les anciens fichiers WAL ne doivent jamais accompagner la nouvelle DB.
        Path(str(database) + "-wal").unlink(missing_ok=True)
        Path(str(database) + "-shm").unlink(missing_ok=True)

        candidate.replace(database)

    verify_sqlite(database)
    print(f"Restauration terminée : {database}")
    print("Tu peux maintenant redémarrer le bot.")


if __name__ == "__main__":
    main()
