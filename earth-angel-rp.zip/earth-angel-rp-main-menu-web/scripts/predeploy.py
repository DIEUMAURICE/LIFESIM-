# scripts/predeploy.py
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run(label: str, command: list[str]) -> None:
    print(f"\n[PREDEPLOY] {label}")
    print("$", " ".join(command))
    result = subprocess.run(command, cwd=ROOT, timeout=1800)
    if result.returncode != 0:
        print(f"[PREDEPLOY] ÉCHEC : {label}")
        raise SystemExit(result.returncode)
    print(f"[PREDEPLOY] OK : {label}")


def check_required_files() -> None:
    required = [
        ROOT / "bot.py",
        ROOT / "database.py",
        ROOT / "migrations.py",
        ROOT / "requirements.txt",
        ROOT / "utils" / "cooldowns.py",
        ROOT / "utils" / "scheduler.py",
        ROOT / "utils" / "arena_store.py",
        ROOT / "test" / "test_concurrency.py",
    ]
    missing = [str(path.relative_to(ROOT)) for path in required if not path.is_file()]
    if missing:
        print("[PREDEPLOY] Fichiers manquants :")
        for path in missing:
            print(" -", path)
        raise SystemExit(1)


def check_environment() -> None:
    token = os.getenv("BOT_TOKEN", "")
    if token and token == "YOUR_BOT_TOKEN_HERE":
        print("[PREDEPLOY] BOT_TOKEN contient encore la valeur d'exemple.")
        raise SystemExit(1)

    environment = os.getenv("APP_ENV", "development").strip().lower()
    if environment in {"production", "prod", "staging"}:
        db_path = os.getenv("DB_PATH", "").strip()
        require_db = os.getenv("REQUIRE_EXISTING_DB", "").strip().lower()
        if not db_path:
            print("[PREDEPLOY] DB_PATH doit pointer vers un volume persistant en production.")
            raise SystemExit(1)
        if require_db not in {"1", "true", "yes", "on"}:
            print("[PREDEPLOY] REQUIRE_EXISTING_DB=1 est obligatoire en production.")
            raise SystemExit(1)


def main() -> None:
    print(f"[PREDEPLOY] Python {sys.version.split()[0]}")
    if sys.version_info < (3, 11):
        print("[PREDEPLOY] Python 3.11 minimum requis.")
        raise SystemExit(1)

    check_required_files()
    check_environment()

    run(
        "Compilation du projet",
        [
            sys.executable,
            "-m",
            "compileall",
            "-q",
            "bot.py",
            "database.py",
            "migrations.py",
            "handlers",
            "utils",
            "test",
        ],
    )
    run(
        "Tests de concurrence",
        [sys.executable, "-m", "pytest", "test/test_concurrency.py", "-q"],
    )
    run(
        "Suite de tests complète",
        [sys.executable, "-m", "pytest", "-q"],
    )

    print("\n[PREDEPLOY] ✅ Déploiement autorisé")


if __name__ == "__main__":
    main()
