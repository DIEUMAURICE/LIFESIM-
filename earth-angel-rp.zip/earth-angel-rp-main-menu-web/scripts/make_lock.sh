#!/usr/bin/env bash
# Génère requirements-lock.txt (toutes les dépendances, transitives comprises, figées).
# À lancer sur une machine AVEC internet, une fois les tests au vert :
#     bash scripts/make_lock.sh
# Déploiement reproductible ensuite :  pip install -r requirements-lock.txt
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .lockenv
. .lockenv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
pip freeze --exclude-editable | sort -f > requirements-lock.txt
deactivate
rm -rf .lockenv
echo "✅ requirements-lock.txt généré ($(wc -l < requirements-lock.txt) paquets)"
