# Incident de persistance SQL

## Cause identifiée

La configuration utilisait `DB_PATH = "life_sim.db"`, un chemin relatif au répertoire courant. Lors d’un redeploy, l’hébergeur pouvait changer ou recréer ce répertoire. SQLite ouvrait alors une nouvelle base vide et les migrations créaient normalement les tables, ce qui masquait l’erreur.

La base `life_sim.db` était également présente dans l’archive de code. Une nouvelle archive pouvait donc remettre en place une copie de développement et remplacer le fichier runtime.

## Correctif appliqué

Le chemin SQL est maintenant absolu et configurable avec `DB_PATH` ou `DATA_DIR`. Les sauvegardes utilisent également un chemin absolu via `BACKUP_DIR`. En production, `APP_ENV=production` active automatiquement `REQUIRE_EXISTING_DB=1` sauf surcharge explicite.

Le serveur refuse désormais de démarrer si la base de production est absente, vide, illisible, corrompue ou dépourvue de la table `users`. Il ne crée plus silencieusement une nouvelle base dans ce mode.

`predeploy.py` bloque aussi un déploiement de production sans `DB_PATH` et sans `REQUIRE_EXISTING_DB=1`. Les fichiers SQLite, WAL, SHM et sauvegardes sont exclus du code via `.gitignore`, et `.env.example` documente la configuration attendue.

## Configuration obligatoire

```env
APP_ENV=production
DATA_DIR=/var/lib/earthangel-rp
DB_PATH=/var/lib/earthangel-rp/life_sim.db
BACKUP_DIR=/var/lib/earthangel-rp/backups
REQUIRE_EXISTING_DB=1
```

Le chemin doit être situé sur un volume réellement persistant. Si l’hébergeur ne fournit pas de volume persistant, SQLite ne peut pas garantir la conservation des données après redeploy ; il faut utiliser une base externe, idéalement PostgreSQL, ou changer de plan d’hébergement.

## Récupération

Arrêter le bot et l’API, vérifier la sauvegarde `.db.gz` et son manifeste SHA-256, puis restaurer avec :

```bash
python3 scripts/restore_backup.py /var/lib/earthangel-rp/backups/life_sim-AAAAMMJJTHHMMSSZ.db.gz --database /var/lib/earthangel-rp/life_sim.db --confirm
```

La restauration crée une copie de sécurité de la base actuelle avant remplacement et vérifie `PRAGMA integrity_check` avant et après l’opération.
