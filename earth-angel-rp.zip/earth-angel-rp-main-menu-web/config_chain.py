# config_chain.py — LA CHAÎNE DE PRODUCTION : métiers → biens → entreprises → produits finis → joueurs
"""
Tout ce qui régit l'économie « lourde » du jeu est ici, modifiable à la main :

    MÉTIER (joueur, payé par le bot)  ──►  BIEN / SERVICE de base (« intrant »)
        │                                          │ vendu à une entreprise (ou via un commerçant)
        ▼                                          ▼
    promotions par compétences        ENTREPRISE : équipes par secteur → étapes de fabrication
    (plus de travail, de gains)                    → PRODUIT FINI (bien ou service)
                                                       │ grossiste → commerçant → marché  /  prestation directe
                                                       ▼
                                          effets sur un joueur, son véhicule, ses biens…

Sections : 1 métiers · 2 biens · 3 stades d'entreprise · 4 secteurs et équipes · 5 recettes ·
6 effets · 7 services · 8 outils de calcul (prix, coûts, validation).

Ce module n'importe rien du reste du jeu (pas de config.py, pas de base de données) : il est
donc testable seul. config.py en ré-exporte ce dont l'ancien code a besoin.
"""
from __future__ import annotations

import math

# ═════════════════════════════════════════════════════════════════════════════
# 1. MÉTIERS — rangs et promotions (par compétences)
# ═════════════════════════════════════════════════════════════════════════════
# Un rang plus haut = plus de travail ET de gains : missions mieux payées, plus de biens fournis,
# mais un effort (énergie) plus lourd. À partir du rang GRANDE_COMMANDE_RANK, le joueur peut
# aussi prendre des « grandes commandes » (mission lourde : x4 biens, cooldown x3).
JOB_RANKS = [
    # name,           pay,  goods, energy
    ("Apprenti",       1.0,  1.0,   1.00),
    ("Compagnon",      1.2,  1.3,   1.10),
    ("Confirmé",       1.5,  1.7,   1.25),
    ("Expert",         1.9,  2.2,   1.40),
    ("Maître",         2.5,  3.0,   1.60),
    ("Grand maître",   3.3,  4.0,   1.80),
]
MAX_JOB_RANK = len(JOB_RANKS)
GRANDE_COMMANDE_RANK = 3
GRANDE_COMMANDE = {"pay": 2.5, "goods": 4.0, "energy": 2.2, "cooldown": 3.0}

# Conditions pour ATTEINDRE un rang (clé = rang visé) :
#   missions     : missions déjà accomplies dans CE métier
#   skill        : niveau de la compétence principale du métier (voir MINIGAME_SKILL dans config.py)
#   extra        : autres compétences exigées
#   diplome      : diplôme minimal (voir DIP_ORDER dans handlers/work.py)
JOB_PROMOTION = {
    2: {"missions": 8,   "skill": 1, "extra": {},                                    "diplome": ""},
    3: {"missions": 25,  "skill": 2, "extra": {"Technique": 1},                      "diplome": ""},
    4: {"missions": 60,  "skill": 3, "extra": {"Intelligence": 2, "Endurance": 2},   "diplome": "Bac"},
    5: {"missions": 120, "skill": 5, "extra": {"Leadership": 3, "Négociation": 3},   "diplome": "BTS"},
    6: {"missions": 250, "skill": 7, "extra": {"Leadership": 5, "Négociation": 5},   "diplome": "Licence"},
}

# Score du mini-jeu (0–3) → part des biens livrés (0 = mission ratée : rien)
SCORE_GOODS = {0: 0.0, 1: 0.7, 2: 1.0, 3: 1.5}

# Vente « au comptoir national » : filet de sécurité quand aucune entreprise n'achète
COUNTER_PRICE_RATIO = 0.40       # part du prix de référence
COUNTER_DAILY_CAP = 30           # unités par bien, par joueur et par jour de jeu


DIPLOMES_ORDER = ["", "Brevet", "Bac", "BTS", "Licence", "Master", "MBA", "Doctorat", "Habilitation"]


def job_rank_name(rank: int) -> str:
    return JOB_RANKS[max(1, min(int(rank), MAX_JOB_RANK)) - 1][0]


def job_rank_mult(rank: int) -> dict:
    _n, pay, goods, energy = JOB_RANKS[max(1, min(int(rank), MAX_JOB_RANK)) - 1]
    return {"pay": pay, "goods": goods, "energy": energy}


# ═════════════════════════════════════════════════════════════════════════════
# 2. BIENS — intrants (fournis par les métiers), intermédiaires (internes), produits finis
# ═════════════════════════════════════════════════════════════════════════════
# kind : 'intrant' (vient d'un métier / du jardin) · 'inter' (fabriqué puis consommé dans l'entreprise)
#        'final' (produit fini : défini dans RECIPES).   ref = prix de référence (€A) d'un intrant.
INTRANTS: dict[str, dict] = {
    "mat_brut":     {"name": "Matériaux bruts",           "emoji": "🧱", "ref": 400,   "job": "Ouvrier",       "units": 3, "type": "bien"},
    "transport":    {"name": "Transport & livraison",     "emoji": "🚚", "ref": 300,   "job": "Livreur",       "units": 3, "type": "service"},
    "salle":        {"name": "Service en salle",          "emoji": "🍽️", "ref": 350,   "job": "Serveur",       "units": 3, "type": "service"},
    "caisse":       {"name": "Encaissement",              "emoji": "🧾", "ref": 300,   "job": "Caissier",      "units": 3, "type": "service"},
    "creation":     {"name": "Création artistique",       "emoji": "🎨", "ref": 900,   "job": "Artiste",       "units": 2, "type": "service"},
    "visibilite":   {"name": "Visibilité & promotion",    "emoji": "📣", "ref": 800,   "job": "Influenceur",   "units": 2, "type": "service"},
    "performance":  {"name": "Performance sportive",      "emoji": "⚽", "ref": 1000,  "job": "Footballeur",   "units": 2, "type": "service"},
    "distribution": {"name": "Distribution commerciale",  "emoji": "🛍️", "ref": 500,   "job": "Commerçant",    "units": 3, "type": "service"},
    "securite":     {"name": "Sécurité & surveillance",   "emoji": "🛡️", "ref": 600,   "job": "Agent secu",    "units": 2, "type": "service"},
    "pieces":       {"name": "Pièces techniques",         "emoji": "⚙️", "ref": 900,   "job": "Technicien",    "units": 2, "type": "bien"},
    "soins":        {"name": "Soins & hygiène",           "emoji": "💊", "ref": 1000,  "job": "Infirmier",     "units": 2, "type": "service"},
    "compta":       {"name": "Gestion comptable",         "emoji": "📊", "ref": 1200,  "job": "Comptable",     "units": 2, "type": "service"},
    "code":         {"name": "Code logiciel",             "emoji": "💻", "ref": 1800,  "job": "Dev freelance", "units": 1, "type": "bien"},
    # Hors métier : le jardin (récolte) approvisionne l'alimentation
    "recolte":      {"name": "Récolte fraîche",           "emoji": "🌾", "ref": 450,   "job": "",              "units": 0, "type": "bien"},
}
JOB_GOOD: dict[str, str] = {v["job"]: k for k, v in INTRANTS.items() if v["job"]}

# Récolte du jardin → biens (1 « Récolte fraîche » par plante récoltée)
GARDEN_GOOD = "recolte"
GARDEN_UNITS_PER_PLANT = 1

# Prix d'achat d'un intrant par l'entreprise : multiplicateur du prix de référence réglable par la direction
BID_MIN, BID_MAX, BID_STEP, BID_DEFAULT = 0.6, 1.6, 0.1, 1.0
# Filet de sécurité pour l'entreprise : « fournisseur national » (plus cher, plafonné par jour)
NPC_SUPPLY_MARKUP = 1.5
NPC_SUPPLY_DAILY = 24            # unités par bien et par jour, × capacité du stade

# Intermédiaires : nom et emoji uniquement (ils ne quittent jamais l'entreprise)
INTERMEDIAIRES: dict[str, dict] = {
    "ingredients":   {"name": "Ingrédients préparés",   "emoji": "🥬"},
    "produits_fins": {"name": "Produits sélectionnés",  "emoji": "🧀"},
    "plats_gastro":  {"name": "Plats d'auteur",         "emoji": "🍲"},
    "brut":          {"name": "Hydrocarbures bruts",    "emoji": "🛢️"},
    "electricite":   {"name": "Électricité produite",   "emoji": "⚡"},
    "composants":    {"name": "Composants usinés",      "emoji": "🔩"},
    "kits_bruts":    {"name": "Kits assemblés",         "emoji": "📦"},
    "modules":       {"name": "Modules logiciels",      "emoji": "🧩"},
    "modules_secu":  {"name": "Modules de sécurité",    "emoji": "🔐"},
    "dossiers":      {"name": "Dossiers clients",       "emoji": "📁"},
    "modeles":       {"name": "Modèles financiers",     "emoji": "📈"},
    "dossier_valide":{"name": "Dossiers validés",       "emoji": "✅"},
    "lots":          {"name": "Lots de marchandises",   "emoji": "📦"},
    "emballages":    {"name": "Coffrets préparés",      "emoji": "🎀"},
    "contenu":       {"name": "Contenus rédigés",       "emoji": "📝"},
    "rushes":        {"name": "Rushes tournés",         "emoji": "🎞️"},
    "mandats":       {"name": "Mandats de gestion",     "emoji": "📜"},
    "etudes":        {"name": "Études de faisabilité",  "emoji": "📐"},
    "gros_oeuvre":   {"name": "Gros œuvre",             "emoji": "🏗️"},
    "programmes":    {"name": "Programmes d'entraînement", "emoji": "📋"},
    "plans_perf":    {"name": "Plans de performance",   "emoji": "📊"},
    "maquettes":     {"name": "Maquettes & répétitions","emoji": "🎼"},
    "toiles":        {"name": "Toiles préparées",       "emoji": "🖼️"},
    "matieres_nobles":{"name": "Matières nobles",       "emoji": "🪡"},
    "prototypes":    {"name": "Prototypes",             "emoji": "✂️"},
}


# ═════════════════════════════════════════════════════════════════════════════
# 3. STADES D'ENTREPRISE — du petit atelier à la multinationale
# ═════════════════════════════════════════════════════════════════════════════
# cap   : multiplicateur de capacité (production max, commandes du marché national, achats des fournisseurs)
# lines : nombre de lignes de production simultanées
# Pour passer au stade suivant : XP + effectif + réputation + trésorerie (tout doit être réuni).
STAGES = [
    {"name": "Atelier",           "xp": 0,       "staff": 1,  "rep": 0,  "treasury": 0,           "cap": 1.0,  "lines": 1},
    {"name": "Petite entreprise", "xp": 400,     "staff": 2,  "rep": 40, "treasury": 100_000,     "cap": 1.6,  "lines": 1},
    {"name": "PME",               "xp": 2_000,   "staff": 4,  "rep": 50, "treasury": 500_000,     "cap": 2.6,  "lines": 2},
    {"name": "Entreprise",        "xp": 8_000,   "staff": 7,  "rep": 60, "treasury": 2_000_000,   "cap": 4.0,  "lines": 2},
    {"name": "Grande entreprise", "xp": 28_000,  "staff": 12, "rep": 70, "treasury": 8_000_000,   "cap": 6.5,  "lines": 3},
    {"name": "Groupe",            "xp": 90_000,  "staff": 20, "rep": 80, "treasury": 30_000_000,  "cap": 10.0, "lines": 3},
    {"name": "Multinationale",    "xp": 250_000, "staff": 35, "rep": 90, "treasury": 100_000_000, "cap": 16.0, "lines": 4},
]
MAX_STAGE = len(STAGES)
STAGE_EMOJI = ["🛠️", "🏪", "🏬", "🏢", "🏛️", "🌐", "🌍"]
# Journée réussie (commandes du marché national remplies à ≥ 100 %) : bonus d'XP et de réputation
TARGET_MET_XP = 25
TARGET_MET_REP = 1
TARGET_MISSED_RATIO = 0.30       # < 30 % des commandes remplies alors qu'une ligne tourne : réputation -1
TARGET_MISSED_REP = 1
# Les employés sans équipe précise (anciens salariés) renforcent n'importe quelle étape à demi-efficacité
GENERAL_EFFICIENCY = 0.5
# Commission versée à l'employé en service qui réalise une prestation (part du prix)
SERVICE_COMMISSION = 0.10


def clamp_stage(level) -> int:
    try:
        return max(1, min(MAX_STAGE, int(level)))
    except (TypeError, ValueError):
        return 1


def stage_name(level) -> str:
    return STAGES[clamp_stage(level) - 1]["name"]


def stage_emoji(level) -> str:
    return STAGE_EMOJI[clamp_stage(level) - 1]


def stage_cap(level) -> float:
    return STAGES[clamp_stage(level) - 1]["cap"]


SECTOR_TEAMS: dict[str, dict] = {
    "Alimentation": {"emoji": "🍽️", "motto": "Du champ à l'assiette",
                     "depts": {"appro": ("Approvisionnement", "🧺"), "cuisine": ("Cuisine", "🍳"),
                               "service": ("Service & livraison", "🛵")}},
    "Énergie":      {"emoji": "⚡", "motto": "Faire tourner la ville",
                     "depts": {"extraction": ("Extraction & production", "⛏️"), "reseau": ("Réseau & distribution", "🔌"),
                               "maintenance": ("Maintenance", "🔧")}},
    "Industrie":    {"emoji": "🏭", "motto": "Fabriquer en série",
                     "depts": {"usinage": ("Usinage", "🏭"), "assemblage": ("Assemblage", "🔩"),
                               "qualite": ("Contrôle qualité", "✅")}},
    "Technologie":  {"emoji": "💻", "motto": "Le futur en code",
                     "depts": {"dev": ("Développement", "💻"), "infra": ("Infrastructure", "🖥️"),
                               "support": ("Support & déploiement", "🎧")}},
    "Finance":      {"emoji": "💹", "motto": "L'argent qui travaille",
                     "depts": {"analyse": ("Analyse", "📈"), "conseil": ("Conseil clientèle", "🤝"),
                               "conformite": ("Conformité", "📑")}},
    "Commerce":     {"emoji": "🛒", "motto": "Acheter, stocker, vendre",
                     "depts": {"achats": ("Achats & logistique", "📦"), "vente": ("Vente", "🛍️"),
                               "stock": ("Gestion de stock", "🗂️")}},
    "Médias":       {"emoji": "📺", "motto": "Faire parler de soi",
                     "depts": {"redaction": ("Rédaction", "✍️"), "production": ("Production", "🎬"),
                               "diffusion": ("Diffusion & régie", "📡")}},
    "Immobilier":   {"emoji": "🏘️", "motto": "Pierre et confiance",
                     "depts": {"prospection": ("Prospection", "🔍"), "travaux": ("Travaux", "🏗️"),
                               "gestion": ("Gestion locative", "🗝️")}},
    "Sport":        {"emoji": "🏅", "motto": "Plus vite, plus haut",
                     "depts": {"coaching": ("Coaching", "🏋️"), "medical": ("Suivi médical", "🩺"),
                               "evenement": ("Événementiel", "🏟️")}},
    "Arts":         {"emoji": "🎭", "motto": "Créer et émouvoir",
                     "depts": {"creation": ("Création", "🎨"), "scene": ("Scène & production", "🎭"),
                               "galerie": ("Galerie", "🖼️")}},
    "Luxe":         {"emoji": "💎", "motto": "L'excellence a un prix",
                     "depts": {"atelier": ("Atelier", "💎"), "design": ("Design", "✏️"),
                               "boutique": ("Boutique & conciergerie", "🛎️")}},
}
SECTORS_CHAIN = list(SECTOR_TEAMS)            # ordre d'affichage


def dept_label(sector: str, dept: str) -> str:
    d = SECTOR_TEAMS.get(sector, {}).get("depts", {}).get(dept)
    return f"{d[1]} {d[0]}" if d else "👥 Polyvalent"


# ═════════════════════════════════════════════════════════════════════════════
# 5. RECETTES — chaque secteur : 2 produits finis, fabriqués en 2 ou 3 étapes
# ═════════════════════════════════════════════════════════════════════════════
def _S(name, dept, inputs, out, effort, cost):
    """Une étape de fabrication.
       inputs : {bien: quantité} consommés par LOT · out : (bien, quantité) produits par lot
       effort : points d'activité du département par lot · cost : €A de frais (énergie, matériel) par lot"""
    return {"name": name, "dept": dept, "in": dict(inputs), "out": out, "effort": effort, "cost": cost}


# type 'bien'    : objet d'inventaire (grossiste → commerçant → marché → joueur qui l'utilise)
# type 'service' : prestation directe (le client paie l'entreprise, un employé en service l'exécute)
# base_cap : unités de produit fini par jour au stade 1 (× capacité du stade) = commandes du marché national
# min_price / npc_price : prix de vente au marché national (calculé depuis le coût si absent, voir §8)
RECIPES: dict[str, dict] = {
    # ── Alimentation ────────────────────────────────────────────────────────
    "repas": {
        "sector": "Alimentation", "name": "Repas préparés", "emoji": "🍱", "type": "bien", "min_stage": 1,
        "base_cap": 36, "xp": 2, "desc": "Plats prêts à manger pour tous les jours.",
        "steps": [
            _S("Approvisionnement", "appro", {"recolte": 2, "transport": 1}, ("ingredients", 6), 2, 150),
            _S("Cuisine", "cuisine", {"ingredients": 6, "salle": 1}, ("repas", 6), 3, 300),
        ],
        "effects": [("hunger", 40), ("energy", 10), ("happiness", 2)],
    },
    "gastro": {
        "sector": "Alimentation", "name": "Menu gastronomique", "emoji": "🍾", "type": "service", "min_stage": 3,
        "base_cap": 12, "xp": 6, "desc": "Table d'exception, servie par la brigade en salle.",
        "steps": [
            _S("Sélection des produits", "appro", {"recolte": 3, "transport": 1, "distribution": 1}, ("produits_fins", 3), 3, 400),
            _S("Cuisine d'auteur", "cuisine", {"produits_fins": 3, "creation": 1}, ("plats_gastro", 3), 5, 900),
            _S("Service en salle", "service", {"plats_gastro": 3, "salle": 2}, ("gastro", 3), 3, 400),
        ],
        "effects": [("hunger", 80), ("energy", 25), ("happiness", 12), ("stress", -10)],
        "service_dept": "service",
    },
    # ── Énergie ─────────────────────────────────────────────────────────────
    "carburant": {
        "sector": "Énergie", "name": "Carburant", "emoji": "⛽", "type": "bien", "min_stage": 1,
        "base_cap": 28, "xp": 2, "desc": "Fait le plein du véhicule actif.",
        "steps": [
            _S("Extraction", "extraction", {"mat_brut": 3, "securite": 1}, ("brut", 6), 3, 600),
            _S("Raffinage & distribution", "reseau", {"brut": 6, "transport": 1}, ("carburant", 6), 3, 600),
        ],
        "effects": [("fuel", 40)],
    },
    "batterie": {
        "sector": "Énergie", "name": "Cellule d'énergie", "emoji": "🔋", "type": "bien", "min_stage": 3,
        "base_cap": 10, "xp": 6, "desc": "Recharge instantanée de ton énergie.",
        "steps": [
            _S("Production d'électricité", "extraction", {"mat_brut": 2, "pieces": 1}, ("electricite", 4), 3, 800),
            _S("Stockage", "maintenance", {"electricite": 4, "pieces": 2, "securite": 1}, ("batterie", 2), 5, 1000),
        ],
        "effects": [("energy", 45)],
    },
    # ── Industrie ───────────────────────────────────────────────────────────
    "pieces_auto": {
        "sector": "Industrie", "name": "Pièces détachées", "emoji": "🔧", "type": "bien", "min_stage": 1,
        "base_cap": 18, "xp": 2, "desc": "Répare l'état du véhicule actif.",
        "steps": [
            _S("Usinage", "usinage", {"mat_brut": 4, "pieces": 1}, ("composants", 4), 3, 500),
            _S("Assemblage", "assemblage", {"composants": 4, "pieces": 1}, ("pieces_auto", 4), 3, 500),
        ],
        "effects": [("repair", 35)],
    },
    "kit_maison": {
        "sector": "Industrie", "name": "Kit de rénovation", "emoji": "🧰", "type": "bien", "min_stage": 2,
        "base_cap": 9, "xp": 4, "desc": "Remet en état ton bien immobilier le plus abîmé.",
        "steps": [
            _S("Usinage", "usinage", {"mat_brut": 3, "pieces": 1}, ("composants", 3), 3, 500),
            _S("Assemblage", "assemblage", {"composants": 3, "transport": 1}, ("kits_bruts", 3), 3, 400),
            _S("Contrôle qualité", "qualite", {"kits_bruts": 3, "securite": 1}, ("kit_maison", 3), 2, 300),
        ],
        "effects": [("repair_home", 30)],
    },
    # ── Technologie ─────────────────────────────────────────────────────────
    "formation_log": {
        "sector": "Technologie", "name": "Formation logicielle", "emoji": "🧠", "type": "service", "min_stage": 1,
        "base_cap": 8, "xp": 3, "desc": "Une formation sur-mesure, animée par l'équipe support.",
        "steps": [
            _S("Développement", "dev", {"code": 2}, ("modules", 2), 4, 800),
            _S("Déploiement & formation", "support", {"modules": 2, "visibilite": 1}, ("formation_log", 2), 3, 400),
        ],
        "effects": [("xp", 300)],
        "service_dept": "support",
    },
    "pare_feu": {
        "sector": "Technologie", "name": "Licence pare-feu", "emoji": "🛡️", "type": "bien", "min_stage": 2,
        "base_cap": 5, "xp": 5, "desc": "Protège ton compte du piratage (3 jours de jeu).",
        "steps": [
            _S("Développement sécurisé", "dev", {"code": 2, "securite": 1}, ("modules_secu", 2), 5, 1000),
            _S("Mise en production", "infra", {"modules_secu": 2, "pieces": 1}, ("pare_feu", 2), 4, 800),
        ],
        "effects": [("antihack", 3)],
    },
    # ── Finance ─────────────────────────────────────────────────────────────
    "assurance_veh": {
        "sector": "Finance", "name": "Assurance auto", "emoji": "🚗", "type": "service", "min_stage": 1,
        "base_cap": 6, "xp": 4, "desc": "Assure ton véhicule actif auprès de l'équipe conseil.",
        "steps": [
            _S("Analyse du risque", "analyse", {"compta": 2}, ("dossiers", 4), 3, 600),
            _S("Souscription", "conseil", {"dossiers": 4, "distribution": 1}, ("assurance_veh", 4), 3, 500),
        ],
        "effects": [("insure", 1)],
        "service_dept": "conseil",
    },
    "produit_struct": {
        "sector": "Finance", "name": "Conseil patrimonial", "emoji": "💼", "type": "service", "min_stage": 3,
        "base_cap": 3, "xp": 8, "desc": "Montage patrimonial : prestige et savoir-faire.",
        "steps": [
            _S("Modélisation", "analyse", {"compta": 3, "code": 1}, ("modeles", 2), 4, 1200),
            _S("Validation réglementaire", "conformite", {"modeles": 2, "securite": 1}, ("dossier_valide", 2), 4, 1000),
            _S("Conseil", "conseil", {"dossier_valide": 2, "distribution": 1, "visibilite": 1}, ("produit_struct", 2), 4, 800),
        ],
        "effects": [("prestige", 3), ("xp", 400)],
        "service_dept": "conseil",
    },
    # ── Commerce ────────────────────────────────────────────────────────────
    "panier": {
        "sector": "Commerce", "name": "Panier de marchandises", "emoji": "🧺", "type": "bien", "min_stage": 1,
        "base_cap": 36, "xp": 2, "desc": "Provisions pour tenir la semaine.",
        "steps": [
            _S("Achats & transport", "achats", {"mat_brut": 1, "transport": 2}, ("lots", 6), 2, 200),
            _S("Mise en rayon", "vente", {"lots": 6, "caisse": 1, "distribution": 1}, ("panier", 6), 3, 250),
        ],
        "effects": [("hunger", 25), ("happiness", 4)],
    },
    "colis": {
        "sector": "Commerce", "name": "Colis cadeau", "emoji": "🎁", "type": "bien", "min_stage": 2,
        "base_cap": 14, "xp": 4, "desc": "Fait plaisir… et rend meilleur.",
        "steps": [
            _S("Sélection & emballage", "achats", {"creation": 1, "transport": 1}, ("emballages", 3), 3, 350),
            _S("Mise en vente", "vente", {"emballages": 3, "caisse": 1}, ("colis", 3), 3, 300),
        ],
        "effects": [("happiness", 18), ("karma", 2)],
    },
    # ── Médias ──────────────────────────────────────────────────────────────
    "pub": {
        "sector": "Médias", "name": "Campagne publicitaire", "emoji": "📣", "type": "service", "min_stage": 1,
        "base_cap": 14, "xp": 2, "desc": "Fait grimper ton nombre d'abonnés.",
        "steps": [
            _S("Rédaction", "redaction", {"creation": 1, "visibilite": 1}, ("contenu", 3), 3, 250),
            _S("Diffusion", "diffusion", {"contenu": 3, "visibilite": 1}, ("pub", 3), 3, 300),
        ],
        "effects": [("followers", 150)],
        "service_dept": "diffusion",
    },
    "docu": {
        "sector": "Médias", "name": "Production audiovisuelle", "emoji": "🎬", "type": "service", "min_stage": 3,
        "base_cap": 4, "xp": 7, "desc": "Un film sur toi : abonnés et prestige.",
        "steps": [
            _S("Tournage", "production", {"creation": 2, "securite": 1, "transport": 1}, ("rushes", 2), 5, 1200),
            _S("Montage", "production", {"rushes": 2, "code": 1}, ("docu_brut", 2), 5, 1200),
            _S("Diffusion", "diffusion", {"docu_brut": 2, "visibilite": 2}, ("docu", 2), 4, 900),
        ],
        "effects": [("followers", 700), ("prestige", 1)],
        "service_dept": "diffusion",
    },
    # ── Immobilier ──────────────────────────────────────────────────────────
    "gestion": {
        "sector": "Immobilier", "name": "Gestion locative", "emoji": "🏘️", "type": "service", "min_stage": 1,
        "base_cap": 5, "xp": 3, "desc": "Entretien de tout ton patrimoine immobilier.",
        "steps": [
            _S("Prospection & mandats", "prospection", {"compta": 1, "securite": 1}, ("mandats", 2), 3, 500),
            _S("Suivi des biens", "gestion", {"mandats": 2, "distribution": 1, "mat_brut": 1}, ("gestion", 2), 3, 500),
        ],
        "effects": [("repair_home_all", 20)],
        "service_dept": "gestion",
    },
    "programme": {
        "sector": "Immobilier", "name": "Programme immobilier", "emoji": "🏙️", "type": "service", "min_stage": 4,
        "base_cap": 2, "xp": 10, "desc": "Un programme à ton nom : le prestige de la pierre.",
        "steps": [
            _S("Études", "prospection", {"compta": 2, "code": 1}, ("etudes", 2), 5, 1500),
            _S("Gros œuvre", "travaux", {"etudes": 2, "mat_brut": 6, "pieces": 2}, ("gros_oeuvre", 2), 8, 3000),
            _S("Commercialisation", "gestion", {"gros_oeuvre": 2, "visibilite": 2, "distribution": 1}, ("programme", 2), 5, 1500),
        ],
        "effects": [("prestige", 6)],
        "service_dept": "gestion",
    },
    # ── Sport ───────────────────────────────────────────────────────────────
    "seance": {
        "sector": "Sport", "name": "Séance de coaching", "emoji": "🏋️", "type": "service", "min_stage": 1,
        "base_cap": 14, "xp": 3, "desc": "Un coach, de l'énergie, de l'expérience.",
        "steps": [
            _S("Programme", "coaching", {"performance": 1, "soins": 1}, ("programmes", 3), 3, 400),
            _S("Séance encadrée", "coaching", {"programmes": 3, "salle": 1}, ("seance", 3), 3, 300),
        ],
        "effects": [("health", 10), ("energy", 15), ("xp", 120)],
        "service_dept": "coaching",
    },
    "stage_sport": {
        "sector": "Sport", "name": "Stage de performance", "emoji": "🏅", "type": "service", "min_stage": 3,
        "base_cap": 4, "xp": 8, "desc": "Un stage intensif : une compétence physique progresse.",
        "steps": [
            _S("Plan de performance", "coaching", {"performance": 2, "soins": 1}, ("plans_perf", 2), 4, 900),
            _S("Suivi médical", "medical", {"plans_perf": 2, "soins": 2}, ("plans_ok", 2), 4, 800),
            _S("Stage", "evenement", {"plans_ok": 2, "securite": 1, "transport": 1}, ("stage_sport", 2), 5, 900),
        ],
        "effects": [("skill", 1)],
        "service_dept": "evenement",
    },
    # ── Arts ────────────────────────────────────────────────────────────────
    "spectacle": {
        "sector": "Arts", "name": "Spectacle privé", "emoji": "🎭", "type": "service", "min_stage": 1,
        "base_cap": 12, "xp": 3, "desc": "Une représentation rien que pour toi.",
        "steps": [
            _S("Répétitions", "creation", {"creation": 2, "securite": 1}, ("maquettes", 3), 3, 350),
            _S("Représentation", "scene", {"maquettes": 3, "caisse": 1}, ("spectacle", 3), 3, 350),
        ],
        "effects": [("happiness", 25), ("stress", -15)],
        "service_dept": "scene",
    },
    "oeuvre": {
        "sector": "Arts", "name": "Œuvre d'art originale", "emoji": "🖼️", "type": "bien", "min_stage": 3,
        "base_cap": 3, "xp": 8, "desc": "Une pièce unique, signée.",
        "steps": [
            _S("Préparation", "creation", {"creation": 2, "mat_brut": 2}, ("toiles", 1), 4, 900),
            _S("Exécution", "creation", {"toiles": 1, "creation": 2}, ("oeuvre_brute", 1), 6, 1200),
            _S("Mise en galerie", "galerie", {"oeuvre_brute": 1, "securite": 1, "visibilite": 1}, ("oeuvre", 1), 3, 700),
        ],
        "effects": [("prestige", 4), ("happiness", 8)],
    },
    # ── Luxe ────────────────────────────────────────────────────────────────
    "article_luxe": {
        "sector": "Luxe", "name": "Article de luxe", "emoji": "💎", "type": "bien", "min_stage": 1,
        "base_cap": 4, "xp": 5, "desc": "Un objet rare : du prestige à porter.",
        "steps": [
            _S("Atelier", "atelier", {"mat_brut": 4, "pieces": 2, "creation": 1}, ("matieres_nobles", 1), 4, 2000),
            _S("Finition & boutique", "boutique", {"matieres_nobles": 1, "creation": 2, "distribution": 1}, ("article_luxe", 1), 4, 1500),
        ],
        "effects": [("prestige", 3)],
        "min_price": 18_000,
    },
    "haute_couture": {
        "sector": "Luxe", "name": "Pièce de haute couture", "emoji": "👑", "type": "bien", "min_stage": 4,
        "base_cap": 2, "xp": 14, "desc": "Une pièce d'exception : prestige et plaisir.",
        "steps": [
            _S("Design", "design", {"creation": 3, "visibilite": 1}, ("prototypes", 1), 5, 3000),
            _S("Atelier", "atelier", {"prototypes": 1, "mat_brut": 6, "pieces": 3}, ("couture_brute", 1), 8, 5000),
            _S("Conciergerie", "boutique", {"couture_brute": 1, "creation": 1, "securite": 1, "distribution": 1}, ("haute_couture", 1), 4, 2500),
        ],
        "effects": [("prestige", 10), ("happiness", 15)],
        "min_price": 60_000,
    },
}
# Intermédiaires non déclarés plus haut : noms automatiques
for _r in RECIPES.values():
    for _st in _r["steps"]:
        _g = _st["out"][0]
        if _g not in INTERMEDIAIRES and _g != next(k for k, v in RECIPES.items() if v is _r):
            INTERMEDIAIRES.setdefault(_g, {"name": _g.replace("_", " ").capitalize(), "emoji": "📦"})

RECIPES_BY_SECTOR: dict[str, list[str]] = {}
for _k, _r in RECIPES.items():
    RECIPES_BY_SECTOR.setdefault(_r["sector"], []).append(_k)
for _s in RECIPES_BY_SECTOR.values():
    _s.sort(key=lambda k: RECIPES[k]["min_stage"])


# ═════════════════════════════════════════════════════════════════════════════
# 6. EFFETS des produits finis (sur le joueur, son véhicule, ses biens)
# ═════════════════════════════════════════════════════════════════════════════
EFFECT_LABEL = {
    "hunger": "🍽️ Faim", "energy": "⚡ Énergie", "health": "❤️ Santé", "happiness": "😊 Bonheur",
    "stress": "🧘 Stress", "xp": "✨ XP", "prestige": "👑 Prestige", "followers": "👥 Abonnés",
    "karma": "☯️ Karma", "skill": "🧠 Compétence physique", "fuel": "⛽ Carburant du véhicule",
    "repair": "🔧 État du véhicule", "insure": "🛡️ Assurance du véhicule",
    "repair_home": "🏠 État du bien le plus abîmé", "repair_home_all": "🏘️ État de tous tes biens",
    "antihack": "💻 Protection anti-piratage (jours)",
}
PHYSICAL_SKILLS = ("Force", "Endurance", "Agilité")


def describe_effects(effects) -> str:
    parts = []
    for key, val in effects:
        label = EFFECT_LABEL.get(key, key)
        if key in ("skill", "insure"):
            parts.append(f"{label} +{val}" if key == "skill" else label)
        else:
            parts.append(f"{label} {val:+d}")
    return " · ".join(parts)


# ═════════════════════════════════════════════════════════════════════════════
# 8. OUTILS DE CALCUL — noms, coûts, prix (calculés depuis les recettes) et validation
# ═════════════════════════════════════════════════════════════════════════════
def good_info(key: str) -> dict:
    """{'name','emoji','kind','ref'?} pour n'importe quel bien (intrant, intermédiaire ou produit fini)."""
    if key in INTRANTS:
        v = INTRANTS[key]
        return {"name": v["name"], "emoji": v["emoji"], "kind": "intrant", "ref": v["ref"]}
    if key in RECIPES:
        v = RECIPES[key]
        return {"name": v["name"], "emoji": v["emoji"], "kind": "final", "ref": 0}
    v = INTERMEDIAIRES.get(key)
    if v:
        return {"name": v["name"], "emoji": v["emoji"], "kind": "inter", "ref": 0}
    return {"name": key, "emoji": "📦", "kind": "inter", "ref": 0}


def good_label(key: str) -> str:
    g = good_info(key)
    return f"{g['emoji']} {g['name']}"


def _unit_costs(recipe_key: str, input_mult: float = 1.0) -> dict[str, float]:
    """Coût de revient de chaque bien produit par la recette : somme des intrants (au prix de référence
    × input_mult) + frais de l'étape, divisée par la quantité produite. Les intermédiaires héritent du coût."""
    r = RECIPES[recipe_key]
    cost: dict[str, float] = {k: v["ref"] * input_mult for k, v in INTRANTS.items()}
    for st in r["steps"]:
        total = st["cost"] + sum(cost[g] * q for g, q in st["in"].items())
        cost[st["out"][0]] = total / st["out"][1]
    return cost


def unit_cost_ref(recipe_key: str, input_mult: float = 1.0) -> float:
    return _unit_costs(recipe_key, input_mult)[recipe_key]


def _round50(x: float) -> int:
    return int(math.ceil(x / 50.0) * 50)


PRICE_MARKUP = 1.85       # prix de vente au marché national = coût de revient (prix de référence) × 1,85
WHOLESALE_MARKUP = 1.12   # prix de gros par défaut = prix national × 1,12 (le commerçant revend plus cher)


def npc_price(recipe_key: str) -> int:
    r = RECIPES[recipe_key]
    return max(r.get("min_price", 0), _round50(unit_cost_ref(recipe_key) * PRICE_MARKUP))


def wholesale_default(recipe_key: str) -> int:
    return _round50(npc_price(recipe_key) * WHOLESALE_MARKUP)


def recipe_needs(recipe_key: str) -> dict[str, int]:
    """Intrants (non fabriqués par l'entreprise elle-même) consommés par une recette, par lot de chaque étape."""
    needs: dict[str, int] = {}
    for st in RECIPES[recipe_key]["steps"]:
        for g, q in st["in"].items():
            if g in INTRANTS:
                needs[g] = needs.get(g, 0) + q
    return needs


def sector_inputs(sector: str) -> set[str]:
    """Tous les intrants qu'une entreprise du secteur peut consommer."""
    out: set[str] = set()
    for rk in RECIPES_BY_SECTOR.get(sector, []):
        out |= set(recipe_needs(rk))
    return out


def sector_depts(sector: str) -> dict:
    return SECTOR_TEAMS.get(sector, {}).get("depts", {})


def final_service_dept(recipe_key: str) -> str:
    r = RECIPES[recipe_key]
    return r.get("service_dept") or r["steps"][-1]["dept"]


def validate() -> list[str]:
    """Contrôle de cohérence des données (utilisé par les tests) : renvoie la liste des erreurs."""
    errs: list[str] = []
    for sec in SECTORS_CHAIN:
        if sec not in RECIPES_BY_SECTOR:
            errs.append(f"secteur sans recette : {sec}")
        elif len(RECIPES_BY_SECTOR[sec]) < 2:
            errs.append(f"{sec} : au moins 2 produits attendus")
        elif RECIPES[RECIPES_BY_SECTOR[sec][0]]["min_stage"] != 1:
            errs.append(f"{sec} : la première recette doit être accessible dès le stade 1")
    for k, r in RECIPES.items():
        if r["sector"] not in SECTOR_TEAMS:
            errs.append(f"{k} : secteur inconnu")
            continue
        depts = sector_depts(r["sector"])
        produced: set[str] = set()
        for i, st in enumerate(r["steps"]):
            if st["dept"] not in depts:
                errs.append(f"{k} étape {i + 1} : équipe inconnue {st['dept']}")
            for g in st["in"]:
                if g not in INTRANTS and g not in produced:
                    errs.append(f"{k} étape {i + 1} : « {g} » n'est ni un intrant ni produit avant")
            produced.add(st["out"][0])
        if r["steps"][-1]["out"][0] != k:
            errs.append(f"{k} : la dernière étape doit produire le produit fini")
        if not r.get("effects"):
            errs.append(f"{k} : aucun effet défini")
        if r["type"] not in ("bien", "service"):
            errs.append(f"{k} : type invalide")
        if len({st["dept"] for st in r["steps"]}) < 2 and r["type"] == "service" and len(r["steps"]) > 1:
            pass
        if not 1 <= r["min_stage"] <= MAX_STAGE:
            errs.append(f"{k} : stade minimal invalide")
        if r["type"] == "service" and final_service_dept(k) not in depts:
            errs.append(f"{k} : équipe de service inconnue")
        for ek, _v in r["effects"]:
            if ek not in EFFECT_LABEL:
                errs.append(f"{k} : effet inconnu {ek}")
        # marges : rentable au prix de référence, et encore rentable avec le fournisseur national
        price = npc_price(k)
        if price <= unit_cost_ref(k):
            errs.append(f"{k} : vendu à perte")
        if price <= unit_cost_ref(k, NPC_SUPPLY_MARKUP):
            errs.append(f"{k} : invendable avec le fournisseur national (marge négative)")
    for job, good in JOB_GOOD.items():
        if not job:
            continue
    for k, v in INTRANTS.items():
        if v["job"] and v["units"] <= 0:
            errs.append(f"{k} : le métier {v['job']} ne fournit rien")
    if any(STAGES[i]["xp"] >= STAGES[i + 1]["xp"] for i in range(MAX_STAGE - 1)):
        errs.append("STAGES : l'XP doit augmenter")
    return errs
