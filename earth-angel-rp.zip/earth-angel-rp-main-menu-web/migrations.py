# migrations.py
import logging

import aiosqlite

from config import DB_PATH
from database import DB_TIMEOUT, _configure_connection


logger = logging.getLogger(__name__)


MIGRATIONS: list[tuple[int, tuple[str, ...]]] = [
    (
        1,
        (
            "CREATE TABLE IF NOT EXISTS user_cooldowns ("
            "user_id INTEGER NOT NULL,"
            "cooldown_key TEXT NOT NULL,"
            "last_used INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY(user_id,cooldown_key)"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_user_cooldowns_last_used "
            "ON user_cooldowns(last_used)",
        ),
    ),
    (
        2,
        (
            "CREATE INDEX IF NOT EXISTS idx_market_status_expiry "
            "ON market_listings(status,expires_at)",
            "CREATE INDEX IF NOT EXISTS idx_mp_trades_status_expiry "
            "ON mp_trades(status,expires_at)",
            "CREATE INDEX IF NOT EXISTS idx_rental_proposals_status "
            "ON rental_proposals(property_id,status)",
        ),
    ),
    (
        3,
        (
            "CREATE TABLE IF NOT EXISTS arena_matches ("
            "match_id TEXT PRIMARY KEY,"
            "challenger_id INTEGER NOT NULL,"
            "target_id INTEGER NOT NULL,"
            "game TEXT NOT NULL,"
            "bet INTEGER NOT NULL CHECK(bet>0),"
            "pot INTEGER NOT NULL DEFAULT 0 CHECK(pot>=0),"
            "status TEXT NOT NULL DEFAULT 'pending',"
            "challenger_choice TEXT DEFAULT '',"
            "target_choice TEXT DEFAULT '',"
            "winner_id INTEGER DEFAULT 0,"
            "created_at INTEGER NOT NULL,"
            "accepted_at INTEGER DEFAULT 0,"
            "expires_at INTEGER NOT NULL,"
            "settled_at INTEGER DEFAULT 0,"
            "result_text TEXT DEFAULT ''"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_arena_status_expiry "
            "ON arena_matches(status,expires_at)",
            "CREATE INDEX IF NOT EXISTS idx_arena_challenger "
            "ON arena_matches(challenger_id,status)",
            "CREATE INDEX IF NOT EXISTS idx_arena_target "
            "ON arena_matches(target_id,status)",
        ),
    ),
    (
        4,
        (
            # ─── Abonnements VIP / Premium (Telegram Stars) ───
            "ALTER TABLE users ADD COLUMN vip_until INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN premium_until INTEGER DEFAULT 0",
            # ─── Boosts temporaires (boutique étoiles, catégorie 1) ───
            "ALTER TABLE users ADD COLUMN boost_xp2_until INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN boost_coins2_until INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN boost_chance_until INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN boost_jardin_until INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN boost_vitesse_until INTEGER DEFAULT 0",
            # ─── Améliorations permanentes cumulables (catégorie 2) ───
            "ALTER TABLE users ADD COLUMN extra_inventory_slots INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN extra_garden_plots INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN extra_properties INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN extra_vehicles INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN extra_work_cd_reduction INTEGER DEFAULT 0",
            "ALTER TABLE users ADD COLUMN extra_casino_spins INTEGER DEFAULT 0",
            # ─── Cosmétiques (catégorie 4) ───
            "ALTER TABLE users ADD COLUMN profile_title TEXT DEFAULT ''",
            "ALTER TABLE users ADD COLUMN profile_badge TEXT DEFAULT ''",
            "ALTER TABLE users ADD COLUMN signature_emoji TEXT DEFAULT ''",
            # ─── Historique des paiements en Étoiles (audit + remboursements) ───
            "CREATE TABLE IF NOT EXISTS star_purchases ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "user_id INTEGER NOT NULL,"
            "item_id TEXT NOT NULL,"
            "stars_amount INTEGER NOT NULL,"
            "charge_id TEXT NOT NULL,"
            "payload TEXT NOT NULL,"
            "refunded INTEGER NOT NULL DEFAULT 0,"
            "created_at INTEGER NOT NULL"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_star_purchases_user "
            "ON star_purchases(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_star_purchases_charge "
            "ON star_purchases(charge_id)",
        ),
    ),
    (
        5,
        (
            # ─── Monde RP : position des joueurs et trajets en cours ───
            "CREATE TABLE IF NOT EXISTS user_position ("
            "user_id INTEGER PRIMARY KEY,"
            "location TEXT NOT NULL DEFAULT 'maison',"
            "travel_to TEXT NOT NULL DEFAULT '',"
            "travel_from TEXT NOT NULL DEFAULT '',"
            "travel_mode TEXT NOT NULL DEFAULT '',"
            "depart_at INTEGER NOT NULL DEFAULT 0,"
            "arrive_at INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_user_position_arrival "
            "ON user_position(arrive_at) WHERE travel_to != ''",
            # Migration sans perte : tous les joueurs existants démarrent chez eux.
            "INSERT OR IGNORE INTO user_position(user_id) SELECT user_id FROM users",
        ),
    ),
    (
        6,
        (
            # ─── Rôles d'entreprise ───
            "ALTER TABLE company_members ADD COLUMN role TEXT NOT NULL DEFAULT 'employe'",
            "UPDATE company_members SET role='owner' WHERE user_id IN "
            "(SELECT owner_id FROM companies WHERE companies.company_id=company_members.company_id)",
            # Anciens « Directeur » / « PDG » non créateurs gardent leurs pouvoirs → gérants
            "UPDATE company_members SET role='manager' WHERE role='employe' AND poste IN ('Directeur','PDG')",
            # ─── Factions gouvernementales ───
            "CREATE TABLE IF NOT EXISTS faction_state ("
            "faction TEXT PRIMARY KEY,"
            "budget INTEGER NOT NULL DEFAULT 0 CHECK(budget>=0)"
            ")",
            "CREATE TABLE IF NOT EXISTS faction_members ("
            "user_id INTEGER PRIMARY KEY,"
            "faction TEXT NOT NULL,"
            "rank INTEGER NOT NULL DEFAULT 0,"
            "activity_score INTEGER NOT NULL DEFAULT 0,"
            "joined_at INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_faction_members_faction ON faction_members(faction)",
            "CREATE TABLE IF NOT EXISTS faction_applications ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "user_id INTEGER NOT NULL,"
            "faction TEXT NOT NULL,"
            "status TEXT NOT NULL DEFAULT 'pending',"
            "created_at INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_faction_app_pending "
            "ON faction_applications(user_id, faction) WHERE status='pending'",
            # ─── Demandes de promotion en entreprise ───
            "CREATE TABLE IF NOT EXISTS promotion_requests ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "user_id INTEGER NOT NULL,"
            "company_id INTEGER NOT NULL,"
            "status TEXT NOT NULL DEFAULT 'pending',"
            "created_at INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_promo_pending "
            "ON promotion_requests(user_id, company_id) WHERE status='pending'",
            # ─── Journal de paie : 1 ligne par (type, entité, joueur, jour de jeu) = jamais payé 2 fois ───
            "CREATE TABLE IF NOT EXISTS payroll_log ("
            "kind TEXT NOT NULL,"
            "entity TEXT NOT NULL,"
            "user_id INTEGER NOT NULL,"
            "day INTEGER NOT NULL,"
            "amount INTEGER NOT NULL,"
            "status TEXT NOT NULL,"
            "PRIMARY KEY(kind, entity, user_id, day)"
            ")",
        ),
    ),
    (
        7,
        (
            # Activité de l'équipe par jour de jeu (alimentée par /travailler) ; `consumed` = déjà transformée en production
            "CREATE TABLE IF NOT EXISTS company_activity ("
            "company_id INTEGER NOT NULL,"
            "day INTEGER NOT NULL,"
            "points INTEGER NOT NULL DEFAULT 0,"
            "consumed INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY(company_id, day)"
            ")",
            # Stock de l'entreprise (distinct de l'inventaire du créateur)
            "CREATE TABLE IF NOT EXISTS company_stock ("
            "company_id INTEGER NOT NULL,"
            "product TEXT NOT NULL,"
            "quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity>=0),"
            "PRIMARY KEY(company_id, product)"
            ")",
            "CREATE TABLE IF NOT EXISTS company_production_state ("
            "company_id INTEGER PRIMARY KEY,"
            "level INTEGER NOT NULL DEFAULT 2,"
            "carry REAL NOT NULL DEFAULT 0"
            ")",
            "CREATE TABLE IF NOT EXISTS company_production_log ("
            "company_id INTEGER NOT NULL,"
            "day INTEGER NOT NULL,"
            "produced INTEGER NOT NULL DEFAULT 0,"
            "sold INTEGER NOT NULL DEFAULT 0,"
            "cost INTEGER NOT NULL DEFAULT 0,"
            "revenue INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY(company_id, day)"
            ")",
        ),
    ),
    (
        8,
        (
            # Offres de revente d'un civil à un commerçant (objets mis sous séquestre jusqu'à la réponse)
            "CREATE TABLE IF NOT EXISTS merchant_offers ("
            "offer_id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "seller_id INTEGER NOT NULL,"
            "merchant_id INTEGER NOT NULL,"
            "item_id INTEGER NOT NULL,"
            "quantity INTEGER NOT NULL CHECK(quantity>0),"
            "unit_price INTEGER NOT NULL CHECK(unit_price>0),"
            "status TEXT NOT NULL DEFAULT 'pending',"
            "created_at INTEGER NOT NULL,"
            "expires_at INTEGER NOT NULL"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_merchant_offers_status "
            "ON merchant_offers(status, expires_at)",
        ),
    ),
    (
        9,
        (
            # Candidatures aux gangs (acceptées par l'encadrement)
            "CREATE TABLE IF NOT EXISTS gang_applications ("
            "app_id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "gang_id INTEGER NOT NULL,"
            "user_id INTEGER NOT NULL,"
            "status TEXT NOT NULL DEFAULT 'pending',"
            "created_at INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_gang_app_pending "
            "ON gang_applications(gang_id, user_id) WHERE status='pending'",
        ),
    ),
    (
        10,
        (
            # Ancien poste par défaut « Membre » → « Recrue » (hiérarchie Chef > Bras droit > Lieutenant > Soldat > Recrue)
            "UPDATE gang_members SET role='Recrue' WHERE role='Membre'",
        ),
    ),
    (
        11,
        (
            # Chambre PNJ louée par un joueur (un seul logement PNJ par joueur)
            "CREATE TABLE IF NOT EXISTS housing_npc ("
            "user_id INTEGER PRIMARY KEY,"
            "name TEXT NOT NULL,"
            "daily_cost INTEGER NOT NULL,"
            "since INTEGER NOT NULL"
            ")",
            # Jours d'impayés consécutifs : kind = rental | npc | owner
            "CREATE TABLE IF NOT EXISTS housing_arrears ("
            "kind TEXT NOT NULL,"
            "ref_id INTEGER NOT NULL,"
            "days INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY(kind, ref_id)"
            ")",
        ),
    ),
    (
        12,
        (
            # ─── Santé publique : personnel (un poste + un hôpital par employé), direction unique par hôpital ───
            "CREATE TABLE IF NOT EXISTS sante_staff ("
            "user_id INTEGER PRIMARY KEY,"
            "hospital_id TEXT NOT NULL,"
            "post TEXT NOT NULL,"
            "on_duty INTEGER NOT NULL DEFAULT 0,"
            "since INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_sante_staff_hospital ON sante_staff(hospital_id)",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_sante_head ON sante_staff(hospital_id) "
            "WHERE post IN ('dg','pdg')",
            # Stocks de la faction : kind = raw (ressources) | inter (laboratoire) | med (en vente)
            "CREATE TABLE IF NOT EXISTS sante_stock ("
            "kind TEXT NOT NULL,"
            "item TEXT NOT NULL,"
            "quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity>=0),"
            "PRIMARY KEY(kind, item)"
            ")",
            # Appels : ambulance (gratuit, n'importe où) ou consultation sur place à l'hôpital
            "CREATE TABLE IF NOT EXISTS sante_calls ("
            "call_id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "patient_id INTEGER NOT NULL,"
            "kind TEXT NOT NULL,"
            "hospital_id TEXT NOT NULL DEFAULT '',"
            "status TEXT NOT NULL DEFAULT 'pending',"
            "responder_id INTEGER NOT NULL DEFAULT 0,"
            "created_at INTEGER NOT NULL DEFAULT 0,"
            "taken_at INTEGER NOT NULL DEFAULT 0,"
            "done_at INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_sante_calls_status ON sante_calls(status, created_at)",
            # Lits occupés (un joueur = un lit) ; heure RÉELLE de la mise au lit
            "CREATE TABLE IF NOT EXISTS sante_beds ("
            "user_id INTEGER PRIMARY KEY,"
            "hospital_id TEXT NOT NULL,"
            "since_real INTEGER NOT NULL"
            ")",
            # Journal d'audit (enquêtes anti-triche par les admins)
            "CREATE TABLE IF NOT EXISTS sante_logs ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "ts INTEGER NOT NULL,"
            "actor_id INTEGER NOT NULL DEFAULT 0,"
            "action TEXT NOT NULL,"
            "target_id INTEGER NOT NULL DEFAULT 0,"
            "details TEXT NOT NULL DEFAULT ''"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_sante_logs_pair ON sante_logs(action, actor_id, target_id, ts)",
        ),
    ),
    (
        13,
        (
            # ─── Service : le temps RÉEL passé « en service » détermine l'activité gagnée ───
            "CREATE TABLE IF NOT EXISTS work_duty ("
            "user_id INTEGER PRIMARY KEY,"
            "since REAL NOT NULL"
            ")",
        ),
    ),
    (
        14,
        (
            # ─── Ordre public (police & armée) : personnel — un poste + un lieu par agent, un chef par lieu ───
            "CREATE TABLE IF NOT EXISTS ordre_staff ("
            "user_id INTEGER PRIMARY KEY,"
            "faction TEXT NOT NULL,"
            "station_id TEXT NOT NULL,"
            "post TEXT NOT NULL,"
            "agent_no INTEGER NOT NULL DEFAULT 0,"
            "on_duty INTEGER NOT NULL DEFAULT 0,"
            "since INTEGER NOT NULL DEFAULT 0,"
            "activity INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_ordre_staff_station ON ordre_staff(faction, station_id)",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_ordre_head ON ordre_staff(faction, station_id) "
            "WHERE post IN ('dg','chef')",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_ordre_agent_no ON ordre_staff(faction, agent_no) WHERE agent_no>0",
            # Dossiers : crime contre le bot (fuite puis enquête), crime contre un joueur, signalement
            "CREATE TABLE IF NOT EXISTS ordre_cases ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "kind TEXT NOT NULL,"
            "crime TEXT NOT NULL DEFAULT '',"
            "suspect_id INTEGER NOT NULL,"
            "victim_id INTEGER NOT NULL DEFAULT 0,"
            "victim_gov INTEGER NOT NULL DEFAULT 0,"
            "gov_suspect INTEGER NOT NULL DEFAULT 0,"
            "reward INTEGER NOT NULL DEFAULT 0,"
            "created_at INTEGER NOT NULL,"
            "open_at INTEGER NOT NULL,"
            "status TEXT NOT NULL DEFAULT 'fuite',"
            "attempts INTEGER NOT NULL DEFAULT 0,"
            "solver_id INTEGER NOT NULL DEFAULT 0,"
            "closed_at INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_ordre_cases_status ON ordre_cases(status, open_at)",
            "CREATE INDEX IF NOT EXISTS idx_ordre_cases_suspect ON ordre_cases(suspect_id, status)",
            "CREATE INDEX IF NOT EXISTS idx_ordre_cases_victim ON ordre_cases(victim_id, created_at)",
            # États temporaires d'un joueur : stun · cuffs (menottes) · interro · hold (retenu par l'armée) · hidecd
            "CREATE TABLE IF NOT EXISTS ordre_status ("
            "user_id INTEGER NOT NULL,"
            "kind TEXT NOT NULL,"
            "until INTEGER NOT NULL,"
            "by_id INTEGER NOT NULL DEFAULT 0,"
            "extra TEXT NOT NULL DEFAULT '',"
            "PRIMARY KEY(user_id, kind)"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_ordre_status_by ON ordre_status(by_id, kind)",
            # Discussions relayées par le bot : interrogatoire ou entretien d'embauche
            "CREATE TABLE IF NOT EXISTS ordre_chats ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "kind TEXT NOT NULL,"
            "a_id INTEGER NOT NULL,"
            "b_id INTEGER NOT NULL,"
            "ref INTEGER NOT NULL DEFAULT 0,"
            "faction TEXT NOT NULL DEFAULT '',"
            "started_at INTEGER NOT NULL,"
            "expires_at INTEGER NOT NULL,"
            "status TEXT NOT NULL DEFAULT 'open'"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_ordre_chats_a ON ordre_chats(a_id, status)",
            "CREATE INDEX IF NOT EXISTS idx_ordre_chats_b ON ordre_chats(b_id, status)",
            # Candidatures (entretien d'embauche avant recrutement)
            "CREATE TABLE IF NOT EXISTS ordre_apps ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "user_id INTEGER NOT NULL,"
            "faction TEXT NOT NULL,"
            "station_id TEXT NOT NULL DEFAULT '',"
            "status TEXT NOT NULL DEFAULT 'pending',"
            "created_at INTEGER NOT NULL,"
            "handler_id INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_ordre_app_open ON ordre_apps(user_id, faction) "
            "WHERE status IN ('pending','interview')",
            # Signalements de joueurs
            "CREATE TABLE IF NOT EXISTS ordre_reports ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "reporter_id INTEGER NOT NULL,"
            "target_id INTEGER NOT NULL,"
            "reason TEXT NOT NULL DEFAULT '',"
            "status TEXT NOT NULL DEFAULT 'pending',"
            "created_at INTEGER NOT NULL,"
            "handler_id INTEGER NOT NULL DEFAULT 0,"
            "case_id INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_ordre_reports_status ON ordre_reports(status, created_at)",
            "CREATE INDEX IF NOT EXISTS idx_ordre_reports_reporter ON ordre_reports(reporter_id, created_at)",
            # Mini-jeu d'enquête en cours (un par enquêteur)
            "CREATE TABLE IF NOT EXISTS ordre_mg ("
            "user_id INTEGER PRIMARY KEY,"
            "case_id INTEGER NOT NULL,"
            "seq TEXT NOT NULL,"
            "pos INTEGER NOT NULL DEFAULT 0,"
            "started_at INTEGER NOT NULL"
            ")",
            # Défenses anti-hack achetées par les joueurs
            "CREATE TABLE IF NOT EXISTS anti_hack ("
            "user_id INTEGER PRIMARY KEY,"
            "level TEXT NOT NULL,"
            "expires_at INTEGER NOT NULL"
            ")",
            # Journal d'audit
            "CREATE TABLE IF NOT EXISTS ordre_logs ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "ts INTEGER NOT NULL,"
            "actor_id INTEGER NOT NULL DEFAULT 0,"
            "action TEXT NOT NULL,"
            "target_id INTEGER NOT NULL DEFAULT 0,"
            "details TEXT NOT NULL DEFAULT ''"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_ordre_logs_pair ON ordre_logs(action, actor_id, target_id, ts)",
        ),
    ),
    (
        15,
        (
            # ─── Boutique Étoiles : items FONCTIONNELS (pas juste cosmétiques) ───
            # Charges d'assurance anti-arrestation : annule la prison au prochain
            # crime raté (consommé automatiquement par handlers/crime.py).
            "ALTER TABLE users ADD COLUMN crime_shield_charges INTEGER DEFAULT 0",
        ),
    ),
    (
        16,
        (
            # ─── Armes : arsenal personnel (munitions limitées) et chambres d'armes des factions ───
            "CREATE TABLE IF NOT EXISTS user_weapons ("
            "user_id INTEGER NOT NULL,"
            "weapon TEXT NOT NULL,"
            "ammo INTEGER NOT NULL DEFAULT 0 CHECK(ammo>=0),"
            "equipped INTEGER NOT NULL DEFAULT 0,"
            "source TEXT NOT NULL DEFAULT 'noir',"
            "PRIMARY KEY(user_id, weapon)"
            ")",
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_user_weapon_equipped ON user_weapons(user_id) WHERE equipped=1",
            "CREATE TABLE IF NOT EXISTS armory ("
            "faction TEXT NOT NULL,"
            "weapon TEXT NOT NULL,"
            "qty INTEGER NOT NULL DEFAULT 0 CHECK(qty>=0),"
            "rounds INTEGER NOT NULL DEFAULT 0 CHECK(rounds>=0),"
            "PRIMARY KEY(faction, weapon)"
            ")",
            # ─── Justice : dossiers judiciaires (arrestation → caution / procès / peine) ───
            "CREATE TABLE IF NOT EXISTS justice_files ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "suspect_id INTEGER NOT NULL,"
            "crime TEXT NOT NULL DEFAULT '',"
            "source TEXT NOT NULL DEFAULT 'police',"
            "jail_secs INTEGER NOT NULL DEFAULT 0,"
            "bail INTEGER NOT NULL DEFAULT 0,"
            "lawyer_id INTEGER NOT NULL DEFAULT 0,"
            "plead INTEGER NOT NULL DEFAULT 0,"
            "judge_id INTEGER NOT NULL DEFAULT 0,"
            "status TEXT NOT NULL DEFAULT 'detenu',"
            "verdict TEXT NOT NULL DEFAULT '',"
            "created_at INTEGER NOT NULL,"
            "closed_at INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_justice_files_status ON justice_files(status, created_at)",
            "CREATE INDEX IF NOT EXISTS idx_justice_files_suspect ON justice_files(suspect_id, status)",
        ),
    ),
    (
        17,
        (
            # ─── Chats d'équipe (faction / entreprise / gouvernement) relayés par le bot ───
            "CREATE TABLE IF NOT EXISTS team_chat_state ("
            "user_id INTEGER PRIMARY KEY,"
            "channel TEXT NOT NULL,"
            "since INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE TABLE IF NOT EXISTS team_chat_mute ("
            "user_id INTEGER NOT NULL,"
            "channel TEXT NOT NULL,"
            "PRIMARY KEY(user_id, channel)"
            ")",
        ),
    ),
    (
        18,
        (
            # ─── Études : cours révisés (bibliothèque) et examen par questions ───
            "CREATE TABLE IF NOT EXISTS study_lessons ("
            "user_id INTEGER NOT NULL,"
            "diplome TEXT NOT NULL,"
            "lesson_id TEXT NOT NULL,"
            "seen_at INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY(user_id, diplome, lesson_id)"
            ")",
            "CREATE TABLE IF NOT EXISTS study_exam ("
            "user_id INTEGER PRIMARY KEY,"
            "diplome TEXT NOT NULL,"
            "questions TEXT NOT NULL,"
            "pos INTEGER NOT NULL DEFAULT 0,"
            "score INTEGER NOT NULL DEFAULT 0,"
            "started_at INTEGER NOT NULL DEFAULT 0"
            ")",
        ),
    ),
    (
        19,
        (
            # ─── Chaîne de production : métiers → biens → entreprises → produits finis ───
            # Progression d'un joueur dans CHAQUE métier (rang, missions)
            "CREATE TABLE IF NOT EXISTS job_progress ("
            "user_id INTEGER NOT NULL,"
            "job TEXT NOT NULL,"
            "rank INTEGER NOT NULL DEFAULT 1,"
            "missions INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY(user_id, job)"
            ")",
            # Statistiques de fournisseur / commerce (classements)
            "CREATE TABLE IF NOT EXISTS user_chain_stats ("
            "user_id INTEGER PRIMARY KEY,"
            "goods_made INTEGER NOT NULL DEFAULT 0,"
            "goods_supplied INTEGER NOT NULL DEFAULT 0,"
            "supply_value INTEGER NOT NULL DEFAULT 0,"
            "big_orders INTEGER NOT NULL DEFAULT 0"
            ")",
            # État « grandeur » d'une entreprise : XP, totaux, politique de vente (part du marché national)
            "CREATE TABLE IF NOT EXISTS company_chain ("
            "company_id INTEGER PRIMARY KEY,"
            "xp INTEGER NOT NULL DEFAULT 0,"
            "produced_total INTEGER NOT NULL DEFAULT 0,"
            "revenue_total INTEGER NOT NULL DEFAULT 0,"
            "npc_share REAL NOT NULL DEFAULT 1.0"
            ")",
            # Activité par équipe (département) et par jour de jeu
            "CREATE TABLE IF NOT EXISTS company_dept_activity ("
            "company_id INTEGER NOT NULL,"
            "dept TEXT NOT NULL DEFAULT '',"
            "day INTEGER NOT NULL,"
            "points INTEGER NOT NULL DEFAULT 0,"
            "consumed INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY(company_id, dept, day)"
            ")",
            # Lignes de production activées (recettes)
            "CREATE TABLE IF NOT EXISTS company_lines ("
            "company_id INTEGER NOT NULL,"
            "recipe TEXT NOT NULL,"
            "position INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY(company_id, recipe)"
            ")",
            # Prix d'achat des intrants (multiplicateur) et prix de gros des produits finis
            "CREATE TABLE IF NOT EXISTS company_bids ("
            "company_id INTEGER NOT NULL,"
            "good TEXT NOT NULL,"
            "mult REAL NOT NULL DEFAULT 1.0,"
            "PRIMARY KEY(company_id, good)"
            ")",
            "CREATE TABLE IF NOT EXISTS company_prices ("
            "company_id INTEGER NOT NULL,"
            "recipe TEXT NOT NULL,"
            "price INTEGER NOT NULL,"
            "PRIMARY KEY(company_id, recipe)"
            ")",
            # Compteurs journaliers génériques (plafonds : fournisseur national, comptoir, ventes nationales)
            "CREATE TABLE IF NOT EXISTS chain_daily ("
            "scope TEXT NOT NULL,"
            "owner INTEGER NOT NULL,"
            "good TEXT NOT NULL,"
            "day INTEGER NOT NULL,"
            "qty INTEGER NOT NULL DEFAULT 0,"
            "PRIMARY KEY(scope, owner, good, day)"
            ")",
            "ALTER TABLE company_members ADD COLUMN dept TEXT NOT NULL DEFAULT ''",
            # Le secteur Éducation disparaît : ses entreprises passent en Commerce
            "UPDATE companies SET sector='Commerce' WHERE sector='Éducation'",
            # Ancien stock (par nom de produit) → clés de produits finis
            "UPDATE OR REPLACE company_stock SET product='formation_log' WHERE product='Licence logicielle'",
            "UPDATE OR REPLACE company_stock SET product='assurance_veh' WHERE product='Produit financier'",
            "UPDATE OR REPLACE company_stock SET product='panier' WHERE product IN ('Denrées et marchandises','Formation dispensée')",
            "UPDATE OR REPLACE company_stock SET product='pieces_auto' WHERE product='Biens manufacturés'",
            "UPDATE OR REPLACE company_stock SET product='pub' WHERE product='Contenu publicitaire'",
            "UPDATE OR REPLACE company_stock SET product='gestion' WHERE product='Dossier immobilier'",
            "UPDATE OR REPLACE company_stock SET product='carburant' WHERE product='Énergie livrée'",
            "UPDATE OR REPLACE company_stock SET product='repas' WHERE product='Repas préparés'",
            "UPDATE OR REPLACE company_stock SET product='seance' WHERE product='Prestation sportive'",
            "UPDATE OR REPLACE company_stock SET product='spectacle' WHERE product='Œuvre ou spectacle'",
            "UPDATE OR REPLACE company_stock SET product='article_luxe' WHERE product='Article de luxe'",
        ),
    ),
    (
        20,
        (
            # ⚙️ Règles du jeu pilotées par le staff (sources d'argent du bot, paiements réels, événements)
            "CREATE TABLE IF NOT EXISTS game_rules (key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '',"
            "updated_by INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS game_rules_log (id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT NOT NULL,"
            "old_value TEXT NOT NULL DEFAULT '', new_value TEXT NOT NULL DEFAULT '', actor_id INTEGER NOT NULL DEFAULT 0,"
            "created_at INTEGER NOT NULL DEFAULT 0)",
            # 🌐 Réseau RP entre joueurs : publications, likes, commentaires, abonnements, messages privés
            "CREATE TABLE IF NOT EXISTS rp_posts (id INTEGER PRIMARY KEY AUTOINCREMENT, author_id INTEGER NOT NULL,"
            "platform TEXT NOT NULL DEFAULT '', text TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL DEFAULT 0,"
            "likes INTEGER NOT NULL DEFAULT 0, comments INTEGER NOT NULL DEFAULT 0, deleted INTEGER NOT NULL DEFAULT 0)",
            "CREATE INDEX IF NOT EXISTS idx_rp_posts_author ON rp_posts(author_id, deleted, created_at)",
            "CREATE INDEX IF NOT EXISTS idx_rp_posts_time ON rp_posts(deleted, created_at)",
            "CREATE TABLE IF NOT EXISTS rp_likes (post_id INTEGER NOT NULL, user_id INTEGER NOT NULL,"
            "created_at INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(post_id, user_id))",
            "CREATE TABLE IF NOT EXISTS rp_comments (id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER NOT NULL,"
            "user_id INTEGER NOT NULL, text TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL DEFAULT 0,"
            "deleted INTEGER NOT NULL DEFAULT 0)",
            "CREATE INDEX IF NOT EXISTS idx_rp_comments_post ON rp_comments(post_id, deleted, created_at)",
            "CREATE TABLE IF NOT EXISTS rp_follows (follower_id INTEGER NOT NULL, followee_id INTEGER NOT NULL,"
            "since INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(follower_id, followee_id))",
            "CREATE INDEX IF NOT EXISTS idx_rp_follows_followee ON rp_follows(followee_id)",
            "CREATE TABLE IF NOT EXISTS rp_dms (id INTEGER PRIMARY KEY AUTOINCREMENT, from_id INTEGER NOT NULL,"
            "to_id INTEGER NOT NULL, text TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL DEFAULT 0,"
            "is_read INTEGER NOT NULL DEFAULT 0)",
            "CREATE INDEX IF NOT EXISTS idx_rp_dms_to ON rp_dms(to_id, is_read, created_at)",
            "CREATE INDEX IF NOT EXISTS idx_rp_dms_pair ON rp_dms(from_id, to_id, created_at)",
            "CREATE TABLE IF NOT EXISTS rp_mutes (user_id INTEGER PRIMARY KEY, until INTEGER NOT NULL DEFAULT 0,"
            "reason TEXT NOT NULL DEFAULT '', by_id INTEGER NOT NULL DEFAULT 0)",
        ),
    ),
    (
        21,
        (
            # 🏛️ Trésor public (faction Administration) : d'où vient l'argent, où il est redistribué
            "CREATE TABLE IF NOT EXISTS treasury_flow (day INTEGER NOT NULL, source TEXT NOT NULL,"
            "kind TEXT NOT NULL, amount INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(day, source, kind))",
            "CREATE TABLE IF NOT EXISTS treasury_grants (id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id INTEGER NOT NULL,"
            "target TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '',"
            "created_at INTEGER NOT NULL DEFAULT 0)",
            "CREATE INDEX IF NOT EXISTS idx_treasury_grants_time ON treasury_grants(created_at)",
        ),
    ),
    (
        22,
        (
            # ⏱️ Service : l'activité est créditée en continu (toutes les 10 min de jeu), plus seulement à la fin
            "ALTER TABLE work_duty ADD COLUMN credited_pts INTEGER NOT NULL DEFAULT 0",
        ),
    ),
    (
        23,
        (
            # #️⃣ Hashtags du Réseau RP + 🗳️ sondages rattachés aux communautés
            "CREATE TABLE IF NOT EXISTS rp_hashtags (post_id INTEGER NOT NULL, tag TEXT NOT NULL,"
            "created_at INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(post_id, tag))",
            "CREATE INDEX IF NOT EXISTS idx_rp_hashtags_tag ON rp_hashtags(tag, created_at)",
            "ALTER TABLE social_polls ADD COLUMN community_id INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE social_polls ADD COLUMN closes_at INTEGER NOT NULL DEFAULT 0",
        ),
    ),
    (
        24,
        (
            # 🪪 Personnage : identité RP et apparence (pure personnalité, aucun effet sur l'équilibre du jeu)
            "CREATE TABLE IF NOT EXISTS characters (user_id INTEGER PRIMARY KEY, first_name TEXT NOT NULL DEFAULT '',"
            "last_name TEXT NOT NULL DEFAULT '', gender TEXT NOT NULL DEFAULT '', origin TEXT NOT NULL DEFAULT '',"
            "build TEXT NOT NULL DEFAULT '', skin TEXT NOT NULL DEFAULT '', hair TEXT NOT NULL DEFAULT '',"
            "outfit TEXT NOT NULL DEFAULT '', trait1 TEXT NOT NULL DEFAULT '', trait2 TEXT NOT NULL DEFAULT '',"
            "story TEXT NOT NULL DEFAULT '', complete INTEGER NOT NULL DEFAULT 0,"
            "created_at INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL DEFAULT 0)",
        ),
    ),
    (
        25,
        (
            # 🏛️ Politique unifiée : le gouvernement = l'Administration. Réglages de l'État (coefficient d'impôt…)
            "CREATE TABLE IF NOT EXISTS state_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL,"
            "updated_at INTEGER NOT NULL DEFAULT 0)",
            # Nouveau grade « Ministre » (index 5) inséré avant « Président » : l'ancien président passe de 5 à 6.
            "UPDATE faction_members SET rank=6 WHERE faction='mairie' AND rank=5",
            # Postes sans fonction supprimés (Conseiller municipal, Maire, Député, Sénateur, ancien « Ministre »)
            "UPDATE users SET political_post='' WHERE political_post IN "
            "('Conseiller municipal','Maire','Député','Sénateur','Ministre')",
            "DELETE FROM political_offices WHERE poste<>'Président'",
            # Ministères sans faction supprimés (Éducation, Affaires étrangères)
            "DELETE FROM cabinet_positions WHERE position NOT IN ('Intérieur','Défense','Justice','Santé','Économie')",
            # Le Président n'est pas ministre
            "DELETE FROM cabinet_positions WHERE occupant_id IN "
            "(SELECT occupant_id FROM political_offices WHERE poste='Président' AND occupant_id IS NOT NULL)",
            # Les ministres déjà nommés entrent dans l'Administration au grade « Ministre »
            "INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) "
            "SELECT occupant_id, 'mairie', 5, 0, CAST(strftime('%s','now') AS INTEGER) FROM cabinet_positions "
            "WHERE occupant_id IS NOT NULL AND occupant_id NOT IN "
            "(SELECT occupant_id FROM political_offices WHERE poste='Président' AND occupant_id IS NOT NULL) "
            "ON CONFLICT(user_id) DO UPDATE SET faction='mairie', rank=5",
        ),
    ),
    (
        26,
        (
            # 📢 Un référendum peut porter un effet appliqué s'il est accepté (ex. « constitution:<nouveau texte> »)
            "ALTER TABLE referendums ADD COLUMN payload TEXT NOT NULL DEFAULT ''",
            # ⚖️ Motions de destitution restées « en attente » avant ce correctif : elles expirent (elles bloquaient la cible)
            "UPDATE motions SET status='expired' WHERE status='pending'",
        ),
    ),
    (
        27,
        (
            # 🛍️ Boutique v2 : catalogue géré par le staff, commandes fiables, fidélité, exclusivités
            "CREATE TABLE IF NOT EXISTS shop_catalog (item_key TEXT PRIMARY KEY, kind TEXT NOT NULL DEFAULT 'shop',"
            "category TEXT NOT NULL DEFAULT 'upgrade', stars INTEGER NOT NULL DEFAULT 0, promo_pct INTEGER NOT NULL DEFAULT 0,"
            "active INTEGER NOT NULL DEFAULT 1, featured INTEGER NOT NULL DEFAULT 0, stock INTEGER NOT NULL DEFAULT -1,"
            "sold INTEGER NOT NULL DEFAULT 0, starts_at INTEGER NOT NULL DEFAULT 0, ends_at INTEGER NOT NULL DEFAULT 0,"
            "sort INTEGER NOT NULL DEFAULT 0, money_item INTEGER NOT NULL DEFAULT 0, label TEXT NOT NULL DEFAULT '',"
            "description TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS shop_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, charge_id TEXT NOT NULL UNIQUE,"
            "user_id INTEGER NOT NULL, target_id INTEGER NOT NULL, item_key TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'shop',"
            "stars_paid INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'paid', error TEXT NOT NULL DEFAULT '',"
            "attempts INTEGER NOT NULL DEFAULT 0, test INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL DEFAULT 0,"
            "delivered_at INTEGER NOT NULL DEFAULT 0)",
            "CREATE INDEX IF NOT EXISTS idx_shop_orders_user ON shop_orders(user_id, status, created_at)",
            "CREATE INDEX IF NOT EXISTS idx_shop_orders_status ON shop_orders(status, created_at)",
            "CREATE TABLE IF NOT EXISTS shop_rewards (user_id INTEGER NOT NULL, tier INTEGER NOT NULL,"
            "claimed_at INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id, tier))",
            "CREATE TABLE IF NOT EXISTS shop_cosmetics (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,"
            "code TEXT NOT NULL, label TEXT NOT NULL DEFAULT '', granted_at INTEGER NOT NULL DEFAULT 0,"
            "UNIQUE(user_id, code))",
        ),
    ),
    (
        28,
        (
            "DROP TABLE IF EXISTS competition_participants",
            "DROP TABLE IF EXISTS competition_scores",
            "DROP TABLE IF EXISTS competitions",
        ),
    ),
    (
        29,
        (
            # 🛡️ Staff : historique en temps réel, créneaux des admins, présence et formulaires de passation
            "ALTER TABLE admin_logs ADD COLUMN real_ts INTEGER NOT NULL DEFAULT 0",
            "CREATE INDEX IF NOT EXISTS idx_admin_logs_actor ON admin_logs(admin_id, real_ts)",
            "CREATE INDEX IF NOT EXISTS idx_admin_logs_target ON admin_logs(target_id, real_ts)",
            "CREATE TABLE IF NOT EXISTS staff_slots (user_id INTEGER PRIMARY KEY, slot TEXT NOT NULL,"
            "set_by INTEGER NOT NULL DEFAULT 0, set_at INTEGER NOT NULL DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS staff_shifts (shift_id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "user_id INTEGER NOT NULL, slot TEXT NOT NULL, day TEXT NOT NULL, starts_at INTEGER NOT NULL,"
            "ends_at INTEGER NOT NULL, confirmed_at INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'pending',"
            "start_notified INTEGER NOT NULL DEFAULT 0, end_notified INTEGER NOT NULL DEFAULT 0,"
            "report_json TEXT NOT NULL DEFAULT '', report_at INTEGER NOT NULL DEFAULT 0, UNIQUE(user_id, day, slot))",
            "CREATE INDEX IF NOT EXISTS idx_staff_shifts_user ON staff_shifts(user_id, ends_at)",
        ),
    ),
    (
        30,
        (
            # 🌐 Fusion des réseaux : les stories rejoignent rp_posts (kind='story', expirent à expires_at)
            "ALTER TABLE rp_posts ADD COLUMN kind TEXT NOT NULL DEFAULT 'post'",
            "ALTER TABLE rp_posts ADD COLUMN expires_at INTEGER NOT NULL DEFAULT 0",
            "CREATE TABLE IF NOT EXISTS social_stories (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,"
            "platform TEXT, content TEXT, created_at INTEGER, expires_at INTEGER)",
            "INSERT INTO rp_posts (author_id, platform, text, created_at, kind, expires_at) "
            "SELECT user_id, COALESCE(platform,''), COALESCE(NULLIF(content,''),'story'), COALESCE(created_at,0), 'story', "
            "COALESCE(expires_at,0) FROM social_stories WHERE COALESCE(expires_at,0) > 0",
            "DROP TABLE social_stories",
            "CREATE INDEX IF NOT EXISTS idx_rp_posts_kind ON rp_posts(kind, expires_at)",
        ),
    ),
    (
        31,
        (
            # 📣 Lead Influenceurs : campagnes soumises au Lead Staff Global avant diffusion (charte, article 14)
            "CREATE TABLE IF NOT EXISTS staff_campaigns (campaign_id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "author_id INTEGER NOT NULL, title TEXT NOT NULL, message TEXT NOT NULL,"
            "status TEXT NOT NULL DEFAULT 'pending', reviewed_by INTEGER NOT NULL DEFAULT 0,"
            "reason TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL DEFAULT 0,"
            "reviewed_at INTEGER NOT NULL DEFAULT 0, sent_at INTEGER NOT NULL DEFAULT 0)",
            "CREATE INDEX IF NOT EXISTS idx_staff_campaigns_status ON staff_campaigns(status, created_at)",
        ),
    ),
    (
        32,
        (
            # 🔗 Fusion réseaux : index rp_follows(followee_id) pour get_total_followers
            "CREATE INDEX IF NOT EXISTS idx_rp_follows_followee_v2 "
            "ON rp_follows(followee_id)",
        ),
    ),
    (
        33,
        (
            "CREATE TABLE IF NOT EXISTS casino_game_sessions ("
            "game_id TEXT PRIMARY KEY,"
            "user_id INTEGER NOT NULL,"
            "game_type TEXT NOT NULL CHECK(game_type IN ('blackjack','mines','crash')),"
            "status TEXT NOT NULL CHECK(status IN ('active','processing','win','loss','push','blackjack','bust','crashed','cashed_out')),"
            "state_json TEXT NOT NULL,"
            "revision INTEGER NOT NULL DEFAULT 0 CHECK(revision>=0),"
            "created_at INTEGER NOT NULL,"
            "updated_at INTEGER NOT NULL,"
            "settled_at INTEGER NOT NULL DEFAULT 0"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_casino_sessions_owner_active "
            "ON casino_game_sessions(user_id,game_type,status,updated_at)",
        ),
    ),
    (
        34,
        (
            # 🧭 Persistance des phases de voyage (trajet / repos) : `travel_log` porte
            # désormais directement l'heure d'arrivée et la fin de repos de CE voyage, pour
            # que l'API ne les devine plus depuis une plage de durée plausible.
            "ALTER TABLE travel_log ADD COLUMN arrival_at INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE travel_log ADD COLUMN travel_until INTEGER NOT NULL DEFAULT 0",
            "CREATE INDEX IF NOT EXISTS idx_travel_log_owner_until "
            "ON travel_log(user_id, travel_until)",
        ),
    ),
    (
        35,
        (
            # 🎓 Historique des examens : une ligne par examen corrigé (réussite ou échec).
            "CREATE TABLE IF NOT EXISTS exam_history ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "user_id INTEGER NOT NULL,"
            "diploma TEXT NOT NULL,"
            "score INTEGER NOT NULL,"
            "total INTEGER NOT NULL,"
            "needed INTEGER NOT NULL,"
            "success INTEGER NOT NULL CHECK(success IN (0,1)),"
            "taken_at INTEGER NOT NULL"
            ")",
            "CREATE INDEX IF NOT EXISTS idx_exam_history_user ON exam_history(user_id, taken_at)",
        ),
    ),
]


async def get_database_version(db: aiosqlite.Connection) -> int:
    async with db.execute("PRAGMA user_version") as cursor:
        row = await cursor.fetchone()
    return int(row[0] if row else 0)


async def _table_exists(db, table: str) -> bool:
    async with db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)) as cur:
        return await cur.fetchone() is not None


async def _repair_schema(db) -> None:
    """Filet de sécurité : rejoue ce qui est idempotent (CREATE ... IF NOT EXISTS, INSERT OR IGNORE,
    colonnes manquantes) pour TOUTES les migrations. Répare une base dont `user_version` est en avance
    sur son schéma réel (ex. « no such table: user_position »)."""
    import re
    fixed = 0
    for version, statements in MIGRATIONS:
        for stmt in statements:
            head = stmt.lstrip()
            up = head.upper()
            try:
                if re.match(r"CREATE (UNIQUE )?(TABLE|INDEX) IF NOT EXISTS", head, re.I):
                    if " INDEX " in up[:30]:                      # un index exige que sa table existe
                        m = re.search(r"\bON\s+(\w+)", head, re.I)
                        if m and not await _table_exists(db, m.group(1)):
                            continue
                    await db.execute(stmt)
                    fixed += 1
                elif up.startswith("INSERT OR IGNORE"):
                    t = re.search(r"INTO\s+(\w+)", head, re.I)
                    if t and await _table_exists(db, t.group(1)):
                        await db.execute(stmt)
                        fixed += 1
                else:
                    m = re.match(r"ALTER TABLE (\w+) ADD COLUMN (\w+)", head, re.I)
                    if m and await _table_exists(db, m.group(1)):
                        async with db.execute(f"PRAGMA table_info({m.group(1)})") as cur:
                            cols = {r[1] for r in await cur.fetchall()}
                        if m.group(2) not in cols:
                            await db.execute(stmt)
                            fixed += 1
            except Exception:
                logger.exception("Réparation du schéma : instruction ignorée (migration %s)", version)
    await db.commit()
    if fixed:
        logger.info("Schéma vérifié (%s instruction(s) idempotente(s) rejouée(s)).", fixed)


async def run_migrations() -> int:
    async with aiosqlite.connect(DB_PATH, timeout=DB_TIMEOUT) as db:
        await _configure_connection(db)
        current = await get_database_version(db)

        for version, statements in MIGRATIONS:
            if version <= current:
                continue

            logger.info("Migration DB %s en cours", version)
            try:
                await db.execute("BEGIN IMMEDIATE")
                for statement in statements:
                    await db.execute(statement)
                await db.execute(f"PRAGMA user_version={int(version)}")
                await db.commit()
                current = version
                logger.info("Migration DB %s appliquée", version)
            except Exception:
                await db.rollback()
                logger.exception("Migration DB %s annulée", version)
                raise

        await _repair_schema(db)
        return current
