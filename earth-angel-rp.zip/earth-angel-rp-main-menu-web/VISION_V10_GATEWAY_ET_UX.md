# Earth Angel RP — Vision v10 : le bot devient une porte d'entrée, la Mini App/Web devient le jeu

Ce document fixe le nouvel objectif du projet, au-dessus de la parité bot/Mini App/Web déjà en cours
(voir `PARITE_BOT_MINIAPP_WEB.md`, `TODO.md`, `PARITE_AUDIT_REPRISE.md`). Il ne remplace pas ces documents :
il leur ajoute une direction à atteindre une fois la parité terminée.

## 1. Pourquoi ce changement

Un bot Telegram classique est une interface textuelle : des commandes et des boutons dans une
conversation. Une Mini App est une véritable application web, ouverte à l'intérieur de Telegram, sans
rien à installer. C'est elle qui doit porter le jeu : l'interface, l'expérience, la profondeur visuelle.
Le bot, lui, redevient ce qu'il fait de mieux : une porte d'entrée et un canal de notifications.

Concrètement :

- **Le bot** gère `/start`, les notifications (argent reçu, prison, hôpital, messages d'un autre joueur…),
  les commandes staff qui agissent sur Telegram lui-même, et les paiements Stars. Il fournit le bouton qui
  ouvre la Mini App.
- **La Mini App et l'application Web** portent tout le gameplay : chaque module de jeu, son interface,
  ses écrans, son détail.

## 2. Ce que ça change pour la parité déjà en cours

Ce basculement ne dispense de rien : tant qu'un module n'est pas à égalité entre bot, Mini App et
application Web (voir la liste dans `TODO.md`), sa version bot reste la seule façon d'y jouer pour
certains joueurs. On ne ferme jamais un module côté bot avant que sa Mini App soit terminée, jouée et
validée. Fermer avant romprait le jeu pour les joueurs qui comptaient dessus.

## 3. Plan de bascule du bot vers une simple porte d'entrée

### Étape 1 — Ajouter le bouton de lancement
Le bot n'a aujourd'hui aucun bouton `WebAppInfo` : rien n'ouvre la Mini App depuis une conversation.
À ajouter :
- `/start` répond avec un bouton **🎮 Jouer** qui ouvre la Mini App (`WebAppInfo`).
- Le bouton de menu natif de Telegram (à côté de la zone de texte, `MenuButtonWebApp`) est configuré pour
  ouvrir la Mini App en permanence.

### Étape 2 — Couper le gameplay du chat, module par module
Ne jamais couper d'un coup : le bot compte aujourd'hui 146 commandes et 77 callbacks de jeu enregistrés
dans `bot.py`. Pour chaque module déjà mis à égalité (travail, banque, marché, jardin, éducation…), sa
commande/ses boutons Telegram sont remplacés par un message court du type « Ouvre la Mini App pour jouer »
avec le bouton de lancement, plutôt que de continuer à dérouler l'écran de jeu dans le chat.

### Étape 3 — Garder ce qui doit rester côté bot
Restent dans `bot.py`, quoi qu'il arrive :
- `/start` et les notifications poussées ;
- les commandes staff qui agissent sur Telegram (bannir, poster dans un groupe) ;
- les paiements Telegram Stars (ils ne peuvent exister que côté Telegram).

### Étape 4 — Ordre de bascule
Un module ne passe en « redirection vers la Mini App » qu'une fois :
1. sa parité confirmée (service `gameplay/<module>.py` partagé, routeur API, écran partagé) ;
2. testé en conditions réelles sur Mini App et sur Web ;
3. validé par l'utilisateur.

État au moment de l'écriture de ce document : voir la section « Déjà aligné dans cette version » de
`TODO.md` pour les modules prêts à basculer en premier, et la section « À fermer avant d'ajouter de
nouveaux systèmes » pour ceux qui doivent d'abord être terminés.

## 4. Ambition UX/UI : un jeu à part entière, pas une page unique

Au-delà de la parité des règles, l'objectif devient la qualité de l'expérience elle-même. La Mini App et
l'application Web doivent être un jeu comparable aux meilleurs du genre — et viser à les surclasser — pas
une liste de boutons dans une seule page.

Principes retenus :

- **Jamais tout sur un seul écran.** La navigation progressive déjà posée en v9
  (espace → hub → écran de module → détail/confirmation, voir `UX_NAVIGATION_V9.md`) est la bonne
  direction ; elle doit maintenant être approfondie, pas revue. Chaque module gagne son propre parcours
  à plusieurs écrans au lieu d'un unique panneau qui empile toutes ses informations.
- **Plus large et plus détaillé visuellement.** Les écrans de jeu (fiches de personnage, de métier,
  d'entreprise, de bien immobilier, de combat, de diplôme…) doivent présenter une mise en page riche :
  sections bien séparées, hiérarchie visuelle claire, illustrations ou représentations graphiques du
  contenu (pas seulement du texte et des boutons empilés), au niveau de ce qui se fait dans les jeux de
  simulation de vie et RP les plus soignés du marché.
  C'est un choix produit : Claude continue de proposer des écrans compacts et fonctionnels par défaut
  pour n'importe quel autre projet, mais sur Earth Angel RP, cette direction prime sur la sobriété par
  défaut.
- **Chaque module a ses propres écrans dédiés**, pas un écran générique réutilisé partout : l'écran
  Combat ne doit pas ressembler à l'écran Banque simplement parce qu'ils partagent les mêmes composants
  de base (`ea-card`, `ea-list`, etc.) ; les composants communs servent de fondation, pas de limite.
- **Référence de qualité : les meilleurs jeux du genre (vie simulée, RP économique, multijoueur
  persistant)**, pour le niveau de détail, la clarté de la progression, et le soin visuel — l'ambition est
  de les égaler puis de les dépasser, pas de s'en approcher.

## 5. Ce que ce document ne décide pas encore

- La liste précise des écrans par module (à faire module par module, en même temps que sa mise à égalité).
- Un design system illustré complet (palette, typographies, composants riches) : à produire comme travail
  dédié, pas à improviser module par module.
- Le calendrier de bascule du bot : dépend de l'avancement réel de la parité (section 3, étape 4).
