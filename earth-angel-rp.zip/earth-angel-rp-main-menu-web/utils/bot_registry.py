# utils/bot_registry.py
"""
═══════════════════════════════════════════════════════════════════════════
   Singleton global pour accéder au bot depuis n'importe où
═══════════════════════════════════════════════════════════════════════════
Permet à n'importe quel module d'envoyer des messages via le bot sans
provoquer d'import circulaire.

Utilisation :
    from utils.bot_registry import get_bot, set_bot

    # Au démarrage (bot.py → on_application_start)
    set_bot(application.bot)

    # Ailleurs (payments.py, etc.)
    bot = get_bot()
    if bot:
        await bot.send_message(...)
"""

_bot = None


def set_bot(bot):
    """Enregistre l'instance du bot (appelé au démarrage)."""
    global _bot
    _bot = bot


def get_bot():
    """Retourne l'instance du bot, ou None si pas encore démarré."""
    return _bot