# utils/ratelimit.py
from utils.swallow import swallowed
import asyncio
import time
from collections import defaultdict, deque

from telegram import Update
from telegram.ext import ContextTypes


RATE_LIMIT = 30
RATE_WINDOW = 60
CALLBACK_LIMIT = 45

_histories: dict[int, deque[float]] = defaultdict(deque)
_locks: dict[int, asyncio.Lock] = {}


def _lock_for(user_id: int) -> asyncio.Lock:
    lock = _locks.get(user_id)
    if lock is None:
        lock = asyncio.Lock()
        _locks[user_id] = lock
    return lock


async def check_rate_limit(
    user_id: int,
    limit: int,
    window: int = RATE_WINDOW,
) -> tuple[bool, int]:
    current = time.monotonic()
    async with _lock_for(user_id):
        history = _histories[user_id]
        cutoff = current - window
        while history and history[0] <= cutoff:
            history.popleft()

        if len(history) >= limit:
            wait = max(1, int(window - (current - history[0])) + 1)
            return False, wait

        history.append(current)
        return True, 0


async def rate_limit_middleware(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> bool:
    user = update.effective_user
    if not user:
        return True

    limit = CALLBACK_LIMIT if update.callback_query else RATE_LIMIT
    allowed, wait = await check_rate_limit(user.id, limit)
    if allowed:
        return True

    if update.callback_query:
        try:
            await update.callback_query.answer(
                f"Trop rapide. Réessaie dans {wait}s.",
                show_alert=True,
            )
        except Exception:
            swallowed('utils/ratelimit.py')
    elif update.effective_message:
        await update.effective_message.reply_text(
            f"⏳ Trop de commandes. Attends {wait} secondes."
        )
    return False


async def cleanup_rate_limits() -> None:
    """Évite que les dictionnaires grandissent sans limite."""
    current = time.monotonic()
    stale = []
    for user_id, history in list(_histories.items()):
        while history and history[0] <= current - RATE_WINDOW:
            history.popleft()
        if not history:
            stale.append(user_id)

    for user_id in stale:
        _histories.pop(user_id, None)
        _locks.pop(user_id, None)