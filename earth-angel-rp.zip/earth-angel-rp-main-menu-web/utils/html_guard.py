# utils/html_guard.py — Filet de sécurité : plus jamais de « <b>…</b> » affichés en clair,
# ni de « **gras** » ou de message perdu à cause d'un balisage refusé par Telegram.
"""
Problèmes corrigés
──────────────────
1. Quand un message contient des balises (<b>, <i>, <code>…) mais est envoyé SANS
   `parse_mode="HTML"`, Telegram affiche les balises telles quelles : « <b>Santé</b> ».

2. Une partie du jeu écrivait en Markdown v1 (`parse_mode="Markdown"`). Ce mode ne connaît
   ni `**gras**` ni les pseudos contenant `_` ou `*` : les étoiles restaient visibles, ou
   Telegram refusait le message (« Can't parse entities ») et le joueur ne recevait rien.

3. Certains messages étaient donc perdus sans trace (résultats d'arène, bilan de sommeil…).

Solution
────────
`install_html_guard()` enveloppe les méthodes d'envoi/édition du Bot :

  • parse_mode="Markdown" → le texte est converti en HTML (échappement sûr, `**x**` et `*x*`
    deviennent du gras, `_x_` de l'italique, `` `x` `` du code). Les pseudos sont échappés.
  • sans parse_mode (ou "HTML") → si le texte contient des balises HTML valides et bien fermées,
    parse_mode="HTML" est ajouté et les `<`, `>`, `&` isolés sont échappés ; si les balises sont
    cassées, elles sont retirées et le texte part en clair.
  • si Telegram refuse malgré tout les balises (« can't parse entities »), le message est renvoyé
    en texte brut plutôt que perdu.

Les messages qui précisent un autre parse_mode (None volontaire, MarkdownV2…) ne sont jamais modifiés.
"""
from __future__ import annotations

import html
import logging
import re

logger = logging.getLogger(__name__)

# Balises supportées par Telegram en mode HTML.
_TAG_RE = re.compile(
    r"</?(?:b|strong|i|em|u|ins|s|strike|del|code|pre|tg-spoiler|blockquote)>"
    r"|<a\s+href=(?:\"[^\"<>]*\"|'[^'<>]*')>|</a>",
    re.I,
)
_NAME_RE = re.compile(r"</?\s*([a-zA-Z-]+)")
_BARE_AMP_RE = re.compile(r"&(?!(?:amp|lt|gt|quot|#\d+|#x[0-9a-fA-F]+);)")
_ANY_TAG_RE = re.compile(r"</?[a-zA-Z][^>]*>")

# Markdown v1 (ancien mode Telegram, encore utilisé par certains messages).
_MD_MODES = ("markdown", "md")
_MD_CODE_RE = re.compile(r"`([^`\n]+)`")
_MD_BOLD2_RE = re.compile(r"\*\*([^\n]+?)\*\*")
_MD_BOLD_RE = re.compile(r"(?<![\w*])\*([^\n*]+?)\*(?![\w*])")
_MD_ITALIC_RE = re.compile(r"(?<!\w)_([^\n_]+?)_(?!\w)")
_PLACEHOLDER_RE = re.compile("\x00(\\d+)\x00")


def _escape_text(segment: str) -> str:
    """Échappe un morceau de texte hors balises, sans toucher aux entités déjà valides."""
    segment = _BARE_AMP_RE.sub("&amp;", segment)
    return segment.replace("<", "&lt;").replace(">", "&gt;")


def _balanced(text: str) -> bool:
    """Vrai si toutes les balises ouvertes sont refermées dans le bon ordre."""
    stack: list[str] = []
    for m in _TAG_RE.finditer(text):
        tag = m.group(0)
        name = _NAME_RE.match(tag).group(1).lower()
        if tag.startswith("</"):
            if not stack or stack.pop() != name:
                return False
        else:
            stack.append(name)
    return not stack


def prepare_text(text):
    """Retourne (texte_à_envoyer, parse_mode_ou_None).

    parse_mode vaut "HTML" seulement si le texte contenait de vraies balises valides.
    """
    if not isinstance(text, str) or "<" not in text or not _TAG_RE.search(text):
        return text, None

    if not _balanced(text):
        # Balises cassées : mieux vaut du texte propre qu'une erreur ou des <b> visibles.
        return _TAG_RE.sub("", text), None

    out: list[str] = []
    last = 0
    for m in _TAG_RE.finditer(text):
        out.append(_escape_text(text[last:m.start()]))
        out.append(m.group(0))
        last = m.end()
    out.append(_escape_text(text[last:]))
    return "".join(out), "HTML"


def md1_to_html(text: str) -> str:
    """Convertit du Markdown v1 Telegram en HTML sûr (le texte est échappé, les pseudos aussi)."""
    t = html.escape(text, quote=False)
    spans: list[str] = []

    def keep_code(m):
        spans.append(f"<code>{m.group(1)}</code>")
        return f"\x00{len(spans) - 1}\x00"

    t = _MD_CODE_RE.sub(keep_code, t)          # le code n'est pas re-interprété
    t = _MD_BOLD2_RE.sub(r"<b>\1</b>", t)      # **gras**
    t = _MD_BOLD_RE.sub(r"<b>\1</b>", t)       # *gras* (syntaxe v1)
    t = _MD_ITALIC_RE.sub(r"<i>\1</i>", t)     # _italique_
    return _PLACEHOLDER_RE.sub(lambda m: spans[int(m.group(1))], t)


def to_plain(html_text: str) -> str:
    """Texte lisible sans aucune balise (repli si Telegram refuse le balisage)."""
    return html.unescape(_ANY_TAG_RE.sub("", html_text))


def _is_unset(value) -> bool:
    """Vrai si parse_mode n'a pas été choisi par l'appelant (absent ou DEFAULT_NONE de PTB).

    Un `None` explicite ou une chaîne (« HTML », « Markdown ») = choix volontaire.
    """
    return type(value).__name__ == "DefaultValue"


def _is_entity_error(exc: Exception) -> bool:
    s = str(exc).lower()
    return "parse entities" in s or "find end of the entity" in s or "can't find end" in s


def _wrap(orig, text_kw: str, text_pos: int | None):
    """Enveloppe une méthode du Bot. `text_kw` : nom du paramètre texte/légende ;
    `text_pos` : sa position si l'appelant le passe sans nom (None = jamais positionnel)."""

    async def wrapper(self, *args, **kwargs):
        args = list(args)
        in_kwargs = text_kw in kwargs
        fallback = None          # version sans balises, utilisée si Telegram refuse le balisage

        def _set(value):
            if in_kwargs:
                kwargs[text_kw] = value
            else:
                args[text_pos] = value

        try:
            if in_kwargs:
                text = kwargs[text_kw]
            elif text_pos is not None and len(args) > text_pos:
                text = args[text_pos]
            else:
                text = None

            # parse_mode passé en position (rare) → on ne touche à rien.
            positional_pm = text_pos is not None and len(args) > text_pos + 1 and not in_kwargs
            if isinstance(text, str) and not positional_pm:
                pm = kwargs.get("parse_mode")
                if isinstance(pm, str) and pm.lower() in _MD_MODES:
                    _set(md1_to_html(text))
                    kwargs["parse_mode"] = "HTML"
                    fallback = text.replace("**", "").replace("`", "")
                elif isinstance(pm, str) and pm.upper() == "HTML":
                    fallback = to_plain(text)
                elif "parse_mode" not in kwargs or _is_unset(pm):
                    new_text, mode = prepare_text(text)
                    if new_text is not text:
                        _set(new_text)
                    if mode:
                        kwargs["parse_mode"] = mode
                        fallback = to_plain(new_text)
        except Exception:  # le filet ne doit jamais casser un envoi
            logger.exception("html_guard : analyse impossible, message envoyé tel quel")

        try:
            return await orig(self, *args, **kwargs)
        except Exception as exc:
            if fallback is None or not _is_entity_error(exc):
                raise
            logger.warning("html_guard : balisage refusé par Telegram (%s) : envoi en texte brut.", exc)
            _set(fallback)
            kwargs["parse_mode"] = None
            return await orig(self, *args, **kwargs)

    wrapper._html_guard = True
    wrapper.__name__ = getattr(orig, "__name__", "wrapper")
    wrapper.__doc__ = getattr(orig, "__doc__", None)
    return wrapper


# (méthode du Bot, paramètre texte, position du texte si passé sans nom)
_PATCHES = (
    ("send_message", "text", 1),            # send_message(chat_id, text, …)
    ("edit_message_text", "text", 0),       # edit_message_text(text, chat_id, …)
    ("send_photo", "caption", None),
    ("send_document", "caption", None),
    ("send_video", "caption", None),
    ("send_animation", "caption", None),
    ("edit_message_caption", "caption", None),
)


def install_html_guard() -> None:
    """À appeler une fois au démarrage (idempotent)."""
    from telegram import Bot
    from telegram.ext import ExtBot

    for cls in (Bot, ExtBot):
        for name, text_kw, text_pos in _PATCHES:
            orig = cls.__dict__.get(name)
            if orig is None or getattr(orig, "_html_guard", False):
                continue
            setattr(cls, name, _wrap(orig, text_kw, text_pos))
    logger.info("🛡️ html_guard installé : Markdown converti en HTML, balises passées en HTML, "
                "repli en texte brut si Telegram refuse un balisage.")
