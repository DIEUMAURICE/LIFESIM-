# utils/ui.py — 🎨 Mise en page des boutons (lisibilité sur téléphone)
"""
Telegram affiche N boutons d'une même ligne côte à côte : au-delà d'une quinzaine de caractères par bouton,
le texte est tronqué (« … ») ou écrasé. `layout` met deux boutons sur une ligne SEULEMENT s'ils sont courts ;
sinon chacun a sa propre ligne, pleine largeur, donc lisible.
"""
from __future__ import annotations

import html
import re

SHORT = 20          # caractères visibles max pour partager une ligne à deux
_EMOJI = re.compile(r"[\U0001F000-\U0001FAFF\u2600-\u27BF\uFE0F\u200D]")


def visible_len(text: str) -> int:
    """Longueur affichée (un emoji compte 2 caractères de large)."""
    emojis = len(_EMOJI.findall(text.replace("\uFE0F", "")))
    return len(_EMOJI.sub("", text)) + emojis * 2


def layout(buttons: list, per_row: int = 2, short: int = SHORT) -> list[list]:
    """Range des boutons (objets avec .text) en lignes lisibles."""
    rows: list[list] = []
    cur: list = []
    for b in buttons:
        fits = visible_len(b.text) <= short
        if fits and len(cur) < per_row and all(visible_len(x.text) <= short for x in cur):
            cur.append(b)
            continue
        if cur:
            rows.append(cur)
            cur = []
        if fits:
            cur = [b]
        else:
            rows.append([b])
    if cur:
        rows.append(cur)
    return rows


def esc(value, quote: bool = False) -> str:
    """Échappe le HTML pour Telegram sans transformer les apostrophes ni les guillemets (lisibles tels quels)."""
    return html.escape(str(value), quote=quote)
