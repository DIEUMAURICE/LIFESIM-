# utils/decorators.py — LIFESIM ULTRA V2 (version corrigée)
"""
═══════════════════════════════════════════════════════════════════════════
Décorateurs de protection et hiérarchie admin complète.
═══════════════════════════════════════════════════════════════════════════

Ce fichier fournit :
  • Protection de base : @require_registered, @require_free, @admin_only
  • Cooldown atomique : @cooldown(key, duration, msg)
  • Vérification de solde : @require_min_balance(amount)
  • Rate limit : @rate_limited
  • Hiérarchie admin complète :
      - get_user_role(user_id)         → rôle STATIQUE (config, sync)
      - get_user_role_async(user_id)   → rôle STATIQUE + DYNAMIQUE (BDD)
      - requireLevel(min_level)        → décorateur générique (async, BDD inclus)
      - admin_n1_only, admin_n2_only, game_leader_only,
        lead_staff_only, lead_principal_only, lead_studio_only

✅ FIX CRITIQUE : requireLevel et lead_studio_only utilisent désormais
   get_user_role_async() → les rôles assignés via /nommer_* (BDD) sont
   enfin reconnus par les décorateurs.
"""
from utils.swallow import swallowed
import functools
import logging

from telegram import Update
from telegram.ext import ContextTypes

from database import get_user, log_admin_action
from utils.helpers import now, fmt_time
from utils.ratelimit import rate_limit_middleware
from utils.cooldowns import claim_cooldown, release_cooldown
from utils.gametime import game_seconds_to_real
from utils.simulation import apply_passive_simulation
from config import (
    ADMIN_IDS,
    ROLE_LABELS,
    ROLE_HIERARCHY,
    LEAD_PRINCIPAL_IDS,
    LEAD_STUDIO_IDS,
    LEAD_INFLUENCEURS_IDS,
    TRANSVERSE_ROLES,
    LEAD_STAFF_GLOBAL_IDS,
    GAME_LEADER_IDS,
    ADMIN_N2_IDS,
    ADMIN_N1_IDS,
    role_level,
    can_manage_role,
)

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
#                        HELPERS INTERNES
# ═══════════════════════════════════════════════════════════════════════════
async def _reply(update: Update, text: str, parse_mode: str | None = None):
    """Répond sur le message ou le callback selon le contexte."""
    try:
        if update.message:
            await update.message.reply_text(text, parse_mode=parse_mode)
        elif update.callback_query and update.callback_query.message:
            await update.callback_query.message.reply_text(text, parse_mode=parse_mode)
    except Exception:
        logger.exception("Impossible de répondre à l'utilisateur")


def _command_label(update: Update) -> str:
    """Reconstruit un libellé lisible de la commande/action (pour l'audit log)."""
    try:
        if update.message and update.message.text:
            return update.message.text.split()[0]
        if update.callback_query and update.callback_query.data:
            return f"callback:{update.callback_query.data}"
    except Exception:
        swallowed('utils/decorators.py')
    return "unknown"


# ═══════════════════════════════════════════════════════════════════════════
#                HIÉRARCHIE ADMIN — Rôle d'un utilisateur
# ═══════════════════════════════════════════════════════════════════════════
def get_user_role(user_id: int) -> str:
    """
    Rôle STATIQUE uniquement (config).

    ⚠️ Ne voit PAS les rôles dynamiques (assignés via /nommer_*).
       Utilise `get_user_role_async()` pour obtenir le rôle effectif.
    """
    if user_id in LEAD_PRINCIPAL_IDS:
        return "LEAD_PRINCIPAL"
    if user_id in LEAD_STUDIO_IDS:
        return "LEAD_STUDIO"
    if user_id in LEAD_INFLUENCEURS_IDS:
        return "LEAD_INFLUENCEURS"
    if user_id in LEAD_STAFF_GLOBAL_IDS:
        return "LEAD_STAFF_GLOBAL"
    if user_id in GAME_LEADER_IDS:
        return "GAME_LEADER"
    if user_id in ADMIN_N2_IDS:
        return "ADMIN_N2"
    if user_id in ADMIN_N1_IDS:
        return "ADMIN_N1"
    return "PLAYER"


async def get_user_role_async(user_id: int) -> str:
    """
    Rôle EFFECTIF = max(statique, dynamique BDD).

    À utiliser partout où une vérification de permission doit reconnaître
    les joueurs nommés via `/nommer_*`, `/lsg_nommer_*`, `/gl_nommer_*`.
    """
    from database import get_active_admin_role

    static_role = get_user_role(user_id)

    try:
        dyn = await get_active_admin_role(user_id)
    except Exception:
        logger.exception("get_active_admin_role a échoué pour %s", user_id)
        dyn = None

    if dyn and isinstance(dyn, dict):
        dyn_role = dyn.get("role")
        if dyn_role and (role_level(dyn_role) > role_level(static_role)
                         or (static_role == "PLAYER" and dyn_role in TRANSVERSE_ROLES)):
            return dyn_role

    return static_role


# ═══════════════════════════════════════════════════════════════════════════
#                PROTECTION DE BASE
# ═══════════════════════════════════════════════════════════════════════════
# Commandes exemptées de la porte « personnage obligatoire » : création du personnage
# elle-même (handlers.personnage) ainsi que l'aide et l'annulation, toujours accessibles
# même en pleine création (ex. pour sortir d'un flux bloqué).
_CHARACTER_GATE_EXEMPT = {"cmd_personnage", "cmd_aide", "cmd_help", "cmd_guide", "cmd_annuler"}


def require_registered(func):
    """Vérifie que le joueur existe et a fait le menu. Applique la simulation passive."""
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        if not user:
            return
        u = await get_user(user.id, user.username or "", user.full_name or "")
        if u.get("banned"):
            await _reply(update, "🚫 Tu as été banni du jeu.")
            return
        if not u.get("registered"):
            await _reply(
                update,
                "<b>Bienvenue dans EARTH ANGEL RP</b>\n"
                "Tu n'es pas encore apparu sur Terre.\n"
                "Ouvre le 🎮 Menu principal pour entrer dans le monde.",
                parse_mode="HTML",
            )
            return

        if func.__name__ not in _CHARACTER_GATE_EXEMPT and func.__module__ != "handlers.personnage":
            from utils.character import gate as _character_gate
            if await _character_gate(update, user.id):
                return

        sim_result = await apply_passive_simulation(user.id)
        if sim_result.get("alert"):
            await _reply(update, sim_result["alert"], parse_mode="HTML")
        return await func(update, context, *args, **kwargs)
    return wrapper


# Modules où le joueur à 0 de santé peut encore agir (se soigner, manger, dormir, acheter un médicament).
_HEALING_MODULES = {"handlers.health", "handlers.life", "handlers.sante", "handlers.market"}
DOWN_TEXT = ("💀 Ta santé est à <b>zéro</b> : tu es hors d'état d'agir.\n"
             "Soigne-toi pour reprendre le jeu : 🏥 hôpital, 💊 médicaments, 🍽️ manger, 😴 dormir.")


async def free_problem(user_id: int, module: str = "") -> str | None:
    """Règle unique « le joueur peut-il agir ? » (bot ET application web).

    Renvoie le texte de refus (HTML) si le joueur est à terre, en prison, à l'hôpital ou
    neutralisé ; None s'il est libre d'agir. `module` = module de l'action (certains modules
    restent permis à 0 de santé : se soigner, manger, dormir…)."""
    u = await get_user(user_id)

    # god mode (outil de test) : aucune restriction
    if u.get("god_mode"):
        return None

    # ℹ️ Tous les rôles jouent (prison, hôpital… s'appliquent à tous). Seule la politique / les élections sont
    # fermées aux Admins N2+, Game Leaders et Leads (voir utils/roles.py : players_only).

    # 💀 Santé à 0 : considéré comme « à terre » — aucune action, sauf celles qui permettent de se soigner.
    if u.get("health", 100) <= 0 and module not in _HEALING_MODULES:
        return DOWN_TEXT

    t = now()
    if u.get("prison_until", 0) > t:
        rem = u["prison_until"] - t
        return (f"⛓️ Tu es en prison ! Libération dans <b>{fmt_time(rem)}</b>\n"
                f"💰 Caution et ⚖️ Tribunal : menu Société → Justice")
    if u.get("hospital_until", 0) > t:
        rem = u["hospital_until"] - t
        return f"🏥 Tu es à l'hôpital ! Sortie dans <b>{fmt_time(rem)}</b>"
    # 🚓 Neutralisé / menotté / en interrogatoire / retenu par l'armée : plus aucune action
    from utils.ordre import restraint_reason
    restrained = await restraint_reason(user_id)
    if restrained:
        return f"⛓️ Tu es {restrained}"
    return None


def require_free(func):
    """Vérifie que le joueur n'est ni en prison, ni à l'hôpital."""
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        if not user:
            return
        problem = await free_problem(user.id, func.__module__)
        if problem:
            await _reply(update, problem, parse_mode="HTML")
            return
        return await func(update, context, *args, **kwargs)
    return wrapper


def admin_only(func):
    """
    Réservé aux admins — accepte :
      • les rôles statiques (config ADMIN_IDS)
      • les rôles dynamiques (BDD admin_roles)
      • le god_mode
    """
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        if not user:
            return
        u = await get_user(user.id)
        role = await get_user_role_async(user.id)
        if role == "PLAYER" and not u.get("god_mode"):
            await _reply(update, "🚫 Accès réservé aux admins.")
            return
        return await func(update, context, *args, **kwargs)
    return wrapper


# ═══════════════════════════════════════════════════════════════════════════
#                COOLDOWN ATOMIQUE
# ═══════════════════════════════════════════════════════════════════════════
async def cooldown_problem(user_id: int, key: str, duration: int, error_msg: str = None,
                           real_time: bool = False) -> tuple[str | None, bool]:
    """Règle unique du cooldown atomique (bot ET application web).

    → (message_de_refus | None, réservé). `réservé` vaut True quand le cooldown vient d'être pris :
    l'appelant doit alors le relâcher (release_cooldown) si l'action échoue ensuite."""
    u = await get_user(user_id)
    # Exemption admins (statiques + dynamiques) & god mode
    role = await get_user_role_async(user_id)
    if role != "PLAYER" or u.get("god_mode"):
        return None, False

    allowed, remaining = await claim_cooldown(user_id, key, duration)
    if not allowed:
        shown = fmt_time(game_seconds_to_real(remaining) if real_time else remaining)
        if error_msg:
            return error_msg.replace("{remaining}", shown), False
        return f"⏳ Cooldown ! Attends encore {shown}.", False
    return None, True


def cooldown(key: str, duration: int, error_msg: str = None, real_time: bool = False):
    """Décorateur utilisant la table `user_cooldowns` (réservation atomique).

    `duration` est en secondes de JEU (horloge du bot). `real_time=True` (bonus quotidien : seule
    exception du jeu, 24 h RÉELLES) affiche le temps restant en temps réel ; dans `error_msg`,
    « {remaining} » est remplacé par ce temps restant.
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            user = update.effective_user
            if not user:
                return
            message, claimed = await cooldown_problem(user.id, key, duration, error_msg, real_time)
            if message:
                await _reply(update, message, parse_mode="HTML")
                return
            try:
                return await func(update, context, *args, **kwargs)
            except Exception:
                if claimed:
                    await release_cooldown(user.id, key)
                raise

        return wrapper
    return decorator


# ═══════════════════════════════════════════════════════════════════════════
#                VÉRIFICATION DE SOLDE
# ═══════════════════════════════════════════════════════════════════════════
def require_min_balance(amount: int):
    """Vérifie que le joueur a au moins `amount` coins."""
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            user = update.effective_user
            if not user:
                return
            u = await get_user(user.id)
            role = await get_user_role_async(user.id)
            if role != "PLAYER" or u.get("god_mode"):
                return await func(update, context, *args, **kwargs)
            if u["balance"] < amount:
                from utils.helpers import fmt
                await _reply(
                    update,
                    f"❌ Fonds insuffisants. Il te faut au moins <b>{fmt(amount)}</b>.\n"
                    f"💰 Ton solde : {fmt(u['balance'])}",
                    parse_mode="HTML",
                )
                return
            return await func(update, context, *args, **kwargs)
        return wrapper
    return decorator


# ═══════════════════════════════════════════════════════════════════════════
#                RATE LIMIT
# ═══════════════════════════════════════════════════════════════════════════
def rate_limited(func):
    """Applique le middleware de rate limit global."""
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        if not await rate_limit_middleware(update, context):
            return
        return await func(update, context, *args, **kwargs)
    return wrapper


# ═══════════════════════════════════════════════════════════════════════════
#      SYSTÈME DE GRADES ADMIN — requireLevel() + audit log
#      ✅ FIX : utilise get_user_role_async() → rôles dynamiques reconnus
# ═══════════════════════════════════════════════════════════════════════════

async def _get_admin_level_async(user_id: int) -> int:
    """Niveau numérique du rôle EFFECTIF (statique + dynamique). 0 = joueur."""
    role = await get_user_role_async(user_id)
    return role_level(role)   # rôles transverses = 0 : ils n'ont que leurs commandes dédiées (lead_studio_only, campagnes)


def _role_key_from_level(level: int) -> str:
    """Retourne la clé du rôle à un niveau donné."""
    try:
        if 0 <= level < len(ROLE_HIERARCHY):
            return ROLE_HIERARCHY[level]
    except Exception:
        swallowed('utils/decorators.py')
    return "PLAYER"


def requireLevel(min_level: int):
    """
    Middleware de vérification de niveau admin.

    - Bloque IMMÉDIATEMENT l'exécution si l'ID n'a pas au moins le grade requis.
    - Si autorisé, enregistre automatiquement l'action dans les logs
      (ID, nom/username, rôle, commande, timestamp) AVANT d'exécuter.
    - ✅ Reconnaît les rôles dynamiques assignés via /nommer_*.

    Utilisation :
        @requireLevel(role_level("LEAD_STAFF_GLOBAL"))
        async def cmd_sensible(update, context): ...
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
            user = update.effective_user
            if not user:
                return

            # ⭐ FIX : rôle EFFECTIF (statique + dynamique BDD)
            level = await _get_admin_level_async(user.id)

            if level < min_level:
                required_label = ROLE_LABELS.get(
                    _role_key_from_level(min_level), f"Niveau {min_level}"
                )
                current_label = ROLE_LABELS.get(
                    _role_key_from_level(level), "Aucun grade"
                )
                await _reply(
                    update,
                    "🚫 <b>Accès refusé</b>\n"
                    f"Cette action nécessite au minimum le grade <b>{required_label}</b>.\n"
                    f"Ton grade actuel : <b>{current_label}</b>.",
                    parse_mode="HTML",
                )
                if update.callback_query:
                    try:
                        await update.callback_query.answer(
                            "🚫 Accès refusé.", show_alert=True
                        )
                    except Exception:
                        swallowed('utils/decorators.py')
                return

            # ─── Traçabilité (Audit Log) ───
            role_key = _role_key_from_level(level)
            role_label = ROLE_LABELS.get(role_key, "Inconnu")
            command_name = _command_label(update)
            try:
                await log_admin_action(
                    actor_id=user.id,
                    action=command_name,
                    target_id=0,
                    details=f"Role={role_label}",
                )
            except Exception:
                # Une panne du log ne doit jamais bloquer une action admin légitime.
                pass

            return await func(update, context, *args, **kwargs)
        return wrapper
    return decorator


# ═══════════════════════════════════════════════════════════════════════════
#            RACCOURCIS DE DÉCORATEURS PAR NIVEAU
# ═══════════════════════════════════════════════════════════════════════════

def admin_n1_only(func):
    """Accès minimum : Admin N1."""
    return requireLevel(role_level("ADMIN_N1"))(func)


def admin_n2_only(func):
    """Accès minimum : Admin N2."""
    return requireLevel(role_level("ADMIN_N2"))(func)


def game_leader_only(func):
    """Accès minimum : Game Leader."""
    return requireLevel(role_level("GAME_LEADER"))(func)


def lead_staff_only(func):
    """Accès minimum : Lead Staff Global."""
    return requireLevel(role_level("LEAD_STAFF_GLOBAL"))(func)


def lead_principal_only(func):
    """Accès minimum : Lead Principal."""
    return requireLevel(role_level("LEAD_PRINCIPAL"))(func)


def lead_studio_only(func):
    """
    Accès minimum : Lead Studio.
    ⚠️ Lead Studio est un rôle transversal (pas dans la hiérarchie linéaire).
    ✅ FIX : utilise la version ASYNC → les rôles dynamiques sont reconnus.
    """
    @functools.wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user = update.effective_user
        if not user:
            return
        role = await get_user_role_async(user.id)
        if role not in ("LEAD_STUDIO", "LEAD_PRINCIPAL"):
            await _reply(
                update,
                "🚫 <b>Accès réservé au Lead Studio.</b>",
                parse_mode="HTML",
            )
            return

        try:
            await log_admin_action(
                actor_id=user.id,
                action=_command_label(update),
                target_id=0,
                details=f"Role={ROLE_LABELS.get(role, role)}",
            )
        except Exception:
            swallowed('utils/decorators.py')

        return await func(update, context, *args, **kwargs)
    return wrapper


# ═══════════════════════════════════════════════════════════════════════════
#                          EXPORTS
# ═══════════════════════════════════════════════════════════════════════════
__all__ = [
    # Protection de base
    "require_registered",
    "require_free",
    "admin_only",
    "cooldown",
    "require_min_balance",
    "rate_limited",
    # Hiérarchie
    "get_user_role",
    "get_user_role_async",
    "requireLevel",
    # Raccourcis par niveau
    "admin_n1_only",
    "admin_n2_only",
    "game_leader_only",
    "lead_staff_only",
    "lead_principal_only",
    "lead_studio_only",
]