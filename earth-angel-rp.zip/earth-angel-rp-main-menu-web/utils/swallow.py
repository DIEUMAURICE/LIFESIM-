"""utils/swallow.py — Une erreur volontairement ignorée reste visible dans les journaux (niveau DEBUG).

Remplace les « except Exception: pass » silencieux : le jeu continue comme avant,
mais une panne (envoi refusé, message non modifiable…) laisse une trace pour le diagnostic.
"""
import logging

_log = logging.getLogger("earth_angel.ignored")


def swallowed(where: str = "") -> None:
    """À appeler dans un « except » qui ignore volontairement l'erreur."""
    _log.debug("Erreur ignorée (%s)", where, exc_info=True)
