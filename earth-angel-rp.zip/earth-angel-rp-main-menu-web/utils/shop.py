# utils/shop.py — 🛍️ Boutique v2 : catalogue, prix, commandes fiables, fidélité (sans dépendance Telegram)
"""
Principes
─────────
• Le catalogue vit en BASE (`shop_catalog`) : le staff active, désactive, met en avant, règle prix, promo, stock et
  dates sans toucher au code. Le texte et l'effet des articles de base viennent de config.STARS_SHOP / STARS_SUBSCRIPTIONS.
• Une COMMANDE (`shop_orders`) naît à la réception du paiement (identifiant de transaction unique : jamais deux livraisons).
  Si la livraison échoue, la commande passe en « failed » et le joueur est REMBOURSÉ ; une tâche planifiée reprend les
  commandes restées « paid » (arrêt du bot en plein achat).
• Incitations : offre du jour, offre de bienvenue, fidélité cumulée, cadeaux à un autre joueur, éditions limitées (stock + dates).
• L'argent vendu en boutique peut être masqué par le staff (réglage « shop_money ») : au fil de la transition du bot.
"""
from __future__ import annotations

import re
import time

import aiosqlite

from config import STARS_SHOP, STARS_SHOP_CATEGORIES, STARS_SUBSCRIPTIONS, STARS_RETIRED_ITEMS
from database import db_connection

# ── Catégories ────────────────────────────────────────────────────────────────
CATEGORIES = {
    "boost": ("⚡", "Boosts temporaires"), "upgrade": ("💎", "Améliorations"), "consumable": ("🎁", "Consommables"),
    "cosmetic": ("🎨", "Style & cosmétiques"), "pack": ("📦", "Packs"), "pass": ("👑", "Pass VIP & Premium"),
    "exclusive": ("🌟", "Exclusivités"),
}
_CAT_OF_ID = {1: "boost", 2: "upgrade", 3: "consumable", 4: "cosmetic", 5: "pack"}
MONEY_ITEMS = {"sac_coins", "pack_starter", "pack_decouverte", "pack_entrepreneur"}   # versent des €A : masquables
WELCOME_ITEM, WELCOME_PCT = "pack_starter", 40
DEAL_PCT = 20
PROMO_STEPS = (0, 10, 20, 30, 40, 50)
STOCK_STEPS = (-1, 10, 25, 50, 100)
WINDOW_HOURS = (0, 24, 72, 168)                      # 0 = sans limite
LOYALTY = [(100, "badge_perso"), (300, "emoji_signature"), (500, "titre_perso"), (1500, "couleur_animee")]
MAX_ATTEMPTS = 3


def _now() -> int:
    return int(time.time())


# ── Catalogue ─────────────────────────────────────────────────────────────────
def meta(item: dict) -> dict:
    """Texte et effet d'un article (config pour les articles de base, base de données pour les exclusivités)."""
    key, kind = item["item_key"], item["kind"]
    src = (STARS_SUBSCRIPTIONS if kind == "sub" else STARS_SHOP).get(key)
    if src:
        return {"label": src["label"], "desc": src.get("desc", ""), "short": src.get("short_desc", ""),
                "tag": src.get("tag", ""), "type": src.get("type", "sub" if kind == "sub" else "")}
    return {"label": item["label"] or key, "desc": item["description"], "short": item["description"][:60],
            "tag": "🌟 EXCLUSIF", "type": "custom"}


async def seed() -> int:
    """Insère les articles de base absents du catalogue (n'écrase jamais un réglage du staff)."""
    n = 0
    async with db_connection() as db:
        order = 0
        for key, it in STARS_SHOP.items():
            order += 1
            cur = await db.execute(
                "INSERT OR IGNORE INTO shop_catalog(item_key, kind, category, stars, money_item, sort, created_at) VALUES (?,?,?,?,?,?,?)",
                (key, "shop", _CAT_OF_ID.get(it.get("cat"), "upgrade"), it["stars"], 1 if key in MONEY_ITEMS else 0, order, _now()))
            n += cur.rowcount
        for key, it in STARS_SUBSCRIPTIONS.items():
            order += 1
            cur = await db.execute(
                "INSERT OR IGNORE INTO shop_catalog(item_key, kind, category, stars, sort, created_at) VALUES (?,?,?,?,?,?)",
                (key, "sub", "pass", it["stars"], order, _now()))
            n += cur.rowcount
        await db.commit()
    return n


async def items(category: str | None = None, include_hidden: bool = False) -> list[dict]:
    sql = "SELECT * FROM shop_catalog"
    where, params = [], []
    if category:
        where.append("category=?"); params.append(category)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY featured DESC, sort, item_key"
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(sql, params) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
    if include_hidden:
        return rows
    from utils.gamerules import switch_on
    money = await switch_on("shop_money")
    return [r for r in rows if visible(r, money)[0]]


async def get_item(key: str) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM shop_catalog WHERE item_key=?", (key,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


def visible(item: dict, money_on: bool, ts: int | None = None) -> tuple[bool, str]:
    """L'article est-il proposé en ce moment ? (actif, fenêtre de dates, stock, argent masqué par le staff)."""
    ts = ts or _now()
    if item.get("item_key") in STARS_RETIRED_ITEMS:
        return False, "retiré de la vente"
    if not item["active"]:
        return False, "indisponible"
    if item["money_item"] and not money_on:
        return False, "indisponible"
    if item["starts_at"] and ts < item["starts_at"]:
        return False, "pas encore disponible"
    if item["ends_at"] and ts >= item["ends_at"]:
        return False, "édition terminée"
    if item["stock"] >= 0 and item["sold"] >= item["stock"]:
        return False, "épuisé"
    return True, ""


def deal_key(candidates: list[dict], day: int | None = None) -> str | None:
    """Offre du jour : rotation déterministe parmi les articles ordinaires (hors pass, packs et exclusivités)."""
    pool = sorted((i["item_key"] for i in candidates
                   if i["category"] in ("boost", "consumable", "cosmetic", "upgrade") and not i["money_item"]))
    if not pool:
        return None
    day = (_now() // 86400) if day is None else day
    return pool[day % len(pool)]


def price(item: dict, *, welcome: bool = False, deal: str | None = None) -> tuple[int, int, str]:
    """Prix effectif en Étoiles → (prix, remise %, raison). La meilleure remise s'applique (pas de cumul)."""
    options = [(item["promo_pct"], "promo")]
    if deal and item["item_key"] == deal:
        options.append((DEAL_PCT, "offre du jour"))
    if welcome and item["item_key"] == WELCOME_ITEM:
        options.append((WELCOME_PCT, "offre de bienvenue"))
    pct, why = max(options, key=lambda o: o[0])
    return max(1, round(item["stars"] * (100 - pct) / 100)), pct, (why if pct else "")


# ── Commandes ─────────────────────────────────────────────────────────────────
async def delivered_count(user_id: int) -> int:
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM shop_orders WHERE user_id=? AND status='delivered' AND test=0", (user_id,)) as cur:
            return (await cur.fetchone())[0]


async def create_order(charge_id: str, user_id: int, target_id: int, key: str, kind: str, stars: int, test: bool = False) -> tuple[int | None, bool]:
    """Enregistre le paiement. Retourne (id, True) si nouveau, (id, False) si déjà connu (doublon Telegram)."""
    async with db_connection() as db:
        cur = await db.execute(
            "INSERT OR IGNORE INTO shop_orders(charge_id, user_id, target_id, item_key, kind, stars_paid, status, test, created_at) "
            "VALUES (?,?,?,?,?,?,'paid',?,?)", (charge_id, user_id, target_id, key, kind, stars, 1 if test else 0, _now()))
        await db.commit()
        if cur.rowcount:
            return cur.lastrowid, True
        async with db.execute("SELECT id FROM shop_orders WHERE charge_id=?", (charge_id,)) as c2:
            row = await c2.fetchone()
    return (row[0] if row else None), False


async def get_order(order_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM shop_orders WHERE id=?", (order_id,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def deliver(order_id: int, apply_fn) -> tuple[str, str]:
    """Livre une commande. `apply_fn(kind, key, target_id) -> texte`. Retourne (statut, texte ou erreur) avec statut
    'delivered' | 'already' | 'soldout' | 'failed'. Idempotent : une commande livrée ne l'est jamais deux fois."""
    order = await get_order(order_id)
    if not order:
        return "failed", "commande introuvable"
    if order["status"] == "delivered":
        return "already", ""
    if order["status"] == "refunded":
        return "failed", "commande remboursée"
    key = order["item_key"]
    async with db_connection() as db:
        # réserve une unité de stock (atomique) ; pas de limite si stock < 0
        cur = await db.execute("UPDATE shop_catalog SET sold=sold+1 WHERE item_key=? AND (stock<0 OR sold<stock)", (key,))
        await db.commit()
        reserved = cur.rowcount > 0
    if not reserved and (await get_item(key)):
        await mark(order_id, "failed", "épuisé")
        return "soldout", "épuisé"
    try:
        text = await apply_fn(order["kind"], key, order["target_id"])
    except Exception as e:                      # l'effet a échoué : on rend le stock et on laisse la commande récupérable
        refusal = isinstance(e, ValueError)      # refus « métier » (plafond, condition) : inutile de réessayer → remboursement
        async with db_connection() as db:
            await db.execute("UPDATE shop_catalog SET sold=MAX(0, sold-1) WHERE item_key=?", (key,))
            await db.execute("UPDATE shop_orders SET status='failed', error=?, attempts=? WHERE id=?",
                             (("REFUS:" if refusal else "") + str(e)[:190], MAX_ATTEMPTS if refusal else order["attempts"] + 1, order_id))
            await db.commit()
        return "refused" if refusal else "failed", str(e)
    async with db_connection() as db:
        await db.execute("UPDATE shop_orders SET status='delivered', delivered_at=?, error='' WHERE id=?", (_now(), order_id))
        await db.commit()
    return "delivered", text


async def mark(order_id: int, status: str, error: str = "") -> None:
    async with db_connection() as db:
        await db.execute("UPDATE shop_orders SET status=?, error=? WHERE id=?", (status, error[:200], order_id))
        await db.commit()


async def recoverable(older_than: int = 120) -> list[dict]:
    """Commandes payées jamais livrées (arrêt du bot) ou en échec avec des essais restants."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT * FROM shop_orders WHERE status IN ('paid','failed') AND test=0 AND attempts<? AND created_at<? "
                "ORDER BY id LIMIT 20", (MAX_ATTEMPTS, _now() - older_than)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def history(user_id: int, limit: int = 8) -> list[dict]:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM shop_orders WHERE user_id=? AND test=0 ORDER BY id DESC LIMIT ?", (user_id, limit)) as cur:
            return [dict(r) for r in await cur.fetchall()]


# ── Fidélité ──────────────────────────────────────────────────────────────────
async def spent(user_id: int) -> int:
    async with db_connection() as db:
        async with db.execute("SELECT COALESCE(SUM(stars_paid),0) FROM shop_orders WHERE user_id=? AND status='delivered' AND test=0", (user_id,)) as cur:
            return int((await cur.fetchone())[0])


async def loyalty(user_id: int) -> dict:
    total = await spent(user_id)
    async with db_connection() as db:
        async with db.execute("SELECT tier FROM shop_rewards WHERE user_id=?", (user_id,)) as cur:
            claimed = {r[0] for r in await cur.fetchall()}
    tiers = [{"tier": i, "need": need, "item": key, "reached": total >= need, "claimed": i in claimed}
             for i, (need, key) in enumerate(LOYALTY)]
    nxt = next((t for t in tiers if not t["reached"]), None)
    return {"spent": total, "tiers": tiers, "next": nxt}


async def claim_reward(user_id: int, tier: int, apply_fn) -> tuple[bool, str]:
    info = await loyalty(user_id)
    if not 0 <= tier < len(LOYALTY) or not info["tiers"][tier]["reached"]:
        return False, "Palier pas encore atteint."
    async with db_connection() as db:
        cur = await db.execute("INSERT OR IGNORE INTO shop_rewards(user_id, tier, claimed_at) VALUES (?,?,?)", (user_id, tier, _now()))
        await db.commit()
        if not cur.rowcount:
            return False, "Récompense déjà récupérée."
    try:
        return True, await apply_fn("shop", LOYALTY[tier][1], user_id)
    except Exception as e:
        async with db_connection() as db:
            await db.execute("DELETE FROM shop_rewards WHERE user_id=? AND tier=?", (user_id, tier))
            await db.commit()
        return False, f"Erreur : {e}"


# ── Exclusivités (créées par le staff) ───────────────────────────────────────
async def create_custom(label: str, stars: int, stock: int = -1, hours: int = 0, description: str = "") -> str:
    label = label.strip()[:40]
    code = "x" + re.sub(r"[^a-z0-9]", "", label.lower())[:12] + str(_now() % 10000)
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO shop_catalog(item_key, kind, category, stars, stock, ends_at, sort, label, description, featured, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,1,?)",
            (code, "custom", "exclusive", max(1, int(stars)), stock, _now() + hours * 3600 if hours else 0, 0, label,
             description.strip()[:200] or "Article exclusif en édition limitée.", _now()))
        await db.commit()
    return code


async def grant_cosmetic(user_id: int, code: str) -> str:
    item = await get_item(code)
    label = (item or {}).get("label") or code
    async with db_connection() as db:
        await db.execute("INSERT OR IGNORE INTO shop_cosmetics(user_id, code, label, granted_at) VALUES (?,?,?,?)", (user_id, code, label, _now()))
        await db.commit()
    return f"{label} ajouté à ta collection"


async def cosmetics_of(user_id: int) -> list[str]:
    async with db_connection() as db:
        async with db.execute("SELECT label FROM shop_cosmetics WHERE user_id=? ORDER BY id", (user_id,)) as cur:
            return [r[0] for r in await cur.fetchall()]


# ── Réglages staff ───────────────────────────────────────────────────────────
_FIELDS = {"active", "featured", "stars", "promo_pct", "stock", "starts_at", "ends_at"}


async def set_field(key: str, field: str, value: int) -> bool:
    if field not in _FIELDS:
        return False
    async with db_connection() as db:
        cur = await db.execute(f"UPDATE shop_catalog SET {field}=? WHERE item_key=?", (int(value), key))
        await db.commit()
    return cur.rowcount > 0


async def stats(days: int = 7) -> dict:
    since = _now() - days * 86400
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async def one(sql, p=()):
            async with db.execute(sql, p) as cur:
                return (await cur.fetchone())[0] or 0
        out = {
            "stars": await one("SELECT SUM(stars_paid) FROM shop_orders WHERE status='delivered' AND test=0 AND created_at>=?", (since,)),
            "orders": await one("SELECT COUNT(*) FROM shop_orders WHERE status='delivered' AND test=0 AND created_at>=?", (since,)),
            "buyers": await one("SELECT COUNT(DISTINCT user_id) FROM shop_orders WHERE status='delivered' AND test=0 AND created_at>=?", (since,)),
            "refunded": await one("SELECT COUNT(*) FROM shop_orders WHERE status='refunded' AND created_at>=?", (since,)),
            "attention": await one("SELECT COUNT(*) FROM shop_orders WHERE status IN ('paid','failed') AND test=0"),
        }
        async with db.execute("SELECT item_key, COUNT(*) n, SUM(stars_paid) s FROM shop_orders WHERE status='delivered' AND test=0 "
                              "AND created_at>=? GROUP BY item_key ORDER BY s DESC LIMIT 5", (since,)) as cur:
            out["top"] = [dict(r) for r in await cur.fetchall()]
    return out


async def attention_orders(limit: int = 10) -> list[dict]:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM shop_orders WHERE status IN ('paid','failed') AND test=0 ORDER BY id DESC LIMIT ?", (limit,)) as cur:
            return [dict(r) for r in await cur.fetchall()]
