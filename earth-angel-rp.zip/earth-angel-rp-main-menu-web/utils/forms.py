"""
utils/forms.py — Formulaires pilotés par des tables (remplace les commandes à arguments)
═══════════════════════════════════════════════════════════════════════
Une commande = un `Form` : liste de champs (`P`) posés un par un, puis appel de
l'ancienne `cmd_*` avec les arguments reconstitués. Boutons : `fm:<clé>` (démarrer)
et `fp:<n>` (choix n dans une liste de boutons).

    register(Form("postuler", "📝 Postuler", "handlers.companies:cmd_postuler",
                  params=(P("company", "choice", "Quelle entreprise ?", choices="companies"),
                          P("salary", "int", "Salaire souhaité (€A/j) ?", min=0)),
                  groups=("comp_postuler_info",)))
"""
from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Awaitable, Callable

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from database import db_connection
from utils.input_flow import ask, call_cmd, clear, flow

STATE = "_form"
PROVIDERS: dict[str, Callable[[int], Awaitable[list[tuple[str, str]]]]] = {}
FORMS: dict[str, "Form"] = {}


@dataclass(frozen=True)
class P:
    key: str
    kind: str                      # amount | int | user | text | choice | literal (valeur fixe, jamais demandée)
    prompt: str
    choices: tuple | str | None = None   # ((label, valeur), …) ou nom d'un provider
    min: int | None = None
    max: int | None = None
    reply: bool = False            # joueur transmis « en répondant à son message »
    one_word: bool = False         # texte sans espace
    quote: bool = False            # valeur transmise entre guillemets ("…")
    split: bool = False            # valeur découpée mot par mot (comme une commande tapée)


@dataclass(frozen=True)
class Form:
    key: str
    label: str
    cmd: str                       # "handlers.module:cmd_nom"
    params: tuple = ()
    groups: tuple = ()
    back: str = "menu_main"
    confirm: str | None = None     # texte de confirmation (action sensible)
    fixed_args: tuple = ()         # arguments constants ajoutés à la fin
    requires: str | None = None    # "merchant" : réservé aux commerçants (refus dès le début)
    area: str | None = None        # zone du hub (ex. "entreprises") où afficher ce formulaire, sans dépendre d'un préfixe de clé


def register(*forms: Form) -> None:
    for f in forms:
        FORMS[f.key] = f


def provider(name: str):
    def deco(fn):
        PROVIDERS[name] = fn
        return fn
    return deco


def form_rows(group: str, per_row: int = 2) -> list[list[InlineKeyboardButton]]:
    """Boutons de tous les formulaires d'un groupe (pour les menus existants)."""
    btns = [InlineKeyboardButton(f.label, callback_data=f"fm:{f.key}")
            for f in FORMS.values() if group in f.groups]
    return [btns[i:i + per_row] for i in range(0, len(btns), per_row)]


# ═══════════════════════════════════════════════════════════════════
#   MOTEUR
# ═══════════════════════════════════════════════════════════════════
def _back_markup(form: Form, extra: list | None = None) -> InlineKeyboardMarkup:
    rows = list(extra or [])
    rows.append([InlineKeyboardButton("⬅️ Retour", callback_data=form.back),
                 InlineKeyboardButton("❌ Annuler", callback_data="flow_cancel")])
    return InlineKeyboardMarkup(rows)


async def _edit(target, text: str, markup) -> None:
    if hasattr(target, "edit_message_text"):
        await target.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
    else:
        await target.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


async def start_form(query, context, key: str) -> None:
    form = FORMS.get(key)
    if not form:
        await query.edit_message_text("❌ Action inconnue.")
        return
    clear(context)
    if form.requires == "merchant":
        from handlers.market import can_sell_on_market, NOT_MERCHANT_TEXT
        if not await can_sell_on_market(_uid(query)):
            await _edit(query, NOT_MERCHANT_TEXT, _back_markup(form))
            return
    context.user_data[STATE] = {"key": key, "i": 0, "vals": [], "opts": []}
    await _next(query, context)


async def _next(target, context) -> None:
    st = context.user_data.get(STATE)
    if not st:
        return
    form = FORMS[st["key"]]
    if st["i"] >= len(form.params):
        if form.confirm and not st.get("confirmed"):
            rows = [[InlineKeyboardButton("✅ Confirmer", callback_data="fp:ok")]]
            await _edit(target, f"⚠️ <b>{form.label}</b>\n\n{form.confirm}", _back_markup(form, rows))
            return
        await _execute(target, context)
        return
    p = form.params[st["i"]]
    if p.kind == "literal":                       # constante insérée telle quelle (ex. séparateur « | »)
        st["vals"].append(p.choices)
        st["i"] += 1
        await _next(target, context)
        return
    head = f"<b>{form.label}</b>\n\n{p.prompt}"
    if p.kind == "choice":
        opts = await _options(p, _uid(target))
        if not opts:
            context.user_data.pop(STATE, None)
            await _edit(target, f"<b>{form.label}</b>\n\n❌ Rien à choisir pour le moment.",
                        _back_markup(form))
            return
        st["opts"] = [v for _, v in opts]
        rows = [[InlineKeyboardButton(lbl[:40], callback_data=f"fp:{n}")] for n, (lbl, _) in enumerate(opts)]
        await _edit(target, head, _back_markup(form, rows))
        return
    kind = {"amount": "amount", "int": "int", "user": "user"}.get(p.kind, "text")
    await ask(target, context, "form_step", head, kind=kind,
              min_value=p.min, max_value=p.max, back=form.back)


def _uid(target) -> int:
    u = getattr(target, "from_user", None) or target.effective_user
    return u.id


async def _options(p: P, user_id: int) -> list[tuple[str, str]]:
    if isinstance(p.choices, str):
        return await PROVIDERS[p.choices](user_id)
    return [(str(l), str(v)) for l, v in (p.choices or ())]


async def _store(target, context, p: P, value) -> None:
    st = context.user_data[STATE]
    if p.kind == "user":
        uid, name = value
        async with db_connection() as db:
            async with db.execute("SELECT username FROM users WHERE user_id=?", (uid,)) as cur:
                row = await cur.fetchone()
        uname = row[0] if row and row[0] else None
        value = {"id": uid, "name": name, "username": uname}
    st["vals"].append(value)
    st["i"] += 1
    await _next(target, context)


@flow("form_step")
async def _form_step(update, context, value, data):
    st = context.user_data.get(STATE)
    if not st:
        return
    form = FORMS[st["key"]]
    p = form.params[st["i"]]
    if p.one_word and " " in str(value):
        await update.effective_message.reply_text("❌ Un seul mot, sans espace.")
        await _next(update, context)
        return
    await _store(update, context, p, value)


async def pick(query, context, token: str) -> None:
    st = context.user_data.get(STATE)
    if not st:
        await query.edit_message_text("⌛ Action expirée. Rouvre le menu.")
        return
    if token == "ok":
        st["confirmed"] = True
        await _next(query, context)
        return
    form = FORMS[st["key"]]
    p = form.params[st["i"]]
    try:
        value = st["opts"][int(token)]
    except (ValueError, IndexError):
        await query.edit_message_text("⌛ Choix expiré. Recommence.")
        return
    await _store(query, context, p, value)


def build_args(form: Form, vals: list) -> tuple[list[str], dict | None]:
    args: list[str] = []
    reply_to = None
    for p, v in zip(form.params, vals):
        if p.kind == "user":
            if p.reply:
                reply_to = v
            else:
                args.append(f"@{v['username']}" if v["username"] else str(v["id"]))
        elif p.quote:
            args.append('"' + str(v).replace('"', "'") + '"')
        elif p.split:
            args.extend(str(v).split())
        else:
            args.append(str(v))
    return args + [str(a) for a in form.fixed_args], reply_to


async def _execute(target, context) -> None:
    st = context.user_data.pop(STATE, None)
    if not st:
        return
    form = FORMS[st["key"]]
    mod, fn = form.cmd.split(":")
    cmd = getattr(importlib.import_module(mod), fn)
    args, reply_to = build_args(form, st["vals"])
    await call_cmd(target, context, cmd, args, reply_to=reply_to)


async def forms_callback(update, context) -> None:
    q = update.callback_query
    await q.answer()
    kind, _, rest = q.data.partition(":")
    if kind == "fm":
        await start_form(q, context, rest)
    elif kind == "fp":
        await pick(q, context, rest)
