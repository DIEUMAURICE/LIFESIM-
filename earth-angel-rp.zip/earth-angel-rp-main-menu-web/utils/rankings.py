# utils/rankings.py — TOUS les classements du jeu, complets jusqu'au dernier, avec « ma position »
"""
Un seul moteur pour tous les classements (richesse, XP, karma, prestige, arène, social, gangs,
entreprises, métiers, fournisseurs, compétition…).

• Chaque classement est une requête SQL « source » : (id, name, value, extra, extra2).
• Le rang est calculé par SQLite (ROW_NUMBER) : classement COMPLET, de la 1re à la dernière place,
  page par page (PAGE_SIZE lignes) — plus aucun « top 10 » tronqué.
• `my_position()` retrouve le rang du joueur (ou de SON entreprise / SON gang) même s'il est
  très loin dans le classement ; l'écran propose un bouton « 📍 Ma position ».

Ce module ne dépend pas de Telegram : l'affichage est dans handlers/rankings.py.
"""
from __future__ import annotations

import html
import logging
from dataclasses import dataclass
from typing import Awaitable, Callable

import aiosqlite

from database import db_read, now
from utils.helpers import fmt, get_level

logger = logging.getLogger(__name__)

PAGE_SIZE = 15

_NAME = "COALESCE(NULLIF(u.full_name,''), NULLIF(u.username,''), 'Joueur#' || u.user_id)"
from utils.staff_scope import excluded_sql  # noqa: E402  (staff N2+ : ignoré par tous les classements)

_USER_OK = "u.registered=1 AND u.banned=0 AND " + excluded_sql("u.user_id")


# ─────────────────────────────────────────────────────────────────────────────
#  Définition d'un classement
# ─────────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Ranking:
    key: str
    emoji: str
    title: str
    desc: str
    kind: str                      # 'user' | 'company' | 'gang'
    source: str                    # SELECT id, name, value, extra, extra2 FROM … (sans ORDER BY)
    fmt: Callable[[object, object, object], str]          # (value, extra, extra2) → texte
    order: str = "value DESC, name COLLATE NOCASE ASC, id ASC"
    dynamic: Callable[[], Awaitable[tuple[str, tuple] | None]] | None = None   # source calculée (compétition)


def _f_money(v, e, e2) -> str:
    return fmt(v)


def _f_xp(v, e, e2) -> str:
    return f"{int(v):,} XP · niv. {get_level(int(v))}".replace(",", " ")


def _f_karma(v, e, e2) -> str:
    return f"{int(v):+d}"


def _f_pts(v, e, e2) -> str:
    return f"{int(v):,} pts".replace(",", " ")


def _f_arena(v, e, e2) -> str:
    wins, losses = int(v), int(e or 0)
    wr = int(wins / max(1, wins + losses) * 100)
    return f"{wins}V/{losses}D ({wr} %)"


def _f_followers(v, e, e2) -> str:
    return f"{int(v):,} abonnés".replace(",", " ")


def _f_missions(v, e, e2) -> str:
    return f"{int(v):,} missions".replace(",", " ")


def _f_job(v, e, e2) -> str:
    from config_chain import job_rank_name
    rank = int(v)
    if rank <= 0:
        return "sans métier"
    return f"{e or '?'} · {job_rank_name(rank)} · {int(e2 or 0)} missions"


def _f_supply(v, e, e2) -> str:
    return f"{fmt(v)} · {int(e or 0):,} biens livrés".replace(",", " ")


def _f_company_value(v, e, e2) -> str:
    return f"{fmt(v)} · {e} · 👥 {int(e2 or 0)}"


def _f_company_stage(v, e, e2) -> str:
    from config_chain import stage_name
    return f"{stage_name(int(v))} · {e} · {int(e2 or 0):,} XP".replace(",", " ")


def _f_units(v, e, e2) -> str:
    return f"{int(v):,} unités · {e}".replace(",", " ")


def _f_revenue(v, e, e2) -> str:
    return f"{fmt(v)} · {e}"


def _f_gang(v, e, e2) -> str:
    return f"⭐ {int(v)} · 💰 {fmt(e or 0)} · 👥 {int(e2 or 0)}"


def _user_source(value_sql: str, extra_sql: str = "0", extra2_sql: str = "0", where: str = "", joins: str = "") -> str:
    return (f"SELECT u.user_id AS id, {_NAME} AS name, {value_sql} AS value, "
            f"{extra_sql} AS extra, {extra2_sql} AS extra2 FROM users u {joins} "
            f"WHERE {_USER_OK}{(' AND ' + where) if where else ''}")




RANKINGS: dict[str, Ranking] = {}


def _reg(r: Ranking) -> None:
    RANKINGS[r.key] = r


# ── Joueurs ──────────────────────────────────────────────────────────────────
_reg(Ranking("richesse", "💰", "Les plus riches", "Fortune en liquide.", "user",
             _user_source("u.balance"), _f_money))
_reg(Ranking("xp", "⭐", "Niveau & XP", "Les plus expérimentés.", "user",
             _user_source("u.xp"), _f_xp))
_reg(Ranking("karma", "😇", "Karma", "Du plus vertueux au plus sombre.", "user",
             _user_source("u.karma"), _f_karma))
_reg(Ranking("prestige", "👑", "Prestige", "Les plus prestigieux.", "user",
             _user_source("u.prestige"), _f_pts))
_reg(Ranking("gains", "💼", "Revenus cumulés", "Tout l'argent gagné depuis le début.", "user",
             _user_source("u.total_earned"), _f_money))
_reg(Ranking("arene", "⚔️", "Arène", "Les meilleurs combattants (victoires).", "user",
             _user_source("u.arena_wins", "u.arena_losses"), _f_arena,
             order="value DESC, extra ASC, name COLLATE NOCASE ASC, id ASC"))
_reg(Ranking("social", "🌐", "Influenceurs", "Les plus suivis.", "user",
             _user_source("u.social_followers"), _f_followers))
_reg(Ranking("missions", "🎯", "Missions accomplies", "Les plus actifs.", "user",
             _user_source("u.missions_done"), _f_missions))
_reg(Ranking("metier", "🛠️", "Maîtres de métier", "Rang dans ton métier, puis nombre de missions.", "user",
             _user_source("COALESCE(jp.rank,0)", "u.job", "COALESCE(jp.missions,0)",
                          joins="LEFT JOIN job_progress jp ON jp.user_id=u.user_id AND jp.job=u.job"),
             _f_job, order="value DESC, extra2 DESC, name COLLATE NOCASE ASC, id ASC"))
_reg(Ranking("fournisseurs", "📦", "Meilleurs fournisseurs", "Valeur des biens livrés aux entreprises.", "user",
             _user_source("COALESCE(cs.supply_value,0)", "COALESCE(cs.goods_supplied,0)",
                          joins="LEFT JOIN user_chain_stats cs ON cs.user_id=u.user_id"),
             _f_supply))

# ── Entreprises ──────────────────────────────────────────────────────────────
_CO_BASE = ("SELECT c.company_id AS id, c.name AS name, {value} AS value, {extra} AS extra, {extra2} AS extra2 "
            "FROM companies c LEFT JOIN company_chain ch ON ch.company_id=c.company_id "
            "WHERE c.dissolved=0 AND " + excluded_sql("COALESCE(c.owner_id,0)"))
_reg(Ranking("entreprises", "🏢", "Entreprises les plus riches", "Trésorerie.", "company",
             _CO_BASE.format(value="c.treasury", extra="c.sector",
                             extra2="(SELECT COUNT(*) FROM company_members m WHERE m.company_id=c.company_id)"),
             _f_company_value))
_reg(Ranking("grandes", "🏭", "Plus grandes entreprises", "Du stade et de l'expérience.", "company",
             _CO_BASE.format(value="MAX(1, MIN(7, c.level))", extra="c.sector", extra2="COALESCE(ch.xp,0)"),
             _f_company_stage, order="value DESC, extra2 DESC, name COLLATE NOCASE ASC, id ASC"))
_reg(Ranking("production", "📈", "Production totale", "Unités de produits finis fabriquées.", "company",
             _CO_BASE.format(value="COALESCE(ch.produced_total,0)", extra="c.sector", extra2="0"),
             _f_units))
_reg(Ranking("chiffre", "💶", "Chiffre d'affaires", "Ventes cumulées de l'entreprise.", "company",
             _CO_BASE.format(value="COALESCE(ch.revenue_total,0)", extra="c.sector", extra2="0"),
             _f_revenue))

# ── Gangs ────────────────────────────────────────────────────────────────────
_reg(Ranking("gangs", "🏴‍☠️", "Gangs", "Réputation, puis trésorerie.", "gang",
             "SELECT g.gang_id AS id, g.name AS name, g.reputation AS value, g.treasury AS extra, "
             "(SELECT COUNT(*) FROM gang_members gm WHERE gm.gang_id=g.gang_id) AS extra2 FROM gangs g "
             "WHERE " + excluded_sql("COALESCE(g.founder_id,0)"),
             _f_gang, order="value DESC, extra DESC, name COLLATE NOCASE ASC, id ASC"))

# Ordre d'affichage du menu : (titre de rubrique, [clés])
GROUPS: list[tuple[str, list[str]]] = [
    ("👤 Joueurs", ["richesse", "xp", "karma", "prestige", "gains", "missions", "social", "arene"]),
    ("🛠️ Métiers & commerce", ["metier", "fournisseurs"]),
    ("🏢 Entreprises", ["entreprises", "grandes", "production", "chiffre"]),
    ("🏴‍☠️ Gangs", ["gangs"]),
]

# Anciens noms de commandes / callbacks → clé de classement
ALIASES = {"leaderboard": "richesse", "topxp": "xp", "classementprestige": "prestige",
           "classement_arene": "arene", "classement_social": "social", "classement_boites": "entreprises",
           "gangclassement": "gangs", "g_classement": "gangs"}


# ─────────────────────────────────────────────────────────────────────────────
#  Requêtes
# ─────────────────────────────────────────────────────────────────────────────
async def _resolve(r: Ranking) -> tuple[str, tuple] | None:
    if r.dynamic is not None:
        return await r.dynamic()
    return r.source, ()


def _ranked_sql(src: str, order: str) -> str:
    return (f"SELECT id, name, value, extra, extra2, "
            f"ROW_NUMBER() OVER (ORDER BY {order}) AS rk, COUNT(*) OVER () AS total FROM ({src})")


async def my_entity_id(r: Ranking, user_id: int) -> int | None:
    """Identifiant, dans ce classement, de ce que le joueur « est » : lui-même, son entreprise ou son gang."""
    if r.kind == "user":
        return user_id
    sql = {"company": "SELECT cm.company_id FROM company_members cm JOIN companies c ON c.company_id=cm.company_id "
                      "WHERE cm.user_id=? AND c.dissolved=0",
           "gang": "SELECT gang_id FROM gang_members WHERE user_id=?"}[r.kind]
    async with db_read() as db:
        async with db.execute(sql, (user_id,)) as cur:
            row = await cur.fetchone()
    return int(row[0]) if row else None


async def get_page(key: str, page: int, user_id: int | None = None, per_page: int = PAGE_SIZE) -> dict:
    """Une page du classement `key`. Retourne :
    {key, title, emoji, rows:[{rank,id,name,text,is_me}], total, page, pages, me:{rank,text,page}|None}"""
    r = RANKINGS[key]
    out = {"key": key, "title": r.title, "emoji": r.emoji, "desc": r.desc, "rows": [], "total": 0,
           "page": 1, "pages": 1, "me": None, "kind": r.kind}
    res = await _resolve(r)
    if res is None:
        return out
    src, params = res
    ranked = _ranked_sql(src, r.order)
    me_id = await my_entity_id(r, user_id) if user_id else None
    try:
        async with db_read(row_factory=aiosqlite.Row) as db:
            async with db.execute(f"SELECT COUNT(*) FROM ({src})", params) as cur:
                total = int((await cur.fetchone())[0])
            pages = max(1, -(-total // per_page))
            page = max(1, min(int(page), pages))
            lo, hi = (page - 1) * per_page + 1, page * per_page
            async with db.execute(f"SELECT * FROM ({ranked}) WHERE rk BETWEEN ? AND ? ORDER BY rk",
                                  (*params, lo, hi)) as cur:
                rows = [dict(x) for x in await cur.fetchall()]
            me = None
            if me_id is not None:
                async with db.execute(f"SELECT * FROM ({ranked}) WHERE id=?", (*params, me_id)) as cur:
                    row = await cur.fetchone()
                if row:
                    me = dict(row)
    except aiosqlite.OperationalError:
        logger.exception("Classement %s indisponible", key)
        return out
    out.update(total=total, page=page, pages=pages)
    for x in rows:
        out["rows"].append({"rank": x["rk"], "id": x["id"], "name": x["name"],
                            "text": r.fmt(x["value"], x["extra"], x["extra2"]),
                            "is_me": me_id is not None and x["id"] == me_id})
    if me:
        out["me"] = {"rank": me["rk"], "name": me["name"], "text": r.fmt(me["value"], me["extra"], me["extra2"]),
                     "page": -(-me["rk"] // per_page)}
    return out


async def my_position(key: str, user_id: int, per_page: int = PAGE_SIZE) -> dict | None:
    """Rang du joueur (ou de son entreprise / gang) : {rank,total,text,page} ou None s'il n'est pas classé."""
    p = await get_page(key, 1, user_id, per_page)
    if not p["me"]:
        return None
    return {**p["me"], "total": p["total"]}


# ─────────────────────────────────────────────────────────────────────────────
#  Mise en forme (texte HTML Telegram)
# ─────────────────────────────────────────────────────────────────────────────
MEDALS = {1: "🥇", 2: "🥈", 3: "🥉"}


def render_page(p: dict) -> str:
    """Texte HTML d'une page de classement (≈ 15 lignes : bien sous la limite de 4096 caractères)."""
    r = RANKINGS[p["key"]]
    lines = [f"{p['emoji']} <b>{html.escape(p['title'])}</b>", f"<i>{html.escape(p['desc'])}</i>", ""]
    if not p["rows"]:
        lines.append("📭 Aucun classement pour le moment.")
        return "\n".join(lines)
    for x in p["rows"]:
        medal = MEDALS.get(x["rank"], f"<b>{x['rank']}.</b>")
        name = html.escape(str(x["name"]))
        if x["is_me"]:
            lines.append(f"👉 {medal} <b>{name}</b> (toi) — {html.escape(x['text'])}")
        else:
            lines.append(f"{medal} {name} — {html.escape(x['text'])}")
    lines.append("")
    lines.append(f"📄 Page {p['page']}/{p['pages']} · {p['total']} classés")
    me = p["me"]
    if me:
        if not any(x["is_me"] for x in p["rows"]):
            who = {"user": "Ton rang", "company": "Ton entreprise", "gang": "Ton gang"}[r.kind]
            lines.append(f"📍 <b>{who} : #{me['rank']}</b> sur {p['total']} — {html.escape(me['text'])}")
    elif r.kind != "user":
        lines.append("📍 Tu n'as " + ("pas d'entreprise." if r.kind == "company" else "pas de gang."))
    else:
        lines.append("📍 Tu n'es pas encore classé ici.")
    return "\n".join(lines)
