# utils/vip.py
"""
Helpers centraux pour les abonnements VIP/Premium et les boosts Étoiles.

FONCTIONS :
  • get_tier()                  — détecte le tier actif
  • income_multiplier()         — bonus de revenus
  • cooldown_multiplier()       — réduction de cooldowns
  • casino_bonus()              — bonus de gains au casino
  • tax_reduction()             — réduction d'impôts
  • social_bonus()              — bonus de followers
  • has_boost()                 — vérifie si un boost est actif
  • xp_boost_multiplier()       — multiplicateur XP
  • coins_boost_multiplier()    — multiplicateur Coins
  • chance_boost_bonus()        — bonus de chance (+15%)
  • garden_growth_multiplier()  — multiplicateur jardin (x3)
  • travel_time_multiplier()    — multiplicateur vitesse voyage (-50%)
  • max_garden_plots()          — limite parcelles
  • max_properties()            — limite propriétés
  • max_vehicles()              — limite véhicules
  • max_inventory_slots()       — limite inventaire (obsolète)
  • extra_casino_spins()        — relances casino (obsolète)
  • effective_cooldown()        — cooldown effectif (avec VIP + work bonus)
  • status_label()              — label du statut VIP

  ⭐ NOUVEAU :
  • add_xp()                    — ajoute XP avec boost appliqué automatiquement
  • add_coins()                 — ajoute coins avec boost appliqué automatiquement
"""
from utils.swallow import swallowed
from utils.gametime import real_now as now   # abonnements/boosts payants : jours RÉELS
from config import VIP_TIER_BONUSES


# ═══════════════════════════════════════════════════════════════════
#                    DÉTECTION DU TIER VIP
# ═══════════════════════════════════════════════════════════════════

def get_tier(u: dict) -> str:
    """Retourne 'premium', 'vip' ou 'none' selon les abonnements actifs."""
    t = now()
    if u.get("premium_until", 0) and u["premium_until"] > t:
        return "premium"
    if u.get("vip_until", 0) and u["vip_until"] > t:
        return "vip"
    return "none"


def _bonuses(u: dict) -> dict:
    return VIP_TIER_BONUSES[get_tier(u)]


# ═══════════════════════════════════════════════════════════════════
#                    BONUS VIP/PREMIUM
# ═══════════════════════════════════════════════════════════════════

def income_multiplier(u: dict) -> float:
    """Bonus sur le menu et le menu (+10% VIP / +25% Premium)."""
    return _bonuses(u)["income_mult"]


def cooldown_multiplier(u: dict) -> float:
    """Réduction de cooldowns (-15% VIP / -30% Premium)."""
    return _bonuses(u)["cooldown_mult"]


def casino_bonus(u: dict) -> float:
    """Bonus de gains casino (+5% VIP / +10% Premium)."""
    return _bonuses(u)["casino_bonus"]


def tax_reduction(u: dict) -> float:
    """Réduction d'impôts (-5% VIP / -15% Premium)."""
    return _bonuses(u)["tax_reduction"]


def social_bonus(u: dict) -> float:
    """Bonus de followers (+10% VIP / +25% Premium)."""
    return _bonuses(u)["social_bonus"]


# ═══════════════════════════════════════════════════════════════════
#                    BOOSTS TEMPORAIRES
# ═══════════════════════════════════════════════════════════════════

def has_boost(u: dict, field: str) -> bool:
    """Vérifie si un boost temporaire (ex: boost_xp2_until) est actif."""
    return bool(u.get(field, 0)) and u[field] > now()


def xp_boost_multiplier(u: dict) -> float:
    """Multiplicateur d'XP : 2.0 si boost actif, sinon 1.0."""
    return 2.0 if has_boost(u, "boost_xp2_until") else 1.0


def coins_boost_multiplier(u: dict) -> float:
    """Multiplicateur de Coins : 2.0 si boost actif, sinon 1.0."""
    return 2.0 if has_boost(u, "boost_coins2_until") else 1.0


def chance_boost_bonus(u: dict) -> float:
    """+15% de succès (crime, hack, casino) si le boost est actif."""
    return 0.15 if has_boost(u, "boost_chance_until") else 0.0


def garden_growth_multiplier(u: dict) -> float:
    """x3 sur la vitesse de croissance du jardin si boost actif."""
    return 3.0 if has_boost(u, "boost_jardin_until") else 1.0


def travel_time_multiplier(u: dict) -> float:
    """x0.5 sur la durée des voyages si boost actif."""
    return 0.5 if has_boost(u, "boost_vitesse_until") else 1.0


# ═══════════════════════════════════════════════════════════════════
#                    LIMITES (stacks permanents)
# ═══════════════════════════════════════════════════════════════════

def max_garden_plots(u: dict, base: int) -> int:
    """Retourne la limite de parcelles de jardin (base + bonus VIP)."""
    return base + (u.get("extra_garden_plots", 0) or 0)


def max_properties(u: dict, base: int) -> int:
    """Retourne la limite de propriétés (base + bonus VIP)."""
    return base + (u.get("extra_properties", 0) or 0)


def max_vehicles(u: dict, base: int) -> int:
    """Retourne la limite de véhicules (base + bonus VIP)."""
    return base + (u.get("extra_vehicles", 0) or 0)


def max_inventory_slots(u: dict, base: int) -> int:
    """Note : pas utilisé actuellement (pas de limite d'inventaire en jeu)."""
    return base + (u.get("extra_inventory_slots", 0) or 0)


def extra_casino_spins(u: dict) -> int:
    """Note : pas utilisé actuellement (pas de limite de spins casino)."""
    return u.get("extra_casino_spins", 0) or 0


# ═══════════════════════════════════════════════════════════════════
#                    COOLDOWN EFFECTIF
# ═══════════════════════════════════════════════════════════════════

def effective_cooldown(u: dict, base_seconds: int, work: bool = False) -> int:
    """
    Durée de cooldown effective en tenant compte :
      • Du bonus VIP/Premium (cooldown_multiplier)
      • Du rachat permanent '-1h cooldown travail' (uniquement pour /travailler)

    Args:
        u: dict utilisateur
        base_seconds: cooldown de base en secondes
        work: True si c'est le cooldown de /travailler (applique extra_work_cd_reduction)
    """
    seconds = int(base_seconds * cooldown_multiplier(u))
    if work:
        seconds = max(0, seconds - (u.get("extra_work_cd_reduction", 0) or 0))
    return max(0, seconds)


# ═══════════════════════════════════════════════════════════════════
#                    LABEL DE STATUT
# ═══════════════════════════════════════════════════════════════════

def status_label(u: dict) -> str:
    """Retourne le label lisible du tier VIP actif."""
    tier = get_tier(u)
    if tier == "premium":
        return "👑 PREMIUM"
    if tier == "vip":
        return "🎖 VIP"
    return "Aucun abonnement actif"


# ═══════════════════════════════════════════════════════════════════
#     ⭐ FONCTIONS CENTRALISÉES POUR GAINS XP & COINS (NOUVEAU)
#        → Appliquent automatiquement les boosts VIP actifs
# ═══════════════════════════════════════════════════════════════════

async def add_xp(user_id: int, base_amount: int) -> int:
    """
    Ajoute de l'XP en appliquant automatiquement le boost x2 si actif.

    À utiliser PARTOUT à la place de :
        await increment_field(user_id, "xp", N)

    Args:
        user_id: ID du joueur
        base_amount: XP de base (avant boost)

    Returns:
        Le montant final d'XP appliqué (avec boost)
    """
    if base_amount <= 0:
        return 0

    # Import tardif pour éviter les boucles circulaires
    from database import get_user, increment_field

    final = base_amount
    old_xp = 0
    try:
        u = await get_user(user_id)
        old_xp = int(u.get("xp", 0) or 0)
        final = int(base_amount * xp_boost_multiplier(u))
    except Exception:
        # En cas d'erreur (user inexistant), on applique sans boost
        swallowed('utils/vip.py')

    await increment_field(user_id, "xp", final)

    from utils.progress_notify import check_level_up      # 🔔 prévient le joueur s'il monte de niveau
    await check_level_up(user_id, old_xp)

    return final


async def add_coins(user_id: int, base_amount: int) -> int:
    """
    Ajoute des coins en appliquant automatiquement le boost x2 si actif.

    À utiliser PARTOUT à la place de :
        await update_balance(user_id, N)  # si N > 0

    Args:
        user_id: ID du joueur
        base_amount: Coins de base (avant boost)

    Returns:
        Le montant final de coins appliqué (avec boost)
    """
    if base_amount <= 0:
        return 0

    # Import tardif pour éviter les boucles circulaires
    from database import get_user, update_balance

    final = base_amount
    try:
        u = await get_user(user_id)
        final = int(base_amount * coins_boost_multiplier(u))
    except Exception:
        # En cas d'erreur (user inexistant), on applique sans boost
        swallowed('utils/vip.py')

    await update_balance(user_id, final)
    return final


# ═══════════════════════════════════════════════════════════════════
#                    EXPORTS
# ═══════════════════════════════════════════════════════════════════

__all__ = [
    # Tier & statut
    "get_tier", "status_label",
    # Bonus VIP/Premium
    "income_multiplier", "cooldown_multiplier", "casino_bonus",
    "tax_reduction", "social_bonus",
    # Boosts temporaires
    "has_boost", "xp_boost_multiplier", "coins_boost_multiplier",
    "chance_boost_bonus", "garden_growth_multiplier", "travel_time_multiplier",
    # Limites (stacks)
    "max_garden_plots", "max_properties", "max_vehicles",
    "max_inventory_slots", "extra_casino_spins",
    # Cooldown
    "effective_cooldown",
    # ⭐ Nouveau : gains XP & Coins centralisés
    "add_xp", "add_coins",
]