# utils/courses.py — 📚 Cours à réviser et examen par questions
"""
RÉVISER = recevoir un COURS (une leçon) à apprendre ; EXAMEN = répondre à des QUESTIONS sur les cours révisés.
Les cours servent à connaître le jeu (économie, crimes, justice, factions, entreprises, politique…) et à comprendre
l'importance du diplôme : la première leçon d'une formation présente ce que le diplôme ouvre (métiers qui l'exigent,
bonus de salaire). Les chiffres des cours sont lus dans la config : ils restent exacts quand tu rééquilibres.
"""
import json
import math
import random

import aiosqlite

from config import HOUSING_EVICT_AFTER, SOCIAL_PLATFORMS
from config_chain import JOB_RANKS, GRANDE_COMMANDE_RANK
from config import (
    JOBS, ORDRE, JUSTICE, WEAPON_MAX_MAGS, ANTI_HACK_PLANS, ORDRE_PLAYER_CRIMES, ELECTED_POSTS,
)
from database import db_connection, now
from utils import reseau_rules as RR

MAX_REVISIONS = 5
PASS_RATIO = (0.6, 0.7, 0.8)          # note minimale par palier de diplôme (bas → haut)
QUESTIONS_PER_LESSON = (1, 1, 2)      # questions par cours révisé selon le palier
MAX_QUESTIONS = 10


# ─────────────────────────────────────────────────────────────────────────────
#  Catalogue des cours
# ─────────────────────────────────────────────────────────────────────────────
def _q(question: str, correct: str, *wrong: str, why: str = "") -> dict:
    return {"q": question, "right": correct, "wrong": list(wrong), "why": why}


def _min(n: int) -> str:
    return f"{n // 60} min"


def catalog() -> dict[str, dict]:
    """Cours généraux (indépendants du diplôme) : {id: {theme, title, level, text, questions}}."""
    pw = ANTI_HACK_PLANS["pare_feu"]
    fr = ORDRE_PLAYER_CRIMES
    L: list[dict] = [
        dict(id="eco1", theme="💰 Économie", title="Liquide ou banque ?", level=0,
             text=("Ton argent existe sous deux formes. Le <b>liquide</b> est dans ta poche : un voleur peut te le "
                   "prendre (vol à la tire). L'argent en <b>banque</b> est à l'abri du vol, mais un pirate peut le "
                   f"siphonner. Seule une défense protège ton compte : le <b>{pw['name']}</b> ({pw['cost']:,}, "
                   f"{pw['days']} jours de jeu)."),
             questions=[_q("Quel argent un voleur à la tire peut-il te prendre ?", "Ton argent liquide",
                           "Ton compte en banque", "Ton salaire futur", "Rien du tout", why="Le vol vise le liquide."),
                        _q("Qu'est-ce qui protège ton compte bancaire des pirates ?", f"Le {pw['name']}",
                           "Un casque de chantier", "Un diplôme", "Un avocat", why="Une seule défense existe : le pare-feu.")]),
        dict(id="eco2", theme="💰 Économie", title="Le salaire et le diplôme", level=0,
             text=("Chaque métier a une fourchette de salaire. Ton <b>diplôme</b> multiplie ce salaire (bonus de salaire) "
                   "et débloque des métiers : sans le diplôme requis, impossible d'occuper le poste. "
                   "Un diplôme se mérite : cours à réviser puis examen."),
             questions=[_q("À quoi sert surtout un diplôme ?", "Débloquer des métiers et augmenter le salaire",
                           "Voler plus facilement", "Éviter la prison", "Gagner des munitions"),
                        _q("Que se passe-t-il si tu n'as pas le diplôme requis d'un métier ?", "Tu ne peux pas l'exercer",
                           "Tu es payé le double", "Tu deviens juge", "Rien, tu y vas quand même")]),
        dict(id="life1", theme="❤️ Vie", title="Énergie et stress", level=0,
             text=("Étudier fatigue : <b>réviser coûte 15 d'énergie</b> et ajoute du stress. Quand tu es trop fatigué, "
                   "repose-toi avant de continuer. Le stress monte aussi après un échec à l'examen."),
             questions=[_q("Combien d'énergie coûte une révision ?", "15", "5", "50", "Aucune"),
                        _q("Que faire quand tu es trop fatigué pour réviser ?", "Te reposer d'abord",
                           "Continuer quand même", "Passer l'examen", "Changer de ville")]),
        dict(id="crime1", theme="🚨 Crimes", title="Crimes, fuite et enquête", level=0,
             text=("Un crime sur le bot qui <b>réussit</b> te rapporte un butin, mais la police ouvrira une enquête "
                   f"après un délai : les enquêteurs doivent réussir un mini-jeu de mémoire. Un crime qui "
                   f"<b>échoue</b> t'envoie directement en prison ({_min(ORDRE['jail_bot'][0])} à "
                   f"{_min(ORDRE['jail_bot'][1])}). Tu peux te cacher pour retarder l'enquête."),
             questions=[_q("Que se passe-t-il quand un crime sur le bot échoue ?", "Tu vas directement en prison",
                           "Tu gagnes quand même le butin", "La police te verse un salaire", "Rien"),
                        _q("Comment la police peut-elle t'arrêter après un crime réussi ?", "En réussissant son enquête (mini-jeu)",
                           "En tirant au sort", "Elle ne le peut pas", "En te téléphonant")]),
        dict(id="crime2", theme="🚨 Crimes", title="Crimes sur les joueurs", level=1,
             text=(f"Les membres d'un gang peuvent viser des joueurs : <b>{fr['vol']['name']}</b> (liquide), "
                   f"<b>{fr['hack']['name']}</b> (compte en banque, compétence Technique) et "
                   f"<b>{fr['meurtre']['name']}</b> (exige une arme à feu). Réussir alerte la police ; si le gouvernement "
                   "est concerné, l'armée aussi."),
             questions=[_q("Quel crime sur joueur exige une arme à feu ?", fr["meurtre"]["name"], fr["vol"]["name"],
                           fr["hack"]["name"], "Aucun"),
                        _q("Qui est alerté quand un crime touche un membre du gouvernement ?", "La police et l'armée",
                           "Seulement les juges", "Personne", "Les avocats")]),
        dict(id="karma1", theme="🚨 Crimes", title="Le karma", level=0,
             text=("Le <b>karma</b> mesure ta réputation. Les crimes le font baisser. Un bon karma te rend plus difficile "
                   "à retrouver pour les enquêteurs ; un faux signalement fait aussi baisser ton karma."),
             questions=[_q("Qu'est-ce qui fait baisser le karma ?", "Les crimes", "Réviser", "Dormir", "Payer ses impôts"),
                        _q("Un bon karma rend les enquêteurs…", "Moins efficaces pour te retrouver",
                           "Plus efficaces", "Aveugles à tout", "Jaloux")]),
        dict(id="weap1", theme="🔫 Armes", title="Marché noir et munitions", level=1,
             text=("Le marché noir ne vend plus que des <b>armes</b>, avec des <b>munitions limitées</b> "
                   f"(maximum {WEAPON_MAX_MAGS} chargeurs par arme). Racheter la même arme ajoute des munitions. "
                   "Une arme équipée augmente tes chances de crime mais chaque usage consomme des munitions. "
                   "Braquage et Hold-up exigent une arme à feu."),
             questions=[_q("Que vend le marché noir ?", "Des armes et leurs munitions", "Des diplômes", "Des médicaments", "Des maisons"),
                        _q("Que consomme chaque usage d'une arme ?", "Des munitions", "Du karma", "Un diplôme", "De la santé")]),
        dict(id="weap2", theme="🔫 Armes", title="Armée, police et armes", level=1,
             text=("Les <b>armuriers de l'armée</b> fabriquent armes et munitions (payées par le coffre de l'armée). "
                   "Tout militaire peut prendre une arme dans la chambre d'armes. La police a aussi sa chambre d'armes, "
                   "mais c'est <b>l'armée qui lui livre</b> ses armes."),
             questions=[_q("Qui fabrique les armes officielles ?", "Les armuriers de l'armée", "Les juges", "Les infirmiers", "Les avocats"),
                        _q("Qui fournit la chambre d'armes de la police ?", "L'armée", "Le marché noir", "La mairie", "Les entreprises")]),
        dict(id="pol1", theme="🚓 Ordre public", title="Les pouvoirs de la police", level=1,
             text=(f"Un agent en service peut <b>neutraliser</b> un joueur ({ORDRE['stun_seconds']} s), le "
                   f"<b>menotter</b> (seulement {ORDRE['cuffs_max']} paires de menottes à la fois), l'amener en salle "
                   f"d'interrogatoire puis l'<b>emprisonner</b> (maximum {_min(ORDRE['jail_max'])}) ou le libérer. "
                   "Toute arrestation ouvre un dossier à la Justice."),
             questions=[_q("Combien de joueurs un agent peut-il menotter en même temps ?", str(ORDRE["cuffs_max"]),
                           str(ORDRE["cuffs_max"] + 2), "1", "10"),
                        _q("Quelle peine maximale la police peut-elle infliger ?", _min(ORDRE["jail_max"]),
                           "5 min", "3 jours", "À vie")]),
        dict(id="jus1", theme="⚖️ Justice", title="Juges et avocats", level=1,
             text=("La Justice a deux postes : le <b>juge</b> et l'<b>avocat</b>. Le juge fixe la <b>caution</b>, juge "
                   f"l'affaire (acquittement, amende, prison jusqu'à {JUSTICE['sentence_max'] // 3600} h) et peut délivrer "
                   f"un <b>mandat d'arrêt</b>. L'avocat plaide : une plaidoirie réussie réduit la caution et la peine "
                   f"de {int(JUSTICE['plead_reduction'] * 100)} %."),
             questions=[_q("Qui fixe la caution ?", "Le juge", "L'avocat", "Le médecin", "Le soldat"),
                        _q("De combien une plaidoirie réussie réduit-elle la peine ?", f"{int(JUSTICE['plead_reduction'] * 100)} %",
                           "5 %", "90 %", "0 %")]),
        dict(id="fac1", theme="🎖️ Factions", title="Les factions de l'État", level=0,
             text=("L'État compte la <b>police</b>, l'<b>armée</b>, la <b>justice</b>, la <b>santé</b> et l'<b>Administration</b>. "
                   "Leurs membres sont payés par le <b>coffre de leur faction</b>, par heure de jeu. On y entre par "
                   "candidature puis <b>entretien d'embauche</b> avec la direction."),
             questions=[_q("Qui paie le salaire des membres d'une faction ?", "Le coffre de la faction", "Le marché noir", "Les joueurs un par un", "Personne"),
                        _q("Comment entre-t-on dans une faction ?", "Candidature puis entretien", "En achetant un badge",
                           "Au hasard", "Par un crime")]),
        dict(id="fac2", theme="🎖️ Factions", title="Hiérarchie et chats", level=1,
             text=("Chaque membre voit la <b>hiérarchie</b> de sa faction ou entreprise (nom, pseudo, ID, poste). Seule la "
                   "direction (DG, PDG) voit aussi l'<b>activité</b> des employés. Les chats d'équipe relaient tes messages "
                   "via le bot, avec ton nom et ton poste ; un chat commun réunit tout le gouvernement."),
             questions=[_q("Qui voit l'activité des employés ?", "La direction (DG / PDG)", "Tout le monde", "Les inconnus", "Personne"),
                        _q("Que voit-on devant un message de chat d'équipe ?", "Le nom et le poste de l'expéditeur",
                           "Rien", "Son numéro de téléphone", "Son mot de passe")]),
        dict(id="biz1", theme="🏢 Entreprises", title="Créer et diriger une entreprise", level=1,
             text=("Une entreprise a un <b>PDG</b> (le fondateur), des postes et des employés. Les postes de direction "
                   "(MBA : Manager, Directeur, PDG) exigent un haut diplôme. Le PDG consulte l'activité de ses employés "
                   "et peut discuter avec eux dans le chat de l'entreprise."),
             questions=[_q("Qui est le PDG d'une entreprise ?", "Son fondateur", "Un inconnu tiré au sort", "Le juge", "Le président"),
                        _q("Quel diplôme ouvre les postes de PDG et de Directeur ?", "Le MBA", "Le Brevet", "Aucun", "Le BTS")]),
        dict(id="pol2", theme="🏛️ Politique", title="Élections et pouvoir", level=2,
             text=("La politique est réservée aux <b>Admins N1</b> : ils se présentent aux élections. Les "
                   f"<b>joueurs votent</b>. Seul le poste de <b>{', '.join(ELECTED_POSTS)}</b> est élu ; le président "
                   "prend la tête de l'<b>Administration</b> et nomme les <b>ministres</b> (un joueur ou un Admin N1). Chaque ministre est "
                   "un grade de l'Administration : il dirige une faction d'État (Intérieur → Police, Défense → Armée, Justice, "
                   "Santé) ou, pour l'Économie, règle l'impôt sur la fortune."),
             questions=[_q("Qui peut se présenter à la présidence ?", "Un Admin N1", "N'importe quel joueur", "Un juge", "Un soldat"),
                        _q("Qui vote pour le président ?", "Les joueurs", "Les armuriers seulement", "Le Game Leader seul", "Personne")]),
        dict(id="health1", theme="🏥 Santé", title="L'hôpital", level=1,
             text=("La faction <b>santé</b> a deux missions : <b>soigner</b> les joueurs et <b>produire des médicaments</b>. "
                   "Les médecins et infirmiers travaillent à l'hôpital, dirigé par un PDG et des DG ; ils recrutent par "
                   "entretien comme les autres factions."),
             questions=[_q("Quelles sont les deux missions de la santé ?", "Soigner et produire des médicaments",
                           "Arrêter et juger", "Voter et nommer", "Fabriquer des armes et les livrer"),
                        _q("Qui dirige un hôpital ?", "Un PDG ou un DG", "Un avocat", "Un soldat", "Un cadet")]),
        dict(id="net1", theme="🌐 Réseau RP", title="Publier sur le réseau", level=0,
             text=(f"Le Réseau RP est lu par les <b>autres joueurs</b>. Tu publies sur l'une des "
                   f"{len(SOCIAL_PLATFORMS)} plateformes (max {RR.POST_MAX} caractères) et tu peux ajouter des "
                   f"<b>#hashtags</b>. Une publication rapporte {RR.XP_POST} XP et de l'audience ; tu peux publier "
                   f"toutes les <b>{RR.POST_COOLDOWN_HOURS} h de jeu</b>."),
             questions=[_q("Qui lit tes publications du Réseau RP ?", "Les autres joueurs", "Seulement le bot",
                           "Personne", "Uniquement les admins"),
                        _q("À quoi servent les #hashtags ?", "À retrouver et classer les publications",
                           "À payer plus d'impôts", "À supprimer un post", "À rien")]),
        dict(id="net2", theme="🌐 Réseau RP", title="Likes, abonnés et modération", level=1,
             text=(f"Un <b>like</b> ne peut pas être donné à son propre post. Un <b>abonnement</b> est réel : "
                   f"chaque abonné te rapporte aussi {RR.FOLLOW_BONUS_FOLLOWERS} d'audience sociale. Tu peux "
                   f"écrire {RR.COMMENTS_PER_POST} commentaires par publication. Le staff peut <b>supprimer</b> un "
                   f"post ou te mettre en <b>sourdine {RR.MUTE_HOURS} h</b> : tu lis, mais tu ne publies plus."),
             questions=[_q("Combien de commentaires maximum par publication ?", str(RR.COMMENTS_PER_POST),
                           "1", "20", "Aucun"),
                        _q("Que se passe-t-il pendant une sourdine ?", "Tu peux lire mais plus publier",
                           "Ton compte est supprimé", "Tu gagnes le double", "Rien")]),
        dict(id="net4", theme="🌐 Réseau RP", title="Hashtags, communautés et sondages", level=1,
             text=("Un <b>#hashtag</b> classe ta publication : les <b>Tendances</b> montrent ceux dont on parle. "
                   "Chaque <b>communauté</b> a un hashtag officiel, un fil et des <b>sondages</b> réservés à ses "
                   "membres ; chaque joueur ne vote qu'une fois et gagne 1 SocialCoin. Un sondage dure 2 jours de jeu."),
             questions=[_q("Qui peut voter à un sondage de communauté ?", "Les membres de la communauté",
                           "Tout le monde, plusieurs fois", "Seulement le chef", "Personne"),
                        _q("Combien de fois peut-on voter à un même sondage ?", "Une fois", "Autant qu'on veut",
                           "Dix fois", "Jamais")]),
        dict(id="net3", theme="🌐 Réseau RP", title="Messages privés", level=0,
             text=(f"Les <b>messages privés</b> relient deux joueurs : le destinataire reçoit une notification. "
                   f"Maximum {RR.DM_MAX} caractères et {RR.DMS_PER_HOUR} messages par heure, pour éviter le spam. "
                   "Sers-t'en pour organiser un mariage, un clan, une entreprise ou un échange."),
             questions=[_q("Comment le destinataire est-il prévenu d'un message privé ?", "Par une notification",
                           "Il ne l'est jamais", "Par un appel du juge", "Par la police"),
                        _q("Pourquoi les messages sont-ils limités par heure ?", "Pour éviter le spam",
                           "Pour punir les joueurs", "Pour gagner de l'argent", "Par hasard")]),
        dict(id="fam3", theme="👪 Famille", title="Amis, mariage et adoption", level=0,
             text=("Les <b>amis</b> se choisissent depuis un profil. Le <b>mariage</b> se demande puis s'accepte ; "
                   "il se termine par un <b>divorce</b>. L'<b>adoption</b> agrandit ta lignée, visible dans "
                   "l'<b>arbre généalogique</b>. Ces liens servent au jeu de rôle et aux échanges entre proches."),
             questions=[_q("Comment un mariage commence-t-il ?", "Une demande, puis une acceptation",
                           "Par tirage au sort", "Automatiquement", "Par décision du juge"),
                        _q("Où voit-on sa lignée ?", "Dans l'arbre généalogique", "Au casino",
                           "Au marché noir", "Dans le garage")]),
        dict(id="fam4", theme="👪 Famille", title="Le clan", level=1,
             text=("Un <b>clan</b> a un chef et des membres. Le chef <b>invite</b>, peut <b>transférer</b> son titre "
                   "ou <b>dissoudre</b> le clan. Un membre peut le quitter à tout moment. Le clan est la base "
                   "d'une famille qui joue ensemble : entreprises, échanges et entraide."),
             questions=[_q("Qui peut dissoudre un clan ?", "Son chef", "N'importe quel passant", "Le premier venu",
                           "Un soldat"),
                        _q("Un membre peut-il quitter son clan ?", "Oui, à tout moment", "Jamais", "Seulement le lundi",
                           "Seulement avec un diplôme")]),
        dict(id="chain1", theme="🏭 Métiers", title="Des métiers aux entreprises", level=1,
             text=(f"Un <b>petit métier</b> te paie tout de suite et te donne des <b>biens</b> à vendre aux entreprises. "
                   f"Tu montes de rang ({', '.join(r[0] for r in JOB_RANKS)}). Dès le rang "
                   f"<b>{JOB_RANKS[GRANDE_COMMANDE_RANK - 1][0]}</b>, les grandes commandes s'ouvrent. Les entreprises "
                   "transforment ces biens en produits finis que les commerçants revendent."),
             questions=[_q("Que donne une mission de métier en plus de l'argent ?", "Des biens pour les entreprises",
                           "Un diplôme", "Une arme", "Un véhicule"),
                        _q("Qui transforme les biens en produits finis ?", "Les entreprises", "La police",
                           "Les juges", "Le bot seul")]),
        dict(id="market1", theme="🏪 Marché", title="Commerçants et revente", level=1,
             text=("Seuls les <b>commerçants</b> vendent sur le marché. Un civil qui possède un objet le revend "
                   "à un commerçant. Les entreprises vendent leurs produits finis en gros aux commerçants. "
                   "Le prix est fixé par l'offre et la demande entre joueurs."),
             questions=[_q("Qui peut vendre sur le marché ?", "Les commerçants", "Tout le monde sans exception",
                           "Uniquement les policiers", "Les juges"),
                        _q("À qui un civil revend-il un objet ?", "À un commerçant", "Au juge", "À l'armée",
                           "À personne")]),
        dict(id="house1", theme="🏠 Logement", title="Loyers et expulsion", level=0,
             text=(f"Un logement est <b>obligatoire</b> et ses frais sont toujours notifiés. Après "
                   f"<b>{HOUSING_EVICT_AFTER} jours</b> de loyer impayé, tu es expulsé : ton bail ou ta chambre est "
                   "perdu. Propriétaire, tu perçois les loyers de tes locataires."),
             questions=[_q("Après combien de jours impayés es-tu expulsé ?", str(HOUSING_EVICT_AFTER),
                           str(HOUSING_EVICT_AFTER + 10), "1 an", "Jamais"),
                        _q("Les frais de logement sont-ils notifiés ?", "Oui, toujours", "Jamais", "Une fois par an",
                           "Seulement pour les riches")]),
        dict(id="prog1", theme="📈 Progression", title="XP, niveau et tutoriel", level=0,
             text=("Tu gagnes de l'<b>XP</b> en travaillant, en étudiant, en publiant et en accomplissant des "
                   "missions. L'XP fait monter ton <b>niveau</b>. Le <b>tutoriel</b> compte 8 étapes, chacune avec "
                   "une récompense : économie, objets, multijoueur, réseau, liens et cours."),
             questions=[_q("Combien d'étapes compte le tutoriel ?", "8", "2", "30", "Aucune"),
                        _q("Qu'est-ce qui fait monter ton niveau ?", "L'XP", "Le karma seul", "La prison",
                           "Le hasard")]),
        dict(id="eco3", theme="💰 Économie", title="Qui crée l'argent ?", level=2,
             text=("Au début, le <b>bot</b> amorce l'économie : bonus, salaires, récompenses. À mesure que les "
                   "joueurs produisent et échangent, le staff <b>réduit puis coupe</b> ces sources. L'économie "
                   "repose alors sur la production des joueurs, et le bot ne récompense que l'essentiel."),
             questions=[_q("Qui règle ce que le bot donne encore ?", "Le staff", "Les joueurs un par un",
                           "Le hasard", "Les juges"),
                        _q("Que devient l'économie quand les joueurs produisent ?", "Elle repose sur eux",
                           "Elle s'arrête", "Elle disparaît", "Elle devient gratuite")]),
        dict(id="rp1", theme="🎭 Règles RP", title="Vivre son personnage", level=0,
             text=("Ici, on <b>vit</b> son personnage. Le <b>métagaming</b> (utiliser une information apprise hors du "
                   "jeu) et le <b>powergaming</b> (imposer une action à un autre joueur) sont interdits. Le fair-play "
                   "et la cohérence avec ton rôle font la qualité de l'histoire."),
             questions=[_q("Qu'est-ce que le métagaming ?", "Utiliser une information apprise hors du jeu",
                           "Jouer en équipe", "Gagner un duel", "Créer une entreprise"),
                        _q("Que faire si tu trouves un bug ?", "Le signaler au staff", "En profiter au maximum",
                           "Le cacher", "Quitter le jeu")]),
        dict(id="rp2", theme="🎭 Règles RP", title="Les chefs de faction", level=1,
             text=("Dans certaines factions, le <b>staff nomme le chef</b> après un <b>entretien RP</b>. Il regarde ton "
                   "parcours : faction, diplôme, compétences (Leadership, Négociation) et expérience en entreprise. "
                   "Un chef abusif ou absent peut être remplacé après sa période d'essai."),
             questions=[_q("Qui nomme les chefs de certaines factions ?", "Le staff, après un entretien",
                           "Le hasard", "Le premier arrivé", "Un joueur au choix"),
                        _q("Que peut-il arriver à un chef qui abuse ?", "Il peut être remplacé", "Il est récompensé",
                           "Rien", "Il devient président")]),
        dict(id="tres1", theme="🏛️ Administration", title="Le Trésor public", level=1,
             text=("Ce que les joueurs <b>dépensent envers le jeu</b> (études, casino, transports, état civil, "
                   "politique…) et l'<b>impôt sur la fortune</b> arrivent dans le <b>Trésor public</b>. Le Président et les "
                   "ministres le <b>redistribuent</b> aux coffres des factions (chaque ministre pour son ministère). "
                   "Une dotation ne peut pas dépasser la moitié du Trésor et chaque mouvement est journalisé."),
             questions=[_q("Qui redistribue le Trésor public ?", "Le Président et les ministres",
                           "N'importe quel joueur", "Les casinos", "Les juges seuls"),
                        _q("Que finance le Trésor public ?", "Les coffres des factions", "Les paris des joueurs",
                           "Les cadeaux entre amis", "Rien")]),
        dict(id="chain2", theme="🏭 Métiers", title="La production par heure", level=1,
             text=("Une entreprise produit <b>chaque heure de jeu</b> : plus besoin d'attendre la fin de la journée. "
                   "L'équipe <b>en service</b> gagne de l'activité en continu (1 point toutes les 10 minutes de jeu). "
                   "Le <b>bilan</b> arrive en fin de journée. Si rien ne sort, « 🔍 Pourquoi ça ne produit pas ? » "
                   "explique le blocage : personne en service, trésorerie ou intrants manquants."),
             questions=[_q("À quel rythme une entreprise produit-elle ?", "Chaque heure de jeu", "Une fois par an",
                           "Jamais", "Seulement sur ordre du bot"),
                        _q("Qu'est-ce qui permet de produire ?", "Une équipe en service et des intrants",
                           "Un simple clic", "Un diplôme seul", "La chance")]),
        dict(id="edu1", theme="🎓 Études", title="Comment fonctionne l'examen", level=0,
             text=(f"Après l'inscription, tu <b>révises</b> (maximum {MAX_REVISIONS} cours) pendant que le temps de formation "
                   "s'écoule. À la fin, l'<b>examen</b> pose des questions uniquement sur les cours que tu as révisés : "
                   "plus tu as révisé, plus tu es préparé. Un échec coûte un tiers du prix pour repasser."),
             questions=[_q("Sur quoi portent les questions de l'examen ?", "Sur les cours que tu as révisés", "Sur des sujets tirés au hasard",
                           "Sur ta fortune", "Sur ton karma"),
                        _q("Combien de cours peux-tu réviser par formation ?", str(MAX_REVISIONS), "1", "20", "Aucun")]),
    ]
    return {x["id"]: x for x in L}


def _diploma_lesson(dip: str) -> dict:
    """Cours propre au diplôme préparé : l'importance du diplôme (métiers débloqués, salaire)."""
    from config import DIPLOME_SALARY_BONUS, DIPLOME_SALARY_BONUS_EXTENDED
    ALL_SALARY_BONUS = {**DIPLOME_SALARY_BONUS, **DIPLOME_SALARY_BONUS_EXTENDED}
    jobs = [j for j, v in JOBS.items() if v.get("need") == dip]
    bonus = ALL_SALARY_BONUS.get(dip, 1.0)
    others = [j for j, v in JOBS.items() if v.get("need") != dip]
    text = (f"Le diplôme <b>{dip}</b> multiplie ton salaire par <b>×{bonus}</b>"
            + (f" et ouvre ces métiers : <b>{', '.join(jobs)}</b>." if jobs
               else ". Aucun métier ne l'exige à lui seul, mais il fait grimper ton salaire et ton prestige.")
            + " Sans diplôme, tu restes cantonné aux petits boulots.")
    questions = []
    if jobs:
        questions.append(_q(f"Quel métier exige le diplôme {dip} ?", random.choice(jobs),
                            *random.sample(others, min(3, len(others)))))
    all_bonus = sorted({v for v in ALL_SALARY_BONUS.values() if v != bonus})
    wrong = [f"×{b}" for b in random.sample(all_bonus, min(3, len(all_bonus)))]
    questions.append(_q(f"Quel bonus de salaire le {dip} apporte-t-il ?", f"×{bonus}", *wrong))
    return dict(id=f"dip:{dip}", theme="🎓 Ton diplôme", title=f"Pourquoi le {dip} compte", level=0,
                text=text, questions=questions)


def lesson(lesson_id: str) -> dict | None:
    if lesson_id.startswith("dip:"):
        return _diploma_lesson(lesson_id[4:])
    return catalog().get(lesson_id)


def tier_of(dip_index: int, total: int) -> int:
    return min(2, dip_index * 3 // max(1, total))


# ─────────────────────────────────────────────────────────────────────────────
#  Révisions
# ─────────────────────────────────────────────────────────────────────────────
async def seen_lessons(user_id: int, diplome: str) -> list[str]:
    async with db_connection() as db:
        async with db.execute("SELECT lesson_id FROM study_lessons WHERE user_id=? AND diplome=? ORDER BY seen_at, rowid",
                              (user_id, diplome)) as cur:
            return [r[0] for r in await cur.fetchall()]


async def library(user_id: int) -> list[tuple[str, str]]:
    """Tous les cours déjà lus (toutes formations) — consultables à tout moment."""
    async with db_connection() as db:
        async with db.execute("SELECT DISTINCT lesson_id, diplome FROM study_lessons WHERE user_id=? ORDER BY seen_at, rowid",
                              (user_id,)) as cur:
            return [(r[0], r[1]) for r in await cur.fetchall()]


async def reset(user_id: int, diplome: str) -> None:
    """Nouvelle inscription : on repart de zéro pour ce diplôme (cours et examen en cours)."""
    async with db_connection() as db:
        await db.execute("DELETE FROM study_lessons WHERE user_id=? AND diplome=?", (user_id, diplome))
        await db.execute("DELETE FROM study_exam WHERE user_id=?", (user_id,))
        await db.commit()


async def next_lesson(user_id: int, diplome: str, dip_index: int, total: int) -> dict:
    """Choisit le prochain cours à réviser : d'abord celui du diplôme (son importance), puis un cours de niveau adapté."""
    seen = set(await seen_lessons(user_id, diplome))
    first_id = f"dip:{diplome}"
    if first_id not in seen:
        chosen = first_id
    else:
        tier = tier_of(dip_index, total)
        pool = [lid for lid, x in catalog().items() if x["level"] <= tier and lid not in seen]
        chosen = random.choice(pool) if pool else random.choice(list(catalog()))
    async with db_connection() as db:
        await db.execute("INSERT OR IGNORE INTO study_lessons(user_id, diplome, lesson_id, seen_at) VALUES (?,?,?,?)",
                         (user_id, diplome, chosen, now()))
        await db.commit()
    return lesson(chosen)


# ─────────────────────────────────────────────────────────────────────────────
#  Examen par questions
# ─────────────────────────────────────────────────────────────────────────────
def _build_question(lesson_id: str, q: dict) -> dict:
    choices = [q["right"], *q["wrong"][:3]]
    random.shuffle(choices)
    return {"lid": lesson_id, "q": q["q"], "choices": choices, "a": choices.index(q["right"]), "why": q.get("why", "")}


async def start_exam(user_id: int, diplome: str, dip_index: int, total: int) -> dict:
    """Crée (ou reprend) l'examen : uniquement des questions sur les cours révisés. → état de la session."""
    state = await get_exam(user_id)
    if state and state["diplome"] == diplome:
        return state
    seen = await seen_lessons(user_id, diplome)
    tier = tier_of(dip_index, total)
    per = QUESTIONS_PER_LESSON[tier]
    questions: list[dict] = []
    for lid in seen:
        les = lesson(lid)
        if not les:
            continue
        pool = list(les["questions"])
        random.shuffle(pool)
        for q in pool[:per]:
            questions.append(_build_question(lid, q))
    random.shuffle(questions)
    questions = questions[:MAX_QUESTIONS]
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO study_exam(user_id, diplome, questions, pos, score, started_at) VALUES (?,?,?,0,0,?) "
            "ON CONFLICT(user_id) DO UPDATE SET diplome=excluded.diplome, questions=excluded.questions, pos=0, score=0, "
            "started_at=excluded.started_at", (user_id, diplome, json.dumps(questions, ensure_ascii=False), now()))
        await db.commit()
    return await get_exam(user_id)


async def get_exam(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM study_exam WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
    if not row:
        return None
    d = dict(row)
    d["questions"] = json.loads(d["questions"])
    d["total"] = len(d["questions"])
    return d


async def answer(user_id: int, choice: int) -> dict:
    """Enregistre la réponse à la question en cours. → {ok, correct, why, right, finished, score, total}"""
    ex = await get_exam(user_id)
    if not ex or ex["pos"] >= ex["total"]:
        return {"ok": False}
    q = ex["questions"][ex["pos"]]
    correct = choice == q["a"]
    score = ex["score"] + (1 if correct else 0)
    pos = ex["pos"] + 1
    async with db_connection() as db:
        await db.execute("UPDATE study_exam SET pos=?, score=? WHERE user_id=?", (pos, score, user_id))
        await db.commit()
    return {"ok": True, "correct": correct, "why": q["why"], "right": q["choices"][q["a"]],
            "finished": pos >= ex["total"], "score": score, "total": ex["total"]}


async def finish(user_id: int) -> None:
    async with db_connection() as db:
        await db.execute("DELETE FROM study_exam WHERE user_id=?", (user_id,))
        await db.commit()


def needed(total: int, dip_index: int, n_diplomes: int) -> int:
    return max(1, math.ceil(PASS_RATIO[tier_of(dip_index, n_diplomes)] * total))


def mention(score: int, total: int) -> str:
    r = score / total if total else 0
    return "Très Bien" if r >= 0.9 else "Bien" if r >= 0.75 else "Passable"
