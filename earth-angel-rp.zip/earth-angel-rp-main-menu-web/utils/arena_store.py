# utils/arena_store.py
import json
import uuid

import aiosqlite

from database import db_connection, now


def new_match_id() -> str:
    return uuid.uuid4().hex


async def create_match(
    challenger_id: int,
    target_id: int,
    game: str,
    bet: int,
    ttl: int = 600,
) -> str:
    if challenger_id == target_id:
        raise ValueError("Un joueur ne peut pas se défier lui-même")
    if bet <= 0:
        raise ValueError("Mise invalide")

    match_id = new_match_id()
    current = now()
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO arena_matches "
            "(match_id,challenger_id,target_id,game,bet,pot,status,"
            "created_at,expires_at) VALUES (?,?,?,?,?,0,'pending',?,?)",
            (
                match_id,
                challenger_id,
                target_id,
                game,
                bet,
                current,
                current + ttl,
            ),
        )
        await db.commit()
    return match_id


async def get_match(match_id: str) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT * FROM arena_matches WHERE match_id=?",
            (match_id,),
        ) as cursor:
            row = await cursor.fetchone()
    return dict(row) if row else None


async def decline_match(match_id: str, target_id: int) -> bool:
    async with db_connection() as db:
        cursor = await db.execute(
            "UPDATE arena_matches SET status='declined',settled_at=? "
            "WHERE match_id=? AND target_id=? AND status='pending'",
            (now(), match_id, target_id),
        )
        await db.commit()
        return cursor.rowcount == 1


async def accept_and_fund_match(match_id: str, target_id: int) -> dict | None:
    """Débite les deux joueurs exactement une fois et ouvre le match."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT * FROM arena_matches WHERE match_id=?",
                (match_id,),
            ) as cursor:
                match = await cursor.fetchone()

            if (
                not match
                or match["target_id"] != target_id
                or match["status"] != "pending"
                or match["expires_at"] <= now()
            ):
                await db.rollback()
                return None

            claim = await db.execute(
                "UPDATE arena_matches SET status='funding' "
                "WHERE match_id=? AND status='pending'",
                (match_id,),
            )
            if claim.rowcount != 1:
                await db.rollback()
                return None

            bet = match["bet"]
            debit_a = await db.execute(
                "UPDATE users SET balance=balance-?,total_spent=total_spent+? "
                "WHERE user_id=? AND balance>=?",
                (bet, bet, match["challenger_id"], bet),
            )
            debit_b = await db.execute(
                "UPDATE users SET balance=balance-?,total_spent=total_spent+? "
                "WHERE user_id=? AND balance>=?",
                (bet, bet, match["target_id"], bet),
            )
            if debit_a.rowcount != 1 or debit_b.rowcount != 1:
                await db.rollback()
                return None

            await db.execute(
                "UPDATE arena_matches SET status='active',pot=?,accepted_at=? "
                "WHERE match_id=? AND status='funding'",
                (bet * 2, now(), match_id),
            )
            await db.commit()
        except Exception:
            await db.rollback()
            raise

    return await get_match(match_id)


async def save_choice(
    match_id: str,
    user_id: int,
    choice: str,
) -> dict | None:
    if len(choice) > 100:
        raise ValueError("Choix trop long")

    async with db_connection(row_factory=aiosqlite.Row) as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT * FROM arena_matches WHERE match_id=? AND status='active'",
                (match_id,),
            ) as cursor:
                match = await cursor.fetchone()
            if not match:
                await db.rollback()
                return None

            if user_id == match["challenger_id"]:
                column = "challenger_choice"
            elif user_id == match["target_id"]:
                column = "target_choice"
            else:
                await db.rollback()
                return None

            # Le premier choix est définitif, un second clic ne le remplace pas.
            cursor = await db.execute(
                f"UPDATE arena_matches SET {column}=? "
                f"WHERE match_id=? AND status='active' AND {column}=''",
                (choice, match_id),
            )
            if cursor.rowcount != 1:
                await db.rollback()
                return await get_match(match_id)

            await db.commit()
        except Exception:
            await db.rollback()
            raise

    return await get_match(match_id)


async def settle_winner(
    match_id: str,
    winner_id: int,
    result: dict | str,
) -> bool:
    """Verse le pot exactement une fois."""
    result_text = result if isinstance(result, str) else json.dumps(result)

    async with db_connection(row_factory=aiosqlite.Row) as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT * FROM arena_matches WHERE match_id=?",
                (match_id,),
            ) as cursor:
                match = await cursor.fetchone()
            if not match or match["status"] != "active":
                await db.rollback()
                return False
            if winner_id not in (
                match["challenger_id"],
                match["target_id"],
            ):
                await db.rollback()
                return False

            claim = await db.execute(
                "UPDATE arena_matches SET status='settling' "
                "WHERE match_id=? AND status='active'",
                (match_id,),
            )
            if claim.rowcount != 1:
                await db.rollback()
                return False

            await db.execute(
                "UPDATE users SET balance=balance+?,total_earned=total_earned+? "
                "WHERE user_id=?",
                (match["pot"], match["pot"], winner_id),
            )
            await db.execute(
                "UPDATE arena_matches SET status='completed',winner_id=?,"
                "settled_at=?,result_text=? WHERE match_id=? "
                "AND status='settling'",
                (winner_id, now(), result_text[:4000], match_id),
            )
            await db.commit()
            return True
        except Exception:
            await db.rollback()
            raise


async def settle_draw(match_id: str, result: dict | str) -> bool:
    """Rembourse chaque mise exactement une fois."""
    result_text = result if isinstance(result, str) else json.dumps(result)

    async with db_connection(row_factory=aiosqlite.Row) as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT * FROM arena_matches WHERE match_id=?",
                (match_id,),
            ) as cursor:
                match = await cursor.fetchone()
            if not match or match["status"] != "active":
                await db.rollback()
                return False

            claim = await db.execute(
                "UPDATE arena_matches SET status='settling' "
                "WHERE match_id=? AND status='active'",
                (match_id,),
            )
            if claim.rowcount != 1:
                await db.rollback()
                return False

            for user_id in (match["challenger_id"], match["target_id"]):
                await db.execute(
                    "UPDATE users SET balance=balance+? WHERE user_id=?",
                    (match["bet"], user_id),
                )
            await db.execute(
                "UPDATE arena_matches SET status='completed',winner_id=0,"
                "settled_at=?,result_text=? WHERE match_id=? "
                "AND status='settling'",
                (now(), result_text[:4000], match_id),
            )
            await db.commit()
            return True
        except Exception:
            await db.rollback()
            raise


async def refund_match(match_id: str, final_status: str = "refunded") -> bool:
    if final_status not in ("refunded", "expired", "cancelled"):
        raise ValueError("Statut de remboursement invalide")

    async with db_connection(row_factory=aiosqlite.Row) as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT * FROM arena_matches WHERE match_id=?",
                (match_id,),
            ) as cursor:
                match = await cursor.fetchone()
            if not match or match["status"] not in ("active", "funding"):
                await db.rollback()
                return False

            claim = await db.execute(
                "UPDATE arena_matches SET status='refunding' "
                "WHERE match_id=? AND status IN ('active','funding')",
                (match_id,),
            )
            if claim.rowcount != 1:
                await db.rollback()
                return False

            # funding est transactionnel et ne devrait pas persister avec pot>0.
            if match["pot"] > 0:
                for user_id in (
                    match["challenger_id"],
                    match["target_id"],
                ):
                    await db.execute(
                        "UPDATE users SET balance=balance+? WHERE user_id=?",
                        (match["bet"], user_id),
                    )
            await db.execute(
                "UPDATE arena_matches SET status=?,settled_at=? "
                "WHERE match_id=? AND status='refunding'",
                (final_status, now(), match_id),
            )
            await db.commit()
            return True
        except Exception:
            await db.rollback()
            raise


async def expire_arena_matches() -> int:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT match_id,status FROM arena_matches "
            "WHERE expires_at<=? AND status IN ('pending','active')",
            (now(),),
        ) as cursor:
            matches = await cursor.fetchall()

    handled = 0
    for match in matches:
        if match["status"] == "pending":
            async with db_connection() as db:
                cursor = await db.execute(
                    "UPDATE arena_matches SET status='expired',settled_at=? "
                    "WHERE match_id=? AND status='pending'",
                    (now(), match["match_id"]),
                )
                await db.commit()
                handled += max(0, cursor.rowcount)
        elif await refund_match(match["match_id"], "expired"):
            handled += 1
    return handled