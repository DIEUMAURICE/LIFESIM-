# utils/ordre.py — 🚓 Ordre public : Police & Armée (crimes, enquêtes, arrestations, personnel, papiers)
"""
Les factions gouvernementales Police et Armée suivent le modèle de la Santé publique :
5 lieux (1 central dirigé par un DG nommé par le Game Leader, 4 postes dirigés par un chef nommé par le DG),
un coffre de faction, des salaires PAR HEURE DE JEU, un recrutement par entretien.

Crimes
  • contre le BOT : si le crime réussit, le joueur empoche le butin et fuit ; l'enquête s'ouvre après un délai
    (bouton « Se cacher » pour le rallonger). Les enquêteurs jouent un mini-jeu très difficile : réussi → ils
    peuvent arrêter ; raté deux fois → affaire classée. Crime raté → prison immédiate.
  • contre un JOUEUR (vol, piratage, attaque mortelle) : réussi → la police est alertée (police ET armée si le
    criminel ou la victime est membre d'une faction gouvernementale).
Pouvoirs (agents en service) : liste des joueurs (+ karma), neutraliser 30 s, menotter (3 max), escorter en salle
d'interrogatoire (discussion relayée par le bot), emprisonner (60 min max) ou libérer. L'armée peut livrer à la
police ou exécuter un tueur de membre du gouvernement.

Toute la logique est ici (testable sans Telegram) ; les écrans sont dans handlers/ordre.py.
Toutes les durées (neutralisation, menottes, fuite, interrogatoire, prison…) sont en secondes de JEU,
comme le reste du jeu (config.ORDRE).
"""
from utils.swallow import swallowed
import logging
import random

import aiosqlite

from config import (
    ORDRE, ORDRE_FACTIONS, ORDRE_STATIONS, ORDRE_POSTS, ORDRE_BASE_POST, ORDRE_DG_POST,
    ORDRE_CHIEF_POST, ORDRE_HEAD_LEVEL, ORDRE_POWER_LEVEL, ORDRE_PAY_ONLY_ON_DUTY,
    ORDRE_CENTRAL_HEAD, ORDRE_MULTI_HEAD, SANTE_HOSPITALS,
    ORDRE_LEGACY_RANK_TO_POST, ORDRE_PLAYER_CRIMES, ANTI_HACK_PLANS, ANTI_HACK_DAY_GAME_SECONDS,
    GOV_FACTIONS, CRIMES, ADMIN_IDS,
)
from database import db_connection, now, get_user
from utils.factions import coffre_add
from utils.gametime import real_now
from utils.notify import notify

logger = logging.getLogger(__name__)

POWER_FACTIONS = ("police", "armee")                 # seules ces factions ont les pouvoirs d'agent
# TOUTES les factions gouvernementales recrutent par candidature + entretien d'embauche.
# Police / armée / justice / santé ont leurs postes et lieux ; les autres (ex. Administration) ont un lieu unique.
GENERIC_FACTIONS = tuple(k for k in GOV_FACTIONS if k not in ORDRE_FACTIONS and k != "sante")
RECRUIT_FACTIONS = tuple(ORDRE_FACTIONS) + ("sante",) + GENERIC_FACTIONS
GENERIC_HEAD_RANK = 3                                # grade minimal (index) pour recruter dans une faction « simple »
CODE_PREFIX = {"police": "POL", "armee": "ARM", "justice": "JUS"}


def mgnow() -> int:
    """Minuteur d'AFFICHAGE du mini-jeu d'enquête (séquence montrée quelques secondes, puis saisie) :
    c'est un délai d'interface, mesuré en temps réel comme l'expiration des formulaires. Ce n'est
    ni un cooldown ni une durée du jeu."""
    return real_now()


def rnow() -> int:
    """Heure de JEU (alias historique : tout le module ordre utilise l'horloge du jeu)."""
    return now()


# ─────────────────────────────────────────────────────────────────────────────
#  Références (config)
# ─────────────────────────────────────────────────────────────────────────────
def fmt_s(sec: int) -> str:
    sec = max(0, int(sec))
    if sec >= 86400:
        return f"{sec // 86400} j {(sec % 86400) // 3600:02d} h"
    if sec >= 3600:
        return f"{sec // 3600} h {(sec % 3600) // 60:02d} min"
    if sec >= 60:
        return f"{sec // 60} min {sec % 60:02d} s"
    return f"{sec} s"


def faction_info(faction: str) -> dict:
    return GOV_FACTIONS[faction]


def post_info(faction: str, post: str) -> dict:
    return ORDRE_POSTS[faction][post]


def station_info(faction: str, station_id: str) -> dict:
    return ORDRE_STATIONS[faction][station_id]


def station_of_location(faction: str, location: str) -> str | None:
    for sid, s in ORDRE_STATIONS[faction].items():
        if s["location"] == location:
            return sid
    return None


def head_post_for(faction: str, station_id: str) -> str:
    return ORDRE_CENTRAL_HEAD[faction] if station_info(faction, station_id)["kind"] == "central" else ORDRE_CHIEF_POST


def assignable_posts(faction: str) -> list[str]:
    """Postes attribuables par la direction (la direction elle-même est une nomination)."""
    return [k for k, v in ORDRE_POSTS[faction].items() if v["role"] != "head"]


def agent_code(faction: str, no: int) -> str:
    return f"{CODE_PREFIX.get(faction, 'AGT')}-{no:04d}"


def jail_between(rng: tuple[int, int], ratio: float) -> int:
    lo, hi = rng
    return max(60, min(ORDRE["jail_max"], int(lo + (hi - lo) * max(0.0, min(1.0, ratio)))))


def bot_crime_ratio(crime_name: str) -> float:
    names = list(CRIMES)
    return names.index(crime_name) / max(1, len(names) - 1) if crime_name in names else 0.5


def jail_for_bot_crime(crime_name: str) -> int:
    """Peine d'un crime contre le bot (15 à 30 min selon la gravité, jamais plus que le maximum)."""
    return jail_between(ORDRE["jail_bot"], bot_crime_ratio(crime_name))


def jail_for_player_crime(key: str) -> int:
    return jail_between(ORDRE["jail_player"], ORDRE_PLAYER_CRIMES[key]["jail_idx"])


def clamp_sentence(secs: int) -> int:
    return max(60, min(int(secs), ORDRE["jail_max"]))


# ─────────────────────────────────────────────────────────────────────────────
#  Journal
# ─────────────────────────────────────────────────────────────────────────────
def _log(db, actor: int, action: str, target: int = 0, details: str = ""):
    return db.execute(
        "INSERT INTO ordre_logs(ts, actor_id, action, target_id, details) VALUES (?,?,?,?,?)",
        (rnow(), actor, action, target, details[:300]))


async def register_arrest(suspect_id: int, crime: str, source: str, secs: int) -> None:
    """Toute arrestation / peine ouvre un dossier judiciaire (la Justice prend le relais : caution, avocat, procès)."""
    try:
        from utils import justice
        await justice.open_file(suspect_id, crime, source, secs)
    except Exception:
        logger.exception("Ouverture du dossier judiciaire impossible (suspect %s)", suspect_id)


async def log_event(actor: int, action: str, target: int = 0, details: str = "") -> None:
    async with db_connection() as db:
        await _log(db, actor, action, target, details)
        await db.commit()


async def audit(limit: int = 25, user_id: int = 0) -> list[dict]:
    q, args = "SELECT * FROM ordre_logs", []
    if user_id:
        q += " WHERE actor_id=? OR target_id=?"
        args += [user_id, user_id]
    q += " ORDER BY id DESC LIMIT ?"
    args.append(max(1, min(limit, 60)))
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(q, tuple(args)) as cur:
            return [dict(r) for r in await cur.fetchall()]


# ─────────────────────────────────────────────────────────────────────────────
#  Utilitaires joueurs
# ─────────────────────────────────────────────────────────────────────────────
async def is_gov_member(user_id: int) -> bool:
    """Membre de n'importe quelle faction gouvernementale (police, armée, santé, justice, mairie)."""
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM faction_members WHERE user_id=?", (user_id,)) as cur:
            return await cur.fetchone() is not None


async def is_protected(user_id: int) -> bool:
    """Admins / god mode / rôles staff : on ne les neutralise pas, on ne les vole pas."""
    from utils.decorators import get_user_role_async
    u = await get_user(user_id)
    return bool(user_id in ADMIN_IDS or u.get("god_mode") or await get_user_role_async(user_id) != "PLAYER")


async def _display_name(user_id: int) -> str:
    u = await get_user(user_id)
    return u.get("full_name") or u.get("username") or str(user_id)


# ─────────────────────────────────────────────────────────────────────────────
#  Personnel
# ─────────────────────────────────────────────────────────────────────────────
def _staff_dict(row) -> dict:
    d = dict(row)
    if d.get("fm_score") is not None:       # activité = score de faction (temps en service + actions)
        d["activity"] = d["fm_score"]
    p = post_info(d["faction"], d["post"])
    s = station_info(d["faction"], d["station_id"])
    f = faction_info(d["faction"])
    d.update(post_name=p["name"], post_emoji=p["emoji"], level=p["level"], salary_h=p["salary_h"], role=p["role"],
             station_name=s["name"], location=s["location"], faction_name=f["name"], faction_emoji=f["emoji"],
             code=agent_code(d["faction"], d["agent_no"]),
             is_head=p["role"] == "head",
             central_head=d["post"] == ORDRE_CENTRAL_HEAD.get(d["faction"]),
             can_act=d["faction"] in POWER_FACTIONS and p["level"] >= ORDRE_POWER_LEVEL and p["role"] != "base")
    return d


async def _next_agent_no(db, faction: str) -> int:
    async with db.execute("SELECT COALESCE(MAX(agent_no),0)+1 FROM ordre_staff WHERE faction=?", (faction,)) as cur:
        return (await cur.fetchone())[0]


async def get_staff(user_id: int) -> dict | None:
    """Fiche d'agent du joueur (poste, lieu, matricule) ou None. Réconcilie les anciennes adhésions
    (faction_members sans poste → grade converti, jamais de direction automatique) et les postes orphelins."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        marks = ",".join("?" * len(ORDRE_FACTIONS))
        async with db.execute(
                f"SELECT faction, rank, activity_score FROM faction_members WHERE user_id=? AND faction IN ({marks})",
                (user_id, *ORDRE_FACTIONS)) as cur:
            fm = await cur.fetchone()
        async with db.execute("SELECT * FROM ordre_staff WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
        if not fm:
            if row:
                await db.execute("DELETE FROM ordre_staff WHERE user_id=?", (user_id,))
                await db.commit()
            return None
        if row and row["faction"] != fm["faction"]:
            await db.execute("DELETE FROM ordre_staff WHERE user_id=?", (user_id,))
            row = None
        if not row:
            post = ORDRE_LEGACY_RANK_TO_POST[fm["faction"]].get(fm["rank"], ORDRE_BASE_POST[fm["faction"]])
            no = await _next_agent_no(db, fm["faction"])
            await db.execute(
                "INSERT OR IGNORE INTO ordre_staff(user_id, faction, station_id, post, agent_no, on_duty, since, activity) "
                "VALUES (?,?,?,?,?,0,?,0)", (user_id, fm["faction"], "central", post, no, rnow()))
            await db.execute("UPDATE faction_members SET rank=? WHERE user_id=?",
                             (post_info(fm["faction"], post)["level"], user_id))
            await db.commit()
            async with db.execute("SELECT * FROM ordre_staff WHERE user_id=?", (user_id,)) as cur:
                row = await cur.fetchone()
        if row and row["agent_no"] == 0:   # sécurité : matricule manquant
            no = await _next_agent_no(db, row["faction"])
            await db.execute("UPDATE ordre_staff SET agent_no=? WHERE user_id=?", (no, user_id))
            await db.commit()
            async with db.execute("SELECT * FROM ordre_staff WHERE user_id=?", (user_id,)) as cur:
                row = await cur.fetchone()
    if row:
        row = dict(row)
        row["fm_score"] = fm["activity_score"]
    return _staff_dict(row) if row else None


async def list_staff(faction: str, station_id: str | None = None) -> list[dict]:
    q = ("SELECT s.*, fm.activity_score AS fm_score, u.full_name, u.username FROM ordre_staff s JOIN faction_members fm "
         "ON fm.user_id=s.user_id AND fm.faction=s.faction LEFT JOIN users u ON u.user_id=s.user_id "
         "WHERE s.faction=?")
    from utils.staff_scope import excluded_sql      # le staff n'apparaît jamais côté joueurs
    q += " AND " + excluded_sql("s.user_id")
    args: list = [faction]
    if station_id:
        q += " AND s.station_id=?"
        args.append(station_id)
    q += " ORDER BY s.station_id, s.post, s.agent_no"
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(q, tuple(args)) as cur:
            rows = await cur.fetchall()
    return [_staff_dict(r) for r in rows]


async def get_head(faction: str, station_id: str) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT s.*, fm.activity_score AS fm_score, u.full_name, u.username FROM ordre_staff s JOIN faction_members fm "
                "ON fm.user_id=s.user_id AND fm.faction=s.faction LEFT JOIN users u ON u.user_id=s.user_id "
                "WHERE s.faction=? AND s.station_id=? AND s.post IN ('dg','chef')", (faction, station_id)) as cur:
            row = await cur.fetchone()
    return _staff_dict(row) if row else None


async def overview(faction: str) -> list[dict]:
    out = []
    for sid, s in ORDRE_STATIONS[faction].items():
        staff = await list_staff(faction, sid)
        out.append({"station_id": sid, **s, "head": next((x for x in staff if x["is_head"]), None),
                    "count": len(staff), "on_duty": sum(1 for x in staff if x["on_duty"])})
    return out


async def _is_free_worker(db, user_id: int, faction: str) -> str:
    """'' si le joueur peut prendre un poste ; sinon la raison du refus."""
    async with db.execute("SELECT faction FROM faction_members WHERE user_id=?", (user_id,)) as cur:
        fm = await cur.fetchone()
    if fm and fm[0] != faction:
        return "Il travaille déjà dans une autre faction."
    async with db.execute(
            "SELECT 1 FROM company_members cm JOIN companies c ON c.company_id=cm.company_id "
            "WHERE cm.user_id=? AND c.dissolved=0", (user_id,)) as cur:
        if await cur.fetchone():
            return "Il travaille déjà dans une entreprise (il doit démissionner)."
    return ""


async def _set_post(db, user_id: int, faction: str, station_id: str, post: str) -> None:
    lvl = post_info(faction, post)["level"]
    await db.execute(
        "INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) VALUES (?,?,?,0,?) "
        "ON CONFLICT(user_id) DO UPDATE SET rank=excluded.rank", (user_id, faction, lvl, now()))
    async with db.execute("SELECT agent_no FROM ordre_staff WHERE user_id=?", (user_id,)) as cur:
        row = await cur.fetchone()
    no = row[0] if row and row[0] else await _next_agent_no(db, faction)
    await db.execute(
        "INSERT INTO ordre_staff(user_id, faction, station_id, post, agent_no, on_duty, since, activity) "
        "VALUES (?,?,?,?,?,0,?,0) ON CONFLICT(user_id) DO UPDATE SET faction=excluded.faction, "
        "station_id=excluded.station_id, post=excluded.post, on_duty=0, since=excluded.since",
        (user_id, faction, station_id, post, no, rnow()))


async def _install_head(actor_id: int, target_id: int, faction: str, station_id: str) -> tuple[bool, str]:
    post = head_post_for(faction, station_id)
    st = station_info(faction, station_id)
    target = await get_user(target_id)
    if not target or not target.get("registered") or target.get("banned"):
        return False, "Ce joueur n'est pas inscrit (ou banni)."
    from utils.staff_scope import is_ignored
    if await is_ignored(target_id):
        return False, "Le staff n'intervient pas dans le jeu : mentionne (@pseudo) un joueur, pas un membre du staff."
    old_id = 0
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            why = await _is_free_worker(db, target_id, faction)
            if why:
                await db.rollback()
                return False, why
            async with db.execute(
                    "SELECT user_id FROM ordre_staff WHERE faction=? AND station_id=? AND post IN ('dg','chef')",
                    (faction, station_id)) as cur:
                row = await cur.fetchone()
            if faction in ORDRE_MULTI_HEAD:
                row = None                          # plusieurs juges : on n'en remplace aucun
            if row and row["user_id"] != target_id:
                old_id = row["user_id"]
                await db.execute("UPDATE ordre_staff SET post=?, on_duty=0 WHERE user_id=?",
                                 (ORDRE_BASE_POST[faction], old_id))
                await db.execute("UPDATE faction_members SET rank=0 WHERE user_id=?", (old_id,))
            await _set_post(db, target_id, faction, station_id, post)
            await _log(db, actor_id, f"nomination_{post}", target_id, f"{faction}/{station_id}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    p = post_info(faction, post)
    await notify(target_id, "👑 Nomination",
                 f"Tu diriges désormais <b>{st['name']}</b> en tant que <b>{p['name']}</b> "
                 f"({faction_info(faction)['name']}). Tu recrutes, affectes et promeus ton personnel "
                 f"(menu État & factions → Police & Armée).", "achievement")
    if old_id:
        await notify(old_id, "🚓 Fin de mandat",
                     f"Tu ne diriges plus <b>{st['name']}</b> : tu reprends un poste de base.", "warning")
    return True, f"{p['emoji']} {p['name']} de {st['name']} nommé(e)."


async def appoint_dg(actor_id: int, target_id: int, faction: str) -> tuple[bool, str]:
    """Le Game Leader (ou plus) nomme le DG de la faction (contrôle d'accès : handler)."""
    return await _install_head(actor_id, target_id, faction, "central")


async def revoke_dg(actor_id: int, faction: str, reason: str = "") -> tuple[bool, str]:
    head = await get_head(faction, "central")
    if not head:
        return False, "Le poste de DG est déjà vacant."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await db.execute("UPDATE ordre_staff SET post=?, on_duty=0 WHERE user_id=?",
                             (ORDRE_BASE_POST[faction], head["user_id"]))
            await db.execute("UPDATE faction_members SET rank=0 WHERE user_id=?", (head["user_id"],))
            await _log(db, actor_id, "revocation_dg", head["user_id"], f"{faction} {reason}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await notify(head["user_id"], "👔 Fin de mandat",
                 f"Tu n'es plus DG ({faction_info(faction)['name']})." + (f"\nMotif : {reason}" if reason else ""),
                 "warning")
    return True, "DG révoqué(e) : le poste est vacant."


async def revoke_judge(actor_id: int, target_id: int, reason: str = "") -> tuple[bool, str]:
    """Le Game Leader (ou plus) retire un juge : il redevient avocat."""
    st = await get_staff(target_id)
    if not st or st["faction"] != "justice" or st["post"] != "juge":
        return False, "Ce joueur n'est pas juge."
    async with db_connection() as db:
        await db.execute("UPDATE ordre_staff SET post=?, on_duty=0 WHERE user_id=?", (ORDRE_BASE_POST["justice"], target_id))
        await db.execute("UPDATE faction_members SET rank=0 WHERE user_id=?", (target_id,))
        await _log(db, actor_id, "revocation_juge", target_id, reason)
        await db.commit()
    await notify(target_id, "⚖️ Fin de fonction", "Tu n'es plus juge : tu reprends le poste d'avocat.", "warning")
    return True, "Juge révoqué(e) : il redevient avocat."


async def appoint_chief(actor_id: int, target_id: int, faction: str, station_id: str,
                        is_admin: bool = False) -> tuple[bool, str]:
    """Le DG nomme le chef d'un poste secondaire (les admins aussi, pour débloquer une situation)."""
    if station_id not in ORDRE_STATIONS[faction] or station_info(faction, station_id)["kind"] == "central":
        return False, "Un chef dirige un des postes de quartier (le lieu central est dirigé par le DG)."
    if not is_admin:
        me = await get_staff(actor_id)
        if not me or me["faction"] != faction or not me["central_head"]:
            return False, "Seul le DG nomme les chefs de poste."
    return await _install_head(actor_id, target_id, faction, station_id)


async def _authority(actor_id: int, target: dict, is_admin: bool, new_station: str | None = None) -> tuple[dict | None, str]:
    """(fiche acteur, erreur). DG : toute sa faction ; chef : son poste ; admins : tout."""
    if is_admin:
        return None, ""
    me = await get_staff(actor_id)
    if not me or not me["is_head"]:
        return None, "Réservé aux chefs de poste, au DG, aux juges et aux admins."
    if me["faction"] != target["faction"]:
        return None, "Ce joueur appartient à l'autre faction."
    if me["post"] == ORDRE_CHIEF_POST:
        if target["station_id"] != me["station_id"] or (new_station and new_station != me["station_id"]):
            return None, "Un chef de poste gère uniquement le personnel de son poste."
    return me, ""


async def assign_post(actor_id: int, target_id: int, post: str, station_id: str | None = None,
                      is_admin: bool = False) -> tuple[bool, str]:
    tgt = await get_staff(target_id)
    if not tgt:
        return False, "Ce joueur ne fait pas partie de cette faction (il doit d'abord candidater)."
    faction = tgt["faction"]
    if post not in assignable_posts(faction):
        return False, "Poste inconnu."
    if station_id and station_id not in ORDRE_STATIONS[faction]:
        return False, "Lieu inconnu."
    if actor_id == target_id and not is_admin:
        return False, "Tu ne peux pas modifier ton propre poste."
    me, err = await _authority(actor_id, tgt, is_admin, station_id)
    if err:
        return False, err
    if tgt["is_head"] and not is_admin:
        return False, "On ne change pas le poste d'un chef : c'est une nomination."
    if me and post_info(faction, post)["level"] >= me["level"]:
        return False, "Tu ne peux attribuer qu'un poste inférieur au tien."
    new_station = station_id or tgt["station_id"]
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await _set_post(db, target_id, faction, new_station, post)
            await _log(db, actor_id, "poste", target_id, f"{tgt['post']}→{post} @{new_station}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    p = post_info(faction, post)
    await notify(target_id, "🎖️ Nouveau poste",
                 f"Tu es maintenant <b>{p['emoji']} {p['name']}</b> à <b>{station_info(faction, new_station)['name']}</b> — "
                 f"salaire <b>{p['salary_h']:,}</b> par heure de jeu.", "achievement")
    return True, f"{p['emoji']} {p['name']} — {station_info(faction, new_station)['name']}."


async def dismiss(actor_id: int, target_id: int, is_admin: bool = False, reason: str = "") -> tuple[bool, str]:
    tgt = await get_staff(target_id)
    if not tgt:
        return False, "Ce joueur ne fait pas partie de la police ni de l'armée."
    me, err = await _authority(actor_id, tgt, is_admin)
    if err:
        return False, err
    if me and (tgt["user_id"] == actor_id or tgt["level"] >= me["level"]):
        return False, "Tu ne peux renvoyer que quelqu'un de moins gradé que toi."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await db.execute("DELETE FROM faction_members WHERE user_id=? AND faction=?", (target_id, tgt["faction"]))
            await db.execute("DELETE FROM ordre_staff WHERE user_id=?", (target_id,))
            await _log(db, actor_id, "renvoi" if not is_admin else "revocation_admin", target_id,
                       f"{tgt['post']}@{tgt['station_id']} {reason}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    from utils import weapons
    await weapons.strip_issued_weapons(target_id)
    await notify(target_id, f"{tgt['faction_emoji']} Fin de contrat",
                 f"Tu ne fais plus partie de {tgt['faction_name']} ({tgt['post_name']})."
                 + (f"\nMotif : {reason}" if reason else ""), "warning")
    return True, f"{tgt['post_name']} {await _display_name(target_id)} renvoyé(e)."


async def workplace_location(user_id: int) -> str:
    """Lieu de travail (poste de police / caserne d'affectation) — utilisé par « Prendre mon service »."""
    st = await get_staff(user_id)
    return st["location"] if st else "commissariat"


async def set_duty(user_id: int, on: bool) -> tuple[bool, str]:
    st = await get_staff(user_id)
    if not st or not (st["can_act"] or st["faction"] == "justice"):
        return False, "Seuls les agents (hors cadets / recrues), juges et avocats prennent un service."
    if on:
        from utils.location import is_exempt, get_position
        if not await is_exempt(user_id):
            pos = await get_position(user_id)
            if pos["in_transit"] or pos["location"] != st["location"]:
                return False, f"Pour prendre ton service, rends-toi à <b>{st['station_name']}</b>."
    async with db_connection() as db:
        await db.execute("UPDATE ordre_staff SET on_duty=? WHERE user_id=?", (1 if on else 0, user_id))
        await _log(db, user_id, "service_on" if on else "service_off", 0, st["station_id"])
        await db.commit()
    return True, "🟢 Tu es EN SERVICE : tu reçois les alertes et peux agir." if on else "⚪ Tu es hors service."


async def _bump_activity(db, user_id: int, points: int = 1) -> None:
    await db.execute("UPDATE ordre_staff SET activity=activity+? WHERE user_id=?", (points, user_id))
    await db.execute("UPDATE faction_members SET activity_score=activity_score+? WHERE user_id=?", (points, user_id))


async def on_duty_users(factions: tuple[str, ...], roles: tuple[str, ...] | None = None, limit: int = 40) -> list[int]:
    marks = ",".join("?" * len(factions))
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                f"SELECT s.user_id, s.faction, s.post FROM ordre_staff s JOIN faction_members fm "
                f"ON fm.user_id=s.user_id AND fm.faction=s.faction WHERE s.on_duty=1 AND s.faction IN ({marks}) "
                f"LIMIT ?", (*factions, limit)) as cur:
            rows = await cur.fetchall()
    out = []
    for r in rows:
        if roles is None or post_info(r["faction"], r["post"])["role"] in roles:
            out.append(r["user_id"])
    return out


# ─────────────────────────────────────────────────────────────────────────────
#  Papiers : carte d'identité, carnet de travail, carte grise, insigne, activité des employés
# ─────────────────────────────────────────────────────────────────────────────
async def id_card(user_id: int) -> dict:
    u = await get_user(user_id)
    return {"number": f"CI-{user_id:010d}", "user_id": user_id, "name": u.get("full_name") or "—",
            "username": u.get("username") or "—", "karma": u.get("karma", 0),
            "created_at": u.get("created_at", 0), "level": u.get("level", 1)}


async def work_book(user_id: int) -> dict:
    """Situation professionnelle actuelle + derniers événements (recrutements, postes, renvois)."""
    from database import get_user_company
    u = await get_user(user_id)
    comp = await get_user_company(user_id)
    st = await get_staff(user_id)
    async with db_connection() as db:
        async with db.execute(
                "SELECT ts, action, details FROM ordre_logs WHERE target_id=? AND action IN "
                "('recrutement','renvoi','revocation_admin','poste','nomination_dg','nomination_chef','revocation_dg') "
                "ORDER BY id DESC LIMIT ?", (user_id, ORDRE["work_book_events"])) as cur:
            events = [dict(zip(("ts", "action", "details"), r)) for r in await cur.fetchall()]
    return {"number": f"CT-{user_id:010d}", "job": u.get("job") or "", "company": comp, "staff": st, "events": events}


async def vehicle_papers(user_id: int) -> list[dict]:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT veh_id, veh_type, condition, insured FROM vehicles WHERE user_id=? ORDER BY veh_id",
                (user_id,)) as cur:
            rows = await cur.fetchall()
    return [{"plate": f"EA-{r['veh_id']:05d}", "type": r["veh_type"], "condition": r["condition"],
             "insured": bool(r["insured"])} for r in rows]


async def badge(user_id: int) -> dict | None:
    """Insigne : n° d'agent, pseudo / nom / ID, poste, lieu, activité."""
    st = await get_staff(user_id)
    if not st:
        return None
    u = await get_user(user_id)
    return {**st, "name": u.get("full_name") or "—", "username": u.get("username") or "—"}


async def staff_activity(actor_id: int) -> tuple[list[dict], str]:
    """Activité des employés : réservée au DG (toute la faction) et aux chefs (leur poste)."""
    me = await get_staff(actor_id)
    if not me or not me["is_head"]:
        return [], "Réservé à la direction (DG, chefs de poste, juges)."
    sid = me["station_id"] if me["post"] == ORDRE_CHIEF_POST else None
    rows = await list_staff(me["faction"], sid)
    rows.sort(key=lambda r: (-r["activity"], r["agent_no"]))
    return rows, ""


# ─────────────────────────────────────────────────────────────────────────────
#  Candidatures + entretien d'embauche (police, armée, justice ET santé) — discussion relayée par le bot
# ─────────────────────────────────────────────────────────────────────────────
def station_ids(faction: str) -> list[str]:
    if faction in GENERIC_FACTIONS:
        return ["central"]
    return list(SANTE_HOSPITALS) if faction == "sante" else list(ORDRE_STATIONS[faction])


def station_name(faction: str, station_id: str) -> str:
    if faction in GENERIC_FACTIONS:
        return GOV_FACTIONS[faction]["name"]
    return SANTE_HOSPITALS[station_id]["name"] if faction == "sante" else station_info(faction, station_id)["name"]


async def _generic_heads(faction: str) -> list[dict]:
    """Direction (grade ≥ GENERIC_HEAD_RANK) d'une faction « simple », hors police/armée/justice/santé."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT user_id, rank FROM faction_members WHERE faction=? AND rank>=?",
                              (faction, GENERIC_HEAD_RANK)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def recruiter(user_id: int) -> dict | None:
    """Fiche « recruteur » d'un joueur de la direction (toutes factions qui recrutent par entretien)."""
    st = await get_staff(user_id)
    if st:
        return {"faction": st["faction"], "station_id": st["station_id"], "is_head": st["is_head"],
                "central": st["central_head"], "post_name": st["post_name"], "user_id": user_id}
    from utils import sante
    s = await sante.get_staff(user_id)
    if s:
        return {"faction": "sante", "station_id": s["hospital_id"], "is_head": s["role"] == "head",
                "central": s["post"] == "pdg", "post_name": s["post_name"], "user_id": user_id}
    from utils.factions import get_membership, rank_name    # factions simples : le grade décide
    m = await get_membership(user_id)
    if m and m["faction"] in GENERIC_FACTIONS and m["rank"] >= GENERIC_HEAD_RANK:
        return {"faction": m["faction"], "station_id": "central", "is_head": True, "central": True,
                "post_name": rank_name(m["faction"], m["rank"]), "user_id": user_id}
    return None


async def apply_for_job(user_id: int, faction: str, station_id: str = "central") -> tuple[bool, str]:
    if faction not in RECRUIT_FACTIONS or station_id not in station_ids(faction):
        return False, "Faction ou lieu inconnu."
    u = await get_user(user_id)
    if u.get("prison_until", 0) > now():
        return False, "Tu es en prison : impossible de candidater."
    async with db_connection() as db:
        why = await _is_free_worker(db, user_id, faction)
        async with db.execute("SELECT 1 FROM faction_members WHERE user_id=?", (user_id,)) as cur:
            already = await cur.fetchone()
        if already:
            return False, "Tu fais déjà partie d'une faction."
        if why:
            return False, ("Tu travailles déjà dans une autre faction." if "faction" in why
                           else "Tu travailles déjà dans une entreprise : démissionne d'abord.")
        if faction in GENERIC_FACTIONS and not await _generic_heads(faction):
            # Faction simple sans encadrement : personne ne peut faire passer d'entretien → embauche directe
            # au grade d'entrée (un admin installe ensuite un chef avec /faction_chef).
            await db.execute("BEGIN IMMEDIATE")
            await _hire(db, user_id, faction, station_id)
            await db.commit()
            f0 = faction_info(faction)
            return True, (f"✅ {f0['emoji']} <b>{f0['name']}</b> n'a pas encore de direction : "
                          f"tu es recruté(e) directement au grade d'entrée.")
        cur = await db.execute(
            "INSERT OR IGNORE INTO ordre_apps(user_id, faction, station_id, status, created_at) "
            "VALUES (?,?,?,'pending',?)", (user_id, faction, station_id, rnow()))
        await db.commit()
        if not cur.rowcount:
            return False, "Ta candidature est déjà en cours d'examen."
    f = faction_info(faction)
    # destinataires : la direction du lieu visé + la direction centrale (DG / PDG / juges)
    heads: set[int] = set()
    if faction == "sante":
        from utils import sante
        for h in await sante.list_staff():
            if h["role"] == "head" and (h["post"] == "pdg" or h["hospital_id"] == station_id):
                heads.add(h["user_id"])
    elif faction in GENERIC_FACTIONS:
        heads.update(h["user_id"] for h in await _generic_heads(faction))
    else:
        for h in await list_staff(faction):
            if h["is_head"] and (h["central_head"] or h["station_id"] == station_id):
                heads.add(h["user_id"])
    name = await _display_name(user_id)
    for h in heads:
        await notify(h, "📨 Candidature", f"{name} veut rejoindre {f['name']} ({station_name(faction, station_id)}). "
                                          f"👉 Candidatures (menu Ordre public ou ton menu de faction)", "info")
    return True, (f"📨 Candidature envoyée à {f['emoji']} <b>{f['name']}</b> ({station_name(faction, station_id)}). "
                  f"Un entretien te sera peut-être proposé.")


async def list_apps(actor_id: int) -> list[dict]:
    me = await recruiter(actor_id)
    if not me or not me["is_head"]:
        return []
    q = ("SELECT a.*, u.full_name, u.username FROM ordre_apps a LEFT JOIN users u ON u.user_id=a.user_id "
         "WHERE a.faction=? AND a.status IN ('pending','interview')")
    args: list = [me["faction"]]
    if not me["central"]:
        q += " AND a.station_id=?"
        args.append(me["station_id"])
    q += " ORDER BY a.id LIMIT 20"
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(q, tuple(args)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def _get_app(app_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM ordre_apps WHERE id=?", (app_id,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def _app_access(actor_id: int, app: dict | None) -> tuple[dict | None, str]:
    me = await recruiter(actor_id)
    if not app or app["status"] not in ("pending", "interview"):
        return None, "Cette candidature n'existe plus."
    if not me or not me["is_head"] or me["faction"] != app["faction"]:
        return None, "Réservé à la direction de la faction concernée."
    if not me["central"] and me["station_id"] != app["station_id"]:
        return None, "Cette candidature vise un autre lieu."
    return me, ""


async def start_interview(actor_id: int, app_id: int) -> tuple[bool, str]:
    app = await _get_app(app_id)
    me, err = await _app_access(actor_id, app)
    if err:
        return False, err
    ok, msg, _cid = await open_chat("entretien", actor_id, app["user_id"], app_id, app["faction"],
                                    ORDRE.get("interview_seconds", 900))
    if not ok:
        return False, msg
    async with db_connection() as db:
        await db.execute("UPDATE ordre_apps SET status='interview', handler_id=? WHERE id=?", (actor_id, app_id))
        await _log(db, actor_id, "entretien", app["user_id"], app["faction"])
        await db.commit()
    await notify(app["user_id"], "🗣️ Entretien d'embauche",
                 f"{faction_info(app['faction'])['emoji']} {me['post_name']} {await _display_name(actor_id)} "
                 f"t'accorde un entretien. Écris simplement ici : tes messages lui sont transmis par le bot.",
                 "info")
    return True, "🗣️ Entretien ouvert : tout ce que tu écris est transmis au candidat."


async def _hire(db, user_id: int, faction: str, station: str) -> None:
    """Inscrit le recruté au poste de base (dans la transaction de l'appelant)."""
    if faction in GENERIC_FACTIONS:
        await db.execute(
            "INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) VALUES (?,?,0,0,?) "
            "ON CONFLICT(user_id) DO UPDATE SET rank=excluded.rank", (user_id, faction, now()))
        return
    if faction == "sante":
        await db.execute(
            "INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) VALUES (?,?,0,0,?) "
            "ON CONFLICT(user_id) DO UPDATE SET rank=excluded.rank", (user_id, faction, now()))
        await db.execute(
            "INSERT INTO sante_staff(user_id, hospital_id, post, on_duty, since) VALUES (?,?, 'recolteur', 0, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET hospital_id=excluded.hospital_id", (user_id, station, now()))
        return
    await _set_post(db, user_id, faction, station, ORDRE_BASE_POST[faction])


async def decide_application(actor_id: int, app_id: int, accept: bool) -> tuple[bool, str]:
    app = await _get_app(app_id)
    me, err = await _app_access(actor_id, app)
    if err:
        return False, err
    uid, faction = app["user_id"], app["faction"]
    f = faction_info(faction)
    chat = await active_chat(uid)
    if chat and chat["kind"] == "entretien" and chat["ref"] == app_id:
        await end_chat(chat["id"], "decision")
    if not accept:
        async with db_connection() as db:
            await db.execute("UPDATE ordre_apps SET status='refused', handler_id=? WHERE id=?", (actor_id, app_id))
            await _log(db, actor_id, "candidature_refusee", uid, faction)
            await db.commit()
        await notify(uid, "📨 Candidature", f"{f['emoji']} <b>{f['name']}</b> n'a pas retenu ta candidature.", "warning")
        return True, "❌ Candidature refusée."
    papers_err = await _papers_blocker(uid)
    if papers_err:
        return False, papers_err
    station = app["station_id"] if me["central"] else me["station_id"]
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            why = await _is_free_worker(db, uid, faction)
            async with db.execute("SELECT faction FROM faction_members WHERE user_id=?", (uid,)) as cur:
                fm = await cur.fetchone()
            if why or fm:
                await db.rollback()
                return False, why or "Ce joueur fait déjà partie d'une faction."
            await _hire(db, uid, faction, station)
            await db.execute("UPDATE ordre_apps SET status='accepted', handler_id=? WHERE id=?", (actor_id, app_id))
            await _log(db, actor_id, "recrutement", uid, f"{faction}/{station}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    if faction in GENERIC_FACTIONS:
        from utils.factions import rank_name, rank_salary, salary_unit
        p = {"name": rank_name(faction, 0), "emoji": f["emoji"], "salary_h": rank_salary(faction, 0)}
        unit = salary_unit(faction)
    else:
        if faction == "sante":
            from utils.sante import post_info as sante_post
            p = sante_post("recolteur")
        else:
            p = post_info(faction, ORDRE_BASE_POST[faction])
        unit = "/h de jeu"
    await notify(uid, "🎉 Recruté(e) !",
                 f"{f['emoji']} Bienvenue chez <b>{f['name']}</b> ({station_name(faction, station)}) : "
                 f"poste <b>{p['name']}</b>, salaire {p['salary_h']:,}{unit}.", "achievement")
    return True, f"✅ {await _display_name(uid)} recruté(e) : {p['emoji']} {p['name']}."


async def _papers_blocker(user_id: int) -> str:
    """Vérification des papiers avant recrutement : carte d'identité valide, pas en prison, pas déjà employé."""
    u = await get_user(user_id)
    if not u or not u.get("registered") or u.get("banned"):
        return "❌ Carte d'identité invalide : ce joueur n'est pas (ou plus) inscrit."
    if u.get("prison_until", 0) > now():
        return "❌ Casier : ce candidat est actuellement en prison."
    return ""


# ─────────────────────────────────────────────────────────────────────────────
#  Discussions relayées (interrogatoire, entretien)
# ─────────────────────────────────────────────────────────────────────────────
async def active_chat(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT * FROM ordre_chats WHERE status='open' AND (a_id=? OR b_id=?) ORDER BY id DESC LIMIT 1",
                (user_id, user_id)) as cur:
            row = await cur.fetchone()
    if not row:
        return None
    c = dict(row)
    if c["expires_at"] <= rnow():
        return None   # expiré : le nettoyage (maintenance) le ferme et prévient
    return c


async def open_chat(kind: str, a_id: int, b_id: int, ref: int, faction: str, ttl: int) -> tuple[bool, str, int]:
    if await active_chat(a_id):
        return False, "Tu as déjà une discussion en cours : termine-la d'abord.", 0
    if await active_chat(b_id):
        return False, "L'autre personne est déjà en discussion.", 0
    async with db_connection() as db:
        cur = await db.execute(
            "INSERT INTO ordre_chats(kind, a_id, b_id, ref, faction, started_at, expires_at) VALUES (?,?,?,?,?,?,?)",
            (kind, a_id, b_id, ref, faction, rnow(), rnow() + ttl))
        await db.commit()
        cid = cur.lastrowid
    return True, "", cid


async def end_chat(chat_id: int, outcome: str = "end") -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM ordre_chats WHERE id=? AND status='open'", (chat_id,)) as cur:
            row = await cur.fetchone()
        if not row:
            return None
        await db.execute("UPDATE ordre_chats SET status=? WHERE id=?", (f"closed:{outcome}"[:30], chat_id))
        await db.commit()
    return dict(row)


async def relay_target(sender_id: int) -> dict | None:
    """Destinataire d'un message du joueur s'il est en discussion : {to, label, chat}."""
    c = await active_chat(sender_id)
    if not c:
        return None
    to = c["b_id"] if c["a_id"] == sender_id else c["a_id"]
    me_is_officer = c["a_id"] == sender_id
    if c["kind"] == "interro":
        label = "👮 Agent" if me_is_officer else "🧑‍⚖️ Suspect"
    else:
        label = "🧑‍💼 Recruteur" if me_is_officer else "📝 Candidat"
    return {"to": to, "label": label, "chat": c}


# ─────────────────────────────────────────────────────────────────────────────
#  États temporaires (neutralisé, menotté, interrogé, retenu)
# ─────────────────────────────────────────────────────────────────────────────
STATUS_TEXT = {"stun": "⚡ neutralisé(e)", "cuffs": "⛓️ menotté(e)", "interro": "🧑‍⚖️ en interrogatoire",
               "hold": "🪖 retenu(e) par l'armée"}


async def get_status(user_id: int, kind: str) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT * FROM ordre_status WHERE user_id=? AND kind=? AND until>?", (user_id, kind, rnow())) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def restraint_reason(user_id: int) -> str:
    """'' si le joueur est libre de ses mouvements ; sinon un message (utilisé par require_free)."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT kind, until FROM ordre_status WHERE user_id=? AND kind IN ('stun','cuffs','interro','hold') "
                "AND until>? ORDER BY until DESC LIMIT 1", (user_id, rnow())) as cur:
            row = await cur.fetchone()
    if not row:
        return ""
    return f"{STATUS_TEXT[row['kind']].capitalize()} — encore <b>{fmt_s(row['until'] - rnow())}</b>."


async def player_flags(user_id: int) -> list[str]:
    out = []
    for kind in ("stun", "cuffs", "interro", "hold"):
        s = await get_status(user_id, kind)
        if s:
            out.append(STATUS_TEXT[kind])
    return out


async def _put_status(db, user_id: int, kind: str, seconds: int, by_id: int, extra: str = "") -> int:
    until = rnow() + seconds
    await db.execute(
        "INSERT INTO ordre_status(user_id, kind, until, by_id, extra) VALUES (?,?,?,?,?) "
        "ON CONFLICT(user_id, kind) DO UPDATE SET until=excluded.until, by_id=excluded.by_id, extra=excluded.extra",
        (user_id, kind, until, by_id, extra))
    return until


async def _clear_status(db, user_id: int, *kinds: str) -> None:
    marks = ",".join("?" * len(kinds))
    await db.execute(f"DELETE FROM ordre_status WHERE user_id=? AND kind IN ({marks})", (user_id, *kinds))


async def _acting_agent(actor_id: int, target_id: int) -> tuple[dict | None, str]:
    """Vérifications communes aux pouvoirs : agent en service, cible valide."""
    me = await get_staff(actor_id)
    if not me or not me["can_act"]:
        return None, "Tu n'as pas les pouvoirs d'un agent (cadet / recrue : observation seulement)."
    if not me["on_duty"]:
        return None, "Prends d'abord ton service (menu Ordre public → Mon poste)."
    if actor_id == target_id:
        return None, "Tu ne peux pas agir sur toi-même."
    t = await get_user(target_id)
    if not t or not t.get("registered") or t.get("banned"):
        return None, "Joueur introuvable."
    if await is_protected(target_id):
        return None, "Cette personne est protégée (staff du jeu)."
    return me, ""


async def stun(actor_id: int, target_id: int) -> tuple[bool, str]:
    me, err = await _acting_agent(actor_id, target_id)
    if err:
        return False, err
    if await get_status(target_id, "stuncd"):
        return False, "Cette personne vient d'être neutralisée : elle est insensible un moment."
    if await get_status(target_id, "stun"):
        return False, "Elle est déjà neutralisée."
    from config import WEAPON_STUN_MULT
    from utils import weapons
    seconds = ORDRE["stun_seconds"]
    aw = await weapons.active_weapon(actor_id)           # agent armé : neutralisation plus longue (1 munition)
    if aw and await weapons.spend_ammo(actor_id, aw["key"], 1):
        seconds = int(seconds * WEAPON_STUN_MULT)
    async with db_connection() as db:
        await _put_status(db, target_id, "stun", seconds, actor_id)
        await _put_status(db, target_id, "stuncd", seconds + ORDRE["stun_cooldown_target"], actor_id)
        await _log(db, actor_id, "neutralise", target_id, me["faction"])
        await _bump_activity(db, actor_id)
        await db.commit()
    await notify(target_id, "⚡ Neutralisé(e)",
                 f"{me['faction_emoji']} Un agent te neutralise pendant <b>{seconds} s</b>.", "warning")
    return True, f"⚡ {await _display_name(target_id)} est neutralisé(e) {seconds} s."


async def active_cuffs(actor_id: int) -> list[dict]:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT s.user_id, s.until, u.full_name FROM ordre_status s LEFT JOIN users u ON u.user_id=s.user_id "
                "WHERE s.kind='cuffs' AND s.by_id=? AND s.until>? ORDER BY s.until", (actor_id, rnow())) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def cuff(actor_id: int, target_id: int) -> tuple[bool, str]:
    me, err = await _acting_agent(actor_id, target_id)
    if err:
        return False, err
    if await get_status(target_id, "cuffs") or await get_status(target_id, "interro"):
        return False, "Cette personne est déjà menottée ou interrogée."
    mine = await active_cuffs(actor_id)
    if len(mine) >= ORDRE["cuffs_max"]:
        return False, f"Tu n'as que <b>{ORDRE['cuffs_max']}</b> paires de menottes : libère ou interroge quelqu'un d'abord."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                    "SELECT COUNT(*) FROM ordre_status WHERE kind='cuffs' AND by_id=? AND until>?",
                    (actor_id, rnow())) as cur:
                if (await cur.fetchone())[0] >= ORDRE["cuffs_max"]:
                    await db.rollback()
                    return False, "Plus de menottes disponibles."
            await _put_status(db, target_id, "cuffs", ORDRE["cuffs_seconds"], actor_id)
            await _log(db, actor_id, "menotte", target_id, me["faction"])
            await _bump_activity(db, actor_id)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await notify(target_id, "⛓️ Menotté(e)",
                 f"{me['faction_emoji']} Un agent te menotte (jusqu'à <b>{fmt_s(ORDRE['cuffs_seconds'])}</b> max). "
                 f"Tu ne peux plus rien faire.", "warning")
    return True, f"⛓️ {await _display_name(target_id)} est menotté(e) ({len(mine) + 1}/{ORDRE['cuffs_max']} menottes)."


async def uncuff(actor_id: int, target_id: int) -> tuple[bool, str]:
    st = await get_status(target_id, "cuffs")
    if not st or st["by_id"] != actor_id:
        return False, "Cette personne n'est pas menottée par toi."
    async with db_connection() as db:
        await _clear_status(db, target_id, "cuffs")
        await _log(db, actor_id, "libere_menottes", target_id)
        await db.commit()
    await notify(target_id, "🔓 Libéré(e)", "Tes menottes sont retirées.", "info")
    return True, "🔓 Menottes retirées."


async def _teleport(db, user_id: int, location: str) -> None:
    await db.execute("INSERT OR IGNORE INTO user_position(user_id, location) VALUES (?, ?)", (user_id, location))
    await db.execute(
        "UPDATE user_position SET location=?, travel_to='', travel_from='', travel_mode='', depart_at=0, arrive_at=0 "
        "WHERE user_id=?", (location, user_id))


async def escort_to_interrogation(actor_id: int, target_id: int) -> tuple[bool, str]:
    """Amène un joueur MENOTTÉ en salle d'interrogatoire : l'agent doit être dans son poste ; le canal de
    discussion entre les deux s'ouvre (le bot relaie les messages)."""
    me = await get_staff(actor_id)
    if not me or not me["can_act"] or not me["on_duty"]:
        return False, "Il faut être agent en service."
    st = await get_status(target_id, "cuffs")
    if not st or st["by_id"] != actor_id:
        return False, "Menotte d'abord cette personne."
    from utils.location import is_exempt, get_position
    if not await is_exempt(actor_id):
        pos = await get_position(actor_id)
        if pos["in_transit"] or station_of_location(me["faction"], pos["location"]) is None:
            return False, f"Amène-la dans un lieu de {me['faction_name']} (salle d'interrogatoire) : va dans un poste."
        where = pos["location"]
    else:
        where = me["location"]
    ok, msg, cid = await open_chat("interro", actor_id, target_id, 0, me["faction"], ORDRE["interro_seconds"])
    if not ok:
        return False, msg
    async with db_connection() as db:
        await _clear_status(db, target_id, "cuffs")
        await _put_status(db, target_id, "interro", ORDRE["interro_seconds"], actor_id, str(cid))
        await _teleport(db, target_id, where)
        await _log(db, actor_id, "interrogatoire", target_id, me["faction"])
        await db.commit()
    await notify(target_id, "🧑‍⚖️ Salle d'interrogatoire",
                 f"On t'amène en salle d'interrogatoire. Tout ce que tu écris est transmis à l'agent "
                 f"(<b>{fmt_s(ORDRE['interro_seconds'])}</b> max).", "warning")
    return True, "🧑‍⚖️ Interrogatoire ouvert : écris tes questions, le bot les transmet."


async def finish_interrogation(actor_id: int, target_id: int, jail_seconds: int = 0) -> tuple[bool, str]:
    """jail_seconds > 0 → emprisonner (≤ 60 min) ; 0 → libérer."""
    st = await get_status(target_id, "interro")
    if not st or st["by_id"] != actor_id:
        return False, "Aucun interrogatoire en cours avec cette personne."
    me = await get_staff(actor_id)
    chat = await active_chat(actor_id)
    if chat and chat["kind"] == "interro" and chat["b_id"] == target_id:
        await end_chat(chat["id"], "jail" if jail_seconds else "free")
    secs = clamp_sentence(jail_seconds) if jail_seconds else 0
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await _clear_status(db, target_id, "interro", "cuffs", "stun")
            if secs:
                await db.execute("UPDATE users SET prison_until=MAX(prison_until, ?) WHERE user_id=?",
                                 (now() + secs, target_id))
                await db.execute(
                    "UPDATE ordre_cases SET status='arrete', solver_id=?, closed_at=? WHERE suspect_id=? "
                    "AND status IN ('open','solved')", (actor_id, rnow(), target_id))
                await _bump_activity(db, actor_id, 3)
            await _log(db, actor_id, "emprisonne" if secs else "libere", target_id, str(secs))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    if secs:
        await notify(target_id, "⛓️ Emprisonné(e)",
                     f"Après l'interrogatoire, tu es placé(e) en prison pour <b>{fmt_s(secs)}</b>. "
                     f"(Caution / tribunal / avocat : menu État & factions → Justice.)", "crime")
        await register_arrest(target_id, "Interrogatoire", me["faction"] if me else "police", secs)
        return True, f"⛓️ {await _display_name(target_id)} emprisonné(e) {fmt_s(secs)}."
    await notify(target_id, "🔓 Libéré(e)", "L'interrogatoire est terminé : tu es libre.", "info")
    return True, "🔓 Suspect libéré."


# ── Armée : tueur d'un membre du gouvernement ─────────────────────────────────
async def army_wanted_case(target_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT * FROM ordre_cases WHERE suspect_id=? AND victim_gov=1 AND kind='joueur' "
                "AND status IN ('open','solved') ORDER BY id DESC LIMIT 1", (target_id,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def army_capture(actor_id: int, target_id: int) -> tuple[bool, str]:
    me, err = await _acting_agent(actor_id, target_id)
    if err:
        return False, err
    if me["faction"] != "armee":
        return False, "Seule l'armée capture les tueurs de membres du gouvernement."
    case = await army_wanted_case(target_id)
    if not case:
        return False, "Cette personne n'est pas recherchée par l'armée."
    from utils import weapons
    if not await weapons.active_weapon(actor_id):
        return False, "🔫 Équipe une arme (chambre d'armes de l'armée) avec des munitions pour capturer un suspect armé."
    async with db_connection() as db:
        await _clear_status(db, target_id, "cuffs", "stun")
        await _put_status(db, target_id, "hold", ORDRE["army_decision_seconds"], actor_id, str(case["id"]))
        await _log(db, actor_id, "capture_armee", target_id, f"case {case['id']}")
        await db.commit()
    await notify(target_id, "🪖 Capturé(e)", "L'armée t'a capturé(e) : ton sort se décide maintenant…", "crime")
    return True, (f"🪖 Suspect capturé. Décide dans <b>{ORDRE['army_decision_seconds']} s</b> : "
                  f"le livrer à la police ou l'exécuter.")


async def army_decide(actor_id: int, target_id: int, action: str) -> tuple[bool, str]:
    st = await get_status(target_id, "hold")
    if not st or st["by_id"] != actor_id:
        return False, "Le délai est écoulé (le suspect a été livré à la police)."
    case_id = int(st["extra"] or 0)
    if action == "deliver":
        return await _deliver_to_police(target_id, actor_id, case_id)
    if action != "execute":
        return False, "Action inconnue."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT balance FROM users WHERE user_id=?", (target_id,)) as cur:
                row = await cur.fetchone()
            loss = int((row[0] if row else 0) * ORDRE["army_exec_cash_loss"])
            if loss > 0:
                await db.execute("UPDATE users SET balance=balance-? WHERE user_id=? AND balance>=?",
                                 (loss, target_id, loss))
                await coffre_add(db, "armee", loss)
            await db.execute("UPDATE users SET health=10, hospital_until=? WHERE user_id=?", (now() + 7200, target_id))
            await _clear_status(db, target_id, "hold", "cuffs", "stun")
            await db.execute("UPDATE ordre_cases SET status='arrete', solver_id=?, closed_at=? WHERE id=?",
                             (actor_id, rnow(), case_id))
            await _bump_activity(db, actor_id, 3)
            await _log(db, actor_id, "execution", target_id, f"case {case_id} perte {loss}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await notify(target_id, "💀 Abattu(e)",
                 f"L'armée t'a abattu(e) : tu es à l'hôpital et tu perds <b>{loss:,}</b> en liquide.", "crime")
    return True, f"💀 Suspect abattu(e) (-{loss:,} de liquide, versés au coffre de l'armée)."


async def _deliver_to_police(target_id: int, actor_id: int, case_id: int) -> tuple[bool, str]:
    secs = ORDRE["jail_max"]
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await _clear_status(db, target_id, "hold", "cuffs", "stun")
            await db.execute("UPDATE users SET prison_until=MAX(prison_until, ?) WHERE user_id=?",
                             (now() + secs, target_id))
            await db.execute("UPDATE ordre_cases SET status='arrete', solver_id=?, closed_at=? WHERE id=?",
                             (actor_id, rnow(), case_id))
            if actor_id:
                await _bump_activity(db, actor_id, 2)
            await _log(db, actor_id, "livre_police", target_id, f"case {case_id}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await notify(target_id, "⛓️ Livré(e) à la police",
                 f"L'armée te livre à la police : prison <b>{fmt_s(secs)}</b>.", "crime")
    await register_arrest(target_id, "Meurtre d'un membre du gouvernement", "armee", secs)
    for uid in await on_duty_users(("police",), limit=15):
        await notify(uid, "🪖 Suspect livré", "L'armée a livré un tueur de membre du gouvernement : écroué.", "info")
    return True, f"🚓 Suspect livré à la police (prison {fmt_s(secs)})."


# ── Liste des joueurs (agents) ─────────────────────────────────────────────────
PAGE_PLAYERS = 6


async def list_players(actor_id: int, page: int = 0, query: str = "") -> tuple[list[dict], int]:
    """Joueurs avec karma et indicateur « recherché » (police/armée). → (page, total)."""
    where = "u.registered=1 AND u.banned=0 AND u.user_id!=?"
    args: list = [actor_id]
    if query:
        where += " AND (LOWER(u.full_name) LIKE ? OR LOWER(u.username) LIKE ?)"
        like = f"%{query.lower().lstrip('@')}%"
        args += [like, like]
    wanted = ("EXISTS(SELECT 1 FROM ordre_cases c WHERE c.suspect_id=u.user_id AND "
              "(c.status='solved' OR (c.kind IN ('joueur','signalement') AND c.status='open')))")
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(f"SELECT COUNT(*) FROM users u WHERE {where}", tuple(args)) as cur:
            total = (await cur.fetchone())[0]
        async with db.execute(
                f"SELECT u.user_id, u.full_name, u.username, u.karma, {wanted} AS wanted FROM users u "
                f"WHERE {where} ORDER BY wanted DESC, u.karma ASC, u.full_name LIMIT ? OFFSET ?",
                (*args, PAGE_PLAYERS, max(0, page) * PAGE_PLAYERS)) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
    return rows, total


async def player_card(target_id: int) -> dict | None:
    u = await get_user(target_id)
    if not u or not u.get("registered"):
        return None
    case = None
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT * FROM ordre_cases WHERE suspect_id=? AND status IN ('open','solved') "
                "AND (status='solved' OR kind IN ('joueur','signalement')) ORDER BY id DESC LIMIT 1",
                (target_id,)) as cur:
            row = await cur.fetchone()
            case = dict(row) if row else None
    return {"user_id": target_id, "name": u.get("full_name") or u.get("username") or str(target_id),
            "username": u.get("username") or "", "karma": u.get("karma", 0),
            "prison": max(0, u.get("prison_until", 0) - now()), "flags": await player_flags(target_id),
            "case": case, "army_wanted": bool(await army_wanted_case(target_id))}


# ─────────────────────────────────────────────────────────────────────────────
#  Crimes contre le bot : fuite → enquête
# ─────────────────────────────────────────────────────────────────────────────
async def register_bot_crime(user_id: int, crime_name: str, reward: int) -> int:
    """Crime RÉUSSI contre le bot : le butin est déjà encaissé ; le joueur fuit et l'enquête s'ouvrira plus tard."""
    gov = await is_gov_member(user_id)
    t = rnow()
    async with db_connection() as db:
        cur = await db.execute(
            "INSERT INTO ordre_cases(kind, crime, suspect_id, victim_id, victim_gov, gov_suspect, reward, "
            "created_at, open_at, status) VALUES ('bot',?,?,0,0,?,?,?,?,'fuite')",
            (crime_name, user_id, 1 if gov else 0, reward, t, t + ORDRE["flee_delay"]))
        await db.commit()
        return cur.lastrowid


async def flee_case(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT * FROM ordre_cases WHERE suspect_id=? AND kind='bot' AND status='fuite' "
                "ORDER BY id DESC LIMIT 1", (user_id,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def hide(user_id: int) -> tuple[bool, str]:
    """« Se cacher » : chance de repousser l'ouverture de l'enquête (cooldown)."""
    case = await flee_case(user_id)
    if not case:
        return False, "Tu n'es pas en fuite."
    if case["open_at"] <= rnow():
        return False, "L'enquête est déjà ouverte : trop tard pour te cacher."
    cd = await get_status(user_id, "hidecd")
    if cd:
        return False, f"Tu t'es déjà caché récemment : encore <b>{fmt_s(cd['until'] - rnow())}</b> avant de réessayer."
    ok = random.random() < ORDRE["hide_chance"]
    async with db_connection() as db:
        await _put_status(db, user_id, "hidecd", ORDRE["hide_cooldown"], 0)
        if ok:
            await db.execute("UPDATE ordre_cases SET open_at=MAX(open_at, created_at+?) WHERE id=?",
                             (ORDRE["hide_delay"], case["id"]))
        await db.commit()
    if ok:
        return True, (f"🫥 Tu te fonds dans la ville : l'enquête ne s'ouvrira que dans "
                      f"<b>{fmt_s(case['created_at'] + ORDRE['hide_delay'] - rnow())}</b>.")
    return True, "👀 Un passant t'a repéré : ta cachette ne change rien."


# ─────────────────────────────────────────────────────────────────────────────
#  Crimes contre les joueurs
# ─────────────────────────────────────────────────────────────────────────────
async def get_defense(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM anti_hack WHERE user_id=? AND expires_at>?", (user_id, now())) as cur:
            row = await cur.fetchone()
    if not row:
        return None
    d = dict(row)
    d.update(ANTI_HACK_PLANS.get(d["level"], {"name": d["level"], "emoji": "🛡️", "reduction": 0.0}))
    d["left"] = d["expires_at"] - now()
    return d


async def buy_defense(user_id: int, plan: str) -> tuple[bool, str]:
    p = ANTI_HACK_PLANS.get(plan)
    if not p:
        return False, "Défense inconnue."
    cur_def = await get_defense(user_id)
    if cur_def and ANTI_HACK_PLANS.get(cur_def["level"], {}).get("reduction", 0) > p["reduction"]:
        return False, f"Tu as déjà une défense plus forte ({cur_def['name']}) encore active."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            cur = await db.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                                   "WHERE user_id=? AND balance>=?", (p["cost"], p["cost"], user_id, p["cost"]))
            if not cur.rowcount:
                await db.rollback()
                return False, f"Il te faut <b>{p['cost']:,}</b> en liquide."
            await db.execute(
                "INSERT INTO anti_hack(user_id, level, expires_at) VALUES (?,?,?) "
                "ON CONFLICT(user_id) DO UPDATE SET level=excluded.level, expires_at=excluded.expires_at",
                (user_id, plan, now() + p["days"] * ANTI_HACK_DAY_GAME_SECONDS))
            await _log(db, user_id, "achat_defense", 0, plan)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"{p['emoji']} <b>{p['name']}</b> installée pour {p['days']} jours de jeu (-{p['cost']:,})."


async def _victim_recently_hit(victim_id: int) -> bool:
    async with db_connection() as db:
        async with db.execute(
                "SELECT 1 FROM ordre_cases WHERE victim_id=? AND kind='joueur' AND created_at>? LIMIT 1",
                (victim_id, rnow() - ORDRE["victim_protect"])) as cur:
            return await cur.fetchone() is not None


async def commit_player_crime(user_id: int, key: str, target_id: int) -> dict:
    """Tente un crime contre un joueur. Les contrôles « prison / cooldown / gang » sont faits par l'appelant.
    → {ok, success, amount, jail, msg, case_id}"""
    from database import get_skill, increment_field
    from utils.helpers import roll_success
    cfg = ORDRE_PLAYER_CRIMES.get(key)
    if not cfg:
        return {"ok": False, "msg": "Crime inconnu."}
    if target_id == user_id:
        return {"ok": False, "msg": "Tu ne peux pas te cibler toi-même."}
    victim = await get_user(target_id)
    if not victim or not victim.get("registered") or victim.get("banned"):
        return {"ok": False, "msg": "Cible introuvable."}
    if await is_protected(target_id):
        return {"ok": False, "msg": "Cette cible est intouchable (staff du jeu)."}
    if await _victim_recently_hit(target_id):
        return {"ok": False, "msg": "Cette victime vient déjà d'être visée : laisse-lui un peu de répit."}
    if cfg["need"]:
        skill, lvl = cfg["need"]
        have = await get_skill(user_id, skill)
        if have < lvl:
            return {"ok": False, "msg": f"🔒 Compétence insuffisante : {skill} {have}/{lvl}."}
    # Butin possible ?
    base = 0
    bank_id = 0
    if cfg["source"] == "cash":
        base = victim.get("balance", 0)
    elif cfg["source"] == "bank":
        async with db_connection() as db:
            async with db.execute(
                    "SELECT id, balance FROM bank_accounts WHERE user_id=? ORDER BY balance DESC LIMIT 1",
                    (target_id,)) as cur:
                row = await cur.fetchone()
        if row:
            bank_id, base = row[0], row[1]
    if cfg["source"] != "none" and base < 500:
        return {"ok": False, "msg": "Cette cible n'a presque rien à prendre : cherche une autre victime."}

    me = await get_user(user_id)
    from utils import weapons
    weapon_bonus, weapon_msg = 0.0, ""
    riposte = 0.0
    if key != "hack":
        weapon_bonus, weapon_msg, w_ok = await weapons.use_for_action(user_id, need_firearm=(key == "meurtre"))
        if not w_ok:
            return {"ok": False, "msg": weapon_msg}
        vw = await weapons.active_weapon(target_id)       # victime armée : elle riposte
        if vw and vw["firearm"] and await weapons.spend_ammo(target_id, vw["key"], 1):
            from config import WEAPON_RIPOSTE
            riposte = WEAPON_RIPOSTE
    discretion = await get_skill(user_id, "Discrétion")
    agility = await get_skill(user_id, "Agilité")
    tech = await get_skill(user_id, "Technique")
    bonus = tech * 0.03 if key == "hack" else discretion * 0.02 + agility * 0.01
    karma_bonus = max(-0.1, min(0.1, me.get("karma", 0) / 1000))
    try:
        from utils.vip import chance_boost_bonus
        bonus += chance_boost_bonus(me)
    except Exception:
        swallowed('utils/ordre.py')
    blocked = ""
    if key == "hack":
        d = await get_defense(target_id)
        if d:
            if d["reduction"] >= 1.0:
                blocked = d["name"]
            bonus -= d["reduction"]
    bonus += weapon_bonus - riposte
    success = False if blocked else roll_success(cfg["success"], bonus, karma_bonus)

    if not success:
        jail = jail_for_player_crime(key)
        async with db_connection() as db:
            await db.execute("UPDATE users SET prison_until=MAX(prison_until, ?) WHERE user_id=?",
                             (now() + jail, user_id))
            await _log(db, user_id, "crime_joueur_echec", target_id, key)
            await db.commit()
        await increment_field(user_id, "crimes_done")
        await register_arrest(user_id, cfg["name"], "crime", jail)
        if key == "hack" and blocked:
            await notify(target_id, "🛡️ Attaque bloquée", f"Ta <b>{blocked}</b> a bloqué une tentative de piratage.", "success")
            return {"ok": True, "success": False, "amount": 0, "jail": jail, "case_id": 0,
                    "msg": f"🛡️ La défense de la cible ({blocked}) t'a repéré : tu es tracé(e) !"}
        await notify(target_id, "🛡️ Tentative déjouée", f"Quelqu'un a tenté de te viser ({cfg['name']}) et a échoué.", "info")
        return {"ok": True, "success": False, "amount": 0, "jail": jail, "case_id": 0,
                "msg": random.choice(["La victime a donné l'alerte : la police te cueille ! 🚨",
                                      "Un témoin t'a filmé en pleine action 📱", "Tu as laissé des traces partout 🔍"])}

    amount = 0
    if cfg["source"] != "none":
        amount = min(cfg["cap"], int(base * random.uniform(*cfg["pct"])))
        amount = max(100, min(amount, base))
    victim_gov = await is_gov_member(target_id)
    gov_suspect = await is_gov_member(user_id)
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            if amount:
                if cfg["source"] == "cash":
                    cur = await db.execute("UPDATE users SET balance=balance-? WHERE user_id=? AND balance>=?",
                                           (amount, target_id, amount))
                else:
                    cur = await db.execute("UPDATE bank_accounts SET balance=balance-? WHERE id=? AND balance>=?",
                                           (amount, bank_id, amount))
                if not cur.rowcount:
                    await db.rollback()
                    return {"ok": False, "msg": "La cible a bougé son argent : raté de peu, réessaie plus tard."}
                await db.execute("UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                                 (amount, amount, user_id))
            if key == "meurtre":
                await db.execute("UPDATE users SET health=10, hospital_until=? WHERE user_id=?", (now() + 7200, target_id))
            c = await db.execute(
                "INSERT INTO ordre_cases(kind, crime, suspect_id, victim_id, victim_gov, gov_suspect, reward, "
                "created_at, open_at, status) VALUES ('joueur',?,?,?,?,?,?,?,?, 'open')",
                (key, user_id, target_id, 1 if victim_gov else 0, 1 if gov_suspect else 0, amount, rnow(), rnow()))
            case_id = c.lastrowid
            await _log(db, user_id, "crime_joueur", target_id, f"{key} {amount}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await increment_field(user_id, "karma", cfg["karma"])
    await increment_field(user_id, "crimes_done")
    await increment_field(user_id, "crimes_success")
    suspect_name = await _display_name(user_id)
    vtxt = {"vol": f"Tu t'es fait voler <b>{amount:,}</b>.", "hack": f"Un pirate a siphonné <b>{amount:,}</b> de ton compte.",
            "meurtre": "On a attenté à ta vie : tu es à l'hôpital."}[key]
    await notify(target_id, "🚨 Tu as été victime d'un crime", vtxt + " La police est alertée.", "crime")
    include_army = victim_gov or gov_suspect
    alert = (f"🚨 <b>{cfg['name']}</b> : suspect <b>{suspect_name}</b>"
             + (" (⚠️ membre du gouvernement)" if gov_suspect else "")
             + (" — victime : membre du gouvernement" if victim_gov else "")
             + f". Dossier #{case_id}.")
    for uid in await on_duty_users(("police", "armee") if include_army else ("police",)):
        await notify(uid, "🚨 Alerte crime", alert, "crime")
    return {"ok": True, "success": True, "amount": amount, "jail": 0, "case_id": case_id,
            "msg": {"vol": "Tu files avec le portefeuille ! 🏃", "hack": "Virement discret… transfert réussi 💻",
                    "meurtre": "Le coup est parti… tu t'éclipses 🗡️"}[key]
                   + (f"\n{weapon_msg}" if weapon_msg else "") + ("\n⚔️ La victime a riposté !" if riposte else "")}


# ─────────────────────────────────────────────────────────────────────────────
#  Signalements
# ─────────────────────────────────────────────────────────────────────────────
async def report_player(reporter_id: int, target_id: int, reason: str) -> tuple[bool, str]:
    if reporter_id == target_id:
        return False, "Tu ne peux pas te signaler toi-même."
    t = await get_user(target_id)
    if not t or not t.get("registered"):
        return False, "Joueur introuvable."
    if await is_protected(target_id):
        return False, "Ce compte est protégé : contacte le staff directement."
    async with db_connection() as db:
        async with db.execute(
                "SELECT COUNT(*) FROM ordre_reports WHERE reporter_id=? AND created_at>?",
                (reporter_id, rnow() - 86400)) as cur:
            if (await cur.fetchone())[0] >= ORDRE["report_daily_max"]:
                return False, f"Limite atteinte : {ORDRE['report_daily_max']} signalements par jour."
        async with db.execute(
                "SELECT 1 FROM ordre_reports WHERE reporter_id=? AND target_id=? AND status='pending'",
                (reporter_id, target_id)) as cur:
            if await cur.fetchone():
                return False, "Tu as déjà un signalement en attente contre ce joueur."
        await db.execute("INSERT INTO ordre_reports(reporter_id, target_id, reason, status, created_at) "
                         "VALUES (?,?,?,'pending',?)", (reporter_id, target_id, reason[:300], rnow()))
        await _log(db, reporter_id, "signalement", target_id, reason[:120])
        await db.commit()
    for uid in await on_duty_users(("police",), limit=20):
        await notify(uid, "📢 Signalement", "Un joueur en a signalé un autre. 👉 Ordre public → Signalements", "info")
    return True, "📢 Signalement transmis à la police. Elle décidera de la suite selon les circonstances."


async def list_reports(limit: int = 10) -> list[dict]:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT r.*, a.full_name AS reporter_name, b.full_name AS target_name FROM ordre_reports r "
                "LEFT JOIN users a ON a.user_id=r.reporter_id LEFT JOIN users b ON b.user_id=r.target_id "
                "WHERE r.status='pending' AND r.created_at>? ORDER BY r.id LIMIT ?",
                (rnow() - ORDRE["report_ttl"], limit)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def handle_report(actor_id: int, report_id: int, founded: bool) -> tuple[bool, str]:
    me = await get_staff(actor_id)
    if not me or me["faction"] != "police" or not me["can_act"]:
        return False, "Réservé aux agents de police."
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT * FROM ordre_reports WHERE id=? AND status='pending'", (report_id,)) as cur:
                rep = await cur.fetchone()
            if not rep:
                await db.rollback()
                return False, "Ce signalement a déjà été traité."
            if founded:
                c = await db.execute(
                    "INSERT INTO ordre_cases(kind, crime, suspect_id, victim_id, created_at, open_at, status) "
                    "VALUES ('signalement',?,?,?,?,?, 'open')",
                    (rep["reason"][:80], rep["target_id"], rep["reporter_id"], rnow(), rnow()))
                case_id = c.lastrowid
                await db.execute("UPDATE ordre_reports SET status='founded', handler_id=?, case_id=? WHERE id=?",
                                 (actor_id, case_id, report_id))
            else:
                case_id = 0
                await db.execute("UPDATE ordre_reports SET status='unfounded', handler_id=? WHERE id=?",
                                 (actor_id, report_id))
                await db.execute("UPDATE users SET karma=karma+? WHERE user_id=?",
                                 (ORDRE["report_false_karma"], rep["reporter_id"]))
            await _bump_activity(db, actor_id)
            await _log(db, actor_id, "signalement_fonde" if founded else "signalement_infonde", rep["target_id"], str(report_id))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    if founded:
        await notify(rep["reporter_id"], "📢 Signalement retenu", "La police a ouvert une enquête suite à ton signalement.", "success")
        return True, f"✅ Signalement fondé : dossier #{case_id} ouvert (liste des enquêtes / joueurs recherchés)."
    await notify(rep["reporter_id"], "📢 Signalement classé",
                 f"La police n'a pas retenu ton signalement (karma {ORDRE['report_false_karma']}).", "warning")
    return True, "🗂️ Signalement classé sans suite."


# ─────────────────────────────────────────────────────────────────────────────
#  Enquêtes : mini-jeu de mémoire très difficile
# ─────────────────────────────────────────────────────────────────────────────
SYMBOLS = ORDRE["mg_symbols"]


def mg_length(suspect_karma: int, suspect_crimes_done: int) -> int:
    n = ORDRE["mg_len"]
    if suspect_karma >= ORDRE["mg_good_karma"]:
        n += ORDRE["mg_good_karma_extra"]          # bon karma : plus dur à retrouver
    if suspect_crimes_done >= ORDRE["mg_recidivist_crimes"]:
        n -= ORDRE["mg_recidivist_less"]           # récidiviste : plus facile
    return max(6, min(12, n))


def seq_to_text(seq: str) -> str:
    return " ".join(SYMBOLS[int(c)] for c in seq)


async def investigator_check(user_id: int) -> tuple[dict | None, str]:
    me = await get_staff(user_id)
    if not me or me["faction"] != "police" or me["role"] not in ("enquete", "head"):
        return None, "Seuls les enquêteurs (et la direction) de la police mènent les enquêtes."
    if not me["on_duty"]:
        return None, "Prends d'abord ton service."
    return me, ""


async def list_cases(limit: int = 10) -> list[dict]:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT c.*, u.full_name AS suspect_name FROM ordre_cases c LEFT JOIN users u ON u.user_id=c.suspect_id "
                "WHERE c.status IN ('open','solved') ORDER BY c.status DESC, c.id LIMIT ?", (limit,)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_case(case_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT c.*, u.full_name AS suspect_name FROM ordre_cases c LEFT JOIN users u ON u.user_id=c.suspect_id "
                "WHERE c.id=?", (case_id,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def mg_start(investigator_id: int, case_id: int) -> tuple[bool, str, str]:
    """Lance le mini-jeu : → (ok, message, séquence). Compte une tentative sur le dossier (2 max)."""
    me, err = await investigator_check(investigator_id)
    if err:
        return False, err, ""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT * FROM ordre_cases WHERE id=?", (case_id,)) as cur:
                case = await cur.fetchone()
            if not case or case["status"] != "open":
                await db.rollback()
                return False, "Ce dossier n'est pas (ou plus) ouvert à l'enquête.", ""
            if case["suspect_id"] == investigator_id:
                await db.rollback()
                return False, "Tu ne peux pas enquêter sur toi-même.", ""
            if case["attempts"] >= ORDRE["mg_attempts"]:
                await db.rollback()
                return False, "Les tentatives sont épuisées : dossier classé.", ""
            async with db.execute("SELECT karma, crimes_done FROM users WHERE user_id=?", (case["suspect_id"],)) as cur:
                su = await cur.fetchone()
            n = mg_length(su["karma"] if su else 0, su["crimes_done"] if su else 0)
            seq = "".join(str(random.randrange(len(SYMBOLS))) for _ in range(n))
            await db.execute("UPDATE ordre_cases SET attempts=attempts+1 WHERE id=?", (case_id,))
            await db.execute(
                "INSERT INTO ordre_mg(user_id, case_id, seq, pos, started_at) VALUES (?,?,?,0,?) "
                "ON CONFLICT(user_id) DO UPDATE SET case_id=excluded.case_id, seq=excluded.seq, pos=0, "
                "started_at=excluded.started_at", (investigator_id, case_id, seq, mgnow()))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, "", seq


async def mg_press(investigator_id: int, symbol: int) -> dict:
    """→ {state: wait|continue|fail|win|none, pos, total, case_id, retry}"""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT * FROM ordre_mg WHERE user_id=?", (investigator_id,)) as cur:
                mg = await cur.fetchone()
            if not mg:
                await db.rollback()
                return {"state": "none"}
            total = len(mg["seq"])
            if mgnow() < mg["started_at"] + ORDRE["mg_show"]:
                await db.rollback()
                return {"state": "wait", "pos": mg["pos"], "total": total, "case_id": mg["case_id"]}
            if mgnow() > mg["started_at"] + ORDRE["mg_show"] + 120:   # trop lent : échec
                symbol = -1
            if symbol == int(mg["seq"][mg["pos"]]):
                pos = mg["pos"] + 1
                if pos >= total:
                    await db.execute("DELETE FROM ordre_mg WHERE user_id=?", (investigator_id,))
                    await db.execute("UPDATE ordre_cases SET status='solved', solver_id=? WHERE id=? AND status='open'",
                                     (investigator_id, mg["case_id"]))
                    await _bump_activity(db, investigator_id, 2)
                    await _log(db, investigator_id, "enquete_reussie", 0, str(mg["case_id"]))
                    await db.commit()
                    return {"state": "win", "pos": pos, "total": total, "case_id": mg["case_id"]}
                await db.execute("UPDATE ordre_mg SET pos=? WHERE user_id=?", (pos, investigator_id))
                await db.commit()
                return {"state": "continue", "pos": pos, "total": total, "case_id": mg["case_id"]}
            await db.execute("DELETE FROM ordre_mg WHERE user_id=?", (investigator_id,))
            async with db.execute("SELECT attempts, suspect_id, crime FROM ordre_cases WHERE id=?", (mg["case_id"],)) as cur:
                case = await cur.fetchone()
            retry = bool(case and case["attempts"] < ORDRE["mg_attempts"])
            if case and not retry:
                await db.execute("UPDATE ordre_cases SET status='classe', closed_at=? WHERE id=? AND status='open'",
                                 (rnow(), mg["case_id"]))
            await _log(db, investigator_id, "enquete_ratee", 0, str(mg["case_id"]))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    if case and not retry:
        await notify(case["suspect_id"], "🕵️ Enquête classée",
                     "La police a perdu ta trace : l'enquête sur ton dernier coup est classée.", "success")
    return {"state": "fail", "pos": mg["pos"], "total": total, "case_id": mg["case_id"], "retry": retry}


async def arrest_case(actor_id: int, case_id: int) -> tuple[bool, str]:
    """Arrête le suspect d'un dossier RÉSOLU (mini-jeu réussi)."""
    me, err = await investigator_check(actor_id)
    if err:
        return False, err
    case = await get_case(case_id)
    if not case or case["status"] != "solved":
        return False, "Ce dossier n'est pas résolu : réussis d'abord l'enquête."
    if case["kind"] == "bot":
        secs = jail_for_bot_crime(case["crime"])
    elif case["kind"] == "joueur":
        secs = jail_for_player_crime(case["crime"]) if case["crime"] in ORDRE_PLAYER_CRIMES else ORDRE["jail_player"][0]
    else:
        secs = jail_between(ORDRE["jail_report"], random.random())
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            cur = await db.execute(
                "UPDATE ordre_cases SET status='arrete', solver_id=?, closed_at=? WHERE id=? AND status='solved'",
                (actor_id, rnow(), case_id))
            if not cur.rowcount:
                await db.rollback()
                return False, "Ce dossier vient d'être traité par quelqu'un d'autre."
            await db.execute("UPDATE users SET prison_until=MAX(prison_until, ?) WHERE user_id=?",
                             (now() + secs, case["suspect_id"]))
            await _clear_status(db, case["suspect_id"], "cuffs", "stun")
            await _bump_activity(db, actor_id, 3)
            await _log(db, actor_id, "arrestation", case["suspect_id"], f"case {case_id} {secs}s")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await notify(case["suspect_id"], "🚨 Arrêté(e) !",
                 f"L'enquête a abouti : tu es arrêté(e) pour <b>{case['crime'] or 'ton crime'}</b>. "
                 f"Prison : <b>{fmt_s(secs)}</b>. (Caution / tribunal / avocat : menu État & factions → Justice.)", "crime")
    await register_arrest(case["suspect_id"], case["crime"], "police", secs)
    return True, f"🚨 {case.get('suspect_name') or case['suspect_id']} arrêté(e) : prison {fmt_s(secs)}."


# ─────────────────────────────────────────────────────────────────────────────
#  Tâche planifiée : ouvertures d'enquêtes, expirations
# ─────────────────────────────────────────────────────────────────────────────
async def ordre_maintenance() -> None:
    t = rnow()
    notes: list[tuple[int, str, str, str]] = []
    opened: list[dict] = []
    expired_chats: list[dict] = []
    expired_status: list[dict] = []
    holds: list[dict] = []
    gone_defenses: list[int] = []
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            # 1. fin de fuite → l'enquête s'ouvre
            async with db.execute("SELECT * FROM ordre_cases WHERE status='fuite' AND open_at<=?", (t,)) as cur:
                opened = [dict(r) for r in await cur.fetchall()]
            await db.execute("UPDATE ordre_cases SET status='open' WHERE status='fuite' AND open_at<=?", (t,))
            # 2. dossiers résolus mais jamais bouclés (1 h) → classés
            await db.execute("UPDATE ordre_cases SET status='classe', closed_at=? WHERE status='solved' AND created_at<?",
                             (t, t - 3600 - ORDRE["flee_delay"] - ORDRE["hide_delay"]))
            # 3. états expirés
            async with db.execute("SELECT * FROM ordre_status WHERE until<=?", (t,)) as cur:
                dead = [dict(r) for r in await cur.fetchall()]
            for r in dead:
                if r["kind"] == "hold":
                    holds.append(r)
                elif r["kind"] in ("cuffs", "interro"):
                    expired_status.append(r)
            await db.execute("DELETE FROM ordre_status WHERE until<=? AND kind NOT IN ('hold')", (t,))
            # 4. discussions expirées
            async with db.execute("SELECT * FROM ordre_chats WHERE status='open' AND expires_at<=?", (t,)) as cur:
                expired_chats = [dict(r) for r in await cur.fetchall()]
            await db.execute("UPDATE ordre_chats SET status='closed:expired' WHERE status='open' AND expires_at<=?", (t,))
            # 5. signalements trop anciens
            await db.execute("UPDATE ordre_reports SET status='expired' WHERE status='pending' AND created_at<=?",
                             (t - ORDRE["report_ttl"],))
            # 6. mini-jeux abandonnés
            await db.execute("DELETE FROM ordre_mg WHERE started_at<=?", (t - 600,))
            # 7. défenses anti-hack expirées
            async with db.execute("SELECT user_id FROM anti_hack WHERE expires_at<=?", (now(),)) as cur:
                gone_defenses = [r[0] for r in await cur.fetchall()]
            await db.execute("DELETE FROM anti_hack WHERE expires_at<=?", (now(),))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    if opened:
        forces = await on_duty_users(("police",), roles=("enquete", "head"))
        for c in opened:
            for uid in forces:
                notes.append((uid, "🕵️ Enquête ouverte",
                              f"Dossier #{c['id']} : <b>{c['crime']}</b>. 👉 Ordre public → Enquêtes", "info"))
            if c["suspect_id"]:
                notes.append((c["suspect_id"], "🚨 Enquête ouverte",
                              "La police enquête sur ton dernier coup : tu peux encore être retrouvé(e).", "warning"))
    for r in expired_status:
        if r["kind"] == "cuffs":
            notes.append((r["user_id"], "🔓 Menottes retirées", "Le délai est écoulé : tu es libre.", "info"))
        elif r["kind"] == "interro":
            notes.append((r["user_id"], "🔓 Libéré(e)", "L'interrogatoire a expiré : tu es libre.", "info"))
    for ch in expired_chats:
        label = "🧑‍⚖️ L'interrogatoire a expiré." if ch["kind"] == "interro" else "🗣️ L'entretien a expiré."
        notes += [(ch["a_id"], "⌛ Discussion terminée", label, "info"), (ch["b_id"], "⌛ Discussion terminée", label, "info")]
    for uid in gone_defenses:
        notes.append((uid, "🛡️ Défense expirée", "Ta défense anti-hack a expiré : renouvelle-la depuis le menu Ordre public.", "warning"))
    for h in holds:   # l'armée n'a pas décidé à temps : le suspect est livré à la police
        try:
            await _deliver_to_police(h["user_id"], h["by_id"], int(h["extra"] or 0))
        except Exception:
            logger.exception("Livraison automatique impossible (hold %s)", h)
    for uid, title, msg, kind in notes:
        await notify(uid, title, msg, kind)
    try:
        from utils import justice
        await justice.maintenance()
    except Exception:
        logger.exception("Maintenance de la Justice")


# ─────────────────────────────────────────────────────────────────────────────
#  Salaires PAR HEURE DE JEU, payés par le coffre de chaque faction
# ─────────────────────────────────────────────────────────────────────────────
async def run_ordre_payroll(hour: int | None = None) -> dict:
    from utils.sante import game_hour
    hour = game_hour() if hour is None else hour
    result = {"police": None, "armee": None}
    for faction in ORDRE_FACTIONS:
        result[faction] = await _pay_faction_hour(faction, hour)
    return result


async def _pay_faction_hour(faction: str, hour: int) -> dict:
    res = {"status": "none", "total": 0, "paid": 0, "count": 0}
    notes: list[tuple[int, str, str, str]] = []
    emoji = faction_info(faction)["emoji"]
    name = faction_info(faction)["name"]
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES (?,0)", (faction,))
            q = ("SELECT s.user_id, s.post FROM ordre_staff s JOIN faction_members fm "
                 "ON fm.user_id=s.user_id AND fm.faction=s.faction WHERE s.faction=? AND NOT EXISTS "
                 "(SELECT 1 FROM payroll_log p WHERE p.kind='ordre_h' AND p.entity=? AND p.user_id=s.user_id AND p.day=?)")
            if ORDRE_PAY_ONLY_ON_DUTY:
                q += " AND s.on_duty=1"
            async with db.execute(q, (faction, faction, hour)) as cur:
                due = [(r["user_id"], post_info(faction, r["post"])["salary_h"]) for r in await cur.fetchall()]
            if not due:
                await db.rollback()
                return res
            async with db.execute("SELECT budget FROM faction_state WHERE faction=?", (faction,)) as cur:
                budget = (await cur.fetchone())["budget"]
            total = sum(a for _, a in due)
            ratio = 1.0 if budget >= total else (budget / total if total else 0)
            paid_total = 0
            for uid, amount in due:
                pay = int(amount * ratio)
                paid_total += pay
                if pay > 0:
                    await db.execute("UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                                     (pay, pay, uid))
                await db.execute("INSERT INTO payroll_log VALUES ('ordre_h',?,?,?,?,?)",
                                 (faction, uid, hour, pay, "paid" if ratio >= 1 else "partial"))
                if ratio < 1:
                    notes.append((uid, "⚠️ Salaire partiel",
                                  f"{emoji} Le coffre de {name} est presque vide : tu reçois <b>{pay:,}</b> sur {amount:,} "
                                  f"pour cette heure de jeu.", "warning"))
            await db.execute("UPDATE faction_state SET budget=budget-? WHERE faction=?", (paid_total, faction))
            if hour % 24 == 0:
                for uid, _a in due:
                    async with db.execute(
                            "SELECT COALESCE(SUM(amount),0) FROM payroll_log WHERE kind='ordre_h' AND entity=? "
                            "AND user_id=? AND day>? AND day<=?", (faction, uid, hour - 24, hour)) as cur:
                        day_total = (await cur.fetchone())[0]
                    notes.append((uid, "💰 Salaires de la journée",
                                  f"{emoji} {name} : <b>+{day_total:,}</b> sur les 24 dernières heures de jeu.", "economy"))
            await db.commit()
            res.update(status="paid" if ratio >= 1 else "partial", total=total, paid=paid_total, count=len(due))
        except Exception:
            await db.rollback()
            raise
    for uid, title, msg, kind in notes:
        await notify(uid, title, msg, kind)
    return res
