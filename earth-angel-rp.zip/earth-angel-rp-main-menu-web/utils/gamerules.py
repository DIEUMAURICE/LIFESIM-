# utils/gamerules.py — ⚙️ Règles du jeu pilotées par le staff
"""
utils/gamerules.py — ⚙️ Rôle du bot dans l'économie, piloté par le staff
═══════════════════════════════════════════════════════════════════════
Au début, le BOT fait tourner le monde : il fournit des intrants, achète la production, distribue des bonus.
Quand les entreprises produisent et vendent elles-mêmes, le staff RÉDUIT puis FERME ces rôles, au bon moment,
sans toucher au code. Tant qu'un rôle est ouvert, il sert de filet de sécurité.

• BOT_ROLES : ce que le bot FOURNIT ou ACHÈTE (fournisseur, marché et comptoir nationaux) — 0 % = fermé.
• FAUCETS   : l'argent que le bot DISTRIBUE (bonus, missions, succès…) — 0 % = coupé.
• SWITCHES  : réglages du jeu (paiements réels réservés au Lead Principal, réseau RP, abonnés offerts).
• Chaque changement est journalisé (table game_rules_log) ; l'argent créé par le bot est comptabilisé
  (table treasury_flow, kind='created') pour mesurer le relais des joueurs.
Les valeurs sont mises en cache 20 s : un changement du staff s'applique en quelques secondes.
"""
from __future__ import annotations

import logging
import time

from database import db_connection

logger = logging.getLogger(__name__)

CACHE_TTL = 20
STEPS = (0, 25, 50, 75, 100, 150, 200)      # pourcentages proposés au staff

# Rôles du bot dans la chaîne économique : clé → (libellé, description)
BOT_ROLES: dict[str, tuple[str, str]] = {
    "npc_supply":  ("🏭 Fournisseur national", "Le bot vend des intrants aux entreprises (+50 %, plafonné par jour)."),
    "npc_orders":  ("🛒 Marché national", "Le bot achète chaque jour une part de la production des entreprises."),
    "npc_counter": ("🏛️ Comptoir national", "Le bot rachète des biens aux joueurs (filet de sécurité, prix réduit)."),
}

# Récompenses distribuées par le bot : clé → (libellé, description)
FAUCETS: dict[str, tuple[str, str]] = {
    "daily":        ("🎁 Bonus quotidien", "Argent du bonus des 24 h."),
    "work":         ("🛠️ Petits métiers", "Gains des missions de petits métiers payées par le bot."),
    "achievements": ("🏅 Succès", "Argent des succès débloqués."),
    "tutorial":     ("🎓 Tutoriel", "Argent des étapes du tutoriel."),
    "missions":     ("🎯 Missions", "Argent des missions quotidiennes et hebdomadaires."),
    "travel":       ("✈️ Voyages", "Bonus d'argent des événements de voyage."),
    "referral":     ("🤝 Parrainage", "Récompenses de parrainage."),
}

# clé → (libellé, valeur par défaut 1/0, réservé au Lead Principal)
SWITCHES: dict[str, tuple[str, int, bool]] = {
    "real_payments": ("💳 Paiements réels (Telegram Stars)", 1, True),
    "rp_network":    ("🌐 Réseau RP entre joueurs", 1, False),
    "bot_followers": ("📈 Abonnés offerts par le bot sur les posts solo", 1, False),
    "shop_money":    ("💰 Argent vendu en boutique (sacs et packs de €A)", 1, False),
}

_cache: dict[str, tuple[float, str]] = {}


async def get_rule(key: str, default: str = "") -> str:
    import database as _database
    cache_key = f"{_database.DB_PATH}:{key}"
    hit = _cache.get(cache_key)
    if hit and time.monotonic() - hit[0] < CACHE_TTL:
        return hit[1]
    value = default
    try:
        async with db_connection() as db:
            async with db.execute("SELECT value FROM game_rules WHERE key=?", (key,)) as cur:
                row = await cur.fetchone()
        if row:
            value = row[0]
    except Exception:
        logger.exception("Lecture de la règle %s impossible : valeur par défaut", key)
    _cache[cache_key] = (time.monotonic(), value)
    return value


async def set_rule(key: str, value: str, actor_id: int) -> None:
    old = await get_rule(key, "")
    ts = int(time.time())
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO game_rules (key, value, updated_by, updated_at) VALUES (?,?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_by=excluded.updated_by, "
            "updated_at=excluded.updated_at", (key, str(value), actor_id, ts))
        await db.execute(
            "INSERT INTO game_rules_log (key, old_value, new_value, actor_id, created_at) VALUES (?,?,?,?,?)",
            (key, old, str(value), actor_id, ts))
        await db.commit()
    import database as _database
    _cache[f"{_database.DB_PATH}:{key}"] = (time.monotonic(), str(value))


async def faucet_pct(key: str) -> int:
    raw = await get_rule(f"faucet:{key}", "100")
    try:
        return max(0, min(500, int(raw)))
    except ValueError:
        return 100


async def faucet(key: str, amount: int) -> int:
    """Applique le réglage du staff à une récompense du bot (jamais négatif ; 0 si elle est coupée) et la comptabilise."""
    if amount <= 0:
        return amount
    out = int(amount * await faucet_pct(key) / 100)
    if out > 0:
        await record(f"faucet:{key}", "created", out)
    return out


async def bot_pct(role: str) -> int:
    """Part (0-200 %) de l'activité d'un rôle du bot : 100 = normal, 0 = fermé."""
    raw = await get_rule(f"bot:{role}", "100")
    try:
        return max(0, min(200, int(raw)))
    except ValueError:
        return 100


async def record(source: str, kind: str, amount: int) -> None:
    """Comptabilise un mouvement d'argent du bot (kind='created' : créé par le bot ; 'bot' : payé au bot)."""
    if amount <= 0:
        return
    try:
        from database import now
        async with db_connection() as db:
            await db.execute(
                "INSERT INTO treasury_flow(day, source, kind, amount) VALUES (?,?,?,?) "
                "ON CONFLICT(day, source, kind) DO UPDATE SET amount=amount+excluded.amount",
                (now() // 86400, source, kind, int(amount)))
            await db.commit()
    except Exception:
        logger.exception("Comptabilité du bot impossible")


async def switch_on(key: str) -> bool:
    default = SWITCHES.get(key, ("", 1, False))[1]
    return (await get_rule(f"switch:{key}", str(default))) == "1"


async def toggle_switch(key: str, actor_id: int) -> bool:
    new = not await switch_on(key)
    await set_rule(f"switch:{key}", "1" if new else "0", actor_id)
    return new


async def recent_changes(limit: int = 8) -> list[dict]:
    async with db_connection() as db:
        async with db.execute(
                "SELECT key, old_value, new_value, actor_id, created_at FROM game_rules_log "
                "ORDER BY id DESC LIMIT ?", (limit,)) as cur:
            return [dict(r) for r in await cur.fetchall()]
