# utils/character.py — 🪪 Personnage : options, avatar et carte d'identité
"""
Identité RP d'un personnage : prénom, nom et sexe uniquement. Aucun de ces choix ne change l'équilibre
du jeu. (Les anciennes colonnes d'apparence restent en base mais ne sont plus demandées ni affichées.)
"""
from __future__ import annotations

from utils.ui import esc

import html
import time

from database import db_connection

# Identité : prénom, nom et sexe, rien d'autre.
GENDERS = {"homme": ("👨", "Homme"), "femme": ("👩", "Femme"), "autre": ("🧑", "Autre / non précisé")}

FIELDS = {"gender": GENDERS}
FIELD_LABEL = {"first_name": "Prénom", "last_name": "Nom", "gender": "Sexe"}
# ordre de la création guidée
STEPS = ["first_name", "last_name", "gender"]
NAME_MAX = 20


def options(field: str) -> dict[str, tuple[str, str]]:
    return FIELDS[field]


def avatar(gender: str, skin: str = "", hair: str = "") -> str:
    """Avatar en emoji selon le sexe (teint et cheveux ne sont plus demandés : paramètres ignorés)."""
    return GENDERS.get(gender, ("🧑",))[0]


async def get(user_id: int) -> dict | None:
    async with db_connection() as db:
        async with db.execute("SELECT * FROM characters WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def ensure(user_id: int) -> dict:
    if not await get(user_id):
        async with db_connection() as db:
            await db.execute("INSERT OR IGNORE INTO characters(user_id, created_at, updated_at) VALUES (?,?,?)",
                             (user_id, int(time.time()), int(time.time())))
            await db.commit()
    return await get(user_id)


def valid(field: str, value: str) -> bool:
    if field in ("first_name", "last_name"):
        return 2 <= len(value.strip()) <= NAME_MAX
    return value in options(field)


async def set_field(user_id: int, field: str, value: str) -> bool:
    """Enregistre un champ (validé). Retourne False si la valeur est refusée."""
    if field not in FIELD_LABEL or not valid(field, value):
        return False
    value = value.strip()
    await ensure(user_id)
    async with db_connection() as db:
        await db.execute(f"UPDATE characters SET {field}=?, updated_at=? WHERE user_id=?", (value, int(time.time()), user_id))
        await db.commit()
    return True


def next_missing(ch: dict) -> str | None:
    for f in STEPS:
        if not ch.get(f):
            return f
    return None


async def finish(user_id: int) -> bool:
    ch = await get(user_id)
    if not ch or next_missing(ch):
        return False
    async with db_connection() as db:
        await db.execute("UPDATE characters SET complete=1, updated_at=? WHERE user_id=?", (int(time.time()), user_id))
        await db.commit()
    return True


async def is_complete(user_id: int) -> bool:
    ch = await get(user_id)
    return bool(ch and ch["complete"])


async def gate(update, uid: int) -> bool:
    """Porte d'entrée OBLIGATOIRE du jeu : tant que le personnage n'est pas terminé, bloque
    l'action en cours et affiche l'écran de création. Retourne True si l'action a été bloquée.

    À appeler en tête de toute action de jeu (menu, hub, commandes…) — sauf le module
    `handlers.personnage` lui-même, qui doit rester accessible pour pouvoir créer le personnage.
    Valable pour Telegram comme pour un futur client (mini-app / web) qui passerait par la même
    couche de jeu : la porte est côté serveur, pas côté interface.
    """
    if await is_complete(uid):
        return False
    from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as M
    ch = await get(uid)
    started = bool(ch and (ch["first_name"] or ch["gender"]))
    text = (
        "🪪 <b>CRÉATION DE PERSONNAGE OBLIGATOIRE</b>\n━━━━━━━━━━━━━━━━━━\n"
        "Avant d'apparaître sur Terre, donne un visage et une identité à ton personnage : "
        "prénom, nom et sexe.\n\n"
        "<i>Ce sont des choix d'identité : ils n'influencent ni l'argent, ni l'XP, ni les gains.</i>"
    )
    kb = M([[B("▶️ Continuer la création" if started else "✨ Créer mon personnage", callback_data="pc:go")]])
    q = getattr(update, "callback_query", None)
    try:
        if q:
            try:
                await q.answer("🪪 Crée d'abord ton personnage.", show_alert=True)
            except Exception:
                pass
            try:
                await q.edit_message_text(text, parse_mode="HTML", reply_markup=kb)
            except Exception:
                await q.message.reply_text(text, parse_mode="HTML", reply_markup=kb)
        else:
            msg = getattr(update, "effective_message", None)
            if msg:
                await msg.reply_text(text, parse_mode="HTML", reply_markup=kb)
    except Exception:
        pass
    return True


def card_lines(ch: dict) -> list[str]:
    e, label = GENDERS.get(ch.get("gender", ""), ("", ch.get("gender") or "—"))
    av = avatar(ch.get("gender", ""))
    return [f"{av}  <b>{esc(ch.get('first_name', ''))} {esc(ch.get('last_name', ''))}</b>".rstrip(),
            f"⚧ {e} {label}".replace("⚧  ", "⚧ ")]
