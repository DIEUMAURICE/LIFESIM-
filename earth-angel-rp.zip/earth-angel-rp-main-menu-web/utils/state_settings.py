# utils/state_settings.py — réglages de l'État fixés par le gouvernement (table `state_settings`)
"""
Aujourd'hui : le coefficient de l'impôt sur la fortune, réglé par le Ministre de l'Économie (ou le Président).
Le coefficient est gardé en mémoire (lecture synchrone depuis le calcul d'impôt) et persisté en base ;
`refresh()` le relit (démarrage, avant le prélèvement quotidien).
"""
from __future__ import annotations

import logging

from config import (TAX_FACTOR_MAX, TAX_FACTOR_MIN, TAX_FACTOR_STEP, TAX_FACTOR_COOLDOWN)
from database import db_connection, now

logger = logging.getLogger(__name__)

_TAX_KEY = "tax_factor"
_tax_factor: float = 1.0


def tax_factor() -> float:
    """Coefficient actuel appliqué au barème de l'impôt sur la fortune (1.0 = barème normal)."""
    return _tax_factor


def clamp_factor(value: float) -> float:
    steps = round((float(value) - TAX_FACTOR_MIN) / TAX_FACTOR_STEP)
    return round(min(TAX_FACTOR_MAX, max(TAX_FACTOR_MIN, TAX_FACTOR_MIN + steps * TAX_FACTOR_STEP)), 4)


async def refresh() -> float:
    """Relit le coefficient en base (1.0 par défaut)."""
    global _tax_factor
    try:
        async with db_connection() as db:
            async with db.execute("SELECT value FROM state_settings WHERE key=?", (_TAX_KEY,)) as cur:
                row = await cur.fetchone()
        _tax_factor = clamp_factor(float(row[0])) if row else 1.0
    except Exception:
        logger.exception("Lecture du coefficient d'impôt impossible")
    return _tax_factor


async def set_tax_factor(value: float) -> tuple[bool, str]:
    """Fixe le coefficient (borné, par pas), au plus une fois par jour de jeu."""
    global _tax_factor
    factor = clamp_factor(value)
    async with db_connection() as db:
        async with db.execute("SELECT value, updated_at FROM state_settings WHERE key=?", (_TAX_KEY,)) as cur:
            row = await cur.fetchone()
        if row and now() - int(row[1]) < TAX_FACTOR_COOLDOWN:
            left = TAX_FACTOR_COOLDOWN - (now() - int(row[1]))
            return False, f"L'impôt a déjà été modifié récemment (encore {left // 3600} h de jeu avant le prochain changement)."
        await db.execute(
            "INSERT INTO state_settings(key, value, updated_at) VALUES (?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (_TAX_KEY, str(factor), now()))
        await db.commit()
    _tax_factor = factor
    return True, f"Coefficient d'impôt fixé à ×{factor:g}."
