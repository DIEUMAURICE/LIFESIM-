"""utils/staff_scope.py — Le staff à partir d'Admin N2 n'intervient pas dans le jeu.

Les Admins N2, Game Leaders, Leads (Staff, Studio, Influenceurs, Principal) peuvent toujours se
connecter et jouer, mais rien de ce qu'ils font ne COMPTE : ils n'apparaissent dans aucun
classement, ni dans les agrégats du jeu (ex. quorum des élections), et ne participent pas à la
politique (voir `utils/roles.can_play`). Les Admins N1 restent des joueurs à part entière.

Source unique : ce module. `excluded_sql(colonne)` renvoie un prédicat SQL (« cet utilisateur n'est
PAS du staff ignoré ») à ajouter aux requêtes de classement ; `is_ignored(user_id)` répond au cas par cas.
Le rôle effectif suit `get_user_role_async` : rôle statique (config) OU rôle dynamique actif (table
`admin_roles`, nominations `/nommer_*`).
"""
from __future__ import annotations

from config import (
    ADMIN_N2_IDS, GAME_LEADER_IDS, LEAD_INFLUENCEURS_IDS, LEAD_PRINCIPAL_IDS, LEAD_STAFF_GLOBAL_IDS,
    LEAD_STUDIO_IDS, ROLE_LABELS,
)

# Tout le staff sauf les joueurs et les Admins N1.
IGNORED_ROLES: tuple[str, ...] = tuple(r for r in ROLE_LABELS if r not in ("PLAYER", "ADMIN_N1"))


def _static_ids() -> list[int]:
    """Rôles statiques (config) ignorés : toutes les listes d'ID staff sauf Admin N1 (un ID présent dans
    une liste supérieure ET dans N1 garde son rôle le plus haut, donc reste ignoré — comme get_user_role)."""
    ids = set(LEAD_PRINCIPAL_IDS + LEAD_STUDIO_IDS + LEAD_INFLUENCEURS_IDS + LEAD_STAFF_GLOBAL_IDS
              + GAME_LEADER_IDS + ADMIN_N2_IDS)
    return sorted(ids)


def excluded_sql(column: str) -> str:
    """Prédicat SQL vrai quand `column` (un user_id) n'est PAS du staff ignoré."""
    roles = ",".join(f"'{r}'" for r in IGNORED_ROLES)
    parts = [f"{column} NOT IN (SELECT user_id FROM admin_roles WHERE revoked_at=0 AND role IN ({roles}))"]
    static = _static_ids()
    if static:
        parts.append(f"{column} NOT IN ({','.join(str(int(i)) for i in static)})")
    return "(" + " AND ".join(parts) + ")"


async def is_ignored(user_id: int) -> bool:
    from utils.decorators import get_user_role_async
    return await get_user_role_async(user_id) in IGNORED_ROLES
