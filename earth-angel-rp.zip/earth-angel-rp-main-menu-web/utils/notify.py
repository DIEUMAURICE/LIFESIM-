# utils/notify.py — Point d'entrée UNIQUE pour notifier un joueur
"""
Règle du jeu : tout ce qui est accompli, arrivé à échéance ou prélevé doit être notifié.
Tous les modules appellent `notify()` (ou un des helpers ci-dessous) au lieu d'insérer
eux-mêmes dans la table `notifications`. La remise (envoi Telegram, retries) reste gérée
par handlers/notifications.process_notifications.
"""
import logging

logger = logging.getLogger(__name__)

# Types reconnus (icônes dans handlers/notifications.py)
TYPES = ("info", "success", "warning", "error", "event", "reward", "achievement",
         "crime", "economy", "social")


async def notify(user_id: int, title: str, message: str, notif_type: str = "info",
                 delay: int = 0) -> None:
    """Met une notification en file d'attente. Ne lève jamais d'exception (une notification
    ratée ne doit pas annuler l'action du joueur)."""
    if notif_type not in TYPES:
        notif_type = "info"
    try:
        from handlers.notifications import queue_notification
        await queue_notification(user_id, title, message, notif_type, delay)
    except Exception:
        logger.exception("Notification perdue pour %s : %s", user_id, title)

