# utils/gametime.py
"""
Horloge du jeu — UNE SEULE pour tous les joueurs.

    Depuis le 08/11/2026 00:00 UTC : 1 jour de jeu = 24 h réelles (UTC+0), temps réel pur.
    Avant cette date, phase accélérée : 24 h de jeu = 10 h réelles (1 s réelle = 2,4 s de jeu).

Règle d'or
──────────
• Tout ce qui appartient AU JEU (cooldowns, prison, hôpital, voyages, pousse des plantes,
  élections, votes, impôts, loyers, saisons, date affichée…) utilise `game_now()` — c'est
  ce que renvoient `now()` de database.py et de utils/helpers.py.
  Toutes les durées de config.py sont donc en SECONDES DE JEU (3600 = 1 h de jeu).
• Tout ce qui est EXTÉRIEUR au jeu reste en temps réel avec `real_now()` : abonnements
  VIP/Premium et boosts achetés en Stars (« 7 jours » = 7 vrais jours), reçus/paiements,
  sauvegardes, anti-spam, expiration des formulaires, timeouts techniques.

Continuité : l'horloge est ancrée sur DEUX points (config.py) :
  1. GAME_EPOCH_REAL   : avant ce point, temps de jeu = temps réel ; après, phase accélérée.
     Continu à la jonction : aucun saut.
  2. RATE_CHANGE_REAL  : avant ce point, phase accélérée ; à partir de ce point, la date de jeu
     est RECALÉE sur la date réelle (temps de jeu = temps réel, UTC+0, pour toujours après).
     ⚠️ Contrairement au point 1, celui-ci provoque UN SEUL saut, une seule fois, pile à cet
     instant : c'est volontaire, pour que le jeu ne reste pas décalé par rapport à la réalité
     à cause de la phase accélérée qui l'a précédé.

Calcul en entiers (pas de float) : aucune dérive, résultat identique sur tous les processus.
"""
from __future__ import annotations

import time
from datetime import datetime, timezone

from config import GAME_DAY_REAL_SECONDS, GAME_EPOCH_REAL, OLD_GAME_DAY_REAL_SECONDS, RATE_CHANGE_REAL

DAY = 86_400                      # un jour de jeu, en secondes de jeu

# Taux ACTUEL (depuis RATE_CHANGE_REAL) : utilisé pour game_now() après la jonction et pour
# toutes les conversions de durée (celles-ci ne regardent jamais en arrière).
_NUM = DAY                        # secondes de jeu écoulées…
_DEN = GAME_DAY_REAL_SECONDS      # …pour _DEN secondes réelles

# Taux HISTORIQUE (phase accélérée, entre GAME_EPOCH_REAL et RATE_CHANGE_REAL) — figé pour
# toujours, ne sert qu'à rejouer fidèlement cette période dans real_to_game().
_OLD_NUM = DAY
_OLD_DEN = OLD_GAME_DAY_REAL_SECONDS

# Temps de jeu au moment exact de la jonction : ICI ON RECALE SUR LA RÉALITÉ (et non sur la valeur
# qu'aurait donnée l'ancien taux, qui aurait laissé la date de jeu dériver loin devant la date réelle).
# Conséquence assumée : UN SEUL saut, une fois, à cet instant précis — ensuite plus aucun saut, le
# temps de jeu suit exactement le temps réel (UTC+0) pour toujours.
_RATE_CHANGE_GAME = RATE_CHANGE_REAL

SEASONS_BY_MONTH = {
    12: "Hiver", 1: "Hiver", 2: "Hiver",
    3: "Printemps", 4: "Printemps", 5: "Printemps",
    6: "Été", 7: "Été", 8: "Été",
    9: "Automne", 10: "Automne", 11: "Automne",
}
MONTH_NAMES_FR = [
    "", "janvier", "février", "mars", "avril", "mai", "juin",
    "juillet", "août", "septembre", "octobre", "novembre", "décembre",
]
WEEKDAYS_FR = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]


# ─── Conversions ────────────────────────────────────────────────────────────
def real_now() -> int:
    """Temps RÉEL (timestamp UNIX). Pour abonnements payants, paiements, logs techniques."""
    return int(time.time())


def real_to_game(real_ts: float) -> int:
    """Convertit un instant réel en instant de jeu.

    Trois segments, continus entre eux (aucun saut, aucune dérive) :
      • ≤ GAME_EPOCH_REAL  : temps de jeu = temps réel.
      • entre les deux     : phase accélérée (x2,4 — ancien taux figé).
      • ≥ RATE_CHANGE_REAL : 1 j de jeu = 24 h réelles (taux actuel, UTC+0).
    """
    real_ts = int(real_ts)
    if real_ts <= GAME_EPOCH_REAL:
        return real_ts
    if real_ts < RATE_CHANGE_REAL:
        return GAME_EPOCH_REAL + (real_ts - GAME_EPOCH_REAL) * _OLD_NUM // _OLD_DEN
    return _RATE_CHANGE_GAME + (real_ts - RATE_CHANGE_REAL) * _NUM // _DEN


def game_now() -> int:
    """Temps de JEU en secondes (identique pour tous les joueurs)."""
    return real_to_game(time.time())


def game_seconds_to_real(seconds: float) -> int:
    """Durée de jeu (s) → durée réelle (s), arrondie au supérieur. Taux actuel : 24 h de jeu → 24 h réelles."""
    return -(-int(seconds) * _DEN // _NUM) if seconds > 0 else 0


def real_seconds_to_game(seconds: float) -> int:
    """Durée réelle (s) → durée de jeu (s)."""
    return int(seconds) * _NUM // _DEN


# ─── Date / heure de jeu ────────────────────────────────────────────────────
def _dt(game_ts: float) -> datetime:
    return datetime.fromtimestamp(int(game_ts), tz=timezone.utc)


def game_datetime(game_ts: float | None = None) -> dict:
    """Date/heure de jeu complètes : year, month, day, hour, minute, second, weekday, yday,
    season, month_name, weekday_name, game_ts."""
    ts = game_now() if game_ts is None else int(game_ts)
    d = _dt(ts)
    return {
        "year": d.year, "month": d.month, "day": d.day,
        "hour": d.hour, "minute": d.minute, "second": d.second,
        "weekday": d.weekday(), "yday": d.timetuple().tm_yday,
        "season": SEASONS_BY_MONTH[d.month],
        "month_name": MONTH_NAMES_FR[d.month],
        "weekday_name": WEEKDAYS_FR[d.weekday()],
        "game_ts": ts,
    }


def game_month(game_ts: float | None = None) -> int:
    return game_datetime(game_ts)["month"]


def game_season(game_ts: float | None = None) -> str:
    """Saison du jeu (« Printemps », « Été », « Automne », « Hiver ») — la même pour tous."""
    return game_datetime(game_ts)["season"]


def game_day_number(game_ts: float | None = None) -> int:
    """Numéro du jour de jeu (change à 00:00 heure de jeu). Sert aux « une fois par jour »."""
    ts = game_now() if game_ts is None else int(game_ts)
    return ts // DAY


def fmt_game_date(game_ts: float | None = None) -> str:
    d = game_datetime(game_ts)
    return f"{d['day']:02d}/{d['month']:02d}/{d['year']}"


def fmt_game_time(game_ts: float | None = None) -> str:
    d = game_datetime(game_ts)
    return f"{d['hour']:02d}:{d['minute']:02d}"


def fmt_game_datetime(game_ts: float | None = None, sep: str = " à ") -> str:
    """« 11/10/2026 à 14:30 » (heure de jeu)."""
    return f"{fmt_game_date(game_ts)}{sep}{fmt_game_time(game_ts)}"


def real_seconds_until_game_hour(hour: int, game_ts: float | None = None) -> int:
    """Secondes RÉELLES avant la prochaine occurrence de `hour`:00 en heure de jeu."""
    ts = game_now() if game_ts is None else int(game_ts)
    day_sec = ts % DAY
    target = (hour % 24) * 3600
    delta = target - day_sec
    if delta <= 0:
        delta += DAY
    return game_seconds_to_real(delta)


def calendar_years_between(start_ts: float, end_ts: float | None = None) -> int:
    """Années CIVILES complètes entre deux instants de jeu (anniversaires du calendrier,
    années bissextiles incluses). Un 29/02 est fêté le 01/03 les années non bissextiles."""
    a = _dt(start_ts)
    b = _dt(game_now() if end_ts is None else end_ts)
    years = b.year - a.year
    if (b.month, b.day, b.hour, b.minute, b.second) < (a.month, a.day, a.hour, a.minute, a.second):
        years -= 1
    return max(0, years)


# ─── Mois / années CIVILS (durées « 1 mois », « 30 ans »… suivent le calendrier de jeu) ──
def add_game_months(game_ts: float, months: int) -> int:
    """Même jour/heure `months` mois plus tard (négatif = avant). Si le jour n'existe pas dans le
    mois visé (31 janvier + 1 mois), on prend le dernier jour du mois (28/29 février)."""
    import calendar as _cal
    d = _dt(game_ts)
    idx = d.year * 12 + (d.month - 1) + months
    year, month = divmod(idx, 12)
    month += 1
    day = min(d.day, _cal.monthrange(year, month)[1])
    return int(d.replace(year=year, month=month, day=day).timestamp())


def add_game_years(game_ts: float, years: int) -> int:
    return add_game_months(game_ts, 12 * years)


def start_of_next_game_month(game_ts: float | None = None) -> int:
    """00:00 (heure de jeu) du 1er jour du mois suivant."""
    ts = game_now() if game_ts is None else int(game_ts)
    d = _dt(ts).replace(day=1, hour=0, minute=0, second=0)
    return add_game_months(int(d.timestamp()), 1)
