# utils/company_roles.py — rôles dans une entreprise : créateur / gérant / employé
"""
• owner   : le créateur. Seul à pouvoir dissoudre, transférer, retirer de la trésorerie,
            nommer/révoquer les gérants.
• manager : gérant nommé par le créateur. Recrute, licencie les employés, gère annonces,
            produits et prix.
• employe : produit et vend. Son salaire est versé automatiquement (utils/payroll.py).
"""
from database import db_connection


async def get_role(user_id: int, company: dict | None) -> str | None:
    """'owner' | 'manager' | 'employe' | None (pas membre)."""
    if not company:
        return None
    if company.get("owner_id") == user_id:
        return "owner"
    async with db_connection() as db:
        async with db.execute(
            "SELECT role FROM company_members WHERE user_id=? AND company_id=?",
            (user_id, company["company_id"]),
        ) as cur:
            row = await cur.fetchone()
    if not row:
        return None
    return row[0] if row[0] in ("manager", "employe") else "employe"


async def can_manage(user_id: int, company: dict | None) -> bool:
    """Créateur ou gérant."""
    return await get_role(user_id, company) in ("owner", "manager")


async def set_role(company_id: int, owner_id: int, target_id: int, role: str) -> tuple[bool, str]:
    """Le créateur change le rôle d'un membre ('manager' ou 'employe')."""
    if role not in ("manager", "employe"):
        return False, "Rôle invalide (manager ou employe)."
    if target_id == owner_id:
        return False, "Le créateur garde toujours le rôle de créateur."
    async with db_connection() as db:
        cur = await db.execute(
            "UPDATE company_members SET role=? WHERE user_id=? AND company_id=?",
            (role, target_id, company_id),
        )
        await db.commit()
    if not cur.rowcount:
        return False, "Cette personne ne travaille pas dans ton entreprise."
    return True, ""
