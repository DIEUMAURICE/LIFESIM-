# utils/team.py — 👥 Hiérarchie (annuaire) et 💬 chats d'équipe relayés par le bot
"""
HIÉRARCHIE : tout membre d'une faction ou d'une entreprise voit la liste de ses collègues (nom, pseudo, ID, poste) ;
la direction (DG / PDG / chefs) voit en plus l'ACTIVITÉ de chaque employé.

CHATS : trois canaux, relayés par le bot (personne ne voit le compte Telegram des autres) :
  • "f:<faction>"  — tous les membres de ma faction
  • "c:<id>"       — tous les membres de mon entreprise
  • "g"            — TOUS les membres des factions gouvernementales
Le joueur « entre » dans un canal (bouton) : ses messages suivants y sont diffusés, précédés de son NOM et de son POSTE.
"""
import logging
import time

import aiosqlite

from config import GOV_FACTIONS, COMPANY_RANKS
from database import db_connection, get_user, now

logger = logging.getLogger(__name__)

MAX_LEN = 500
MIN_DELAY = 1.5          # secondes réelles entre deux messages d'un même joueur (anti-spam)
_LAST_SENT: dict[int, float] = {}
GOV_CHANNEL = "g"


def fcode(faction: str) -> str:
    return f"f:{faction}"


def ccode(company_id: int) -> str:
    return f"c:{company_id}"


# ─────────────────────────────────────────────────────────────────────────────
#  Appartenances
# ─────────────────────────────────────────────────────────────────────────────
async def membership(user_id: int) -> dict:
    """{'faction': {...}|None, 'company': {...}|None} — ce que le joueur peut voir / utiliser."""
    from utils.factions import get_membership
    from database import get_user_company
    m = await get_membership(user_id)
    c = await get_user_company(user_id)
    return {"faction": m, "company": c}


def channel_title(channel: str, company_name: str = "") -> str:
    if channel == GOV_CHANNEL:
        return "🏛️ Gouvernement (toutes les factions)"
    if channel.startswith("f:"):
        f = GOV_FACTIONS.get(channel[2:])
        return f"{f['emoji']} {f['name']}" if f else channel
    if channel.startswith("c:"):
        return f"🏢 {company_name or 'Entreprise'}"
    return channel


async def my_channels(user_id: int) -> list[tuple[str, str]]:
    """Canaux auxquels le joueur a droit : [(code, titre)]."""
    mem = await membership(user_id)
    out = []
    if mem["faction"]:
        out.append((fcode(mem["faction"]["faction"]), channel_title(fcode(mem["faction"]["faction"]))))
        out.append((GOV_CHANNEL, channel_title(GOV_CHANNEL)))
    if mem["company"]:
        out.append((ccode(mem["company"]["company_id"]), channel_title("c:", mem["company"]["name"])))
    return out


async def channel_member_ids(channel: str) -> list[int]:
    async with db_connection() as db:
        if channel == GOV_CHANNEL:
            q, args = "SELECT user_id FROM faction_members", ()
        elif channel.startswith("f:"):
            q, args = "SELECT user_id FROM faction_members WHERE faction=?", (channel[2:],)
        elif channel.startswith("c:"):
            q, args = "SELECT user_id FROM company_members WHERE company_id=?", (int(channel[2:] or 0),)
        else:
            return []
        async with db.execute(q, args) as cur:
            return [r[0] for r in await cur.fetchall()]


async def has_access(user_id: int, channel: str) -> bool:
    return channel in {c for c, _t in await my_channels(user_id)}


async def sender_line(user_id: int, channel: str) -> str:
    """« Nom · Poste » ; dans le canal du gouvernement, la faction est précisée."""
    u = await get_user(user_id)
    name = u.get("full_name") or u.get("username") or str(user_id)
    mem = await membership(user_id)
    if channel.startswith("c:") and mem["company"]:
        post = f"🏢 {mem['company']['poste']}"
    elif mem["faction"]:
        f = GOV_FACTIONS[mem["faction"]["faction"]]
        post = f"{f['emoji']} {mem['faction']['rank_name']}" + (f" · {f['name']}" if channel == GOV_CHANNEL else "")
    else:
        post = "—"
    return name, post


# ─────────────────────────────────────────────────────────────────────────────
#  État du chat (canal actif, sourdine)
# ─────────────────────────────────────────────────────────────────────────────
async def get_channel(user_id: int) -> str | None:
    async with db_connection() as db:
        async with db.execute("SELECT channel FROM team_chat_state WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
    return row[0] if row else None


async def enter(user_id: int, channel: str) -> tuple[bool, str]:
    if not await has_access(user_id, channel):
        return False, "Tu n'as pas accès à ce canal."
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO team_chat_state(user_id, channel, since) VALUES (?,?,?) "
            "ON CONFLICT(user_id) DO UPDATE SET channel=excluded.channel, since=excluded.since",
            (user_id, channel, now()))
        await db.execute("DELETE FROM team_chat_mute WHERE user_id=? AND channel=?", (user_id, channel))
        await db.commit()
    return True, "💬 Tu es dans le chat : tes prochains messages seront envoyés à tout le canal."


async def leave(user_id: int) -> None:
    async with db_connection() as db:
        await db.execute("DELETE FROM team_chat_state WHERE user_id=?", (user_id,))
        await db.commit()


async def toggle_mute(user_id: int, channel: str) -> bool:
    """True si le canal est maintenant en sourdine."""
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM team_chat_mute WHERE user_id=? AND channel=?", (user_id, channel)) as cur:
            muted = await cur.fetchone() is not None
        if muted:
            await db.execute("DELETE FROM team_chat_mute WHERE user_id=? AND channel=?", (user_id, channel))
        else:
            await db.execute("INSERT OR IGNORE INTO team_chat_mute(user_id, channel) VALUES (?,?)", (user_id, channel))
        await db.commit()
    return not muted


async def is_muted(user_id: int, channel: str) -> bool:
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM team_chat_mute WHERE user_id=? AND channel=?", (user_id, channel)) as cur:
            return await cur.fetchone() is not None


# ─────────────────────────────────────────────────────────────────────────────
#  Diffusion d'un message
# ─────────────────────────────────────────────────────────────────────────────
async def prepare_message(sender_id: int, text: str) -> dict | None:
    """Si le joueur est dans un canal : prépare la diffusion → {'channel', 'recipients', 'name', 'post', 'text'}.
    Renvoie None si le joueur n'est dans aucun canal ; {'error': ...} si le message est refusé."""
    channel = await get_channel(sender_id)
    if not channel:
        return None
    if not await has_access(sender_id, channel):
        await leave(sender_id)
        return {"error": "Tu n'as plus accès à ce canal : tu en es sorti."}
    text = (text or "").strip()
    if not text:
        return {"error": ""}
    if len(text) > MAX_LEN:
        return {"error": f"Message trop long ({MAX_LEN} caractères maximum)."}
    t = time.monotonic()
    if t - _LAST_SENT.get(sender_id, 0) < MIN_DELAY:
        return {"error": "⏳ Doucement : un message toutes les secondes."}
    _LAST_SENT[sender_id] = t
    name, post = await sender_line(sender_id, channel)
    members = await channel_member_ids(channel)
    recipients = []
    for uid in members:
        if uid != sender_id and not await is_muted(uid, channel):
            recipients.append(uid)
    return {"channel": channel, "recipients": recipients, "name": name, "post": post, "text": text,
            "title": channel_title(channel, (await membership(sender_id))["company"]["name"]
                                   if channel.startswith("c:") else "")}


# ─────────────────────────────────────────────────────────────────────────────
#  Hiérarchie (annuaire)
# ─────────────────────────────────────────────────────────────────────────────
async def _faction_roster(faction: str) -> list[dict]:
    """Membres d'une faction : [{user_id, name, username, title, place, activity, duty, level, head}]."""
    from config import SANTE_POSTS, SANTE_HOSPITALS
    from utils import ordre
    out: list[dict] = []
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT fm.user_id, fm.rank, fm.activity_score, u.full_name, u.username FROM faction_members fm "
                "LEFT JOIN users u ON u.user_id=fm.user_id WHERE fm.faction=? ORDER BY fm.rank DESC", (faction,)) as cur:
            base = [dict(r) for r in await cur.fetchall()]
    if faction in ordre.ORDRE_FACTIONS:
        by_id = {s["user_id"]: s for s in await ordre.list_staff(faction)}
    elif faction == "sante":
        from utils import sante
        by_id = {s["user_id"]: s for s in await sante.list_staff()}
    else:
        by_id = {}
    for b in base:
        entry = {"user_id": b["user_id"], "name": b["full_name"] or b["username"] or str(b["user_id"]),
                 "username": b["username"] or "", "activity": b["activity_score"], "duty": False,
                 "place": "", "level": b["rank"], "head": False}
        s = by_id.get(b["user_id"])
        if faction in ordre.ORDRE_FACTIONS and s:
            entry.update(title=s["post_name"], place=s["station_name"], duty=bool(s["on_duty"]), level=s["level"],
                         head=s["is_head"])
        elif faction == "sante" and s:
            p = SANTE_POSTS.get(s["post"], {})
            entry.update(title=p.get("name", s["post"]), place=SANTE_HOSPITALS.get(s["hospital_id"], {}).get("name", ""),
                         duty=bool(s["on_duty"]), level=p.get("level", 0), head=p.get("role") == "head")
        else:
            from utils.factions import rank_name
            from utils.ordre import GENERIC_HEAD_RANK
            entry.update(title=rank_name(faction, b["rank"]), head=b["rank"] >= GENERIC_HEAD_RANK)
        out.append(entry)
    out.sort(key=lambda e: (-e["level"], e["name"].lower()))
    return out


async def _company_roster(company_id: int) -> tuple[list[dict], dict]:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM companies WHERE company_id=?", (company_id,)) as cur:
            comp = await cur.fetchone()
        async with db.execute(
                "SELECT cm.user_id, cm.poste, cm.activity_score, u.full_name, u.username FROM company_members cm "
                "LEFT JOIN users u ON u.user_id=cm.user_id WHERE cm.company_id=?", (company_id,)) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
    comp = dict(comp) if comp else {}
    out = []
    for r in rows:
        lvl = COMPANY_RANKS.index(r["poste"]) if r["poste"] in COMPANY_RANKS else 0
        is_owner = r["user_id"] == comp.get("owner_id")
        if is_owner:
            lvl = len(COMPANY_RANKS)
        out.append({"user_id": r["user_id"], "name": r["full_name"] or r["username"] or str(r["user_id"]),
                    "username": r["username"] or "", "title": "PDG (fondateur)" if is_owner else r["poste"],
                    "place": "", "activity": r["activity_score"], "duty": False, "level": lvl,
                    "head": is_owner or r["poste"] in ("PDG", "Directeur")})
    out.sort(key=lambda e: (-e["level"], e["name"].lower()))
    return out, comp


async def roster(viewer_id: int, kind: str) -> dict:
    """kind = 'faction' | 'company'. → {'title', 'members', 'can_see_activity', 'error'}
    Tout membre voit le nom, le pseudo, l'ID et le poste ; seule la direction voit l'activité."""
    mem = await membership(viewer_id)
    if kind == "faction":
        m = mem["faction"]
        if not m:
            return {"error": "Tu ne fais partie d'aucune faction."}
        members = await _faction_roster(m["faction"])
        me = next((e for e in members if e["user_id"] == viewer_id), None)
        return {"title": channel_title(fcode(m["faction"])), "members": members,
                "can_see_activity": bool(me and me["head"]), "kind": kind}
    c = mem["company"]
    if not c:
        return {"error": "Tu ne travailles dans aucune entreprise."}
    members, comp = await _company_roster(c["company_id"])
    me = next((e for e in members if e["user_id"] == viewer_id), None)
    return {"title": f"🏢 {comp.get('name', 'Entreprise')}", "members": members,
            "can_see_activity": bool(me and me["head"]), "kind": kind}
