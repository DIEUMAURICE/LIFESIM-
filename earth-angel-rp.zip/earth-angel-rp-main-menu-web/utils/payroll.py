# utils/payroll.py — salaires automatiques chaque fin de jour de jeu
"""
Entreprises : chaque employé (hors créateur) reçoit son `base_salary` depuis la trésorerie,
SANS approbation du créateur. Si la trésorerie ne couvre pas la paie du jour : personne n'est
payé ce jour-là, la réputation baisse, employés et créateur sont notifiés.

Factions gouvernementales : salaire du rang, payé depuis le budget de la faction ; budget
insuffisant → paie proportionnelle (partielle) + notification.

Garanties :
• `payroll_log` (clé primaire kind/entity/user/jour) → un joueur n'est JAMAIS payé deux fois
  pour le même jour de jeu, même si la tâche est relancée.
• Une transaction par entreprise/faction ; les notifications partent APRÈS le commit.
"""
import logging

import aiosqlite

from config import GOV_FACTIONS
from database import db_connection, now
from utils.gamerules import bot_pct
from utils.notify import notify

logger = logging.getLogger(__name__)

DAY = 86400
COMPANY_BATCH = 100


def game_day() -> int:
    return now() // DAY


# ─────────────────────────────────────────────────────────────────────────────
# Entreprises
# ─────────────────────────────────────────────────────────────────────────────
async def pay_company(company_id: int, day: int | None = None) -> dict:
    """Paie une entreprise pour `day`. Retourne un résumé (utile aux tests)."""
    day = game_day() if day is None else day
    notes: list[tuple[int, str, str, str]] = []
    result = {"company_id": company_id, "status": "none", "total": 0, "count": 0}
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT company_id, name, owner_id, treasury FROM companies "
                "WHERE company_id=? AND dissolved=0", (company_id,)) as cur:
                comp = await cur.fetchone()
            if not comp:
                await db.rollback()
                return result
            async with db.execute(
                "SELECT cm.user_id, COALESCE(cm.base_salary, cm.salary, 0) AS amount "
                "FROM company_members cm "
                "WHERE cm.company_id=? AND cm.user_id<>? "
                "AND COALESCE(cm.base_salary, cm.salary, 0) > 0 "
                "AND NOT EXISTS (SELECT 1 FROM payroll_log p WHERE p.kind='company' AND p.entity=? "
                "                AND p.user_id=cm.user_id AND p.day=?)",
                (company_id, comp["owner_id"], str(company_id), day)) as cur:
                due = [(r["user_id"], int(r["amount"])) for r in await cur.fetchall()]
            if not due:
                await db.rollback()
                return result
            total = sum(a for _, a in due)
            name = comp["name"]
            if comp["treasury"] >= total:
                await db.execute("UPDATE companies SET treasury=treasury-? WHERE company_id=?",
                                 (total, company_id))
                for uid, amount in due:
                    await db.execute(
                        "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                        (amount, amount, uid))
                    await db.execute("INSERT INTO payroll_log VALUES ('company',?,?,?,?,'paid')",
                                     (str(company_id), uid, day, amount))
                    notes.append((uid, "💰 Salaire reçu",
                                  f"<b>{name}</b> t'a versé ton salaire du jour : <b>+{amount:,}</b>", "economy"))
                await db.execute(
                    "INSERT INTO company_logs (company_id,action,actor_id,details,timestamp) VALUES (?,?,?,?,?)",
                    (company_id, "payroll_auto", 0, f"{len(due)} salaires, total {total}", now()))
                result.update(status="paid", total=total, count=len(due))
            else:
                for uid, amount in due:
                    await db.execute("INSERT INTO payroll_log VALUES ('company',?,?,?,?,'unpaid')",
                                     (str(company_id), uid, day, amount))
                    notes.append((uid, "⚠️ Salaire impayé",
                                  f"<b>{name}</b> n'a pas pu payer ton salaire du jour "
                                  f"(<b>{amount:,}</b>) : trésorerie insuffisante.", "warning"))
                await db.execute("UPDATE companies SET reputation=MAX(0, reputation-5) WHERE company_id=?",
                                 (company_id,))
                await db.execute(
                    "INSERT INTO company_logs (company_id,action,actor_id,details,timestamp) VALUES (?,?,?,?,?)",
                    (company_id, "payroll_failed", 0,
                     f"paie impossible : besoin {total}, trésorerie {comp['treasury']}", now()))
                notes.append((comp["owner_id"], "🚨 Paie impossible",
                              f"<b>{name}</b> : il faut <b>{total:,}</b> pour payer {len(due)} employé(s), "
                              f"la trésorerie n'a que <b>{comp['treasury']:,}</b>. Réputation -5. "
                              f"👉 le menu pour renflouer.", "warning"))
                result.update(status="unpaid", total=total, count=len(due))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    for uid, title, msg, kind in notes:
        await notify(uid, title, msg, kind)
    return result


async def run_company_payroll() -> None:
    day = game_day()
    last_id = 0
    while True:
        async with db_connection() as db:
            async with db.execute(
                "SELECT company_id FROM companies WHERE dissolved=0 AND company_id>? "
                "ORDER BY company_id LIMIT ?", (last_id, COMPANY_BATCH)) as cur:
                ids = [r[0] for r in await cur.fetchall()]
        if not ids:
            break
        for cid in ids:
            try:
                await pay_company(cid, day)
            except Exception:
                logger.exception("Paie entreprise %s impossible", cid)
        last_id = ids[-1]


# ─────────────────────────────────────────────────────────────────────────────
# Factions gouvernementales
# ─────────────────────────────────────────────────────────────────────────────
async def pay_faction(key: str, day: int | None = None) -> dict:
    day = game_day() if day is None else day
    fdata = GOV_FACTIONS[key]
    ranks = fdata["ranks"]
    notes: list[tuple[int, str, str, str]] = []
    result = {"faction": key, "status": "none", "total": 0, "paid": 0, "count": 0}
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES (?,0)", (key,))
            async with db.execute(
                "SELECT fm.user_id, fm.rank FROM faction_members fm WHERE fm.faction=? "
                "AND NOT EXISTS (SELECT 1 FROM payroll_log p WHERE p.kind='faction' AND p.entity=? "
                "                AND p.user_id=fm.user_id AND p.day=?)",
                (key, key, day)) as cur:
                due = [(r["user_id"], ranks[min(r["rank"], len(ranks) - 1)][1]) for r in await cur.fetchall()]
            if not due:
                await db.rollback()
                return result
            async with db.execute("SELECT budget FROM faction_state WHERE faction=?", (key,)) as cur:
                budget = (await cur.fetchone())["budget"]
            total = sum(a for _, a in due)
            ratio = 1.0 if budget >= total else (budget / total if total else 0)
            paid_total = 0
            for uid, amount in due:
                pay = int(amount * ratio)
                paid_total += pay
                if pay > 0:
                    await db.execute(
                        "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                        (pay, pay, uid))
                await db.execute("INSERT INTO payroll_log VALUES ('faction',?,?,?,?,?)",
                                 (key, uid, day, pay, "paid" if ratio >= 1 else "partial"))
                if ratio >= 1:
                    notes.append((uid, "💰 Solde reçu",
                                  f"{fdata['emoji']} <b>{fdata['name']}</b> : salaire du jour <b>+{pay:,}</b>", "economy"))
                else:
                    notes.append((uid, "⚠️ Solde partiel",
                                  f"{fdata['emoji']} <b>{fdata['name']}</b> : budget insuffisant, "
                                  f"tu reçois <b>{pay:,}</b> sur {amount:,}.", "warning"))
            await db.execute("UPDATE faction_state SET budget=budget-? WHERE faction=?", (paid_total, key))
            await db.commit()
            result.update(status="paid" if ratio >= 1 else "partial", total=total,
                          paid=paid_total, count=len(due))
        except Exception:
            await db.rollback()
            raise
    for uid, title, msg, kind in notes:
        await notify(uid, title, msg, kind)
    return result


async def fund_factions(day: int | None = None) -> None:
    """Dotation quotidienne : l'État (impôts collectés) finance chaque faction jusqu'à son budget
    journalier ; l'éventuel manque est comblé par une dotation de base (GOV_MINT_RATIO)."""
    from config import GOV_MINT_RATIO
    day = game_day() if day is None else day
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES ('_state',0)")
            # Une seule dotation par jour de jeu (relance sans effet)
            cur = await db.execute(
                "INSERT OR IGNORE INTO payroll_log VALUES ('funding','all',0,?,0,'done')", (day,))
            if not cur.rowcount:
                await db.rollback()
                return
            async with db.execute("SELECT budget FROM faction_state WHERE faction='_state'") as c:
                state = (await c.fetchone())[0]
            # 🏛️ Un haut dirigeant de l'Administration est en place : c'est lui qui répartit le Trésor public
            # (console de l'Administration). Le bot ne verse alors que la dotation de base (GOV_MINT_RATIO).
            from config import PRESIDENT_FACTION
            from utils.treasury import GRANT_MIN_RANK
            async with db.execute("SELECT COUNT(*) FROM faction_members WHERE faction=? AND rank>=?",
                                  (PRESIDENT_FACTION, GRANT_MIN_RANK)) as c:
                admin_leads = (await c.fetchone())[0]
            if admin_leads:
                state = 0
            for key, fd in GOV_FACTIONS.items():
                await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES (?,0)", (key,))
                want = fd["daily_budget"]
                from_state = min(state, want)
                state -= from_state
                minted = int((want - from_state) * GOV_MINT_RATIO)
                await db.execute("UPDATE faction_state SET budget=budget+? WHERE faction=?",
                                 (from_state + minted, key))
            if not admin_leads:
                await db.execute("UPDATE faction_state SET budget=? WHERE faction='_state'", (state,))
            await db.commit()
        except Exception:
            await db.rollback()
            raise


async def run_faction_payroll() -> None:
    await fund_factions()
    for key, fd in GOV_FACTIONS.items():
        if fd.get("hourly"):      # payée toutes les heures de jeu par utils/sante.run_sante_payroll
            continue
        try:
            await pay_faction(key)
        except Exception:
            logger.exception("Paie faction %s impossible", key)


async def run_payroll() -> None:
    """Tâche planifiée (1×/jour de jeu) : production des entreprises, puis paie entreprises + factions."""
    # La production tourne désormais CHAQUE HEURE de jeu (run_hourly_production) : les ventes du jour
    # ont déjà alimenté les trésoreries avant cette paie de fin de journée.
    await run_company_payroll()
    await run_faction_payroll()


# ══════════════════════════════════════════════════════════════════════
#  PRODUCTION DES ENTREPRISES — activité → produits → vente PNJ (ex utils/company_production.py)
# ══════════════════════════════════════════════════════════════════════
import math
import inspect
from config import SECTOR_PRODUCTION, PRODUCTION_LEVELS
from config_chain import RECIPES, RECIPES_BY_SECTOR, GENERAL_EFFICIENCY, NPC_SUPPLY_MARKUP, INTRANTS, NPC_SUPPLY_DAILY


async def record_activity(company_id: int, points: int, day: int | None = None, dept: str = "") -> None:
    """Ajoute des points d'activité à la journée de l'entreprise (total + équipe du salarié)."""
    if points <= 0:
        return
    day = game_day() if day is None else day
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO company_activity(company_id, day, points) VALUES (?,?,?) "
            "ON CONFLICT(company_id, day) DO UPDATE SET points=points+excluded.points",
            (company_id, day, points))
        await db.execute(
            "INSERT INTO company_dept_activity(company_id, dept, day, points) VALUES (?,?,?,?) "
            "ON CONFLICT(company_id, dept, day) DO UPDATE SET points=points+excluded.points",
            (company_id, dept or "", day, points))
        await db.commit()


async def get_level(company_id: int) -> int:
    async with db_connection() as db:
        async with db.execute(
                "SELECT level FROM company_production_state WHERE company_id=?", (company_id,)) as cur:
            row = await cur.fetchone()
    return int(row[0]) if row else 2


async def set_level(company_id: int, level: int) -> bool:
    if level not in PRODUCTION_LEVELS:
        return False
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO company_production_state(company_id, level) VALUES (?,?) "
            "ON CONFLICT(company_id) DO UPDATE SET level=excluded.level", (company_id, level))
        await db.commit()
    return True


async def get_stock(company_id: int) -> dict[str, int]:
    async with db_connection() as db:
        async with db.execute(
                "SELECT product, quantity FROM company_stock WHERE company_id=? AND quantity>0",
                (company_id,)) as cur:
            return {r[0]: r[1] for r in await cur.fetchall()}


class _Plan:
    """État mutable d'une journée de production (copié pour tester la faisabilité)."""

    def __init__(self, stock, pools, treasury, supply_left, level_cost):
        self.stock = dict(stock)
        self.pools = dict(pools)              # {équipe: points restants} ('' = polyvalents, efficacité réduite)
        self.treasury = treasury
        self.supply_left = dict(supply_left)  # {intrant: unités achetables au fournisseur national aujourd'hui}
        self.level_cost = level_cost
        self.spent_supply = 0
        self.spent_steps = 0
        self.lots: list[tuple[str, int]] = []  # (étape, lots)
        self.bought: dict[str, int] = {}

    def copy(self):
        c = _Plan(self.stock, self.pools, self.treasury, self.supply_left, self.level_cost)
        c.spent_supply, c.spent_steps = self.spent_supply, self.spent_steps
        c.lots, c.bought = list(self.lots), dict(self.bought)
        return c

    def take_points(self, dept: str, pts: int) -> bool:
        own = self.pools.get(dept, 0)
        use = min(own, pts)
        rest = pts - use
        gen_pts = 0
        if rest > 0:
            gen_pts = int(math.ceil(rest / GENERAL_EFFICIENCY))
            if self.pools.get("", 0) < gen_pts:
                return False
        self.pools[dept] = own - use
        if gen_pts:
            self.pools[""] = self.pools.get("", 0) - gen_pts
        return True


def _try_recipe(plan: _Plan, recipe: str, final_lots: int) -> bool:
    """Réserve ressources/points/trésorerie pour `final_lots` lots de l'étape finale (et ses amonts). Modifie plan."""
    steps = RECIPES[recipe]["steps"]
    need_out = {steps[-1]["out"][0]: final_lots * steps[-1]["out"][1]}
    plan_lots: list[tuple[dict, int]] = []
    raw_need: dict[str, int] = {}
    for st in reversed(steps):
        good, qty_out = st["out"]
        want = need_out.get(good, 0)
        if good != recipe:                    # un intermédiaire déjà en stock est utilisé d'abord
            have = plan.stock.get(good, 0)
            want = max(0, want - have)
        lots = int(math.ceil(want / qty_out)) if want > 0 else 0
        if good == recipe:
            lots = final_lots
        plan_lots.append((st, lots))
        for g, q in st["in"].items():
            tot = lots * q
            if g in INTRANTS:
                raw_need[g] = raw_need.get(g, 0) + tot
            else:
                need_out[g] = need_out.get(g, 0) + tot
    # intrants : stock d'abord, puis fournisseur national (plus cher, plafonné)
    for g, tot in raw_need.items():
        take = min(plan.stock.get(g, 0), tot)
        gap = tot - take
        if gap > 0:
            if gap > plan.supply_left.get(g, 0):
                return False
            price = int(round(INTRANTS[g]["ref"] * NPC_SUPPLY_MARKUP))
            if plan.treasury < gap * price + 0:
                return False
            plan.treasury -= gap * price
            plan.spent_supply += gap * price
            plan.supply_left[g] -= gap
            plan.bought[g] = plan.bought.get(g, 0) + gap
        plan.stock[g] = plan.stock.get(g, 0) - take
    for st, lots in reversed(plan_lots):
        if lots <= 0:
            continue
        pts = lots * st["effort"]
        cost = int(round(lots * st["cost"] * plan.level_cost))
        if plan.treasury < cost or not plan.take_points(st["dept"], pts):
            return False
        plan.treasury -= cost
        plan.spent_steps += cost
        good, qty_out = st["out"]
        for g, q in st["in"].items():
            if g not in INTRANTS:
                use = min(plan.stock.get(g, 0), lots * q)
                plan.stock[g] = plan.stock.get(g, 0) - use
        plan.stock[good] = plan.stock.get(good, 0) + lots * qty_out
        plan.lots.append((st["name"], lots))
    return True


def _best_lots(plan: _Plan, recipe: str, max_lots: int) -> int:
    lo, hi = 0, max_lots
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if _try_recipe(plan.copy(), recipe, mid):
            lo = mid
        else:
            hi = mid - 1
    return lo


async def produce_company(company_id: int, day: int | None = None, hour: int | None = None) -> dict:
    """Production d'une entreprise : lignes → étapes par équipe → stock, puis vente au marché national
    (plafonnée), XP, objectif quotidien, passage de stade. Retourne un résumé (utile aux tests).

    • `hour=None`  : mode « jour complet » (tous les plafonds du jour d'un coup).
    • `hour=0..23` : mode HORAIRE — les plafonds du jour se débloquent à raison de (heure+1)/24 : la production
      suit le rythme des équipes au fil de la journée de jeu. Un seul passage par entreprise et par heure
      (idempotent) ; le bilan est envoyé aux patrons à la dernière heure (23), l'objectif du jour y est jugé."""
    from config_chain import (RECIPES, STAGES, MAX_STAGE, clamp_stage, stage_cap, stage_name, GENERAL_EFFICIENCY,
                              NPC_SUPPLY_MARKUP, NPC_SUPPLY_DAILY, TARGET_MET_XP, TARGET_MET_REP,
                              TARGET_MISSED_RATIO, TARGET_MISSED_REP, npc_price, INTRANTS, good_label)
    import utils.chain as ch
    day = game_day() if day is None else day
    hourly = hour is not None
    frac = (hour + 1) / 24 if hourly else 1.0
    final = (not hourly) or hour == 23
    result = {"company_id": company_id, "status": "none", "produced": 0, "sold": 0,
              "cost": 0, "revenue": 0, "blocked": 0, "xp": 0, "stage_up": False, "met": None}
    notes: list[tuple[int, str, str, str]] = []
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                    "SELECT company_id, name, owner_id, sector, treasury, level, reputation FROM companies "
                    "WHERE company_id=? AND dissolved=0", (company_id,)) as cur:
                comp = await cur.fetchone()
            if not comp or comp["sector"] not in RECIPES_BY_SECTOR:
                await db.rollback()
                return result
            if hourly and await ch._daily_get(db, "hour", company_id, "run", day * 24 + hour) > 0:
                await db.rollback()          # cette heure a déjà été produite
                return result
            stage = clamp_stage(comp["level"])
            cap_mult = stage_cap(stage)
            await db.execute("INSERT OR IGNORE INTO company_production_state(company_id) VALUES (?)", (company_id,))
            await db.execute("INSERT OR IGNORE INTO company_chain(company_id) VALUES (?)", (company_id,))
            async with db.execute("SELECT level FROM company_production_state WHERE company_id=?",
                                  (company_id,)) as cur:
                lvl = (await cur.fetchone())["level"]
            lv = PRODUCTION_LEVELS.get(lvl, PRODUCTION_LEVELS[2])
            async with db.execute("SELECT npc_share, xp FROM company_chain WHERE company_id=?",
                                  (company_id,)) as cur:
                chs = await cur.fetchone()
            npc_share = float(chs["npc_share"])
            lines = await ch.ensure_default_line(db, company_id, comp["sector"])

            pools: dict[str, int] = {}
            async with db.execute(
                    "SELECT dept, SUM(points-consumed) FROM company_dept_activity WHERE company_id=? AND day<=? "
                    "GROUP BY dept", (company_id, day)) as cur:
                for r in await cur.fetchall():
                    if r[1] and r[1] > 0:
                        pools[r[0]] = int(r[1])
            async with db.execute("SELECT product, quantity FROM company_stock WHERE company_id=? AND quantity>0",
                                  (company_id,)) as cur:
                stock = {r[0]: int(r[1]) for r in await cur.fetchall()}
            supply_pct = await bot_pct("npc_supply")          # ⚙️ rôle du bot réglé par le staff (0 % = fermé)
            orders_pct = await bot_pct("npc_orders")
            supply_left = {}
            for g in INTRANTS:
                used = await ch._daily_get(db, "supply", company_id, g, day)
                supply_left[g] = max(0, int(NPC_SUPPLY_DAILY * cap_mult * frac * supply_pct / 100) - used)

            plan = _Plan(stock, pools, comp["treasury"] or 0, supply_left, lv["cost"])
            start_treasury = plan.treasury
            made: dict[str, int] = {}
            blocked = 0
            for rk in lines:
                r = RECIPES[rk]
                final_q = r["steps"][-1]["out"][1]
                done_today = await ch._daily_get(db, "made", company_id, rk, day)
                target = max(0, int(round(r["base_cap"] * cap_mult * lv["units"] * frac)) - done_today)
                room = max(0, 3 * int(r["base_cap"] * cap_mult) - plan.stock.get(rk, 0))   # stock plafonné
                target = min(target, room)
                max_lots = int(math.ceil(target / final_q)) if target > 0 else 0
                lots = _best_lots(plan, rk, max_lots)
                if lots < max_lots:
                    blocked += (max_lots - lots) * final_q
                if lots:
                    _try_recipe(plan, rk, lots)
                    made[rk] = lots * final_q
                    await ch._daily_add(db, "made", company_id, rk, day, lots * final_q)
            # mouvements : consommer points, stock, achats
            for g, qty in plan.bought.items():
                await ch._daily_add(db, "supply", company_id, g, day, qty)
            for dept, left in plan.pools.items():
                before = pools.get(dept, 0)
                if before - left > 0:
                    await _consume_points(db, company_id, dept, day, before - left)
            for k in set(stock) | set(plan.stock):
                q = plan.stock.get(k, 0)
                await db.execute(
                    "INSERT INTO company_stock(company_id, product, quantity) VALUES (?,?,?) "
                    "ON CONFLICT(company_id, product) DO UPDATE SET quantity=excluded.quantity",
                    (company_id, k, max(0, q)))
            cost = plan.spent_steps + plan.spent_supply
            treasury = plan.treasury

            # ── Marché national : commandes plafonnées × part réservée aux PNJ ──
            sold_total = revenue = 0
            ordered_total = 0
            for rk in lines:
                r = RECIPES[rk]
                orders = int(math.ceil(r["base_cap"] * cap_mult * npc_share * frac * orders_pct / 100))
                already = await ch._daily_get(db, "npc", company_id, rk, day)
                orders = max(0, orders - already)
                ordered_total += orders
                qty = min(plan.stock.get(rk, 0), orders)
                if qty > 0:
                    price = npc_price(rk)
                    revenue += qty * price
                    sold_total += qty
                    plan.stock[rk] -= qty
                    await db.execute("UPDATE company_stock SET quantity=? WHERE company_id=? AND product=?",
                                     (plan.stock[rk], company_id, rk))
                    await ch._daily_add(db, "npc", company_id, rk, day, qty)
            treasury += revenue
            from utils.treasury import _flow, collect
            if plan.spent_supply > 0:                  # intrants payés au bot → Trésor public de l'Administration
                await collect(db, plan.spent_supply, "intrants")
                await _flow(db, "npc_supply", "bot", plan.spent_supply)
            if revenue > 0:                            # argent créé par le marché national
                await _flow(db, "npc_orders", "created", revenue)

            units = sum(made.values())
            # ── XP, objectif, réputation ──
            xp_gain = sum(RECIPES[rk]["xp"] * q for rk, q in made.items())
            met = None
            rep_delta = 0
            if hourly:
                # objectif jugé une seule fois par jour (heure 23), sur le cumul du jour
                sold_day = ordered_day = 0
                if final:
                    for rk in lines:
                        sold_day += await ch._daily_get(db, "npc", company_id, rk, day)
                        ordered_day += int(math.ceil(RECIPES[rk]["base_cap"] * cap_mult * npc_share))
                if final and lines and npc_share > 0 and ordered_day > 0:
                    met = sold_day >= ordered_day
                    if met:
                        xp_gain += TARGET_MET_XP
                        rep_delta = TARGET_MET_REP
                    elif sold_day < TARGET_MISSED_RATIO * ordered_day:
                        rep_delta = -TARGET_MISSED_REP
            elif lines and npc_share > 0 and ordered_total > 0:
                met = sold_total >= ordered_total
                if met:
                    xp_gain += TARGET_MET_XP
                    rep_delta = TARGET_MET_REP
                elif sold_total < TARGET_MISSED_RATIO * ordered_total:
                    rep_delta = -TARGET_MISSED_REP
            rep = max(0, min(100, int(comp["reputation"] or 0) + rep_delta))
            await db.execute("UPDATE companies SET treasury=?, reputation=? WHERE company_id=?",
                             (treasury, rep, company_id))
            new_xp = int(chs["xp"]) + xp_gain
            await db.execute("UPDATE company_chain SET xp=?, produced_total=produced_total+?, "
                             "revenue_total=revenue_total+? WHERE company_id=?",
                             (new_xp, units, revenue, company_id))
            await db.execute(
                "INSERT INTO company_production_log(company_id, day, produced, sold, cost, revenue) "
                "VALUES (?,?,?,?,?,?) ON CONFLICT(company_id, day) DO UPDATE SET "
                "produced=produced+excluded.produced, sold=sold+excluded.sold, "
                "cost=cost+excluded.cost, revenue=revenue+excluded.revenue",
                (company_id, day, units, sold_total, cost, revenue))
            await db.execute(
                "INSERT INTO company_logs (company_id,action,actor_id,details,timestamp) VALUES (?,?,?,?,?)",
                (company_id, "production_auto", 0,
                 f"{units} produits, {sold_total} vendus, coût {cost}, revenu {revenue}", now()))

            # ── Passage de stade ──
            stage_up = False
            async with db.execute("SELECT COUNT(*) FROM company_members WHERE company_id=?", (company_id,)) as cur:
                staff = (await cur.fetchone())[0]
            if stage < MAX_STAGE:
                nx = STAGES[stage]
                if (new_xp >= nx["xp"] and staff >= nx["staff"] and rep >= nx["rep"] and treasury >= nx["treasury"]):
                    await db.execute("UPDATE companies SET level=? WHERE company_id=?", (stage + 1, company_id))
                    stage_up = True
            async with db.execute(
                    "SELECT user_id FROM company_members WHERE company_id=? AND role IN ('owner','manager')",
                    (company_id,)) as cur:
                bosses = {r[0] for r in await cur.fetchall()} | {comp["owner_id"]}

            if hourly:
                await ch._daily_add(db, "hour", company_id, "run", day * 24 + hour, 1)
            net = revenue - cost
            if hourly and final:
                async with db.execute("SELECT produced, sold, cost, revenue FROM company_production_log "
                                      "WHERE company_id=? AND day=?", (company_id, day)) as cur:
                    dl = await cur.fetchone()
                if dl:
                    units, sold_total, cost, revenue = dl[0], dl[1], dl[2], dl[3]
                    net = revenue - cost
                made = {"__day__": units} if units else {}
            lines_txt = [f"📦 Produit : " + (", ".join(f"<b>{q}</b> × {RECIPES[k]['name']}" if k in RECIPES else f"<b>{q}</b> unité(s) sur la journée" for k, q in made.items()) or "rien"),
                         f"💸 Coûts (étapes + fournisseur national) : <b>-{cost:,}</b>",
                         f"🛒 Marché national : <b>{sold_total}</b> vendu(s) → <b>+{revenue:,}</b>",
                         f"📊 Bilan net : <b>{'+' if net >= 0 else ''}{net:,}</b> · 🏦 Trésorerie : <b>{treasury:,}</b>",
                         f"✨ XP +{xp_gain} (total {new_xp:,})"]
            if met is True:
                lines_txt.append("🎯 Objectif du jour atteint : réputation +1.")
            elif met is False and rep_delta < 0:
                lines_txt.append("📉 Objectif très loin : réputation -1.")
            if blocked:
                lines_txt.append(f"⚠️ <b>{blocked}</b> unité(s) non produites : manque d'intrants, d'activité d'équipe "
                                 "ou de trésorerie.")
            if stage_up:
                lines_txt.append(f"🎉 <b>{comp['name']} passe au stade {STAGES[stage]['name']} !</b> "
                                 "Plus de lignes, plus de capacité.")
            if final or stage_up:
                for b in bosses:
                    notes.append((b, f"🏭 Bilan du jour — {comp['name']}", "\n".join(lines_txt),
                                  "warning" if blocked else "economy"))
            result.update(status="blocked" if blocked else "ok", produced=units, sold=sold_total,
                          cost=cost, revenue=revenue, blocked=blocked, xp=xp_gain, stage_up=stage_up, met=met)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    for uid, title, msg, kind in notes:
        notification_result = notify(uid, title, msg, kind)
        if inspect.isawaitable(notification_result):
            await notification_result
    return result


async def _consume_points(db, company_id: int, dept: str, day: int, pts: int) -> None:
    """Consomme `pts` points d'une équipe, des plus anciens jours aux plus récents."""
    async with db.execute(
            "SELECT day, points-consumed FROM company_dept_activity WHERE company_id=? AND dept=? AND day<=? "
            "AND points>consumed ORDER BY day", (company_id, dept, day)) as cur:
        rows = await cur.fetchall()
    for d, avail in rows:
        if pts <= 0:
            break
        take = min(avail, pts)
        await db.execute("UPDATE company_dept_activity SET consumed=consumed+? WHERE company_id=? AND dept=? AND day=?",
                         (take, company_id, dept, d))
        pts -= take


async def run_company_production(hour: int | None = None, day: int | None = None) -> None:
    """Fait produire toutes les entreprises. `hour` (0-23 de jeu) = production horaire (voir produce_company)."""
    day = game_day() if day is None else day
    last_id = 0
    while True:
        async with db_connection() as db:
            async with db.execute(
                    "SELECT company_id FROM companies WHERE dissolved=0 AND company_id>? "
                    "ORDER BY company_id LIMIT ?", (last_id, COMPANY_BATCH)) as cur:
                ids = [r[0] for r in await cur.fetchall()]
        if not ids:
            break
        for cid in ids:
            try:
                await produce_company(cid, day, hour)
            except Exception:
                logger.exception("Production entreprise %s impossible", cid)
        last_id = ids[-1]


async def run_hourly_production() -> None:
    """Tâche planifiée (chaque heure de jeu) : production horaire de toutes les entreprises."""
    t = now()
    await run_company_production(hour=(t % DAY) // 3600, day=t // DAY)


async def diagnose(company_id: int, day: int | None = None) -> dict:
    """Pourquoi une entreprise produit (ou pas) : équipe en service, activité disponible, trésorerie et, pour chaque
    ligne active, ce qu'il faut pour UN lot et ce qui manque. Lecture seule."""
    from config_chain import RECIPES, clamp_stage, stage_cap, NPC_SUPPLY_DAILY, INTRANTS, sector_depts
    import utils.chain as ch
    day = game_day() if day is None else day
    out: dict = {"members": 0, "on_duty": 0, "pools": {}, "treasury": 0, "lines": []}
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT sector, treasury, level FROM companies WHERE company_id=? AND dissolved=0",
                              (company_id,)) as cur:
            comp = await cur.fetchone()
        if not comp or comp["sector"] not in RECIPES_BY_SECTOR:
            return out
        async with db.execute(
                "SELECT COUNT(*), SUM(CASE WHEN d.user_id IS NOT NULL THEN 1 ELSE 0 END) FROM company_members cm "
                "LEFT JOIN work_duty d ON d.user_id=cm.user_id WHERE cm.company_id=?", (company_id,)) as cur:
            r = await cur.fetchone()
            out["members"], out["on_duty"] = int(r[0] or 0), int(r[1] or 0)
        async with db.execute("SELECT level FROM company_production_state WHERE company_id=?", (company_id,)) as cur:
            row = await cur.fetchone()
        lv = PRODUCTION_LEVELS.get(row["level"] if row else 2, PRODUCTION_LEVELS[2])
        async with db.execute("SELECT dept, SUM(points-consumed) FROM company_dept_activity WHERE company_id=? AND day<=? "
                              "GROUP BY dept", (company_id, day)) as cur:
            pools = {r[0]: int(r[1]) for r in await cur.fetchall() if r[1] and r[1] > 0}
        async with db.execute("SELECT product, quantity FROM company_stock WHERE company_id=? AND quantity>0",
                              (company_id,)) as cur:
            stock = {r[0]: int(r[1]) for r in await cur.fetchall()}
    cap_mult = stage_cap(clamp_stage(comp["level"]))
    supply = {g: int(NPC_SUPPLY_DAILY * cap_mult * await bot_pct("npc_supply") / 100) for g in INTRANTS}
    treasury = int(comp["treasury"] or 0)
    out["pools"], out["treasury"] = dict(pools), treasury
    huge = 10 ** 9
    depts = list(sector_depts(comp["sector"])) + [""]
    active = await ch.get_lines(company_id) or [RECIPES_BY_SECTOR[comp["sector"]][0]]   # la 1re recette démarre seule
    for rk in active:
        plan = _Plan(stock, pools, treasury, supply, lv["cost"])
        # besoin d'UN lot, avec des ressources illimitées
        inf = _Plan(stock, {d: huge for d in depts}, huge * 100, {g: huge for g in INTRANTS}, lv["cost"])
        need_pts = need_cost = 0
        if _try_recipe(inf, rk, 1):
            need_pts = sum(huge - inf.pools[d] for d in depts)
            need_cost = inf.spent_steps + inf.spent_supply
        ok = _try_recipe(plan.copy(), rk, 1)
        reason = None
        if not ok:
            t = plan.copy(); t.treasury = huge * 100
            p = plan.copy(); p.pools = {d: huge for d in depts}
            sp = plan.copy(); sp.supply_left = {g: huge for g in INTRANTS}
            if _try_recipe(t, rk, 1):
                reason = "treasury"
            elif _try_recipe(p, rk, 1):
                reason = "points"
            elif _try_recipe(sp, rk, 1):
                reason = "supply"
            else:
                reason = "points"
        out["lines"].append({"recipe": rk, "ok": ok, "reason": reason, "need_points": need_pts, "need_cost": need_cost,
                             "lots_now": _best_lots(plan, rk, 6) if ok else 0})
    return out
