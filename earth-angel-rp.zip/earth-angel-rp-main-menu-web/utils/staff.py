# utils/staff.py — la hiérarchie du STAFF (droits, nominations, révocation, recours)
"""
Hiérarchie du staff du jeu, d'après le document GAME FRENCH (parties « en jeu » seulement) :

    👑 Lead Principal ─ nomme/révoque tout le monde ; a toujours le dernier mot (recours)
    🎖️ Lead Staff     ─ nomme/révoque Game Leaders, Admins N2 et N1
    🎮 Game Leader    ─ nomme, promeut, révoque Admins N2 et N1
    🔴 Admin N2       ─ sanctions et conflits
    🟢 Admin N1       ─ support et signalements
    👨‍💻 Lead Studio    ─ technique, transversal : ne donne aucun ordre au staff

Règles : chaque niveau hérite des permissions du niveau inférieur ; toute révocation est MOTIVÉE et notifiée ;
le révoqué peut faire recours auprès du Lead Principal pendant STAFF_APPEAL_DAYS jours.
Aucune mécanique d'organisation interne (revenus, horaires, primes) n'est reprise.
"""
from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timedelta, timezone

import aiosqlite

from config import (
    GAME_LEADER_IDS, ROLE_HIERARCHY, ROLE_LABELS, STAFF_APPEAL_DAYS, STAFF_SLOTS, STAFF_TIMEZONE,
    can_manage_role, role_level,
)

logger = logging.getLogger(__name__)

BADGES = {
    "LEAD_PRINCIPAL": "👑", "LEAD_STUDIO": "👨‍💻", "LEAD_INFLUENCEURS": "📣", "LEAD_STAFF_GLOBAL": "🎖️",
    "GAME_LEADER": "🎮", "ADMIN_N2": "🔴", "ADMIN_N1": "🟢", "PLAYER": "👤",
}
NOMINABLE = ("LEAD_STAFF_GLOBAL", "GAME_LEADER", "ADMIN_N2", "ADMIN_N1", "LEAD_STUDIO", "LEAD_INFLUENCEURS")      # rôles attribuables en BDD
ROLE_ALIASES = {
    "lead_staff": "LEAD_STAFF_GLOBAL", "leadstaff": "LEAD_STAFF_GLOBAL", "lsg": "LEAD_STAFF_GLOBAL",
    "game_leader": "GAME_LEADER", "gameleader": "GAME_LEADER", "gl": "GAME_LEADER",
    "admin_n2": "ADMIN_N2", "n2": "ADMIN_N2", "admin_n1": "ADMIN_N1", "n1": "ADMIN_N1",
    "lead_studio": "LEAD_STUDIO", "studio": "LEAD_STUDIO",
    "lead_influenceurs": "LEAD_INFLUENCEURS", "influenceurs": "LEAD_INFLUENCEURS", "influ": "LEAD_INFLUENCEURS",
}
STAFF_ROLES_DESC = [r for r in reversed(ROLE_HIERARCHY) if r != "PLAYER"]


def badge(role: str) -> str:
    return BADGES.get(role, "❔")


def label(role: str) -> str:
    return ROLE_LABELS.get(role, role)


# ─────────────────────────────────────────────────────────────────────────────
#  CATALOGUE DES COMMANDES — alimente le panneau unique (/admin). Chaque niveau hérite des niveaux inférieurs.
# ─────────────────────────────────────────────────────────────────────────────
CATALOG: list[tuple[str, str, str, str, list[str]]] = [
    # (clé, emoji, titre, rôle minimum, lignes)
    ("support", "🟢", "Support & signalements", "ADMIN_N1", [
        "/reports_list · /report_handle id statut [réponse]  (les signalements arrivent ici : classe-les, transmets à un N2)",
        "/userinfo @u · /userstats @u · /topstats · /game_logs [période]",
        "/presence (confirmer ton arrivée au créneau) · /passation pb | à surveiller | suggestions",
        "<i>L'Admin N1 ne sanctionne pas : il recueille et transmet à un Admin N2.</i>"]),
    ("sanctions", "🔴", "Sanctions & conflits", "ADMIN_N2", [
        "<b>Chaque sanction exige un MOTIF</b>, envoyé tel quel au joueur et inscrit au journal.",
        "/warn @u motif · /clearwarn @u motif",
        "/banuser @u motif · /unbanuser @u motif",
        "/freezeuser @u secondes motif · /unfreezeuser @u motif",
        "/forceprison @u secondes motif · /freeprison @u motif",
        "/sethospital @u secondes motif · /settravel @u secondes motif",
        "/resetuser @u motif",
        "<i>Astuce : « | » isole le motif — /warn @u | spam répété.</i>",
        "/listusers [page] · /playerhistory @u · /audit @u (qui a fait quoi, à qui)"]),
    ("vitals", "❤️", "Corrections de profil", "ADMIN_N2", [
        "Motif obligatoire, envoyé au joueur :",
        "/sethp · /setenergy · /sethappiness · /sethunger · /setstress · /setage  @u valeur motif",
        "/setjob · /setdiplome · /setbio · /setcolor · /setlocation  @u valeur | motif",
        "/setskill @u skill niveau motif"]),
    ("sante", "🏥", "Santé publique", "ADMIN_N2", [
        "/nommer_dg hôpital @u · /sante_poste poste @u · /sante_renvoyer @u [motif]",
        "/sante_audit · /sante_lits [liberer hôpital|@u]",
        "/nommer_pdg @u · /revoquer_pdg [motif] (Game Leader)"]),
    ("equipe", "🛡️", "Équipe & créneaux", "GAME_LEADER", [
        "/creneau @u A|B|C|D|aucun · /creneaux (couverture) · /presences (7 jours) · /passations [n]",
        "/staff_nommer rôle @u · /staff_promouvoir @u · /revoquer @u motif",
        "/staff_liste · /staff_history @u",
        "<i>Rôles nommables : Game Leader (Lead Staff+), Admin N2/N1 (Game Leader+).</i>"]),
    ("items", "🎁", "Items, missions, événements", "GAME_LEADER", [
        "Motif obligatoire : /giveitem @u item qté motif · /takeitem @u item qté motif · /setitem @u item qté motif",
        "/clearinventory @u motif · /giveallitems @u",
        "/createevent \"nom\" durée effet · /endevent · /broadcast · /announce · /lotowin @u",
        "/mission_force @u mission prog · /resetmissions", "/listitems"]),
    ("gangs", "🏴", "Gangs, relations, coffres", "GAME_LEADER", [
        "/gang_create_admin · /gang_delete · /gang_add · /gang_remove", "/gang_set_treasury · /gang_set_reputation",
        "/setrelation · /setmarriage · /admin_divorce · /setfamily · /removefamily",
        "/coffre [faction] · /coffre_ajouter faction montant · /coffre_retirer faction montant"]),
    ("economie", "💰", "Économie lourde", "LEAD_STAFF_GLOBAL", [
        "<b>Motif obligatoire</b> (envoyé au joueur) : /addmoney · /removemoney · /setmoney  @u montant motif",
        "/addbank · /rembank · /setbank  @u montant | motif · /cleardebt @u motif",
        "/addprestige · /remprestige · /setprestige · /addxp · /remxp · /setxp · /setlevel  @u valeur motif",
        "/addkarma · /remkarma · /setkarma · /addsocialcoins · /remsocialcoins · /setsocialcoins  @u valeur motif",
        "/balance_stats [période]"]),
    ("monde", "🌍", "Marché, entreprises, patrimoine", "LEAD_STAFF_GLOBAL", [
        "/crashmarket · /boommarket · /resetmarket · /setprice asset N · /setstock asset N",
        "/setcompanytreasury · /setcompanyreputation · /setcompanylevel · /addcompanytreasury · /removetreasury",
        "/deletecompany · /listcompanies · /forcehire",
        "/setproperty · /setpropertycond · /setvehicle · /setvehiclecond · /setluxury · /setblackmarket",
        "/autoriser_groupe · /retirer_groupe · /groupes_autorises",
        "/maintenance on|off · /serverstats · /globalstats · /resetcooldown @u champ"]),
    ("campagnes", "📣", "Campagnes (Lead Influenceurs)", "LEAD_INFLUENCEURS", [
        "Lead Influenceurs : /campagne titre | message · /campagnes",
        "<i>Chaque campagne est relue par le Lead Staff Global avant diffusion aux joueurs.</i>",
        "Lead Staff Global+ : /campagnes (à traiter) · /campagne_valider id · /campagne_refuser id motif"]),
    ("dieu", "⚡", "Pouvoirs absolus", "LEAD_PRINCIPAL", [
        "/godmode @u on|off · /timetravel @u heures · /spawn @u argent xp prestige",
        "/killuser @u motif · /deleteuser @u confirm motif · /resetworld confirm",
        "/adminlogs · /admin_action_log [période] · /staff_nommer lead_influenceurs|lead_studio @u"]),
    ("studio", "👨‍💻", "Technique (Lead Studio)", "LEAD_STUDIO", [
        "/reloadconfig · /fix_inventory",
        "<i>Le Lead Studio ne donne aucun ordre au staff et ne sanctionne pas : il communique via le Lead Staff Global.</i>"]),
]


def visible_catalog(role: str) -> list[tuple[str, str, str, str, list[str]]]:
    """Sections accessibles à `role` (héritage vertical ; les rôles transverses ont leur section propre)."""
    from config import TRANSVERSE_ROLES
    lvl, out = role_level(role), []
    for sec in CATALOG:
        need = sec[3]
        if need in TRANSVERSE_ROLES:
            if role == need or role == "LEAD_PRINCIPAL" or (
                    need == "LEAD_INFLUENCEURS" and role not in TRANSVERSE_ROLES and lvl >= role_level("LEAD_STAFF_GLOBAL")):
                out.append(sec)
        elif role not in ("LEAD_INFLUENCEURS",) and lvl >= role_level(need):
            out.append(sec)
    return out


# ─────────────────────────────────────────────────────────────────────────────
#  NOMINATION / PROMOTION / RÉVOCATION (une seule logique pour toutes les commandes)
# ─────────────────────────────────────────────────────────────────────────────
async def nominate(actor_id: int, target_id: int, new_role: str, notes: str = "") -> tuple[bool, str]:
    from database import add_notification, assign_admin_role, log_admin_action
    from utils.decorators import get_user_role_async
    if new_role not in NOMINABLE:
        return False, "Rôle inconnu. Rôles : lead_staff · game_leader · n2 · n1."
    if actor_id == target_id:
        return False, "Tu ne peux pas te nommer toi-même."
    actor = await get_user_role_async(actor_id)
    if not can_manage_role(actor, new_role):
        return False, f"Ton rang ({label(actor)}) ne permet pas de nommer {label(new_role)}."
    current = await get_user_role_async(target_id)
    if current != "PLAYER" and not can_manage_role(actor, current):
        return False, f"Cette personne a déjà un rang que tu ne peux pas modifier ({label(current)})."
    if current == new_role:
        return False, f"Déjà {label(new_role)}."
    await assign_admin_role(actor_id, target_id, new_role, notes or "Nomination")
    await log_admin_action(actor_id, "staff_nommer", target_id, f"{current} → {new_role}. {notes}".strip())
    await add_notification(target_id, f"{badge(new_role)} Tu es nommé {label(new_role)}. Ouvre /admin pour ton panneau.")
    return True, f"{badge(new_role)} {label(new_role)}"


async def promote(actor_id: int, target_id: int) -> tuple[bool, str]:
    """Promotion N1 → N2 → Game Leader (au-dessus d'un Game Leader : nomination à la main)."""
    from utils.decorators import get_user_role_async
    nxt = {"ADMIN_N1": "ADMIN_N2", "ADMIN_N2": "GAME_LEADER"}.get(await get_user_role_async(target_id))
    if not nxt:
        return False, "Seuls un Admin N1 ou N2 se promeuvent (au-delà, utilise /staff_nommer)."
    return await nominate(actor_id, target_id, nxt, "Promotion")


async def revoke(actor_id: int, target_id: int, reason: str = "") -> tuple[bool, str]:
    from database import add_notification, log_admin_action, revoke_admin_role
    from utils.decorators import get_user_role_async
    if actor_id == target_id:
        return False, "Tu ne peux pas révoquer ton propre rôle."
    if not reason.strip():
        return False, "Une révocation doit être motivée : /revoquer @pseudo motif."
    actor = await get_user_role_async(actor_id)
    target = await get_user_role_async(target_id)
    if target == "PLAYER":
        return False, "Cette personne n'a aucun rôle staff."
    if not can_manage_role(actor, target):
        return False, f"Ton rang ({label(actor)}) ne permet pas de révoquer {label(target)}."
    old = await revoke_admin_role(actor_id, target_id)
    if not old:
        return False, "Aucun rôle attribué en base à révoquer (rôle permanent défini dans la configuration ?)."
    await log_admin_action(actor_id, "staff_revoquer", target_id, f"{old}. Motif : {reason}")
    await add_notification(target_id, f"⚠️ Ton rôle {label(old)} a été révoqué. Motif : {reason}. "
                                      f"Recours possible auprès du Lead Principal pendant {STAFF_APPEAL_DAYS} jours : /recours ton message.")
    return True, f"{badge(old)} {label(old)}"


async def appeal(user_id: int, message: str) -> tuple[bool, str]:
    """Recours d'un ancien membre du staff : prévient le Lead Principal (qui a le dernier mot)."""
    from config import LEAD_PRINCIPAL_IDS
    from database import add_notification, db_connection, log_admin_action, now
    from utils.gametime import game_seconds_to_real
    async with db_connection() as db:
        async with db.execute("SELECT role, revoked_at FROM admin_roles WHERE user_id=? AND revoked_at>0 "
                              "ORDER BY revoked_at DESC LIMIT 1", (user_id,)) as cur:
            row = await cur.fetchone()
    if not row:
        return False, "Aucune révocation à contester."
    if game_seconds_to_real(max(0, now() - row[1])) > STAFF_APPEAL_DAYS * 86400:
        return False, f"Le délai de recours ({STAFF_APPEAL_DAYS} jours) est dépassé."
    if not message.strip():
        return False, "Explique ta demande : /recours ton message."
    await log_admin_action(user_id, "staff_recours", 0, message[:200])
    for lp in LEAD_PRINCIPAL_IDS:
        await add_notification(lp, f"📨 Recours de {user_id} (ex-{label(row[0])}) : {message[:300]}")
    return True, "Recours transmis au Lead Principal."


# ─────────────────────────────────────────────────────────────────────────────
#  CRÉNEAUX, PRÉSENCE, CAPTURE ET PASSATION (Admins N1 et N2 → Game Leader) — temps RÉEL
# ─────────────────────────────────────────────────────────────────────────────
# Gestes de consultation : ils ne comptent pas comme « actions » dans la capture d'un créneau.
_READ_ONLY = frozenset({
    "admin", "admin_help", "adminpanel", "monrole", "staff_liste", "staff_history", "userinfo", "userstats",
    "topstats", "listusers", "playerhistory", "reports_list", "reports_stats", "game_logs", "transactions",
    "transaction_info", "adminlogs", "admin_action_log", "serverstats", "globalstats", "balance_stats",
    "listitems", "listcompanies", "coffre", "sante_audit", "notifications_stats", "presence", "passation",
    "passations", "presences", "creneau", "creneaux", "audit", "recours", "unknown",
})
_SANCTIONS = frozenset({"warn", "clearwarn", "banuser", "unbanuser", "freezeuser", "unfreezeuser",
                        "forceprison", "freeprison", "resetuser", "sethospital", "settravel"})
_REPORTS = frozenset({"report_handle"})


def _cmd(action: str) -> str:
    return (action or "").split()[0].split("@")[0].lstrip("/")


def _tz():
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(STAFF_TIMEZONE)
    except Exception:                              # tzdata absent : repli sur UTC+1
        return timezone(timedelta(hours=1))


def slot_label(slot: str) -> str:
    h = STAFF_SLOTS.get(slot)
    return f"Créneau {slot} · {h[2]} ({h[0]:02d}h–{h[1] % 24:02d}h)" if h else slot


def slot_window(slot: str, ts: int | None = None) -> tuple[str, int, int] | None:
    """(jour local, début, fin) du créneau `slot` s'il est en cours à l'instant `ts`, sinon None."""
    h = STAFF_SLOTS.get(slot)
    if not h:
        return None
    loc = datetime.fromtimestamp(ts if ts is not None else time.time(), _tz())
    if not (h[0] <= loc.hour < h[1]):
        return None
    start = loc.replace(hour=h[0], minute=0, second=0, microsecond=0)
    end = start + timedelta(hours=h[1] - h[0])
    return start.strftime("%Y-%m-%d"), int(start.timestamp()), int(end.timestamp())


def fmt_hm(ts: int) -> str:
    return datetime.fromtimestamp(ts, _tz()).strftime("%H:%M") if ts else "—"


async def _name(user_id: int) -> str:
    from database import get_user
    u = await get_user(user_id)
    return (u or {}).get("full_name") or f"#{user_id}"


async def role_holders(role: str) -> list[int]:
    """Tous les porteurs d'un rôle (statiques + nommés en base)."""
    from database import list_admin_roles
    ids = set(GAME_LEADER_IDS) if role == "GAME_LEADER" else set()
    for r in await list_admin_roles(include_revoked=False):
        if r["role"] == role:
            ids.add(r["user_id"])
    return sorted(ids)


async def notify_game_leaders(message: str) -> int:
    from database import add_notification
    ids = await role_holders("GAME_LEADER")
    for uid in ids:
        await add_notification(uid, message)
    return len(ids)


async def set_slot(actor_id: int, target_id: int, slot: str | None) -> tuple[bool, str]:
    """Définit (ou retire avec None) le créneau d'un Admin N1/N2. Réservé au Lead Staff Global et au Game Leader."""
    from database import db_connection, log_admin_action
    from utils.decorators import get_user_role_async
    if role_level(await get_user_role_async(actor_id)) < role_level("GAME_LEADER"):
        return False, "Seuls le Lead Staff Global et le Game Leader (par délégation) définissent les créneaux."
    if await get_user_role_async(target_id) not in ("ADMIN_N1", "ADMIN_N2"):
        return False, "Les créneaux concernent uniquement les Admins N1 et N2."
    async with db_connection() as db:
        if slot is None:
            await db.execute("DELETE FROM staff_slots WHERE user_id=?", (target_id,))
        else:
            if slot not in STAFF_SLOTS:
                return False, "Créneau inconnu : A, B, C ou D."
            await db.execute("INSERT INTO staff_slots(user_id, slot, set_by, set_at) VALUES(?,?,?,?) "
                             "ON CONFLICT(user_id) DO UPDATE SET slot=excluded.slot, set_by=excluded.set_by, "
                             "set_at=excluded.set_at", (target_id, slot, actor_id, int(time.time())))
        await db.commit()
    await log_admin_action(actor_id, "staff_creneau", target_id, slot or "retiré")
    return True, slot_label(slot) if slot else "créneau retiré"


async def coverage() -> dict[str, dict[str, list[int]]]:
    """Pour chaque créneau : Admins N1 et N2 assignés (règle de couverture : au moins un N1 et un N2)."""
    from database import db_connection
    from utils.decorators import get_user_role_async
    out = {k: {"ADMIN_N1": [], "ADMIN_N2": []} for k in STAFF_SLOTS}
    async with db_connection() as db:
        async with db.execute("SELECT user_id, slot FROM staff_slots") as cur:
            rows = await cur.fetchall()
    for uid, slot in rows:
        role = await get_user_role_async(uid)
        if slot in out and role in out[slot]:
            out[slot][role].append(uid)
    return out


async def current_shift(user_id: int) -> dict | None:
    """Créneau en cours pour cet Admin (ligne staff_shifts), None s'il n'est pas dans son créneau."""
    from database import db_connection
    t = int(time.time())
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM staff_shifts WHERE user_id=? AND starts_at<=? AND ends_at>? "
                              "ORDER BY starts_at DESC LIMIT 1", (user_id, t, t)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def confirm_presence(user_id: int) -> tuple[bool, str]:
    """L'Admin confirme son arrivée : le retard se mesure depuis le début du créneau."""
    from database import db_connection, log_admin_action
    sh = await current_shift(user_id)
    if not sh:
        return False, "Aucun créneau en cours pour toi."
    if sh["confirmed_at"]:
        return False, f"Arrivée déjà confirmée à {fmt_hm(sh['confirmed_at'])}."
    t = int(time.time())
    async with db_connection() as db:
        await db.execute("UPDATE staff_shifts SET confirmed_at=?, status='present' WHERE shift_id=?", (t, sh["shift_id"]))
        await db.commit()
    late = max(0, t - sh["starts_at"]) // 60
    await log_admin_action(user_id, "staff_presence", 0, f"{sh['slot']} · retard {late} min")
    return True, (f"✅ Arrivée confirmée à {fmt_hm(t)} — à l'heure." if late < 1
                  else f"✅ Arrivée confirmée à {fmt_hm(t)} — retard de {late} min.")


async def capture(user_id: int, since: int, until: int) -> dict:
    """Ce que l'Admin a réellement fait entre `since` et `until` (lu dans le journal, non modifiable)."""
    from database import db_connection
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT action, target_id, details, real_ts FROM admin_logs "
                              "WHERE admin_id=? AND real_ts>=? AND real_ts<=? ORDER BY log_id", (user_id, since, until)) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
    rows = [r for r in rows if _cmd(r["action"]) not in _READ_ONLY and not r["action"].startswith("staff_")]
    sanctions = [r for r in rows if _cmd(r["action"]) in _SANCTIONS]
    return {"total": len(rows), "reports": sum(1 for r in rows if _cmd(r["action"]) in _REPORTS),
            "sanctions": sanctions, "other": len(rows) - len(sanctions) - sum(1 for r in rows if _cmd(r["action"]) in _REPORTS)}


def capture_lines(c: dict) -> list[str]:
    lines = [f"📩 Signalements traités : <b>{c['reports']}</b>", f"⚖️ Sanctions appliquées : <b>{len(c['sanctions'])}</b>"]
    for r in c["sanctions"][:10]:
        lines.append(f"  • /{_cmd(r['action'])} → <code>{r['target_id']}</code> {(r['details'] or '')[:60]}")
    lines.append(f"🛠️ Autres actions : <b>{c['other']}</b>")
    return lines


async def last_reportable(user_id: int) -> dict | None:
    """Dernier créneau terminé, confirmé et pas encore rapporté."""
    from database import db_connection
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM staff_shifts WHERE user_id=? AND status='present' AND ends_at<=? "
                              "ORDER BY ends_at DESC LIMIT 1", (user_id, int(time.time()))) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def submit_report(user_id: int, problems: str, watch: str, suggestions: str) -> tuple[bool, str]:
    """Formulaire de passation : capture auto + champs libres, envoyé aux Game Leaders."""
    from database import db_connection
    sh = await last_reportable(user_id)
    if not sh:
        return False, "Aucun créneau terminé à rapporter (confirme d'abord ton arrivée pendant ton créneau)."
    cap = await capture(user_id, sh["confirmed_at"], sh["ends_at"])
    form = {"problems": problems, "watch": watch, "suggestions": suggestions,
            "reports": cap["reports"], "sanctions": [{"cmd": _cmd(r["action"]), "target": r["target_id"],
                                                      "details": (r["details"] or "")[:80]} for r in cap["sanctions"]],
            "other": cap["other"]}
    async with db_connection() as db:
        await db.execute("UPDATE staff_shifts SET status='reported', report_json=?, report_at=? WHERE shift_id=?",
                         (json.dumps(form, ensure_ascii=False), int(time.time()), sh["shift_id"]))
        await db.commit()
    n = await notify_game_leaders(await render_report(sh["shift_id"]))
    return True, f"Rapport envoyé à {n} Game Leader(s)."


async def render_report(shift_id: int) -> str:
    from database import db_connection
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM staff_shifts WHERE shift_id=?", (shift_id,)) as cur:
            sh = await cur.fetchone()
    if not sh or not sh["report_json"]:
        return "Rapport introuvable."
    f = json.loads(sh["report_json"])
    late = max(0, sh["confirmed_at"] - sh["starts_at"]) // 60
    sanc = "; ".join(f"/{x['cmd']} → {x['target']} {x['details']}".strip() for x in f["sanctions"][:8]) or "aucune"
    return (f"📋 Passation — {await _name(sh['user_id'])} ({sh['user_id']}) · {slot_label(sh['slot'])}\n"
            f"🕘 {fmt_hm(sh['starts_at'])}–{fmt_hm(sh['ends_at'])} · arrivée {fmt_hm(sh['confirmed_at'])} "
            f"({'à l heure' if late < 1 else f'retard {late} min'})\n"
            f"📩 Signalements : {f['reports']} · ⚖️ Sanctions : {sanc} · 🛠️ Autres actions : {f['other']}\n"
            f"⚠️ Problèmes : {f['problems'] or '—'}\n👀 À surveiller : {f['watch'] or '—'}\n💡 Suggestions : {f['suggestions'] or '—'}")


async def shift_tick() -> None:
    """Tâche planifiée (chaque minute) : ouvre les créneaux, prévient au début et à la fin, note les absences."""
    from database import add_notification, db_connection
    from utils.decorators import get_user_role_async
    t = int(time.time())
    async with db_connection() as db:
        async with db.execute("SELECT user_id, slot FROM staff_slots") as cur:
            slots = await cur.fetchall()
    for uid, slot in slots:
        if await get_user_role_async(uid) not in ("ADMIN_N1", "ADMIN_N2"):
            async with db_connection() as db:
                await db.execute("DELETE FROM staff_slots WHERE user_id=?", (uid,))
                await db.commit()
            continue
        w = slot_window(slot, t)
        if not w:
            continue
        day, start, end = w
        async with db_connection() as db:
            await db.execute("INSERT OR IGNORE INTO staff_shifts(user_id, slot, day, starts_at, ends_at) VALUES(?,?,?,?,?)",
                             (uid, slot, day, start, end))
            async with db.execute("SELECT shift_id, start_notified FROM staff_shifts WHERE user_id=? AND day=? AND slot=?",
                                  (uid, day, slot)) as cur:
                sid, notified = await cur.fetchone()
            if not notified:
                await db.execute("UPDATE staff_shifts SET start_notified=1 WHERE shift_id=?", (sid,))
            await db.commit()
        if not notified:
            await add_notification(uid, f"🛡️ Ton {slot_label(slot)} vient de commencer. Confirme ton arrivée : /presence "
                                        f"(le temps compte tant que tu n'as pas confirmé).")
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM staff_shifts WHERE ends_at<=? AND end_notified=0", (t,)) as cur:
            ended = [dict(r) for r in await cur.fetchall()]
        for sh in ended:
            await db.execute("UPDATE staff_shifts SET end_notified=1, status=CASE WHEN confirmed_at=0 THEN 'absent' "
                             "ELSE status END WHERE shift_id=?", (sh["shift_id"],))
        await db.commit()
    for sh in ended:
        if sh["confirmed_at"]:
            await add_notification(sh["user_id"], f"⏱️ Ton {slot_label(sh['slot'])} est terminé. Remplis le formulaire : "
                                                  f"Pense à remplir ton formulaire de passation depuis le panneau staff.")
        else:
            await add_notification(sh["user_id"], f"⚠️ Créneau {sh['slot']} terminé sans confirmation d'arrivée : absence enregistrée.")
            await notify_game_leaders(f"⏰ Absence : {await _name(sh['user_id'])} ({sh['user_id']}) — {slot_label(sh['slot'])}.")


async def apply_absence_penalty(user_id: int, slot: str) -> None:
    """Enregistre une absence et applique une sanction progressive.

    1 absence        → notification à l'admin concerné
    3+ en 7 jours    → avertissement formel dans admin_logs + notif Game Leaders
    5+ en 7 jours    → signalement urgent au Lead Staff Global
    """
    import time as _time
    cutoff = int(_time.time()) - 7 * 86400
    async with db_connection() as db:
        async with db.execute(
            "SELECT COUNT(*) FROM staff_shifts WHERE user_id=? AND status=\'absent\' AND ends_at > ?",
            (user_id, cutoff),
        ) as cur:
            absences_7d = (await cur.fetchone())[0]

    name = await _name(user_id)
    label = slot_label(slot)

    if absences_7d >= 5:
        await notify_game_leaders(
            f"🚨 <b>ALERTE ABSENCES</b> — {name} ({user_id}) : "
            f"<b>{absences_7d} absences en 7 jours</b>. "
            f"Révocation suggérée — à traiter via le panneau staff (Console → 👤 Actions joueur)."
        )
        await add_notification(user_id,
            "🚨 Tu as accumulé 5 absences ou plus en 7 jours. "
            "Un signalement urgent a été transmis aux Game Leaders. "
            "Contacte un Lead Studio pour expliquer ta situation."
        )
    elif absences_7d >= 3:
        async with db_connection() as db:
            await db.execute(
                "INSERT INTO admin_logs (admin_id, action, target_id, details, real_ts) "
                "VALUES (?,?,?,?,?)",
                (0, "auto_absence_warn", user_id,
                 f"3+ absences en 7 jours — créneau {slot}", int(_time.time())),
            )
            await db.commit()
        await notify_game_leaders(
            f"⚠️ Avertissement automatique : {name} ({user_id}) — "
            f"<b>{absences_7d} absences</b> en 7 jours (créneau {label})."
        )
        await add_notification(user_id,
            f"⚠️ Avertissement : {absences_7d} absences enregistrées en 7 jours. "
            "Un avertissement formel a été inscrit dans les logs et transmis aux Game Leaders."
        )
    else:
        await add_notification(user_id,
            f"📋 Absence enregistrée pour le créneau {label}. "
            "Préviens un Game Leader si tu ne peux plus assurer ce créneau."
        )


async def attendance(days: int = 7) -> list[dict]:
    """Présence des Admins sur `days` jours : créneaux, présents, absents, retard moyen."""
    from database import db_connection
    since = int(time.time()) - days * 86400
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT user_id, COUNT(*) n, SUM(status IN ('present','reported')) p, SUM(status='absent') a, "
                              "AVG(CASE WHEN confirmed_at>0 THEN confirmed_at-starts_at END) late "
                              "FROM staff_shifts WHERE ends_at<=? AND ends_at>=? GROUP BY user_id ORDER BY a DESC, n DESC",
                              (int(time.time()), since)) as cur:
            return [dict(r) for r in await cur.fetchall()]
