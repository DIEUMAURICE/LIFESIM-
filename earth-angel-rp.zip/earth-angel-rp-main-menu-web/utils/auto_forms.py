"""
utils/auto_forms.py — Boutons + saisies pour TOUTES les actions du jeu (plus aucune commande tapée)
═══════════════════════════════════════════════════════════════════════
Chaque action qui demandait des arguments (ex. /pret montant banque) devient un formulaire :
des boutons pour les choix (banque, plateforme, destination…) et des messages à envoyer pour les
saisies (pseudo, montant, texte). Le formulaire appelle ensuite la fonction `cmd_*` existante
avec les arguments reconstitués : la logique métier ne change pas.

Clé du formulaire : `a_<fonction>` (bouton `fm:a_<fonction>`). Le hub (handlers/hub.py) les affiche.
"""
from __future__ import annotations

import glob
import os
import re

from config import (
    ASSETS, BANKS, SKILLS, DIPLOMES_EXTENDED, VEHICLES, LUXURY_ITEMS, MEDICINES, DESTINATIONS, CRIMES,
    SOCIAL_PLATFORMS, POLITICAL_POSTS, CITIES,
    GOV_FACTIONS, SANTE_HOSPITALS, SANTE_POSTS, SANTE_ASSIGNABLE, CABINET_POSITIONS,
)
from utils.forms import Form, P, register


def _opts(values) -> tuple:
    return tuple((str(v), str(v)) for v in values)


# ── Choix issus de la configuration ──────────────────────────────────────────
BANK = P("bank", "choice", "Quelle banque ?", choices=_opts(b["name"] for b in BANKS), split=True)
ASSET = P("asset", "choice", "Quel actif ?", choices=_opts(a["name"] for a in ASSETS), split=True)
PLATFORM = P("platform", "choice", "Sur quelle plateforme ?", choices=_opts(SOCIAL_PLATFORMS))
YES_NO = P("answer", "choice", "Ta réponse ?", choices=(("✅ Accepter", "accepter"), ("❌ Refuser", "refuser")))
FOR_AGAINST = P("vote", "choice", "Ton vote ?", choices=(("👍 Pour", "pour"), ("👎 Contre", "contre")))
PLUS_MINUS = P("note", "choice", "Ta note ?", choices=(("👍 +1", "+1"), ("👎 −1", "-1")))


# ── Factions / Santé publique ────────────────────────────────────────────────
FACTION = P("faction", "choice", "À quelle faction candidates-tu ?",
            choices=tuple((f"{f['emoji']} {f['name']}", k) for k, f in GOV_FACTIONS.items()))
HOSP_PETIT = P("hospital", "choice", "Quel <b>petit hôpital</b> dirigera-t-il ?",
               choices=tuple((h["name"], k) for k, h in SANTE_HOSPITALS.items() if h["kind"] == "petit"))
SANTE_POST = P("post", "choice", "Quel <b>poste</b> ?",
               choices=tuple((f"{p['emoji']} {p['name']} — {p['salary_h']:,}/h", k)
                             for k, p in SANTE_POSTS.items() if k in SANTE_ASSIGNABLE))
SANTE_HOSP = P("hosp", "choice", "Dans quel <b>hôpital</b> ?",
               choices=(("🏥 Il garde son hôpital", "same"),
                        *((h["name"], k) for k, h in SANTE_HOSPITALS.items())))


def amount(prompt: str, key: str = "amount") -> P:
    return P(key, "amount", prompt + "\n<i>Exemples : 500, 2k, 1.5m</i>", min=1)


def number(prompt: str, key: str = "n", lo: int = 1) -> P:
    return P(key, "int", prompt, min=lo)


def text(prompt: str, key: str = "text", **kw) -> P:
    return P(key, "text", prompt, **kw)


def who(prompt: str = "Envoie le <b>@pseudo</b> (ou l'ID) du joueur.", key: str = "user") -> P:
    return P(key, "user", prompt)


def reply_user(prompt: str = "Envoie le <b>@pseudo</b> (ou l'ID) du joueur concerné.") -> P:
    return P("user", "user", prompt, reply=True)


def pick(prompt: str, values, key: str = "choice", split: bool = True) -> P:
    return P(key, "choice", prompt, choices=_opts(values), split=split)


def bet(prompt: str = "Quelle <b>mise</b> ? (nombre, ex : 500 ou 2k)") -> P:
    return P("bet", "amount", prompt, min=1)


# fonction → (paramètres, texte de confirmation, arguments fixes)
SPEC: dict[str, tuple] = {
    # ── Vie / banque / carrière ──
    "ouvrir": ((BANK,), None, ()),
    "pret": ((amount("Quel <b>montant</b> veux-tu emprunter ?"), BANK), None, ()),
    "rembourser": ((amount("Quel <b>montant</b> veux-tu rembourser ?"), BANK), None, ()),
    "formation": ((pick("Quelle compétence veux-tu travailler ?", SKILLS),), None, ()),
    "etudier": ((pick("Quel diplôme prépares-tu ?", DIPLOMES_EXTENDED),), None, ()),
    # ── Bourse ──
    "acheteraction": ((ASSET, number("Combien d'actions veux-tu <b>acheter</b> ?", "qty")), None, ()),
    "vendreaction": ((ASSET, text("Combien d'actions veux-tu <b>vendre</b> ? (un nombre, ou « tout »)", "qty", one_word=True)),
                     None, ()),
    "historique": ((ASSET,), None, ()),
    # ── Entreprises ──
    "donner_produit": ((number("Quel est l'<b>ID de l'objet</b> à donner ?", "item"),
                        number("Quelle <b>quantité</b> ?", "qty"),
                        reply_user("À qui donnes-tu ce produit ? Envoie son <b>@pseudo</b>.")), None, ()),
    "retirer_produit": ((number("Quel est l'<b>ID de l'objet</b> à retirer du stock ?", "item"),
                         number("Quelle <b>quantité</b> ?", "qty")), None, ()),
    "negocier_contrat": ((number("<b>ID du contrat</b> ?", "id"),
                          amount("Quel <b>nouveau montant</b> proposes-tu ?", "montant"),
                          number("Quelle <b>nouvelle durée</b> (en jours) ?", "jours")), None, ()),
    "negocier": ((number("<b>ID de la candidature</b> ?", "id"),
                  amount("Quel <b>salaire</b> proposes-tu ?", "salaire")), None, ()),
    "proposer_contrat": ((text("Quelle <b>entreprise cible</b> ? (son nom)", "company"),
                          amount("Quel <b>montant total</b> ?", "total"),
                          number("Sur combien de <b>jours</b> ?", "jours"),
                          text("Quel <b>type</b> de contrat ? (un mot)", "type", one_word=True)), None, ()),
    "proposer_fusion": ((text("Avec quelle <b>entreprise</b> veux-tu fusionner ? (son nom)", "company"),), None, ()),
    "repondre_contrat": ((number("<b>ID du contrat</b> ?", "id"), YES_NO), None, ()),
    "repondre_fusion": ((number("<b>ID de l'entreprise</b> qui propose la fusion ?", "id"), YES_NO), None, ()),
    "repondre_invitation": ((number("<b>ID de l'entreprise</b> qui t'invite ?", "id"), YES_NO), None, ()),
    "repondre_offre": ((number("<b>ID de la candidature</b> ?", "id"), YES_NO), None, ()),
    "transfert_entreprise": ((reply_user("À qui cèdes-tu ton entreprise ? Envoie son <b>@pseudo</b>."),),
                             "Tu vas <b>céder ton entreprise</b> à ce joueur. C'est définitif.", ()),
    # ── Factions de l'État / Santé publique ──
    "faction_postuler": ((FACTION,), None, ()),
    "faction_accepter": ((number("<b>Numéro de la candidature</b> à accepter ?", "id"),), None, ()),
    "faction_refuser": ((number("<b>Numéro de la candidature</b> à refuser ?", "id"),), None, ()),
    "faction_nommer": ((number("Quel <b>numéro de grade</b> (1 = le plus bas) ?", "grade"),
                        reply_user("Quel membre nommes-tu ? Envoie son <b>@pseudo</b>.")), None, ()),
    "nommer_dg": ((HOSP_PETIT, who("Quel joueur devient <b>DG</b> ? Envoie son <b>@pseudo</b>.")),
                  "Tu vas nommer ce joueur DG : l'ancien DG de cet hôpital redevient employé de base.", ()),
    "sante_poste": ((SANTE_POST, who("Quel <b>employé</b> de la santé ? Envoie son <b>@pseudo</b>."), SANTE_HOSP), None, ()),
    "sante_renvoyer": ((who("Quel <b>employé</b> renvoies-tu ? Envoie son <b>@pseudo</b>."),
                        text("Quel est le <b>motif</b> ? (il sera noté au journal)", "motif", split=True)),
                       "Tu vas renvoyer cet employé de la Santé publique.", ()),
    "promouvoir": ((reply_user("Quel employé veux-tu promouvoir ? Envoie son <b>@pseudo</b>."),), None, ()),
    # ── Marché ──
    "buyitem": ((number("<b>Numéro de l'annonce</b> ?", "listing"), number("Quelle <b>quantité</b> ?", "qty")), None, ()),
    "cancelitem": ((number("<b>Numéro de l'annonce</b> à retirer ?", "listing"),), None, ()),
    "useitem": ((number("<b>ID de l'objet</b> à utiliser ?", "item"), number("Quelle <b>quantité</b> ?", "qty")), None, ()),
    "sellitem": ((number("<b>ID de l'objet</b> à vendre ?", "item"),
                  amount("À quel <b>prix unitaire</b> ?", "prix"), number("Quelle <b>quantité</b> ?", "qty")), None, ()),
    # ── Véhicules / luxe ──
    "acheter_luxe": ((pick("Quel article de luxe ?", LUXURY_ITEMS),), None, ()),
    "acheter_vehicule": ((pick("Quel véhicule ?", VEHICLES),), None, ()),
    "assurer_vehicule": ((number("<b>Numéro du véhicule</b> à assurer (dans le garage) ?", "n"),), None, ()),
    "vehicule_info": ((number("<b>Numéro du véhicule</b> (dans le garage) ?", "n"),), None, ()),
    "vendre_vehicule": ((number("<b>Numéro du véhicule</b> à vendre (dans le garage) ?", "n"),),
                        "Vendre ce véhicule ? Le prix dépend de son état.", ()),
    # ── Loisirs ──
    "eventinfo": ((text("<b>Nom de l'événement</b> ou de l'effet ?", "name"),), None, ()),
    "voyager": ((pick("Quelle destination ?", DESTINATIONS),), None, ()),
    "defier": ((pick("Quel jeu ? (combat, pierre_papier_ciseaux, …)", ("combat", "pierre_papier_ciseaux", "pile_ou_face"),
                     "game", split=False),
                amount("Quelle <b>mise</b> ?", "mise"),
                reply_user("Qui défies-tu ? Envoie son <b>@pseudo</b>.")), None, ()),
    "parier": ((amount("Quelle <b>mise</b> ?", "mise"),
                reply_user("Sur quel joueur paries-tu ? Envoie son <b>@pseudo</b>.")), None, ()),
    **{c: ((bet(),), None, ()) for c in ("blackjack", "crash", "slots", "mines", "pmu", "poker", "roulette")},
    # ── Réseaux sociaux ──
    "sondage": ((text("Quelle est la <b>question</b> du sondage ?", "q", quote=True),
                 text("<b>Option 1</b> ?", "o1", quote=True), text("<b>Option 2</b> ?", "o2", quote=True)), None, ()),
    "creer_communaute": ((text("Quel <b>nom</b> pour ta communauté ?", "name"),), None, ()),
    "donner_socialcoins": ((who(), amount("Combien de SocialCoins donnes-tu ?")), None, ()),
    "inviter_communaute": ((number("<b>ID de la communauté</b> ?", "id"), who()), None, ()),
    "lancer_tendance": ((text("Quel <b>#hashtag</b> ? (un seul mot)", "tag", one_word=True),
                         amount("Quelle <b>mise</b> ?", "mise")), None, ()),
    "live": ((PLATFORM, number("Combien d'<b>heures</b> de live ?", "h")), None, ()),
    "noter_social": ((who(), PLUS_MINUS), None, ()),
    "poster": ((PLATFORM, text("Envoie le <b>message</b> à publier.", "msg")), None, ()),
    "rejoindre_communaute": ((number("<b>ID de la communauté</b> ?", "id"),), None, ()),
    "resultats_sondage": ((number("<b>ID du sondage</b> ?", "id"),), None, ()),
    "donner_live": ((number("<b>ID du live</b> ?", "id"), amount("Quel montant donnes-tu ?")), None, ()),
    "story": ((PLATFORM, text("Envoie le <b>message</b> de ta story.", "msg")), None, ()),
    "utiliser_tendance": ((text("Quel <b>#hashtag</b> ? (un seul mot)", "tag", one_word=True),), None, ()),
    "vendre_followers": ((who(), number("Combien d'<b>abonnés</b> vends-tu ?", "qty"),
                          amount("À quel <b>prix</b> ?", "prix")), None, ()),
    "vote": ((number("<b>ID du sondage</b> ?", "id"), number("<b>Numéro de l'option</b> ?", "opt")), None, ()),
    "collab": ((reply_user("Avec qui collabores-tu ? Envoie son <b>@pseudo</b>."),), None, ()),
    "partager": ((reply_user("Quel joueur veux-tu partager ? Envoie son <b>@pseudo</b>."),), None, ()),
    # ── Famille / multijoueur ──
    "creer_famille": ((text("Quel <b>nom de clan</b> ?", "name"),), None, ()),
    "cadeau": ((who(), amount("Quel <b>montant</b> offres-tu ?"),
                text("Un petit <b>message</b> pour accompagner le cadeau ?", "msg", split=True)), None, ()),
    "rejoindrefamille": ((text("Quel <b>nom de clan</b> veux-tu rejoindre ?", "name"),), None, ()),
    "echange": ((who(), amount("Combien <b>offres-tu</b> ?", "offre"), amount("Combien <b>demandes-tu</b> ?", "demande")),
                None, ()),
    "adopter": ((reply_user("Qui veux-tu adopter ? Envoie son <b>@pseudo</b>."),), None, ()),
    "ami": ((reply_user("Qui veux-tu ajouter en ami ? Envoie son <b>@pseudo</b>."),), None, ()),
    "salutations": ((reply_user("Qui veux-tu saluer ? Envoie son <b>@pseudo</b>."),), None, ()),
    "divorce": ((), "💔 Divorcer ? Les frais sont de <b>25 000 €A</b> et le mariage sera dissous.", ()),
    "nommer_ministre": ((who("Quel joueur nommes-tu ministre ? Envoie son <b>@pseudo</b>."),
                         P("position", "choice", "À quel <b>ministère</b> ?",
                           choices=tuple((c, c) for c in CABINET_POSITIONS))), None, ()),
    "revoquer_ministre": ((P("position", "choice", "Quel <b>ministère</b> retires-tu à son titulaire ?",
                             choices=tuple((c, c) for c in CABINET_POSITIONS)),), None, ()),
    "mariage": ((reply_user("Qui veux-tu épouser ? Envoie son <b>@pseudo</b>."),), None, ()),
    "inviterfamille": ((reply_user("Qui invites-tu dans ton clan ? Envoie son <b>@pseudo</b>."),), None, ()),
    "transfertclan": ((reply_user("À qui transmets-tu la direction du clan ? Envoie son <b>@pseudo</b>."),),
                      "Tu vas <b>céder la direction</b> du clan. Confirmer ?", ()),
    "dissoudrefamille": ((), "⚠️ <b>Tu vas dissoudre ton clan.</b> C'est définitif. Confirmer ?", ("confirmer",)),
    # ── Crime / marché noir ──
    "commettre": ((pick("Quel crime ?", CRIMES),), None, ()),
    # ── Politique ──
    "destituer": ((who("Qui veux-tu destituer ? Envoie son <b>@pseudo</b>."),), None, ()),
    "lancerelection": ((pick("Pour quel poste ?", POLITICAL_POSTS, "poste", split=False),
                        number("Durée de l'élection en <b>heures</b> ?", "h")), None, ()),
    "modifierconstitution": ((text("Envoie le <b>nouveau texte</b> de la constitution (10 caractères minimum).", "txt"),), None, ()),
    "proposerloi": ((text("Quel est le <b>titre</b> de la loi ?", "titre"), P("sep", "literal", "", choices="|"),
                     text("Envoie la <b>description</b> de la loi.", "desc")), None, ()),
    "referendum": ((text("Quelle est la <b>question</b> du référendum ?", "q"),), None, ()),
    "signer": ((who("Quel élu veux-tu soutenir ? Envoie son <b>@pseudo</b>."),), None, ()),
    "vote_destitution": ((FOR_AGAINST,), None, ()),
    "voter": ((who("Pour quel candidat votes-tu ? Envoie son <b>@pseudo</b>."),), None, ()),
    "votereferendum": ((FOR_AGAINST,), None, ()),
    "voterloi": ((text("Quel est le <b>titre</b> de la loi ?", "titre"), FOR_AGAINST), None, ()),
    "demissionnerposte": ((), "⚠️ Tu vas <b>démissionner</b> de ton poste. Confirmer ?", ("confirmer",)),
    # ── Progression / profil / téléphone ──
    "phone_status": ((text("Quel <b>statut</b> veux-tu afficher ?", "msg"),), None, ()),
}

# Actions sans argument obligatoire : un simple bouton ▶ ouvre leur menu.
RUN_ONLY = {
    "assurance", "metier", "auditboite", "market", "mes_vehicules", "repair_vehicle", "recolter",
    "candidats", "candidater", "tutorial", "profil", "graphstats", "analytiques", "bio",
    "setlocation", "report",
}


_HANDLERS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "handlers")
_MODULE_OF: dict[str, str] = {}


_STAFF_MODULES = {"handlers.admin", "handlers.admin_roles", "handlers.staff"}


def module_of(fn: str) -> str | None:
    """Module `handlers.xxx` qui définit `async def cmd_<fn>` (le module joueur prime sur le module staff)."""
    if not _MODULE_OF:
        found: dict[str, list[str]] = {}
        for path in sorted(glob.glob(os.path.join(_HANDLERS_DIR, "*.py"))):
            with open(path, encoding="utf-8") as f:
                for m in re.finditer(r"^async def (cmd_\w+)\(", f.read(), re.M):
                    found.setdefault(m.group(1), []).append("handlers." + os.path.basename(path)[:-3])
        for name, mods in found.items():
            _MODULE_OF[name] = next((x for x in mods if x not in _STAFF_MODULES), mods[0])
    return _MODULE_OF.get(f"cmd_{fn}")


def form_key(fn: str) -> str:
    return f"a_{fn}"


MERCHANT_ONLY = {"sellitem"}      # mise en vente sur le marché : commerçants uniquement


def _build() -> None:
    from handlers.hub_data import ITEMS
    labels = {fn: label for _a, fn, _c, _al, _u, label, _d in ITEMS}
    for fn, (params, confirm, fixed) in SPEC.items():
        mod = module_of(fn)
        if not mod:                       # fonction supprimée : on ne crée pas de bouton cassé
            continue
        register(Form(form_key(fn), labels.get(fn, fn), f"{mod}:cmd_{fn}", params=params,
                      confirm=confirm, fixed_args=fixed, back="hub:home",
                      requires="merchant" if fn in MERCHANT_ONLY else None))


_build()
