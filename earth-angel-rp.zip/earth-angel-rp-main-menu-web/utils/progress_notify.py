# utils/progress_notify.py — 🔔 Notifications de progression (niveau, succès, missions, compétitions)
"""Petits helpers appelés par les systèmes qui font progresser le joueur, pour qu'il soit toujours prévenu."""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


async def check_level_up(user_id: int, old_xp: int) -> int | None:
    """Prévient le joueur s'il a gagné un niveau depuis `old_xp`. Retourne le nouveau niveau, sinon None."""
    try:
        from database import get_user
        from utils.helpers import get_level
        from utils.notify import notify
        new_xp = int((await get_user(user_id)).get("xp", 0) or 0)
        old_lvl, new_lvl = get_level(int(old_xp or 0)), get_level(new_xp)
        if new_lvl > old_lvl:
            await notify(user_id, f"⭐ Niveau {new_lvl} atteint !",
                         f"Tu passes du niveau <b>{old_lvl}</b> au niveau <b>{new_lvl}</b>. "
                         "Retrouve ta progression dans 🎮 Menu → Progression → Mon évolution.", "achievement")
            return new_lvl
    except Exception:
        logger.exception("Notification de niveau impossible")
    return None
