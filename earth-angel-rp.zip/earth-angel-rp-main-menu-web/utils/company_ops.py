"""Opérations de base du module entreprises : inventaire, parts, mouvements d'argent atomiques."""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
import aiosqlite
from database import now, db_connection

CONTRACT_TYPES = ["service", "fourniture", "partenariat", "licence"]   # types de contrats inter-entreprises


def strip_quotes(s: str) -> str:
    """Enlève les guillemets au début et à la fin d'une chaîne."""
    s = s.strip()
    if s.startswith('"') and s.endswith('"'):
        return s[1:-1]
    if s.startswith("'") and s.endswith("'"):
        return s[1:-1]
    return s


async def _add_item_to_inventory(user_id: int, item_id: int, quantity: int = 1, item_type: str = "product", db=None):
    if db is None:
        async with db_connection() as db:
            return await _add_item_to_inventory(user_id, item_id, quantity, item_type, db)
    async with db.execute("SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?", (user_id, item_id)) as cur:
        existing = await cur.fetchone()
    if existing:
        await db.execute("UPDATE inventory SET quantity = quantity + ? WHERE user_id = ? AND item_id = ?", (quantity, user_id, item_id))
    else:
        async with db.execute("SELECT name FROM items WHERE item_id = ?", (item_id,)) as cur2:
            name_row = await cur2.fetchone()
        item_name = name_row[0] if name_row else "Item"
        await db.execute("""
            INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (user_id, item_id, item_type, item_name, quantity, now()))
    return True


async def _remove_item_from_inventory(user_id: int, item_id: int, quantity: int = 1, db=None) -> bool:
    if db is None:
        async with db_connection() as db:
            return await _remove_item_from_inventory(user_id, item_id, quantity, db)
    async with db.execute("SELECT quantity FROM inventory WHERE user_id = ? AND item_id = ?", (user_id, item_id)) as cur:
        row = await cur.fetchone()
    if not row or row[0] < quantity:
        return False
    new_qty = row[0] - quantity
    if new_qty <= 0:
        await db.execute("DELETE FROM inventory WHERE user_id = ? AND item_id = ?", (user_id, item_id))
    else:
        await db.execute("UPDATE inventory SET quantity = quantity - ? WHERE user_id = ? AND item_id = ?", (quantity, user_id, item_id))
    return True


async def paginate_items(items: list, page: int, per_page: int = 5, title: str = ""):
    if not items:
        return title + "\n\nAucun résultat.", None

    total_pages = max(1, (len(items) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start = (page - 1) * per_page
    page_items = items[start:start + per_page]
    text = title + "\n\n" + "\n".join(page_items)

    navigation = []
    if page > 1:
        navigation.append(
            InlineKeyboardButton("◀️", callback_data=f"company_page_{page - 1}")
        )
    navigation.append(
        InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop")
    )
    if page < total_pages:
        navigation.append(
            InlineKeyboardButton("▶️", callback_data=f"company_page_{page + 1}")
        )

    markup = InlineKeyboardMarkup([navigation]) if total_pages > 1 else None
    return text, markup


async def get_user_shares(user_id: int, company_id: int) -> int:
    async with db_connection() as db:
        async with db.execute("SELECT shares FROM company_shares WHERE user_id=? AND company_id=?", (user_id, company_id)) as cur:
            row = await cur.fetchone()
    return row[0] if row else 0


async def update_company_field(company_id: int, field: str, value):
    allowed_fields = {"treasury", "reputation", "level", "rd_level", "overhead"}
    if field not in allowed_fields:
        raise ValueError("Champ non autorisé")
    async with db_connection() as db:
        await db.execute(f"UPDATE companies SET {field}=? WHERE company_id=?", (value, company_id))
        await db.commit()


async def company_deposit_atomic(
    user_id: int,
    company_id: int,
    amount: int,
) -> bool:
    """Dépose de l'argent de l'utilisateur vers la trésorerie de l'entreprise."""
    if amount <= 0:
        raise ValueError("Montant invalide")

    async with db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            debit = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                "WHERE user_id=? AND balance>=?",
                (amount, amount, user_id, amount),
            )
            if debit.rowcount != 1:
                await db.rollback()
                return False

            credit = await db.execute(
                "UPDATE companies SET treasury=treasury+? "
                "WHERE company_id=? AND dissolved=0",
                (amount, company_id),
            )
            if credit.rowcount != 1:
                raise RuntimeError("Entreprise introuvable")

            await db.execute(
                "INSERT INTO company_logs "
                "(company_id,action,actor_id,details,timestamp) "
                "VALUES (?,?,?,?,?)",
                (company_id, "deposit", user_id, str(amount), now()),
            )
            await db.commit()
            return True
        except Exception:
            await db.rollback()
            raise


async def company_withdraw_atomic(
    user_id: int,
    company_id: int,
    amount: int,
) -> bool:
    """Retire de l'argent de la trésorerie vers l'utilisateur (PDG ou Directeur)."""
    if amount <= 0:
        raise ValueError("Montant invalide")

    async with db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT poste FROM company_members "
                "WHERE user_id=? AND company_id=?",
                (user_id, company_id),
            ) as cursor:
                member = await cursor.fetchone()
            if not member or member[0] not in ("PDG", "Directeur"):
                await db.rollback()
                return False

            debit = await db.execute(
                "UPDATE companies SET treasury=treasury-? "
                "WHERE company_id=? AND dissolved=0 AND treasury>=?",
                (amount, company_id, amount),
            )
            if debit.rowcount != 1:
                await db.rollback()
                return False

            await db.execute(
                "UPDATE users SET balance=balance+?, total_earned=total_earned+? "
                "WHERE user_id=?",
                (amount, amount, user_id),
            )
            await db.execute(
                "INSERT INTO company_logs "
                "(company_id,action,actor_id,details,timestamp) "
                "VALUES (?,?,?,?,?)",
                (company_id, "withdrawal", user_id, str(amount), now()),
            )
            await db.commit()
            return True
        except Exception:
            await db.rollback()
            raise


async def company_spend_atomic(
    company_id: int,
    amount: int,
    actor_id: int,
    action: str,
    details: str,
) -> bool:
    """Dépense de la trésorerie pour une action interne (salaires, R&D, etc.)."""
    if amount <= 0:
        raise ValueError("Montant invalide")

    async with db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            debit = await db.execute(
                "UPDATE companies SET treasury=treasury-? "
                "WHERE company_id=? AND dissolved=0 AND treasury>=?",
                (amount, company_id, amount),
            )
            if debit.rowcount != 1:
                await db.rollback()
                return False
            await db.execute(
                "INSERT INTO company_logs "
                "(company_id,action,actor_id,details,timestamp) "
                "VALUES (?,?,?,?,?)",
                (company_id, action, actor_id, details, now()),
            )
            await db.commit()
            return True
        except Exception:
            await db.rollback()
            raise


async def pay_company_salaries_atomic(
    company_id: int,
    actor_id: int,
) -> tuple[bool, int, int]:
    """Paie les salaires de tous les employés sauf le PDG, en une transaction."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            async with db.execute(
                "SELECT user_id,COALESCE(base_salary,salary,0) AS amount "
                "FROM company_members WHERE company_id=? AND user_id<>?",
                (company_id, actor_id),
            ) as cursor:
                salaries = await cursor.fetchall()

            total = sum(max(0, int(row["amount"] or 0)) for row in salaries)
            if total <= 0:
                await db.rollback()
                return False, 0, 0

            debit = await db.execute(
                "UPDATE companies SET treasury=treasury-? "
                "WHERE company_id=? AND dissolved=0 AND treasury>=?",
                (total, company_id, total),
            )
            if debit.rowcount != 1:
                await db.rollback()
                return False, total, len(salaries)

            for row in salaries:
                salary = max(0, int(row["amount"] or 0))
                if salary == 0:
                    continue
                await db.execute(
                    "UPDATE users SET balance=balance+?, total_earned=total_earned+? "
                    "WHERE user_id=?",
                    (salary, salary, row["user_id"]),
                )

            await db.execute(
                "INSERT INTO company_logs "
                "(company_id,action,actor_id,details,timestamp) "
                "VALUES (?,?,?,?,?)",
                (
                    company_id,
                    "payroll",
                    actor_id,
                    f"{len(salaries)} salaires, total {total}",
                    now(),
                ),
            )
            await db.commit()
            return True, total, len(salaries)
        except Exception:
            await db.rollback()
            raise
