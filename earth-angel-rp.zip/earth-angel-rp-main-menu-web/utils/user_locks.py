# utils/user_locks.py
"""
Verrous par joueur pour le traitement concurrent des mises à jour Telegram.

Principe : deux joueurs différents sont traités EN PARALLÈLE, mais deux
messages du MÊME joueur restent traités dans l'ordre, l'un après l'autre.
Cela évite les courses du type « double clic = double dépense » tout en
permettant au bot de servir beaucoup de joueurs à la fois.

Aucune dépendance à Telegram : testable seul.
"""
import asyncio
from collections.abc import Awaitable
from contextlib import asynccontextmanager


class KeyedLocks:
    """Un asyncio.Lock par clé, supprimé dès que plus personne ne l'utilise."""

    def __init__(self) -> None:
        # clé -> [lock, nombre d'utilisateurs (en cours + en attente)]
        self._entries: dict[int, list] = {}

    @asynccontextmanager
    async def hold(self, key: int):
        entry = self._entries.get(key)
        if entry is None:
            entry = [asyncio.Lock(), 0]
            self._entries[key] = entry
        entry[1] += 1
        try:
            async with entry[0]:
                yield
        finally:
            entry[1] -= 1
            if entry[1] == 0:
                self._entries.pop(key, None)

    def __len__(self) -> int:
        return len(self._entries)


user_locks = KeyedLocks()


async def run_serialized_per_user(user_id: int | None, coroutine: Awaitable) -> None:
    """Exécute `coroutine` en série pour ce joueur ; sans joueur, directement."""
    if user_id is None:
        await coroutine
        return
    async with user_locks.hold(user_id):
        await coroutine
