# utils/location.py — Monde RP : position du joueur, trajets, garde de présence
"""
Le jeu n'est pas en 3D mais reste un monde ouvert : pour jouer au casino, travailler,
aller à la banque… le joueur doit être SUR PLACE. Pour s'y rendre il marche (coûte de
l'énergie) ou prend un véhicule (carburant + usure, plus rapide).

• get_position(uid)        → position courante (résout l'arrivée si le trajet est fini)
• plan_options(uid, dest)  → façons d'y aller (à pied / chaque véhicule utilisable)
• start_travel(...)        → lance le trajet (débite énergie ou carburant)
• resolve_arrivals()       → tâche planifiée : fait arriver les joueurs + les notifie
• @require_location("casino") → décorateur : refuse si le joueur n'est pas au bon endroit

Tous les temps sont en secondes de JEU (now() = game_now()).
"""
import functools
import logging
import math

import aiosqlite

from config import (
    ADMIN_IDS, LOCATIONS, START_LOCATION, SAME_ZONE_KM, ZONE_DISTANCES_KM,
    WALK_SPEED_KMH, WALK_ENERGY_PER_KM, VEHICLE_FUEL_PER_KM, VEHICLE_WEAR_PER_KM,
    VEHICLE_MIN_CONDITION, LAND_VEHICLES, VEHICLES, GAME_DAY_REAL_SECONDS,
    TRAVEL_GAME_SEC_PER_HOUR, TRAVEL_MIN_SECONDS, TRAVEL_MAX_SECONDS,
    TAXI_SPEED_KMH, TAXI_BASE_FARE, TAXI_FARE_PER_KM,
)
from database import db_connection, get_user, get_vehicles, now

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Géographie
# ─────────────────────────────────────────────────────────────────────────────
def location_label(key: str) -> str:
    loc = LOCATIONS.get(key)
    return f"{loc['emoji']} {loc['name']}" if loc else key


def distance_km(a: str, b: str) -> float:
    """Distance entre deux lieux (0 si identiques)."""
    if a == b:
        return 0.0
    za, zb = LOCATIONS[a]["zone"], LOCATIONS[b]["zone"]
    if za == zb:
        return SAME_ZONE_KM
    return float(ZONE_DISTANCES_KM.get((za, zb)) or ZONE_DISTANCES_KM.get((zb, za)) or 10)


def _duration(km: float, speed_kmh: float) -> int:
    """Durée du trajet en secondes de JEU : entre TRAVEL_MIN_SECONDS et TRAVEL_MAX_SECONDS."""
    secs = km / max(1.0, speed_kmh) * TRAVEL_GAME_SEC_PER_HOUR
    return max(1, int(round(max(TRAVEL_MIN_SECONDS, min(TRAVEL_MAX_SECONDS, secs)))))


def taxi_fare(km: float) -> int:
    return int(TAXI_BASE_FARE + math.ceil(km * TAXI_FARE_PER_KM))


# ─────────────────────────────────────────────────────────────────────────────
# État du joueur
# ─────────────────────────────────────────────────────────────────────────────
async def _ensure_row(db, user_id: int) -> None:
    await db.execute(
        "INSERT OR IGNORE INTO user_position(user_id, location) VALUES (?, ?)",
        (user_id, START_LOCATION),
    )


async def _arrive(db, user_id: int, t: int) -> str | None:
    """Termine le trajet si l'heure est passée. Idempotent : renvoie le lieu atteint
    uniquement pour l'appel qui a réellement fait arriver le joueur."""
    async with db.execute(
        "SELECT travel_to FROM user_position WHERE user_id=? AND travel_to!='' AND arrive_at<=?",
        (user_id, t),
    ) as cur:
        row = await cur.fetchone()
    if not row:
        return None
    dest = row[0]
    cur = await db.execute(
        "UPDATE user_position SET location=?, travel_to='', travel_from='', travel_mode='', "
        "depart_at=0, arrive_at=0 WHERE user_id=? AND travel_to=? AND arrive_at<=?",
        (dest, user_id, dest, t),
    )
    return dest if cur.rowcount else None


async def _notify_arrival(user_id: int, dest: str) -> None:
    from utils.notify import notify
    await notify(user_id, "📍 Arrivée", f"Tu es arrivé(e) : <b>{location_label(dest)}</b>.", "info")


async def get_position(user_id: int) -> dict:
    """Position du joueur : {location, travel_to, travel_mode, arrive_at, in_transit, remaining}."""
    t = now()
    arrived = None
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await _ensure_row(db, user_id)
        arrived = await _arrive(db, user_id, t)
        await db.commit()
        async with db.execute("SELECT * FROM user_position WHERE user_id=?", (user_id,)) as cur:
            pos = dict(await cur.fetchone())
    if arrived:
        await _notify_arrival(user_id, arrived)
    pos["in_transit"] = bool(pos["travel_to"])
    pos["remaining"] = max(0, pos["arrive_at"] - t) if pos["in_transit"] else 0
    return pos


async def resolve_arrivals() -> None:
    """Tâche planifiée : fait arriver tous les joueurs dont le trajet est terminé."""
    t = now()
    async with db_connection() as db:
        async with db.execute(
            "SELECT user_id FROM user_position WHERE travel_to!='' AND arrive_at<=?", (t,)
        ) as cur:
            ids = [r[0] for r in await cur.fetchall()]
    for uid in ids:
        try:
            await get_position(uid)   # résout + notifie (idempotent)
        except Exception:
            logger.exception("Arrivée impossible pour %s", uid)


# ─────────────────────────────────────────────────────────────────────────────
# Options de trajet
# ─────────────────────────────────────────────────────────────────────────────
async def plan_options(user_id: int, origin: str, dest: str) -> list[dict]:
    """Liste des façons de rejoindre `dest`. Chaque option précise si elle est faisable."""
    km = distance_km(origin, dest)
    u = await get_user(user_id)
    energy = u.get("energy", 100)
    walk_cost = int(math.ceil(km * WALK_ENERGY_PER_KM))
    opts = [{
        "mode": "walk", "label": "🚶 À pied", "km": km,
        "duration": _duration(km, WALK_SPEED_KMH),
        "energy": walk_cost, "fuel": 0, "money": 0,
        "ok": energy >= walk_cost,
        "why": "" if energy >= walk_cost else f"trop fatigué (énergie {energy}/{walk_cost})",
    }]
    vehicles = await get_vehicles(user_id)
    for v in vehicles:
        vt = v["veh_type"]
        if vt not in LAND_VEHICLES:
            continue
        data = VEHICLES.get(vt, {})
        speed = max(1, data.get("speed", 10))
        motor = data.get("fuel_capacity", 0) > 0
        fuel_cost = int(math.ceil(km * VEHICLE_FUEL_PER_KM)) if motor else 0
        ok, why = True, ""
        if (v.get("condition") or 0) < VEHICLE_MIN_CONDITION:
            ok, why = False, "en panne (à réparer)"
        elif motor and (v.get("fuel") or 0) < fuel_cost:
            ok, why = False, f"pas assez d'essence ({v.get('fuel') or 0}/{fuel_cost})"
        opts.append({
            "mode": f"v{v['veh_id']}", "label": f"{data.get('emoji', '🚗')} {vt}", "km": km,
            "duration": _duration(km, speed), "energy": 0, "fuel": fuel_cost, "money": 0,
            "ok": ok, "why": why,
        })
    # Taxi : on paie, on arrive vite (aucune fatigue, aucun carburant)
    # Un joueur qui ne possède qu’un bateau/jet n’a pas de transport terrestre
    # disponible dans la zone. Le taxi reste disponible sans véhicule, ou avec
    # au moins un véhicule terrestre.
    if not vehicles or any(v.get("veh_type") in LAND_VEHICLES for v in vehicles):
        fare = taxi_fare(km)
        balance = u.get("balance", 0)
        opts.append({
            "mode": "taxi", "label": "🚕 Taxi", "km": km,
            "duration": _duration(km, TAXI_SPEED_KMH), "energy": 0, "fuel": 0, "money": fare,
            "ok": balance >= fare, "why": "" if balance >= fare else f"course trop chère ({fare:,} €A)",
        })
    return opts


async def start_travel(user_id: int, dest: str, mode: str) -> tuple[bool, str]:
    """Lance un trajet. Atomique : énergie/carburant débités seulement si le départ réussit."""
    if dest not in LOCATIONS:
        return False, "Lieu inconnu."
    pos = await get_position(user_id)
    if pos["in_transit"]:
        return False, f"Tu es déjà en route vers {location_label(pos['travel_to'])}."
    origin = pos["location"]
    if origin == dest:
        return False, f"Tu es déjà : {location_label(dest)}."
    opt = next((o for o in await plan_options(user_id, origin, dest) if o["mode"] == mode), None)
    if not opt:
        return False, "Moyen de transport indisponible."
    if not opt["ok"]:
        return False, f"{opt['label']} impossible : {opt['why']}."

    t = now()
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        # Garde anti double-départ (deux clics simultanés)
        cur = await db.execute(
            "UPDATE user_position SET travel_to=?, travel_from=?, travel_mode=?, depart_at=?, arrive_at=? "
            "WHERE user_id=? AND travel_to='' AND location=?",
            (dest, origin, mode, t, t + opt["duration"], user_id, origin),
        )
        if not cur.rowcount:
            await db.rollback()
            return False, "Tu es déjà en déplacement."
        if opt["energy"]:
            cur = await db.execute(
                "UPDATE users SET energy=energy-? WHERE user_id=? AND energy>=?",
                (opt["energy"], user_id, opt["energy"]),
            )
            if not cur.rowcount:
                await db.rollback()
                return False, "Trop fatigué pour marcher jusque-là."
        if opt.get("money"):
            cur = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
                (opt["money"], opt["money"], user_id, opt["money"]),
            )
            if not cur.rowcount:
                await db.rollback()
                return False, "Fonds insuffisants pour le taxi."
        if mode.startswith("v"):
            veh_id = int(mode[1:])
            wear = max(1, int(round(opt["km"] * VEHICLE_WEAR_PER_KM)))
            cur = await db.execute(
                "UPDATE vehicles SET fuel=MAX(0, fuel-?), condition=MAX(0, condition-?) "
                "WHERE veh_id=? AND user_id=? AND fuel>=? AND condition>=?",
                (opt["fuel"], wear, veh_id, user_id, opt["fuel"], VEHICLE_MIN_CONDITION),
            )
            if not cur.rowcount:
                await db.rollback()
                return False, "Le véhicule n'est plus utilisable."
        await db.commit()
    from utils.helpers import fmt_time
    paid = f" · 💶 -{opt['money']:,} €A" if opt.get("money") else ""
    return True, f"{opt['label']} — arrivée dans {fmt_time(opt['duration'])}{paid}"


# ─────────────────────────────────────────────────────────────────────────────
# Garde de présence
# ─────────────────────────────────────────────────────────────────────────────
async def presence_error(user_id: int, places: tuple[str, ...]) -> str | None:
    """None si le joueur est sur place ; sinon le message à lui montrer."""
    from utils.helpers import fmt_time
    pos = await get_position(user_id)
    if pos["in_transit"]:
        return (f"🚶 Tu es en route vers <b>{location_label(pos['travel_to'])}</b> "
                f"(arrivée dans <b>{fmt_time(pos['remaining'])}</b>). Patiente un peu.")
    if pos["location"] in places:
        return None
    target = location_label(places[0])
    return (f"📍 Tu es ici : <b>{location_label(pos['location'])}</b>.\n"
            f"Pour ça, il faut être sur place : <b>{target}</b>.\n"
            f"👉 Utilise /aller {places[0]} ou « 🧭 Se déplacer » dans le menu pour t'y rendre.")


async def is_exempt(user_id: int) -> bool:
    """Admins / god mode / rôles staff : pas de contrainte de lieu."""
    from utils.decorators import get_user_role_async
    u = await get_user(user_id)
    return bool(user_id in ADMIN_IDS or u.get("god_mode")
                or await get_user_role_async(user_id) != "PLAYER")


def require_location(*places: str):
    """Décorateur : la commande n'est utilisable que si le joueur est dans l'un de ces lieux."""
    for p in places:
        if p not in LOCATIONS:
            raise ValueError(f"Lieu inconnu pour require_location : {p}")

    def decorator(func):
        @functools.wraps(func)
        async def wrapper(update, context, *args, **kwargs):
            from utils.decorators import _reply
            user = update.effective_user
            if not user:
                return
            if not await is_exempt(user.id):
                err = await presence_error(user.id, places)
                if err:
                    await _reply(update, err, parse_mode="HTML")
                    return
            return await func(update, context, *args, **kwargs)
        return wrapper
    return decorator
