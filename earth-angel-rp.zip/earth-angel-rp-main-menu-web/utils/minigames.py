# utils/minigames.py — Mini-jeux de métier (freelance & entreprise)
"""
Chaque petit métier a une CATÉGORIE de mini-jeu. Le résultat est un score 0–3 :
  0 = échec        (gain × 0.0)
  1 = médiocre     (gain × 0.7)
  2 = bon          (gain × 1.0)
  3 = excellent    (gain × 1.5)

UN SEUL essai par mission : le résultat est définitif (réalisme).

Bonus de compétence : selon le niveau dans MINIGAME_SKILL[category],
+0 / +1 / +2 au score brut (avant plafonnement à 3).

À enregistrer dans bot.py :
    from utils.minigames import minigame_callback
    app.add_handler(CallbackQueryHandler(minigame_callback, pattern=r"^mg_"))
"""
from __future__ import annotations

from utils.swallow import swallowed
import random
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from config import MINIGAME_SKILL


# ═════════════════════════════════════════════════════════════════════
#  État en mémoire (reset au redémarrage — partie < 30 s)
# ═════════════════════════════════════════════════════════════════════
_state: dict[int, dict] = {}


def get_state(user_id: int) -> dict | None:
    return _state.get(user_id)


def clear(user_id: int) -> None:
    _state.pop(user_id, None)


SCORE_LABEL = {
    0: "❌ Échec",
    1: "😐 Service médiocre",
    2: "✅ Bon service",
    3: "⭐ Excellent travail",
}
SCORE_MULT = {0: 0.0, 1: 0.7, 2: 1.0, 3: 1.5}


# ═════════════════════════════════════════════════════════════════════
#  Helpers
# ═════════════════════════════════════════════════════════════════════
async def _skill_bonus(user_id: int, category: str) -> int:
    """+0 / +1 / +2 selon le niveau de la compétence liée à la catégorie."""
    skill = MINIGAME_SKILL.get(category)
    if not skill:
        return 0
    try:
        from database import get_skill
        lvl = await get_skill(user_id, skill)
    except Exception:
        return 0
    if lvl >= 8:
        return 2
    if lvl >= 4:
        return 1
    return 0


async def _finalize(query, user_id: int, raw_score: int, game_title: str):
    """Applique les bonus, calcule le gain, délègue à handlers.work."""
    st = get_state(user_id)
    if st is None:
        try:
            await query.edit_message_text("⌛ Session expirée.")
        except Exception:
            swallowed('utils/minigames.py')
        return

    skill_bonus = await _skill_bonus(user_id, st["category"])
    score = max(0, min(3, raw_score + skill_bonus))
    st["score"] = score

    hook = st.get("on_done")          # mini-jeu hors métier (ex. trajet jusqu'au restaurant)
    if hook:
        note = f"\n🧠 Bonus compétence : +{skill_bonus}" if skill_bonus > 0 else ""
        await hook(query, user_id, score, game_title, note)
        return

    base = st["base_gain"]
    gain = int(base * SCORE_MULT[score])

    bonus_note = ""
    if skill_bonus > 0:
        bonus_note = f"\n🧠 Bonus compétence : +{skill_bonus} point(s)"

    # Délégation : c'est handlers/work qui applique gains/XP/énergie.
    from handlers.work import on_minigame_done
    await on_minigame_done(
        query, user_id, score, gain, game_title,
        st.get("attempt", 1), bonus_note,
    )


def _make_query(sent_message):
    """Enveloppe un telegram.Message en pseudo-CallbackQuery."""
    class Q:
        async def edit_message_text(self, *a, **k):
            return await sent_message.edit_text(*a, **k)
        async def answer(self, *a, **k):
            pass
    return Q()


# ═════════════════════════════════════════════════════════════════════
#  CATÉGORIE : VITESSE  (Agilité) — cliquer vite sur la bonne case
# ═════════════════════════════════════════════════════════════════════
async def start_vitesse(query, user_id: int, base_gain: int, attempt: int = 1):
    _state[user_id] = {
        "category": "vitesse", "base_gain": base_gain, "attempt": attempt,
        "round": 0, "correct": 0,
    }
    await _vitesse_next(query, user_id)


async def _vitesse_next(query, user_id: int):
    st = _state.get(user_id)
    if not st:
        await query.edit_message_text("⌛ Session expirée.")
        return
    st["round"] += 1
    if st["round"] > 3:
        await _finalize(query, user_id, st["correct"], "🏃 Vitesse")
        return

    target = random.randint(0, 4)
    st["target"] = target

    kb = [[
        InlineKeyboardButton("🟢" if i == target else "⬛", callback_data=f"mg_vit_{i}")
        for i in range(5)
    ]]
    await query.edit_message_text(
        f"🏃 <b>Vitesse — manche {st['round']}/3</b>\n\n"
        f"Clique sur la case <b>verte</b> :",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(kb),
    )


async def _vitesse_click(update, context):
    q = update.callback_query
    user_id = q.from_user.id
    st = _state.get(user_id)
    if not st or st["category"] != "vitesse":
        await q.answer("⌛ Session expirée.", show_alert=True)
        return
    try:
        clicked = int(q.data.rsplit("_", 1)[1])
    except (ValueError, IndexError):
        await q.answer("Invalide.", show_alert=True)
        return

    if clicked == st["target"]:
        st["correct"] += 1
        await q.answer("✅ Bien joué !")
    else:
        await q.answer("❌ Raté.")
    await _vitesse_next(q, user_id)


# ═════════════════════════════════════════════════════════════════════
#  CATÉGORIE : MÉMOIRE  (Intelligence) — reproduire une séquence
# ═════════════════════════════════════════════════════════════════════
_SYM = ["🍒", "🔔", "💎", "⭐", "🍀"]


async def start_memoire(query, user_id: int, base_gain: int, attempt: int = 1):
    seq_len = 4
    sequence = [random.randint(0, 4) for _ in range(seq_len)]
    _state[user_id] = {
        "category": "memoire", "base_gain": base_gain, "attempt": attempt,
        "sequence": sequence, "index": 0,
    }
    await _memoire_show_sequence(query, user_id, preview=True)


async def _memoire_show_sequence(query, user_id: int, preview: bool = False):
    st = _state.get(user_id)
    if not st:
        await query.edit_message_text("⌛ Session expirée.")
        return

    if preview:
        seq_display = " — ".join(_SYM[i] for i in st["sequence"])
        await query.edit_message_text(
            f"🧠 <b>Mémoire</b>\n\n"
            f"Retiens cette séquence :\n\n{seq_display}\n\n"
            f"<i>Tu vas devoir la reproduire dans l'ordre.</i>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("▶️ Commencer", callback_data="mg_mem_start")
            ]]),
        )
    else:
        progress = f"{st['index']}/{len(st['sequence'])}"
        kb = [
            [InlineKeyboardButton(f"{i+1}. {_SYM[i]}", callback_data=f"mg_mem_{i}") for i in range(5)],
            [InlineKeyboardButton("⏭️ Je passe", callback_data="mg_mem_skip")],
        ]
        await query.edit_message_text(
            f"🧠 <b>Mémoire — {progress}</b>\n\nReproduis la séquence :",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(kb),
        )


async def _memoire_start(update, context):
    q = update.callback_query
    await q.answer()
    await _memoire_show_sequence(q, q.from_user.id, preview=False)


async def _memoire_click(update, context):
    q = update.callback_query
    user_id = q.from_user.id
    st = _state.get(user_id)
    if not st or st["category"] != "memoire":
        await q.answer("⌛ Session expirée.", show_alert=True)
        return

    if q.data == "mg_mem_skip":
        await q.answer("Passé.")
        raw = min(3, st["index"])
        await _finalize(q, user_id, raw, "🧠 Mémoire")
        return

    try:
        idx = int(q.data.rsplit("_", 1)[1])
    except (ValueError, IndexError):
        await q.answer("Invalide.", show_alert=True)
        return

    expected = st["sequence"][st["index"]]
    if idx == expected:
        st["index"] += 1
        if st["index"] >= len(st["sequence"]):
            await q.answer("✅ Séquence complète !")
            await _finalize(q, user_id, 3, "🧠 Mémoire")
            return
        await q.answer("✅")
        await _memoire_show_sequence(q, user_id, preview=False)
    else:
        await q.answer(f"❌ Faux ! C'était {_SYM[expected]}.", show_alert=True)
        raw = min(3, st["index"])
        await _finalize(q, user_id, raw, "🧠 Mémoire")


# ═════════════════════════════════════════════════════════════════════
#  CATÉGORIE : PRÉCISION  (Agilité) — cliquer au bon endroit
# ═════════════════════════════════════════════════════════════════════
async def start_precision(query, user_id: int, base_gain: int, attempt: int = 1):
    _state[user_id] = {
        "category": "precision", "base_gain": base_gain, "attempt": attempt,
        "round": 0, "correct": 0,
    }
    await _precision_next(query, user_id)


async def _precision_next(query, user_id: int):
    st = _state.get(user_id)
    if not st:
        await query.edit_message_text("⌛ Session expirée.")
        return
    st["round"] += 1
    if st["round"] > 3:
        await _finalize(query, user_id, st["correct"], "🎯 Précision")
        return

    # 8 positions, la cible est à un endroit aléatoire
    target = random.randint(0, 7)
    st["target"] = target

    def btn(i):
        return "🎯" if i == target else "⬜"

    kb = [
        [InlineKeyboardButton(btn(i), callback_data=f"mg_pre_{i}") for i in range(4)],
        [InlineKeyboardButton(btn(i), callback_data=f"mg_pre_{i}") for i in range(4, 8)],
    ]
    await query.edit_message_text(
        f"🎯 <b>Précision — manche {st['round']}/3</b>\n\n"
        f"Vise la cible 🎯 :",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(kb),
    )


async def _precision_click(update, context):
    q = update.callback_query
    user_id = q.from_user.id
    st = _state.get(user_id)
    if not st or st["category"] != "precision":
        await q.answer("⌛ Session expirée.", show_alert=True)
        return
    try:
        clicked = int(q.data.rsplit("_", 1)[1])
    except (ValueError, IndexError):
        await q.answer("Invalide.", show_alert=True)
        return

    if clicked == st["target"]:
        st["correct"] += 1
        await q.answer("✅ Dans le mille !")
    else:
        await q.answer("❌ Raté.")
    await _precision_next(q, user_id)


# ═════════════════════════════════════════════════════════════════════
#  CATÉGORIE : RYTHME  (Endurance) — reproduire un rythme imposé
# ═════════════════════════════════════════════════════════════════════
async def start_rythme(query, user_id: int, base_gain: int, attempt: int = 1):
    sequence = [random.choice(["🔴", "🔵", "🟡"]) for _ in range(3)]
    _state[user_id] = {
        "category": "rythme", "base_gain": base_gain, "attempt": attempt,
        "sequence": sequence, "index": 0, "correct": 0,
    }
    await _rythme_show(query, user_id, preview=True)


async def _rythme_show(query, user_id: int, preview: bool = False):
    st = _state.get(user_id)
    if not st:
        await query.edit_message_text("⌛ Session expirée.")
        return

    if preview:
        seq_str = " ".join(st["sequence"])
        await query.edit_message_text(
            f"🎵 <b>Rythme</b>\n\n"
            f"Retiens ce rythme :\n\n{seq_str}\n\n"
            f"<i>Tu vas le reproduire dans l'ordre.</i>",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("▶️ Commencer", callback_data="mg_ryt_start")
            ]]),
        )
    else:
        kb = [[
            InlineKeyboardButton("🔴", callback_data="mg_ryt_0"),
            InlineKeyboardButton("🔵", callback_data="mg_ryt_1"),
            InlineKeyboardButton("🟡", callback_data="mg_ryt_2"),
        ]]
        await query.edit_message_text(
            f"🎵 <b>Rythme — {st['index']}/{len(st['sequence'])}</b>\n\nReproduis :",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(kb),
        )


async def _rythme_start(update, context):
    q = update.callback_query
    await q.answer()
    await _rythme_show(q, q.from_user.id, preview=False)


async def _rythme_click(update, context):
    q = update.callback_query
    user_id = q.from_user.id
    st = _state.get(user_id)
    if not st or st["category"] != "rythme":
        await q.answer("⌛ Session expirée.", show_alert=True)
        return
    try:
        idx = int(q.data.rsplit("_", 1)[1])
    except (ValueError, IndexError):
        await q.answer("Invalide.", show_alert=True)
        return

    palette = ["🔴", "🔵", "🟡"]
    expected = palette.index(st["sequence"][st["index"]])
    if idx == expected:
        st["index"] += 1
        st["correct"] += 1
        if st["index"] >= len(st["sequence"]):
            await q.answer("✅ Rythme parfait !")
            await _finalize(q, user_id, 3, "🎵 Rythme")
            return
        await q.answer("✅")
        await _rythme_show(q, user_id, preview=False)
    else:
        await q.answer("❌ Faux rythme !", show_alert=True)
        raw = min(3, st["correct"])
        await _finalize(q, user_id, raw, "🎵 Rythme")


# ═════════════════════════════════════════════════════════════════════
#  CATÉGORIE : CRÉATIVITÉ  (Créativité) — choisir la meilleure idée
# ═════════════════════════════════════════════════════════════════════
_IDEAS = [
    ("Un portrait en clair-obscur inspiré des maîtres hollandais", 3),
    ("Une performance scénique immersive avec musique live", 3),
    ("Une installation d'art numérique interactive", 2),
    ("Un simple autoportrait au crayon", 1),
    ("Un dessin rapide fait à la va-vite", 0),
]


async def start_creativite(query, user_id: int, base_gain: int, attempt: int = 1):
    # Mélange 3 idées à présenter, dont la meilleure est TOUJOURS présente
    best = _IDEAS[0]
    others = random.sample(_IDEAS[1:], 2)
    options = [best, *others]
    random.shuffle(options)

    _state[user_id] = {
        "category": "creativite", "base_gain": base_gain, "attempt": attempt,
        "options": options,
    }
    kb = [[InlineKeyboardButton(f"{i+1}. {o[0][:45]}", callback_data=f"mg_cre_{i}")]
          for i, o in enumerate(options)]
    await query.edit_message_text(
        "🎨 <b>Créativité</b>\n\n"
        "Tu dois créer une œuvre pour un client.\n"
        "<b>Quelle idée choisis-tu ?</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(kb),
    )


async def _creativite_click(update, context):
    q = update.callback_query
    user_id = q.from_user.id
    st = _state.get(user_id)
    if not st or st["category"] != "creativite":
        await q.answer("⌛ Session expirée.", show_alert=True)
        return
    try:
        idx = int(q.data.rsplit("_", 1)[1])
    except (ValueError, IndexError):
        await q.answer("Invalide.", show_alert=True)
        return
    if not (0 <= idx < len(st["options"])):
        await q.answer("Invalide.", show_alert=True)
        return

    chosen = st["options"][idx]
    raw = chosen[1]
    await q.answer(f"Note client : {raw}/3 ⭐")
    await _finalize(q, user_id, raw, "🎨 Créativité")


# ═════════════════════════════════════════════════════════════════════
#  CATÉGORIE : CHARISME  (Charisme) — choisir la bonne réplique
# ═════════════════════════════════════════════════════════════════════
_DIALOGUES = [
    {
        "context": "Un client mécontent menace de partir. Que dis-tu ?",
        "options": [
            ("« C'est de votre faute, vous n'aviez qu'à lire. »", 0),
            ("« Je comprends, laissez-moi arranger ça. »", 3),
            ("« Pas mon problème. »", 0),
        ],
    },
    {
        "context": "Tu rencontres un investisseur potentiel. Ton accroche ?",
        "options": [
            ("« Bonjour, j'ai une idée. »", 1),
            ("« J'ai une solution qui va changer votre marché. »", 3),
            ("« Vous voulez investir ? »", 2),
        ],
    },
    {
        "context": "Un fan t'aborde dans la rue. Ta réaction ?",
        "options": [
            ("Tu l'ignores et passes ton chemin.", 0),
            ("Tu prends 30 secondes pour discuter et une photo.", 3),
            ("Tu lui dis de revenir plus tard.", 1),
        ],
    },
]


async def start_charisme(query, user_id: int, base_gain: int, attempt: int = 1):
    dlg = random.choice(_DIALOGUES)
    options = list(dlg["options"])
    random.shuffle(options)

    _state[user_id] = {
        "category": "charisme", "base_gain": base_gain, "attempt": attempt,
        "options": options,
    }
    kb = [[InlineKeyboardButton(f"{i+1}. {o[0][:55]}", callback_data=f"mg_cha_{i}")]
          for i, o in enumerate(options)]
    await query.edit_message_text(
        f"🗣️ <b>Charisme</b>\n\n"
        f"<i>{dlg['context']}</i>\n\n"
        f"<b>Choisis ta réponse :</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(kb),
    )


async def _charisme_click(update, context):
    q = update.callback_query
    user_id = q.from_user.id
    st = _state.get(user_id)
    if not st or st["category"] != "charisme":
        await q.answer("⌛ Session expirée.", show_alert=True)
        return
    try:
        idx = int(q.data.rsplit("_", 1)[1])
    except (ValueError, IndexError):
        await q.answer("Invalide.", show_alert=True)
        return
    if not (0 <= idx < len(st["options"])):
        await q.answer("Invalide.", show_alert=True)
        return

    chosen = st["options"][idx]
    raw = chosen[1]
    await q.answer(f"Réaction : {raw}/3 ⭐")
    await _finalize(q, user_id, raw, "🗣️ Charisme")


# ═════════════════════════════════════════════════════════════════════
#  CATÉGORIE : TIMING  (Agilité) — saisir la bonne fenêtre
# ═════════════════════════════════════════════════════════════════════
async def start_timing(query, user_id: int, base_gain: int, attempt: int = 1):
    _state[user_id] = {
        "category": "timing", "base_gain": base_gain, "attempt": attempt,
        "round": 0, "correct": 0,
    }
    await _timing_next(query, user_id)


async def _timing_next(query, user_id: int):
    st = _state.get(user_id)
    if not st:
        await query.edit_message_text("⌛ Session expirée.")
        return
    st["round"] += 1
    if st["round"] > 3:
        await _finalize(query, user_id, st["correct"], "⏱️ Timing")
        return

    # 5 slots, 1 seul est "ouvert" (l'utilisateur doit le saisir)
    window = random.randint(0, 4)
    st["window"] = window

    def label(i):
        return "🟢" if i == window else "⚪"

    kb = [[InlineKeyboardButton(label(i), callback_data=f"mg_tim_{i}") for i in range(5)]]
    await query.edit_message_text(
        f"⏱️ <b>Timing — manche {st['round']}/3</b>\n\n"
        f"Clique <b>pile</b> dans la fenêtre verte :",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(kb),
    )


async def _timing_click(update, context):
    q = update.callback_query
    user_id = q.from_user.id
    st = _state.get(user_id)
    if not st or st["category"] != "timing":
        await q.answer("⌛ Session expirée.", show_alert=True)
        return
    try:
        idx = int(q.data.rsplit("_", 1)[1])
    except (ValueError, IndexError):
        await q.answer("Invalide.", show_alert=True)
        return

    if idx == st["window"]:
        st["correct"] += 1
        await q.answer("✅ Bien calibré !")
    else:
        await q.answer("❌ Raté.")
    await _timing_next(q, user_id)


# ═════════════════════════════════════════════════════════════════════
#  CATÉGORIE : RÉFLEXE  (Discrétion) — repérer une menace
# ═════════════════════════════════════════════════════════════════════
async def start_reflexe(query, user_id: int, base_gain: int, attempt: int = 1):
    _state[user_id] = {
        "category": "reflexe", "base_gain": base_gain, "attempt": attempt,
        "round": 0, "correct": 0,
    }
    await _reflexe_next(query, user_id)


async def _reflexe_next(query, user_id: int):
    st = _state.get(user_id)
    if not st:
        await query.edit_message_text("⌛ Session expirée.")
        return
    st["round"] += 1
    if st["round"] > 3:
        await _finalize(query, user_id, st["correct"], "🔍 Réflexe")
        return

    # 4 cibles, une seule est la bonne (décrite en texte)
    target = random.randint(0, 3)
    st["target"] = target

    threats = [
        "🕵️ Silhouette suspecte",
        "🚗 Voiture garée sans plaque",
        "🧳 Valise abandonnée",
        "🚨 Alarme déclenchée",
    ]
    random.shuffle(threats)
    st["threats"] = threats

    kb = [[InlineKeyboardButton(f"{i+1}. {threats[i]}", callback_data=f"mg_ref_{i}")
           for i in range(4)]]
    await query.edit_message_text(
        f"🔍 <b>Réflexe — manche {st['round']}/3</b>\n\n"
        f"Repère l'anomalie la plus grave :",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(kb),
    )


async def _reflexe_click(update, context):
    q = update.callback_query
    user_id = q.from_user.id
    st = _state.get(user_id)
    if not st or st["category"] != "reflexe":
        await q.answer("⌛ Session expirée.", show_alert=True)
        return
    try:
        idx = int(q.data.rsplit("_", 1)[1])
    except (ValueError, IndexError):
        await q.answer("Invalide.", show_alert=True)
        return

    if idx == st["target"]:
        st["correct"] += 1
        await q.answer("✅ Bien vu !")
    else:
        await q.answer("❌ Raté.")
    await _reflexe_next(q, user_id)


# ═════════════════════════════════════════════════════════════════════
#  CATÉGORIE : LOGIQUE  (Intelligence) — résoudre un mini-problème
# ═════════════════════════════════════════════════════════════════════
async def start_logique(query, user_id: int, base_gain: int, attempt: int = 1):
    """Petite énigme : trouver le bon nombre dans une suite logique."""
    patterns = [
        ("2, 4, 8, 16, ?", 32, ["24", "30", "32", "36"]),
        ("1, 4, 9, 16, ?", 25, ["20", "22", "24", "25"]),
        ("3, 6, 12, 24, ?", 48, ["30", "36", "42", "48"]),
        ("5, 10, 20, 40, ?", 80, ["60", "70", "80", "90"]),
        ("1, 2, 6, 24, ?", 120, ["60", "96", "120", "144"]),
    ]
    seq, answer, choices = random.choice(patterns)
    random.shuffle(choices)

    _state[user_id] = {
        "category": "logique", "base_gain": base_gain, "attempt": attempt,
        "answer": str(answer), "choices": choices,
    }
    kb = [[InlineKeyboardButton(c, callback_data=f"mg_log_{i}")
           for i, c in enumerate(choices)]]
    await query.edit_message_text(
        f"🧩 <b>Logique</b>\n\n"
        f"Complète la suite :\n\n"
        f"<code>{seq}</code>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(kb),
    )


async def _logique_click(update, context):
    q = update.callback_query
    user_id = q.from_user.id
    st = _state.get(user_id)
    if not st or st["category"] != "logique":
        await q.answer("⌛ Session expirée.", show_alert=True)
        return
    try:
        idx = int(q.data.rsplit("_", 1)[1])
    except (ValueError, IndexError):
        await q.answer("Invalide.", show_alert=True)
        return
    if not (0 <= idx < len(st["choices"])):
        await q.answer("Invalide.", show_alert=True)
        return

    chosen = st["choices"][idx]
    if chosen == st["answer"]:
        await q.answer("✅ Bonne réponse !")
        await _finalize(q, user_id, 3, "🧩 Logique")
    else:
        await q.answer(f"❌ Faux. Réponse : {st['answer']}", show_alert=True)
        await _finalize(q, user_id, 0, "🧩 Logique")


# ═════════════════════════════════════════════════════════════════════
#  Routeur principal
# ═════════════════════════════════════════════════════════════════════
STARTERS = {
    "vitesse":    start_vitesse,
    "memoire":    start_memoire,
    "precision":  start_precision,
    "rythme":     start_rythme,
    "creativite": start_creativite,
    "charisme":   start_charisme,
    "timing":     start_timing,
    "reflexe":    start_reflexe,
    "logique":    start_logique,
}


async def minigame_callback(update, context):
    q = update.callback_query
    data = q.data or ""

    # Aiguillage par catégorie
    if data.startswith("mg_vit_"):
        await _vitesse_click(update, context); return
    if data == "mg_mem_start":
        await _memoire_start(update, context); return
    if data.startswith("mg_mem_"):
        await _memoire_click(update, context); return
    if data.startswith("mg_pre_"):
        await _precision_click(update, context); return
    if data == "mg_ryt_start":
        await _rythme_start(update, context); return
    if data.startswith("mg_ryt_"):
        await _rythme_click(update, context); return
    if data.startswith("mg_cre_"):
        await _creativite_click(update, context); return
    if data.startswith("mg_cha_"):
        await _charisme_click(update, context); return
    if data.startswith("mg_tim_"):
        await _timing_click(update, context); return
    if data.startswith("mg_ref_"):
        await _reflexe_click(update, context); return
    if data.startswith("mg_log_"):
        await _logique_click(update, context); return

    await q.answer("Action inconnue.", show_alert=True)