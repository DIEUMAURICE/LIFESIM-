"""
utils/error_handler.py — Gestionnaire d'erreurs global
Branchement dans bot.py :
    from utils.error_handler import error_handler
    app.add_error_handler(error_handler)
"""
from utils.swallow import swallowed
import html
import logging
import traceback

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from config import ADMIN_IDS

logger = logging.getLogger(__name__)

USER_ERROR_MESSAGE = (
    "😬 Oups, une erreur est survenue de mon côté. "
    "L'incident a été signalé. Réessaie dans un instant."
)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    from telegram.error import NetworkError, TimedOut
    # Coupures réseau passagères avec Telegram (le polling se relance seul) : pas d'alerte, pas de message au joueur.
    if isinstance(context.error, (NetworkError, TimedOut)) and not isinstance(update, Update):
        logger.warning("Réseau Telegram instable : %s", context.error)
        return
    logger.error("Exception non gérée :", exc_info=context.error)

    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text(USER_ERROR_MESSAGE)
        except Exception:
            logger.exception("Impossible d'envoyer le message d'erreur à l'utilisateur")

    tb_list = traceback.format_exception(None, context.error, context.error.__traceback__)
    tb_string = "".join(tb_list)

    user = update.effective_user if isinstance(update, Update) else None
    header = "⚠️ <b>Erreur dans le bot</b>\n"
    if user:
        header += f"👤 {user.id} (@{user.username or '—'})\n"

    message = f"{header}<pre>{html.escape(tb_string[-3500:])}</pre>"

    for admin_id in ADMIN_IDS:
        try:
            await context.bot.send_message(chat_id=admin_id, text=message, parse_mode=ParseMode.HTML)
        except Exception:
            logger.exception("Impossible d'alerter l'admin %s", admin_id)

# ═══════════════════════════════════════════════════════════════════
#   Boutons sous une PHOTO : « There is no text in the message to edit »
# ═══════════════════════════════════════════════════════════════════
def make_photo_safe_edit(orig):
    """Enveloppe CallbackQuery.edit_message_text.

    Un message photo (ex. l'écran /start) n'a pas de texte : Telegram refuse de l'éditer.
    Dans ce cas on envoie le même contenu dans un nouveau message et on supprime la photo.
    Corrige d'un coup tous les menus du bot, sans toucher à chaque handler.
    """
    async def edit_message_text(self, text, *args, **kwargs):
        try:
            return await orig(self, text, *args, **kwargs)
        except Exception as exc:  # BadRequest
            if "message is not modified" in str(exc).lower():
                return None        # même texte et mêmes boutons : rien à faire (double clic, « Actualiser »)
            if "no text in the message" not in str(exc).lower() or self.message is None:
                raise
            reply_markup = kwargs.get("reply_markup", args[0] if args else None)
            extra = {k: kwargs[k] for k in ("parse_mode", "disable_web_page_preview") if k in kwargs}
            sent = await self.message.reply_text(text, reply_markup=reply_markup, **extra)
            try:
                await self.message.delete()
            except Exception:
                swallowed('utils/error_handler.py')
            return sent
    return edit_message_text


def install_photo_safe_edit() -> None:
    from telegram import CallbackQuery
    if not getattr(CallbackQuery.edit_message_text, "_photo_safe", False):
        patched = make_photo_safe_edit(CallbackQuery.edit_message_text)
        patched._photo_safe = True
        CallbackQuery.edit_message_text = patched
