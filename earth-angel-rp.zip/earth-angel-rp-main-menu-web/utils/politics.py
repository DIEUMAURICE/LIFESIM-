# utils/politics.py — règles de la vie politique (élections, destitution, lois, référendums, journal)
"""
Logique « métier » de la politique, séparée des commandes Telegram (handlers/political.py) pour rester testable.

Destitution du Président ou d'un ministre :
  1. un joueur lance une motion (coût MOTION_COST, cooldown personnel, pas deux motions en même temps contre la même cible,
     délai MOTION_TARGET_COOLDOWN après une motion échouée, immunité MOTION_IMMUNITY après la prise de poste) ;
  2. il faut MOTION_SIGNATURES_NEEDED signatures avant MOTION_SIGNATURE_DURATION, sinon la motion expire ;
  3. un vote de MOTION_VOTE_DURATION s'ouvre (la cible ne vote ni ne signe) ;
  4. à la clôture : quorum (10 % des inscrits, 5 à 50 votes) et majorité (60 % pour le Président, 50 % pour un ministre).
"""
from __future__ import annotations

import logging
import math

from config import (
    ELECTION_QUORUM, ELECTION_QUORUM_MAX_VOTES, ELECTION_QUORUM_MIN_VOTES, MINISTRIES,
    MOTION_IMMUNITY, MOTION_MAJORITY, MOTION_MAJORITY_PRESIDENT, MOTION_MAX_VOTES, MOTION_MIN_VOTES,
    MOTION_QUORUM, MOTION_SIGNATURE_DURATION, MOTION_SIGNATURES_NEEDED, MOTION_TARGET_COOLDOWN,
    MOTION_VOTE_DURATION, POLL_MIN_VOTES, PRESIDENT_TERM,
)
from database import db_connection, now
from utils.notify import notify

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
#  Outils
# ─────────────────────────────────────────────────────────────────────────────
def vote_quorum(registered: int, ratio: float, lo: int, hi: int) -> int:
    """Nombre de votes minimum : `ratio` des inscrits, borné entre `lo` et `hi`."""
    return max(lo, min(hi, math.ceil(registered * ratio)))


def election_quorum(registered: int) -> int:
    return vote_quorum(registered, ELECTION_QUORUM, ELECTION_QUORUM_MIN_VOTES, ELECTION_QUORUM_MAX_VOTES)


def motion_quorum(registered: int) -> int:
    return vote_quorum(registered, MOTION_QUORUM, MOTION_MIN_VOTES, MOTION_MAX_VOTES)


def motion_majority(office_label: str) -> float:
    return MOTION_MAJORITY_PRESIDENT if office_label == "Président" else MOTION_MAJORITY


async def registered_count() -> int:
    async with db_connection() as db:
        from utils.staff_scope import excluded_sql
        async with db.execute("SELECT COUNT(*) FROM users WHERE registered=1 AND COALESCE(banned,0)=0 AND "
                              + excluded_sql("user_id")) as cur:
            return int((await cur.fetchone())[0] or 0)


async def display_name(user_id: int) -> str:
    async with db_connection() as db:
        async with db.execute("SELECT full_name, username FROM users WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
    if not row:
        return str(user_id)
    return row[0] or (f"@{row[1]}" if row[1] else str(user_id))


async def log_event(event_type: str, description: str, user_id: int | None = None) -> None:
    """Journal officiel (table political_history) : élections, nominations, destitutions, lois…"""
    try:
        async with db_connection() as db:
            await db.execute(
                "INSERT INTO political_history(event_type, description, involved_user_id, timestamp) VALUES (?,?,?,?)",
                (event_type, description[:300], user_id, now()))
            await db.commit()
    except Exception:
        logger.exception("Journal politique : écriture impossible")


async def recent_events(limit: int = 12) -> list[tuple[str, str, int]]:
    async with db_connection() as db:
        async with db.execute(
                "SELECT event_type, description, timestamp FROM political_history ORDER BY id DESC LIMIT ?", (limit,)) as cur:
            return [(r[0], r[1], int(r[2])) for r in await cur.fetchall()]


async def office_info(user_id: int) -> dict | None:
    """Poste de gouvernement de `user_id` : {'label', 'since', 'kind', 'position'} ou None."""
    from utils.roles import is_president, minister_of
    if await is_president(user_id):
        async with db_connection() as db:
            async with db.execute("SELECT elected_at FROM political_offices WHERE poste='Président' AND occupant_id=?",
                                  (user_id,)) as cur:
                row = await cur.fetchone()
        return {"label": "Président", "kind": "president", "position": "Président", "since": int(row[0] or 0) if row else 0}
    pos = await minister_of(user_id)
    if not pos:
        return None
    async with db_connection() as db:
        async with db.execute("SELECT appointed_at FROM cabinet_positions WHERE position=?", (pos,)) as cur:
            row = await cur.fetchone()
    return {"label": f"Ministre de {pos}", "kind": "minister", "position": pos, "since": int(row[0] or 0) if row else 0}


def _left(seconds: int) -> str:
    from utils.helpers import fmt_duration
    return fmt_duration(max(0, int(seconds)))


# ─────────────────────────────────────────────────────────────────────────────
#  Destitution
# ─────────────────────────────────────────────────────────────────────────────
async def check_motion(initiator_id: int, target_id: int) -> tuple[bool, str, dict | None]:
    """Vérifie qu'une motion peut être lancée (aucun effet de bord). → (ok, message, office_info)."""
    if initiator_id == target_id:
        return False, "Tu ne peux pas lancer une motion contre toi-même.", None
    info = await office_info(target_id)
    if not info:
        return False, "Ce joueur n'est ni Président ni ministre.", None
    if info["since"] and now() - info["since"] < MOTION_IMMUNITY:
        return False, (f"{info['label']} vient de prendre ses fonctions : il est protégé encore "
                       f"{_left(MOTION_IMMUNITY - (now() - info['since']))}."), info
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM motions WHERE target_id=? AND status IN ('pending','voting')", (target_id,)) as cur:
            if await cur.fetchone():
                return False, "Une motion est déjà en cours contre ce joueur.", info
        async with db.execute("SELECT MAX(initiated_at) FROM motions WHERE target_id=? AND status IN ('rejected','expired')",
                              (target_id,)) as cur:
            last = (await cur.fetchone())[0]
    if last and now() - int(last) < MOTION_TARGET_COOLDOWN:
        return False, f"Une motion contre lui a échoué récemment : nouvelle tentative possible dans {_left(MOTION_TARGET_COOLDOWN - (now() - int(last)))}.", info
    return True, "", info


async def create_motion(initiator_id: int, target_id: int) -> int:
    """Crée la motion (l'initiateur signe d'office). Renvoie son id."""
    async with db_connection() as db:
        cur = await db.execute(
            "INSERT INTO motions (target_id, initiated_by, initiated_at, ends_at, status, signatures_needed, signatures) "
            "VALUES (?,?,?,?,?,?,?)",
            (target_id, initiator_id, now(), now() + MOTION_SIGNATURE_DURATION, "pending", MOTION_SIGNATURES_NEEDED, 1))
        motion_id = cur.lastrowid
        await db.execute("INSERT INTO motion_signatures (motion_id, user_id, signed_at) VALUES (?,?,?)",
                         (motion_id, initiator_id, now()))
        await db.commit()
    await log_event("motion", f"Motion de destitution lancée contre {await display_name(target_id)}", target_id)
    await notify(target_id, "⚖️ Motion de destitution",
                 f"Une motion de destitution est lancée contre toi : {MOTION_SIGNATURES_NEEDED} signatures sont requises "
                 f"en {_left(MOTION_SIGNATURE_DURATION)}, puis les joueurs voteront.", "warning")
    return int(motion_id)


async def sign_motion(user_id: int, target_id: int) -> tuple[bool, str]:
    async with db_connection() as db:
        async with db.execute(
                "SELECT motion_id, signatures_needed, ends_at FROM motions WHERE target_id=? AND status='pending'",
                (target_id,)) as cur:
            m = await cur.fetchone()
        if not m:
            return False, "Aucune motion en attente de signatures contre ce joueur."
        motion_id, needed, ends_at = m
        if int(ends_at) <= now():
            return False, "Le délai pour signer cette motion est écoulé."
        if user_id == target_id:
            return False, "La cible d'une motion ne peut pas la signer."
        cur = await db.execute("INSERT OR IGNORE INTO motion_signatures (motion_id, user_id, signed_at) VALUES (?,?,?)",
                               (motion_id, user_id, now()))
        if not cur.rowcount:
            return False, "Tu as déjà signé cette motion."
        async with db.execute("SELECT COUNT(*) FROM motion_signatures WHERE motion_id=?", (motion_id,)) as c2:
            count = int((await c2.fetchone())[0])
        opened = count >= needed
        if opened:
            await db.execute("UPDATE motions SET signatures=?, status='voting', ends_at=? WHERE motion_id=?",
                             (count, now() + MOTION_VOTE_DURATION, motion_id))
        else:
            await db.execute("UPDATE motions SET signatures=? WHERE motion_id=?", (count, motion_id))
        await db.commit()
    if opened:
        await notify(target_id, "⚖️ Vote de destitution",
                     f"Les signatures sont réunies : les joueurs votent pendant {_left(MOTION_VOTE_DURATION)}.", "warning")
        return True, f"Signatures suffisantes ! Un vote de destitution est ouvert pour {_left(MOTION_VOTE_DURATION)}."
    return True, f"Signature enregistrée ({count}/{needed})."


async def vote_motion(user_id: int, choice: str, target_id: int | None = None) -> tuple[bool, str]:
    """choice = 'pour' | 'contre'. Sans cible, il faut qu'un seul vote soit ouvert."""
    if choice not in ("pour", "contre"):
        return False, "Choix : pour ou contre."
    async with db_connection() as db:
        if target_id is not None:
            sql, args = ("SELECT motion_id, target_id FROM motions WHERE status='voting' AND ends_at>? AND target_id=?", (now(), target_id))
        else:
            sql, args = ("SELECT motion_id, target_id FROM motions WHERE status='voting' AND ends_at>?", (now(),))
        async with db.execute(sql, args) as cur:
            rows = await cur.fetchall()
        if not rows:
            return False, "Aucun vote de destitution actif."
        if len(rows) > 1:
            return False, "Plusieurs votes sont ouverts : précise la cible (@pseudo)."
        motion_id, tgt = rows[0]
        if user_id == tgt:
            return False, "La cible d'une motion ne peut pas voter."
        cur = await db.execute("INSERT OR IGNORE INTO motion_votes (motion_id, user_id, vote, voted_at) VALUES (?,?,?,?)",
                               (motion_id, user_id, choice, now()))
        await db.commit()
    if not cur.rowcount:
        return False, "Tu as déjà voté."
    return True, f"Vote enregistré : {choice}."


async def motions_overview() -> list[dict]:
    """Motions actives, avec noms, poste visé, signatures, votes et temps restant."""
    out = []
    async with db_connection() as db:
        async with db.execute("SELECT motion_id, target_id, initiated_by, status, signatures, signatures_needed, ends_at "
                              "FROM motions WHERE status IN ('pending','voting') ORDER BY motion_id DESC LIMIT 8") as cur:
            rows = await cur.fetchall()
        for mid, tgt, ini, status, sig, need, ends in rows:
            async with db.execute("SELECT SUM(vote='pour'), SUM(vote='contre') FROM motion_votes WHERE motion_id=?", (mid,)) as c2:
                v = await c2.fetchone()
            info = await office_info(tgt)
            out.append({"motion_id": mid, "target": tgt, "target_name": await display_name(tgt), "office": info["label"] if info else "—",
                        "status": status, "signatures": sig, "needed": need, "left": int(ends) - now(),
                        "pour": int(v[0] or 0), "contre": int(v[1] or 0)})
    return out


async def close_motions() -> None:
    """Maintenance : expire les motions sans signatures suffisantes, clôture les votes et applique le résultat."""
    from utils.roles import remove_minister, remove_president, is_president, minister_of
    t = now()
    async with db_connection() as db:
        await db.execute("UPDATE motions SET status='expired' WHERE status='pending' AND ends_at<=?", (t,))
        async with db.execute("SELECT motion_id, target_id, initiated_by FROM motions WHERE status='voting' AND ends_at<=?", (t,)) as cur:
            due = await cur.fetchall()
        await db.commit()
    if not due:
        return
    quorum = motion_quorum(await registered_count())
    for motion_id, target_id, initiator in due:
        async with db_connection() as db:
            async with db.execute("SELECT SUM(vote='pour'), SUM(vote='contre') FROM motion_votes WHERE motion_id=?", (motion_id,)) as cur:
                pour, contre = [int(x or 0) for x in await cur.fetchone()]
        info = await office_info(target_id)
        total = pour + contre
        name = await display_name(target_id)
        majority = motion_majority(info["label"] if info else "")
        accepted = bool(info) and total >= quorum and pour / total >= majority
        status = "accepted" if accepted else "rejected"
        async with db_connection() as db:
            await db.execute("UPDATE motions SET status=? WHERE motion_id=?", (status, motion_id))
            await db.commit()
        if accepted:
            if await is_president(target_id):
                await remove_president(target_id)
            else:
                pos = await minister_of(target_id)
                if pos:
                    await remove_minister(pos)
            await notify(target_id, "⚖️ Destitution", f"Tu as été destitué ({info['label']}) par un vote des joueurs : {pour} pour, {contre} contre. "
                                                     "Tu restes directeur de l'Administration.", "warning")
            await log_event("destitution", f"{name} destitué ({info['label']}) : {pour} pour, {contre} contre", target_id)
        else:
            why = ("quorum non atteint" if total < quorum else f"majorité de {int(majority * 100)} % non atteinte") if info else "poste vacant"
            await notify(target_id, "⚖️ Motion rejetée", f"La motion contre toi est rejetée ({why}) : {pour} pour, {contre} contre.", "info")
            await log_event("motion", f"Motion rejetée contre {name} ({why}) : {pour} pour, {contre} contre", target_id)
        await notify(initiator, "⚖️ Résultat de la motion",
                     f"Motion contre {name} : {'ADOPTÉE' if accepted else 'rejetée'} ({pour} pour, {contre} contre, quorum {quorum}).", "info")


# ─────────────────────────────────────────────────────────────────────────────
#  Mandat du Président
# ─────────────────────────────────────────────────────────────────────────────
async def expire_president_term() -> int | None:
    """Fin du mandat : le Président redevient directeur, une nouvelle élection peut être lancée."""
    from utils.roles import remove_president
    async with db_connection() as db:
        async with db.execute("SELECT occupant_id FROM political_offices WHERE poste='Président' AND elected_at>0 AND elected_at+?<=?",
                              (PRESIDENT_TERM, now())) as cur:
            row = await cur.fetchone()
    if not row or not row[0]:
        return None
    pid = int(row[0])
    await remove_president(pid)
    await log_event("mandat", f"Fin du mandat de {await display_name(pid)} : une nouvelle élection est possible", pid)
    await notify(pid, "🏛️ Fin de mandat", "Ton mandat de Président est terminé. Tu restes directeur de l'Administration ; "
                 "tu peux te représenter à la prochaine élection.", "info")
    return pid


async def term_left(user_id: int) -> int | None:
    """Temps de jeu restant au mandat (None si pas Président élu)."""
    async with db_connection() as db:
        async with db.execute("SELECT elected_at FROM political_offices WHERE poste='Président' AND occupant_id=? AND elected_at>0",
                              (user_id,)) as cur:
            row = await cur.fetchone()
    return None if not row else int(row[0]) + PRESIDENT_TERM - now()
