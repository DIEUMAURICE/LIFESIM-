"""utils/user_lookup.py — Résolution unique d'un joueur : ID d'abord, puis @pseudo.

Beaucoup de joueurs n'ont pas de @username : l'ID numérique doit donc passer PARTOUT (avec ou sans « @ »,
ID négatif des comptes Web inclus). Le pseudo suit (insensible à la casse, « @ » et ponctuation finale ignorés).
Toutes les commandes, formulaires et routeurs doivent passer par `find_user` / `resolve_id`.
"""
from __future__ import annotations

import re

from database import db_connection

_ID_RE = re.compile(r"^-?\d{1,19}$")


def normalize(token) -> str:
    return str(token or "").strip().lstrip("@").strip().rstrip(".,;:!?)").strip()


def is_id(token) -> bool:
    return bool(_ID_RE.match(normalize(token)))


async def find_user(token, registered_only: bool = False) -> dict | None:
    """→ {user_id, username, full_name, registered} ou None. ID prioritaire, puis pseudo exact."""
    ref = normalize(token)
    if not ref:
        return None
    extra = " AND registered=1" if registered_only else ""
    cols = "SELECT user_id, username, full_name, registered FROM users WHERE "
    async with db_connection() as db:
        row = None
        if _ID_RE.match(ref):
            async with db.execute(cols + "user_id=?" + extra, (int(ref),)) as cur:
                row = await cur.fetchone()
        if row is None:
            async with db.execute(cols + "LOWER(username)=LOWER(?)" + extra + " LIMIT 1", (ref,)) as cur:
                row = await cur.fetchone()
    if not row:
        return None
    return {"user_id": row[0], "username": row[1], "full_name": row[2], "registered": row[3]}


async def resolve_id(token, registered_only: bool = False) -> int | None:
    u = await find_user(token, registered_only)
    return u["user_id"] if u else None


async def resolve_user(token, registered_only: bool = False) -> tuple[int, str] | None:
    u = await find_user(token, registered_only)
    return (u["user_id"], u["full_name"] or u["username"] or str(u["user_id"])) if u else None
