# utils/job_guard.py
"""
Garde persistant pour les jobs lents (quotidiens / mensuels).

Le ResilientScheduler repart de zéro à chaque redémarrage du bot : un job
« toutes les 24 h » ne s'exécuterait jamais si le bot redémarre plus souvent.
`run_if_due` mémorise la dernière exécution en base (table job_state).

• Premier lancement d'un job : on note l'heure et on N'EXÉCUTE PAS
  (évite un impôt / tirage surprise juste après un déploiement).
• La réservation du créneau est atomique et faite AVANT l'exécution
  (« au plus une fois ») : un job qui touche à l'argent ne doit jamais
  être relancé deux fois pour le même créneau.
"""
import logging
from collections.abc import Awaitable, Callable

import aiosqlite

from config import DB_PATH
from database import db_connection
from utils.gametime import game_now, game_datetime

logger = logging.getLogger(__name__)

_CREATE = (
    "CREATE TABLE IF NOT EXISTS job_state ("
    "name TEXT PRIMARY KEY, last_run INTEGER NOT NULL DEFAULT 0)"
)


async def run_if_due(name: str, interval: int, fn: Callable[[], Awaitable[None]]) -> bool:
    """Exécute `fn` si `interval` secondes DE JEU se sont écoulées. Retourne True si exécuté."""
    t = game_now()          # intervalle en secondes de JEU (86400 = 1 jour de jeu = 10 h réelles)
    async with db_connection() as db:
        await db.execute(_CREATE)
        cur = await db.execute("SELECT last_run FROM job_state WHERE name=?", (name,))
        row = await cur.fetchone()
        if row is None:
            await db.execute(
                "INSERT OR IGNORE INTO job_state (name, last_run) VALUES (?, ?)", (name, t)
            )
            await db.commit()
            logger.info("⏱️ Job %s initialisé (1er passage dans %ss).", name, interval)
            return False
        if t - row[0] < interval:
            return False
        # Réservation atomique du créneau
        cur = await db.execute(
            "UPDATE job_state SET last_run=? WHERE name=? AND last_run=?", (t, name, row[0])
        )
        await db.commit()
        if cur.rowcount != 1:
            return False
    logger.info("▶️ Job %s exécuté.", name)
    await fn()
    return True


def guarded(name: str, interval: int, fn: Callable[[], Awaitable[None]]):
    """Fabrique un job sans argument, utilisable dans un JobSpec."""
    async def _job() -> None:
        await run_if_due(name, interval, fn)
    _job.__name__ = f"guarded_{name}"
    return _job


async def run_if_new_month(name: str, fn: Callable[[], Awaitable[None]]) -> bool:
    """Exécute `fn` une fois par MOIS CIVIL de jeu (au changement de mois). Même garanties que
    run_if_due : 1er passage = on mémorise sans exécuter ; réservation atomique avant exécution."""
    t = game_now()
    ym = lambda ts: (lambda d: d["year"] * 12 + d["month"])(game_datetime(ts))
    async with db_connection() as db:
        await db.execute(_CREATE)
        cur = await db.execute("SELECT last_run FROM job_state WHERE name=?", (name,))
        row = await cur.fetchone()
        if row is None:
            await db.execute("INSERT OR IGNORE INTO job_state (name, last_run) VALUES (?, ?)", (name, t))
            await db.commit()
            return False
        if ym(t) <= ym(row[0]):
            return False
        cur = await db.execute(
            "UPDATE job_state SET last_run=? WHERE name=? AND last_run=?", (t, name, row[0])
        )
        await db.commit()
        if cur.rowcount != 1:
            return False
    logger.info("▶️ Job mensuel %s exécuté.", name)
    await fn()
    return True


def guarded_monthly(name: str, fn: Callable[[], Awaitable[None]]):
    async def _job() -> None:
        await run_if_new_month(name, fn)
    _job.__name__ = f"guarded_monthly_{name}"
    return _job
