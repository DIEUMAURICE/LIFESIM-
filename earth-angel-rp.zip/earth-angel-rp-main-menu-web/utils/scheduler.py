# utils/scheduler.py
from utils.swallow import swallowed
import asyncio
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass

from utils.gametime import game_seconds_to_real


logger = logging.getLogger(__name__)
AsyncJob = Callable[[], Awaitable[None]]


@dataclass(frozen=True)
class JobSpec:
    name: str
    function: AsyncJob
    interval: int
    timeout: int = 120
    run_immediately: bool = False
    # False (défaut) : `interval` en secondes RÉELLES (tâches techniques : notifications,
    #                  nettoyages, sauvegardes, balayage des expirations).
    # True           : `interval` en secondes de JEU (24 h de jeu = 10 h réelles) — pour les
    #                  tâches qui appliquent un effet « par heure / par jour » DE JEU.
    game_time: bool = False

    @property
    def real_interval(self) -> int:
        return game_seconds_to_real(self.interval) if self.game_time else self.interval


class ResilientScheduler:
    MAX_BACKOFF = 10          # intervalle maximal après échecs répétés : 10 × l'intervalle normal
    STOP_GRACE = 30           # secondes laissées aux jobs en cours (transaction SQLite) avant d'annuler

    def __init__(self):
        self._tasks: list[asyncio.Task] = []
        self._stop = asyncio.Event()

    def start(self, jobs: list[JobSpec]) -> None:
        if self._tasks:
            return
        self._stop.clear()
        for job in jobs:
            task = asyncio.create_task(
                self._job_loop(job),
                name=f"lifesim:{job.name}",
            )
            self._tasks.append(task)
        logger.info("Scheduler démarré avec %s jobs", len(jobs))

    async def _job_loop(self, job: JobSpec) -> None:
        if not job.run_immediately:
            try:
                await asyncio.wait_for(
                    self._stop.wait(),
                    timeout=max(1, job.real_interval),
                )
                return
            except asyncio.TimeoutError:
                swallowed('utils/scheduler.py')

        failures = 0   # échecs consécutifs → intervalle multiplié (backoff), remis à zéro au premier succès
        while not self._stop.is_set():
            try:
                await asyncio.wait_for(
                    job.function(),
                    timeout=max(1, job.timeout),
                )
                failures = 0
            except asyncio.CancelledError:
                raise
            except asyncio.TimeoutError:
                failures += 1
                logger.error(
                    "Job %s dépassé après %ss (échec consécutif n°%d)",
                    job.name,
                    job.timeout,
                    failures,
                )
            except Exception:
                failures += 1
                logger.exception("Échec du job %s (échec consécutif n°%d)", job.name, failures)

            # Backoff : ×2 par échec consécutif, plafonné à ×MAX_BACKOFF (évite le spam de logs et la charge DB).
            factor = min(self.MAX_BACKOFF, 2 ** failures) if failures else 1
            try:
                await asyncio.wait_for(
                    self._stop.wait(),
                    timeout=max(1, job.real_interval * factor),
                )
            except asyncio.TimeoutError:
                continue

    async def stop(self) -> None:
        """Arrêt en douceur : on signale l'arrêt, on laisse les jobs en cours finir leur transaction
        (jusqu'à STOP_GRACE s), et on n'annule brutalement qu'en dernier recours."""
        self._stop.set()
        tasks = list(self._tasks)
        if tasks:
            done, pending = await asyncio.wait(tasks, timeout=self.STOP_GRACE)
            if pending:
                logger.warning(
                    "Scheduler : %d job(s) encore actifs après %ss, annulation forcée",
                    len(pending), self.STOP_GRACE,
                )
                for task in pending:
                    task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
        self._tasks.clear()
        logger.info("Scheduler arrêté proprement")