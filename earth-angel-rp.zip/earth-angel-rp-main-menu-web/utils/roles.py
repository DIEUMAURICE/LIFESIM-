# utils/roles.py — qui joue, qui fait de la politique
"""
• Tout le monde peut jouer (crimes, commerce, armes, métiers…), Admins N2, Game Leaders et Leads compris.
• Seule la POLITIQUE et les ÉLECTIONS (vote, candidature, cabinet) sont fermées aux Admins N2, Game Leaders et Leads :
  ils administrent, sans intervenir dans la vie politique. Seuls les joueurs et les Admins N1 y participent.
• La politique est réservée aux Admins N1 : ils se présentent aux élections et peuvent devenir président.
  Les joueurs votent. Le président élu dirige l'Administration et nomme les MINISTRES (joueur ou Admin N1) :
  un ministre est un grade de l'Administration qui dirige une faction d'État (voir config.MINISTRIES).
"""
from utils.swallow import swallowed
from config import (POLITICAL_ROLES, PLAYABLE_ROLES, PRESIDENT_FACTION, MINISTRIES,
                    ADMIN_RANK_DIRECTOR, ADMIN_RANK_MINISTER, ADMIN_RANK_PRESIDENT)

NOT_PLAYER_TEXT = ("🚫 Les Admins N2, Game Leaders et Leads n'interviennent pas dans la politique ni les élections : "
                   "ils administrent. Seuls les joueurs et les Admins N1 y participent. "
                   "Le reste du jeu t'est ouvert.")
NOT_POLITICIAN_TEXT = ("🏛️ La politique est réservée aux <b>Admins N1</b> : ils se présentent aux élections "
                       "et peuvent devenir président. Les joueurs votent pour eux.")


async def role_of(user_id: int) -> str:
    from utils.decorators import get_user_role_async
    return await get_user_role_async(user_id)


async def can_play(user_id: int) -> bool:
    """Participation à la POLITIQUE / aux ÉLECTIONS (vote, candidature, cabinet) : joueurs et Admins N1 seulement.
    (Le reste du jeu est ouvert à tous les rôles : cette fonction ne doit plus bloquer d'autres actions.)"""
    return await role_of(user_id) in PLAYABLE_ROLES


async def is_politician(user_id: int) -> bool:
    return await role_of(user_id) in POLITICAL_ROLES


async def _enter_administration(db, user_id: int, rank: int) -> None:
    """Place `user_id` dans la faction Administration au grade `rank` (il quitte son éventuel poste ailleurs)."""
    await db.execute("DELETE FROM company_members WHERE user_id=?", (user_id,))
    await db.execute("DELETE FROM sante_staff WHERE user_id=?", (user_id,))
    await db.execute("DELETE FROM ordre_staff WHERE user_id=?", (user_id,))
    await db.execute(
        "INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) VALUES (?,?,?,0,?) "
        "ON CONFLICT(user_id) DO UPDATE SET faction=excluded.faction, rank=excluded.rank",
        (user_id, PRESIDENT_FACTION, rank, _now()))


def _now() -> int:
    from database import now
    return now()


async def install_president(user_id: int) -> None:
    """Le président élu prend la tête de l'Administration (grade le plus haut) ; l'ancien président redevient
    simple directeur. Le nouveau président quitte son éventuelle faction précédente."""
    from database import db_connection
    from utils import factions
    m = await factions.get_membership(user_id)
    if m and m["faction"] != PRESIDENT_FACTION:
        await factions.leave_faction(user_id)
    async with db_connection() as db:
        await db.execute("UPDATE faction_members SET rank=? WHERE faction=? AND rank=? AND user_id<>?",
                         (ADMIN_RANK_DIRECTOR, PRESIDENT_FACTION, ADMIN_RANK_PRESIDENT, user_id))
        await db.execute("DELETE FROM cabinet_positions WHERE occupant_id=?", (user_id,))   # un président n'est plus ministre
        await _enter_administration(db, user_id, ADMIN_RANK_PRESIDENT)
        await db.commit()


# ─────────────────────────────────────────────────────────────────────────────
#  Gouvernement : les ministres sont des GRADES de l'Administration
# ─────────────────────────────────────────────────────────────────────────────
async def minister_of(user_id: int) -> str | None:
    """Nom du ministère (clé de config.MINISTRIES) que dirige `user_id`, sinon None."""
    from database import db_connection
    async with db_connection() as db:
        async with db.execute("SELECT position FROM cabinet_positions WHERE occupant_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
    return row[0] if row else None


async def is_president(user_id: int) -> bool:
    """Président en exercice : élu (table political_offices) ou installé au sommet de l'Administration."""
    from database import db_connection
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM political_offices WHERE poste='Président' AND occupant_id=?", (user_id,)) as cur:
            if await cur.fetchone():
                return True
        async with db.execute("SELECT 1 FROM faction_members WHERE user_id=? AND faction=? AND rank>=?",
                              (user_id, PRESIDENT_FACTION, ADMIN_RANK_PRESIDENT)) as cur:
            return bool(await cur.fetchone())


async def install_minister(actor_id: int, user_id: int, position: str) -> tuple[bool, str]:
    """Le Président nomme un ministre : le nommé entre dans l'Administration au grade « Ministre » et dirige le
    ministère. L'ancien titulaire du ministère redevient directeur de l'Administration."""
    from database import db_connection
    from utils import factions
    if position not in MINISTRIES:
        return False, "Ministère inconnu."
    if await is_president(user_id):
        return False, "Le Président ne peut pas être ministre."
    m = await factions.get_membership(user_id)
    if m and m["faction"] != PRESIDENT_FACTION:
        await factions.leave_faction(user_id)          # rend ses armes de dotation, libère son poste ailleurs
    async with db_connection() as db:
        async with db.execute("SELECT occupant_id FROM cabinet_positions WHERE position=?", (position,)) as cur:
            old = await cur.fetchone()
        if old and old[0] and old[0] != user_id:
            await db.execute("UPDATE faction_members SET rank=? WHERE user_id=? AND faction=? AND rank=?",
                             (ADMIN_RANK_DIRECTOR, old[0], PRESIDENT_FACTION, ADMIN_RANK_MINISTER))
        await db.execute("DELETE FROM cabinet_positions WHERE position=? OR occupant_id=?", (position, user_id))
        await db.execute("INSERT INTO cabinet_positions(position, occupant_id, appointed_by, appointed_at) VALUES (?,?,?,?)",
                         (position, user_id, actor_id, _now()))
        await _enter_administration(db, user_id, ADMIN_RANK_MINISTER)
        await db.commit()
    return True, f"{MINISTRIES[position]['emoji']} Ministre de {position}"


async def remove_minister(position: str) -> int | None:
    """Retire le titulaire du ministère : il reste dans l'Administration, comme directeur. Renvoie son id."""
    from database import db_connection
    async with db_connection() as db:
        async with db.execute("SELECT occupant_id FROM cabinet_positions WHERE position=?", (position,)) as cur:
            row = await cur.fetchone()
        if not row:
            return None
        await db.execute("DELETE FROM cabinet_positions WHERE position=?", (position,))
        await db.execute("UPDATE faction_members SET rank=? WHERE user_id=? AND faction=? AND rank=?",
                         (ADMIN_RANK_DIRECTOR, row[0], PRESIDENT_FACTION, ADMIN_RANK_MINISTER))
        await db.commit()
    return row[0]


async def remove_president(user_id: int) -> bool:
    """Fin de mandat (démission ou destitution) : le président redevient directeur de l'Administration."""
    from database import db_connection
    async with db_connection() as db:
        cur = await db.execute("DELETE FROM political_offices WHERE poste='Président' AND occupant_id=?", (user_id,))
        await db.execute("UPDATE faction_members SET rank=? WHERE user_id=? AND faction=? AND rank=?",
                         (ADMIN_RANK_DIRECTOR, user_id, PRESIDENT_FACTION, ADMIN_RANK_PRESIDENT))
        await db.execute("UPDATE users SET political_post='' WHERE user_id=?", (user_id,))
        await db.commit()
    return bool(cur.rowcount)


async def can_direct_faction(user_id: int, faction: str, role: str = "") -> bool:
    """Peut nommer / révoquer le chef de `faction` : Game Leader et plus, ou le ministre de cette faction
    (Intérieur → police, Défense → armée, Justice → justice, Santé → santé). Le Président n'a pas de ministère
    mais conserve la main sur le Trésor et sur ses ministres."""
    from config import role_level
    role = role or await role_of(user_id)
    if role_level(role) >= role_level("GAME_LEADER"):
        return True
    pos = await minister_of(user_id)
    return bool(pos and faction != PRESIDENT_FACTION and MINISTRIES[pos]["faction"] == faction)


import functools


async def _deny(update, text: str) -> None:
    msg = update.effective_message
    if update.callback_query:
        try:
            await update.callback_query.answer(text.replace("<b>", "").replace("</b>", ""), show_alert=True)
            return
        except Exception:
            swallowed('utils/roles.py')
    if msg:
        await msg.reply_text(text, parse_mode="HTML")


def politician_only(func):
    """Commande réservée aux Admins N1 (candidature, lancement d'élection)."""
    @functools.wraps(func)
    async def wrapper(update, context, *args, **kwargs):
        user = update.effective_user
        if not user or not await is_politician(user.id):
            await _deny(update, NOT_POLITICIAN_TEXT)
            return
        return await func(update, context, *args, **kwargs)
    return wrapper


def players_only(func):
    """Action POLITIQUE / ÉLECTION : interdite aux Admins N2, Game Leaders et Leads (ils n'y interviennent pas)."""
    @functools.wraps(func)
    async def wrapper(update, context, *args, **kwargs):
        user = update.effective_user
        if not user or not await can_play(user.id):
            await _deny(update, NOT_PLAYER_TEXT)
            return
        return await func(update, context, *args, **kwargs)
    return wrapper
