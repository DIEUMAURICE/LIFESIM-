"""
utils/groups.py — Groupes Telegram autorisés.

Le bot ne fonctionne dans un groupe QUE si celui-ci est autorisé :
  • ALLOWED_GROUP_IDS (.env) : groupes autorisés dès le départ ;
  • /autoriser_groupe : ajout par un Lead Staff ou plus (stocké en base, sans redémarrage).
Dans un groupe non autorisé, le bot NE QUITTE PAS : il reste, ne fonctionne pas et répond à chaque message par l'avertissement « contacter @mauridieu ». En discussion privée, rien ne change.
Si c'est un Lead Staff (ou plus) qui ajoute le bot, le groupe est autorisé automatiquement.
"""
from __future__ import annotations

from utils.swallow import swallowed
import html
import logging
import time

from config import ALLOWED_GROUP_IDS, GAME_NAME, GROUP_AUTH_CONTACT, role_level
from database import db_connection, now

logger = logging.getLogger(__name__)

GROUP_TYPES = ("group", "supergroup")
STAFF_MIN_ROLE = "LEAD_STAFF_GLOBAL"
_ready = False
_warned: dict[int, float] = {}          # chat_id → dernier avertissement (anti-flood)
WARN_MIN_INTERVAL = 3.0                 # secondes : évite seulement le flood Telegram


async def _ensure() -> None:
    global _ready
    if _ready:
        return
    async with db_connection() as db:
        await db.execute(
            "CREATE TABLE IF NOT EXISTS allowed_groups ("
            "chat_id INTEGER PRIMARY KEY, title TEXT, added_by INTEGER, added_at INTEGER)")
        await db.commit()
    _ready = True


async def is_authorized(chat_id: int) -> bool:
    if chat_id in ALLOWED_GROUP_IDS:
        return True
    await _ensure()
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM allowed_groups WHERE chat_id=?", (chat_id,)) as cur:
            return await cur.fetchone() is not None


async def add_group(chat_id: int, title: str, by: int) -> bool:
    """True si le groupe vient d'être ajouté, False s'il était déjà autorisé."""
    if await is_authorized(chat_id):
        if title:
            async with db_connection() as db:
                await db.execute("UPDATE allowed_groups SET title=? WHERE chat_id=?", (title, chat_id))
                await db.commit()
        return False
    async with db_connection() as db:
        await db.execute("INSERT OR REPLACE INTO allowed_groups(chat_id, title, added_by, added_at) VALUES (?,?,?,?)",
                         (chat_id, title or "", by, now()))
        await db.commit()
    return True


async def remove_group(chat_id: int) -> bool:
    await _ensure()
    async with db_connection() as db:
        cur = await db.execute("DELETE FROM allowed_groups WHERE chat_id=?", (chat_id,))
        await db.commit()
        return cur.rowcount > 0


async def list_groups() -> list[tuple[int, str, str]]:
    """[(chat_id, titre, origine)] : origine = 'env' (fichier .env) ou 'base'."""
    await _ensure()
    out: list[tuple[int, str, str]] = []
    async with db_connection() as db:
        async with db.execute("SELECT chat_id, title FROM allowed_groups ORDER BY added_at") as cur:
            rows = await cur.fetchall()
    seen = set()
    for cid, title in rows:
        out.append((cid, title or "", "base")); seen.add(cid)
    for cid in ALLOWED_GROUP_IDS:
        if cid not in seen:
            out.append((cid, "", "env"))
    return out


def warning_text(chat_id: int) -> str:
    return (f"⛔ <b>Groupe non autorisé</b>\n"
            f"{GAME_NAME} ne fonctionne pas dans ce groupe.\n\n"
            f"Pour obtenir l'autorisation, contacte <b>{html.escape(GROUP_AUTH_CONTACT)}</b> "
            f"en lui donnant l'ID du groupe :\n<code>{chat_id}</code>")


async def is_staff(user_id: int) -> bool:
    from utils.decorators import get_user_role_async
    return role_level(await get_user_role_async(user_id)) >= role_level(STAFF_MIN_ROLE)


async def _warn(context, chat) -> None:
    """Envoie le message « contacter @mauridieu ». Le bot ne quitte JAMAIS le groupe :
    il y reste, ne fonctionne pas et répète ce message (léger anti-flood Telegram)."""
    last = _warned.get(chat.id, 0)
    if time.monotonic() - last < WARN_MIN_INTERVAL:
        return
    _warned[chat.id] = time.monotonic()
    try:
        await context.bot.send_message(chat.id, warning_text(chat.id), parse_mode="HTML")
    except Exception:
        logger.debug("Avertissement groupe impossible (%s)", chat.id, exc_info=True)


async def group_guard(update, context) -> bool:
    """False = l'update doit être ignorée (groupe non autorisé). À appeler en tête du garde global."""
    try:
        member = getattr(update, "my_chat_member", None)
        if member is not None:                                   # le bot vient d'être ajouté / retiré
            chat = member.chat
            logger.info("my_chat_member : chat=%s (%s) par=%s statut=%s", chat.id, chat.type,
                        getattr(member.from_user, "id", None), member.new_chat_member.status)
            if chat.type not in GROUP_TYPES:
                return True
            if member.new_chat_member.status not in ("member", "administrator"):
                return False                                     # retiré : rien à faire
            adder = member.from_user
            if await is_authorized(chat.id):
                if adder and await is_staff(adder.id):
                    try:
                        await context.bot.send_message(chat.id, f"✅ Groupe déjà autorisé : {GAME_NAME} est actif ici.")
                    except Exception:
                        swallowed('utils/groups.py')
                return False
            if adder and await is_staff(adder.id):
                await add_group(chat.id, chat.title or "", adder.id)
                try:
                    await context.bot.send_message(chat.id, f"✅ Groupe autorisé : {GAME_NAME} est actif ici.")
                except Exception:
                    swallowed('utils/groups.py')
                return False
            await _warn(context, chat)
            return False

        chat = update.effective_chat
        if chat is None or chat.type not in GROUP_TYPES:
            return True                                          # privé, canal… : inchangé
        if await is_authorized(chat.id):
            return True
        msg = update.effective_message
        user = update.effective_user
        text = (msg.text or "") if msg else ""
        if user and text.startswith("/autoriser_groupe") and await is_staff(user.id):
            return True                                          # un Lead peut autoriser depuis le groupe
        await _warn(context, chat)
        return False
    except Exception:
        logger.exception("group_guard : erreur (update laissée passer)")
        return True
