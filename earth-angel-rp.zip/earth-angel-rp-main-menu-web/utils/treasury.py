# utils/treasury.py — 🏛️ Trésor public de l'Administration
"""
Tout l'argent que les joueurs dépensent AU JEU (études, casino, transports, état civil, politique…)
et l'impôt sur la fortune arrivent dans le Trésor public (`faction_state._state`).

L'Administration (faction « mairie ») le gère : le Président peut le redistribuer à toutes les factions
gouvernementales (police, santé, justice, armée) ; chaque ministre alimente la faction de son ministère.
Chaque entrée/sortie est comptabilisée par source (table treasury_flow) et chaque dotation est journalisée
(table treasury_grants) : l'économie reste lisible et sans abus.
"""
from __future__ import annotations

import logging

import aiosqlite

from config import (GOV_FACTIONS, PRESIDENT_FACTION, MINISTRIES, ADMIN_RANK_MINISTER, ADMIN_RANK_PRESIDENT)
from database import db_connection, now
from utils.factions import coffre_add, get_membership

logger = logging.getLogger(__name__)

STATE = "_state"
DAY = 86_400
GRANT_MIN_RANK = ADMIN_RANK_MINISTER   # Ministre et au-dessus (Ministre, Président)
GRANT_MAX_SHARE = 0.5               # une dotation ne peut pas vider plus de la moitié du Trésor d'un coup
GRANT_MIN = 1_000

SOURCE_LABELS = {
    "impot": "🧾 Impôt sur la fortune", "etudes": "🎓 Études", "casino": "🎰 Casino", "transports": "🚗 Transports",
    "vehicules": "🚘 Véhicules", "etat_civil": "💍 État civil", "politique": "🗳️ Politique", "amendes": "🚓 Amendes",
    "justice": "⚖️ Justice", "gangs": "🕶️ Gangs", "agriculture": "🌱 Agriculture", "loisirs": "🏋️ Loisirs",
    "vie_courante": "🛒 Vie courante", "reseaux": "🌐 Réseaux", "arene": "⚔️ Arène",
}


def label(source: str) -> str:
    return SOURCE_LABELS.get(source, f"📦 {source}")


async def _flow(db, source: str, kind: str, amount: int) -> None:
    await db.execute(
        "INSERT INTO treasury_flow(day, source, kind, amount) VALUES (?,?,?,?) "
        "ON CONFLICT(day, source, kind) DO UPDATE SET amount=amount+excluded.amount",
        (now() // DAY, source, kind, int(amount)))


async def collect(db, amount: int, source: str) -> None:
    """Verse `amount` au Trésor public dans la transaction `db` de l'appelant."""
    if amount <= 0:
        return
    await coffre_add(db, STATE, amount)
    await _flow(db, source, "in", amount)


async def balance() -> int:
    async with db_connection() as db:
        async with db.execute("SELECT budget FROM faction_state WHERE faction=?", (STATE,)) as cur:
            row = await cur.fetchone()
    return int(row[0]) if row else 0


async def grant_targets(user_id: int, role: str = "") -> list[str]:
    """Coffres que `user_id` peut alimenter depuis le Trésor.
    • Game Leader et plus, Président : toutes les factions.
    • Ministre : la faction de son ministère (Économie : l'Administration elle-même).
    • Les autres : aucune."""
    from config import role_level
    if role and role_level(role) >= role_level("GAME_LEADER"):
        return list(GOV_FACTIONS)
    m = await get_membership(user_id)
    if not m or m["faction"] != PRESIDENT_FACTION:
        return []
    if m["rank"] >= ADMIN_RANK_PRESIDENT:
        return list(GOV_FACTIONS)
    if m["rank"] >= ADMIN_RANK_MINISTER:
        from utils.roles import minister_of
        pos = await minister_of(user_id)
        if pos:
            return [MINISTRIES[pos]["faction"]]
    return []


async def can_set_tax(user_id: int, role: str = "") -> bool:
    """Régler l'impôt sur la fortune : Ministre de l'Économie, Président, ou direction du jeu (Game Leader et plus)."""
    from config import role_level
    if role and role_level(role) >= role_level("GAME_LEADER"):
        return True
    m = await get_membership(user_id)
    if not m or m["faction"] != PRESIDENT_FACTION:
        return False
    if m["rank"] >= ADMIN_RANK_PRESIDENT:
        return True
    from utils.roles import minister_of
    return await minister_of(user_id) == "Économie"


async def can_grant(user_id: int, role: str = "") -> bool:
    """Président, ministres (pour leur ministère), ou direction du jeu (Game Leader et au-dessus)."""
    return bool(await grant_targets(user_id, role))


async def grant(actor_id: int, target: str, amount: int, note: str = "", role: str = "") -> tuple[bool, str]:
    """Verse `amount` du Trésor public vers le coffre d'une faction gouvernementale."""
    if target not in GOV_FACTIONS:
        return False, "Faction inconnue."
    allowed = await grant_targets(actor_id, role)
    if not allowed:
        return False, "Seuls le Président et les ministres peuvent distribuer le Trésor."
    if target not in allowed:
        return False, "Ce coffre dépend d'un autre ministère : seul le Président (ou le ministre concerné) peut l'alimenter."
    amount = int(amount)
    if amount < GRANT_MIN:
        return False, f"Dotation minimale : {GRANT_MIN:,}."
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES (?,0)", (STATE,))
            async with db.execute("SELECT budget FROM faction_state WHERE faction=?", (STATE,)) as cur:
                have = int((await cur.fetchone())["budget"])
            if amount > have:
                await db.rollback()
                return False, f"Le Trésor ne contient que {have:,}."
            if amount > int(have * GRANT_MAX_SHARE) and have > 4 * GRANT_MIN:
                await db.rollback()
                return False, (f"Garde-fou : une dotation ne peut pas dépasser {int(GRANT_MAX_SHARE * 100)} % du Trésor "
                               f"({int(have * GRANT_MAX_SHARE):,}).")
            await coffre_add(db, STATE, -amount)
            await coffre_add(db, target, amount)
            await _flow(db, f"dotation:{target}", "out", amount)
            await db.execute("INSERT INTO treasury_grants(actor_id, target, amount, note, created_at) VALUES (?,?,?,?,?)",
                             (actor_id, target, amount, note[:120], now()))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"{amount:,} versés au coffre {GOV_FACTIONS[target]['emoji']} {GOV_FACTIONS[target]['name']}."


async def report(days: int = 1) -> dict:
    """Résumé des `days` derniers jours de jeu : entrées par source, sorties, dotations récentes."""
    since = now() // DAY - (days - 1)
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT source, SUM(amount) AS a FROM treasury_flow WHERE day>=? AND kind='in' "
                              "GROUP BY source ORDER BY a DESC", (since,)) as cur:
            ins = [(r["source"], int(r["a"])) for r in await cur.fetchall()]
        async with db.execute("SELECT SUM(amount) AS a FROM treasury_flow WHERE day>=? AND kind='out'", (since,)) as cur:
            out = int((await cur.fetchone())["a"] or 0)
        async with db.execute("SELECT actor_id, target, amount, note, created_at FROM treasury_grants "
                              "ORDER BY id DESC LIMIT 5") as cur:
            grants = [dict(r) for r in await cur.fetchall()]
    return {"in": ins, "total_in": sum(a for _, a in ins), "out": out, "grants": grants}
