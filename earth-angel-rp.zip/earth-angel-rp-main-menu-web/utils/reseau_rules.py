# utils/reseau_rules.py — Règles chiffrées du Réseau RP (partagées par le jeu, l'aide et les cours)
POST_MAX = 300                # caractères par publication
COMMENT_MAX = 200
DM_MAX = 300
POST_COOLDOWN_HOURS = 2       # heures DE JEU entre deux publications (moteur unique : handlers/social.cmd_poster)
COMMENTS_PER_POST = 3
DMS_PER_HOUR = 30
XP_POST = 40
POST_COOLDOWN_KEY = "post_cooldown"          # clé du cooldown de publication (bot ET application web)
POST_COOLDOWN_SECONDS = POST_COOLDOWN_HOURS * 3600
FOLLOW_BONUS_FOLLOWERS = 10   # audience sociale gagnée pour chaque vrai abonné
MUTE_HOURS = 24
