# utils/chain.py — logique de la chaîne : métiers → biens → entreprises → produits finis → effets
"""
Aucune dépendance Telegram : tout est testable avec une base SQLite.

  • Biens (items)      : intrants des métiers et produits finis sont de vrais objets d'inventaire,
                         donc le marché des commerçants fonctionne tel quel.
  • Métiers            : rang par métier, promotion par compétences, biens fournis à chaque mission.
  • Entreprises        : stade, lignes de production, équipes, prix d'achat / de gros, livraisons.
  • Produits finis     : effets (apply_effects), objets consommables, prestations directes.

La production quotidienne elle-même est dans utils/payroll.py (produce_company).
"""
from __future__ import annotations

import logging
import random

import aiosqlite

from config_chain import (
    INTRANTS, RECIPES, RECIPES_BY_SECTOR, JOB_GOOD, JOB_RANKS, MAX_JOB_RANK, JOB_PROMOTION, SCORE_GOODS,
    GRANDE_COMMANDE, GRANDE_COMMANDE_RANK, COUNTER_PRICE_RATIO, COUNTER_DAILY_CAP, BID_MIN, BID_MAX,
    BID_DEFAULT, STAGES, MAX_STAGE, SERVICE_COMMISSION, PHYSICAL_SKILLS, DIPLOMES_ORDER,
    clamp_stage, stage_cap, job_rank_mult, job_rank_name, sector_inputs, sector_depts, npc_price,
    wholesale_default, final_service_dept, describe_effects, good_info, _round50,
)
from database import db_connection, now

logger = logging.getLogger(__name__)

DAY = 86400
STOCK_CAP_PER_GOOD = 80          # stock max d'un intrant, × capacité du stade
MERCHANT_JOB = "Commerçant"


def game_day() -> int:
    return now() // DAY


# ═════════════════════════════════════════════════════════════════════════════
# Objets : intrants et produits finis dans l'inventaire
# ═════════════════════════════════════════════════════════════════════════════
def item_name(key: str) -> str:
    return good_info(key)["name"]


def key_of_item_name(name: str) -> str | None:
    for k, v in INTRANTS.items():
        if v["name"] == name:
            return k
    for k, v in RECIPES.items():
        if v["type"] == "bien" and v["name"] == name:
            return k
    return None


def item_goods_keys() -> list[str]:
    """Clés des biens qui existent comme objets d'inventaire."""
    return list(INTRANTS) + [k for k, v in RECIPES.items() if v["type"] == "bien"]


async def item_id(db, key: str) -> int:
    """item_id du bien (créé à la demande, une seule fois par nom)."""
    name = item_name(key)
    async with db.execute("SELECT item_id FROM items WHERE name=?", (name,)) as cur:
        row = await cur.fetchone()
    if row:
        return int(row[0])
    if key in INTRANTS:
        g = INTRANTS[key]
        await db.execute(
            "INSERT OR IGNORE INTO items (name, type, rarity, value, effect_type, effect_value, emoji, description) "
            "VALUES (?, 'intrant', 'common', ?, NULL, 0, ?, ?)",
            (g["name"], g["ref"], g["emoji"], f"Bien de base fourni par le métier {g['job'] or 'jardin'}. "
                                              f"Les entreprises l'achètent pour fabriquer leurs produits."))
    else:
        r = RECIPES[key]
        await db.execute(
            "INSERT OR IGNORE INTO items (name, type, rarity, value, effect_type, effect_value, emoji, description) "
            "VALUES (?, 'consumable', 'uncommon', ?, 'chain', 0, ?, ?)",
            (r["name"], npc_price(key), r["emoji"], f"{r['desc']} Effet : {describe_effects(r['effects'])}"))
    async with db.execute("SELECT item_id FROM items WHERE name=?", (name,)) as cur:
        return int((await cur.fetchone())[0])


async def inv_add(db, user_id: int, key: str, qty: int) -> None:
    iid = await item_id(db, key)
    await db.execute(
        "INSERT INTO inventory (user_id, item_id, item_type, item_name, quantity, acquired_at) "
        "VALUES (?,?,?,?,?,?) ON CONFLICT(user_id, item_id) DO UPDATE SET quantity=quantity+excluded.quantity",
        (user_id, iid, "chain", item_name(key), qty, now()))


async def inv_remove(db, user_id: int, key: str, qty: int) -> bool:
    iid = await item_id(db, key)
    cur = await db.execute(
        "UPDATE inventory SET quantity=quantity-? WHERE user_id=? AND item_id=? AND quantity>=?",
        (qty, user_id, iid, qty))
    if cur.rowcount != 1:
        return False
    await db.execute("DELETE FROM inventory WHERE user_id=? AND item_id=? AND quantity<=0", (user_id, iid))
    return True


async def user_goods(user_id: int) -> dict[str, int]:
    """{clé de bien: quantité} pour tous les biens de la chaîne que possède le joueur."""
    names = {item_name(k): k for k in item_goods_keys()}
    marks = ",".join("?" * len(names))
    async with db_connection() as db:
        async with db.execute(
                f"SELECT i.name, inv.quantity FROM inventory inv JOIN items i ON i.item_id=inv.item_id "
                f"WHERE inv.user_id=? AND inv.quantity>0 AND i.name IN ({marks})",
                (user_id, *names)) as cur:
            return {names[r[0]]: int(r[1]) for r in await cur.fetchall()}


async def _stat(db, user_id: int, **inc) -> None:
    await db.execute("INSERT OR IGNORE INTO user_chain_stats(user_id) VALUES (?)", (user_id,))
    sets = ", ".join(f"{k}={k}+?" for k in inc)
    await db.execute(f"UPDATE user_chain_stats SET {sets} WHERE user_id=?", (*inc.values(), user_id))


async def _daily_get(db, scope: str, owner: int, good: str, day: int) -> int:
    async with db.execute("SELECT qty FROM chain_daily WHERE scope=? AND owner=? AND good=? AND day=?",
                          (scope, owner, good, day)) as cur:
        row = await cur.fetchone()
    return int(row[0]) if row else 0


async def _daily_add(db, scope: str, owner: int, good: str, day: int, qty: int) -> None:
    await db.execute(
        "INSERT INTO chain_daily(scope, owner, good, day, qty) VALUES (?,?,?,?,?) "
        "ON CONFLICT(scope, owner, good, day) DO UPDATE SET qty=qty+excluded.qty",
        (scope, owner, good, day, qty))


# ═════════════════════════════════════════════════════════════════════════════
# Métiers : rang, promotion, biens fournis
# ═════════════════════════════════════════════════════════════════════════════
async def get_job_progress(user_id: int, job: str) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("INSERT OR IGNORE INTO job_progress(user_id, job) VALUES (?,?)", (user_id, job))
        async with db.execute("SELECT rank, missions FROM job_progress WHERE user_id=? AND job=?",
                              (user_id, job)) as cur:
            row = await cur.fetchone()
        await db.commit()
    return {"rank": int(row["rank"]), "missions": int(row["missions"])}


def job_good(job: str) -> str | None:
    return JOB_GOOD.get(job)


def goods_for_mission(job: str, rank: int, score: int, big: bool = False) -> int:
    key = job_good(job)
    if not key or score <= 0:
        return 0
    base = INTRANTS[key]["units"]
    mult = job_rank_mult(rank)["goods"] * (GRANDE_COMMANDE["goods"] if big else 1.0)
    return max(1, int(round(base * mult * SCORE_GOODS.get(score, 0))))


async def record_mission(user_id: int, job: str, score: int, big: bool = False) -> dict:
    """Après une mission de métier : compte la mission et livre les biens au joueur (inventaire).
    Retourne {'rank','missions','good','units'}."""
    prog = await get_job_progress(user_id, job)
    units = goods_for_mission(job, prog["rank"], score, big)
    key = job_good(job)
    async with db_connection() as db:
        await db.execute("UPDATE job_progress SET missions=missions+1 WHERE user_id=? AND job=?", (user_id, job))
        if units and key:
            await inv_add(db, user_id, key, units)
            await _stat(db, user_id, goods_made=units, **({"big_orders": 1} if big else {}))
        elif big:
            await _stat(db, user_id, big_orders=1)
        await db.commit()
    return {"rank": prog["rank"], "missions": prog["missions"] + 1, "good": key, "units": units}


async def promotion_status(user_id: int, job: str) -> dict:
    """{'rank','next','reqs':[(libellé, actuel, requis, ok)],'ok'} — next=None au rang maximal."""
    from config import SMALL_JOBS, MINIGAME_SKILL
    from database import get_user, get_all_skills
    prog = await get_job_progress(user_id, job)
    rank = prog["rank"]
    out = {"rank": rank, "missions": prog["missions"], "next": None, "reqs": [], "ok": False}
    if rank >= MAX_JOB_RANK:
        return out
    need = JOB_PROMOTION[rank + 1]
    u = await get_user(user_id)
    skills = await get_all_skills(user_id)
    cat = SMALL_JOBS.get(job, {}).get("category", "")
    main_skill = MINIGAME_SKILL.get(cat, "Technique")
    reqs = [("Missions de ce métier", prog["missions"], need["missions"], prog["missions"] >= need["missions"])]
    have = skills.get(main_skill, 0)
    reqs.append((f"Compétence {main_skill}", have, need["skill"], have >= need["skill"]))
    for sk, lvl in need["extra"].items():
        h = skills.get(sk, 0)
        reqs.append((f"Compétence {sk}", h, lvl, h >= lvl))
    if need["diplome"]:
        have_d = DIPLOMES_ORDER.index(u.get("diplome") or "") if (u.get("diplome") or "") in DIPLOMES_ORDER else 0
        need_d = DIPLOMES_ORDER.index(need["diplome"])
        reqs.append((f"Diplôme {need['diplome']}", u.get("diplome") or "aucun", need["diplome"], have_d >= need_d))
    out.update(next=rank + 1, reqs=reqs, ok=all(r[3] for r in reqs))
    return out


async def promote_job(user_id: int, job: str) -> tuple[bool, str]:
    st = await promotion_status(user_id, job)
    if st["next"] is None:
        return False, "🏆 Tu es déjà au rang maximal dans ce métier."
    if not st["ok"]:
        miss = ", ".join(f"{r[0]} ({r[1]}/{r[2]})" for r in st["reqs"] if not r[3])
        return False, f"🔒 Il te manque : {miss}"
    async with db_connection() as db:
        cur = await db.execute("UPDATE job_progress SET rank=? WHERE user_id=? AND job=? AND rank=?",
                               (st["next"], user_id, job, st["rank"]))
        await db.execute("UPDATE users SET job_level=? WHERE user_id=?", (st["next"], user_id))
        await db.commit()
    if not cur.rowcount:
        return False, "⏳ Promotion déjà appliquée."
    m = job_rank_mult(st["next"])
    extra = " 🎖️ Les <b>grandes commandes</b> te sont ouvertes !" if st["next"] == GRANDE_COMMANDE_RANK else ""
    return True, (f"🎉 Promotion ! Tu deviens <b>{job_rank_name(st['next'])}</b> ({job}).\n"
                  f"💰 Gains ×{m['pay']} · 📦 biens ×{m['goods']} · ⚡ effort ×{m['energy']}.{extra}")


# ── Vente de biens ───────────────────────────────────────────────────────────
async def counter_sell(user_id: int, good: str, qty: int) -> tuple[bool, str]:
    """Vente au comptoir national (filet de sécurité) : prix réduit, plafond par jour."""
    if good not in INTRANTS or qty <= 0:
        return False, "❌ Bien invalide."
    from utils.gamerules import bot_pct, record
    pct = await bot_pct("npc_counter")
    if pct <= 0:
        return False, "🏛️ Le comptoir national est fermé : vends tes biens aux entreprises ou aux commerçants."
    cap = max(1, int(COUNTER_DAILY_CAP * pct / 100))
    price = max(1, int(INTRANTS[good]["ref"] * COUNTER_PRICE_RATIO))
    day = game_day()
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            done = await _daily_get(db, "counter", user_id, good, day)
            if done + qty > cap:
                await db.rollback()
                left = max(0, cap - done)
                return False, f"⏳ Le comptoir n'achète que {cap} unités par jour et par bien (reste {left})."
            if not await inv_remove(db, user_id, good, qty):
                await db.rollback()
                return False, "❌ Tu n'as pas assez de ce bien."
            total = price * qty
            await db.execute("UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                             (total, total, user_id))
            await _daily_add(db, "counter", user_id, good, day, qty)
            await db.commit()
            await record("npc_counter", "created", total)
        except Exception:
            await db.rollback()
            raise
    return True, f"✅ Vendu {qty} × {item_name(good)} au comptoir national : <b>+{total:,}</b> €A ({price:,}/u)."


# ═════════════════════════════════════════════════════════════════════════════
# Entreprises : état, stade, lignes, équipes, prix
# ═════════════════════════════════════════════════════════════════════════════
async def _company(db, company_id: int) -> dict | None:
    prev = db.row_factory
    db.row_factory = aiosqlite.Row
    try:
        async with db.execute("SELECT * FROM companies WHERE company_id=? AND dissolved=0", (company_id,)) as cur:
            row = await cur.fetchone()
    finally:
        db.row_factory = prev
    return dict(row) if row else None


async def get_chain_state(company_id: int) -> dict:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("INSERT OR IGNORE INTO company_chain(company_id) VALUES (?)", (company_id,))
        async with db.execute("SELECT * FROM company_chain WHERE company_id=?", (company_id,)) as cur:
            row = await cur.fetchone()
        await db.commit()
    return dict(row)


async def get_lines(company_id: int) -> list[str]:
    async with db_connection() as db:
        async with db.execute("SELECT recipe FROM company_lines WHERE company_id=? ORDER BY position, recipe",
                              (company_id,)) as cur:
            return [r[0] for r in await cur.fetchall()]


async def toggle_line(company_id: int, recipe: str) -> tuple[bool, str]:
    if recipe not in RECIPES:
        return False, "❌ Recette inconnue."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            comp = await _company(db, company_id)
            if not comp or RECIPES[recipe]["sector"] != comp["sector"]:
                await db.rollback()
                return False, "❌ Cette recette n'est pas de ton secteur."
            stage = clamp_stage(comp["level"])
            async with db.execute("SELECT recipe FROM company_lines WHERE company_id=? ORDER BY position",
                                  (company_id,)) as cur:
                lines = [r[0] for r in await cur.fetchall()]
            if recipe in lines:
                await db.execute("DELETE FROM company_lines WHERE company_id=? AND recipe=?", (company_id, recipe))
                await db.commit()
                return True, f"⏹️ Ligne « {RECIPES[recipe]['name']} » arrêtée."
            r = RECIPES[recipe]
            if r["min_stage"] > stage:
                await db.rollback()
                return False, (f"🔒 « {r['name']} » demande le stade {STAGES[r['min_stage'] - 1]['name']} "
                               f"(tu es {STAGES[stage - 1]['name']}).")
            if len(lines) >= STAGES[stage - 1]["lines"]:
                await db.rollback()
                return False, (f"❌ {STAGES[stage - 1]['name']} : {STAGES[stage - 1]['lines']} ligne(s) maximum. "
                               f"Arrête-en une ou grandis.")
            await db.execute("INSERT INTO company_lines(company_id, recipe, position) VALUES (?,?,?)",
                             (company_id, recipe, len(lines)))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"▶️ Ligne « {r['name']} » lancée."


async def ensure_default_line(db, company_id: int, sector: str) -> list[str]:
    """Une entreprise sans ligne active démarre sur la 1re recette de son secteur."""
    async with db.execute("SELECT recipe FROM company_lines WHERE company_id=? ORDER BY position",
                          (company_id,)) as cur:
        lines = [r[0] for r in await cur.fetchall()]
    if lines:
        return lines
    first = (RECIPES_BY_SECTOR.get(sector) or [None])[0]
    if not first:
        return []
    await db.execute("INSERT OR IGNORE INTO company_lines(company_id, recipe, position) VALUES (?,?,0)",
                     (company_id, first))
    return [first]


async def set_member_dept(company_id: int, user_id: int, dept: str) -> tuple[bool, str]:
    async with db_connection() as db:
        comp = await _company(db, company_id)
        if not comp:
            return False, "❌ Entreprise introuvable."
        depts = sector_depts(comp["sector"])
        if dept and dept not in depts:
            return False, "❌ Équipe inconnue pour ce secteur."
        cur = await db.execute("UPDATE company_members SET dept=? WHERE company_id=? AND user_id=?",
                               (dept, company_id, user_id))
        await db.commit()
    if not cur.rowcount:
        return False, "❌ Cette personne ne travaille pas ici."
    return True, "✅ Affectation enregistrée."


async def team_overview(company_id: int) -> dict:
    """{dept: [(user_id, nom, poste, en_service)]}, '' = polyvalents."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT cm.user_id, COALESCE(NULLIF(u.full_name,''), u.username, 'Joueur') AS name, cm.poste, cm.dept, "
                "(SELECT 1 FROM work_duty d WHERE d.user_id=cm.user_id) AS duty "
                "FROM company_members cm JOIN users u ON u.user_id=cm.user_id WHERE cm.company_id=? "
                "ORDER BY cm.dept, name", (company_id,)) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
    out: dict[str, list] = {}
    for r in rows:
        out.setdefault(r["dept"] or "", []).append((r["user_id"], r["name"], r["poste"], bool(r["duty"])))
    return out


async def get_bid_mult(company_id: int, good: str) -> float:
    async with db_connection() as db:
        async with db.execute("SELECT mult FROM company_bids WHERE company_id=? AND good=?",
                              (company_id, good)) as cur:
            row = await cur.fetchone()
    return float(row[0]) if row else BID_DEFAULT


def bid_price(good: str, mult: float) -> int:
    return max(1, int(round(INTRANTS[good]["ref"] * mult)))


async def step_bid(company_id: int, good: str, delta: float) -> float:
    cur_m = await get_bid_mult(company_id, good)
    new = round(min(BID_MAX, max(BID_MIN, cur_m + delta)), 2)
    async with db_connection() as db:
        await db.execute("INSERT INTO company_bids(company_id, good, mult) VALUES (?,?,?) "
                         "ON CONFLICT(company_id, good) DO UPDATE SET mult=excluded.mult", (company_id, good, new))
        await db.commit()
    return new


def default_price(recipe: str) -> int:
    """Prix de gros (bien) ou de prestation (service) par défaut."""
    if RECIPES[recipe]["type"] == "service":
        return _round50(npc_price(recipe) * 1.3)
    return wholesale_default(recipe)


async def get_price(company_id: int, recipe: str) -> int:
    async with db_connection() as db:
        async with db.execute("SELECT price FROM company_prices WHERE company_id=? AND recipe=?",
                              (company_id, recipe)) as cur:
            row = await cur.fetchone()
    return int(row[0]) if row else default_price(recipe)


async def step_price(company_id: int, recipe: str, factor: float) -> int:
    base = npc_price(recipe)
    new = int(round(await get_price(company_id, recipe) * factor))
    new = max(int(base * 0.5), min(int(base * 3), new))
    async with db_connection() as db:
        await db.execute("INSERT INTO company_prices(company_id, recipe, price) VALUES (?,?,?) "
                         "ON CONFLICT(company_id, recipe) DO UPDATE SET price=excluded.price",
                         (company_id, recipe, new))
        await db.commit()
    return new


async def set_npc_share(company_id: int, share: float) -> None:
    async with db_connection() as db:
        await db.execute("INSERT OR IGNORE INTO company_chain(company_id) VALUES (?)", (company_id,))
        await db.execute("UPDATE company_chain SET npc_share=? WHERE company_id=?",
                         (max(0.0, min(1.0, share)), company_id))
        await db.commit()


async def stock_of(company_id: int) -> dict[str, int]:
    async with db_connection() as db:
        async with db.execute("SELECT product, quantity FROM company_stock WHERE company_id=? AND quantity>0",
                              (company_id,)) as cur:
            return {r[0]: int(r[1]) for r in await cur.fetchall()}


async def _stock_add(db, company_id: int, good: str, qty: int) -> None:
    await db.execute(
        "INSERT INTO company_stock(company_id, product, quantity) VALUES (?,?,?) "
        "ON CONFLICT(company_id, product) DO UPDATE SET quantity=quantity+excluded.quantity",
        (company_id, good, qty))


async def _is_member(db, company_id: int, user_id: int) -> bool:
    async with db.execute("SELECT 1 FROM company_members WHERE company_id=? AND user_id=?",
                          (company_id, user_id)) as cur:
        return await cur.fetchone() is not None


async def companies_buying(good: str, limit: int = 20) -> list[dict]:
    """Entreprises actives dont le secteur consomme ce bien, avec leur prix d'achat et leur trésorerie."""
    sectors = [s for s in RECIPES_BY_SECTOR if good in sector_inputs(s)]
    if not sectors:
        return []
    marks = ",".join("?" * len(sectors))
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                f"SELECT c.company_id, c.name, c.sector, c.treasury, c.level, COALESCE(b.mult, ?) AS mult, "
                f"COALESCE((SELECT quantity FROM company_stock s WHERE s.company_id=c.company_id AND s.product=?),0) AS stock "
                f"FROM companies c LEFT JOIN company_bids b ON b.company_id=c.company_id AND b.good=? "
                f"WHERE c.dissolved=0 AND c.sector IN ({marks}) "
                f"ORDER BY COALESCE(b.mult, ?) DESC, c.treasury DESC LIMIT ?",
                (BID_DEFAULT, good, good, *sectors, BID_DEFAULT, limit)) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
    for r in rows:
        r["price"] = bid_price(good, r["mult"])
        r["room"] = max(0, int(STOCK_CAP_PER_GOOD * stage_cap(r["level"])) - r["stock"])
    return rows


async def sell_to_company(user_id: int, company_id: int, good: str, qty: int) -> tuple[bool, str]:
    """Un joueur vend des intrants à une entreprise au prix d'achat qu'elle affiche."""
    if good not in INTRANTS or qty <= 0:
        return False, "❌ Bien ou quantité invalide."
    day = game_day()
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            comp = await _company(db, company_id)
            if not comp:
                await db.rollback()
                return False, "❌ Entreprise introuvable."
            if good not in sector_inputs(comp["sector"]):
                await db.rollback()
                return False, f"❌ {comp['name']} n'utilise pas ce bien."
            if await _is_member(db, company_id, user_id):
                await db.rollback()
                return False, "❌ Tu travailles dans cette entreprise : utilise « Déposer au stock » (pas de vente à soi-même)."
            async with db.execute("SELECT mult FROM company_bids WHERE company_id=? AND good=?",
                                  (company_id, good)) as cur:
                row = await cur.fetchone()
            price = bid_price(good, float(row[0]) if row else BID_DEFAULT)
            total = price * qty
            async with db.execute("SELECT quantity FROM company_stock WHERE company_id=? AND product=?",
                                  (company_id, good)) as cur:
                srow = await cur.fetchone()
            stock = int(srow[0]) if srow else 0
            room = int(STOCK_CAP_PER_GOOD * stage_cap(comp["level"])) - stock
            if qty > room:
                await db.rollback()
                return False, f"📦 Le stock de {comp['name']} est presque plein : elle ne peut prendre que {max(0, room)} unité(s)."
            if comp["treasury"] < total:
                await db.rollback()
                return False, f"💸 {comp['name']} n'a pas assez de trésorerie ({comp['treasury']:,} < {total:,})."
            if not await inv_remove(db, user_id, good, qty):
                await db.rollback()
                return False, "❌ Tu n'as pas assez de ce bien."
            await db.execute("UPDATE companies SET treasury=treasury-? WHERE company_id=?", (total, company_id))
            await db.execute("UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                             (total, total, user_id))
            await _stock_add(db, company_id, good, qty)
            await _stat(db, user_id, goods_supplied=qty, supply_value=total)
            await db.execute(
                "INSERT INTO company_logs (company_id,action,actor_id,details,timestamp) VALUES (?,?,?,?,?)",
                (company_id, "achat_intrants", user_id, f"{qty} × {item_name(good)} à {price}", now()))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, (f"✅ Livré {qty} × {item_name(good)} à <b>{comp['name']}</b> : <b>+{total:,}</b> €A ({price:,}/u).")


async def deposit_to_company(user_id: int, company_id: int, good: str, qty: int) -> tuple[bool, str]:
    """Un membre verse gratuitement des biens de son inventaire au stock de son entreprise."""
    if good not in INTRANTS or qty <= 0:
        return False, "❌ Bien ou quantité invalide."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            comp = await _company(db, company_id)
            if not comp or not await _is_member(db, company_id, user_id):
                await db.rollback()
                return False, "❌ Tu ne travailles pas dans cette entreprise."
            if good not in sector_inputs(comp["sector"]):
                await db.rollback()
                return False, f"❌ {comp['name']} n'utilise pas ce bien."
            if not await inv_remove(db, user_id, good, qty):
                await db.rollback()
                return False, "❌ Tu n'as pas assez de ce bien."
            await _stock_add(db, company_id, good, qty)
            await db.execute(
                "INSERT INTO company_logs (company_id,action,actor_id,details,timestamp) VALUES (?,?,?,?,?)",
                (company_id, "depot_intrants", user_id, f"{qty} × {item_name(good)}", now()))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"✅ {qty} × {item_name(good)} ajouté(s) au stock de <b>{comp['name']}</b>."


async def wholesale_offers(limit: int = 30) -> list[dict]:
    """Produits finis de type 'bien' en stock chez les entreprises (catalogue des grossistes)."""
    goods = [k for k, v in RECIPES.items() if v["type"] == "bien"]
    marks = ",".join("?" * len(goods))
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                f"SELECT c.company_id, c.name AS company, c.sector, s.product AS recipe, s.quantity AS stock "
                f"FROM company_stock s JOIN companies c ON c.company_id=s.company_id "
                f"WHERE c.dissolved=0 AND s.quantity>0 AND s.product IN ({marks}) "
                f"ORDER BY s.product, c.name LIMIT ?", (*goods, limit)) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
    for r in rows:
        r["price"] = await get_price(r["company_id"], r["recipe"])
    return rows


async def buy_wholesale(merchant_id: int, company_id: int, recipe: str, qty: int) -> tuple[bool, str]:
    """Un commerçant achète en gros des produits finis (il les revendra sur le marché)."""
    r = RECIPES.get(recipe)
    if not r or r["type"] != "bien" or qty <= 0:
        return False, "❌ Produit invalide."
    day = game_day()
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT job, balance FROM users WHERE user_id=?", (merchant_id,)) as cur:
                u = await cur.fetchone()
            if not u or (u[0] or "") != MERCHANT_JOB:
                await db.rollback()
                return False, "🛍️ Seuls les commerçants achètent en gros."
            comp = await _company(db, company_id)
            if not comp:
                await db.rollback()
                return False, "❌ Entreprise introuvable."
            if await _is_member(db, company_id, merchant_id):
                await db.rollback()
                return False, "❌ Tu travailles dans cette entreprise."
            async with db.execute("SELECT price FROM company_prices WHERE company_id=? AND recipe=?",
                                  (company_id, recipe)) as cur:
                prow = await cur.fetchone()
            price = int(prow[0]) if prow else default_price(recipe)
            total = price * qty
            if u[1] < total:
                await db.rollback()
                return False, f"💸 Il te faut {total:,} €A."
            cur = await db.execute("UPDATE company_stock SET quantity=quantity-? WHERE company_id=? AND product=? "
                                   "AND quantity>=?", (qty, company_id, recipe, qty))
            if cur.rowcount != 1:
                await db.rollback()
                return False, "📦 Stock insuffisant chez ce fournisseur."
            await db.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
                             (total, total, merchant_id, total))
            await db.execute("UPDATE companies SET treasury=treasury+? WHERE company_id=?", (total, company_id))
            await inv_add(db, merchant_id, recipe, qty)
            await db.execute("INSERT OR IGNORE INTO company_chain(company_id) VALUES (?)", (company_id,))
            await db.execute("UPDATE company_chain SET revenue_total=revenue_total+? WHERE company_id=?",
                             (total, company_id))
            await db.execute(
                "INSERT INTO company_production_log(company_id, day, produced, sold, cost, revenue) VALUES (?,?,0,?,0,?) "
                "ON CONFLICT(company_id, day) DO UPDATE SET sold=sold+excluded.sold, revenue=revenue+excluded.revenue",
                (company_id, day, qty, total))
            await db.execute(
                "INSERT INTO company_logs (company_id,action,actor_id,details,timestamp) VALUES (?,?,?,?,?)",
                (company_id, "vente_gros", merchant_id, f"{qty} × {r['name']} à {price}", now()))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, (f"✅ Acheté {qty} × {r['emoji']} {r['name']} à <b>{comp['name']}</b> ({price:,}/u, total {total:,}). "
                  f"Mets-les en vente : Marché → Vendre.")


# ═════════════════════════════════════════════════════════════════════════════
# Effets des produits finis
# ═════════════════════════════════════════════════════════════════════════════
async def _active_vehicle(db, user_id: int) -> dict | None:
    prev = db.row_factory
    db.row_factory = aiosqlite.Row
    try:
        async with db.execute(
                "SELECT v.* FROM vehicles v JOIN users u ON u.active_vehicle_id=v.veh_id "
                "WHERE u.user_id=? AND v.user_id=?", (user_id, user_id)) as cur:
            row = await cur.fetchone()
    finally:
        db.row_factory = prev
    return dict(row) if row else None


async def preflight_effects(user_id: int, effects) -> str | None:
    """Message d'erreur si l'effet serait sans objet (pas de véhicule, rien à réparer…), sinon None."""
    from config import VEHICLES
    async with db_connection() as db:
        for key, _val in effects:
            if key in ("fuel", "repair", "insure"):
                veh = await _active_vehicle(db, user_id)
                if not veh:
                    return "🚗 Il te faut un véhicule actif (menu Véhicules)."
                if key == "fuel":
                    cap = VEHICLES.get(veh["veh_type"], {}).get("fuel_capacity", 0)
                    if cap <= 0:
                        return "⛽ Ce véhicule n'a pas besoin de carburant."
                    if (veh.get("fuel") or 0) >= cap:
                        return "⛽ Le réservoir est déjà plein."
                if key == "repair" and (veh.get("condition") or 0) >= 100:
                    return "🔧 Ton véhicule est déjà en parfait état."
                if key == "insure" and veh.get("insured"):
                    return "🛡️ Ton véhicule est déjà assuré."
            if key in ("repair_home", "repair_home_all"):
                async with db.execute("SELECT COUNT(*) FROM properties WHERE user_id=? AND condition<100",
                                      (user_id,)) as cur:
                    if (await cur.fetchone())[0] == 0:
                        return "🏠 Aucun de tes biens n'a besoin de travaux."
    return None


async def apply_effects(user_id: int, effects) -> list[str]:
    """Applique les effets et renvoie les lignes de compte rendu."""
    from config import VEHICLES, ANTI_HACK_PLANS, ANTI_HACK_DAY_GAME_SECONDS
    lines: list[str] = []
    for key, val in effects:
        if key in ("hunger", "energy", "health", "happiness"):
            async with db_connection() as db:
                await db.execute(f"UPDATE users SET {key}=MAX(0, MIN(100, {key}+?)) WHERE user_id=?", (val, user_id))
                await db.commit()
            lines.append(f"{_EL(key)} {val:+d}")
        elif key == "stress":
            async with db_connection() as db:
                await db.execute("UPDATE users SET stress=MAX(0, MIN(100, stress+?)) WHERE user_id=?", (val, user_id))
                await db.commit()
            lines.append(f"{_EL(key)} {val:+d}")
        elif key == "xp":
            from utils.vip import add_xp
            got = await add_xp(user_id, val)
            lines.append(f"✨ +{got} XP")
        elif key in ("prestige", "karma", "followers"):
            col = {"prestige": "prestige", "karma": "karma", "followers": "social_followers"}[key]
            async with db_connection() as db:
                await db.execute(f"UPDATE users SET {col}={col}+? WHERE user_id=?", (val, user_id))
                await db.commit()
            lines.append(f"{_EL(key)} {val:+d}")
        elif key == "skill":
            from database import upgrade_skill
            sk = random.choice(PHYSICAL_SKILLS)
            lvl = await upgrade_skill(user_id, sk)
            lines.append(f"🧠 {sk} niveau {lvl}")
        elif key == "fuel":
            async with db_connection() as db:
                veh = await _active_vehicle(db, user_id)
                cap = VEHICLES.get(veh["veh_type"], {}).get("fuel_capacity", 0) if veh else 0
                new = min(cap, (veh.get("fuel") or 0) + val) if veh else 0
                if veh:
                    await db.execute("UPDATE vehicles SET fuel=? WHERE veh_id=?", (new, veh["veh_id"]))
                await db.commit()
            lines.append(f"⛽ Carburant {new}/{cap}")
        elif key == "repair":
            async with db_connection() as db:
                veh = await _active_vehicle(db, user_id)
                new = min(100, (veh.get("condition") or 0) + val) if veh else 0
                if veh:
                    await db.execute("UPDATE vehicles SET condition=? WHERE veh_id=?", (new, veh["veh_id"]))
                await db.commit()
            lines.append(f"🔧 État du véhicule {new}%")
        elif key == "insure":
            async with db_connection() as db:
                veh = await _active_vehicle(db, user_id)
                if veh:
                    await db.execute("UPDATE vehicles SET insured=1 WHERE veh_id=?", (veh["veh_id"],))
                await db.commit()
            lines.append("🛡️ Véhicule assuré")
        elif key == "repair_home":
            async with db_connection() as db:
                async with db.execute("SELECT prop_id, condition FROM properties WHERE user_id=? AND condition<100 "
                                      "ORDER BY condition LIMIT 1", (user_id,)) as cur:
                    row = await cur.fetchone()
                new = 0
                if row:
                    new = min(100, row[1] + val)
                    await db.execute("UPDATE properties SET condition=? WHERE prop_id=?", (new, row[0]))
                await db.commit()
            lines.append(f"🏠 Bien rénové : {new}%")
        elif key == "repair_home_all":
            async with db_connection() as db:
                await db.execute("UPDATE properties SET condition=MIN(100, condition+?) WHERE user_id=?",
                                 (val, user_id))
                await db.commit()
            lines.append(f"🏘️ Tous tes biens +{val}%")
        elif key == "antihack":
            plan = "pare_feu"
            days = val * ANTI_HACK_DAY_GAME_SECONDS
            async with db_connection() as db:
                async with db.execute("SELECT expires_at FROM anti_hack WHERE user_id=?", (user_id,)) as cur:
                    row = await cur.fetchone()
                start = max(now(), int(row[0])) if row else now()
                await db.execute(
                    "INSERT INTO anti_hack(user_id, level, expires_at) VALUES (?,?,?) "
                    "ON CONFLICT(user_id) DO UPDATE SET level=excluded.level, expires_at=excluded.expires_at",
                    (user_id, plan if plan in ANTI_HACK_PLANS else "pare_feu", start + days))
                await db.commit()
            lines.append(f"💻 Pare-feu actif {val} jour(s) de jeu de plus")
    return lines


def _EL(key: str) -> str:
    from config_chain import EFFECT_LABEL
    return EFFECT_LABEL.get(key, key)


async def use_chain_item(user_id: int, name: str) -> tuple[bool, str]:
    """Consomme 1 produit fini (objet d'inventaire) : applique ses effets. Utilisé par « Utiliser un objet »."""
    key = key_of_item_name(name)
    if not key or key not in RECIPES:
        return False, "❌ Ce produit n'a pas d'effet connu."
    r = RECIPES[key]
    err = await preflight_effects(user_id, r["effects"])
    if err:
        return False, err
    async with db_connection() as db:
        ok = await inv_remove(db, user_id, key, 1)
        await db.commit()
    if not ok:
        return False, "❌ Tu n'en as plus."
    lines = await apply_effects(user_id, r["effects"])
    return True, "\n".join(lines)


# ═════════════════════════════════════════════════════════════════════════════
# Prestations (services) : le client paie l'entreprise, un employé en service les réalise
# ═════════════════════════════════════════════════════════════════════════════
async def on_duty_workers(company_id: int, recipe: str) -> list[int]:
    """Employés en service capables de réaliser la prestation (équipe du service, ou direction)."""
    dept = final_service_dept(recipe)
    async with db_connection() as db:
        async with db.execute(
                "SELECT cm.user_id FROM company_members cm JOIN work_duty d ON d.user_id=cm.user_id "
                "WHERE cm.company_id=? AND (cm.dept=? OR cm.role IN ('owner','manager') OR cm.user_id=(SELECT owner_id FROM companies WHERE company_id=cm.company_id))",
                (company_id, dept)) as cur:
            return [r[0] for r in await cur.fetchall()]


async def service_offers(limit: int = 30) -> list[dict]:
    """Prestations disponibles : stock ≥ 1 et au moins un employé qualifié en service."""
    services = [k for k, v in RECIPES.items() if v["type"] == "service"]
    marks = ",".join("?" * len(services))
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                f"SELECT c.company_id, c.name AS company, c.sector, s.product AS recipe, s.quantity AS stock "
                f"FROM company_stock s JOIN companies c ON c.company_id=s.company_id "
                f"WHERE c.dissolved=0 AND s.quantity>0 AND s.product IN ({marks}) ORDER BY s.product, c.name",
                tuple(services)) as cur:
            rows = [dict(r) for r in await cur.fetchall()]
    out = []
    for r in rows:
        workers = await on_duty_workers(r["company_id"], r["recipe"])
        if workers:
            r["price"] = await get_price(r["company_id"], r["recipe"])
            r["workers"] = len(workers)
            out.append(r)
        if len(out) >= limit:
            break
    return out


async def perform_service(customer_id: int, company_id: int, recipe: str) -> tuple[bool, str, int | None]:
    """Réalise une prestation. Retourne (ok, message, id_de_l_employé_qui_la_réalise)."""
    r = RECIPES.get(recipe)
    if not r or r["type"] != "service":
        return False, "❌ Prestation invalide.", None
    day = game_day()
    workers = [w for w in await on_duty_workers(company_id, recipe) if w != customer_id]
    if not workers:
        return False, "⏸️ Aucun employé qualifié n'est en service pour le moment.", None
    err = await preflight_effects(customer_id, r["effects"])
    if err:
        return False, err, None
    worker = random.choice(workers)
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            comp = await _company(db, company_id)
            if not comp:
                await db.rollback()
                return False, "❌ Entreprise introuvable.", None
            if await _is_member(db, company_id, customer_id):
                await db.rollback()
                return False, "❌ Tu ne peux pas être client de ta propre entreprise.", None
            async with db.execute("SELECT price FROM company_prices WHERE company_id=? AND recipe=?",
                                  (company_id, recipe)) as cur:
                prow = await cur.fetchone()
            price = int(prow[0]) if prow else default_price(recipe)
            cur = await db.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                                   "WHERE user_id=? AND balance>=?", (price, price, customer_id, price))
            if cur.rowcount != 1:
                await db.rollback()
                return False, f"💸 Il te faut {price:,} €A.", None
            cur = await db.execute("UPDATE company_stock SET quantity=quantity-1 WHERE company_id=? AND product=? "
                                   "AND quantity>=1", (company_id, recipe))
            if cur.rowcount != 1:
                await db.rollback()
                return False, "📦 Plus de prestation disponible.", None
            commission = int(price * SERVICE_COMMISSION)
            await db.execute("UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                             (commission, commission, worker))
            await db.execute("UPDATE companies SET treasury=treasury+? WHERE company_id=?",
                             (price - commission, company_id))
            await db.execute("INSERT OR IGNORE INTO company_chain(company_id) VALUES (?)", (company_id,))
            await db.execute("UPDATE company_chain SET revenue_total=revenue_total+? WHERE company_id=?",
                             (price, company_id))
            await db.execute(
                "INSERT INTO company_production_log(company_id, day, produced, sold, cost, revenue) VALUES (?,?,0,1,0,?) "
                "ON CONFLICT(company_id, day) DO UPDATE SET sold=sold+1, revenue=revenue+excluded.revenue",
                (company_id, day, price))
            await db.execute(
                "INSERT INTO company_logs (company_id,action,actor_id,details,timestamp) VALUES (?,?,?,?,?)",
                (company_id, "prestation", customer_id, f"{r['name']} par {worker} ({price})", now()))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    lines = await apply_effects(customer_id, r["effects"])
    return True, (f"{r['emoji']} <b>{r['name']}</b> réalisée par {comp['name']} (-{price:,} €A)\n" + "\n".join(lines)), worker
