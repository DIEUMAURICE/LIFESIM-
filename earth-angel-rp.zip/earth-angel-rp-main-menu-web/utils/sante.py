# utils/sante.py — Santé publique : hôpitaux, postes, médicaments, soins, lits, assurances, salaires
"""
La faction gouvernementale « Santé publique » EST le système de santé du jeu :

  Ressources (récolteurs) → laboratoire (techniciens) → industrie (opérateurs) → médicaments
  mis automatiquement en vente (menu Médicaments). Tout achat de la faction (médicaments,
  consultations, primes d'assurance) va dans son COFFRE GÉNÉRAL (faction_state.budget), qui
  paie les salaires PAR HEURE DE JEU.

  Soins : ambulance gratuite (les soignants EN SERVICE sont notifiés), consultation sur place à
  l'hôpital, ou lit (≥ 2 min de jeu, lits limités et partagés). L'assurance réduit les coûts.

  Direction : 1 grand hôpital (PDG, nommé par le Game Leader) + 4 petits hôpitaux (DG, nommés par le PDG).
  Les DG/PDG recrutent, affectent et renvoient ; les admins peuvent tout révoquer et auditent le journal.

Toute la logique est ici (testable sans Telegram) ; les écrans sont dans handlers/sante.py.
Toutes les durées sont en secondes de JEU (now()), lits compris.
"""
import logging
import random

import aiosqlite

from config import (
    SANTE_FACTION, SANTE_GRAND, SANTE_HOSPITALS, SANTE_POSTS, SANTE_HEAD_LEVEL, SANTE_ASSIGNABLE,
    SANTE_LEGACY_RANK_TO_POST, SANTE_PAY_ONLY_ON_DUTY, SANTE_RAW, SANTE_INTER, SANTE_GATHER,
    SANTE_LAB_COOLDOWN, SANTE_INDUSTRY_COOLDOWN, SANTE_LAB_RECIPES, SANTE_MED_RECIPES,
    SANTE_STOCK_CAPS, SANTE_AMBULANCE_COOLDOWN, SANTE_CALL_TTL, SANTE_CONSULT_COST,
    SANTE_CONSULT_BONUS, SANTE_PAIR_LIMIT, SANTE_BED_MIN, SANTE_BED_MAX, SANTE_BED_HEAL,
    INSURANCE_PLANS, MEDICINES,
)
from database import db_connection, now, get_user, snapshot_user_core_stats
from utils.helpers import fmt_time
from utils.cooldowns import claim_cooldown, release_cooldown
from utils.factions import coffre_add
from utils.gametime import add_game_months
from utils.notify import notify

logger = logging.getLogger(__name__)

HOUR = 3600
CARE_ROLES = ("care", "head")


# ─────────────────────────────────────────────────────────────────────────────
#  Références (config)
# ─────────────────────────────────────────────────────────────────────────────
def post_info(post: str) -> dict:
    return SANTE_POSTS.get(post) or SANTE_POSTS["recolteur"]


def hospital_info(hid: str) -> dict:
    return SANTE_HOSPITALS.get(hid) or SANTE_HOSPITALS[SANTE_GRAND]


def hospital_at(location: str) -> str | None:
    """Id de l'hôpital situé à ce lieu RP (None si ce n'est pas un hôpital)."""
    for hid, h in SANTE_HOSPITALS.items():
        if h["location"] == location:
            return hid
    return None


def head_post_for(hid: str) -> str:
    return "pdg" if hospital_info(hid)["kind"] == "grand" else "dg"


def _log(db, actor: int, action: str, target: int = 0, details: str = "") -> object:
    """Journal d'audit (dans la transaction de l'appelant)."""
    return db.execute(
        "INSERT INTO sante_logs(ts, actor_id, action, target_id, details) VALUES (?,?,?,?,?)",
        (now(), actor, action, target, details[:300]))


async def log_event(actor: int, action: str, target: int = 0, details: str = "") -> None:
    async with db_connection() as db:
        await _log(db, actor, action, target, details)
        await db.commit()


# ─────────────────────────────────────────────────────────────────────────────
#  Personnel
# ─────────────────────────────────────────────────────────────────────────────
def _staff_dict(row) -> dict:
    d = dict(row)
    p = post_info(d["post"])
    d.update(post_name=p["name"], post_emoji=p["emoji"], level=p["level"], salary_h=p["salary_h"],
             role=p["role"], heal=p["heal"], hospital_name=hospital_info(d["hospital_id"])["name"],
             location=hospital_info(d["hospital_id"])["location"])
    return d


async def get_staff(user_id: int) -> dict | None:
    """Fiche santé du joueur (poste, hôpital, service) ou None s'il n'est pas dans la faction.
    Réconcilie au passage les anciennes adhésions (faction_members sans poste) et les postes orphelins."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT rank FROM faction_members WHERE user_id=? AND faction=?",
                (user_id, SANTE_FACTION)) as cur:
            fm = await cur.fetchone()
        async with db.execute("SELECT * FROM sante_staff WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
        if not fm:
            if row:   # a quitté / été renvoyé de la faction : le poste n'a plus lieu d'être
                await db.execute("DELETE FROM sante_staff WHERE user_id=?", (user_id,))
                await db.commit()
            return None
        if not row:   # ancien membre : grade → poste (jamais de direction automatique)
            post = SANTE_LEGACY_RANK_TO_POST.get(fm["rank"], "recolteur")
            await db.execute(
                "INSERT OR IGNORE INTO sante_staff(user_id, hospital_id, post, on_duty, since) VALUES (?,?,?,0,?)",
                (user_id, SANTE_GRAND, post, now()))
            await db.execute("UPDATE faction_members SET rank=? WHERE user_id=?",
                             (post_info(post)["level"], user_id))
            await db.commit()
            async with db.execute("SELECT * FROM sante_staff WHERE user_id=?", (user_id,)) as cur:
                row = await cur.fetchone()
    return _staff_dict(row)


async def list_staff(hospital_id: str | None = None) -> list[dict]:
    q = ("SELECT s.*, u.full_name FROM sante_staff s JOIN faction_members fm "
         "ON fm.user_id=s.user_id AND fm.faction=? LEFT JOIN users u ON u.user_id=s.user_id")
    args: list = [SANTE_FACTION]
    from utils.staff_scope import excluded_sql      # le staff n'apparaît jamais côté joueurs
    q += " WHERE " + excluded_sql("s.user_id")
    if hospital_id:
        q += " AND s.hospital_id=?"
        args.append(hospital_id)
    q += " ORDER BY s.hospital_id, s.post, s.user_id"
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(q, tuple(args)) as cur:
            rows = await cur.fetchall()
    return [_staff_dict(r) for r in rows]


async def get_head(hospital_id: str) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT s.*, u.full_name FROM sante_staff s JOIN faction_members fm "
                "ON fm.user_id=s.user_id AND fm.faction=? LEFT JOIN users u ON u.user_id=s.user_id "
                "WHERE s.hospital_id=? AND s.post IN ('dg','pdg')", (SANTE_FACTION, hospital_id)) as cur:
            row = await cur.fetchone()
    return _staff_dict(row) if row else None


async def register_recruit(user_id: int, hospital_id: str) -> None:
    """Un nouveau membre (candidature acceptée) entre au poste de base de l'hôpital du recruteur."""
    async with db_connection() as db:
        await db.execute(
            "INSERT INTO sante_staff(user_id, hospital_id, post, on_duty, since) VALUES (?,?, 'recolteur', 0, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET hospital_id=excluded.hospital_id",
            (user_id, hospital_id, now()))
        await _log(db, 0, "recrutement", user_id, hospital_id)
        await db.commit()


async def workplace_location(user_id: int) -> str:
    """Lieu RP où le membre de la santé travaille (l'hôpital auquel il est affecté)."""
    st = await get_staff(user_id)
    return st["location"] if st else hospital_info(SANTE_GRAND)["location"]


async def _is_free_worker(db, user_id: int) -> str:
    """'' si le joueur peut prendre un poste santé ; sinon la raison du refus."""
    async with db.execute("SELECT faction FROM faction_members WHERE user_id=?", (user_id,)) as cur:
        fm = await cur.fetchone()
    if fm and fm[0] != SANTE_FACTION:
        return "Il travaille déjà dans une autre faction."
    async with db.execute(
            "SELECT 1 FROM company_members cm JOIN companies c ON c.company_id=cm.company_id "
            "WHERE cm.user_id=? AND c.dissolved=0", (user_id,)) as cur:
        if await cur.fetchone():
            return "Il travaille déjà dans une entreprise (il doit démissionner)."
    return ""


async def _set_post(db, user_id: int, hospital_id: str, post: str) -> None:
    """Pose le poste (+ adhésion à la faction, grade = niveau du poste). Service remis à zéro."""
    lvl = post_info(post)["level"]
    await db.execute(
        "INSERT INTO faction_members(user_id, faction, rank, activity_score, joined_at) VALUES (?,?,?,0,?) "
        "ON CONFLICT(user_id) DO UPDATE SET rank=excluded.rank", (user_id, SANTE_FACTION, lvl, now()))
    await db.execute(
        "INSERT INTO sante_staff(user_id, hospital_id, post, on_duty, since) VALUES (?,?,?,0,?) "
        "ON CONFLICT(user_id) DO UPDATE SET hospital_id=excluded.hospital_id, post=excluded.post, "
        "on_duty=0, since=excluded.since", (user_id, hospital_id, post, now()))


async def _install_head(actor_id: int, target_id: int, hospital_id: str) -> tuple[bool, str]:
    """Nomme `target` chef (PDG du grand hôpital / DG d'un petit). L'ancien chef redevient poste de base."""
    post = head_post_for(hospital_id)
    h = hospital_info(hospital_id)
    target = await get_user(target_id)
    if not target or not target.get("registered") or target.get("banned"):
        return False, "Ce joueur n'est pas inscrit (ou banni)."
    from utils.staff_scope import is_ignored
    if await is_ignored(target_id):
        return False, "Le staff n'intervient pas dans le jeu : mentionne (@pseudo) un joueur, pas un membre du staff."
    old_id = 0
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            why = await _is_free_worker(db, target_id)
            if why:
                await db.rollback()
                return False, why
            async with db.execute(
                    "SELECT user_id FROM sante_staff WHERE hospital_id=? AND post IN ('dg','pdg')",
                    (hospital_id,)) as cur:
                row = await cur.fetchone()
            if row and row["user_id"] != target_id:
                old_id = row["user_id"]
                await db.execute("UPDATE sante_staff SET post='recolteur', on_duty=0 WHERE user_id=?", (old_id,))
                await db.execute("UPDATE faction_members SET rank=0 WHERE user_id=?", (old_id,))
            await _set_post(db, target_id, hospital_id, post)
            await _log(db, actor_id, f"nomination_{post}", target_id, hospital_id)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await notify(target_id, "👑 Nomination",
                 f"Tu diriges désormais <b>{h['name']}</b> en tant que <b>{post_info(post)['name']}</b>. "
                 f"Tu recrutes, affectes et promeus ton personnel (menu 🏥 Hôpital → 👔 Mon poste).", "achievement")
    if old_id:
        await notify(old_id, "🏥 Fin de mandat",
                     f"Tu ne diriges plus <b>{h['name']}</b> : tu reprends un poste de base.", "warning")
    return True, f"{post_info(post)['emoji']} {post_info(post)['name']} de {h['name']} nommé(e)."


async def appoint_pdg(actor_id: int, target_id: int) -> tuple[bool, str]:
    """Le Game Leader (ou plus) nomme le PDG du grand hôpital (contrôle d'accès : handler)."""
    return await _install_head(actor_id, target_id, SANTE_GRAND)


async def appoint_dg(actor_id: int, target_id: int, hospital_id: str, is_admin: bool = False) -> tuple[bool, str]:
    """Le PDG nomme le DG d'un petit hôpital (les admins peuvent aussi, pour résoudre une situation)."""
    if hospital_id not in SANTE_HOSPITALS or hospital_info(hospital_id)["kind"] != "petit":
        return False, "Un DG dirige un des petits hôpitaux (pas le grand)."
    if not is_admin:
        me = await get_staff(actor_id)
        if not me or me["post"] != "pdg":
            return False, "Seul le PDG nomme les DG."
    return await _install_head(actor_id, target_id, hospital_id)


async def assign_post(actor_id: int, target_id: int, post: str, hospital_id: str | None = None,
                      is_admin: bool = False) -> tuple[bool, str]:
    """Promotion / changement de poste / affectation. PDG : tout le personnel ; DG : son hôpital
    (et il ne peut pas déplacer quelqu'un vers un autre hôpital)."""
    if post not in SANTE_ASSIGNABLE:
        return False, "Poste inconnu. Postes : " + ", ".join(SANTE_ASSIGNABLE)
    if hospital_id and hospital_id not in SANTE_HOSPITALS:
        return False, "Hôpital inconnu."
    if actor_id == target_id and not is_admin:
        return False, "Tu ne peux pas modifier ton propre poste."
    me = None if is_admin else await get_staff(actor_id)
    if not is_admin and (not me or me["level"] < SANTE_HEAD_LEVEL):
        return False, "Réservé aux DG et au PDG."
    tgt = await get_staff(target_id)
    if not tgt:
        return False, "Ce joueur ne fait pas partie de la santé publique (il doit d'abord candidater)."
    if tgt["role"] == "head" and not is_admin:
        return False, "On ne change pas le poste d'un directeur : c'est une nomination."
    if me and me["post"] == "dg":
        if tgt["hospital_id"] != me["hospital_id"] or (hospital_id and hospital_id != me["hospital_id"]):
            return False, "Un DG gère uniquement le personnel de son hôpital."
    new_hosp = hospital_id or tgt["hospital_id"]
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await _set_post(db, target_id, new_hosp, post)
            await _log(db, actor_id, "poste", target_id, f"{tgt['post']}→{post} @{new_hosp}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    p = post_info(post)
    await notify(target_id, "🎖️ Nouveau poste",
                 f"Tu es maintenant <b>{p['emoji']} {p['name']}</b> à <b>{hospital_info(new_hosp)['name']}</b> — "
                 f"salaire <b>{p['salary_h']:,}</b> par heure de jeu.", "achievement")
    return True, f"{p['emoji']} {p['name']} — {hospital_info(new_hosp)['name']}."


async def dismiss(actor_id: int, target_id: int, is_admin: bool = False, reason: str = "") -> tuple[bool, str]:
    """Renvoie un membre de la santé. DG : son hôpital ; PDG : tout sauf lui ; admins : tout le monde."""
    tgt = await get_staff(target_id)
    if not tgt:
        return False, "Ce joueur ne fait pas partie de la santé publique."
    if not is_admin:
        me = await get_staff(actor_id)
        if not me or me["level"] < SANTE_HEAD_LEVEL:
            return False, "Réservé aux DG, au PDG et aux admins."
        if tgt["user_id"] == actor_id or tgt["level"] >= me["level"]:
            return False, "Tu ne peux renvoyer que quelqu'un de moins gradé que toi."
        if me["post"] == "dg" and tgt["hospital_id"] != me["hospital_id"]:
            return False, "Un DG renvoie uniquement le personnel de son hôpital."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await db.execute("DELETE FROM faction_members WHERE user_id=? AND faction=?", (target_id, SANTE_FACTION))
            await db.execute("DELETE FROM sante_staff WHERE user_id=?", (target_id,))
            await _log(db, actor_id, "renvoi" if not is_admin else "revocation_admin", target_id,
                       f"{tgt['post']}@{tgt['hospital_id']} {reason}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await notify(target_id, "🏥 Fin de contrat",
                 f"Tu ne fais plus partie de la Santé publique ({tgt['post_name']})."
                 + (f"\nMotif : {reason}" if reason else ""), "warning")
    return True, f"{tgt['post_name']} {tgt.get('full_name') or target_id} renvoyé(e)."


# ─────────────────────────────────────────────────────────────────────────────
#  Service (réception des appels)
# ─────────────────────────────────────────────────────────────────────────────
async def set_duty(user_id: int, on: bool) -> tuple[bool, str]:
    st = await get_staff(user_id)
    if not st or st["role"] not in CARE_ROLES:
        return False, "Seuls les soignants (ambulancier, infirmier, médecin, chirurgien, direction) prennent un service."
    if on:   # on prend son service sur place, à l'hôpital d'affectation
        from utils.location import is_exempt, get_position
        if not await is_exempt(user_id):
            pos = await get_position(user_id)
            if pos["in_transit"] or pos["location"] != st["location"]:
                return False, f"Pour prendre ton service, rends-toi à <b>{st['hospital_name']}</b>."
    async with db_connection() as db:
        await db.execute("UPDATE sante_staff SET on_duty=? WHERE user_id=?", (1 if on else 0, user_id))
        await _log(db, user_id, "service_on" if on else "service_off", 0, st["hospital_id"])
        await db.commit()
    return True, "🟢 Tu es EN SERVICE : tu reçois les appels." if on else "⚪ Tu es hors service."


async def _on_duty_carers(db, hospital_id: str | None = None, exclude: int = 0) -> list[dict]:
    q = ("SELECT s.* FROM sante_staff s JOIN faction_members fm ON fm.user_id=s.user_id AND fm.faction=? "
         "WHERE s.on_duty=1 AND s.user_id<>?")
    args: list = [SANTE_FACTION, exclude]
    if hospital_id:
        q += " AND s.hospital_id=?"
        args.append(hospital_id)
    async with db.execute(q, tuple(args)) as cur:
        rows = await cur.fetchall()
    return [_staff_dict(r) for r in rows if post_info(r["post"])["role"] in CARE_ROLES]


# ─────────────────────────────────────────────────────────────────────────────
#  Stocks et chaîne de production
# ─────────────────────────────────────────────────────────────────────────────
async def get_stock() -> dict[str, dict[str, int]]:
    out: dict[str, dict[str, int]] = {"raw": {}, "inter": {}, "med": {}}
    async with db_connection() as db:
        async with db.execute("SELECT kind, item, quantity FROM sante_stock WHERE quantity>0") as cur:
            for kind, item, qty in await cur.fetchall():
                out.setdefault(kind, {})[item] = qty
    return out


async def _qty(db, kind: str, item: str) -> int:
    async with db.execute("SELECT quantity FROM sante_stock WHERE kind=? AND item=?", (kind, item)) as cur:
        row = await cur.fetchone()
    return int(row[0]) if row else 0


async def _stock_add(db, kind: str, item: str, delta: int) -> None:
    await db.execute(
        "INSERT INTO sante_stock(kind, item, quantity) VALUES (?,?,MAX(0,?)) "
        "ON CONFLICT(kind, item) DO UPDATE SET quantity=MAX(0, quantity+?)", (kind, item, delta, delta))


async def _bump_activity(db, user_id: int, points: int = 1) -> None:
    await db.execute("UPDATE faction_members SET activity_score=activity_score+? WHERE user_id=?",
                     (points, user_id))


async def _require_role(user_id: int, role: str) -> tuple[dict | None, str]:
    st = await get_staff(user_id)
    if not st:
        return None, "Tu ne fais pas partie de la santé publique."
    if st["role"] != role:
        wanted = next((p["name"] for p in SANTE_POSTS.values() if p["role"] == role), role)
        return None, f"Ton poste ({st['post_name']}) ne permet pas ça. Il faut : {wanted}."
    return st, ""


async def gather(user_id: int, res: str) -> tuple[bool, str]:
    """Récolteur : ramasse des ressources brutes (coûte de l'énergie, cooldown)."""
    if res not in SANTE_RAW:
        return False, "Ressource inconnue."
    st, err = await _require_role(user_id, "gather")
    if err:
        return False, err
    u = await get_user(user_id)
    cost = SANTE_GATHER["energy"]
    if u.get("energy", 0) < cost:
        return False, f"😴 Trop fatigué(e) : il faut {cost}% d'énergie."
    ok, remaining = await claim_cooldown(user_id, "sante_gather", SANTE_GATHER["cooldown"])
    if not ok:
        return False, f"⏳ Repose-toi encore {_fmt(remaining)} avant de récolter."
    qty = random.randint(*SANTE_GATHER["yield"])
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            have = await _qty(db, "raw", res)
            cap = SANTE_STOCK_CAPS["raw"]
            if have >= cap:
                await db.rollback()
                await release_cooldown(user_id, "sante_gather")
                return False, "📦 Entrepôt plein pour cette ressource : laisse le laboratoire la transformer."
            qty = min(qty, cap - have)
            await _stock_add(db, "raw", res, qty)
            await db.execute("UPDATE users SET energy=MAX(0, energy-?) WHERE user_id=?", (cost, user_id))
            await _bump_activity(db, user_id)
            await _log(db, user_id, "recolte", 0, f"{res} x{qty}")
            await db.commit()
        except Exception:
            await db.rollback()
            await release_cooldown(user_id, "sante_gather")
            raise
    name, emoji = SANTE_RAW[res]
    return True, f"{emoji} Tu as récolté <b>{qty}</b> × {name}. (⚡ -{cost}%)"


async def _craft(user_id: int, role: str, kind_in: str, recipe: dict, kind_out: str, item_out: str,
                 cd_key: str, cd: int, label_out: str) -> tuple[bool, str]:
    st, err = await _require_role(user_id, role)
    if err:
        return False, err
    ok, remaining = await claim_cooldown(user_id, cd_key, cd)
    if not ok:
        return False, f"⏳ Prochaine fabrication dans {_fmt(remaining)}."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            missing = []
            for it, need in recipe["in"].items():
                have = await _qty(db, kind_in, it)
                if have < need:
                    missing.append(f"{_label(kind_in, it)} {have}/{need}")
            if missing:
                await db.rollback()
                await release_cooldown(user_id, cd_key)
                return False, "Il manque : " + ", ".join(missing)
            cap = SANTE_STOCK_CAPS[kind_out]
            have_out = await _qty(db, kind_out, item_out)
            if have_out >= cap:
                await db.rollback()
                await release_cooldown(user_id, cd_key)
                return False, f"📦 Stock plein pour {label_out} ({cap})."
            produced = min(recipe["out"], cap - have_out)
            for it, need in recipe["in"].items():
                await _stock_add(db, kind_in, it, -need)
            await _stock_add(db, kind_out, item_out, produced)
            await _bump_activity(db, user_id)
            await _log(db, user_id, "fabrication", 0, f"{item_out} x{produced}")
            await db.commit()
        except Exception:
            await db.rollback()
            await release_cooldown(user_id, cd_key)
            raise
    return True, f"{label_out} : <b>+{produced}</b>."


def _label(kind: str, item: str) -> str:
    if kind == "raw":
        n, e = SANTE_RAW[item]
    elif kind == "inter":
        n, e = SANTE_INTER[item]
    else:
        n, e = item, MEDICINES.get(item, {}).get("emoji", "💊")
    return f"{e} {n}"


async def lab_make(user_id: int, inter: str) -> tuple[bool, str]:
    """Technicien : ressources brutes → produit intermédiaire."""
    if inter not in SANTE_LAB_RECIPES:
        return False, "Recette inconnue."
    return await _craft(user_id, "lab", "raw", SANTE_LAB_RECIPES[inter], "inter", inter,
                        "sante_lab", SANTE_LAB_COOLDOWN, _label("inter", inter))


async def industry_make(user_id: int, med: str) -> tuple[bool, str]:
    """Opérateur : produits intermédiaires → médicament, mis en vente automatiquement."""
    if med not in SANTE_MED_RECIPES or med not in MEDICINES:
        return False, "Médicament inconnu."
    ok, msg = await _craft(user_id, "industry", "inter", SANTE_MED_RECIPES[med], "med", med,
                           "sante_industry", SANTE_INDUSTRY_COOLDOWN, _label("med", med))
    return ok, (msg + " 🛒 En vente dans le menu Médicaments.") if ok else msg


def _fmt(sec: int) -> str:
    sec = max(0, int(sec))
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m = r // 60
    if d:
        return f"{d} j {h:02d} h de jeu"
    return f"{h} h {m:02d} min de jeu" if h else f"{m} min de jeu"


# ─────────────────────────────────────────────────────────────────────────────
#  Assurance et paiements (tout va au coffre)
# ─────────────────────────────────────────────────────────────────────────────
async def get_insurance(user_id: int) -> dict | None:
    """Assurance en cours de validité (1 mois de jeu) ou None."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT type, coverage, claims, since FROM insurance WHERE user_id=? AND since > ?",
                (user_id, add_game_months(now(), -1))) as cur:
            row = await cur.fetchone()
    if not row:
        return None
    d = dict(row)
    d["limit"] = INSURANCE_PLANS.get(d["type"], {}).get("claims_limit", 3)
    d["left"] = max(0, d["limit"] - (d["claims"] or 0))
    return d


async def _apply_insurance(db, user_id: int, base: int) -> tuple[int, bool]:
    """Prix après assurance (consomme 1 sinistre si elle s'applique). Dans la transaction de l'appelant."""
    async with db.execute(
            "SELECT type, coverage, claims FROM insurance WHERE user_id=? AND since > ?",
            (user_id, add_game_months(now(), -1))) as cur:
        row = await cur.fetchone()
    if not row:
        return base, False
    limit = INSURANCE_PLANS.get(row[0], {}).get("claims_limit", 3)
    if (row[2] or 0) >= limit:
        return base, False
    await db.execute("UPDATE insurance SET claims=claims+1 WHERE user_id=?", (user_id,))
    return int(base * (1 - float(row[1]))), True


async def quote(user_id: int, base: int) -> tuple[int, bool]:
    """Prix indicatif après assurance (ne consomme rien)."""
    ins = await get_insurance(user_id)
    if ins and ins["left"] > 0:
        return int(base * (1 - float(ins["coverage"]))), True
    return base, False


async def subscribe_insurance(user_id: int, plan: str) -> tuple[bool, str]:
    p = INSURANCE_PLANS.get(plan)
    if not p:
        return False, "Plan inconnu."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            cur = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
                (p["cost"], p["cost"], user_id, p["cost"]))
            if not cur.rowcount:
                await db.rollback()
                return False, f"Fonds insuffisants : {p['cost']:,} requis."
            await db.execute(
                "INSERT INTO insurance (user_id, type, premium, coverage, since, claims) VALUES (?,?,?,?,?,0) "
                "ON CONFLICT(user_id) DO UPDATE SET type=excluded.type, premium=excluded.premium, "
                "coverage=excluded.coverage, since=excluded.since, claims=0",
                (user_id, plan, 1 if plan in ("premium", "vip") else 0, p["coverage"], now()))
            await coffre_add(db, SANTE_FACTION, p["cost"])           # la prime finance la santé publique
            await _log(db, user_id, "assurance", 0, f"{plan} {p['cost']}")
            await snapshot_user_core_stats(user_id, db)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, plan


# ─────────────────────────────────────────────────────────────────────────────
#  Médicaments (pharmacie : le stock vient de l'industrie)
# ─────────────────────────────────────────────────────────────────────────────
async def pharmacy_catalog(user_id: int) -> list[dict]:
    stock = (await get_stock())["med"]
    out = []
    for name, m in MEDICINES.items():
        price, discounted = await quote(user_id, m["price"])
        out.append({"name": name, "emoji": m["emoji"], "health": m["health"], "base": m["price"],
                    "price": price, "discounted": discounted, "stock": stock.get(name, 0)})
    return out


async def buy_medicine(user_id: int, med: str) -> tuple[bool, str]:
    if med not in MEDICINES:
        return False, "Médicament inconnu."
    m = MEDICINES[med]
    u = await get_user(user_id)
    if u.get("hospital_until", 0) > now():
        return False, "🏥 Tu es hospitalisé(e) : repose-toi."
    if u["health"] >= 100:
        return False, "❤️ Tu es déjà en pleine santé !"
    ok, remaining = await claim_cooldown(user_id, "sante_med", HOUR)
    if not ok:
        return False, f"⏳ Un médicament par heure de jeu : encore {_fmt(remaining)}."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            if await _qty(db, "med", med) <= 0:
                await db.rollback()
                await release_cooldown(user_id, "sante_med")
                return False, f"📦 {med} : rupture de stock. Les employés de la Santé publique doivent en fabriquer."
            price, discounted = await _apply_insurance(db, user_id, m["price"])
            cur = await db.execute(
                "UPDATE users SET balance=balance-?, total_spent=total_spent+?, health=MIN(100, health+?) "
                "WHERE user_id=? AND balance>=?", (price, price, m["health"], user_id, price))
            if not cur.rowcount:
                await db.rollback()
                await release_cooldown(user_id, "sante_med")
                return False, f"Fonds insuffisants : {price:,} requis."
            await _stock_add(db, "med", med, -1)
            await coffre_add(db, SANTE_FACTION, price)
            await _log(db, user_id, "achat_medicament", 0, f"{med} {price}")
            await snapshot_user_core_stats(user_id, db)
            await db.commit()
        except Exception:
            await db.rollback()
            await release_cooldown(user_id, "sante_med")
            raise
    new = min(100, u["health"] + m["health"])
    return True, (f"{m['emoji']} <b>{med}</b> pris !\n❤️ Santé : {u['health']}% → <b>{new}%</b>\n"
                  f"💰 Payé : <b>{price:,}</b>{' (assurance appliquée)' if discounted else ''}")


# ─────────────────────────────────────────────────────────────────────────────
#  Appels : ambulance gratuite et consultation sur place
# ─────────────────────────────────────────────────────────────────────────────
async def _patient_state(user_id: int) -> tuple[dict, str]:
    u = await get_user(user_id)
    if u["health"] >= 100:
        return u, "❤️ Tu es en pleine forme : pas besoin de soins."
    if u.get("hospital_until", 0) > now():
        return u, "🛏️ Tu es déjà pris(e) en charge à l'hôpital."
    return u, ""


async def _open_call(user_id: int, kind: str, hospital_id: str) -> int | None:
    """Crée l'appel si le joueur n'en a pas déjà un ouvert (atomique). None si déjà un appel."""
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                    "SELECT 1 FROM sante_calls WHERE patient_id=? AND status IN ('pending','taken')",
                    (user_id,)) as cur:
                if await cur.fetchone():
                    await db.rollback()
                    return None
            cur = await db.execute(
                "INSERT INTO sante_calls(patient_id, kind, hospital_id, status, created_at) VALUES (?,?,?,'pending',?)",
                (user_id, kind, hospital_id, now()))
            cid = cur.lastrowid
            await _log(db, user_id, "appel_" + kind, 0, f"#{cid} {hospital_id}")
            await db.commit()
            return cid
        except Exception:
            await db.rollback()
            raise


async def call_ambulance(user_id: int) -> tuple[bool, str]:
    """Appel GRATUIT : tous les soignants en service sont notifiés."""
    u, err = await _patient_state(user_id)
    if err:
        return False, err
    ok, remaining = await claim_cooldown(user_id, "sante_amb", SANTE_AMBULANCE_COOLDOWN)
    if not ok:
        return False, f"⏳ Tu as déjà appelé récemment : encore {_fmt(remaining)}."
    cid = await _open_call(user_id, "ambulance", "")
    if cid is None:
        await release_cooldown(user_id, "sante_amb")
        return False, "🚑 Tu as déjà un appel en cours."
    async with db_connection(row_factory=aiosqlite.Row) as db:
        carers = await _on_duty_carers(db, exclude=user_id)
    name = u.get("full_name") or u.get("username") or f"Joueur {user_id}"
    for c in carers:
        await notify(c["user_id"], "🚑 Appel d'urgence",
                     f"<b>{name}</b> (❤️ {u['health']}%) demande une ambulance (appel #{cid}).\n"
                     f"👉 Menu 🏥 Hôpital → 📟 Appels en attente.", "warning")
    if not carers:
        return True, ("🚑 Appel enregistré, mais <b>aucun soignant n'est en service</b> pour l'instant. "
                      "Il reste valable 30 min de jeu. Tu peux aussi aller à l'hôpital ou prendre un lit.")
    return True, f"🚑 Appel envoyé à <b>{len(carers)}</b> soignant(s) en service. Reste où tu es, ça ne coûte rien."


async def request_consult(user_id: int) -> tuple[bool, str]:
    """Soin sur place : le joueur est à un hôpital, les soignants EN SERVICE de cet hôpital sont notifiés."""
    from utils.location import get_position
    u, err = await _patient_state(user_id)
    if err:
        return False, err
    pos = await get_position(user_id)
    hid = None if pos["in_transit"] else hospital_at(pos["location"])
    if not hid:
        return False, "🏥 Rends-toi d'abord dans un hôpital (menu Hôpital → Hôpitaux)."
    ok, remaining = await claim_cooldown(user_id, "sante_consult", HOUR // 2)
    if not ok:
        return False, f"⏳ Une consultation toutes les 30 min de jeu : encore {_fmt(remaining)}."
    async with db_connection(row_factory=aiosqlite.Row) as db:
        carers = await _on_duty_carers(db, hospital_id=hid, exclude=user_id)
    if not carers:
        await release_cooldown(user_id, "sante_consult")
        return False, (f"Aucun soignant en service à <b>{hospital_info(hid)['name']}</b>. "
                       f"Essaie un 🛏️ lit libre, ou appelle une ambulance.")
    cid = await _open_call(user_id, "hopital", hid)
    if cid is None:
        await release_cooldown(user_id, "sante_consult")
        return False, "Tu as déjà un appel en cours."
    price, disc = await quote(user_id, SANTE_CONSULT_COST)
    name = u.get("full_name") or u.get("username") or f"Joueur {user_id}"
    for c in carers:
        await notify(c["user_id"], "🩺 Patient à l'accueil",
                     f"<b>{name}</b> (❤️ {u['health']}%) attend une consultation (appel #{cid}).\n"
                     f"👉 Menu 🏥 Hôpital → 📟 Appels en attente.", "info")
    return True, (f"🩺 Un soignant va te prendre en charge. Consultation : <b>{price:,}</b>"
                  f"{' (assurance appliquée)' if disc else ''}, payée au moment du soin.")


async def pending_calls_for(user_id: int) -> list[dict]:
    """Appels que ce soignant (en service) peut prendre + ceux qu'il a déjà pris."""
    st = await get_staff(user_id)
    if not st or st["role"] not in CARE_ROLES:
        return []
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT c.*, u.full_name, u.health FROM sante_calls c LEFT JOIN users u ON u.user_id=c.patient_id "
                "WHERE c.patient_id<>? AND ((c.status='pending' AND (c.kind='ambulance' OR c.hospital_id=?)) "
                "OR (c.status='taken' AND c.responder_id=?)) ORDER BY c.call_id LIMIT 15",
                (user_id, st["hospital_id"], user_id)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def take_call(user_id: int, call_id: int) -> tuple[bool, str]:
    st = await get_staff(user_id)
    if not st or st["role"] not in CARE_ROLES:
        return False, "Réservé aux soignants."
    if not st["on_duty"]:
        return False, "Prends d'abord ton service (menu Mon poste)."
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT * FROM sante_calls WHERE call_id=?", (call_id,)) as cur:
                call = await cur.fetchone()
            if not call or call["status"] != "pending":
                await db.rollback()
                return False, "Cet appel n'est plus disponible (déjà pris ou expiré)."
            if call["patient_id"] == user_id:
                await db.rollback()
                return False, "Tu ne peux pas te soigner toi-même."
            if call["kind"] == "hopital" and call["hospital_id"] != st["hospital_id"]:
                await db.rollback()
                return False, "Ce patient attend dans un autre hôpital."
            await db.execute(
                "UPDATE sante_calls SET status='taken', responder_id=?, taken_at=? WHERE call_id=?",
                (user_id, now(), call_id))
            await _log(db, user_id, "prise_en_charge", call["patient_id"], f"#{call_id}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await notify(call["patient_id"], "🚑 Un soignant arrive",
                 f"<b>{st['post_emoji']} {st['post_name']}</b> te prend en charge "
                 f"({'il vient à toi' if call['kind'] == 'ambulance' else 'à l’accueil'}).", "success")
    return True, "Appel pris en charge : une fois sur place, appuie sur « ✅ Soigner »."


async def treat_call(user_id: int, call_id: int) -> tuple[bool, str]:
    """Le soignant soigne le patient (gratuit pour une ambulance ; consultation payée au coffre sinon)."""
    from utils.location import get_position
    st = await get_staff(user_id)
    if not st or st["role"] not in CARE_ROLES:
        return False, "Réservé aux soignants."
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM sante_calls WHERE call_id=?", (call_id,)) as cur:
            call = await cur.fetchone()
    if not call or call["status"] != "taken" or call["responder_id"] != user_id:
        return False, "Cet appel n'est pas (ou plus) à toi."
    patient = call["patient_id"]
    if call["kind"] == "hopital":   # le patient doit toujours être à l'hôpital
        pos = await get_position(patient)
        if pos["in_transit"] or hospital_at(pos["location"]) != call["hospital_id"]:
            async with db_connection() as db:
                await db.execute("UPDATE sante_calls SET status='cancelled', done_at=? WHERE call_id=?", (now(), call_id))
                await db.commit()
            return False, "Le patient a quitté l'hôpital : appel annulé."
    limit, window = SANTE_PAIR_LIMIT
    heal = st["heal"] + (SANTE_CONSULT_BONUS if call["kind"] == "hopital" else 0)
    paid, discounted = 0, False
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                    "SELECT status FROM sante_calls WHERE call_id=?", (call_id,)) as cur:
                if (await cur.fetchone())["status"] != "taken":
                    await db.rollback()
                    return False, "Appel déjà traité."
            async with db.execute(
                    "SELECT COUNT(*) FROM sante_logs WHERE action='soin' AND actor_id=? AND target_id=? AND ts>?",
                    (user_id, patient, now() - window)) as cur:
                if (await cur.fetchone())[0] >= limit:
                    await db.rollback()
                    return False, "Ce patient a déjà reçu assez de soins de ta part pour le moment."
            async with db.execute("SELECT health FROM users WHERE user_id=?", (patient,)) as cur:
                prow = await cur.fetchone()
            if not prow or prow["health"] >= 100:
                await db.execute("UPDATE sante_calls SET status='done', done_at=? WHERE call_id=?", (now(), call_id))
                await db.commit()
                return False, "Le patient est déjà en pleine santé."
            if call["kind"] == "hopital":
                price, discounted = await _apply_insurance(db, patient, SANTE_CONSULT_COST)
                cur = await db.execute(
                    "UPDATE users SET balance=balance-?, total_spent=total_spent+? WHERE user_id=? AND balance>=?",
                    (price, price, patient, price))
                if not cur.rowcount:
                    await db.rollback()
                    return False, "Le patient ne peut pas payer la consultation."
                await coffre_add(db, SANTE_FACTION, price)
                paid = price
                await snapshot_user_core_stats(patient, db)
            await db.execute("UPDATE users SET health=MIN(100, health+?), stress=MAX(0, stress-?) WHERE user_id=?",
                             (heal, 10 if call["kind"] == "hopital" else 0, patient))
            await db.execute("UPDATE sante_calls SET status='done', done_at=? WHERE call_id=?", (now(), call_id))
            await _bump_activity(db, user_id)
            await _log(db, user_id, "soin", patient, f"#{call_id} +{heal} paye {paid}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    msg = f"❤️ Tu as soigné ton patient (<b>+{heal}%</b> de santé)."
    await notify(patient, "❤️ Soigné(e)",
                 f"<b>{st['post_emoji']} {st['post_name']}</b> t'a soigné(e) : <b>+{heal}%</b> de santé"
                 + (f"\n💰 Consultation : <b>{paid:,}</b>{' (assurance)' if discounted else ''}" if paid else "\n🚑 Gratuit."),
                 "success")
    return True, msg


async def cancel_call(patient_id: int) -> bool:
    async with db_connection() as db:
        cur = await db.execute(
            "UPDATE sante_calls SET status='cancelled', done_at=? WHERE patient_id=? AND status IN ('pending','taken')",
            (now(), patient_id))
        await db.commit()
    return bool(cur.rowcount)


# ─────────────────────────────────────────────────────────────────────────────
#  Lits (partagés par tous les joueurs, capacité limitée par hôpital, TEMPS RÉEL)
# ─────────────────────────────────────────────────────────────────────────────
async def bed_status(hospital_id: str) -> tuple[int, int]:
    """(lits occupés, capacité)."""
    async with db_connection() as db:
        async with db.execute("SELECT COUNT(*) FROM sante_beds WHERE hospital_id=?", (hospital_id,)) as cur:
            used = (await cur.fetchone())[0]
    return used, hospital_info(hospital_id)["beds"]


async def get_bed(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM sante_beds WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def take_bed(user_id: int) -> tuple[bool, str]:
    from utils.location import get_position
    u, err = await _patient_state(user_id)
    if err and "déjà pris" not in err:
        return False, err
    if await get_bed(user_id):
        return False, "🛏️ Tu es déjà allongé(e) sur un lit."
    if err:
        return False, err
    pos = await get_position(user_id)
    hid = None if pos["in_transit"] else hospital_at(pos["location"])
    if not hid:
        return False, "🏥 Il faut être dans un hôpital pour prendre un lit."
    cap = hospital_info(hid)["beds"]
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT COUNT(*) FROM sante_beds WHERE hospital_id=?", (hid,)) as cur:
                used = (await cur.fetchone())[0]
            if used >= cap:
                await db.rollback()
                return False, (f"🛏️ Tous les lits de <b>{hospital_info(hid)['name']}</b> sont occupés ({used}/{cap}). "
                               f"Réessaie dans quelques minutes ou va dans un autre hôpital.")
            await db.execute("INSERT INTO sante_beds(user_id, hospital_id, since_real) VALUES (?,?,?)",
                             (user_id, hid, now()))
            await db.execute("UPDATE users SET hospital_until=? WHERE user_id=?",
                             (now() + SANTE_BED_MAX, user_id))
            await _log(db, user_id, "lit", 0, hid)
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, (f"🛏️ Tu t'allonges à <b>{hospital_info(hid)['name']}</b> (lit {used + 1}/{cap}).\n"
                  f"⏳ Reste au moins <b>{fmt_time(SANTE_BED_MIN)}</b> (temps de jeu) pour guérir, puis appuie sur « Se lever ».")


async def _finish_bed(db, user_id: int, healed: bool) -> None:
    await db.execute("DELETE FROM sante_beds WHERE user_id=?", (user_id,))
    if healed:
        h = SANTE_BED_HEAL
        await db.execute(
            "UPDATE users SET health=MIN(100, health+?), energy=MIN(100, energy+?), stress=MAX(0, stress+?), "
            "hospital_until=0 WHERE user_id=?", (h["health"], h["energy"], h["stress"], user_id))
    else:
        await db.execute("UPDATE users SET hospital_until=0 WHERE user_id=?", (user_id,))


async def leave_bed(user_id: int, force: bool = False) -> tuple[bool, str]:
    """Se lever. Avant SANTE_BED_MIN (temps de jeu) : refusé (sauf `force` = partir sans être soigné)."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT * FROM sante_beds WHERE user_id=?", (user_id,)) as cur:
                bed = await cur.fetchone()
            if not bed:
                await db.rollback()
                return False, "Tu n'es sur aucun lit."
            elapsed = now() - bed["since_real"]
            if elapsed < SANTE_BED_MIN and not force:
                await db.rollback()
                left = SANTE_BED_MIN - elapsed
                return False, f"⏳ Encore {fmt_time(left)} de repos pour être guéri(e)."
            healed = elapsed >= SANTE_BED_MIN
            await _finish_bed(db, user_id, healed)
            await _log(db, user_id, "lit_fin", 0, f"{'soigné' if healed else 'parti'} {elapsed}s")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    if not healed:
        return True, "Tu quittes le lit sans avoir été soigné(e)."
    h = SANTE_BED_HEAL
    return True, f"✅ Tu te lèves en meilleure forme : ❤️ +{h['health']}% · ⚡ +{h['energy']}% · 😰 {h['stress']}%."


async def release_stale_beds() -> int:
    """Libère les lits occupés depuis plus de SANTE_BED_MAX (le patient est soigné et notifié)."""
    limit = now() - SANTE_BED_MAX
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT user_id FROM sante_beds WHERE since_real<=?", (limit,)) as cur:
            ids = [r[0] for r in await cur.fetchall()]
    done = 0
    for uid in ids:
        ok, _ = await leave_bed(uid)
        if ok:
            done += 1
            await notify(uid, "🛏️ Lit libéré", "Tu as bien récupéré : ton lit est libéré pour les autres patients.", "info")
    return done


async def free_beds(user_id: int | None = None, hospital_id: str | None = None) -> int:
    """Admin : libère de force un lit (sans soin) — résout un lit bloqué ou une triche."""
    q, args = "SELECT user_id FROM sante_beds WHERE 1=1", []
    if user_id:
        q += " AND user_id=?"
        args.append(user_id)
    if hospital_id:
        q += " AND hospital_id=?"
        args.append(hospital_id)
    async with db_connection() as db:
        async with db.execute(q, tuple(args)) as cur:
            ids = [r[0] for r in await cur.fetchall()]
        for uid in ids:
            await _finish_bed(db, uid, False)
        await db.commit()
    return len(ids)


# ─────────────────────────────────────────────────────────────────────────────
#  Tâches planifiées
# ─────────────────────────────────────────────────────────────────────────────
async def expire_calls() -> int:
    t = now()
    async with db_connection() as db:
        cur = await db.execute(
            "UPDATE sante_calls SET status='expired', done_at=? WHERE "
            "(status='pending' AND created_at<=?) OR (status='taken' AND taken_at<=?)",
            (t, t - SANTE_CALL_TTL, t - 2 * SANTE_CALL_TTL))
        await db.commit()
    return cur.rowcount


async def sante_maintenance() -> None:
    try:
        await expire_calls()
        await release_stale_beds()
    except Exception:
        logger.exception("Maintenance santé impossible")


def game_hour() -> int:
    return now() // HOUR


async def run_sante_payroll(hour: int | None = None) -> dict:
    """Salaires PAR HEURE DE JEU, payés par le coffre de la faction. Une seule paie par employé et par
    heure (payroll_log) ; coffre insuffisant → paie proportionnelle. Tâche planifiée (game_time)."""
    hour = game_hour() if hour is None else hour
    result = {"status": "none", "total": 0, "paid": 0, "count": 0}
    notes: list[tuple[int, str, str, str]] = []
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES (?,0)", (SANTE_FACTION,))
            q = ("SELECT s.user_id, s.post FROM sante_staff s JOIN faction_members fm "
                 "ON fm.user_id=s.user_id AND fm.faction=? WHERE NOT EXISTS (SELECT 1 FROM payroll_log p "
                 "WHERE p.kind='sante_h' AND p.entity='sante' AND p.user_id=s.user_id AND p.day=?)")
            if SANTE_PAY_ONLY_ON_DUTY:
                q += " AND s.on_duty=1"
            async with db.execute(q, (SANTE_FACTION, hour)) as cur:
                due = [(r["user_id"], post_info(r["post"])["salary_h"]) for r in await cur.fetchall()]
            if not due:
                await db.rollback()
                return result
            async with db.execute("SELECT budget FROM faction_state WHERE faction=?", (SANTE_FACTION,)) as cur:
                budget = (await cur.fetchone())["budget"]
            total = sum(a for _, a in due)
            ratio = 1.0 if budget >= total else (budget / total if total else 0)
            paid_total = 0
            for uid, amount in due:
                pay = int(amount * ratio)
                paid_total += pay
                if pay > 0:
                    await db.execute(
                        "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                        (pay, pay, uid))
                await db.execute("INSERT INTO payroll_log VALUES ('sante_h','sante',?,?,?,?)",
                                 (uid, hour, pay, "paid" if ratio >= 1 else "partial"))
                if ratio < 1:
                    notes.append((uid, "⚠️ Salaire partiel",
                                  f"🏥 Le coffre de la Santé publique est presque vide : tu reçois <b>{pay:,}</b> "
                                  f"sur {amount:,} pour cette heure de jeu. Les ventes de médicaments le remplissent !",
                                  "warning"))
            await db.execute("UPDATE faction_state SET budget=budget-? WHERE faction=?", (paid_total, SANTE_FACTION))
            if hour % 24 == 0:   # récapitulatif quotidien (évite une notification par heure de jeu)
                for uid, _a in due:
                    async with db.execute(
                            "SELECT COALESCE(SUM(amount),0) FROM payroll_log WHERE kind='sante_h' AND user_id=? "
                            "AND day>? AND day<=?", (uid, hour - 24, hour)) as cur:
                        day_total = (await cur.fetchone())[0]
                    notes.append((uid, "💰 Salaires de la journée",
                                  f"🏥 Santé publique : <b>+{day_total:,}</b> sur les 24 dernières heures de jeu.",
                                  "economy"))
            await db.commit()
            result.update(status="paid" if ratio >= 1 else "partial", total=total, paid=paid_total, count=len(due))
        except Exception:
            await db.rollback()
            raise
    for uid, title, msg, kind in notes:
        await notify(uid, title, msg, kind)
    return result


# ─────────────────────────────────────────────────────────────────────────────
#  Audit (admins)
# ─────────────────────────────────────────────────────────────────────────────
async def audit(limit: int = 25, user_id: int = 0) -> list[dict]:
    q, args = "SELECT * FROM sante_logs", []
    if user_id:
        q += " WHERE actor_id=? OR target_id=?"
        args += [user_id, user_id]
    q += " ORDER BY id DESC LIMIT ?"
    args.append(max(1, min(limit, 60)))
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(q, tuple(args)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_open_call(user_id: int) -> dict | None:
    """Appel en cours du patient (en attente ou pris en charge)."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT * FROM sante_calls WHERE patient_id=? AND status IN ('pending','taken') "
                "ORDER BY call_id DESC LIMIT 1", (user_id,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def hospital_overview() -> list[dict]:
    """Pour chaque hôpital : lits (occupés/capacité), soignants en service, directeur."""
    staff = await list_staff()
    out = []
    for hid, h in SANTE_HOSPITALS.items():
        used, cap = await bed_status(hid)
        here = [s for s in staff if s["hospital_id"] == hid]
        head = next((s for s in here if s["role"] == "head"), None)
        out.append({"id": hid, **h, "beds_used": used, "beds_cap": cap,
                    "on_duty": sum(1 for s in here if s["on_duty"] and s["role"] in CARE_ROLES),
                    "staff": len(here), "head": head})
    return out
