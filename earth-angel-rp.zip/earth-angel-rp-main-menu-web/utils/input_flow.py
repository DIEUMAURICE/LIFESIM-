"""
utils/input_flow.py — Saisie guidée par boutons
═══════════════════════════════════════════════════════════════════════
Remplace les commandes à arguments (/payer @user 500) et les drapeaux
`awaiting_*` dispersés par UN mécanisme unique :

    1. Un bouton lance `ask(...)` : le bot affiche une question + [❌ Annuler].
    2. Le joueur répond par un message (nombre, @pseudo / ID, texte).
    3. `flow_message_handler` valide la réponse et appelle le handler enregistré.

Exemple :

    @flow("payer_montant")
    async def _payer_montant(update, context, value, data):
        ...  # value = int validé
        await ask(update, context, "payer_cible", "Qui ? (@pseudo ou ID)",
                  kind="user", data={"amount": value})

    # Dans un callback de bouton :
    await ask(query, context, "payer_montant", "Montant ?", kind="amount",
              back="eco_retour")
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any, Awaitable, Callable

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationHandlerStop

from database import db_connection
from utils.helpers import parse_amount

FLOW_KEY = "_flow"
FLOW_TTL = 300  # secondes avant expiration d'une saisie en attente
CB_CANCEL = "flow_cancel"

FlowHandler = Callable[..., Awaitable[None]]
_REGISTRY: dict[str, FlowHandler] = {}


# ═══════════════════════════════════════════════════════════════════
#   ENREGISTREMENT
# ═══════════════════════════════════════════════════════════════════
def flow(name: str) -> Callable[[FlowHandler], FlowHandler]:
    """Décorateur : enregistre `fn(update, context, value, data)` sous `name`."""
    def deco(fn: FlowHandler) -> FlowHandler:
        _REGISTRY[name] = fn
        return fn
    return deco


@dataclass
class PendingFlow:
    name: str
    kind: str            # "amount" | "int" | "user" | "text"
    data: dict
    back: str | None
    min_value: int | None
    max_value: int | None
    balance: int | None  # permet « tout », « 50% », « moitié »…
    expires: float


# ═══════════════════════════════════════════════════════════════════
#   RÉSOLUTION D'UN JOUEUR (@pseudo, pseudo, ID)
# ═══════════════════════════════════════════════════════════════════
async def resolve_user(text: str) -> tuple[int, str] | None:
    """Retourne (user_id, nom affiché) pour un @pseudo, un pseudo ou un ID."""
    text = (text or "").strip()
    if not text:
        return None
    async with db_connection() as db:
        if text.lstrip("-").isdigit():
            q, p = "SELECT user_id, full_name, username FROM users WHERE user_id=?", (int(text),)
        else:
            q, p = ("SELECT user_id, full_name, username FROM users "
                    "WHERE LOWER(username)=LOWER(?)", (text.lstrip("@"),))
        async with db.execute(q, p) as cur:
            row = await cur.fetchone()
    if not row:
        return None
    return row[0], (row[1] or row[2] or str(row[0]))


# ═══════════════════════════════════════════════════════════════════
#   VALIDATION
# ═══════════════════════════════════════════════════════════════════
async def _validate(p: PendingFlow, text: str) -> tuple[Any, str | None]:
    """→ (valeur, None) si OK, sinon (None, message d'erreur)."""
    if p.kind in ("amount", "int"):
        n = parse_amount(text, p.balance) if p.kind == "amount" else _to_int(text)
        if n is None:
            return None, "❌ Nombre invalide. Exemples : <code>500</code>, <code>2k</code>, <code>50%</code>."
        if p.min_value is not None and n < p.min_value:
            return None, f"❌ Minimum : <b>{p.min_value}</b>."
        if p.max_value is not None and n > p.max_value:
            return None, f"❌ Maximum : <b>{p.max_value}</b>."
        return n, None
    if p.kind == "user":
        found = await resolve_user(text)
        if not found:
            return None, "❌ Joueur introuvable. Envoie son <b>@pseudo</b> ou son <b>ID</b>."
        return found, None
    value = text.strip()
    if not value:
        return None, "❌ Message vide."
    return value[:500], None


def _to_int(text: str) -> int | None:
    try:
        return int(text.strip())
    except ValueError:
        return None


# ═══════════════════════════════════════════════════════════════════
#   API PUBLIQUE
# ═══════════════════════════════════════════════════════════════════
def cancel_keyboard(back: str | None = None) -> InlineKeyboardMarkup:
    row = [InlineKeyboardButton("❌ Annuler", callback_data=CB_CANCEL)]
    if back:
        row.insert(0, InlineKeyboardButton("⬅️ Retour", callback_data=back))
    return InlineKeyboardMarkup([row])


async def ask(
    target,                       # CallbackQuery ou Update
    context,
    name: str,
    prompt: str,
    *,
    kind: str = "text",
    data: dict | None = None,
    back: str | None = None,
    min_value: int | None = None,
    max_value: int | None = None,
    balance: int | None = None,
) -> None:
    """Demande une saisie au joueur ; la réponse part vers `@flow(name)`."""
    if name not in _REGISTRY:
        raise KeyError(f"flow '{name}' non enregistré")
    context.user_data[FLOW_KEY] = PendingFlow(
        name=name, kind=kind, data=dict(data or {}), back=back,
        min_value=min_value, max_value=max_value, balance=balance,
        expires=time.time() + FLOW_TTL,
    )
    text = f"{prompt}\n\n<i>Réponds par un message — ou appuie sur Annuler.</i>"
    markup = cancel_keyboard(back)
    if hasattr(target, "edit_message_text"):          # CallbackQuery
        await target.edit_message_text(text, parse_mode="HTML", reply_markup=markup)
    else:                                              # Update
        await target.effective_message.reply_text(text, parse_mode="HTML", reply_markup=markup)


def clear(context) -> None:
    if context.user_data is None:
        return
    context.user_data.pop(FLOW_KEY, None)
    context.user_data.pop("_form", None)   # formulaire en cours (utils/forms.py)


class _MsgProxy:
    """Message réel + faux `reply_to_message` (pour les commandes « en répondant »)."""

    def __init__(self, real, reply_user):
        self._real = real
        self.reply_to_message = SimpleNamespace(
            from_user=reply_user, message_id=getattr(real, "message_id", 0), text=None)

    def __getattr__(self, name):
        return getattr(self._real, name)


async def call_cmd(src, context, cmd: Callable, args: list[str] | None = None,
                   reply_to: dict | None = None):
    """Appelle une ancienne `cmd_*` depuis un bouton OU une saisie.

    `src` = CallbackQuery ou Update. `reply_to` = {"id","name","username"} simule
    « en répondant au message de ce joueur ». Les `cmd_*` restent la logique métier ;
    seule leur exposition en commande Telegram disparaît.
    """
    if hasattr(src, "from_user"):                      # CallbackQuery
        u, message = src.from_user, src.message
    else:                                              # Update
        u, message = src.effective_user, src.effective_message
    fake_user = SimpleNamespace(
        id=u.id, username=u.username, full_name=u.full_name,
        first_name=u.first_name, last_name=getattr(u, "last_name", None) or "",
        name=u.full_name,
    )
    if reply_to:
        name = reply_to.get("name") or str(reply_to["id"])
        message = _MsgProxy(message, SimpleNamespace(
            id=reply_to["id"], username=reply_to.get("username"), full_name=name,
            first_name=name.split(" ")[0], last_name="", name=name, is_bot=False))
    fake_update = SimpleNamespace(
        effective_user=fake_user, message=message,
        callback_query=None, effective_message=message,
        effective_chat=getattr(message, "chat", None) or SimpleNamespace(id=u.id, type="private"),
    )
    fake_ctx = SimpleNamespace(
        args=list(args or []), user_data=context.user_data,
        bot=context.bot, application=context.application,
        chat_data=getattr(context, "chat_data", {}),
    )
    return await cmd(fake_update, fake_ctx)


# ═══════════════════════════════════════════════════════════════════
#   HANDLERS TELEGRAM (à enregistrer dans bot.py)
# ═══════════════════════════════════════════════════════════════════
async def flow_message_handler(update, context) -> None:
    """Capte la réponse texte d'une saisie en attente (groupe -1)."""
    msg = update.effective_message
    if context.user_data is None:        # mise à jour sans utilisateur (canal, sondage…) : rien à capter
        return
    p: PendingFlow | None = context.user_data.get(FLOW_KEY)
    if not p or not msg or not msg.text:
        return
    if time.time() > p.expires:
        clear(context)
        await msg.reply_text("⌛ Saisie expirée. Rouvre le 🎮 Menu principal.")
        raise ApplicationHandlerStop
    value, err = await _validate(p, msg.text)
    if err:
        await msg.reply_text(err, parse_mode="HTML", reply_markup=cancel_keyboard(p.back))
        raise ApplicationHandlerStop
    context.user_data.pop(FLOW_KEY, None)  # avant l'appel : le handler peut relancer ask()
    await _REGISTRY[p.name](update, context, value, p.data)
    raise ApplicationHandlerStop


async def flow_cancel_callback(update, context) -> None:
    q = update.callback_query
    await q.answer("Annulé")
    if context.user_data is None:
        return
    p: PendingFlow | None = context.user_data.get(FLOW_KEY)
    clear(context)
    back = p.back if p else None
    markup = InlineKeyboardMarkup(
        [[InlineKeyboardButton("⬅️ Retour", callback_data=back or "menu_main")]]
    )
    await q.edit_message_text("❌ Action annulée.", reply_markup=markup)
