"""
utils/staff_commands.py — Seules commandes Telegram encore actives
═══════════════════════════════════════════════════════════════════════
Le JEU ne se joue plus par commandes : tout passe par les boutons et les saisies guidées
(utils/forms.py, utils/input_flow.py, handlers/hub.py).
Restent uniquement :
  • /start  — ouvre le bot et le menu principal (point d'entrée imposé par Telegram) ;
  • les commandes du STAFF (admin, modération, rôles), qui ne servent pas à jouer.
"""
PLAYER_ENTRY = frozenset({"start"})

STAFF_COMMANDS = frozenset({
    'addbank', 'addcompanytreasury', 'addkarma', 'addmoney', 'addprestige',
    'addsocialcoins', 'addxp', 'admin', 'admin_action_log', 'recours', 'campagne', 'campagnes', 'campagne_valider', 'campagne_refuser', 'presence', 'passation', 'creneau', 'creneaux', 'presences', 'passations', 'audit', 'staff_nommer', 'staff_promouvoir', 'admin_divorce',
    'admin_help', 'adminlogs', 'adminpanel', 'announce', 'balance_stats',
    'banuser', 'boommarket', 'broadcast', 'broadcast_notify', 'cleardebt',
    'clearinventory', 'clearwarn', 'comp_add_score', 'comp_end', 'comp_start',
    'crashmarket', 'createevent', 'deletecompany', 'deleteuser', 'endevent',
    'fix_inventory', 'forcehire', 'forceprison', 'freeprison', 'freezeuser',
    'game_logs', 'gang_add', 'gang_create_admin', 'gang_delete', 'gang_remove',
    'gang_set_reputation', 'gang_set_treasury', 'giveallitems', 'givebadge', 'giveitem',
    'givemoney', 'gl_nommer_admin_n1', 'gl_nommer_admin_n2', 'gl_promouvoir_admin', 'gl_revoquer_admin',
    'globalstats', 'godmode', 'killuser', 'listcompanies', 'listitems',
    'listusers', 'lotowin', 'lsg_nommer_admin_n1', 'lsg_nommer_admin_n2', 'lsg_nommer_game_leader',
    'lsg_revoquer', 'maintenance', 'mission_force', 'monrole', 'nommer_admin_n1',
    'nommer_admin_n2', 'nommer_game_leader', 'nommer_pdg', 'revoquer_pdg', 'nommer_dg', 'sante_poste', 'sante_renvoyer', 'sante_audit', 'sante_lits', 'coffre', 'coffre_ajouter', 'coffre_retirer', 'nommer_lead_staff', 'notifications_stats', 'notify_user',
    'playerhistory', 'reloadconfig', 'rembank', 'remkarma', 'removefamily',
    'removemoney', 'removetreasury', 'remprestige', 'remsocialcoins', 'remxp',
    'report_handle', 'reports_list', 'reports_stats', 'resetcooldown', 'resetmarket',
    'resetmissions', 'resetuser', 'resetworld', 'revoquer', 'serverstats',
    'setage', 'setbank', 'setbio', 'setblackmarket', 'setcolor',
    'setcompanylevel', 'setcompanyreputation', 'setcompanytreasury', 'setdiplome', 'setenergy',
    'setfamily', 'sethappiness', 'sethospital', 'sethp', 'sethunger',
    'setitem', 'setjob', 'setkarma', 'setlevel', 'setlocation',
    'setluxury', 'setmarriage', 'setmoney', 'setprestige', 'setprice',
    'setproperty', 'setpropertycond', 'setrelation', 'setskill', 'setsocialcoins',
    'setstock', 'setstress', 'settravel', 'setvehicle', 'setvehiclecond',
    'setxp', 'spawn', 'staff_history', 'staff_liste', 'stars_revenue',
    'takeitem', 'timetravel', 'topstats', 'transaction_info', 'transactions',
    'unbanuser', 'unfreezeuser', 'userinfo', 'userstats', 'warn',
})

KEEP_COMMANDS = PLAYER_ENTRY | STAFF_COMMANDS
