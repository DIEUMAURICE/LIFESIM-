# utils/factions.py — factions gouvernementales : adhésion, grades, promotions, conversion
"""
Les secteurs Santé / Défense / Juridique ne sont plus des entreprises privées : ce sont des
factions gouvernementales (config.GOV_FACTIONS). Un joueur travaille SOIT dans une entreprise
SOIT dans une faction (un seul lieu de travail).
"""
import logging

import aiosqlite

from config import (
    GOV_FACTIONS, GOV_SECTOR_TO_FACTION, COMPANY_RANKS, PROMOTION_REQUIREMENTS,
    COMPANY_PROMOTION_REQUIREMENTS,
)
from database import db_connection, get_user_company, get_skill, now
from utils.notify import notify

logger = logging.getLogger(__name__)


def rank_name(key: str, rank: int) -> str:
    ranks = GOV_FACTIONS[key]["ranks"]
    return ranks[min(max(rank, 0), len(ranks) - 1)][0]


def rank_salary(key: str, rank: int) -> int:
    ranks = GOV_FACTIONS[key]["ranks"]
    return ranks[min(max(rank, 0), len(ranks) - 1)][1]


async def get_membership(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM faction_members WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
    if not row:
        return None
    m = dict(row)
    m["rank_name"] = rank_name(m["faction"], m["rank"])
    m["salary"] = rank_salary(m["faction"], m["rank"])
    m["hourly"] = bool(GOV_FACTIONS[m["faction"]].get("hourly"))
    if m["faction"] == "sante":
        from utils import sante   # import tardif : sante dépend de ce module
        staff = await sante.get_staff(user_id)
        if staff:
            m["rank_name"], m["salary"], m["post"] = staff["post_name"], staff["salary_h"], staff["post"]
            m["hospital_id"] = staff["hospital_id"]
    elif m["faction"] in ("police", "armee", "justice"):
        from utils import ordre   # import tardif : ordre dépend de ce module
        staff = await ordre.get_staff(user_id)
        if staff:
            m["rank_name"], m["salary"], m["post"] = staff["post_name"], staff["salary_h"], staff["post"]
            m["station_id"] = staff["station_id"]
    return m


def salary_unit(key: str) -> str:
    """'/h de jeu' pour les factions payées à l'heure (santé), '/jour' sinon."""
    return "/h de jeu" if GOV_FACTIONS.get(key, {}).get("hourly") else "/jour"


# ─────────────────────────────────────────────────────────────────────────────
#  Coffre général d'une faction (= faction_state.budget) : reçoit les paiements de ses biens et
#  services, finance ses salaires. Chaque faction a le sien.
# ─────────────────────────────────────────────────────────────────────────────
async def coffre_add(db, key: str, amount: int) -> None:
    """Crédite (ou débite si négatif) le coffre dans la transaction `db` de l'appelant."""
    await db.execute("INSERT OR IGNORE INTO faction_state(faction, budget) VALUES (?,0)", (key,))
    await db.execute("UPDATE faction_state SET budget=budget+? WHERE faction=?", (int(amount), key))


async def coffre_balance(key: str) -> int:
    async with db_connection() as db:
        async with db.execute("SELECT budget FROM faction_state WHERE faction=?", (key,)) as cur:
            row = await cur.fetchone()
    return int(row[0]) if row else 0


def requirements_for(table: dict, target_rank: int) -> dict:
    """Exigences pour atteindre `target_rank` (au-delà de la table : la dernière, renforcée)."""
    if target_rank in table:
        return table[target_rank]
    last_key = max(table)
    base = table[last_key]
    mult = 1 + 0.5 * (target_rank - last_key)
    return {"activity": int(base["activity"] * mult),
            "skills": {k: int(v * mult) for k, v in base["skills"].items()}}


async def check_requirements(user_id: int, activity: int, req: dict) -> list[str]:
    """Liste des manques (vide = éligible)."""
    missing = []
    if activity < req["activity"]:
        missing.append(f"Activité {activity}/{req['activity']}")
    for skill, need in req["skills"].items():
        have = await get_skill(user_id, skill)
        if have < need:
            missing.append(f"{skill} {have}/{need}")
    return missing


async def join_faction(user_id: int, key: str, rank: int = 0) -> tuple[bool, str]:
    if key not in GOV_FACTIONS:
        return False, "Faction inconnue."
    if await get_user_company(user_id):
        return False, "Tu travailles déjà dans une entreprise : démissionne d'abord."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute(
            "INSERT OR IGNORE INTO faction_members(user_id, faction, rank, activity_score, joined_at) "
            "VALUES (?,?,?,0,?)", (user_id, key, rank, now()))
        if not cur.rowcount:
            await db.rollback()
            return False, "Tu fais déjà partie d'une faction."
        await db.commit()
    return True, ""


async def leave_faction(user_id: int) -> bool:
    from utils import weapons
    await weapons.strip_issued_weapons(user_id)      # armes de dotation rendues à la chambre d'armes
    async with db_connection() as db:
        cur = await db.execute("DELETE FROM faction_members WHERE user_id=?", (user_id,))
        await db.execute("DELETE FROM sante_staff WHERE user_id=?", (user_id,))   # poste santé (et direction) libérés
        await db.execute("DELETE FROM ordre_staff WHERE user_id=?", (user_id,))   # poste police / armée libéré
        await db.commit()
    return bool(cur.rowcount)


async def try_auto_promotion(user_id: int) -> tuple[bool, str]:
    """Promotion automatique par compétences, jusqu'à `auto_cap`. Au-delà : nomination du chef."""
    m = await get_membership(user_id)
    if not m:
        return False, "Tu n'es dans aucune faction."
    f = GOV_FACTIONS[m["faction"]]
    if m["faction"] in ("police", "armee", "justice"):
        return False, ("Dans la police et l'armée, les postes sont attribués par ta direction "
                       "(chef de poste ou DG). Fais-toi remarquer !")
    if m["faction"] == "sante":
        return False, ("Dans la santé publique, les postes sont attribués par ta direction "
                       "(DG de ton hôpital ou PDG). Fais-toi remarquer !")
    target = m["rank"] + 1
    if target >= len(f["ranks"]):
        return False, "Tu es déjà au plus haut grade."
    if target > f["auto_cap"]:
        return False, (f"Le grade <b>{rank_name(m['faction'], target)}</b> est une nomination : "
                       f"fais-toi remarquer de ta hiérarchie.")
    req = requirements_for(PROMOTION_REQUIREMENTS, target)
    missing = await check_requirements(user_id, m["activity_score"], req)
    if missing:
        return False, ("Il te manque : " + ", ".join(missing) +
                       "\n💡 Les compétences s'améliorent depuis le menu.")
    async with db_connection() as db:
        cur = await db.execute(
            "UPDATE faction_members SET rank=? WHERE user_id=? AND rank=?", (target, user_id, m["rank"]))
        await db.commit()
    if not cur.rowcount:
        return False, "Ton grade a déjà changé."
    new = rank_name(m["faction"], target)
    await notify(user_id, "🎖️ Promotion",
                 f"Tu es promu(e) <b>{new}</b> ({f['name']}). Nouveau salaire : "
                 f"<b>{rank_salary(m['faction'], target):,}</b>/jour.", "achievement")
    return True, new


def company_rank_index(poste: str) -> int:
    return COMPANY_RANKS.index(poste) if poste in COMPANY_RANKS else COMPANY_RANKS.index("Employé")


async def company_promotion_check(user_id: int, company_id: int) -> tuple[int, dict, list[str], str]:
    """(rang_visé, exigences, manques, poste_actuel) pour un employé d'entreprise."""
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
            "SELECT poste, activity_score FROM company_members WHERE user_id=? AND company_id=?",
            (user_id, company_id)) as cur:
            row = await cur.fetchone()
    poste, activity = row["poste"], row["activity_score"]
    target = company_rank_index(poste) + 1
    # le rang PDG n'est jamais attribué par promotion
    if target >= len(COMPANY_RANKS) - 1:
        return target, {}, ["Rang maximal atteint pour un employé"], poste
    req = requirements_for(COMPANY_PROMOTION_REQUIREMENTS, target)
    return target, req, await check_requirements(user_id, activity, req), poste


async def migrate_gov_companies() -> int:
    """Convertit sans perte les entreprises des anciens secteurs d'État en factions.
    Idempotent (les entreprises converties sont marquées dissoutes). Retourne le nombre converti."""
    done = 0
    async with db_connection(row_factory=aiosqlite.Row) as db:
        marks = ",".join("?" * len(GOV_SECTOR_TO_FACTION))
        async with db.execute(
            f"SELECT * FROM companies WHERE dissolved=0 AND sector IN ({marks})",
            tuple(GOV_SECTOR_TO_FACTION)) as cur:
            companies = [dict(r) for r in await cur.fetchall()]
    for c in companies:
        key = GOV_SECTOR_TO_FACTION[c["sector"]]
        f = GOV_FACTIONS[key]
        notes = []
        async with db_connection(row_factory=aiosqlite.Row) as db:
            await db.execute("BEGIN IMMEDIATE")
            try:
                async with db.execute(
                    "SELECT user_id, poste FROM company_members WHERE company_id=?", (c["company_id"],)) as cur:
                    members = [dict(r) for r in await cur.fetchall()]
                async with db.execute(
                    "SELECT user_id, shares FROM company_shares WHERE company_id=? AND shares>0",
                    (c["company_id"],)) as cur:
                    holders = [dict(r) for r in await cur.fetchall()]
                # Trésorerie : répartie aux actionnaires au prorata, reste au créateur
                treasury = c["treasury"] or 0
                total_shares = sum(h["shares"] for h in holders if h["user_id"] != c["owner_id"])
                payouts: dict[int, int] = {}
                if total_shares > 0 and treasury > 0:
                    pool = treasury // 2
                    for h in holders:
                        if h["user_id"] != c["owner_id"]:
                            payouts[h["user_id"]] = pool * h["shares"] // total_shares
                paid_out = sum(payouts.values())
                payouts[c["owner_id"]] = payouts.get(c["owner_id"], 0) + (treasury - paid_out)
                for uid, amt in payouts.items():
                    if amt > 0:
                        await db.execute("UPDATE users SET balance=balance+? WHERE user_id=?", (amt, uid))
                        notes.append((uid, "🏛️ Entreprise nationalisée",
                                      f"<b>{c['name']}</b> (secteur {c['sector']}) passe sous contrôle de l'État. "
                                      f"Tu récupères <b>{amt:,}</b> de la trésorerie.", "economy"))
                # Membres → grades de la faction
                for mem in members:
                    if mem["user_id"] == c["owner_id"]:
                        rank = min(len(f["ranks"]) - 1, f["auto_cap"] + 1)   # grade de commandement
                    else:
                        rank = min(f["auto_cap"], company_rank_index(mem["poste"]) // 2)
                    cur = await db.execute(
                        "INSERT OR IGNORE INTO faction_members(user_id, faction, rank, activity_score, joined_at) "
                        "VALUES (?,?,?,0,?)", (mem["user_id"], key, rank, now()))
                    if cur.rowcount:
                        notes.append((mem["user_id"], "🏛️ Nouvelle affectation",
                                      f"Tu rejoins {f['emoji']} <b>{f['name']}</b> au grade "
                                      f"<b>{rank_name(key, rank)}</b>.", "info"))
                await db.execute("DELETE FROM company_members WHERE company_id=?", (c["company_id"],))
                await db.execute("UPDATE companies SET dissolved=1, treasury=0 WHERE company_id=?",
                                 (c["company_id"],))
                await db.execute(
                    "INSERT INTO company_logs (company_id,action,actor_id,details,timestamp) VALUES (?,?,?,?,?)",
                    (c["company_id"], "nationalisation", 0, f"→ faction {key}", now()))
                await db.commit()
                done += 1
            except Exception:
                await db.rollback()
                logger.exception("Conversion de %s en faction impossible", c["name"])
                continue
        for uid, title, msg, kind in notes:
            await notify(uid, title, msg, kind)
    return done


# ─────────────────────────────────────────────────────────────────────────────
#  Métiers qualifiés → entreprises / factions (les petits métiers restent freelance)
# ─────────────────────────────────────────────────────────────────────────────
_JOB_RENAMED = {"Développeur": "Dev freelance"}


async def migrate_legacy_jobs() -> int:
    """Les anciens métiers qui n'existent plus en freelance (Médecin, Avocat, PDG…) s'exercent
    désormais en entreprise ou en faction. Le joueur qui en portait un est remis « sans petit
    métier » et notifié. « Développeur » devient « Dev freelance ». Idempotent."""
    from config import SMALL_JOBS
    changed: list[tuple[int, str, str]] = []
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT user_id, job FROM users WHERE job IS NOT NULL AND job != ''") as cur:
            rows = [dict(r) for r in await cur.fetchall()]
        for r in rows:
            job = r["job"]
            if job in SMALL_JOBS:
                continue
            new = _JOB_RENAMED.get(job, "")
            await db.execute("UPDATE users SET job=? WHERE user_id=?", (new, r["user_id"]))
            changed.append((r["user_id"], job, new))
        await db.commit()
    for uid, old, new in changed:
        if new:
            await notify(uid, "💼 Ton métier évolue",
                         f"« {old} » devient <b>{new}</b> (petit métier freelance).", "info")
        else:
            await notify(uid, "💼 Ton métier a changé",
                         f"« {old} » n'est plus un petit métier : il s'exerce maintenant dans une "
                         f"entreprise ou une faction. "
                         f"Tu peux aussi choisir un petit métier depuis le menu.", "warning")
    return len(changed)
