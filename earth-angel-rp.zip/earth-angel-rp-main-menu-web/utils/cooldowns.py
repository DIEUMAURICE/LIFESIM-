# utils/cooldowns.py
from database import db_connection, now


async def claim_cooldown(
    user_id: int,
    key: str,
    duration: int,
) -> tuple[bool, int]:
    """Réserve un cooldown de façon atomique.

    Retourne (True, 0) si la commande peut démarrer.
    Retourne (False, secondes_restantes) sinon.
    """
    if duration <= 0:
        return True, 0
    if not key or len(key) > 100:
        raise ValueError("Clé de cooldown invalide")

    current = now()
    threshold = current - duration

    async with db_connection() as db:
        try:
            await db.execute("BEGIN IMMEDIATE")
            cursor = await db.execute(
                "INSERT INTO user_cooldowns "
                "(user_id,cooldown_key,last_used) VALUES (?,?,?) "
                "ON CONFLICT(user_id,cooldown_key) DO UPDATE SET "
                "last_used=excluded.last_used "
                "WHERE user_cooldowns.last_used<=?",
                (user_id, key, current, threshold),
            )

            if cursor.rowcount == 1:
                await db.commit()
                return True, 0

            async with db.execute(
                "SELECT last_used FROM user_cooldowns "
                "WHERE user_id=? AND cooldown_key=?",
                (user_id, key),
            ) as result:
                row = await result.fetchone()
            await db.rollback()

            last_used = row[0] if row else current
            remaining = max(1, last_used + duration - current)
            return False, remaining
        except Exception:
            await db.rollback()
            raise


async def cooldown_left(user_id: int, key: str, duration: int) -> int:
    """Secondes DE JEU restantes avant la fin du cooldown `key` (0 = disponible). Lecture seule."""
    async with db_connection() as db:
        async with db.execute(
            "SELECT last_used FROM user_cooldowns WHERE user_id=? AND cooldown_key=?",
            (user_id, key),
        ) as cur:
            row = await cur.fetchone()
    if not row:
        return 0
    return max(0, int(row[0]) + int(duration) - now())


async def release_cooldown(user_id: int, key: str) -> None:
    """Annule une réservation, utile si une action échoue techniquement."""
    async with db_connection() as db:
        await db.execute(
            "DELETE FROM user_cooldowns WHERE user_id=? AND cooldown_key=?",
            (user_id, key),
        )
        await db.commit()


async def clear_expired_cooldowns(max_age: int = 30 * 86400) -> int:
    """Nettoyage périodique des anciennes clés."""
    cutoff = now() - max_age
    async with db_connection() as db:
        cursor = await db.execute(
            "DELETE FROM user_cooldowns WHERE last_used<?",
            (cutoff,),
        )
        await db.commit()
        return max(0, cursor.rowcount)