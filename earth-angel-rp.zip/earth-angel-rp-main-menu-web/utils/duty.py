"""Service (« en service ») : le temps DE JEU passé en service sur son lieu de travail détermine l'activité gagnée.

Activité = minutes de jeu en service ÷ ACTIVITY_MINUTES_PER_POINT (une session compte au plus DUTY_MAX_SECONDS).
Elle est créditée EN CONTINU (tâche planifiée) : elle alimente les promotions (factions + entreprises) et,
pour une entreprise, la production de l'heure suivante.
"""
from config import ACTIVITY_MINUTES_PER_POINT, DUTY_MAX_SECONDS
from database import db_connection, now


async def get_duty_since(user_id: int) -> float | None:
    async with db_connection() as db:
        async with db.execute("SELECT since FROM work_duty WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
    return float(row[0]) if row else None


def points_for(elapsed_seconds: float) -> int:
    """Points d'activité gagnés pour `elapsed_seconds` secondes de jeu en service."""
    capped = max(0.0, min(float(elapsed_seconds), float(DUTY_MAX_SECONDS)))
    return int(capped // (ACTIVITY_MINUTES_PER_POINT * 60))


async def start_duty(user_id: int) -> bool:
    """Prend le service. False si le joueur y est déjà."""
    async with db_connection() as db:
        cur = await db.execute("INSERT OR IGNORE INTO work_duty(user_id, since) VALUES (?,?)",
                               (user_id, now()))
        await db.commit()
    return cur.rowcount > 0


async def stop_duty(user_id: int) -> tuple[bool, float, int]:
    """Quitte le service. Retourne (était_en_service, secondes_de_jeu, points_gagnés).
    Les points sont à créditer par l'appelant (faction / entreprise) via `credit_activity`."""
    async with db_connection() as db:
        async with db.execute("SELECT since, credited_pts FROM work_duty WHERE user_id=?", (user_id,)) as cur:
            row = await cur.fetchone()
        cur = await db.execute("DELETE FROM work_duty WHERE user_id=?", (user_id,))
        await db.commit()
    if not row or not cur.rowcount:
        return False, 0.0, 0
    elapsed = max(0.0, now() - float(row[0]))
    return True, elapsed, max(0, points_for(elapsed) - int(row[1] or 0))     # le reste n'a pas été crédité en continu


async def running() -> list[tuple[int, float, int]]:
    """Tous les joueurs actuellement en service : (user_id, début, points déjà crédités)."""
    async with db_connection() as db:
        async with db.execute("SELECT user_id, since, credited_pts FROM work_duty") as cur:
            return [(r[0], float(r[1]), int(r[2] or 0)) for r in await cur.fetchall()]


async def mark_credited(user_id: int, total_points: int) -> None:
    async with db_connection() as db:
        await db.execute("UPDATE work_duty SET credited_pts=? WHERE user_id=?", (total_points, user_id))
        await db.commit()


async def credit_activity(user_id: int, kind: str, company_id: int | None, points: int) -> None:
    """Ajoute les points à l'employeur du joueur (faction ou entreprise)."""
    if points <= 0:
        return
    async with db_connection() as db:
        if kind == "faction":
            await db.execute("UPDATE faction_members SET activity_score=activity_score+? WHERE user_id=?",
                             (points, user_id))
        elif company_id:
            await db.execute("UPDATE company_members SET activity_score=activity_score+? "
                             "WHERE user_id=? AND company_id=?", (points, user_id, company_id))
        await db.commit()
    if kind == "company" and company_id:
        from utils.payroll import record_activity      # l'équipe travaille : alimente la production du jour
        async with db_connection() as db:
            async with db.execute("SELECT dept FROM company_members WHERE user_id=? AND company_id=?",
                                  (user_id, company_id)) as cur:
                row = await cur.fetchone()
        await record_activity(company_id, points, dept=(row[0] if row else "") or "")
