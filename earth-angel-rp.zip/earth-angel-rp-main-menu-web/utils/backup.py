# utils/backup.py
from __future__ import annotations

import asyncio
import gzip
import hashlib
import json
import logging
import os
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import aiosqlite

from config import DB_PATH, DATA_DIR
from database import DB_TIMEOUT, _configure_connection


logger = logging.getLogger(__name__)

BACKUP_DIR = Path(os.getenv("BACKUP_DIR", str(DATA_DIR / "backups"))).expanduser().resolve()
BACKUP_RETENTION = max(3, int(os.getenv("BACKUP_RETENTION", "14")))
BACKUP_PREFIX = "life_sim"

_backup_lock = asyncio.Lock()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


async def _integrity_check(path: Path) -> None:
    async with aiosqlite.connect(str(path), timeout=DB_TIMEOUT) as db:
        async with db.execute("PRAGMA integrity_check") as cursor:
            row = await cursor.fetchone()
    if not row or row[0] != "ok":
        detail = row[0] if row else "aucun résultat"
        raise RuntimeError(f"Sauvegarde SQLite invalide : {detail}")


def _write_manifest(
    archive: Path,
    checksum: str,
    source_size: int,
) -> Path:
    manifest = archive.with_suffix(archive.suffix + ".json")
    payload = {
        "archive": archive.name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "sha256": checksum,
        "compressed_size": archive.stat().st_size,
        "database_size": source_size,
        "source": Path(DB_PATH).name,
    }
    manifest.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return manifest


def prune_old_backups() -> int:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    archives = sorted(
        BACKUP_DIR.glob(f"{BACKUP_PREFIX}-*.db.gz"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    removed = 0
    for archive in archives[BACKUP_RETENTION:]:
        manifest = archive.with_suffix(archive.suffix + ".json")
        archive.unlink(missing_ok=True)
        manifest.unlink(missing_ok=True)
        removed += 1
    return removed


async def create_backup() -> Path:
    """Crée, vérifie, compresse et signe une sauvegarde."""
    async with _backup_lock:
        source_path = Path(DB_PATH)
        if not source_path.is_file():
            raise FileNotFoundError(f"Base introuvable : {source_path}")

        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        archive = BACKUP_DIR / f"{BACKUP_PREFIX}-{timestamp}.db.gz"

        with tempfile.TemporaryDirectory(dir=BACKUP_DIR) as temp_dir:
            snapshot = Path(temp_dir) / "snapshot.db"

            async with aiosqlite.connect(
                str(source_path),
                timeout=DB_TIMEOUT,
            ) as source:
                await _configure_connection(source)
                async with aiosqlite.connect(
                    str(snapshot),
                    timeout=DB_TIMEOUT,
                ) as destination:
                    await source.backup(destination, pages=1000, sleep=0.05)
                    await destination.commit()

            await _integrity_check(snapshot)
            source_size = snapshot.stat().st_size

            with snapshot.open("rb") as source_file:
                with gzip.open(archive, "wb", compresslevel=6) as target_file:
                    shutil.copyfileobj(source_file, target_file)

        checksum = _sha256(archive)
        _write_manifest(archive, checksum, source_size)
        removed = prune_old_backups()
        logger.info(
            "Sauvegarde créée : %s (%s anciennes supprimées)",
            archive,
            removed,
        )
        return archive


async def backup_job() -> None:
    try:
        await create_backup()
    except Exception:
        logger.exception("Échec de la sauvegarde automatique")
        raise
