# utils/justice.py — ⚖️ Justice : dossiers judiciaires, caution, avocats, procès, mandats d'arrêt
"""
Deux postes seulement : le JUGE (nommé par le Game Leader, il recrute les avocats) et l'AVOCAT.

Synchronisation avec la police et l'armée :
  • toute arrestation / peine de prison (interrogatoire, enquête réussie, livraison de l'armée, crime raté)
    ouvre un DOSSIER JUDICIAIRE (`open_file`) ;
  • le juge fixe une CAUTION, juge l'affaire (acquittement, amende, prison jusqu'à 3 h) ou délivre un MANDAT
    d'arrêt (police et armée sont alertées, le joueur apparaît « recherché ») ;
  • le détenu prend un AVOCAT (honoraires) qui plaide : plaidoirie réussie = -35 % sur la caution et la peine ;
  • caution et amendes alimentent le coffre de la Justice (qui paie les salaires).
Sans aucun juge dans la faction, l'ancien système automatique (caution / tribunal / avocat) reste le secours.
"""
import logging
import random

import aiosqlite

from config import JUSTICE, ORDRE
from database import db_connection, now, get_user, get_skill
from utils.factions import coffre_add
from database import now as real_now      # horloge du jeu (comme tout le module Ordre public)
from utils.notify import notify

logger = logging.getLogger(__name__)

OPEN_STATUS = ("detenu", "audience")


def _log(db, actor: int, action: str, target: int = 0, details: str = ""):
    return db.execute("INSERT INTO ordre_logs(ts, actor_id, action, target_id, details) VALUES (?,?,?,?,?)",
                      (real_now(), actor, action, target, details[:300]))


async def _name(user_id: int) -> str:
    u = await get_user(user_id)
    return u.get("full_name") or u.get("username") or str(user_id)


# ─────────────────────────────────────────────────────────────────────────────
#  Personnel de la Justice
# ─────────────────────────────────────────────────────────────────────────────
async def staff(user_id: int) -> dict | None:
    from utils import ordre
    st = await ordre.get_staff(user_id)
    return st if st and st["faction"] == "justice" else None


async def judge_check(user_id: int, on_duty: bool = True) -> tuple[dict | None, str]:
    st = await staff(user_id)
    if not st or st["post"] != "juge":
        return None, "Réservé aux juges."
    if on_duty and not st["on_duty"]:
        return None, "Prends d'abord ton service (menu Ordre public → Mon poste)."
    return st, ""


async def lawyer_check(user_id: int, on_duty: bool = True) -> tuple[dict | None, str]:
    st = await staff(user_id)
    if not st or st["post"] != "avocat":
        return None, "Réservé aux avocats."
    if on_duty and not st["on_duty"]:
        return None, "Prends d'abord ton service (menu Ordre public → Mon poste)."
    return st, ""


async def has_judges() -> bool:
    """Au moins un juge dans la faction ? Sinon l'ancien système automatique prend le relais."""
    async with db_connection() as db:
        async with db.execute(
                "SELECT 1 FROM ordre_staff s JOIN faction_members fm ON fm.user_id=s.user_id AND fm.faction=s.faction "
                "WHERE s.faction='justice' AND s.post='juge' LIMIT 1") as cur:
            return await cur.fetchone() is not None


async def list_lawyers(on_duty_only: bool = True) -> list[dict]:
    q = ("SELECT s.user_id, s.on_duty, u.full_name FROM ordre_staff s JOIN faction_members fm "
         "ON fm.user_id=s.user_id AND fm.faction=s.faction LEFT JOIN users u ON u.user_id=s.user_id "
         "WHERE s.faction='justice' AND s.post='avocat'")
    if on_duty_only:
        q += " AND s.on_duty=1"
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(q + " LIMIT 12") as cur:
            return [dict(r) for r in await cur.fetchall()]


# ─────────────────────────────────────────────────────────────────────────────
#  Dossiers
# ─────────────────────────────────────────────────────────────────────────────
async def open_file(suspect_id: int, crime: str, source: str, jail_secs: int) -> int:
    """Ouvre un dossier judiciaire pour un suspect qui vient d'être arrêté / condamné à une peine de prison."""
    async with db_connection() as db:
        async with db.execute("SELECT id FROM justice_files WHERE suspect_id=? AND status IN ('detenu','audience')",
                              (suspect_id,)) as cur:
            row = await cur.fetchone()
        if row:
            await db.execute("UPDATE justice_files SET jail_secs=MAX(jail_secs, ?) WHERE id=?", (jail_secs, row[0]))
            await db.commit()
            return row[0]
        cur = await db.execute(
            "INSERT INTO justice_files(suspect_id, crime, source, jail_secs, created_at) VALUES (?,?,?,?,?)",
            (suspect_id, (crime or "")[:80], source, jail_secs, real_now()))
        await db.commit()
        fid = cur.lastrowid
    from utils import ordre
    await notify(suspect_id, "⚖️ Dossier judiciaire",
                 "Un dossier est ouvert à ton nom. Tu peux demander une caution, prendre un avocat ou passer devant "
                 "un juge : menu État & factions → Justice.", "warning")
    for uid in await ordre.on_duty_users(("justice",), limit=15):
        await notify(uid, "📁 Nouveau dossier", f"Dossier #{fid} : {crime or 'arrestation'}. 👉 Justice → Dossiers", "info")
    return fid


async def get_file(file_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT f.*, u.full_name AS suspect_name, l.full_name AS lawyer_name FROM justice_files f "
                "LEFT JOIN users u ON u.user_id=f.suspect_id LEFT JOIN users l ON l.user_id=f.lawyer_id "
                "WHERE f.id=?", (file_id,)) as cur:
            row = await cur.fetchone()
    return dict(row) if row else None


async def my_file(user_id: int) -> dict | None:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(
                "SELECT id FROM justice_files WHERE suspect_id=? AND status IN ('detenu','audience') "
                "ORDER BY id DESC LIMIT 1", (user_id,)) as cur:
            row = await cur.fetchone()
    return await get_file(row[0]) if row else None


async def list_files(limit: int = 10, lawyer_id: int = 0) -> list[dict]:
    q = ("SELECT f.*, u.full_name AS suspect_name FROM justice_files f LEFT JOIN users u ON u.user_id=f.suspect_id "
         "WHERE f.status IN ('detenu','audience')")
    args: list = []
    if lawyer_id:
        q += " AND f.lawyer_id=?"
        args.append(lawyer_id)
    q += " ORDER BY (f.status='audience') DESC, f.id LIMIT ?"
    args.append(limit)
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute(q, tuple(args)) as cur:
            return [dict(r) for r in await cur.fetchall()]


def effective_bail(f: dict) -> int:
    """Caution due, après plaidoirie éventuelle."""
    b = int(f["bail"])
    return int(b * (1 - JUSTICE["plead_reduction"])) if f["plead"] == 1 else b


async def _remaining_prison(user_id: int) -> int:
    u = await get_user(user_id)
    return max(0, u.get("prison_until", 0) - now())


# ── Détenu ─────────────────────────────────────────────────────────────────────
async def request_hearing(user_id: int) -> tuple[bool, str]:
    f = await my_file(user_id)
    if not f:
        return False, "Tu n'as aucun dossier ouvert."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute(
            "UPDATE justice_files SET status='audience' WHERE id=? AND suspect_id=? AND status='detenu'",
            (f["id"], user_id),
        )
        if cur.rowcount != 1:
            await db.rollback()
            return False, "Une audience est déjà demandée ou ce dossier est clos."
        await db.commit()
    from utils import ordre
    for uid in await ordre.on_duty_users(("justice",), limit=15):
        await notify(uid, "⚖️ Audience demandée", f"Le dossier #{f['id']} demande à passer devant un juge.", "info")
    return True, "⚖️ Audience demandée : un juge examinera ton dossier."


async def hire_lawyer(user_id: int, lawyer_id: int) -> tuple[bool, str]:
    f = await my_file(user_id)
    if not f:
        return False, "Tu n'as aucun dossier ouvert."
    if f["lawyer_id"]:
        return False, "Tu as déjà un avocat."
    lw, err = await lawyer_check(lawyer_id)
    if err:
        return False, "Cet avocat n'est pas disponible."
    fee = JUSTICE["lawyer_fee"]
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            assigned = await db.execute(
                "UPDATE justice_files SET lawyer_id=? WHERE id=? AND suspect_id=? "
                "AND (lawyer_id IS NULL OR lawyer_id=0) AND status IN ('detenu','audience')",
                (lawyer_id, f["id"], user_id),
            )
            if assigned.rowcount != 1:
                await db.rollback()
                return False, "Un avocat est déjà engagé ou le dossier est clos."
            cur = await db.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                                   "WHERE user_id=? AND balance>=?", (fee, fee, user_id, fee))
            if not cur.rowcount:
                await db.rollback()
                return False, f"Honoraires : <b>{fee:,}</b> en liquide."
            credited = await db.execute(
                "UPDATE users SET balance=balance+?, total_earned=total_earned+? WHERE user_id=?",
                (fee, fee, lawyer_id),
            )
            if credited.rowcount != 1:
                await db.rollback()
                return False, "Cet avocat n'est plus disponible."
            await _log(db, user_id, "avocat_engage", lawyer_id, f"dossier {f['id']}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await notify(lawyer_id, "👨‍⚖️ Nouveau client",
                 f"{await _name(user_id)} t'engage (dossier #{f['id']}) : +{fee:,}. 👉 Justice → Mes clients", "success")
    return True, f"👨‍⚖️ Avocat engagé (-{fee:,}). Il va plaider ton dossier."


async def pay_bail(user_id: int) -> tuple[bool, str]:
    f = await my_file(user_id)
    if not f or f["bail"] <= 0:
        return False, "Aucune caution n'a été fixée par un juge."
    async with db_connection(row_factory=aiosqlite.Row) as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute(
                "SELECT id, suspect_id, bail, plead, judge_id, status FROM justice_files "
                "WHERE id=? AND suspect_id=? AND status IN ('detenu','audience')",
                (f["id"], user_id),
            ) as cur:
                current = await cur.fetchone()
            if not current:
                await db.rollback()
                return False, "Ce dossier est déjà clos."
            current = dict(current)
            if int(current.get("bail", 0) or 0) <= 0:
                await db.rollback()
                return False, "Aucune caution n'a été fixée par un juge."
            due = effective_bail(current)
            cur = await db.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+?, prison_until=0 "
                                   "WHERE user_id=? AND balance>=?", (due, due, user_id, due))
            if not cur.rowcount:
                await db.rollback()
                return False, f"Il te faut <b>{due:,}</b> en liquide pour la caution."
            await coffre_add(db, "justice", due)
            closed = await db.execute(
                "UPDATE justice_files SET status='clos', verdict='caution', closed_at=? "
                "WHERE id=? AND suspect_id=? AND status IN ('detenu','audience')",
                (real_now(), f["id"], user_id),
            )
            if closed.rowcount != 1:
                await db.rollback()
                return False, "Ce dossier est déjà clos."
            await _log(db, user_id, "caution_payee", current.get("judge_id") or 0, f"{due}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"💰 Caution payée (-{due:,}) : tu es libéré(e) !"


# ── Avocat ─────────────────────────────────────────────────────────────────────
async def plead(lawyer_id: int, file_id: int) -> tuple[bool, str]:
    lw, err = await lawyer_check(lawyer_id)
    if err:
        return False, err
    f = await get_file(file_id)
    if not f or f["status"] not in OPEN_STATUS or f["lawyer_id"] != lawyer_id:
        return False, "Ce n'est pas ton client."
    if f["plead"] != 0:
        return False, "Tu as déjà plaidé ce dossier."
    intel = await get_skill(lawyer_id, JUSTICE["plead_skill"])
    chance = min(0.95, JUSTICE["plead_base"] + intel * JUSTICE["plead_per_intelligence"])
    ok = random.random() < chance
    async with db_connection() as db:
        await db.execute("UPDATE justice_files SET plead=? WHERE id=?", (1 if ok else -1, file_id))
        await db.execute("UPDATE ordre_staff SET activity=activity+1 WHERE user_id=?", (lawyer_id,))
        await db.execute("UPDATE faction_members SET activity_score=activity_score+1 WHERE user_id=?", (lawyer_id,))
        await _log(db, lawyer_id, "plaidoirie_ok" if ok else "plaidoirie_ratee", f["suspect_id"], f"dossier {file_id}")
        await db.commit()
    await notify(f["suspect_id"], "👨‍⚖️ Plaidoirie",
                 "Ton avocat a convaincu le tribunal : -35 % sur ta caution et ta peine !" if ok
                 else "Ton avocat n'a pas convaincu le tribunal cette fois.", "success" if ok else "warning")
    return True, ("🎤 Plaidoirie réussie ! (-35 % sur la caution et la peine)" if ok
                  else "🎤 Plaidoirie ratée : le juge n'est pas convaincu.")


# ── Juge ───────────────────────────────────────────────────────────────────────
async def set_bail(judge_id: int, file_id: int, amount: int) -> tuple[bool, str]:
    jg, err = await judge_check(judge_id)
    if err:
        return False, err
    f = await get_file(file_id)
    if not f or f["status"] not in OPEN_STATUS:
        return False, "Dossier introuvable ou clos."
    amount = max(0, min(int(amount), JUSTICE["bail_max"]))
    async with db_connection() as db:
        await db.execute("UPDATE justice_files SET bail=?, judge_id=? WHERE id=?", (amount, judge_id, file_id))
        await db.execute("UPDATE ordre_staff SET activity=activity+1 WHERE user_id=?", (judge_id,))
        await db.execute("UPDATE faction_members SET activity_score=activity_score+1 WHERE user_id=?", (judge_id,))
        await _log(db, judge_id, "caution_fixee", f["suspect_id"], f"{amount}")
        await db.commit()
    if amount:
        await notify(f["suspect_id"], "💰 Caution fixée",
                     f"Un juge fixe ta caution à <b>{amount:,}</b>. Tu peux la payer pour sortir (menu Justice).", "info")
        return True, f"💰 Caution fixée à {amount:,}."
    await notify(f["suspect_id"], "💰 Caution refusée", "Le juge refuse la libération sous caution.", "warning")
    return True, "🚫 Pas de caution : libération sous caution refusée."


async def judge_file(judge_id: int, file_id: int, verdict: str, amount: int = 0) -> tuple[bool, str]:
    """verdict : acquit | amende (montant) | prison (secondes de jeu)."""
    jg, err = await judge_check(judge_id)
    if err:
        return False, err
    f = await get_file(file_id)
    if not f or f["status"] not in OPEN_STATUS:
        return False, "Dossier introuvable ou déjà jugé."
    if f["suspect_id"] == judge_id:
        return False, "Un juge ne se juge pas lui-même."
    uid = f["suspect_id"]
    reduce = (1 - JUSTICE["plead_reduction"]) if f["plead"] == 1 else 1.0
    text = ""
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            if verdict == "acquit":
                await db.execute("UPDATE users SET prison_until=0 WHERE user_id=?", (uid,))
                text = "Acquitté(e) : tu es libre !"
                note = "acquitté"
            elif verdict == "amende":
                fine = max(0, min(int(amount * reduce), JUSTICE["fine_max"]))
                async with db.execute("SELECT balance FROM users WHERE user_id=?", (uid,)) as cur:
                    bal = (await cur.fetchone())[0]
                fine = min(fine, bal)
                await db.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+?, prison_until=0 "
                                 "WHERE user_id=?", (fine, fine, uid))
                await coffre_add(db, "justice", fine)
                text = f"Condamné(e) à une amende de <b>{fine:,}</b> : tu es libre."
                note = f"amende {fine}"
            elif verdict == "prison":
                secs = max(60, min(int(amount * reduce), JUSTICE["sentence_max"]))
                await db.execute("UPDATE users SET prison_until=? WHERE user_id=?", (now() + secs, uid))
                text = f"Condamné(e) à <b>{secs // 60} min</b> de prison."
                note = f"prison {secs}"
            else:
                await db.rollback()
                return False, "Verdict inconnu."
            await db.execute("UPDATE justice_files SET status='clos', verdict=?, judge_id=?, closed_at=? WHERE id=?",
                             (note, judge_id, real_now(), file_id))
            await db.execute("UPDATE ordre_staff SET activity=activity+2 WHERE user_id=?", (judge_id,))
            await db.execute("UPDATE faction_members SET activity_score=activity_score+2 WHERE user_id=?", (judge_id,))
            await _log(db, judge_id, "verdict", uid, f"dossier {file_id} {note}")
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await notify(uid, "⚖️ Jugement", text, "success" if verdict == "acquit" else "crime")
    if f["lawyer_id"]:
        await notify(f["lawyer_id"], "⚖️ Jugement rendu", f"Dossier #{file_id} : {note}.", "info")
    return True, f"⚖️ Dossier #{file_id} jugé : {note}."


async def issue_warrant(judge_id: int, suspect_id: int, reason: str) -> tuple[bool, str]:
    """Mandat d'arrêt : le joueur devient « recherché » et la police / l'armée sont alertées."""
    jg, err = await judge_check(judge_id)
    if err:
        return False, err
    from utils import ordre
    if suspect_id == judge_id:
        return False, "Tu ne peux pas te viser toi-même."
    if await ordre.is_protected(suspect_id):
        return False, "Cette personne est protégée."
    t = real_now()
    async with db_connection() as db:
        async with db.execute("SELECT 1 FROM ordre_cases WHERE suspect_id=? AND kind='signalement' AND status IN ('open','solved')",
                              (suspect_id,)) as cur:
            if await cur.fetchone():
                return False, "Cette personne est déjà recherchée."
        cur = await db.execute(
            "INSERT INTO ordre_cases(kind, crime, suspect_id, victim_id, created_at, open_at, status) "
            "VALUES ('signalement',?,?,0,?,?, 'open')", (f"Mandat : {reason}"[:80], suspect_id, t, t))
        cid = cur.lastrowid
        await db.execute("UPDATE ordre_staff SET activity=activity+1 WHERE user_id=?", (judge_id,))
        await _log(db, judge_id, "mandat", suspect_id, f"dossier {cid} {reason}")
        await db.commit()
    name = await _name(suspect_id)
    for uid in await ordre.on_duty_users(("police", "armee"), limit=40):
        await notify(uid, "📜 Mandat d'arrêt", f"Un juge ordonne l'arrestation de <b>{name}</b> : {reason}. Dossier #{cid}.", "crime")
    await notify(suspect_id, "📜 Mandat d'arrêt", "Un juge a délivré un mandat d'arrêt contre toi : la police et l'armée te recherchent !", "crime")
    return True, f"📜 Mandat délivré contre {name} (dossier #{cid}) : police et armée alertées."


async def maintenance() -> None:
    """Clôt les dossiers dont la peine est purgée (ou le détenu libéré)."""
    t_game = now()
    async with db_connection() as db:
        await db.execute(
            "UPDATE justice_files SET status='clos', verdict='peine purgée', closed_at=? WHERE status IN ('detenu','audience') "
            "AND suspect_id IN (SELECT user_id FROM users WHERE prison_until<=?)", (real_now(), t_game))
        await db.commit()
