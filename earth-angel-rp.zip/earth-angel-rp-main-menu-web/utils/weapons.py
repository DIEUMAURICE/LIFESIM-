# utils/weapons.py — 🔫 Armes : marché noir, arsenal personnel, chambres d'armes (armée & police)
"""
• Marché noir : on n'y vend plus que des ARMES. Acheter une arme donne un chargeur ; racheter la même arme
  ajoute un chargeur (jusqu'à WEAPON_MAX_MAGS). Des paquets de munitions se vendent aussi. Munitions LIMITÉES.
• Une arme équipée (avec munitions) augmente les chances des crimes (sur le bot comme sur les joueurs),
  consomme des munitions, et sert de riposte quand la victime est armée.
• Armée : les ARMURIERS (et la direction) fabriquent armes et munitions avec l'argent du coffre ; elles vont dans
  la chambre d'armes de l'armée. Tout militaire peut y prendre une arme, l'équiper, la rendre.
• Police : sa chambre d'armes n'est alimentée que par les LIVRAISONS de l'armée (armuriers / direction).
Toute la logique est ici ; les écrans sont dans handlers/weapons.py.
"""
import logging

import aiosqlite

from config import WEAPONS, WEAPON_MAX_MAGS, ARMS, ARMS_CRAFT_ROLES, ARMS_DELIVER_ROLES
from database import db_connection, get_user
from utils.factions import coffre_add
from database import now as real_now      # horloge du jeu (comme tout le module Ordre public)
from utils.notify import notify

logger = logging.getLogger(__name__)

ARMORY_FACTIONS = ("armee", "police")


def info(key: str) -> dict:
    return WEAPONS[key]


def max_ammo(key: str) -> int:
    return WEAPONS[key]["mag"] * WEAPON_MAX_MAGS


# ─────────────────────────────────────────────────────────────────────────────
#  Arsenal personnel
# ─────────────────────────────────────────────────────────────────────────────
async def list_weapons(user_id: int) -> list[dict]:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM user_weapons WHERE user_id=? ORDER BY weapon", (user_id,)) as cur:
            rows = await cur.fetchall()
    out = []
    for r in rows:
        if r["weapon"] in WEAPONS:
            out.append({**dict(r), **WEAPONS[r["weapon"]], "key": r["weapon"]})
    return out


async def equipped(user_id: int) -> dict | None:
    for w in await list_weapons(user_id):
        if w["equipped"]:
            return w
    return None


async def active_weapon(user_id: int) -> dict | None:
    """Arme équipée ET utilisable (assez de munitions pour un usage), sinon None."""
    w = await equipped(user_id)
    return w if w and w["ammo"] >= w["per_use"] else None


async def buy_weapon(user_id: int, key: str) -> tuple[bool, str]:
    """Marché noir : une arme (avec un chargeur) ; la racheter ajoute un chargeur de munitions."""
    w = WEAPONS.get(key)
    if not w or not w["market"]:
        return False, "Cette arme n'est pas en vente."
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT ammo FROM user_weapons WHERE user_id=? AND weapon=?", (user_id, key)) as cur:
                row = await cur.fetchone()
            have = row[0] if row else None
            if have is not None and have + w["mag"] > max_ammo(key):
                await db.rollback()
                return False, f"Tu portes déjà le maximum de munitions pour cette arme ({max_ammo(key)})."
            cur = await db.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                                   "WHERE user_id=? AND balance>=?", (w["price"], w["price"], user_id, w["price"]))
            if not cur.rowcount:
                await db.rollback()
                return False, f"Il te faut <b>{w['price']:,}</b> en liquide."
            if have is None:
                await db.execute("INSERT INTO user_weapons(user_id, weapon, ammo, equipped, source) VALUES (?,?,?,0,'noir')",
                                 (user_id, key, w["mag"]))
            else:
                await db.execute("UPDATE user_weapons SET ammo=ammo+? WHERE user_id=? AND weapon=?", (w["mag"], user_id, key))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    if have is None:
        return True, f"{w['emoji']} <b>{w['name']}</b> acheté(e) (-{w['price']:,}) avec <b>{w['mag']}</b> munitions."
    return True, f"{w['emoji']} Même arme rachetée : +{w['mag']} munitions (total {have + w['mag']}) (-{w['price']:,})."


async def buy_ammo(user_id: int, key: str) -> tuple[bool, str]:
    w = WEAPONS.get(key)
    if not w or not w["market"]:
        return False, "Pas de munitions en vente pour cette arme."
    cost = w["ammo_price"] * w["mag"]
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT ammo FROM user_weapons WHERE user_id=? AND weapon=?", (user_id, key)) as cur:
                row = await cur.fetchone()
            if not row:
                await db.rollback()
                return False, "Tu ne possèdes pas cette arme."
            if row[0] + w["mag"] > max_ammo(key):
                await db.rollback()
                return False, f"Maximum atteint ({max_ammo(key)} munitions)."
            cur = await db.execute("UPDATE users SET balance=balance-?, total_spent=total_spent+? "
                                   "WHERE user_id=? AND balance>=?", (cost, cost, user_id, cost))
            if not cur.rowcount:
                await db.rollback()
                return False, f"Il te faut <b>{cost:,}</b> en liquide."
            await db.execute("UPDATE user_weapons SET ammo=ammo+? WHERE user_id=? AND weapon=?", (w["mag"], user_id, key))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"🔶 +{w['mag']} munitions pour {w['name']} (-{cost:,})."


async def equip(user_id: int, key: str | None) -> tuple[bool, str]:
    """Équipe l'arme `key` (une seule à la fois) ; key=None → tout ranger."""
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            await db.execute("UPDATE user_weapons SET equipped=0 WHERE user_id=?", (user_id,))
            if key:
                cur = await db.execute("UPDATE user_weapons SET equipped=1 WHERE user_id=? AND weapon=?", (user_id, key))
                if not cur.rowcount:
                    await db.rollback()
                    return False, "Tu ne possèdes pas cette arme."
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"{WEAPONS[key]['emoji']} {WEAPONS[key]['name']} équipé(e)." if key else "🎒 Arme rangée."


async def spend_ammo(user_id: int, key: str, n: int) -> bool:
    async with db_connection() as db:
        cur = await db.execute("UPDATE user_weapons SET ammo=ammo-? WHERE user_id=? AND weapon=? AND ammo>=?",
                               (n, user_id, key, n))
        await db.commit()
    return bool(cur.rowcount)


async def use_for_action(user_id: int, need_firearm: bool = False) -> tuple[float, str, bool]:
    """Utilise l'arme équipée pour une action (crime…). → (bonus de chance, message, ok).
    ok=False si une arme à feu est exigée et qu'il n'y en a pas d'utilisable."""
    w = await active_weapon(user_id)
    if need_firearm and not (w and w["firearm"]):
        return 0.0, "🔫 Il te faut une arme à feu équipée avec des munitions (marché noir ou armurerie).", False
    if not w:
        return 0.0, "", True
    if not await spend_ammo(user_id, w["key"], w["per_use"]):
        return 0.0, "", not need_firearm
    left = w["ammo"] - w["per_use"]
    return w["bonus"], f"{w['emoji']} {w['name']} utilisé(e) (-{w['per_use']} munitions, reste {left}).", True


# ─────────────────────────────────────────────────────────────────────────────
#  Chambres d'armes (armée & police)
# ─────────────────────────────────────────────────────────────────────────────
async def armory_stock(faction: str) -> list[dict]:
    async with db_connection(row_factory=aiosqlite.Row) as db:
        async with db.execute("SELECT * FROM armory WHERE faction=?", (faction,)) as cur:
            rows = {r["weapon"]: dict(r) for r in await cur.fetchall()}
    return [{"key": k, **WEAPONS[k], "qty": rows.get(k, {}).get("qty", 0), "rounds": rows.get(k, {}).get("rounds", 0)}
            for k in WEAPONS]


async def _arms_actor(user_id: int, faction: str, roles: tuple[str, ...]) -> tuple[dict | None, str]:
    from utils import ordre
    st = await ordre.get_staff(user_id)
    if not st or st["faction"] != faction:
        return None, "Réservé aux membres de cette faction."
    if st["role"] not in roles:
        return None, "Ton poste ne permet pas cette action."
    return st, ""


async def _craft_cooldown(db, user_id: int) -> int:
    async with db.execute("SELECT until FROM ordre_status WHERE user_id=? AND kind='craftcd' AND until>?",
                          (user_id, real_now())) as cur:
        row = await cur.fetchone()
    return row[0] - real_now() if row else 0


async def craft_weapon(user_id: int, key: str) -> tuple[bool, str]:
    """Armée : fabrique une arme (payée par le coffre) → chambre d'armes de l'armée."""
    w = WEAPONS.get(key)
    if not w:
        return False, "Arme inconnue."
    st, err = await _arms_actor(user_id, "armee", ARMS_CRAFT_ROLES)
    if err:
        return False, err
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            cd = await _craft_cooldown(db, user_id)
            if cd:
                await db.rollback()
                return False, f"⏳ L'atelier refroidit : encore {cd} s."
            async with db.execute("SELECT budget FROM faction_state WHERE faction='armee'") as cur:
                row = await cur.fetchone()
            if (row[0] if row else 0) < w["craft"]:
                await db.rollback()
                return False, f"Le coffre de l'armée est insuffisant (il faut {w['craft']:,})."
            async with db.execute("SELECT qty FROM armory WHERE faction='armee' AND weapon=?", (key,)) as cur:
                have = await cur.fetchone()
            if have and have[0] >= ARMS["max_stock"]:
                await db.rollback()
                return False, "Chambre d'armes pleine pour cette arme."
            await coffre_add(db, "armee", -w["craft"])
            await db.execute(
                "INSERT INTO armory(faction, weapon, qty, rounds) VALUES ('armee',?,1,0) "
                "ON CONFLICT(faction, weapon) DO UPDATE SET qty=qty+1", (key,))
            await db.execute(
                "INSERT INTO ordre_status(user_id, kind, until, by_id) VALUES (?,'craftcd',?,0) "
                "ON CONFLICT(user_id, kind) DO UPDATE SET until=excluded.until",
                (user_id, real_now() + ARMS["craft_cooldown"]))
            await db.execute("UPDATE ordre_staff SET activity=activity+1 WHERE user_id=?", (user_id,))
            await db.execute("UPDATE faction_members SET activity_score=activity_score+1 WHERE user_id=?", (user_id,))
            await db.execute("INSERT INTO ordre_logs(ts, actor_id, action, target_id, details) VALUES (?,?,?,?,?)",
                             (real_now(), user_id, "fabrique_arme", 0, key))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"🛠️ {w['emoji']} {w['name']} fabriqué(e) → chambre d'armes de l'armée (-{w['craft']:,} au coffre)."


async def craft_ammo(user_id: int, key: str) -> tuple[bool, str]:
    """Armée : fabrique un chargeur de munitions pour une arme."""
    w = WEAPONS.get(key)
    if not w:
        return False, "Arme inconnue."
    st, err = await _arms_actor(user_id, "armee", ARMS_CRAFT_ROLES)
    if err:
        return False, err
    cost = max(1, int(w["craft"] * ARMS["ammo_craft_ratio"]))
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            cd = await _craft_cooldown(db, user_id)
            if cd:
                await db.rollback()
                return False, f"⏳ L'atelier refroidit : encore {cd} s."
            async with db.execute("SELECT budget FROM faction_state WHERE faction='armee'") as cur:
                row = await cur.fetchone()
            if (row[0] if row else 0) < cost:
                await db.rollback()
                return False, f"Le coffre de l'armée est insuffisant (il faut {cost:,})."
            await coffre_add(db, "armee", -cost)
            await db.execute(
                "INSERT INTO armory(faction, weapon, qty, rounds) VALUES ('armee',?,0,?) "
                "ON CONFLICT(faction, weapon) DO UPDATE SET rounds=MIN(rounds+?, ?)",
                (key, w["mag"], w["mag"], ARMS["max_stock"] * w["mag"]))
            await db.execute(
                "INSERT INTO ordre_status(user_id, kind, until, by_id) VALUES (?,'craftcd',?,0) "
                "ON CONFLICT(user_id, kind) DO UPDATE SET until=excluded.until",
                (user_id, real_now() + ARMS["craft_cooldown"]))
            await db.execute("UPDATE faction_members SET activity_score=activity_score+1 WHERE user_id=?", (user_id,))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"🔶 +{w['mag']} munitions {w['name']} fabriquées (-{cost:,} au coffre)."


async def deliver_to_police(user_id: int, key: str, qty: int = 1) -> tuple[bool, str]:
    """L'armée livre `qty` armes (et leurs munitions disponibles) à la chambre d'armes de la police."""
    w = WEAPONS.get(key)
    if not w or qty < 1:
        return False, "Livraison invalide."
    st, err = await _arms_actor(user_id, "armee", ARMS_DELIVER_ROLES)
    if err:
        return False, err
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT qty, rounds FROM armory WHERE faction='armee' AND weapon=?", (key,)) as cur:
                row = await cur.fetchone()
            if not row or row[0] < qty:
                await db.rollback()
                return False, f"Stock insuffisant à l'armée ({row[0] if row else 0} en chambre)."
            rounds = min(row[1], w["mag"] * qty)
            await db.execute("UPDATE armory SET qty=qty-?, rounds=rounds-? WHERE faction='armee' AND weapon=?",
                             (qty, rounds, key))
            await db.execute(
                "INSERT INTO armory(faction, weapon, qty, rounds) VALUES ('police',?,?,?) "
                "ON CONFLICT(faction, weapon) DO UPDATE SET qty=qty+excluded.qty, rounds=rounds+excluded.rounds",
                (key, qty, rounds))
            await db.execute("UPDATE faction_members SET activity_score=activity_score+1 WHERE user_id=?", (user_id,))
            await db.execute("INSERT INTO ordre_logs(ts, actor_id, action, target_id, details) VALUES (?,?,?,?,?)",
                             (real_now(), user_id, "livraison_police", 0, f"{key} x{qty} +{rounds} munitions"))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    from utils import ordre
    for uid in await ordre.on_duty_users(("police",), roles=("head",), limit=10):
        await notify(uid, "📦 Livraison de l'armée", f"L'armée livre {qty} × {w['emoji']} {w['name']} à votre chambre d'armes.", "info")
    return True, f"📦 {qty} × {w['emoji']} {w['name']} livré(s) à la police (+{rounds} munitions)."


def _can_take(st: dict) -> bool:
    from config import ORDRE_POWER_LEVEL
    return st["faction"] in ARMORY_FACTIONS and st["level"] >= ORDRE_POWER_LEVEL


async def take_weapon(user_id: int, key: str) -> tuple[bool, str]:
    """Prend une arme dans la chambre d'armes de sa faction (armée ou police) avec un chargeur au plus."""
    w = WEAPONS.get(key)
    from utils import ordre
    st = await ordre.get_staff(user_id)
    if not w or not st or not _can_take(st):
        return False, "Réservé aux agents et militaires (hors recrues / cadets)."
    faction = st["faction"]
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT 1 FROM user_weapons WHERE user_id=? AND weapon=?", (user_id, key)) as cur:
                if await cur.fetchone():
                    await db.rollback()
                    return False, "Tu possèdes déjà cette arme : rends-la ou recharge-la."
            async with db.execute("SELECT qty, rounds FROM armory WHERE faction=? AND weapon=?", (faction, key)) as cur:
                row = await cur.fetchone()
            if not row or row[0] < 1:
                await db.rollback()
                return False, "Plus aucune arme de ce type en chambre."
            rounds = min(row[1], w["mag"])
            await db.execute("UPDATE armory SET qty=qty-1, rounds=rounds-? WHERE faction=? AND weapon=?",
                             (rounds, faction, key))
            await db.execute("INSERT INTO user_weapons(user_id, weapon, ammo, equipped, source) VALUES (?,?,?,0,?)",
                             (user_id, key, rounds, faction))
            await db.execute("INSERT INTO ordre_logs(ts, actor_id, action, target_id, details) VALUES (?,?,?,?,?)",
                             (real_now(), user_id, "prend_arme", 0, f"{key} +{rounds}"))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, (f"{w['emoji']} {w['name']} retiré(e) de la chambre d'armes avec <b>{rounds}</b> munitions."
                  + ("" if rounds else " ⚠️ La chambre n'a plus de munitions : l'arme est vide."))


async def reload_weapon(user_id: int, key: str) -> tuple[bool, str]:
    """Recharge une arme de dotation avec les munitions de la chambre d'armes (un chargeur à la fois)."""
    w = WEAPONS.get(key)
    from utils import ordre
    st = await ordre.get_staff(user_id)
    if not w or not st or not _can_take(st):
        return False, "Réservé aux agents et militaires."
    faction = st["faction"]
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT ammo, source FROM user_weapons WHERE user_id=? AND weapon=?", (user_id, key)) as cur:
                mine = await cur.fetchone()
            if not mine:
                await db.rollback()
                return False, "Tu ne possèdes pas cette arme."
            room = w["mag"] - mine[0]
            if room <= 0:
                await db.rollback()
                return False, "Ton chargeur est plein."
            async with db.execute("SELECT rounds FROM armory WHERE faction=? AND weapon=?", (faction, key)) as cur:
                row = await cur.fetchone()
            take = min(room, row[0] if row else 0)
            if take <= 0:
                await db.rollback()
                return False, "La chambre d'armes n'a plus de munitions pour cette arme."
            await db.execute("UPDATE armory SET rounds=rounds-? WHERE faction=? AND weapon=?", (take, faction, key))
            await db.execute("UPDATE user_weapons SET ammo=ammo+? WHERE user_id=? AND weapon=?", (take, user_id, key))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"🔶 Rechargé(e) : +{take} munitions."


async def return_weapon(user_id: int, key: str) -> tuple[bool, str]:
    """Rend une arme de dotation (et ses munitions restantes) à la chambre d'armes."""
    from utils import ordre
    st = await ordre.get_staff(user_id)
    if not st or st["faction"] not in ARMORY_FACTIONS:
        return False, "Réservé aux membres de l'armée et de la police."
    faction = st["faction"]
    async with db_connection() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            async with db.execute("SELECT ammo, source FROM user_weapons WHERE user_id=? AND weapon=?", (user_id, key)) as cur:
                mine = await cur.fetchone()
            if not mine or mine[1] not in ARMORY_FACTIONS:
                await db.rollback()
                return False, "Cette arme ne vient pas d'une chambre d'armes."
            await db.execute("DELETE FROM user_weapons WHERE user_id=? AND weapon=?", (user_id, key))
            await db.execute(
                "INSERT INTO armory(faction, weapon, qty, rounds) VALUES (?,?,1,?) "
                "ON CONFLICT(faction, weapon) DO UPDATE SET qty=qty+1, rounds=rounds+excluded.rounds",
                (faction, key, mine[0]))
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    return True, f"↩️ {WEAPONS[key]['name']} rendu(e) à la chambre d'armes (+{mine[0]} munitions)."


async def strip_issued_weapons(user_id: int) -> None:
    """Un agent renvoyé / qui quitte rend ses armes de dotation à sa faction."""
    async with db_connection() as db:
        async with db.execute("SELECT weapon, ammo, source FROM user_weapons WHERE user_id=? AND source IN ('police','armee')",
                              (user_id,)) as cur:
            rows = await cur.fetchall()
        for weapon, ammo, source in rows:
            await db.execute("DELETE FROM user_weapons WHERE user_id=? AND weapon=?", (user_id, weapon))
            await db.execute(
                "INSERT INTO armory(faction, weapon, qty, rounds) VALUES (?,?,1,?) "
                "ON CONFLICT(faction, weapon) DO UPDATE SET qty=qty+1, rounds=rounds+excluded.rounds",
                (source, weapon, ammo))
        await db.commit()
